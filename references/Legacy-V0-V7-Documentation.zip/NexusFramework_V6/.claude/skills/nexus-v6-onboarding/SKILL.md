---
name: nexus-v6-onboarding
description: Orient a fresh agent session in NexusFramework_V6 - the pipeline stages, the data model, where state lives, and the standing rules that are not negotiable. Load this before touching V6 code or picking up a phase.
---

# NexusFramework_V6 — Agent Onboarding

V6 is a **rebuild-from-lessons** of `NexusFramework_V5` (sibling directory). It is a
standalone UE 5.8 Game project (`NexusFramework.uproject`), not a redistributable plugin.

Read this, then read the three authorities in order:
`project-specifications/AGENT-RULES.md` → `v6-master-architecture.md` →
`v6-coding-standard.md`.

## Read these before writing anything

| File | Why |
|---|---|
| `project-specifications/AGENT-RULES.md` | Standing policy. Currently: **no automated tests unless the user explicitly asks**, and the C++ coding standard. Not optional, not phase-scoped. |
| `project-specifications/v6-master-architecture.md` | Top architecture authority — above every numbered doc. |
| `project-specifications/v6-coding-standard.md` | Naming, and the **serialization warning before renaming any `UPROPERTY` boolean** — saved `.uasset` content on disk would corrupt silently. |
| `CLAUDE.md` | Where project memory lives and the append-only rule. |

## The pipeline — five stages, one direction

```
Source        Landscape Splines, read live. Never cached.
   |          FNexusLandscapeReader
   v
Mapping       Landscape entity -> stable Nexus identity (StableId, HighwayPointId).
   |          FNexusMapping, persisted to UNexusConfigAsset
   v
Representation State/City/Highway/HighwayPoint/ActivationPoint graph.
   |          FNexusRepresentationGraph
   v
Compilation   Freeze into the Runtime Schema. Editor-side, one-way.
   |          FNexusRuntimeCompiler -> FNexusRuntimeResult
   v
Runtime       Query, activate, pool. Packaged build, no editor.
              UNexusActivationSubsystem
```

**The Landscape is the source of truth.** Representation structs deliberately cache **no**
geometry — `FNexusHighwayPoint` has no `Location`/`Rotation`/`Tangent` field, only
`GetLiveLocation()` etc. that resolve through the mapped control point on every read. This
is V5's cross-map stale-reference bug designed out at the schema level; a regression test
(`Nexus.Regression.V5Lessons.HighwayPointCachesNoGeometry`) enforces it.

Compilation is the **one** sanctioned place geometry is frozen into stored values, because a
cooked build has no Landscape and no editor module. Re-compiling is what re-reads.

## The module boundary

```
NexusFrameworkEditor  ──depends on──>  NexusFramework (runtime)
        (never the reverse)
```

A runtime struct must never name an editor type. Where an editor enum is genuinely part of
the runtime contract it is **mirrored** in `Schema/Runtime/NexusRuntimeTypes.h` and guarded
by `static_assert`s in `NexusRuntimeCompiler.cpp` — so drift is a compile error. Do not
"simplify" by moving a reflected type across the boundary: its type path is referenced by
saved `.uasset` content.

Verify the boundary by building the standalone game target:
`Build.bat NexusFramework Win64 Development`.

## Where state lives — three systems, three questions

| System | Question it answers | Rules |
|---|---|---|
| `ai-change-audits/` | What was found/decided/changed | **Append-only.** Never edit an existing record; append a dated section. |
| `agent-todos/` | State of ad-hoc, non-phase work | Files move between folders. `ready-for-review/` is as far as an agent may go. |
| `project-specifications/phases/` | State of the 100-phase roadmap | A `## Status` line per fixed file. `Ready for Review` is as far as an agent may go. |

Check all three when picking up work cold. `/TODO` walks them in the right order.

## Extensibility contract — the thing most likely to be violated

Adding an Activation Point type must require **exactly two things**: a payload `USTRUCT`,
and one `FNexusActivationTypeAutoRegister`. Nothing else. No central enum, no central array,
no edit to the config asset, no per-type export code, no per-type gizmo code.

If a task seems to need a third edit, that is a signal the framework is wrong — report it,
do not route around it. `Nexus.Representation.DumpOnboardingBenchmark` measures this.

Two mechanisms make it hold, and both are generic by reflection:
- **Sub-points** — `FNexusActivationSubPointResolver`, addressed by `(FieldName, ArrayIndex)`.
  One mechanism for fixed offsets and dynamic arrays alike.
- **Export** — `ExportPayloadFieldsGenerically` walks the payload's reflected properties into
  name-keyed runtime containers.

Payloads live on the point itself (`FNexusActivationPoint::Payload`, an `FInstancedStruct`).

## Traps this project has already hit

- **Raw pointers into `TArray`s.** Binding a Details view to `&Config->Array[i]` dangles the
  moment the array grows or an element is removed. Three separate crashes. Carry the **id**
  and re-resolve, or snapshot the container's data pointer and count. See
  `2026-08-10/bug-fixed/debug-details-panel-dangling-pointer-crash.md`.
- **Namespace-scope globals calling `StaticStruct()`.** A global's constructor must never
  eagerly resolve a reflected type — it races module init and crashes on load. Use a lazy
  `TFunction<UScriptStruct*()>`.
- **Visible ≠ clickable divergence.** If something is drawn it must be selectable, and vice
  versa. Both directions have broken before, and both were gated on different categories.
- **Unresolved references are validation errors, never fallback values.** Do not substitute
  a guessed location; fail loudly and name the offending object.
- **`Q.IsNormalized()`** — an engine-level crash risk in Landscape Spline tessellation at
  certain junction rotations. Not a Nexus bug; do not "fix" it in engine code.

## Verifying your work

Build only — do not launch the editor for automation unless explicitly asked.

```
Build.bat NexusFrameworkEditor Win64 Development -Project="<repo>/NexusFramework.uproject"
Build.bat NexusFramework       Win64 Development -Project="<repo>/NexusFramework.uproject"
```

Live Coding blocks the **editor** target while the editor is open; the game target still
builds. Console commands are the inspection surface — `Nexus.Status`,
`Nexus.Representation.Dump*`, `Nexus.Compilation.*`, `Nexus.Verification.*`,
`Nexus.Gizmo.AuditTypeConsistency`.

## What V6 reuses from V5 verbatim, and what it redesigned

Stated explicitly because `v6-phase-verification.md` requires it rather than leaving it
implicit:

| Convention | V6 |
|---|---|
| `agent-todos/` folder-move task queue | **Reused** from V5's proven pattern, unchanged. |
| `/TODO` command | **Reused** in shape; rewritten for V6's own two work sources (todos + phases). |
| Completion records | **Reused** field set (Task/Category/Phase/Status/Dates/Notes). |
| Memory location | **Redesigned** — V6 mandates `ai-change-audits/` only, append-only, and forbids `.claude/` project memory. |
| Onboarding skill | **Redesigned** — this file. V5's referenced Load Layout and old struct names that no longer exist. |
| Runtime schema | **Extended**, not replaced — V5's hierarchical + flat duality kept deliberately. |
| Activation types | **Redesigned** — V5's fixed 4-value enum replaced by an `FName` type registry. |
