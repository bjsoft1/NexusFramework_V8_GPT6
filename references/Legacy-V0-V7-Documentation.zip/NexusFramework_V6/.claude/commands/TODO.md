---
description: Pick up the next unit of V6 work — either an ad-hoc agent-todos task or the next roadmap phase — and implement it end-to-end, per agent-todos/AGENT-TODO-RULES.md and project-specifications/09-development-rules.md rule 12
argument-hint: [optional: task filename, keyword, or a phase number like "05" to pick a specific item instead of auto-selecting]
---

Read `project-specifications/AGENT-RULES.md` first — standing agent policy (currently:
no automated tests unless the user explicitly asks) applies to every step below,
including B5.

V6 has **two** sources of work — check both, in this order:

1. Read `agent-todos/AGENT-TODO-RULES.md` in full (source of truth for the
   `agent-todos/` workflow — if this command file and that file ever disagree, the
   rules file wins).
2. Report anything currently sitting in `agent-todos/active/` (another task may already
   be mid-flight) — do not silently take it over.
3. List `agent-todos/ready-for-development/` (search recursively — tasks may be nested
   in subfolders).
   - If the user supplied `$ARGUMENTS` matching an agent-todos task, use it.
   - Otherwise, if this folder is non-empty, select exactly ONE task using the rules
     file's priority order (explicit priority > blocking/foundation tasks > older tasks
     > first ready task) and follow Steps A below.
   - If this folder is empty, fall through to Step 4 (roadmap phases).
4. **Roadmap phases**: read `project-specifications/PHASE-STATUS.md` for the current
   state of all 100 phases.
   - If `$ARGUMENTS` names a specific phase number, use that phase.
   - Otherwise select the lowest-numbered phase whose `## Status` is `Not started`
     (never skip ahead of an earlier incomplete phase without an explicit reason — see
     `project-specifications/09-development-rules.md`'s "Do not jump phases").
   - If every phase is `Complete`, report that clearly and stop.
   - Follow Steps B below.

## Step A — agent-todos task

A1. Move the selected task file to `agent-todos/active/` (`git mv` if tracked).
A2. Read the complete task file. Before writing any code, re-verify the premise against
    the current codebase — never assume a reported bug's cause, or its continued
    existence, is correct without checking.
A3. Check `ai-change-audits/README.md`'s "Current open threads" and
    `project-specifications/` for anything already known about this area.
A4. Implement only this task — no silent scope expansion; leave a note if it reveals
    separate work.
A5. Build the affected code and fix any errors introduced.
A6. Append the completion record (exact shape in `AGENT-TODO-RULES.md` rule 8).
A7. Move the task file to `agent-todos/ready-for-review/`. **Never** move it to
    `ready-for-qa/` or `closed/` — only the user does that.
A8. If this is a durable finding (root cause, architecture decision), also add a record
    under `ai-change-audits/` per `CLAUDE.md`.
A9. Report per the "Report back" shape below, then stop.

## Step B — roadmap phase

**Do not write `## Status: In progress` at the start.** Only write a phase's `## Status`
**once**, at the very end, once work is genuinely done — never as a routine "I've
started" marker. Every status write triggers a real docs-site rebuild and costs time;
the user tracks what's being worked on themselves and doesn't need a file write to know
it (2026-08-09, see `project-specifications/09-development-rules.md` rule 12's note on
this). The one exception: if work genuinely gets stuck on an external dependency/
decision, write `Blocked` — that's a real state change worth recording, not a routine
start-of-work marker.

B1. Read the complete phase file — Objective, Allowed, Not Allowed, Completion Criteria,
    References — in full before writing anything.
B2. Read every doc it references under `project-specifications/` (the `04`–`14`
    architecture docs, `v5-complete-reference.md` where relevant) — do not implement
    against assumptions when the doc set exists precisely to avoid that.
B3. Check `ai-change-audits/README.md` for anything already logged about this phase's
    area (later phases will have real entries; early phases may find none yet).
B4. Implement **only** what this phase's Allowed/Completion Criteria list — the
    Not Allowed list is a hard boundary, not a suggestion. Do not implement a later
    phase's scope early "since it's related."
B5. Build and fix any errors — this is the only automated verification an agent performs
    (per `AGENT-RULES.md`'s Agent Testing Policy: do not write or run automated tests,
    do not launch the editor for automation, unless the user explicitly asks). For
    Completion Criteria that need in-editor checks/manual QA/benchmarks, do not attempt
    them and do not claim they passed — write down exactly what the user should manually
    verify in Unreal Editor instead, in both the phase file and the report below.
B6. Check off completed Completion Criteria items (`- [x]`) in the phase file; leave
    unmet ones unchecked rather than claiming full verification that didn't happen.
B7. Set the phase's `## Status` block (fixed-line format, rule 12 in
    `09-development-rules.md`) to `Ready for Review` — the single status write for this
    whole phase (direct file edit, not the server API, so it doesn't depend on
    `html-docs/server.js` happening to be running) — this is as far as an agent may
    advance a phase's status. Change ONLY the first line (`<Stage>`) to `Ready for
    Review` and its own `Ready for Review:` field to `<date+time>` — leave the other
    three dated fields and any free-form notes below them exactly as they were:
    ```
    Ready for Review
    Ready for Review: <date+time>
    In Review:
    Ready for QA:
    Complete:
    ```
    **Never** set `Ready for QA` or `Complete` — only the user does that (rule 12,
    `09-development-rules.md`). This is true even with unmet/unchecked criteria from
    B6 — "Ready for Review" means implementation + build-verification is done and it's
    the human's turn, not that every criterion was already confirmed; note what's still
    open in the phase file and the report below.
B8. Regenerate the docs site: `node html-docs/build.js`.
B9. If this phase's work is a durable finding (root cause, architecture decision, a
    deviation from what the phase file originally said), add a record under
    `ai-change-audits/` per `CLAUDE.md` — the phase file tracks planned-vs-done, not
    durable project memory.
B10. Report per the "Report back" shape below, then stop.

## Report back (either path), then stop and wait for the user

```
TODO completed.

Item: <agent-todos task name, OR "Phase NN — <title>">
Status: Ready for Review
Completed: <YYYY-MM-DD HH:MM> <TIMEZONE>

Build: PASS
Manual verification needed from user: <what to check in-editor, or "none">
(No automated test run/added — see AGENT-RULES.md's Agent Testing Policy.)

Moved / updated:
  agent-todos: active/ -> ready-for-review/     (Step A path)
  OR
  phases/phase-NN*.md: Not started -> Ready for Review   (Step B path - one write, not two)
```

Never pick up more than one item (one agent-todos task, or one phase) per `/TODO`
invocation. Never advance anything to `Ready for QA` or `Complete`/`closed/` — that is
always the user's decision, not the agent's, on both the phase and agent-todos systems.
Never delete a task or phase file.
