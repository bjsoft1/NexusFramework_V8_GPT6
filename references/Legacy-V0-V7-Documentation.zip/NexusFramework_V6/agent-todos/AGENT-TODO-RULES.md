# Agent TODO Workflow Rules

This is V6's live task queue for work that is **not** a whole roadmap phase — a bug
found mid-phase, a small ad-hoc feature ask, a follow-up fix. If the work item IS a
roadmap phase (`project-specifications/phases/phase-NN*.md`), it does not go through
this folder-move system at all — see "Relationship to roadmap phases" below.

This file is the source of truth for the workflow. If `.claude/commands/TODO.md` ever
disagrees with this file, this file wins.

## Folder states

```
requirement-pending/     — raw ask, not yet scoped into an actionable task
      ↓
ready-for-development/   — scoped, actionable, waiting to be picked up
      ↓
active/                  — an agent is currently working this task
      ↓
ready-for-review/        — agent's implementation + build verification done,
                            awaiting HUMAN code review
      ↓
ready-for-qa/            — code review passed, awaiting HUMAN QA/testing pass
      ↓
closed/YYYY-MM/          — QA passed, task done
```

A task is a single `.md` (or `.txt`) file that physically moves between these folders
(`git mv` if tracked) as its state changes. Subfolders under `ready-for-development/`
(e.g. `bugs/regression-bugs/`) are fine for organization — search recursively when
listing, don't assume a flat folder.

## Who may move a task where

- `requirement-pending/` → `ready-for-development/`: user, or an agent explicitly asked
  to scope a raw ask into an actionable task.
- `ready-for-development/` → `active/`: an agent, via `/TODO` or when explicitly asked to
  pick up a specific task.
- `active/` → `ready-for-review/`: the agent that did the work, once implemented and
  build-verified.
- `ready-for-review/` → `ready-for-qa/`: **user only.** An agent must never move a task
  here itself, even if it believes the review would pass.
- `ready-for-qa/` → `closed/YYYY-MM/`: **user only.**

This mirrors the phase Status vocabulary's ownership rule in
`project-specifications/09-development-rules.md` rule 12 (`Ready for Review` is as far
as an agent may go unassisted) — the same boundary, two different mechanisms (folder
move here, a `## Status` line for phases).

## Rules

1. Never pick up more than one task per `/TODO` invocation.
2. Never move a task directly from `ready-for-development/` to `ready-for-qa/` or
   `closed/` — always through `active/` → `ready-for-review/` first.
3. Never delete a task file. Never skip hooks or move a task backward silently — if a
   review fails, the user moves it back to `active/` (or a new task file) with notes,
   rather than the original file being edited to hide the failed attempt.
4. Before writing any code: re-verify the premise against the current codebase — never
   assume a reported bug's cause, or its continued existence, is correct without
   checking (project-wide rule, see `project-specifications/09-development-rules.md`).
5. Check `ai-change-audits/README.md`'s "Current open threads" and this project's
   `.claude/skills/` (once one exists) for anything already known about the area before
   making changes.
6. Implement only the task at hand. If it reveals separate work, leave a note in the
   task file rather than silently expanding scope.
7. Build the affected module/script and fix any errors introduced by the change.
8. A completed task's `## Completed` section records:
   ```
   ## Completed

   Task: <short task title>
   Category: <bug-fixed / feature-add / research / others>
   Phase: <related phases/NN if any, else "N/A">
   Status: Ready for Review
   Completed Date: <YYYY-MM-DD>
   Completed Time: <HH:MM TIMEZONE>

   Implemented and build verified.
   Ready for user review.

   ## Verification

   - <check 1>
   - <check 2>
   ```
9. If the task represents a durable finding (root cause, architecture decision) worth
   remembering long-term, also add a record under `ai-change-audits/` per `CLAUDE.md` —
   this file only tracks workflow state, not durable project memory.

## Relationship to roadmap phases

`project-specifications/phases/phase-NN*.md` are V6's primary, pre-planned units of
work — each has its own fixed, numbered file path that other docs cross-reference by
relative link, so phases are **not** moved between folders the way tasks in this folder
are. A phase's state lives in that same file's `## Status` line instead (six-value
vocabulary: `Not started` / `Blocked` / `In progress` / `Ready for Review` /
`Ready for QA` / `Complete` — see `09-development-rules.md` rule 12), editable by hand or
via `html-docs/server.js`'s tracker UI. The same agent/user ownership boundary applies
either way: an agent may advance a phase as far as `Ready for Review`, never further.

Use `agent-todos/` for anything discovered *while* working a phase that isn't itself
that phase's own scope (a bug in already-built code, a small unplanned fix) — don't
silently fold it into the phase's own commit, and don't create a duplicate phase-like
file for it either.
