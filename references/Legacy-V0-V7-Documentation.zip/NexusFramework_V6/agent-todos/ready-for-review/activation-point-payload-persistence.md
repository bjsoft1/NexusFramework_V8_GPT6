# Activation Point payload persistence (the keystone gap)

## Context

Raised by the user on 2026-08-22 after Phases 73–78 landed, choosing this over starting
Phase 79 or Phase 80 directly. Not a roadmap phase of its own — it is a cross-cutting
architecture decision flagged as open since **Phase 46** and re-confirmed by **Phase 75's
GAP 1** (`ai-change-audits/2026-08-22/feature-add/phase-75-onboarding-checklist-proof-five-types.md`).

## Problem

`UNexusConfigAsset::ActivationPoints` is a `TArray<FNexusActivationPoint>` holding
**base-only** values with no storage for a type's specialized payload. Its own doc comment
has said since Phase 46 that the harder question — "flat array? per-type arrays?
`FInstancedStruct`-based heterogeneous storage?" — remains open.

Consequences that all trace back to this one gap:

- Every type declaring sub-point fields — Traffic Light, Crosswalk, Bus Stop, Seat,
  Parking, and all five of Phase 75's facilities — can only live in the **session-only**
  `FNexusActivationPointTestStore`. Nothing a designer authors survives an editor restart.
- The "export" leg of Phases 73/74/75 cannot complete.
- Phases 55, 59 are `Blocked`; 63, 68, 72 are unstarted for the same reason.
- Phase 77's "does an undone edit clear a Diagnostics warning?" criterion is only partly
  exercisable, because the gizmo edits data that is outside the config asset entirely.
- The gizmo tool's real-point loop (`FindClosestSubPointHit`) is disabled, with a comment
  marking exactly where it would be reinstated once real points can carry payloads.

## Decision

**`FInstancedStruct`**, stored on `FNexusActivationPoint` itself.

Evaluated three options:

| Option | Verdict |
|---|---|
| **Per-type arrays** on the config asset (`TArray<FNexusTrafficLightActivation> …`) | **Rejected.** Every new object type would edit the config asset — reintroducing exactly the closed-enum/zero-edit-extensibility failure that `12-v6-activation-point-system.md` exists to prevent, and that Phase 75 just measured the cost of on the Generation side (GAP 2). |
| **Manual byte blob** (mirroring the test store's `TArray<uint8>` + `UScriptStruct*`) | **Rejected.** Works, but hand-rolls what the engine already does properly: no tagged/versioned serialization, no reflection, no Details-panel editing, no undo integration. |
| **`FInstancedStruct`** | **Chosen.** In `CoreUObject` as of UE 5.5+ (`StructUtils/InstancedStruct.h`) — already a dependency, no plugin or new module needed. Heterogeneous, reflected, tagged-serialized, and the built-in `StructUtilsEditor` module registers `FInstancedStructDetails`, so the Details panel gets a type picker plus inline property editing for free. |

**On the base struct, not a side table.** A `TMap<FGuid, FInstancedStruct>` on the config
asset would keep `FNexusActivationPoint` untouched but introduces a sync burden (delete a
point → orphaned payload) and splits one logical object across two transactions. Storing it
on the point makes create/delete/undo atomic.

This is **not** a violation of Phase 21's "do not add feature-specific fields to the shared
base struct" rule — the rule targets *feature-specific* fields (a traffic light's LED
offset). `FInstancedStruct Payload` is the generic mechanism that rule points *to*
("specialize via a payload struct instead"), finally made persistable.

## Scope

1. `FNexusActivationPoint::Payload` (`FInstancedStruct`) + accessors.
2. Unify `FNexusActivationPointTestStore` onto the same field — test and real data then use
   one identical mechanism, which is itself the proof it works.
3. `FNexusActivationSubPointResolver` point-only convenience overloads.
4. Type-aware creation + payload reconciliation for real, persisted points.
5. Reinstate gizmo sub-point selection/editing on real config points, transacted properly
   against the config asset (`FScopedTransaction` + `Modify()`).
6. Validation: flag a point whose registered Type and stored Payload disagree.
7. Docs: record the decision in `12-v6-activation-point-system.md`, append to Phase 21/46,
   and close the open thread in `ai-change-audits/README.md`.

## Notes

- No automated tests, per `project-specifications/AGENT-RULES.md`.
- Serialization: adding a new `UPROPERTY` is additive and safe for existing saved
  `.uasset` content. No existing property is renamed — see `v6-coding-standard.md`'s
  serialization-risk section.

## Status

Active — started 2026-08-22.

## Completed

Task: Activation Point payload persistence (FInstancedStruct on the base struct)
Category: others
Phase: N/A (cross-cutting; flagged by Phase 46, re-reported as Phase 75's GAP 1)
Status: Ready for Review
Completed Date: 2026-08-22
Completed Time: 16:43 GMT+5:45

Implemented and build verified (UE 5.8, Development, Win64 — built after each stage).
Ready for user review.

Full record: `ai-change-audits/2026-08-22/others/activation-point-payload-persistence.md`
Architecture decision: `project-specifications/12-v6-activation-point-system.md` →
"Payload persistence — RESOLVED 2026-08-22".

### Scope note (rule 6 — work this revealed but did not do)

- The Runtime Compiler is still unbuilt. Phases 55/59 stay `Blocked` and the export leg of
  Phases 73/74/75 stays incomplete — that is Phases 80–85's scope, a separate wall from this
  one. Persistence was its prerequisite, not its substitute.
- Phase 75's **GAP 2** (the closed `ENexusStaticObjectType` enum + switch on the Generation
  side) is untouched and still open.
