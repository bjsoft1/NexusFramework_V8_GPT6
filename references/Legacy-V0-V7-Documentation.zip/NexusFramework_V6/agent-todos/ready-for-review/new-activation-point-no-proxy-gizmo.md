Current bug (reported 2026-08-12, distinct from the separate, still-open
`still-not-fix.md` thread): a newly created Activation Point never gets an Editor Proxy
Actor (the draggable "Nexus: ..." gizmo actor) in the viewport, so it cannot be moved.
Switching editor mode and moving the camera near/far do not make it appear either -
user's own words: "the new created interactive point does not have gizmo actor in editor
after create. not possible to move it. switching mode, comes far, near stil not [working]."

## Completed

Task: New Activation Point never gets an Editor Proxy Actor (create-time proxy pool
staleness)
Category: bug-fixed
Phase: N/A (ad-hoc)
Status: Ready for Review
Completed Date: 2026-08-12
Completed Time: (same session)

Implemented and build verified.
Ready for user review.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` - succeeded,
  zero errors/warnings.
- Re-verified the premise before changing anything: read
  `SNexusHierarchyPanel::HandleCreateActivationPoint`/`HandleDeleteActivationPoint`,
  `UNexusFrameworkSubsystem::RefreshRepresentationIfDue`, and
  `FNexusEditorProxyPool::RebuildSpatialIndex` in full, plus the prior
  `activation-point-debug-on-freeze-investigation.md` record (2026-08-11) which had
  already confirmed, as a side finding, that `MarkRepresentationDirty()` is never called
  by either handler - confirmed this is still true in the current codebase and traced why
  it actually matters for THIS symptom (see Result below).
- **Not manually verified in-editor** (this agent cannot launch the editor,
  `AGENT-RULES.md`'s Agent Testing Policy) - see Important Notes below for the exact
  manual test sequence.

## Result

Root cause, confirmed by reading the code (not guessed): `UNexusFrameworkSubsystem::
RefreshRepresentationIfDue` only does a real rebuild (which is the ONLY thing that calls
`FNexusEditorProxyPool::RebuildSpatialIndex`, the function that populates the Editor Proxy
Actor pool's spatial index) when `bRepresentationDirty` is true OR its own idle poll
notices the Landscape's geometry fingerprint changed. `bRepresentationDirty` is set by
`MarkRepresentationDirty()`, and the Landscape fingerprint check is about Landscape spline
geometry only - NEITHER is affected by an `ActivationPoints` array mutation on its own.
`HandleCreateActivationPoint`/`HandleDeleteActivationPoint` never called
`MarkRepresentationDirty()` (confirmed missing, both before and after this fix's own
addition of it) - this was traced back to a real, prior, DELIBERATE decision
(`HandleCreateState`'s own comment: "Deliberately NOT called from the ActivationPoint
handlers"), reasoned correctly for the Debug PDI wireframe renderer (which re-reads
`ActiveConfig->ActivationPoints` LIVE every frame regardless, so a new point's wireframe
marker was never actually missing) - but the Editor Proxy Actor pool did not exist yet
when that reasoning was written, and its own data path (`RebuildSpatialIndex`, added
Phase 48/2026-08-11) is NOT a live per-frame read; it depends entirely on the same
dirty/poll gate `RenderSnapshot` uses. So a newly created point could go permanently
unindexed by the proxy pool - not "eventually," genuinely never - until some UNRELATED
action happened to mark the representation dirty too (creating a State/City/Highway, or a
full Re-sync). Camera movement and mode switching never touch this path at all, exactly
matching the reported symptom ("switching mode, comes far, near still not [working]").

Fixed with the same one-line pattern `HandleCreateState` already pays for every
State/City/Highway create: both `HandleCreateActivationPoint` and
`HandleDeleteActivationPoint` now call `subsystem->MarkRepresentationDirty()` right after
their own transaction, forcing the proxy pool's spatial index (and the RenderSnapshot/
diagnostics that share the same rebuild) to refresh on the very next Tick.

## Important Notes

- **Does not reintroduce or risk the separate, still-open 2026-08-11 "Debug ON creation
  freeze" investigation** - that investigation traced `HandleCreateActivationPoint`'s
  ENTIRE call path and found zero Debug-conditional cost anywhere in it; the new
  `MarkRepresentationDirty()` call only sets a bool flag synchronously (trivial), and the
  actual rebuild it triggers runs on the NEXT Tick, not inside this handler - the exact
  same cost/timing shape `HandleCreateState` already has, unreported as a freeze source
  there. If the freeze is ever revisited, this call is a new, minor, worth-checking
  variable, not assumed innocent - but it was not fixed/guessed at here, only added
  because omitting it directly causes this separate, confirmed bug.
- This is a genuinely different bug from the `still-not-fix.md` thread (proxy binding/
  gizmo-widget issues for points that DO get indexed) - this one is about points that
  never get indexed into the pool's spatial data at all after creation. Filed as its own
  task rather than appended to that thread, per this project's own "don't conflate
  distinct symptoms" precedent (see `still-not-fix.md`'s own header note distinguishing
  itself from the earlier `proxy-gizmo-drag-fights-and-snaps-back.md`).
- **Manual verification needed from the user** (this agent cannot launch the editor):
  1. With Nexus Ready (post Re-sync), right-click a HighwayPoint in the Hierarchy tree and
     choose "Create Activation Point". Confirm a new "Nexus: ..." Editor Proxy Actor
     appears in the viewport (if within `ProxyReleaseDistance` of the camera) immediately,
     without needing a mode switch, camera movement, or a second Re-sync.
  2. Confirm it's genuinely draggable (combines with the separate `still-not-fix.md`
     thread's own open gizmo-widget question - if the proxy appears but still shows no
     move/rotate handles, that's the OTHER thread's symptom, not this one).
  3. Delete an Activation Point via the Hierarchy tree's context menu. Confirm its Editor
     Proxy Actor promptly disappears/releases rather than lingering until an unrelated
     action.
  4. Create several Activation Points in a row - confirm each one gets its own proxy
     (subject to `MaxActiveEditorProxies`/`ProxyReleaseDistance` - the pool's own existing,
     unrelated capacity limits) without needing to touch anything between creations.
