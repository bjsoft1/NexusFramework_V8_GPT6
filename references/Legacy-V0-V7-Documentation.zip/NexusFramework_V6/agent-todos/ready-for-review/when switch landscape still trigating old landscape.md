## Task: Bulletproof Nexus Level/Map Switch Reset

The current LEVEL/MAP switching fix is mostly working, but one issue remains: after switching from LEVEL1 to LEVEL2, some previous LEVEL1 debug/rendered data can still remain visible.

Implement these rules:

1. Detect every editor LEVEL/MAP switch reliably.
2. Immediately stop targeting/referencing the previous level.
3. Clear all previous Nexus debug rendering/visualization data.
4. Clear/reset TreeView contents from the previous level.
5. Clear/reset Details panel selection/data.
6. Clear/reset Diagnostics panel data related to the previous level.
7. Clear cached mappings, temporary representation data, selected IDs, and transient debug state belonging to the previous level.
8. Load the Nexus config associated with the newly active level.
9. If the level config does not exist, create/initialize it using the existing main Nexus config workflow.
10. Do **not** automatically run `Re-Sync From Landscape` or expensive Landscape refresh/rebuild on level switch.
11. After switching, UI should show only safe/empty or already-persisted config data until the user manually clicks `Re-Sync From Landscape`.
12. When the user clicks `Re-Sync From Landscape`, then rebuild/refresh TreeView, Diagnostics, representations, mappings, and debug rendering from the new level.
13. Ensure no stale UObject/Actor/Landscape pointer from LEVEL1 can be used after LEVEL2 becomes active; use valid weak/reference-safe checks where appropriate.
14. Handle repeated switching such as `LEVEL1 → LEVEL2 → LEVEL1 → LEVEL3` without duplicated delegates, duplicated debug primitives, stale selections, or accumulated memory.
15. Keep the current architecture/features unchanged; this task is only to make map switching/reset behavior deterministic and bulletproof.

Expected behavior:

```text
LEVEL1 active
→ Nexus data/debug visible

Switch to LEVEL2
→ LEVEL1 debug immediately disappears
→ old Tree/Details/Diagnostics state cleared
→ LEVEL2 config loaded/created
→ NO automatic landscape re-sync

User clicks Re-Sync From Landscape
→ LEVEL2 data rebuilt
→ Tree/Diagnostics/debug visualization refreshed only for LEVEL2
```

Review the previous V5 level-switch fix for useful lifecycle ideas, but implement it cleanly for the current V6 editor-plugin architecture.

## Completed

Task: Bulletproof Nexus Level/Map Switch Reset
Category: bug-fixed
Phase: N/A (ad-hoc, follow-up to the 2026-08-11 "Refactor Nexus initialization flow" task)
Status: Ready for Review
Completed Date: 2026-08-11
Completed Time: 15:40 +0545

Implemented and build verified.
Ready for user review.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development` - succeeded, zero errors/warnings.
- Static/engine-source audit (not just reading this project's own code): confirmed by reading
  `FileHelpers.cpp`, `LevelEditorSubsystem.cpp`, and `EditorServer.cpp` in the UE 5.8 engine
  source that `ULevelEditorSubsystem::NewLevel()` (File > New Level > Empty Level) calls
  `UEditorEngine::NewMap()` directly and never calls `FEditorFileUtils::LoadMap()` - the only
  function that broadcasts `FEditorDelegates::OnMapOpened`. `NewMap()` only ever broadcasts
  `FEditorDelegates::MapChange(MapChangeEventFlags::NewMap)`. Every other requirement in this
  task (debug/rendered data clearing, Tree/Details/Diagnostics clearing, no implicit Re-sync,
  no stale pointers, repeated-switch safety) was already correctly implemented by the prior
  2026-08-11 "Refactor Nexus initialization flow" task - traced end-to-end through
  `RefreshRepresentationIfDue`, `RenderDebugPrimitives`/`FNexusDebugLabelOverlay::UpdateLabels`,
  `SNexusHierarchyPanel`/`SNexusDetailsPanel`/`SNexusDiagnosticsPanel`, and
  `FNexusEditorProxyPool`'s own world-teardown handling - this task's only real, confirmed gap
  was the blank-New-Level case.
- **Not manually verified in-editor** (this agent cannot launch the editor) - see Important
  Notes below for the exact manual test sequence.

## Result

Root cause found and fixed: `UNexusFrameworkSubsystem` only reset Nexus state
(`ActiveConfig`/`DetailsTarget`/`IsNexusReady`) from `FEditorDelegates::OnMapOpened`, which is
never broadcast when the user creates a brand-new blank level (File > New Level > Empty Level).
That path silently left the PREVIOUS level's config active, editable, and still debug-rendered
in the new (blank) level - exactly the residual "old debug/rendered data" symptom this task was
filed to close out. Fixed by also binding `FEditorDelegates::MapChange` and resetting on its
`MapChangeEventFlags::NewMap` flag (`UNexusFrameworkSubsystem::HandleMapChange`), sharing the
exact same reset logic as `HandleMapOpened` via a new `ResetForMapSwitch()` private helper - see
`Subsystem/NexusFrameworkSubsystem.h/.cpp`. `MapChange` also fires (same `NewMap` flag) during a
normal Open Level, alongside `OnMapOpened` - both handlers firing for one real map load is a
harmless redundant no-op, not a new bug.

## Important Notes

- **Scope note - items 8/9/11 of this task's numbered list were deliberately NOT
  implemented; flagging for an explicit decision rather than silently picking one
  interpretation.** Items 8/9/11 ask for the newly-active level's Nexus config to be
  automatically loaded/created on switch (before any user click), only deferring the
  expensive Landscape *reconciliation* to the explicit Re-sync button. This directly
  contradicts the Not-Ready/Ready state machine built earlier the same day
  (`ai-change-audits/2026-08-11/feature-add/nexus-not-ready-ready-initialization-state-machine.md`),
  which was an explicit, deliberate user decision: "do NOT use editor-mode switching (or
  opening/refreshing a tab) to initialize Nexus" and "Nexus enters Not Ready on every
  map/level switch, becomes Ready ONLY via an explicit Re-sync click." There is currently
  no "load an existing config from disk without also creating one / without also
  reconciling" primitive in `FNexusConfigAssetIO` to implement items 8/9/11 without either
  (a) reintroducing an implicit load trigger the prior task deliberately removed, or (b)
  adding new API surface for a behavior that may not actually be wanted once weighed
  against that prior decision. Left exactly as the Not-Ready/Ready state machine already
  has it (tree/details/diagnostics show empty + "Not Ready" until the user clicks
  Re-sync) - all other items in this task's list (1-7, 10, 12-15) are satisfied by the
  combination of that prior work and this task's own `MapChange` fix.
- **Manual verification needed from the user** (this agent cannot launch the editor):
  1. Open a level with a real, previously-synced Nexus config and visible debug rendering
     (Highways/Segments/etc). Confirm debug wireframes and labels are visible.
  2. File > New Level > Empty Level (a genuinely blank level, not "Open Level" to an
     existing map). Confirm the OLD level's debug wireframes/labels disappear immediately,
     the Hierarchy tree shows "Not Ready", and the Details/Diagnostics tabs are empty.
     This is the specific gap this task's own fix targets - the prior state machine did
     NOT cover this exact path.
  3. Repeat step 2 via File > Open Level to a second real, different level (should already
     have worked before this fix, per the prior task's own manual-verification list -
     confirm it still does).
  4. Repeated switching: LEVEL1 -> blank New Level -> LEVEL2 -> blank New Level. Confirm no
     duplicated debug primitives, no stale selection, tree/details/diagnostics correctly
     empty/"Not Ready" every time.
  5. Click Re-sync from Landscape on the new level and confirm normal Ready-state behavior
     resumes exactly as before this fix.
