# Details panel crash (EXCEPTION_ACCESS_VIOLATION) after adding/removing an entity

Reported: 2026-08-22 by the user, with a full callstack, during the post-commit verification pass.
Category: bug-fixed
Phase: N/A (crosses Phase 26a / 78 / the 2026-08-22 payload-persistence work)
Severity: **Crash.** Intermittent — "this is maybe sometime happens only."

## Report

```
Unhandled Exception: EXCEPTION_ACCESS_VIOLATION reading address 0x0000003100000106

UnrealEditor_PropertyEditor!FDetailLayoutBuilderImpl::Tick()  [DetailLayoutBuilderImpl.cpp:1090]
UnrealEditor_PropertyEditor!SDetailsViewBase::Tick()          [SDetailsViewBase.cpp:1470]
UnrealEditor_SlateCore!SWidget::Paint()                       [SWidget.cpp:1511]
... (pure Slate paint recursion up to FEngineLoop::Tick)
```

## Findings

**This is a dangling-pointer read, not a logic bug in any edited value.** The faulting
address `0x0000003100000106` is not null — it is a partially-overwritten pointer, the
classic signature of reading memory that was freed and reused. The entire callstack is
Slate paint plus PropertyEditor machinery ticking a bound property; nothing of ours is on
it, because by the time it crashes our code has already handed Slate the bad pointer and
returned.

**Root cause.** `SNexusDetailsPanel::RebindToCurrentTarget` binds an
`IStructureDetailsView` to a raw pointer *into* one of `UNexusConfigAsset`'s backing
`TArray`s — `FNexusMapping::FindActivationPointById(*config, id)` and its four siblings
return `&config->ActivationPoints[i]` and friends. That pointer is only ever refreshed on
two events:

- `UNexusConfigAsset::OnPostEditUndo` (undo/redo), and
- `UNexusFrameworkSubsystem::OnDetailsTargetChanged` (selection change).

**Adding or removing an entity fires neither.** `FNexusMapping::AddActivationPoint` calls
`config.ActivationPoints.Add(newPoint)` (`NexusMapping.ActivationPoint.cpp:36`) and
`RemoveActivationPoint` calls `RemoveAt` (:48). There are thirteen such mutation sites
across five Mapping `.cpp`s covering `States`/`Cities`/`Highways`/`HighwayPoints`/
`ActivationPoints`.

Repro sequence:

1. Select an Activation Point in the Nexus panel — Details binds to `&ActivationPoints[i]`.
2. Create another Activation Point.
3. `TArray::Add` reallocates once it outgrows its slack — every element address changes.
4. The bound pointer now references the freed block.
5. The next Slate tick reads through it inside `FDetailLayoutBuilderImpl::Tick()`.

**Why it is intermittent** — exactly as reported. `TArray::Add` only reallocates when it
exceeds capacity, so several consecutive adds often do not move anything, and even when
the block is freed the crash only lands once that memory is reused or unmapped.

**`RemoveAt` is the quieter, worse case.** It shifts elements down rather than freeing the
array, so the pointer usually stays *valid* and simply addresses a **different Activation
Point**. That does not crash — it silently shows and edits the wrong entity.

**Known class, third occurrence.** `2026-08-10/bug-fixed/
debug-details-panel-dangling-pointer-crash.md` is the same failure through a `TMap` growth
in the Debug-category path; `phase-26a.md` records V5's own `PostEditUndo` variant before
either reproduced. `NexusPanelSharedTypes.h` even cites the lesson as the reason
`FNexusGizmoSubPointSelection` carries a KEY and never a resolved pointer. The Details
panel's own header comment already names the risk ("undo/redo can reallocate config's
backing TArrays") — it just did not account for add/remove doing the same thing without
either notification firing.

**Relationship to today's work.** The binding predates today (Phase 78-era), but today's
payload-persistence work made it far likelier to fire: real config Activation Points became
genuinely editable, and the new registry-driven "Create Activation Point" submenu makes
growing `ActivationPoints` while one is selected an ordinary action rather than a rare one.

## Changes

`SNexusDetailsPanel` now detects the mutation instead of trusting every mutation site to
announce it.

- `Private/UI/SNexusDetailsPanel.h` — added a `Tick` override, `GetBoundContainerState`,
  and a `BoundContainerData`/`BoundContainerNum` snapshot pair.
- `Private/UI/SNexusDetailsPanel.cpp` — `RebindToCurrentTarget` snapshots the backing
  container's data pointer and element count before binding; `Tick` compares them and
  re-resolves by id if either changed.

**Why the guard rather than broadcasting from the mutation sites.** Thirteen call sites
across five files would all need a new broadcast, and the fourteenth — written next month —
would not have one. One check cannot be forgotten. It is also O(1): comparing the
container's data pointer and count stays free at the object counts
`11-v6-static-dynamic-architecture.md` targets, whereas re-resolving the element by id
every tick would be a linear scan per frame.

Comparing **count as well as pointer** is deliberate: a reallocation changes the pointer,
but a `RemoveAt` that shifts elements down may leave it identical while every element after
the removed index has moved — the silent-wrong-entity case above.

Covers all five config arrays plus the test store, not just Activation Points.

## Verification

**BUILD VERIFIED 2026-08-22.** `Build.bat NexusFrameworkEditor Win64 Development` (UE 5.8) —
**Succeeded**. The earlier blocker is resolved and recorded below for history: it refused with
"Unable to build while Live Coding is
active. Exit the editor and game, or press Ctrl+Alt+F11" — the user's editor was open. The
code change is complete but has not compiled even once. **This task stays in `active/`
until it builds clean**, per `AGENT-TODO-RULES.md`'s `active/` -> `ready-for-review/`
condition ("implemented AND build-verified").

Next agent or session: close the editor (or Ctrl+Alt+F11) and run

```
Build.bat NexusFrameworkEditor Win64 Development -Project="<repo>/NexusFramework.uproject"
```

### Manual verification for the user, once it builds

1. **The crash repro** — select an Activation Point so the Details panel shows it, then
   create several more Activation Points without changing selection. The panel must keep
   showing the correct point, and must not crash. Before the fix this crashed once the
   array reallocated.
2. **The silent-corruption repro, which matters more** — select the *last* Activation Point
   in the list, then delete an *earlier* one. The Details panel must still show the point
   you selected (re-resolved by id), not the one that shifted into its slot.
3. Repeat 1–2 for a HighwayPoint and a Highway — same guard, same containers.
4. Confirm normal editing still works: expansion state and in-progress edits should not be
   disturbed while nothing is being added or removed (the guard only fires on an actual
   container change, not every tick).

## Correction — 2026-08-22 — the first fix caused a SECOND crash

**The fix recorded above was wrong, and made things worse before making them better.** Recorded
in full rather than quietly amended, because the failure mode it introduced is a trap worth
naming.

### What happened

The user hit a new crash, reported with a full callstack, when **clicking a newly created
Traffic Light in the tree view**:

```
EXCEPTION_ACCESS_VIOLATION reading address 0x0000000000000030
UnrealEditor_PropertyEditor!FDetailItemNode::Tick()        [DetailItemNode.cpp:803]
UnrealEditor_PropertyEditor!FDetailLayoutBuilderImpl::Tick()
UnrealEditor_PropertyEditor!SDetailsViewBase::Tick()
UnrealEditor_SlateCore!SWidget::Paint()                    [SWidget.cpp:1511]
```

### Why this is a DIFFERENT bug, not the original one resurfacing

The faulting address is the tell. The original crash read `0x0000003100000106` - a
partially-overwritten pointer, i.e. freed-and-reused memory. This one reads `0x30`: null plus
a member offset. Null-deref, not use-after-free. **The failure mode changed after the fix**,
which points squarely at the fix.

### Root cause

`SDetailsViewBase::Tick` runs from **inside** `SWidget::Paint` (visible in the callstack), and
a parent widget paints before its children. The first fix called `RebindToCurrentTarget()`
directly from `SNexusDetailsPanel::Tick`, which calls `DetailsView->SetStructureData()` - that
tears down and rebuilds the details view's entire node tree. So the sequence was:

1. `SNexusDetailsPanel` paints -> its `Tick` runs -> detects the container changed
2. `SetStructureData()` destroys and rebuilds the node tree
3. The child `SDetailsViewBase` then paints -> its `Tick` iterates a tree that was just swapped
4. `FDetailItemNode::Tick` walks nodes whose links were destroyed mid-iteration -> null deref

Verified against the engine source. `FDetailItemNode::Tick` is:

```cpp
if (ensure(bTickable)) {
    if (Customization.HasCustomBuilder() && Customization.CustomBuilderRow->RequiresTick())
        Customization.CustomBuilderRow->Tick(DeltaTime);
    RefreshCachedVisibility(true);
}
```

**The user's reproduction detail explains why it needed a Traffic Light specifically.** The
crash requires a `CustomBuilderRow` to exist. `FNexusActivationPoint::Payload` is an
`FInstancedStruct`, which renders through a custom property-type customization - i.e. a custom
builder row. And "newly created" is what grew `ActivationPoints` and triggered the ill-timed
rebind. Both conditions had to coincide, which is why it looked intermittent and why a plain
HighwayPoint did not reproduce it.

### The corrected fix

`Tick` now **detects only**. The rebind is deferred to a one-shot active timer
(`HandleDeferredRebind`), which Slate runs in `FSlateApplication::TickAndDrawWidgets` **before**
`DrawWindows` - outside the paint recursion entirely, which is the only safe place to swap the
bound structure. `IsRebindPending` stops every tick before the timer fires from queuing another.

The container-snapshot detection itself was correct and is unchanged; only *when* the rebind
happens moved.

### Verification

- `Build.bat NexusFrameworkEditor Win64 Development` (UE 5.8) — **Succeeded**.
- `Automation RunTests Nexus.Regression+Nexus.Pipeline` — **11/11 Success**.
- **Neither crash is confirmed fixed in-editor.** Both fixes are reasoned and build-verified;
  only the user's own repro can confirm them.

### The lesson, stated generally

**Never mutate a Slate widget's bound data from inside `Tick` when that widget ticks during
paint.** `SetStructureData`, `RequestTreeRefresh` and friends are safe from event callbacks
(selection changed, undo) but not from a tick that runs inside the paint pass. Defer to an
active timer. This applies to `SNexusHierarchyPanel` and `SNexusVerificationPanel` too, neither
of which currently rebinds from `Tick` - keep it that way.

### Manual verification for the user (supersedes the list above)

1. **The exact repro:** create a new Traffic Light, then click it in the tree view. This
   crashed before; it must not now.
2. Select an Activation Point, then create several more without changing selection - the panel
   must keep showing the correct point.
3. Select the LAST Activation Point, then delete an EARLIER one - the panel must still show the
   point you selected, not the one that shifted into its slot.
4. Confirm normal editing is undisturbed: expansion state and in-progress edits should not reset
   while nothing is being added or removed.

### Separate observation, not a bug

`StructUtilsEditor` is **not** listed in `NexusFrameworkEditor.Build.cs`, yet the payload's
Details-panel type picker and inline properties depend on that module's customization being
registered. It works because the engine loads the module anyway. That is an assumption, not a
guarantee - if the payload row ever renders as a bare struct with no type picker, this is the
first thing to check.

## Correction — 2026-08-22 — the SECOND fix was also wrong; the active timer is inside paint

**The deferred-active-timer fix recorded above crashed too**, reported by the user with a
third callstack — same `FDetailItemNode::Tick` line, this time reading `0x00`:

```
Unhandled Exception: EXCEPTION_ACCESS_VIOLATION 0x0000000000000000
UnrealEditor_PropertyEditor!FDetailItemNode::Tick()          [DetailItemNode.cpp:803]
UnrealEditor_PropertyEditor!FDetailLayoutBuilderImpl::Tick() [DetailLayoutBuilderImpl.cpp:1090]
UnrealEditor_PropertyEditor!SDetailsViewBase::Tick()         [SDetailsViewBase.cpp:1470]
UnrealEditor_SlateCore!SWidget::Paint()                      [SWidget.cpp:1511]
```

User's repro: "when clicking the tree view data maybe the top breadcrumb".

### Why it was wrong

The premise — "an active timer runs in `FSlateApplication::TickAndDrawWidgets` before
`DrawWindows`, i.e. outside the paint recursion" — is false. Read against the engine source:

```cpp
// Engine/Source/Runtime/SlateCore/Private/Widgets/SWidget.cpp, SWidget::Paint
if (HasAnyUpdateFlags(EWidgetUpdateFlags::NeedsActiveTimerUpdate))
{
    MutableThis->ExecuteActiveTimers(Args.GetCurrentTime(), Args.GetDeltaTime());  // :1502
}
if (HasAnyUpdateFlags(EWidgetUpdateFlags::NeedsTick))
{
    MutableThis->Tick(DesktopSpaceGeometry, ...);                                  // :1511
}
```

**`SWidget::Paint` executes a widget's active timers nine lines before it calls `Tick`.** The
"deferral" moved the rebind nine lines earlier in the same function, still inside paint —
which is why the failure mode did not change, only the faulting address.

### The third fix (the one in the working tree)

Detection is abandoned entirely. `Tick`, `HandleDeferredRebind`, `GetBoundContainerState`,
`IsRebindPending`, `BoundContainerData` and `BoundContainerNum` are all removed.
`UNexusConfigAsset::OnStructuralChange` is broadcast from all 14 add/remove sites in the
`FNexusMapping` `.cpp`s; `SNexusDetailsPanel` subscribes and re-resolves by id — the same
mechanism `OnPostEditUndo` has always used, and safe for the same reason (a mutation always
originates from input handling, a console command, or a menu action, never from paint).

## Review — 2026-08-22 — third fix reviewed; four gaps found and closed

Reviewed at the user's request before commit. **The approach is right** and the engine-source
claim it rests on was re-verified line by line against `UE_5.8`. Four gaps were found in the
implementation and closed in the same working tree.

### Verified sound

- All 14 `config.<Array>.Add/RemoveAt/RemoveAll` sites across the five Mapping `.cpp`s
  broadcast; a repo-wide search for structural mutations of `States`/`Cities`/`Highways`/
  `HighwayPoints`/`ActivationPoints` finds no others, and no site assigns an array wholesale.
- The `RemoveAll` in `RemoveHighwaysNotMatchingLiveLandscape` is correctly gated on
  `removedCount > 0`.
- Every mutation site is reachable only from an `SNexusHierarchyPanel` button/menu handler, a
  console command, or `FNexusLandscapeModeExtension::OnEditorModeIDChanged` — never from
  paint, which is the premise the whole fix rests on.
- `RebindToCurrentTarget` re-resolves every hierarchy target by id (`FNexusMapping::Find*ById`)
  and never reuses a cached pointer.

### GAP 1 (crash) — the test store lost its coverage

The removed `GetBoundContainerState` explicitly covered `FNexusActivationPointTestStore` as
well as the five config arrays ("Covers all five config arrays plus the test store"). The
replacement covers only `UNexusConfigAsset`, so `ENexusDetailsTargetMode::TestActivationPointPayload`
was left unprotected: `Nexus.Representation.ClearTestActivationPoints` calls `ClearAll()`,
destroying every `FInstancedStruct` payload block while the details view is still bound to one
— the original use-after-free with a different owner.

(Adding a test point is survivable on its own: `FInstancedStruct` owns its payload block off to
the side, so a `Points` reallocation moves the point but not the payload bytes. `ClearAll` is
the lethal one. Both now broadcast.)

**Fixed** — `FNexusActivationPointTestStore::OnStructuralChange`, broadcast from `AddPoint` and
`ClearAll`; `SNexusDetailsPanel::HandleTestStoreStructuralChange` subscribes.

### GAP 2 (perf regression) — one full rebind per mapped element

`MapControlPoint` is called once per Landscape control point in a loop
(`NexusMapping.PointMapping.cpp:140`) and the highway-chain add once per chain
(`NexusMapping.HighwayMapping.cpp`), each now broadcasting. One broadcast costs a full
`SetStructureData` teardown/rebuild, a full breadcrumb rebuild (whose `FindOwningHighway` is
itself a linear scan of `Highways`), and two unconditional `NexusDebugPerf` log lines — so
entering Landscape Mode on a real Landscape became O(N^2) with thousands of details-view
rebuilds. This is the same unthrottled-per-element editor work behind the 2026-08-10
`editor-performance-stalls-*` and 2026-08-11 "Activation Point + Debug ON freeze" records, and
the removed guard's O(1) design was explicitly justified by
`11-v6-static-dynamic-architecture.md`'s massive-world counts.

**Fixed** — `UNexusConfigAsset::FScopedStructuralChangeBatch`, an RAII depth-counted scope that
records which configs changed and fires one broadcast per config when the outermost scope
closes. Opened in `MapControlPoints`, `MapHighways`, `ReconcileMappingStage` and
`RunAutomaticEnableFlow` (nesting is expected — the inner two are also directly
console-callable, so neither may assume an outer scope exists).

**Safety condition, checked and stated in the code:** batching leaves the binding stale for the
duration of the batch, which is only safe because nothing can paint in between — no Mapping
`.cpp` uses `FScopedSlowTask`, `GWarn` status updates, or any other Slate pump. Introducing one
inside a batch would reopen the original crash.

### GAP 3 (correctness, minor) — no active-config filter

`HandleConfigAssetStructuralChange` rebound on a mutation to **any** config asset, unlike its
sibling `HandleConfigAssetPostEditUndo`, which has always checked
`subsystem->GetActiveConfig() != &editedConfig`.

**Fixed** — same guard added.

### GAP 4 (maintainability) — the invariant was undocumented where it must be honoured

The original guard's stated advantage was that "one place cannot be forgotten by the
fourteenth call site". The broadcast approach genuinely gives that up — it is the right trade
(the detect-it-yourself alternative is only reachable from a tick, and a tick is inside paint),
but nothing at the mutation site said so.

**Fixed** — the requirement is now stated on the data itself, in a comment above the five
`UPROPERTY` arrays in `NexusConfigAsset.h`.

### Files changed by this review

- `Public/Mapping/NexusConfigAsset.h` — `FScopedStructuralChangeBatch`;
  `BroadcastStructuralChange` moved out of line; invariant documented on the arrays.
- `Private/Mapping/NexusConfigAsset.cpp` — batch depth/pending-config state and flush.
- `Private/Mapping/NexusMapping.PointMapping.cpp`, `.HighwayMapping.cpp`, `.Reconciliation.cpp`,
  `.EnableFlow.cpp` — batch scopes.
- `Public/Representation/NexusActivationPointTestStore.h` and its `.cpp` — `OnStructuralChange`.
- `Private/UI/SNexusDetailsPanel.h` / `.cpp` — test-store subscription + handler; active-config guard.

### Verification

- `Build.bat NexusFrameworkEditor Win64 Development` (UE 5.8) — **Succeeded** (17.5s, clean).
- `Automation RunTests Nexus.Regression+Nexus.Pipeline` — **11/11 Success**, unchanged.
- **Still not confirmed in-editor.** Automated coverage cannot reach a Slate paint-pass crash;
  only the user's own repro can close this. The manual list from the previous section stands,
  plus two the review added:
  5. Run `Nexus.Representation.AddTestActivationPoint`, select the test point so the Details
     panel shows its payload, then run `Nexus.Representation.ClearTestActivationPoints` — the
     panel must clear, not crash (GAP 1).
  6. Select a HighwayPoint, then hit **Re-sync from Landscape** on a Landscape with real spline
     data — it must complete without a multi-second freeze, and the panel must still show the
     point you selected (GAP 2). `Nexus Perf Trace: SNexusDetailsPanel::RebindToCurrentTarget`
     should appear a handful of times in the log for the whole re-sync, not once per point.

**This task stays in `ready-for-review/`** — moving it on is the user's call
(`AGENT-TODO-RULES.md`).
