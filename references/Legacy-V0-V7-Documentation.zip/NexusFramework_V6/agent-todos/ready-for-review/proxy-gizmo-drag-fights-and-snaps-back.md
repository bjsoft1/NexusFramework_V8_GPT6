Current bug (reported 2026-08-12, after the proxy interactivity fix in
`still-not-fix.md` made dragging reachable at all):

When editor loads the proxy "Nexus: Activation Point" (which is used to drag points via
gizmo), dragging shows lag, like two people are trying to move the same object. When
trying to move it to a new place, the proxy actor tries to auto-come back to its
previous place - the drag fights itself and the object snaps back after being dropped.

## Completed

Task: Editor Proxy Actor gizmo drag fights the user's own drag input and snaps back to
the pre-drag position after drop
Category: bug-fixed
Phase: N/A (ad-hoc)
Status: Ready for Review
Completed Date: 2026-08-12
Completed Time: (same session, immediately after the 9-phase batch)

Implemented and build verified.
Ready for user review.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` - succeeded,
  zero warnings/errors.
- Re-verified the premise before changing anything: read
  `FNexusEditorProxyPool::TickUpdateNearbyProxies`/`BindSlot`/`NotifyProxyMoved` and
  `ANexusEditorProxyActor::PostEditMove` in full rather than assuming a cause. Confirmed
  the actual mechanism (see Result below) directly from the code, not inferred from the
  symptom description alone.
- **Not manually verified in-editor** (this agent cannot launch the editor,
  `AGENT-RULES.md`'s Agent Testing Policy) - see Important Notes below for the exact
  manual test sequence.

## Result

Root cause, confirmed by reading the code (not guessed): `FNexusEditorProxyPool::
TickUpdateNearbyProxies` runs on a throttled cadence (every ~0.2s or on >50cm camera
movement) and its "refresh already-bound proxies" pass unconditionally calls `BindSlot`
- which unconditionally calls `SetActorTransform` - for EVERY desired proxy, including
the one currently pinned/selected (the one the user is actively dragging via the native
viewport transform gizmo; a drag target is always pinned because native gizmo
manipulation requires the Actor to be UE-selected, and selection sets
`PinnedActivationPointId` via `HandleSelectionChanged`). The transform it pushes comes
from `IndexedWorldTransforms`, a cache that is only rebuilt by `RebuildSpatialIndex` on
its own SEPARATE, independently-throttled cadence - never live during a drag. So while
the user drags: every ~0.2s the pool snaps the actor back to its last-cached (pre-drag)
position, fighting the live drag input every tick - the "like 2 people try to move same
object" lag. And immediately after the user releases the mouse: `NotifyProxyMoved` had
already written the new offset into `UNexusConfigAsset::ActivationPoints`, but the
`IndexedWorldTransforms` cache entry was never updated to match - so the very next
`TickUpdateNearbyProxies` tick (which can fire within a fraction of a second) re-pushes
the STILL-stale pre-drag cached transform, visually snapping the just-dropped object
back to where it started. Both halves of the reported symptom are the same root cause.

Fixed with two small, targeted changes (no architecture change, no new poll/tick):
1. `ANexusEditorProxyActor` gained `IsMidDrag` (true from the first real
   `PostEditMove(false)` of a user drag until the matching `PostEditMove(true)`, never
   set by a programmatic `IsProgrammaticTransformUpdate`-guarded push).
   `TickUpdateNearbyProxies`'s refresh loop now skips the `BindSlot`/`SetActorTransform`
   call entirely for any already-bound proxy currently mid-drag - a freshly-acquired
   slot is never mid-drag, so this only ever skips a REFRESH, never an initial bind.
2. `NotifyProxyMoved` now patches `IndexedWorldTransforms[indexedPos]` in place (a
   single targeted element update by `IndexOfByKey`, not a full `RebuildSpatialIndex`
   rescan - keeps that function's own "never a second independent poll" cost contract
   intact) to the proxy's own just-committed live transform, immediately after writing
   the new offset back to the config, on every `PostEditMove` callback (not just the
   final one) - so the cache is never stale even for a moment after a write-back.

## Important Notes

- **Confidence level, stated plainly**: high - this is a directly-read, concrete code
  path exactly matching both halves of the reported symptom (fights during drag; snaps
  back after drop), not an inferred/best-guess hypothesis. Not yet empirically confirmed
  live (this agent cannot launch the editor).
- Deliberately did NOT touch `HandlePostEditUndo`'s own unconditional
  `SetActorTransform` loop (also pushes onto every bound proxy without an `IsMidDrag`
  check) - a real user drag holds exclusive input focus, so Ctrl+Z/Ctrl+Y cannot
  realistically fire mid-drag; adding the same guard there would be speculative
  defensive code for a scenario that cannot occur, not a fix for anything reported.
- **Manual verification needed from the user** (this agent cannot launch the editor):
  1. Enter Select Mode, click an Editor Proxy Actor ("Nexus: Activation Point..." in the
     viewport), and drag it slowly to a new location using the transform gizmo. Confirm
     the object now follows the mouse smoothly with no fighting/lag/stutter, even if you
     pause mid-drag for more than a second (crossing the pool's own ~0.2s refresh
     interval).
  2. Release the mouse. Confirm the object stays exactly where it was dropped - it
     should NOT snap back toward its original position.
  3. Move the camera around (walking near/past other nearby Activation Points, which
     triggers `TickUpdateNearbyProxies`'s camera-movement-driven refresh path) after the
     drop. Confirm the just-moved object's position remains stable and does not jump.
  4. Repeat with rotation (not just translation) via the gizmo's rotate handle, to
     confirm the same fix covers `OffsetRotation`, not just `OffsetLocation`.
  5. Confirm a DIFFERENT (not currently selected) nearby proxy still correctly refreshes
     its position if its own anchor HighwayPoint moves (e.g. via a Landscape edit +
     Re-sync) - this fix only skips the refresh for the proxy currently mid-drag, not
     for every proxy, so this should be unaffected.
