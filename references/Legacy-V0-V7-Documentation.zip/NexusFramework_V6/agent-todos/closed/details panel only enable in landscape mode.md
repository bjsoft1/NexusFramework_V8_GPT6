## AUTO FIXED BY OUR PREVIOUS SOME ENHANCMENT
Fix the custom Details panel so it remains available and editable in all Unreal Editor modes, not only Landscape Mode.
Current intended behavior: Nexus data can be selected and modified from any editor mode.
For reference only: Nexus gizmos are currently disabled in Landscape Mode because Landscape input/events can interfere with terrain editing.