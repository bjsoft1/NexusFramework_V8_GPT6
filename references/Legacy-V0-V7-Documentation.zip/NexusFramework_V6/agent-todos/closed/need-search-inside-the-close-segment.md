Verify whether the current Start/End debug boxes on a **self-closed highway segment** are correct behavior or a bug.

* A highway is self-closed when its joined start/end points resolve to the same `HighwayId`.
* A self-closed segment should logically have **no open Start/End endpoints**.
* Open branches may have endpoints; e.g. a `+` highway can have 4 different branch ends.
* This is strictly **Closed vs Open topology**, not Corner/Straight/Junction classification.
* Inspect current V6 data, topology logic, and debug renderer and explain the current behavior.
* If incorrect, identify the owning phase/spec and propose the smallest architecture-correct fix; **do not modify code yet**.
* If deeper investigation is needed, inspect V5's closed-segment bug fixes only as historical reference.
* **Do not port V5 logic blindly**; V6 uses a different architecture, so reuse only concepts that still fit V6's design.

## Investigation (2026-08-10)

**Verdict: this is a real bug, root-caused precisely, in `FNexusMapping::MapHighways` (Phase 11), NOT in the debug renderer (Phase 30).**

### Current behavior traced

`RenderStartEnd` (`NexusDebugLandscapeGroupRenderers.cpp`, Phase 30) is already CORRECT:

```cpp
if (highway.IsClosedLoop || highway.OrderedPointIds.Num() == 0) continue;
```

It skips Start/End markers for any Highway flagged `IsClosedLoop`. The bug is that
`MapHighways` (`NexusMapping.HighwayMapping.cpp`, Phase 11) can produce a Highway whose
`OrderedPointIds[0] == OrderedPointIds.Last()` (a genuinely self-closed chain) while
`IsClosedLoop` stays `false` — so `RenderStartEnd`'s own guard never fires for it.

### Root cause

`MapHighways` decomposes the Landscape connection graph in two passes:
- **Pass 2** (pure loops, every point degree-2) correctly sets `IsClosedLoop=true` via
  `WalkChainFrom`, which explicitly stops at the start point WITHOUT re-adding it
  ("Closed loop - back at the start; walk complete, don't re-add it").
- **Pass 1** (chains anchored at a junction/dead-end, `entry.ConnectedPoints.Num() != 2`)
  walks outward from a junction point J and stops when it reaches ANOTHER point whose
  degree != 2. If J itself sits on a loop that has exactly one extra branch (so J has
  degree 3: two loop directions + the branch), Pass 1's own walk starting in one loop
  direction can legitimately travel all the way around and arrive back at J itself —
  and BECAUSE the stop condition is checked on `current` at the top of each iteration
  (not before appending), J DOES get appended a second time before the loop breaks.
  Result: `chain = [J, A, A2, ..., LastBeforeJ, J]` — first and last elements are the
  *same* `ULandscapeSplineControlPoint*`.
- But `BuildHighwayFromChain(config, chain, false, newHighwayCount)` is called with
  `isClosedLoop` **hardcoded to `false`** for every Pass-1-derived chain — the code never
  checks `chain[0] == chain.Last()`.

So the resulting `FNexusHighway` has `OrderedPointIds[0] == OrderedPointIds.Last()` (the
same `HighwayPointId`, matching this task's own "joined start/end points resolve to the
same [point]" framing) but `IsClosedLoop=false`. `RenderStartEnd` then draws BOTH a Start
box and an End sphere at the identical world location (J's own resolved position) —
visually a stacked/overlapping marker at a point that is topologically a junction (also
correctly drawn as a Connections sphere by `RenderConnections`, which checks
`ConnectedHighwayIds.Num() >= 2` independently and unaffected by this bug), not a real
open dead-end. A true dead-end (`+`-shaped junction's own branch tips, `ConnectedHighwayIds.Num()==1`
at that end) is unaffected — those correctly get exactly one Start/End marker each, this
task's own "open branches may have endpoints" case.

This is a genuine gap in Phase 11's *original* implementation, present since that phase
shipped — not a regression, and distinct from the separate stale-`IsClosedLoop`-after-a-
Landscape-edit bug fixed earlier this session (`ai-change-audits/2026-08-10/bug-fixed/
closed-loop-highway-renders-open-after-landscape-edit.md`, `Nexus.Mapping.
RemoveStaleHighways`) — that one was about a chain that changed shape after being mapped;
this one is about Pass 1 never attempting closed-loop detection at all for a chain that
happens to return to its own start.

### V5 historical reference (concept only, not ported)

V5 had a structurally-similar-shaped bug (`NexusFramework_V5/ai-change-audits/bug-fixed/
closed-loop-and-divider-save-load.md`): its own import/loop-detection pass correctly
*detected* a closed loop but never *recorded* it as `bIsClosedLoop`, because the two
concerns (detect vs. record) were split across different code paths. Same shape of gap
(detection happens, recording doesn't) — but V5's actual bug and fix were about a
Save/Load round-trip losing topology in a WorldData-caches-Landscape architecture, which
does not apply to V6 (V6 never caches Location/Rotation/Tangent, always resolves live) —
not ported, only the "detect vs. record" framing informed how this investigation was read.

### Owning phase / proposed smallest fix (NOT implemented, per this task's instruction)

Owning phase: **Phase 11** (`phases/phase-11.md`, `FNexusMapping::MapHighways`) — this is
where the chain is built and where `isClosedLoop` is decided; `RenderStartEnd` (Phase 30)
needs no change once fed correct data.

Smallest correct fix (two parts, not just one):
1. In Pass 1's walk, before calling `BuildHighwayFromChain`, replace the hardcoded
   `false` with `chain.Num() > 1 && chain[0] == chain.Last()`.
2. **Also strip the duplicated trailing point** (`chain.Pop()` or equivalent) when that
   condition is true, before building `orderedIds` — Pass 2's own convention (the
   established "closed loop" shape everywhere else: `RenderSegments`'s
   `IsClosedLoop ? numPoints : numPoints-1` + modulo wraparound, `WalkChainFrom` itself)
   never repeats the boundary point; a naive fix that only flips the boolean would leave
   Pass-1-derived closed loops in an inconsistent shape from Pass-2-derived ones (an
   extra real point that duplicates index 0), which would make `RenderSegments`
   draw a redundant/zero-length final segment and could misalign any future code that
   assumes `OrderedPointIds.Num()` reflects the loop's true distinct-point count. Keeping
   ONE shape for "closed loop" `OrderedPointIds` (never repeated boundary point,
   `IsClosedLoop` alone implies the wrap) is the actual "smallest architecture-correct"
   fix, not just the boolean flip.

No new field, no schema/serialization change - both parts are internal to `MapHighways`'s
own chain-building logic.

## Completed

Task: Investigate self-closed-highway Start/End debug marker behavior
Category: research
Phase: 11 (Nexus Mapping - Highway Membership), owning the identified bug; 30 (Debug
Rendering - Landscape Group), confirmed NOT at fault
Status: Ready for Review
Completed Date: 2026-08-10
Completed Time: 19:10 GMT+5:45

Investigation only - no code modified, per this task's own explicit instruction. Root
cause identified and proposed fix documented above; not implemented.

## Verification

- Traced `RenderStartEnd`'s existing `IsClosedLoop` guard (correct) against
  `MapHighways`'s Pass 1 chain-walk logic (the actual bug) by direct code reading, not
  assumption.
- Confirmed `RenderConnections` independently and correctly marks the junction point
  regardless of this bug (unaffected code path).
- Checked V5's own historically-similar bug for concept parity, confirmed NOT directly
  portable (different architecture - V5 was a Save/Load topology-loss bug, V6 has no
  such cache to lose), used only to validate the "detect vs. record" framing.
- No build performed - no code was changed.



> **2026-08-10 2:50 PM (Nepal)**
> Confirmed V6 already supports closed-loop highways. The current issue is a small Phase 11 mapping bug where a loop returning to the same start point through a junction/branch path can be incorrectly marked open, causing false Start/End debug markers. Phase 30 rendering is correct.
> *ChatGPT verification 😄*
