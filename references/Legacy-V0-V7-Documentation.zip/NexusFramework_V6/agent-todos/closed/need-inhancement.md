Refactor Nexus initialization flow.

Required behavior:

* On **map/level load or switch**, Nexus must enter `Not Ready` state.
* Disable all Nexus authoring/editing controls.
* Keep `Re-sync from Landscape` enabled and clearly highlighted.
* Add tooltip explaining that re-sync is required before editing.

When user clicks `Re-sync from Landscape`:

* run full existing Landscape → Nexus reconciliation
* rebuild/refresh mapping, representation, spatial index, proxy pool, Hierarchy and Details
* if successful, set Nexus to `Ready`
* enable all normal controls immediately
* remove/highlight-normalize the Re-sync button
* proxy actors/native selection must work immediately in Select Mode

Important:

* Do NOT require entering Landscape Mode.
* Do NOT use editor-mode switching to initialize Nexus.
* Mode switching after Ready must NOT reset readiness or trigger full sync.
* Map/level switch must always reset back to `Not Ready` and highlight Re-sync again.
* If Re-sync fails, remain `Not Ready`, keep controls disabled and keep button highlighted.
* Preserve existing Nexus-authored offsets/data during re-sync.

Target flow:

`Map Load/Switch`
→ `Not Ready`
→ controls disabled
→ `Re-sync from Landscape` highlighted
→ user clicks
→ successful sync
→ `Ready`
→ normal Nexus workflow.

## Completed

Task: Refactor Nexus initialization flow (Not Ready/Ready state machine)
Category: feature-add
Phase: N/A (ad-hoc, cross-cutting)
Status: Ready for Review
Completed Date: 2026-08-11
Completed Time: 06:33 GMT+5:45 (+0545)

Implemented and build verified.
Ready for user review.

**Premise re-verified before implementing** (AGENT-TODO-RULES.md rule 4): confirmed
`UNexusFrameworkSubsystem::ActiveConfig` had genuinely zero map-change handling
anywhere in the codebase before this task - opening a second level really did silently
keep the first level's config active/editable, matching the separate, still-unscoped
`agent-todos/requirement-pending/when switch landscape still trigating old landscape.md`
report. Also confirmed `SNexusDetailsPanel.cpp` still gated editing on
`GLevelEditorModeTools().IsModeActive(EM_Landscape)` - a leftover from before the
2026-08-11 editor-usability pass moved Nexus editing to Select Mode - matching the
separate `agent-todos/requirement-pending/details panel only enable in landscape
mode.md` report. Both confirmed real, not assumed, before writing any code.

**Changes**:

- `Subsystem/NexusFrameworkSubsystem.h/.cpp` - new `IsNexusReady()`/`SetNexusReady()`/
  `OnNexusReadinessChanged` (defaults `false`); new `HandleMapOpened` bound to
  `FEditorDelegates::OnMapOpened` - the ONE place `ActiveConfig` is cleared,
  `DetailsTarget` is cleared, and readiness resets to `false` on any map/level
  load/switch.
- `UI/NexusLandscapeModeExtension.h/.cpp` - removed the Landscape-Mode-entry
  config-load block entirely (tabs still auto-open, unchanged); `RefreshNexusInteractionState`
  now gates gizmo/proxy-pool interactivity on Select Mode AND `IsNexusReady()` together;
  binds `OnNexusReadinessChanged` so becoming Ready reactivates interaction immediately
  without requiring a mode change.
- `UI/SNexusHierarchyPanel.h/.cpp` - removed the self-heal config-load path entirely
  (`ResolveActiveConfig` deleted); `HandleResyncFromLandscapeClicked` is now the ONLY
  place that loads/creates+reconciles a config, and it sets `SetNexusReady(config !=
  nullptr)`; the tree widget disables while Not Ready; the button gets a highlight
  color (warm orange while Not Ready) and a context-sensitive tooltip; the tree's
  existing empty-state info row now explains "Not Ready - click Re-sync" instead of
  the old Landscape-Mode-era message.
- `UI/SNexusDetailsPanel.cpp` - replaced both `GLevelEditorModeTools().IsModeActive(EM_Landscape)`
  gates (Construct's `SetEnabled` + `NotifyPreChange`'s write-commit guard) with
  `IsNexusReady()` - also removes the last two production call sites of the unsafe
  `GLevelEditorModeTools()` accessor in this module (grep-confirmed: every remaining
  hit is either a prose comment explaining why it's not used, or the pre-existing,
  unrelated `NexusLandscapeModeExtensionTests.cpp`, not touched).
- `Mapping/NexusMapping.h` - fixed one stale comment referencing the just-removed
  `SNexusHierarchyPanel::ResolveActiveConfig`.

**Preserving authored data**: `FNexusMapping::RunAutomaticEnableFlow`/
`ReconcileMappingStage` were read in full and confirmed to never touch
`ActivationPoints`/offsets - only Highways/HighwayPoints/Cities/States. "Preserve
existing Nexus-authored offsets/data during re-sync" holds structurally, unchanged by
this task.

**Proxy pool / spatial index / Hierarchy / Details refresh on Re-sync**: already
correctly cascade from the existing plumbing - `MarkRepresentationDirty()` (already
called) forces `RefreshRepresentationIfDue`'s next-Tick rebuild, which already calls
`FNexusEditorProxyPool::RebuildSpatialIndex`; `RefreshHierarchyTree(true)` refreshes
Hierarchy; `ClearDetailsTarget()` (on the preceding map-open) plus the existing
`OnDetailsTargetChanged` binding keep Details from showing a dangling selection. No new
plumbing needed for these - confirmed by re-reading each path, not assumed.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development` - succeeded, zero
  warnings/errors (editor was closed at build time).
- Static audit: grep-confirmed zero production `GLevelEditorModeTools()` call sites
  remain in this module (only comments + the pre-existing, untouched test file); zero
  remaining references to the removed `ResolveActiveConfig`/`SNexusHierarchyPanel::ResolveActiveConfig`
  symbol outside the one now-fixed comment.
- **Not manually verified in-editor** (this agent cannot launch the editor,
  `AGENT-RULES.md`'s Agent Testing Policy) - see the `ai-change-audits/` record for the
  exact manual test steps the user should run.
- **Observed, not touched**: `Tests/NexusLandscapeModeExtensionTests.cpp` asserts the
  Nexus tab closes on leaving Landscape Mode - already inconsistent with production
  behavior since an earlier 2026-08-11 pass removed that auto-close, unrelated to and
  unaffected by this task's own changes. Left as-is per the Agent Testing Policy (do not
  fix/modify tests).
