// NexusFramework_V6 docs shell — shared behavior for every page under html-docs/.
// Same responsibilities as NexusFramework_V4/html-docs/js/script.js (theme
// toggle, mobile sidebar toggle+scrim) plus V6-specific nav injection (V6 is
// multi-page, so the nav is generated from nav-data.js instead of hand-written
// per page) and active-page highlighting instead of V4's scrollspy (V6 has no
// in-page #anchors to spy on - each doc is its own page).

(function () {
  "use strict";

  var THEME_KEY = "nexus-v6-docs-theme";

  function initTheme() {
    var stored = null;
    try { stored = localStorage.getItem(THEME_KEY); } catch (e) { /* localStorage unavailable in this context - fall through to system preference */ }
    if (stored) {
      document.documentElement.setAttribute("data-theme", stored);
    }
    var btns = document.querySelectorAll(".theme-toggle");
    if (!btns.length) return;
    updateThemeButtons(btns);
    btns.forEach(function (btn) {
      btn.addEventListener("click", function () {
        var current = document.documentElement.getAttribute("data-theme");
        var prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        var currentlyDark = current ? current === "dark" : prefersDark;
        var next = currentlyDark ? "light" : "dark";
        document.documentElement.setAttribute("data-theme", next);
        try { localStorage.setItem(THEME_KEY, next); } catch (e) { /* theme just won't persist this session */ }
        updateThemeButtons(btns);
      });
    });
  }

  function updateThemeButtons(btns) {
    var current = document.documentElement.getAttribute("data-theme");
    var prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    var currentlyDark = current ? current === "dark" : prefersDark;
    btns.forEach(function (btn) {
      btn.textContent = currentlyDark ? "☀" : "☽"; // sun / moon
      btn.title = currentlyDark ? "Switch to light theme" : "Switch to dark theme";
    });
  }

  function initMobileNav() {
    var toggle = document.getElementById("nav-toggle");
    var sidebar = document.getElementById("sidebar");
    var scrim = document.getElementById("scrim");
    if (!toggle || !sidebar || !scrim) return;

    function close() {
      sidebar.classList.remove("open");
      scrim.classList.remove("show");
    }

    toggle.addEventListener("click", function () {
      sidebar.classList.toggle("open");
      scrim.classList.toggle("show");
    });
    scrim.addEventListener("click", close);
    sidebar.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", close);
    });
  }

  function currentPageFile() {
    var path = window.location.pathname.replace(/\\/g, "/");
    var parts = path.split("/");
    return parts[parts.length - 1] || "index.html";
  }

  // V6 is multi-page (unlike V4's single page + #anchors), so the nav is
  // built here from NEXUS_NAV (see nav-data.js) instead of hand-written -
  // one array to edit when a new doc page is added, not 12+ HTML files.
  function initNav() {
    var mount = document.getElementById("nav-groups");
    if (!mount || typeof NEXUS_NAV === "undefined") return;

    var current = currentPageFile();
    NEXUS_NAV.forEach(function (group) {
      var groupEl = document.createElement("div");
      groupEl.className = "nav-group";

      var titleEl = document.createElement("div");
      titleEl.className = "nav-group-title";
      titleEl.textContent = group.title;
      groupEl.appendChild(titleEl);

      group.links.forEach(function (link) {
        var a = document.createElement("a");
        a.href = link.href;
        a.textContent = link.label;
        if (link.href === current) {
          a.classList.add("active");
          a.setAttribute("aria-current", "page");
        }
        groupEl.appendChild(a);
      });

      mount.appendChild(groupEl);
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    initTheme();
    initNav();
    initMobileNav();
  });
})();
