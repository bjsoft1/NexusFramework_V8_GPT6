/* NexusFramework_V6 html-docs — shared sidebar nav, grouped (matches
   NexusFramework_V4/html-docs' .nav-group visual pattern). Single source for
   the nav on every page - add a new doc page to the right group here (one
   line) rather than editing every page's HTML. Consumed by site.js. */

var NEXUS_NAV = [
  {
    title: "Start Here",
    links: [
      { label: "Doc Index", href: "index.html" },
      { label: "Project Overview", href: "project-overview.html" }
    ]
  },
  {
    title: "V5 Reference",
    links: [
      { label: "V5 Complete Reference", href: "v5-complete-reference.html" },
      { label: "01 — V5 Analysis", href: "01-v5-analysis.html" },
      { label: "02 — V5 Feature Inventory", href: "02-v5-feature-inventory.html" },
      { label: "03 — V5 Problems & Lessons", href: "03-v5-problems-and-lessons.html" }
    ]
  },
  {
    title: "V6 Design",
    links: [
      { label: "04 — V6 Architecture", href: "04-v6-architecture.html" },
      { label: "05 — V6 Data Flow", href: "05-v6-data-flow.html" },
      { label: "06 — V6 Debug System", href: "06-v6-debug-system.html" },
      { label: "07 — V6 UI Design", href: "07-v6-ui-design.html" },
      { label: "08 — V5 vs V6", href: "08-v5-vs-v6.html" },
      { label: "10 — Runtime Schema", href: "10-v6-runtime-schema.html" },
      { label: "11 — Static/Dynamic Architecture", href: "11-v6-static-dynamic-architecture.html" },
      { label: "12 — Activation Point System", href: "12-v6-activation-point-system.html" },
      { label: "13 — Gizmo System", href: "13-v6-gizmo-system.html" },
      { label: "14 — Validation", href: "14-v6-validation.html" },
      { label: "15 — Verification System", href: "15-v6-verification-system.html" }
    ]
  },
  {
    title: "Process",
    links: [
      { label: "09 — Development Rules", href: "09-development-rules.html" },
      { label: "Phase Tracker", href: "phase-tracker.html" },
      { label: "Phase Verification Report", href: "v6-phase-verification.html" }
    ]
  }
];
