#!/usr/bin/env node
/**
 * NexusFramework_V6 docs server — serves html-docs/ and exposes a tiny JSON
 * API the phase-tracker page uses to advance a phase's status. No
 * dependencies (Node http/fs/path builtins only), matching build.js's
 * philosophy.
 *
 * The API writes DIRECTLY to the phase's own .md `## Status` line — there is
 * still only one authoritative source of truth (the phase file itself, per
 * 09-development-rules.md rule 12); this server is just a convenient way to
 * edit that line by clicking instead of hand-editing markdown. Every write
 * triggers an automatic `node build.js` so PHASE-STATUS.md/phase-data.js/the
 * generated HTML never go stale relative to what was just clicked.
 *
 * Run:
 *   node html-docs/server.js
 * Then open the printed URL in a browser instead of double-clicking
 * index.html directly. Opening the .html files without this server still
 * works for reading docs — only the phase-tracker's checkboxes need it.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { markdownToHtml, parseStatusBlock, serializeStatusBlock, ALL_STAGES, DATED_STAGES } = require('./build.js');

const HTML_DIR = __dirname;
const ROOT = path.resolve(HTML_DIR, '..');
const SPEC_DIR = path.join(ROOT, 'project-specifications');
const PHASES_DIR = path.join(SPEC_DIR, 'phases');
const PORT = process.env.PORT ? Number(process.env.PORT) : 4173;

// Must match 09-development-rules.md rule 12's vocabulary exactly - reuses
// build.js's own ALL_STAGES so this list only exists in one place.
const ALLOWED_STATUSES = ALL_STAGES;

// "Not started" (default/initial) and "In progress" (an agent has begun work)
// are states an agent sets by editing the phase file directly (or via
// /TODO) - they don't mean anything as a browser click, so this API refuses
// to set them. Reachable only by direct file edit, matching how the file
// watcher above already picks those up automatically. This is enforced here
// (backend) AND mirrored in js/phase-tracker.js (frontend, disabled <option>s)
// - the backend check is the real gate, the frontend one is just UX so a
// disabled option never round-trips to a 400 in the first place.
const UI_BLOCKED_STATUSES = ['Not started', 'In progress'];

// Once a phase has been Complete for more than an hour, its status is locked
// - protects a finalized record from being casually changed long after the
// fact (this project's records are meant to be append-only once settled, see
// CLAUDE.md/ai-change-audits). Within the first hour it's still changeable,
// e.g. to undo a mis-click. See 09-development-rules.md rule 12.
const COMPLETE_LOCK_MS = 60 * 60 * 1000;

// Parses a single dated field's own value, e.g. "2026-08-09 22:22 NST (+0545)"
// (current convention) or the legacy date-only "2026-08-09" (no time
// recorded, from a status set before rule 12's timestamp convention existed).
// The date-only form falls back to UTC midnight, which is always >= 1 hour
// old for any date other than "today" - the only case the lock actually
// cares about telling apart. Unlike the old free-text scraping this replaced,
// the caller already knows this string is exactly one dated field's own
// value (via parseStatusBlock), not a whole prose line to search within.
function parseDateFieldValue(dateStr) {
  if (!dateStr) return null;
  const m = dateStr.match(/^(\d{4}-\d{2}-\d{2})(?:\s+(\d{2}:\d{2})\s+\S+\s*\(([+-]\d{4})\))?/);
  if (!m) return null;
  const [, datePart, timeStr, offset] = m;
  const iso = (timeStr && offset)
    ? datePart + 'T' + timeStr + ':00' + offset.slice(0, 3) + ':' + offset.slice(3)
    : datePart + 'T00:00:00Z';
  const d = new Date(iso);
  return isNaN(d.getTime()) ? null : d;
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
};

// Matches the "YYYY-MM-DD HH:MM TZID (+HHMM)" convention from
// 09-development-rules.md rule 12 - status changes made through this API
// (the phase-tracker's dropdown) need the same timestamp shape an agent
// writes by hand, both because parseStatusTimestamp() above depends on it
// and so Complete/Ready-for-Review timestamps are comparable at a glance
// regardless of who/what set them.
function nowTimestamp() {
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  const datePart = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate());
  const timePart = pad(now.getHours()) + ':' + pad(now.getMinutes());
  const offsetMin = -now.getTimezoneOffset();
  const offsetStr = (offsetMin >= 0 ? '+' : '-') + pad(Math.floor(Math.abs(offsetMin) / 60)) + pad(Math.abs(offsetMin) % 60);
  let tzName = '';
  try {
    tzName = new Intl.DateTimeFormat('en-US', { timeZoneName: 'short' }).formatToParts(now)
      .find(p => p.type === 'timeZoneName').value;
  } catch (e) { /* Intl unavailable - omit the name, the numeric offset alone is still enough to parse */ }
  return datePart + ' ' + timePart + (tzName ? ' ' + tzName : '') + ' (' + offsetStr + ')';
}

// Matches by exact filename stem (e.g. "phase-30a", "phase-01-core-structures") - the
// phase's own `id` field (build.js's extractPhases) is already 1:1 unique per file, so
// this is a plain exact match, not a numeric-prefix search. That numeric-prefix search
// is exactly what this replaced (2026-08-10 bug fix): a bare numeric id like "30" is
// ambiguous between "phase-30.md" and "phase-30a.md" (parseInt("30a", 10) === 30 too,
// per build.js's own title-number extraction - both files' `n` field is 30, used only
// for sort/group order, deliberately NOT unique), and `files.find` silently returned
// whichever sorted first ("phase-30.md" - "." < "a" in a directory listing), making
// phase-30a permanently unreachable through this API. Found when a user's genuine
// attempt to advance phase-30a's status instead hit phase-30's own Complete-lock.
function findPhaseFile(id) {
  const files = fs.readdirSync(PHASES_DIR).filter(f => /^phase-\d{2,3}[a-z]?.*\.md$/.test(f));
  const target = decodeURIComponent(String(id)).replace(/\.md$/, '');
  return files.find(f => f.replace(/\.md$/, '') === target);
}

// Rewrites the fixed `## Status` block in place via the shared
// parseStatusBlock/serializeStatusBlock (build.js) - the same reader/writer
// build.js's own extractPhases() uses, so this API and the generated docs
// can never disagree about how to read/write the block. Setting the stage to
// one of DATED_STAGES stamps THAT field's own date only - the other three
// dated fields (and any free-form notes) are carried over untouched, so a
// phase's full stage history accumulates over its lifetime instead of each
// transition erasing the previous one's date (the old single-line format's
// main limitation).
function setPhaseStatus(id, status) {
  if (!ALLOWED_STATUSES.includes(status)) {
    throw new Error('Unknown status "' + status + '" - must be one of: ' + ALLOWED_STATUSES.join(', '));
  }
  if (UI_BLOCKED_STATUSES.includes(status)) {
    throw new Error('"' + status + '" is set by an agent (direct file edit or /TODO), not from this UI/API.');
  }
  const file = findPhaseFile(id);
  if (!file) throw new Error('No phase file found for id ' + id);
  const filePath = path.join(PHASES_DIR, file);
  const text = fs.readFileSync(filePath, 'utf8');
  const lines = text.split('\n');
  const headerIdx = lines.findIndex(l => l.trim() === '## Status');
  if (headerIdx === -1) throw new Error('Phase file has no "## Status" section: ' + file);

  const parsed = parseStatusBlock(lines, headerIdx);

  // Regression fix (2026-08-09, carried over from the old single-line format):
  // UI_BLOCKED_STATUSES above only ever blocked the TARGET status from being
  // "Not started"/"In progress" - it never checked the CURRENT one. A phase
  // currently "Not started"/"In progress" must not be draggable straight to
  // "Ready for QA"/"Complete" from the browser, skipping the agent's own
  // "Ready for Review" step. Whether a phase is still "Not started"/
  // "In progress" is itself agent-owned state (rule 12: only settable by
  // direct file edit/`/TODO`) - so moving it anywhere else from this UI/API
  // must be refused too, regardless of which target status was requested.
  if (/^(Not started|In progress)$/i.test(parsed.stage)) {
    throw new Error('This phase is currently "' + parsed.stage +
      '" - only an agent (direct file edit or /TODO) may change its status while it\'s Not started/In progress, not this UI/API.');
  }

  if (/^Complete$/i.test(parsed.stage)) {
    const completedAt = parseDateFieldValue(parsed.dates['Complete']);
    if (completedAt && (Date.now() - completedAt.getTime()) > COMPLETE_LOCK_MS) {
      throw new Error('This phase has been Complete for over 1 hour and is locked from further status changes (09-development-rules.md rule 12).');
    }
  }

  const newDates = Object.assign({}, parsed.dates);
  if (DATED_STAGES.includes(status)) {
    newDates[status] = nowTimestamp();
  }

  const newBlockLines = serializeStatusBlock(status, newDates, parsed.notes);
  lines.splice(parsed.stageLineIdx, parsed.endIdx - parsed.stageLineIdx, ...newBlockLines);

  fs.writeFileSync(filePath, lines.join('\n'), 'utf8');
  return file;
}

function rebuildDocs() {
  execFileSync(process.execPath, [path.join(HTML_DIR, 'build.js')], { stdio: 'inherit' });
}

// The POST /status route above already rebuilds synchronously after its own
// write. This watcher is the backstop for status changes that DON'T go
// through that route - Claude/an agent editing a phase's ## Status line
// directly (e.g. via /TODO), or a hand-edit - so the site (and any browser
// polling /api/phases, see js/phase-tracker.js) picks them up automatically
// too, without anyone needing to remember to run `node build.js`.
let rebuildTimer = null;
function scheduleRebuild(reason) {
  if (rebuildTimer) clearTimeout(rebuildTimer);
  rebuildTimer = setTimeout(() => {
    rebuildTimer = null;
    try {
      rebuildDocs();
      console.log('[server] Auto-rebuilt (' + reason + ')');
    } catch (e) {
      console.error('[server] Auto-rebuild failed: ' + e.message);
    }
  }, 400); // debounced - fs.watch can fire more than once per logical save
}

try {
  fs.watch(PHASES_DIR, { persistent: false }, (eventType, filename) => {
    if (filename && /^phase-\d{2,3}.*\.md$/.test(filename)) {
      scheduleRebuild('changed: ' + filename);
    }
  });
  console.log('Watching project-specifications/phases/ for direct edits...');
} catch (e) {
  console.warn('[server] Could not watch phases dir for auto-rebuild: ' + e.message);
}

function sendJson(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

// Repo-root-relative prefixes served read-only in addition to html-docs/
// itself - these live as siblings of html-docs/, not inside it, but doc
// pages/the phase-tracker link into them with paths like
// "/project-specifications/phases/phase-01-core-structures.md". Without this,
// such a link 404s even though the file genuinely exists on disk (only
// HTML_DIR was ever served). The phase-tracker's own "Open phase-NN.md"
// button now prefers the rendered /api/phases/:n/content popup (see below),
// but a raw link/URL - typed directly, or opened in a new tab - should still
// resolve rather than 404.
const ROOT_SERVED_PREFIXES = ['/project-specifications/', '/ai-change-audits/', '/agent-todos/'];

function serveStatic(req, res, urlPath) {
  let rel = urlPath === '/' ? '/index.html' : urlPath;
  rel = decodeURIComponent(rel.split('?')[0]);
  const base = ROOT_SERVED_PREFIXES.some(p => rel.startsWith(p)) ? ROOT : HTML_DIR;
  const filePath = path.join(base, rel);
  if (!filePath.startsWith(base)) { res.writeHead(403); res.end('Forbidden'); return; }
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found: ' + rel); return; }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

// [a-z0-9-]+ (not \d+) - a bare number is ambiguous between e.g. "phase-30.md" and
// "phase-30a.md" (see findPhaseFile's own comment above) - both routes below key off
// each phase's own unique `id` field (e.g. "phase-30a", "phase-01-core-structures"),
// never a number alone.
const PHASE_ID_SEGMENT = '([a-z0-9-]+)';

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && new RegExp('^/api/phases/' + PHASE_ID_SEGMENT + '/status$').test(req.url)) {
    const id = req.url.match(new RegExp('^/api/phases/' + PHASE_ID_SEGMENT + '/status$'))[1];
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const parsed = JSON.parse(body || '{}');
        const file = setPhaseStatus(id, parsed.status);
        rebuildDocs();
        sendJson(res, 200, { ok: true, phaseId: id, file: file, status: parsed.status });
      } catch (e) {
        sendJson(res, 400, { ok: false, error: e.message });
      }
    });
    return;
  }

  if (req.method === 'GET' && new RegExp('^/api/phases/' + PHASE_ID_SEGMENT + '/content$').test(req.url)) {
    const id = req.url.match(new RegExp('^/api/phases/' + PHASE_ID_SEGMENT + '/content$'))[1];
    try {
      const file = findPhaseFile(id);
      if (!file) throw new Error('No phase file found for id ' + id);
      const md = fs.readFileSync(path.join(PHASES_DIR, file), 'utf8');
      const titleMatch = md.match(/^#\s+(.*)$/m);
      sendJson(res, 200, { ok: true, file: file, title: titleMatch ? titleMatch[1].trim() : file, html: markdownToHtml(md) });
    } catch (e) {
      sendJson(res, 404, { ok: false, error: e.message });
    }
    return;
  }

  if (req.method === 'GET' && req.url === '/api/phases') {
    try {
      const dataPath = path.join(HTML_DIR, 'js', 'phase-data.js');
      const src = fs.readFileSync(dataPath, 'utf8');
      // phase-data.js is `/* generated-file comment */\n\nvar NEXUS_PHASES = [...];\n`
      // - strip the leading comment before anchoring on the assignment.
      const m = src.match(/var NEXUS_PHASES\s*=\s*(\[[\s\S]*\])\s*;\s*$/);
      if (!m) throw new Error('Could not parse js/phase-data.js - run node build.js first');
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(m[1]);
    } catch (e) {
      sendJson(res, 500, { ok: false, error: e.message });
    }
    return;
  }

  serveStatic(req, res, req.url);
});

server.listen(PORT, () => {
  console.log('NexusFramework_V6 docs server running:');
  console.log('  http://localhost:' + PORT + '/');
  console.log('Open that URL (not the .html files directly) so the phase');
  console.log('tracker\'s checkboxes can write back to each phase\'s .md file.');
  console.log('Ctrl+C to stop.');
});
