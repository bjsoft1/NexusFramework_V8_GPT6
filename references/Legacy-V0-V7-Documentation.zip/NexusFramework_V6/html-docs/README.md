# html-docs — internal tooling notes

This folder is a **generated, browsable view** of `../project-specifications/` — a static
site with a left sidebar, right content pane, light/dark theme toggle, and an interactive
phase-tracker page. It's here for visual human review; it is not itself a source of project
truth. This file documents the tooling itself (not V6 architecture), which is why it lives
here rather than in `project-specifications/` — see that folder's `09-development-rules.md`
for the documentation-separation rule this follows.

## Open it

**To just read the docs**: double-click `index.html` (or any `.html` file here) to open
directly in a browser — no server, no build step needed. Works fully offline via
`file://`.

**To use the phase-tracker's status dropdown**: it writes back to a real `.md` file, so
it needs a server (see below) — opened via `file://` it renders disabled with a banner
explaining why.

```
npm start
```

(from the `NexusFramework_V6` repo root — `package.json` just aliases this to
`node html-docs/server.js`; equivalent commands: `npm run server`, or run
`node html-docs/server.js` directly, or `PORT=8080 node html-docs/server.js` for a
different port). No dependencies to install — no `npm install` needed, `package.json`
exists purely for the `npm start` convenience, not for any package. Then open the
printed `http://localhost:4173/` URL. It serves this folder as static files and adds
two JSON routes the tracker page calls:

- `GET /api/phases` — the current phase list (same data as `js/phase-data.js`, read
  fresh each request).
- `GET /api/phases/:n/content` — a phase's `.md` rendered to HTML (via `build.js`'s own
  `markdownToHtml()`, required as a module — see "How the markdown → HTML conversion
  works" below) as `{ ok, file, title, html }`. Backs the phase-tracker's "Open
  phase-NN.md" popup (see below) — it used to link straight to
  `../project-specifications/phases/phase-NN....md`, which 404'd (that path lives
  outside `html-docs/`, the only directory this server serves as static files).
- `POST /api/phases/:n/status` — body `{"status": "Ready for Review"}` (or any of the
  seven values in `09-development-rules.md` rule 12, except `Not started`/`In progress`,
  which this endpoint refuses — those are agent-set only, see rule 12). Rewrites the
  `<Stage>` line of `project-specifications/phases/phase-NN*.md`'s fixed-line `## Status`
  block (rule 12) and stamps a date+time into that stage's own dated field (if it's one
  of the four that gets one) — the other three dated fields and any free-form notes below
  them are left untouched, so earlier stage dates survive later transitions — then runs
  `build.js` automatically so everything (this site, `PHASE-STATUS.md`) stays in sync.
  There is no separate database or shadow-state file; the phase `.md` files ARE the
  storage. Both this write path and `build.js`'s own phase-status reader share one parser/
  serializer (`parseStatusBlock`/`serializeStatusBlock` in `build.js`) rather than each
  keeping its own regex. Also refuses to change a phase that has been `Complete` for over
  an hour (see "Phase-tracker status dropdown" below).

Static files: this server serves `html-docs/` itself, plus read-only access to
`project-specifications/`, `ai-change-audits/`, and `agent-todos/` (siblings of
`html-docs/` that pages sometimes link into directly, e.g. a raw phase `.md` URL) — no
other path on disk is reachable through it.

The server also **watches `project-specifications/phases/` for direct edits** (an agent
running `/TODO`, or you hand-editing a `## Status` line) and auto-rebuilds when it sees
one, and the tracker page **polls `/api/phases` every few seconds** — so a status change
from any source shows up in the browser within a few seconds, with no manual refresh or
`npm run build` needed.

Stop the server with Ctrl+C — it doesn't need to stay running to read docs, only to
click tracker checkboxes.

## What's authoritative vs. generated

- **Authoritative (hand-edited)**: every `.md` file in `../project-specifications/`
  (including `phases/*.md`).
- **Generated (never hand-edit — edits are silently lost on the next build)**:
  - Every `.html` file in this folder.
  - `js/phase-data.js`.
  - `../project-specifications/PHASE-STATUS.md`.

## Regenerating after a doc changes

```
node html-docs/build.js
```

Run from the `NexusFramework_V6` repo root (or any directory — the script resolves paths
from its own location, not the current working directory). No `npm install`, no external
packages — pure Node.js builtins (`fs`, `path`) only, by design, so this keeps working with
whatever Node is already on the machine.

Run it whenever:
- Any `project-specifications/*.md` file changes (re-renders that page).
- A new doc is added to `project-specifications/` — also add one line to
  `js/nav-data.js`'s `NEXUS_NAV` array and one entry to `build.js`'s `DOC_PAGES` list (map
  its `.md` name to the `.html` name you want) so the build picks it up and the sidebar
  links to it. This is the "future docs must be supportable" mechanism — one array entry,
  not a new hand-authored page.
- Any `phases/phase-NN*.md` file's `## Status` changes (regenerates `PHASE-STATUS.md` and
  the phase-tracker page's data).

## How the markdown → HTML conversion works

`build.js` contains a small, deliberately non-general markdown-to-HTML converter (headers,
paragraphs incl. wrapped/multi-line list items, bold/italic, inline code, fenced code
blocks, blockquotes, ordered/unordered lists with one level of nesting and GFM `[ ]`/`[x]`
task items, tables, links). It is scoped to exactly what this project's own docs use, not a
general CommonMark implementation — extend `markdownToHtml()` in `build.js` if a future doc
needs a construct it doesn't handle yet (rare; it already covers everything the current 12
docs use).

Links between two known top-level docs get rewritten from `.md` to `.html` automatically
(e.g. `[03-...](03-v5-problems-and-lessons.md)` → `03-v5-problems-and-lessons.html`) via the
`DOC_PAGES` map in `build.js`. Links into `phases/*.md` are left as plain `.md` links (no
per-phase HTML page is generated — the phase tracker page is the browsable view for those;
clicking a phase link opens/downloads the raw markdown, which is fine for occasional
reference).

**Known cosmetic limitation**: nested list items render as a `<ul>` sibling rather than
nested inside the parent `<li>` (not strictly valid HTML5 content model for `<ul>`, though
every current major browser still renders it correctly indented). Not worth the added
parser complexity to fix unless it visibly breaks somewhere.

## Theme toggle

Uses `localStorage`, scoped to this browser only: `nexus-v6-docs-theme` — `"light"` or
`"dark"`, falls back to OS `prefers-color-scheme` when unset. Purely cosmetic, no reason
for this one to be server-backed.

## Phase-tracker status dropdown

**Not `localStorage`-based** (an earlier design used checkboxes and browser storage;
both are gone). Each row has one `<select>` showing the same six-value status
vocabulary as `project-specifications/09-development-rules.md` rule 12. Changing it
calls the server's `POST /api/phases/:n/status` API (see above), which edits that
phase's own `.md` file directly — there is exactly one source of truth (the phase
file), not a browser-side shadow copy that can drift from it. Without `server.js`
running, the dropdown still renders (reflecting the last build) but is disabled, with a
banner explaining why.

The page also polls `/api/phases` every few seconds, so a status change shows up
automatically — whether it came from this dropdown, another browser tab, or **an agent
editing a phase's `## Status` line directly** (e.g. via `/TODO`). `server.js` watches
`project-specifications/phases/` and auto-rebuilds on any change to those files, not
just ones made through its own API, so a direct edit is picked up the same way.

**`Not started` and `In progress` are technically blocked from this UI — as both a
target AND the phase's current status.** Both the dropdown (rendered `disabled`, greyed
out) and the server's API (`setPhaseStatus` throws) refuse to set either one. Those two
only mean anything as something an agent does (starting work), not something meaningful
to click in a browser — set them by editing the phase file directly, or via `/TODO`.
The reverse direction is blocked too: if a phase's CURRENT status is `Not started` or
`In progress`, its entire dropdown is disabled (not just those two options as targets) —
a human moving such a phase straight to `Ready for QA`/`Complete` would skip the agent's
own `Ready for Review` step, which is exactly the gap a real regression exploited (fixed
2026-08-09, see `ai-change-audits/2026-08-09/bug-fixed/phase-tracker-status-ui-broken.md`).

**`In Review`, `Ready for QA`, and `Complete` are convention-only, not technically
enforced** — same as `agent-todos/AGENT-TODO-RULES.md`'s folder-move ownership: only a
human should pick those from the dropdown. An agent implementing a phase via `/TODO`
stops at `Ready for Review`, whether it edits the `.md` file directly or calls the same
API this page uses — nothing currently stops an agent from calling the API with
`In Review`, `Ready for QA`, or `Complete` itself, so this boundary relies on the agent
following
`09-development-rules.md` rule 12, the same way `AGENT-TODO-RULES.md` already relies on
agents not moving a task to `ready-for-qa/`/`closed/` themselves.

**A phase `Complete` for over an hour is locked from further status changes** — this one
*is* technically enforced, both server-side (`setPhaseStatus` in `server.js` throws) and
in the dropdown (rendered `disabled`, with a tooltip). Protects a finalized record from
being casually changed long after the fact; within the first hour it's still changeable
(e.g. to undo a mis-click). The lock is keyed off the timestamp already in the phase's
own status block `Complete: YYYY-MM-DD HH:MM TZID (+HHMM)` field, so it needs no separate
storage.

**"Open `phase-NN....md`" opens a popup, not a raw file link** — fetches
`GET /api/phases/:n/content` and renders it with the same look as every other doc page
(headers, tables, checklists) instead of navigating to a `.md` URL. Closes via its ✕
button, clicking outside it, or Escape.

## Files

```
html-docs/
  build.js              — the build script (see above)
  server.js              — dev server + phase-status write-back API (see above)
  css/site.css            — all shared styles (theme tokens, layout, prose, phase-tracker)
  js/nav-data.js          — shared sidebar nav list (add new pages here)
  js/site.js               — theme toggle + sidebar/topbar injection (every page)
  js/phase-tracker.js       — phase-tracker.html's checkbox/collapse/filter behavior,
                               calls server.js's API
  js/phase-data.js           — GENERATED phase list, also served as JSON at /api/phases
  *.html                      — GENERATED pages (one per project-specifications/*.md,
                                 plus phase-tracker.html)
```
