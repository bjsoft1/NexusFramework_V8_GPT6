# Project AI Memory — Single Source of Truth

Project AI memory lives **exclusively** in:

```
ai-change-audits/
```

It is the primary and authoritative source of truth for this project's AI-assisted work
history. See `ai-change-audits/README.md` for the category index.

This rule applies automatically to every agent working in this repository — Codex,
new sessions, sub-agents, future agents — including ones with no memory of this
instruction ever being given. Check `ai-change-audits/` before doing work that may depend
on previous project history.

This project (`NexusFramework_V6`) is a rebuild-from-lessons of `NexusFramework_V5`, in a
sibling directory. V5 has its own, separate `ai-change-audits/` — do not conflate the
two. Read `project-specifications/v5-complete-reference.md` and
`project-specifications/03-v5-problems-and-lessons.md` for what V5 knowledge already
carried over; only log *new*, V6-specific findings here.

## Rules

1. **One location.** Never store project-specific AI memory in `.Codex/`,
   `<PROJECT_ROOT>/.Codex/`, `C:/Users/<user>/.Codex/`, or any other global/external
   Codex memory, cache, log, or temp location. `.Codex/` may hold tooling configuration,
   never project history.
2. **Append-only.** Never delete, overwrite, or silently edit an existing audit record.
   When new information, a correction, or a verification result comes in, append a new
   dated section to the relevant file (or add a new file) — never rewrite what's already
   there. A correction to a past finding is itself a new appended section
   (`## Correction — YYYY-MM-DD`), not an edit to the original text.
3. **Structure**: a date folder for the day the entry was written, then category, then the
   record file(s) — `ai-change-audits/<YYYY-MM-DD>/<category>/<record-name>.md`:
   ```
   ai-change-audits/
   └── 2026-08-09/
       ├── bug-fixed/    — investigations, root causes, crash/regression fixes, verification
       │   └── some-bug-fixed-record.md
       ├── feature-add/  — new features, systems, tools, editor functionality, architecture
       │   └── some-feature-record.md
       ├── research/     — engine/API/architecture investigation, experiments
       └── others/       — architecture decisions, project conventions, general history
   ```
   New records go in today's `YYYY-MM-DD` folder, under the right category subfolder inside
   it (create either if they don't exist yet). A follow-up/correction/verification for an
   existing record still appends to that record's own file in its **original** date folder
   — it does NOT get a new entry under today's date.
4. **No duplicate memory systems.** Don't create `project-memory/`, `ai-memory/`,
   `agent-memory/`, `ai-logs/`, or similar — `ai-change-audits/` only.
5. **Preferred record shape** (existing files may instead be one long append-only log with
   dated `##` sections — both are fine, don't force a rewrite to fit this shape):
   ```
   # Title
   Date:
   Category:
   Phase: (which phases/NN this relates to, if any)

   ## Context
   ## Problem / Goal
   ## Findings
   ## Changes
   ## Verification
   ## Result
   ## Important Notes
   ```
6. **Completion records** (for `ai-change-audits/` entries, and separately for
   `agent-todos/` task files per their own rules) include: Task, Category, Phase, Status,
   Completed Date, Completed Time, Notes — see
   `project-specifications/09-development-rules.md` rule 12 for the phase Status
   vocabulary these must stay consistent with.

## Related: standing agent policy (`project-specifications/AGENT-RULES.md`)

`project-specifications/AGENT-RULES.md` holds persistent, project-wide behavioral rules
for every agent (currently: an Agent Testing Policy — do not write/run automated tests
unless the user explicitly asks). Read it before starting work, same as this file —
it's policy, not memory, so it lives in `project-specifications/` rather than
`ai-change-audits/`, but it carries the same "every agent must read this" weight.

## Related: master architecture (`project-specifications/v6-master-architecture.md`)

The top-level architecture authority for V6 — above `v6-phase-verification.md` and above
the numbered `04`-`14` docs. Read it (after `AGENT-RULES.md`, before everything else in
`project-specifications/`) before starting or auditing any phase work: it defines the
required Landscape→Editor→Runtime Schema pipeline, the Landscape-as-source-of-truth rule,
the N-sub-point gizmo requirement, per-object field-level specs (Parking/Bus Stop/Seat),
debug LOD/always-draw requirements, junction rotation safety, the massive-world static
+dynamic actor strategy, and the mandatory Phase 20/40/60/80/100 architecture-review
checkpoints. Like `AGENT-RULES.md`, it's policy/architecture, not memory, so it lives in
`project-specifications/` rather than `ai-change-audits/`.

## Related: C++ coding standard (`project-specifications/v6-coding-standard.md`)

Read before writing or modifying any C++ in this repo — same standing weight as
`AGENT-RULES.md`'s Agent Testing Policy (this standard is now cross-referenced from that
same file). Covers naming case/prefix rules (PascalCase types/members/functions with an
`Is/Has/Can/Should/Was/Were` boolean prefix, camelCase parameters/locals) and, critically,
a serialization-risk warning before renaming any `UPROPERTY` boolean — this project has
saved `.uasset` content on disk that a bare property rename would silently corrupt.

## Related: task workflow queue (`agent-todos/`)

`agent-todos/` is a **separate, complementary system** for day-to-day task state (what's
queued, what's actively being worked, what's awaiting review/QA) for work that is NOT a
whole roadmap phase — not memory, not covered by the append-only rule above. Full rules
live in `agent-todos/AGENT-TODO-RULES.md` — **read that file before processing a `/TODO`
command**.

## Related: roadmap phases (`project-specifications/phases/`)

The 100-phase roadmap (`phase-00.md` .. `phase-99.md`) is V6's primary unit of planned
work — see `project-specifications/README.md` and `09-development-rules.md`. A phase's
state lives in its own file's `## Status` line (six-value vocabulary, rule 12 in
`09-development-rules.md`), not in `agent-todos/` — a phase's identity is a fixed,
numbered file path other docs cross-reference, so it isn't moved between folders the way
`agent-todos/` tasks are. `html-docs/server.js` provides a clickable UI for advancing a
phase's status (see `html-docs/README.md`) that writes directly to the same `.md` file —
it is a convenience for editing the one authoritative field, not a second copy of it.

`ai-change-audits/` (history of what was found/decided/changed, append-only, read for
context), `agent-todos/` (state of ad-hoc, non-phase work, files moved between folders as
work progresses), and `project-specifications/phases/` (state of the planned roadmap,
status field per fixed file) answer three different questions — check all three when
picking up work cold. When `agent-todos/` or phase work is significant enough to be worth
remembering long-term (a root cause, an architecture decision), it still belongs recorded
in `ai-change-audits/` too — those track workflow state, not durable findings.
