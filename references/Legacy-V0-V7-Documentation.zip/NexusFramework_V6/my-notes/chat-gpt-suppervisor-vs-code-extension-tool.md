# Build: Nexus AI Supervisor — VS Code Extension

Build a production-quality VS Code extension named:

**Nexus AI Supervisor**

The extension coordinates:

* GPT = Architect / Decision Maker / Final Reviewer
* Claude Agent = Implementation Worker
* VS Code Extension = Supervisor / Permission Controller / Automation Controller

Do NOT use Codex.

The main goal is:

```text
User gives task
    ↓
GPT understands task + project architecture
    ↓
GPT gives short implementation instruction
    ↓
Claude implements
    ↓
Claude needs permission?
    → Extension auto-allow / GPT / User
    ↓
Claude needs architectural decision?
    → GPT decides automatically
    ↓
Claude finishes
    ↓
Extension captures result + diff + build/test
    ↓
GPT final review
    ↓
APPROVED
or
FIX instructions → Claude
    ↓
Complete
```

---

# 1. Technology

Build the extension in:

* TypeScript
* strict TypeScript mode
* VS Code Extension API
* Claude Agent SDK using the current official Anthropic SDK/API
* OpenAI official JavaScript/TypeScript SDK
* OpenAI Responses API for GPT
* Node.js APIs where required

Before implementation, verify current official SDK documentation and use the latest stable supported APIs.

Do not automate browser sessions.
Do not scrape ChatGPT or Claude websites.
Do not use browser cookies.

Use official APIs/SDK authentication only.

For OpenAI:

* Support OpenAI API credential
* GPT model must be configurable
* Never hard-code Codex
* Store credentials securely

For Claude:

* Use the officially supported Claude Agent SDK authentication mechanism.
* Support existing Claude authentication when officially available.
* Never scrape credentials.

Use VS Code SecretStorage for secrets.

Never store API keys inside:

* `.env`
* workspace settings
* project files
* logs
* prompts

---

# 2. Main Extension UI

Create a VS Code Activity Bar section:

```text
NEXUS AI
```

Main panel:

```text
┌───────────────────────────────────┐
│ Nexus AI Supervisor               │
│                                   │
│ Project Type                      │
│ [ Unreal Engine Editor Tool  ▼ ] │
│                                   │
│ GPT       ● Connected             │
│ Claude    ● Connected             │
│                                   │
│ Task                              │
│ ┌───────────────────────────────┐ │
│ │ Implement Phase 42...         │ │
│ └───────────────────────────────┘ │
│                                   │
│ [ Start Task ]                    │
│ [ Pause ] [ Stop ]                │
│                                   │
│ Status                            │
│ Claude: Implementing              │
│ GPT: Idle                         │
│ Build: Waiting                    │
│                                   │
│ Last Event                        │
│ Editing NexusRoadPoint.cpp        │
│                                   │
│ [ View Logs ]                     │
│ [ View Decisions ]                │
│ [ View Permissions ]              │
└───────────────────────────────────┘
```

Also create a VS Code status bar item:

```text
$(hubot) Nexus AI: Claude Working
```

Possible states:

```text
Idle
Planning
Claude Working
Waiting for GPT
Building
Testing
GPT Reviewing
Needs Approval
Failed
Completed
```

---

# 3. Project Type Dropdown

The extension MUST have a project type dropdown.

Supported project types:

```text
.NET Backend
Next.js Frontend
Unreal Engine Editor Tool / Plugin
Unreal Engine Game C++
```

Define:

```ts
enum NexusProjectType {
    DotNetBackend,
    NextJsFrontend,
    UnrealEditorTool,
    UnrealGameCpp
}
```

Store selection per workspace.

Allow manual switching at any time.

Optionally detect project type automatically, but manual selection always overrides auto-detection.

Detection examples:

```text
*.sln / *.csproj
    → .NET Backend

next.config.*
package.json + Next dependency
    → Next.js Frontend

*.uplugin
    → Unreal Engine Editor Tool / Plugin

*.uproject + Source/
    → Unreal Engine Game C++
```

---

# 4. Project-Specific Permission Profiles

The selected project type controls Claude's default permissions.

Create:

```ts
interface PermissionProfile {
    autoAllow: PermissionRule[];
    askGPT: PermissionRule[];
    askUser: PermissionRule[];
    deny: PermissionRule[];
}
```

Permission evaluation order:

```text
DENY
↓
ASK USER
↓
ASK GPT
↓
AUTO ALLOW
↓
Default = ASK USER
```

Never globally disable permission safety.

---

# 5. Global Auto-Allow

Generally auto-allow:

```text
Read files inside workspace
Search files inside workspace
Glob
Grep
List directories
Read git history
git status
git diff
git log

Edit normal source files
Create normal source files
Create tests
Create documentation

Run build
Run tests
Run lint
Read build logs
Read compiler output
Read test output
```

The extension should answer these Claude permission requests automatically.

Do NOT bother the user for normal development operations.

---

# 6. Global ASK GPT

Route these to GPT Architect first:

```text
Architectural changes
Design-pattern decisions
New abstractions
Module boundaries
Plugin boundaries
Schema changes
Serialization changes
Public API changes
Large refactors
Dependency additions
Package upgrades
Database migration design
Multiple valid implementation approaches
Changing project structure
Changing important configuration
Claude explicitly says it is uncertain
Claude asks "which approach is better?"
```

GPT makes the decision automatically.

User should normally NOT see these questions.

---

# 7. Global ASK USER

Require real user approval for:

```text
Access outside workspace
Delete important source directories
Delete user assets
Delete database
Drop database/table
Destructive database migration
Git push
Git force push
Git reset --hard
Git clean destructive operations
Publish package
Deploy application
Production deployment
Production database operation
Credential access
Secret access
Elevated/admin command
OS-level destructive operation
Irreversible migration
```

VS Code approval dialog:

```text
Nexus AI requires approval

Claude wants to:
Delete Content/Maps/City01.umap

[Allow Once]
[Always Allow for Project]
[Deny]
```

Never let GPT approve highly destructive operations on behalf of the user.

---

# 8. .NET Backend Profile

Auto allow:

```text
*.cs
*.csproj normal compilation fixes
*.sln normal usage
Controllers/
Services/
Repositories/
Models/
DTOs/
Mappings/
Features/
Tests/
Interfaces/
Infrastructure/
Application/
Domain/
```

Commands:

```text
dotnet restore
dotnet build
dotnet test
dotnet format
```

Auto allow normal Dapper/EF/source development.

ASK GPT:

```text
Major csproj dependency changes
Architecture layer changes
DI lifetime changes
Database schema design
Repository/service pattern changes
Authentication architecture
Breaking API contract
Large refactor
```

ASK USER:

```text
dotnet ef database update against non-local database
database drop
destructive migration
production DB command
secret/connection-string exposure
deployment
```

Never expose connection strings or secrets to GPT/Claude unnecessarily.

---

# 9. Next.js Frontend Profile

Auto allow:

```text
app/
pages/
src/
components/
hooks/
lib/
utils/
styles/
public source references
tests/
*.ts
*.tsx
*.js
*.jsx
*.css
*.scss
```

Commands:

```text
npm run build
npm run test
npm run lint
pnpm build
pnpm test
pnpm lint
yarn build
yarn test
yarn lint
```

ASK GPT:

```text
New major dependency
Framework architecture changes
State-management changes
Routing architecture changes
Authentication architecture
Breaking API contract
Major package upgrade
next.config changes with architectural impact
```

ASK USER:

```text
Production deployment
Secret/environment credential exposure
Destructive cloud command
Production database operation
```

Never send `.env` secrets to agents.

---

# 10. Unreal Engine Editor Tool / Plugin Profile

This profile is for:

```text
UE C++ plugins
Editor-only plugins
Custom editor tools
Slate UI
Editor subsystem
Landscape Mode integration
Custom tabs
Debug tools
Data Assets
Editor schemas
Automation tests
```

Auto allow normal development inside:

```text
Plugins/
Source/
Config/
Scripts/
Documentation/
Tests/
```

Allow normal changes to:

```text
.h
.cpp
.cs Build.cs
Target.cs
Slate files
Editor subsystem code
Automation tests
Plugin source
```

Auto allow:

```text
Unreal Build Tool builds
Editor target builds
Automation tests
Reading Saved/Logs
Reading crash logs
Deleting generated build folders
```

Generated cleanup may auto-delete:

```text
Binaries/
Intermediate/
DerivedDataCache/
.vs/
Saved temporary build data
Plugin Binaries/
Plugin Intermediate/
```

ASK GPT:

```text
Changing module architecture
Runtime ↔ Editor ownership change
New module
Plugin architecture change
Schema change
Serialized USTRUCT change
UENUM numeric-value change
Landscape integration architecture
Slate framework architecture change
Changing .uplugin meaningfully
Changing .uproject meaningfully
Large Content/DataAsset migration strategy
```

ASK USER:

```text
Delete .uasset
Delete .umap
Delete important Content/
Mass asset migration
Destructive asset commandlet
Git push
Release/package plugin
```

Do not directly corrupt or text-edit binary Unreal assets.

---

# 11. Unreal Engine Game C++ Profile

This profile is for runtime/game development.

Auto allow:

```text
Source/
Config/
Tests/
Scripts/
Gameplay C++
Actors
Components
Subsystems
Game modes
AI
Vehicles
World systems
Runtime schemas
```

Auto allow:

```text
UE build
UBT
Automation tests
Functional tests
Reading logs
Compiler diagnostics
Normal source changes
```

ASK GPT:

```text
Gameplay architecture
Subsystem ownership
Replication architecture
Save-game schema
Runtime schema
Networking architecture
Performance-sensitive redesign
Module dependency changes
Large refactor
.uplugin/.uproject architecture changes
```

ASK USER:

```text
Delete maps
Delete important assets
Mass Content modification
Packaging/release
Git push
Destructive migration
```

---

# 12. User-Editable Permission Configuration

Create workspace configuration:

```text
.nexus-ai/
    config.json
```

Example:

```json
{
  "projectType": "UnrealEditorTool",
  "maxReviewLoops": 3,
  "permissions": {
    "autoAllow": [],
    "askGPT": [],
    "askUser": [],
    "deny": []
  }
}
```

Built-in profile rules are defaults.

Workspace rules may extend/override them.

Provide UI:

```text
Nexus AI: Edit Permission Rules
```

---

# 13. GPT Architect

GPT is NOT the coding worker.

GPT responsibilities:

```text
Understand architecture
Analyze Claude concerns
Choose best approach
Protect existing design patterns
Resolve ambiguity
Review architecture changes
Review final implementation
Catch regressions
```

GPT should receive only relevant project context.

Do not send the entire repository every request.

Create:

```text
.nexus-ai/
    PROJECT.md
    ARCHITECTURE.md
    DESIGN-PATTERNS.md
    LOCKED-DECISIONS.md
    SCHEMA.md
    CODING-RULES.md
    BUILD-RULES.md

    prompts/
        architect.md
        decision.md
        final-review.md
        claude-worker.md
```

Files may be missing.

The extension should work without them, but use them when present.

---

# 14. GPT Must Return SHORT Instructions

This is extremely important.

GPT must NOT return ChatGPT-style long explanations to Claude.

Use this permanent instruction:

```text
You are the project's Technical Architect.
Claude is the implementation worker.

Think deeply internally.

Return ONLY the instruction Claude needs to continue.

Do not say:
"Okay"
"I will"
"Here is the prompt"
"My recommendation"
"Analysis"
"Explanation"

Do not repeat the question.

Prefer 2-8 short implementation-focused lines.

Include only:
- decision
- critical constraints
- required verification

The output will be sent directly to Claude.
```

Example:

```text
Preserve the existing serialized field.
Add CategoryMask as the new representation and migrate legacy data during load.
Do not renumber existing enum values.
Update Editor → Runtime export and add a backward-compatibility test.
```

Nothing else.

---

# 15. Claude Worker Prompt

Claude receives a permanent worker rule:

```text
You are the implementation worker.

Follow the project's existing architecture and patterns.

GPT is the Technical Architect.

You may independently make normal local coding decisions.

If you encounter:
- multiple architecture options
- schema uncertainty
- design-pattern uncertainty
- breaking change risk
- ownership ambiguity
- an important tradeoff
- something you would normally ask the user to choose

do NOT guess.

Emit a structured architecture question so the Nexus AI Supervisor can send it to GPT.

Do not ask architecture questions through ordinary conversational prose when a structured question mechanism is available.

After receiving GPT's decision, continue implementation automatically.

Normal compiler errors, syntax fixes, naming decisions and local implementation details should normally be solved by you without asking GPT.

Build and test your work before reporting completion.
```

---

# 16. Claude Question → GPT

Intercept Claude questions requiring architectural/user decisions.

Preferred flow:

```text
Claude
   ↓
Structured question / AskUserQuestion event
   ↓
Nexus Supervisor
   ↓
Classify
   ↓
GPT Architect
   ↓
Short decision
   ↓
Claude
```

Send GPT:

```text
Task
Relevant project rules
Claude question
Claude options if supplied
Relevant affected files/context
Current implementation state
Relevant error information
```

Do NOT unnecessarily send:

```text
Entire repository
Huge logs
Unrelated files
Secrets
Binary files
```

---

# 17. Question Classification

Create:

```ts
enum QuestionTarget {
    ClaudeSelf,
    GPTArchitect,
    HumanUser
}
```

Examples:

```text
"What should this variable be called?"
→ ClaudeSelf

"Should this live in Runtime or Editor module?"
→ GPTArchitect

"This operation will delete 400 assets. Continue?"
→ HumanUser
```

---

# 18. Permission Classification

Create:

```ts
enum PermissionDecision {
    Allow,
    AskGPT,
    AskUser,
    Deny
}
```

Centralize permission logic.

Do not scatter permission decisions throughout UI code.

Create a dedicated:

```text
PermissionEngine
RiskClassifier
ProjectPermissionProfile
```

---

# 19. Claude Final Result Capture

When Claude says the task is complete, do NOT immediately mark it complete.

Capture:

```text
Claude final message
Changed files
git diff
git diff --stat
Build result
Test result
Warnings
Compiler errors
Task specification
Relevant architecture rules
```

Create:

```ts
interface ClaudeCompletionResult {
    summary: string;
    changedFiles: string[];
    diff: string;
    buildResult?: BuildResult;
    testResult?: TestResult;
    warnings: string[];
}
```

---

# 20. GPT Final Review

Send Claude's completed work to GPT with:

```text
Original task
Relevant architecture
Relevant locked decisions
Claude final result
Git diff
Build results
Test results
Custom final-review prompt
```

Custom prompt comes from:

```text
.nexus-ai/prompts/final-review.md
```

Default final-review instruction:

```text
Review Claude's implementation against the task and project architecture.

Check:
- requirements completed
- architecture compliance
- design-pattern compliance
- schema compatibility
- obvious bugs
- incomplete implementation
- unsafe changes
- missing tests
- build/test failures

Return ONLY one of:

APPROVED

or

FIX
<short direct instructions for Claude>

Do not provide general feedback.
Do not provide a long explanation.
Keep FIX instructions concise and executable.
```

---

# 21. Automatic Review/Fix Loop

Workflow:

```text
Claude finishes
      ↓
Build
      ↓
Tests
      ↓
GPT review
      ↓
APPROVED?
  │
 YES ─────→ Complete
  │
 NO
  ↓
FIX instructions
  ↓
Claude
  ↓
Build
  ↓
Tests
  ↓
GPT review
```

Default:

```text
maxReviewLoops = 3
```

Make configurable.

If maximum loops are exceeded:

```text
STOP
```

Show user warning:

```text
Nexus AI stopped after 3 review attempts.
Human review is required.
```

---

# 22. Build/Test Awareness

Do not hard-code one build command for every project.

Create:

```ts
interface ProjectAdapter {
    detect(): Promise<boolean>;
    getBuildCommand(): Promise<Command | undefined>;
    getTestCommand(): Promise<Command | undefined>;
    getLintCommand(): Promise<Command | undefined>;
    getPermissionProfile(): PermissionProfile;
    collectContext(): Promise<ProjectContext>;
}
```

Implement:

```text
DotNetProjectAdapter
NextJsProjectAdapter
UnrealEditorProjectAdapter
UnrealGameProjectAdapter
```

Allow commands to be overridden in `.nexus-ai/config.json`.

---

# 23. VS Code Notifications

Use native VS Code notifications.

### Information

Use information notification for:

```text
Nexus AI task started
Project profile selected
Claude started
Build passed
Tests passed
GPT approved implementation
Task completed
GPT automatically resolved a Claude question
```

Example:

```text
Nexus AI: GPT resolved Claude's architecture question.
```

### Warning

Use warning notification for:

```text
Human permission required
Build warning
GPT rejected implementation
Review retry
Unusual command
External workspace access requested
Max review loops approaching
```

### Error

Use error notification for:

```text
Claude failed
GPT request failed
Authentication failed
Build failed permanently
Agent crashed
Permission engine failed
Invalid configuration
Review loop exhausted with fatal issue
```

Use:

```ts
vscode.window.showInformationMessage(...)
vscode.window.showWarningMessage(...)
vscode.window.showErrorMessage(...)
```

Do not spam notifications for every file edit.

Only notify meaningful lifecycle events.

---

# 24. Output Channel

Create:

```text
Nexus AI
```

VS Code Output Channel.

Example:

```text
[20:14:01] Task started
[20:14:02] Profile: Unreal Editor Tool
[20:14:04] GPT architecture request
[20:14:07] GPT → Claude: Preserve existing runtime schema...
[20:14:09] Claude resumed
[20:17:32] UE build started
[20:19:11] Build PASS
[20:19:15] GPT final review started
[20:19:20] GPT: APPROVED
[20:19:21] Task COMPLETE
```

Never log:

```text
API keys
Tokens
Passwords
Connection strings
Secrets
```

---

# 25. Decision History

Maintain a local workspace decision history:

```text
.nexus-ai/history/
```

Example:

```json
{
  "timestamp": "...",
  "taskId": "...",
  "type": "ArchitectureDecision",
  "question": "...",
  "gptDecision": "...",
  "affectedFiles": []
}
```

Do NOT store chain-of-thought.

Store only:

```text
Question
Final decision
Short instruction
Result
```

---

# 26. Session State

Persist task state.

A VS Code restart should not destroy knowledge of:

```text
Active task
Project type
Current stage
Claude session identifier if resumable
Review count
Permission overrides
Last GPT decision
```

Create lifecycle stages:

```ts
enum TaskStage {
    Idle,
    Planning,
    Implementing,
    WaitingForGPT,
    WaitingForUser,
    Building,
    Testing,
    Reviewing,
    Fixing,
    Completed,
    Failed,
    Cancelled
}
```

---

# 27. Security

Security is mandatory.

Never send secrets to GPT or Claude.

Detect/restrict common files such as:

```text
.env
.env.*
secrets.json
credentials.json
*.pfx
*.pem
*.key
SSH keys
AWS credentials
cloud credentials
```

Reading these requires explicit user approval unless only metadata/existence is needed.

Never include their content in GPT context automatically.

---

# 28. Commands

Register:

```text
Nexus AI: Start Task
Nexus AI: Stop Task
Nexus AI: Pause Task
Nexus AI: Resume Task

Nexus AI: Select Project Type

Nexus AI: Connect GPT
Nexus AI: Connect Claude

Nexus AI: Open Dashboard
Nexus AI: Open Logs
Nexus AI: Open Decisions
Nexus AI: Open Permission Rules

Nexus AI: Initialize Project Context
Nexus AI: Run Final Review

Nexus AI: Clear Session
```

---

# 29. Initialize Project

`Nexus AI: Initialize Project Context`

creates:

```text
.nexus-ai/
├── config.json
├── PROJECT.md
├── ARCHITECTURE.md
├── DESIGN-PATTERNS.md
├── LOCKED-DECISIONS.md
├── SCHEMA.md
├── CODING-RULES.md
├── BUILD-RULES.md
│
├── prompts/
│   ├── architect.md
│   ├── decision.md
│   ├── final-review.md
│   └── claude-worker.md
│
└── history/
```

Do not overwrite existing files without confirmation.

---

# 30. Custom Prompts

All prompts must be editable.

Global default prompts are shipped with extension.

Workspace prompts override them.

Composition:

```text
SYSTEM DEFAULT
+
PROJECT CONTEXT
+
WORKSPACE CUSTOM PROMPT
+
CURRENT TASK CONTEXT
```

For final review:

```text
GPT_SYSTEM_REVIEW_PROMPT
+
PROJECT_ARCHITECTURE
+
CUSTOM_FINAL_REVIEW_PROMPT
+
ORIGINAL_TASK
+
CLAUDE_RESULT
+
DIFF
+
BUILD/TEST_RESULTS
```

---

# 31. GPT Context Optimization

Keep GPT fast.

Do NOT repeatedly send massive context.

Use:

```text
Relevant architecture files
Relevant design rules
Relevant source snippets
Claude's question
Current diff
Build error
```

Avoid unrelated project data.

For Claude architectural questions, GPT output should usually be approximately:

```text
2-8 lines
```

The purpose of GPT is accurate decision-making, not conversational output.

---

# 32. Failure Handling

GPT unavailable:

```text
Retry using configurable retry policy.

If still unavailable:
Pause only the decision-dependent action.
Notify user.
Do not guess architecture-changing decisions.
```

Claude unavailable:

```text
Preserve state.
Notify user.
Allow Resume.
```

Build failure:

```text
Return compiler/build error to Claude first.
Claude attempts normal fixes.

Only escalate to GPT if:
- architectural
- ambiguous
- repeated failure
- schema/design concern
```

---

# 33. Do Not Overuse GPT

Claude may independently handle:

```text
Compiler fixes
Missing include
Syntax errors
Local naming
Formatting
Straightforward implementation
Simple refactoring
Normal test fixes
```

GPT should handle:

```text
Architecture
Design patterns
Schema
Important tradeoffs
Uncertainty
Breaking changes
Final review
```

---

# 34. Human Should Be Last Escalation

Desired priority:

```text
Can Claude solve safely?
    ↓ yes
Claude solves

Otherwise:

Can GPT make the project decision safely?
    ↓ yes
GPT decides

Otherwise:

Ask User
```

The goal is maximum safe autonomy without constant user interruptions.

---

# 35. Extension Architecture

Use clean separated services.

Suggested structure:

```text
src/
├── extension.ts
│
├── ui/
│   ├── NexusDashboardProvider.ts
│   ├── StatusBarController.ts
│   ├── NotificationService.ts
│   └── ApprovalDialog.ts
│
├── supervisor/
│   ├── NexusSupervisor.ts
│   ├── TaskRunner.ts
│   ├── TaskStateMachine.ts
│   └── SessionManager.ts
│
├── agents/
│   ├── claude/
│   │   ├── ClaudeAgentClient.ts
│   │   ├── ClaudeEventRouter.ts
│   │   └── ClaudeResultCollector.ts
│   │
│   └── gpt/
│       ├── GPTClient.ts
│       ├── GPTArchitect.ts
│       ├── GPTDecisionService.ts
│       └── GPTReviewService.ts
│
├── permissions/
│   ├── PermissionEngine.ts
│   ├── RiskClassifier.ts
│   ├── PermissionRule.ts
│   └── profiles/
│       ├── DotNetProfile.ts
│       ├── NextJsProfile.ts
│       ├── UnrealEditorProfile.ts
│       └── UnrealGameProfile.ts
│
├── projects/
│   ├── ProjectDetector.ts
│   ├── ProjectAdapter.ts
│   ├── DotNetProjectAdapter.ts
│   ├── NextJsProjectAdapter.ts
│   ├── UnrealEditorProjectAdapter.ts
│   └── UnrealGameProjectAdapter.ts
│
├── context/
│   ├── ProjectContextLoader.ts
│   ├── PromptComposer.ts
│   └── ContextFilter.ts
│
├── security/
│   ├── SecretService.ts
│   └── SensitiveFileFilter.ts
│
└── logging/
    ├── NexusLogger.ts
    └── DecisionHistory.ts
```

Do not make one huge `extension.ts`.

Use interfaces and dependency injection where useful.

Keep core supervisor logic independent from VS Code UI as much as practical so it can be unit tested.

---

# 36. Important Agent Flow

Implement this as the central state machine:

```text
START TASK

↓
Load Project Profile

↓
Load Architecture Context

↓
Send task to GPT Architect if planning is needed

↓
Send concise GPT instruction + task to Claude

↓
CLAUDE WORKING
    │
    ├── safe tool request
    │       → AUTO ALLOW
    │
    ├── architectural question
    │       → GPT
    │       → short answer
    │       → Claude continues
    │
    ├── destructive request
    │       → User
    │
    ├── normal compiler error
    │       → Claude fixes
    │
    └── completion
            ↓
        Collect Result
            ↓
        Build
            ↓
        Test
            ↓
        GPT Final Review
            ↓
       ┌─────────────┐
       │             │
    APPROVED        FIX
       │             │
       │             ↓
       │          Claude
       │             ↓
       │          Build/Test
       │             ↓
       │          GPT Review
       │
       ↓
    COMPLETE
```

---

# 37. First Version Scope

Build a working V1 first.

V1 MUST contain:

```text
✓ VS Code extension
✓ Nexus AI Activity Bar view
✓ Project-type dropdown
✓ Four permission profiles
✓ Claude Agent integration
✓ GPT integration
✓ SecretStorage
✓ Claude permission interception
✓ Claude architecture-question → GPT routing
✓ Short GPT response
✓ Claude completion capture
✓ Git diff collection
✓ Build/test integration
✓ GPT final review
✓ Automatic FIX loop
✓ VS Code Info/Warning/Error notifications
✓ Output Channel
✓ Status bar
✓ Workspace custom prompts
✓ Permission configuration
✓ Unit tests for permission/risk logic
```

Do not add unnecessary unrelated features before V1 works.

---

# 38. Verification

Create tests for at least:

```text
Project type detection

.NET permission profile
Next.js permission profile
UE Editor permission profile
UE Game permission profile

Safe read → AUTO ALLOW

Normal source edit → AUTO ALLOW

Architecture change → ASK GPT

Git push → ASK USER

Delete Source → DENY/ASK USER

Secret file → protected

Claude architecture question → GPT

GPT short decision → Claude

Claude completion → Final Review

GPT FIX → Claude retry

GPT APPROVED → Complete

Review-loop limit

Workspace permission override
```

---

# 39. Build and Deliver

After implementation:

1. Build the extension.
2. Run all tests.
3. Fix TypeScript/compiler errors.
4. Run extension development host if available.
5. Verify project dropdown.
6. Verify native VS Code notifications.
7. Verify permission routing.
8. Verify GPT call.
9. Verify Claude call.
10. Verify Claude → GPT → Claude loop.
11. Verify final GPT review.
12. Generate installable `.vsix` if packaging tooling is available.

Provide a final concise report:

```text
IMPLEMENTATION COMPLETE

Build: PASS/FAIL
Tests: X/X PASS
VSIX: path

Implemented:
- ...
- ...

Manual configuration required:
- OpenAI credential
- Claude authentication

Known limitations:
- ...
```

---

# 40. Important Development Rule

Do not stop implementation every time there are multiple technically valid choices.

For normal extension implementation decisions, inspect current official documentation, existing code, and choose the cleanest maintainable solution.

Only ask me if a decision is genuinely impossible to make safely without owner input.

The primary objective is a working V1, not only architecture documentation.

Start by inspecting the current workspace. If this is a new empty project, scaffold the VS Code extension and begin implementation.
