# Roadmap Decision — "Runtime Compilation & Export" Phases Resequenced to After Phase 85

Date: 2026-08-22
Category: others
Phase: 55, 59, 63, 68, 72 (deferred); 79, 80-85 (promoted ahead of them)

## Context

Phase 55's record (2026-08-12) escalated a genuine roadmap sequencing gap to the user
and deliberately did not resolve it unilaterally: five "Runtime Compilation & Export"
phases (55/59/63/68/72) each depend on Compilation-stage / Runtime Schema
infrastructure that is itself the scope of Phases 80-85 — phases numbered *after* them.

That decision sat open for ten days. In the meantime Phases 73/74/75 completed their
editor-side work with their export leg left undone for the same reason, and on
2026-08-22 Phase 63 became the third phase to stop at the identical wall. At that point
the missing Compilation stage was the sole blocker on eight phases and had become the
project's critical path rather than a side note.

## Problem / Goal

Choose between the two resolutions Phase 55 put to the user:

1. **Resequence** — defer 55/59/63/68/72 to after Phase 85, build the Runtime Schema
   once against a settled design.
2. **Early stub** — authorize a throwaway Compilation stage now, scoped to one object
   type, to get something end-to-end sooner at the cost of known rework.

## Findings

Evidence gathered on 2026-08-22 before putting the choice to the user (full detail in
`phase-63-blocked-same-as-phase-55.md`):

- Zero implementations of `FNexusRuntimeResult` / `FNexusRuntimeState` /
  `NexusRuntimeCompiler` / `FNexusRuntimeHighwayPoint` / `FNexusRuntimeActivationPoint`
  under `Source/`. The only textual hits anywhere are two comments saying the
  infrastructure does not exist yet.
- `Source/NexusFramework/` (the runtime module) is still a bare three-file stub.
- `10-v6-runtime-schema.md`'s `FNexusRuntimeResult` shape is marked *Drafted* — a
  proposal, not a settled schema. This was the decisive factor against the stub option:
  exporting five object types into a shape Phase 80 is still free to redefine generates
  rework rather than progress.
- Phase 79 ("Gizmo — Full Category Rollout Verification") is the next `Not started`
  phase with no Runtime-Compiler dependency, and the roadmap positions it as closing the
  gizmo stage *before* Runtime Schema work begins — so option 1 has a real, in-order
  next step rather than idle time.

## Changes

**User decision (2026-08-22): resequence.** Build order is now
**Phase 79 → Phases 80-85 → back-fill 55/59/63/68/72.**

- `project-specifications/phases/phase-55.md`, `phase-59.md`, `phase-63.md` — already
  `Blocked`; appended the dated resequence decision to their existing Status notes.
  Status value unchanged, prior notes left intact (append-only).
- `project-specifications/phases/phase-68.md`, `phase-72.md` — `## Status` changed
  `Not started` -> `Blocked`, each with the shared root-cause note plus the resequence
  decision. This is the change that makes the decision *operative*: left as
  `Not started`, the next `/TODO` invocation would have selected Phase 68 as the
  lowest-numbered unstarted phase and re-derived the same block a fourth time.
- `ai-change-audits/2026-08-12/others/phase-55-blocked-runtime-compiler-not-built-yet.md`
  — appended a `## Verification — 2026-08-22` section (append-only).
- `PHASE-STATUS.md` / `html-docs/js/phase-data.js` / `phase-tracker.html` regenerated.
- **No source code changed.**

## Verification

N/A — documentation and phase-status only, no code. Regeneration confirmed: all five
phases now render as `Blocked` in `PHASE-STATUS.md`, and Phase 79 is the lowest-numbered
`Not started` phase remaining.

## Result

The roadmap's execution order now matches its actual dependency graph. Five phases are
explicitly deferred rather than repeatedly rediscovered as blocked, and the next agent
picking up `/TODO` lands on Phase 79 — the correct next step under this decision.

## Important Notes

- **Phase numbers and file paths were deliberately NOT changed.** Renumbering would have
  been the literal reading of "resequence," but `AGENT-TODO-RULES.md` and
  `09-development-rules.md` both note that a phase's identity is a fixed numbered file
  path other docs cross-reference by relative link. Execution order changed; identity
  did not. Anyone reading the roadmap top-to-bottom should expect 55/59/63/68/72 to run
  last, out of numeric order.
- **`09-development-rules.md`'s "do not jump phases" rule now has an explicit,
  user-authorized exception** covering exactly these five phases. An agent proceeding
  from Phase 79 to Phase 80 is following the roadmap, not violating it. This is recorded
  here rather than in the rules file because it is a one-time decision about specific
  phases, not a change to the standing rule.
- **Future agents: do not pick up 55/59/63/68/72 via `/TODO` until Phase 85 is done.**
  They are deferred by decision, not merely stalled. Each phase file says so in its own
  Status note.
- When those five are eventually back-filled, Phases 73/74/75's incomplete export leg
  should be back-filled in the same pass — it is blocked by the identical gap and is
  easy to overlook because those three phases already read as `Ready for Review`.
- Phase 80's own file carries a 2026-08-10 note listing five *additional*
  `FNexusHighwayPoint` fields (`Description`, `bHasCrossWalk`, `bHasTrafficLight`,
  `CategoryMask`, `SubCategory`) that must also be exported when its
  `FNexusRuntimeHighwayPoint` is implemented. Read that note before starting Phase 80 —
  it is not in the phase's own Allowed list.
