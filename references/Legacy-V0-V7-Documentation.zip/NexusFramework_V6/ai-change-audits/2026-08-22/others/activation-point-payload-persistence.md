# Activation Point payload persistence — the keystone gap, resolved

Date: 2026-08-22
Category: others (architecture decision)
Phase: cross-cutting — flagged by Phase 46, re-reported as Phase 75's GAP 1, unblocks the
gizmo's real-point editing; does NOT unblock Phases 55/59/80–85 (see Result).

## Context

Chosen by the user immediately after Phases 73–78 were committed (`4947c94`), over starting
Phase 79 or Phase 80 directly — on the reasoning that Phase 80's Runtime Compiler would hit
this wall within its first hour and end up solving it mid-phase, less cleanly.

Not a roadmap phase. Tracked as `agent-todos/` work per `CLAUDE.md`'s split, with the
durable decision recorded here and in `project-specifications/12-v6-activation-point-system.md`.

## Problem

`UNexusConfigAsset::ActivationPoints` held **base-only** `FNexusActivationPoint` values with
nowhere to put a type's specialized payload. Its own doc comment had said since Phase 46
that the harder question — flat array? per-type arrays? `FInstancedStruct`? — was open.

Everything downstream traced back to it: every sub-pointed type (Traffic Light, Crosswalk,
Bus Stop, Seat, Parking, and Phase 75's five facilities) could only live in the session-only
test store; the gizmo's real-point loop was disabled; Phase 77's Diagnostics criterion was
only partly exercisable.

## Findings

- **`FInstancedStruct` is in `CoreUObject` as of UE 5.5** (`StructUtils/InstancedStruct.h`)
  — verified in the 5.8 install, not assumed. No new module or plugin dependency.
- **`StructUtilsEditor` is a built-in editor module** (`Source/Editor/StructUtilsEditor`)
  that registers `FInstancedStructDetails` for the `InstancedStruct` property type. So the
  Details panel gets a type picker plus inline payload properties with no work from us.
- **`TFieldIterator`/`FindPropertyByName` walk the super chain**, so the existing
  reflection-driven sub-point machinery would also work with a payload struct hierarchy if
  one is ever wanted. Checked, not assumed; not used yet.

## Decision

**`FInstancedStruct Payload` on `FNexusActivationPoint` itself.** Full option comparison in
`12-v6-activation-point-system.md`'s new "Payload persistence" section and in the task file.
Short version: per-type arrays were rejected for reintroducing the zero-edit-extensibility
failure the type registry exists to prevent; a hand-rolled byte blob was rejected for
re-implementing tagged serialization, reflection, Details editing and undo, worse. On the
point rather than a side table, so create/delete/undo stay atomic.

## Changes

**Storage**
- `FNexusActivationPoint::Payload` + `GetPayloadStructType/HasPayload/GetPayloadMemory/GetMutablePayloadMemory/InitializePayloadForType`.
- `UNexusConfigAsset::ActivationPoints`' doc comment updated — the open question it posed is
  answered in place rather than left to mislead.

**Unification (the proof it works)**
- `FNexusActivationPointTestStore` no longer owns payload memory at all: its side
  `TMap<FGuid, FPayloadEntry>` of hand-managed bytes, its destructor, and its manual
  `DestroyStruct` loop are gone, and every accessor forwards to the point's own field. Test
  data and real data now travel through **one identical mechanism**, so every renderer, the
  gizmo, and the resolver exercise the same path against both. All accessor signatures were
  kept, so no existing caller changed.

**Plumbing**
- `FNexusActivationSubPointResolver` point-only overloads (the explicit `void*` +
  `UScriptStruct*` versions kept — they are the honest signature for the reflection layer).
- **New `FNexusActivationPointLocator`** — answers "given an ActivationPointId, where does it
  live, and does editing it need a `FScopedTransaction` or an `FChange`?" in one place. The
  gizmo (hit test, remembered-selection restore, drag write-back, rebind), the undo record,
  and the Details tab all needed the same two-source lookup; four copies would have drifted,
  most dangerously on which undo mechanism an edit gets.
- **New `FNexusActivationPayloadReconciler`** — keeps `Payload` in step with `Type`, run from
  `UNexusConfigAsset::PostEditChangeProperty`. Idempotent, so it never destroys authored
  values; an **unregistered** Type deliberately leaves the payload alone (a Type from an
  unloaded module must not cost the user their data) and is reported by validation instead.

**Authoring**
- `FNexusMapping::CreateActivationPointAtHighwayPoint` takes an optional `type`, creating the
  payload in the same transaction so a point is never persisted typed-but-payloadless.
- The Hierarchy context menu's "Create Activation Point" is now a **submenu built from the
  live registry** — a new object type appears there with zero edits to the panel, and each
  entry's tooltip reports that type's sub-point shape.

**Gizmo (the reinstatement 13-v6-gizmo-system.md marked as pending)**
- `FindClosestSubPointHit` tests real config points again. Gating was factored into one
  `IsGizmoSelectable` so the two sources cannot disagree on what "selectable" means.
- A real point's **base** offset is still explicitly excluded — that stays the Editor Proxy
  Actor pool's job. Only specialized sub-points are this tool's, which is exactly the scope
  13-v6 defines.
- `ApplySubPointOffsetEdit` now branches on target kind: real → `FScopedTransaction` +
  `Modify()` (standard UObject undo, and what marks the asset dirty so the edit is saved);
  session-only → the Phase 77 `FChange`. **One place** writes that branch, and every edit
  path routes through it.

**Validation**
- `ValidateRepresentationStage` reports Type/Payload disagreement as a **Warning**, not
  Blocking — the likeliest cause is an unloaded module, which is recoverable and should not
  fail the gate for every other object in the level.

**Verification**
- `Nexus.Representation.DumpActivationPointPayloads` — Type, actual payload struct, resolved
  sub-point key count, and consistency per point. Designed for a round trip: note the
  numbers, save, restart, re-run.

## Verification

- `NexusFrameworkEditor` compiles clean (UE 5.8, Development, Win64) — built after each
  stage, final build `Result: Succeeded`.
- No automated tests written or run, per `project-specifications/AGENT-RULES.md`.

## Result

Implemented. **Not manually verified** — awaiting the user.

**Unblocked**: authored payloads persist; gizmo sub-point editing works on real config
points; Phase 75's GAP 1 is closed.

**NOT unblocked, and worth being exact about**: the Runtime Compiler. Phases 55/59 stay
`Blocked` and the export leg of Phases 73/74/75 stays incomplete, because no Compilation
stage or `FNexusRuntimeResult` exists — Phases 80–85's own scope, always a separate wall
from this one. Persistence was the prerequisite; the compiler is still the work.

## Manual verification the user should do

1. **Round trip (the one that matters).** Right-click a HighwayPoint → *Create Activation
   Point* → pick `TrafficLight`. Run `Nexus.Representation.DumpActivationPointPayloads` and
   note Type / payload struct / sub-point count. Save, restart the editor, re-run. The
   numbers must be identical.
2. **Details panel** — select that point in the Hierarchy tree. The `Payload` row should show
   a type picker with `FNexusTrafficLightActivation` and its Pole/VehicleLED/PedestrianLED
   fields inline.
3. **Gizmo on a real point** — with the point's Debug category visible, click its VehicleLED
   sub-point in Select Mode and drag. Then Ctrl+Z: it should undo, and the asset should be
   marked dirty by the edit (not by the undo).
4. **Base offset stays with the proxy actor** — clicking the real point's *base* marker
   should NOT bind this gizmo. That exclusion is deliberate.
5. **Reconciliation** — change that point's `Type` to `Parking` in the Details panel. The
   payload should switch to `FNexusParkingActivation`. Set Type to something nonsense like
   `NotARealType`: the payload should be **left alone**, and the Diagnostics tab should show
   a Warning naming it.
6. **Array sub-points on a real point** — create a `PetrolStation`, add 4 `FuelPumpPoints`
   entries in the Details panel, drag element `[1]`, and confirm `[0]`/`[2]`/`[3]` and the
   anchor do not move.

## Important Notes

- The riskiest single change is the gizmo real-point loop reinstatement; if real points
  behave oddly in the viewport, `FindClosestSubPointHit`'s new config loop is the place to
  look.
- Adding a `UPROPERTY` is additive, so existing saved `.uasset` content loads fine with an
  empty payload and is then reconciled on first edit. No existing property was renamed —
  `v6-coding-standard.md`'s serialization-risk rule respected.
- Related: [[phase-75-onboarding-checklist-proof-five-types]] (GAP 1's original report),
  [[phase-77-gizmo-undo-redo-hardening]] (the undo mechanism this extends).
