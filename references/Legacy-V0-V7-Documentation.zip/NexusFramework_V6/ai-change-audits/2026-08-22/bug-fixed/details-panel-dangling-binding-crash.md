# Details panel dangling-binding crash — three fixes, and the rule that came out of it

Date: 2026-08-22
Category: bug-fixed
Phase: N/A (crosses Phase 26a / 76 / 78 and the 2026-08-22 payload-persistence work)

The live task record is `agent-todos/ready-for-review/details-panel-dangling-binding-
crash-on-entity-add-remove.md` — the full crash reports, callstacks and repro steps live
there. This record exists because the *conclusion* is durable architecture knowledge that
outlives the task file's own workflow lifetime.

## Context

`SNexusDetailsPanel` binds an `IStructureDetailsView` (via `FStructOnScope`) directly to
`&UNexusConfigAsset::<Array>[i]` — a raw pointer into a `TArray` the config asset owns.
That binding was refreshed on exactly two events: `OnPostEditUndo` and
`OnDetailsTargetChanged`.

## Problem

Adding or removing an entity fires neither. The array reallocates, the bound pointer is
freed memory, and Slate reads it on the next tick. `RemoveAt` is the quieter, worse case:
the pointer usually stays valid and silently addresses a **different** entity.

## Findings

Three fixes were attempted. The first two are the valuable part of this record.

1. **Detect from `Tick`, rebind inline.** Crashed at `0x30` in `FDetailItemNode::Tick`.
2. **Detect from `Tick`, rebind from a one-shot `RegisterActiveTimer`.** Crashed at
   `0x00`, same line. The reasoning behind it — "an active timer runs in
   `FSlateApplication::TickAndDrawWidgets` before `DrawWindows`, i.e. outside paint" — is
   **wrong**, and this is the finding worth keeping:

   ```cpp
   // Engine/Source/Runtime/SlateCore/Private/Widgets/SWidget.cpp, SWidget::Paint
   if (HasAnyUpdateFlags(EWidgetUpdateFlags::NeedsActiveTimerUpdate))
   {
       MutableThis->ExecuteActiveTimers(Args.GetCurrentTime(), Args.GetDeltaTime());  // :1502
   }
   if (HasAnyUpdateFlags(EWidgetUpdateFlags::NeedsTick))
   {
       MutableThis->Tick(DesktopSpaceGeometry, ...);                                  // :1511
   }
   ```

   **`SWidget::Paint` executes active timers nine lines before it calls `Tick`.** A
   widget's active timer is *inside* the paint pass, not outside it. Deferring paint-unsafe
   work to `RegisterActiveTimer` does not make it safe — it moves it nine lines earlier in
   the same function.

3. **Broadcast from the mutation** (`UNexusConfigAsset::OnStructuralChange`). Correct: a
   mutation always originates from input handling, a console command, or a menu action, so
   the notification cannot land inside paint. Verified for this codebase — every one of the
   14 mutation sites is reachable only from an `SNexusHierarchyPanel` button/menu handler,
   a console command, or `FNexusLandscapeModeExtension::OnEditorModeIDChanged`.

## Result — the durable rules

1. **Nothing reachable from a widget's own paint may swap that widget's bound data.**
   `SetStructureData`, `RequestTreeRefresh` and friends are safe from event callbacks
   (selection changed, undo, a mutation notification) and unsafe from `Tick` **and** from
   an active timer, because both run inside `SWidget::Paint`.
2. **A container whose elements are bound by raw pointer must announce its own structural
   changes.** The detect-it-yourself alternative is not available: the only place a
   subscriber could cheaply detect it is a tick, and a tick is inside paint. This applies
   to `UNexusConfigAsset`'s five arrays and to `FNexusActivationPointTestStore::Points`.
3. **A per-element broadcast needs a batch scope.** `UNexusConfigAsset::
   FScopedStructuralChangeBatch` coalesces a bulk mutation into one notification;
   `MapControlPoints`/`MapHighways`/`ReconcileMappingStage`/`RunAutomaticEnableFlow` each
   open one. Without it, entering Landscape Mode rebuilds the details view once per mapped
   control point — the same unthrottled-per-element editor work behind the 2026-08-10 and
   2026-08-11 freeze records. The batch is only safe because no Nexus bulk mutation pumps
   Slate; introducing an `FScopedSlowTask` inside one would reopen the original crash.

## Important Notes

Known class, fourth occurrence — `2026-08-10/bug-fixed/debug-details-panel-dangling-
pointer-crash.md` (a `TMap` growth), Phase 26a's V5 `PostEditUndo` variant, and
`NexusPanelSharedTypes.h`'s own note that `FNexusGizmoSubPointSelection` carries a KEY and
never a resolved pointer, are all the same lesson arriving from different directions.
