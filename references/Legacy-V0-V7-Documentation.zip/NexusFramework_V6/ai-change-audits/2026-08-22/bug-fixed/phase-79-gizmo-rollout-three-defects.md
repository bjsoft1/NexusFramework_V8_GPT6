# Phase 79 — Gizmo Rollout Verification: Three Sub-Point Addressing Defects

Date: 2026-08-22
Category: bug-fixed
Phase: 79

## Context

Phase 79 ("Gizmo — Full Category Rollout Verification") picked up via `/TODO`, immediately
after Phase 63 was recorded `Blocked` and the user resequenced the five "Runtime
Compilation & Export" phases to after Phase 85 (see
`../others/runtime-compilation-phases-resequenced-after-85.md`). Phase 79 became the
lowest `Not started` phase as a direct result of that decision.

Phase 79 is mostly a manual, in-editor verification phase, which AGENT-RULES.md's Agent
Testing Policy forbids an agent from automating. The agent-side work was therefore: build
the enumeration, statically audit the sub-point addressing path where an
element-independence bug would actually live, fix what that turned up, and write the
manual matrix down for the user.

## Problem / Goal

Verify every gizmo-enabled Debug category works end-to-end across the full object-type
set, with a distinct, separately-tested requirement that editing array element `i` never
disturbs element `i-1`, `i+1`, or the shared anchor.

## Findings

**The enumeration itself was the first surprise.** `CanSupportGizmo = true` is set in
exactly ONE place in the codebase — the `Runtime.ActivationPoints` category. All 14
registered Activation Point types gate their selection/gizmo on that single category, so
"full category rollout" is one category x 14 types x 3 sub-point shapes, not N gizmo
implementations. That is by design (13-v6-gizmo-system.md mandates one generic
mechanism), and Phase 76's `Nexus.Gizmo.AuditTypeConsistency` already reports it at
runtime.

Three real defects were found by static audit:

1. **Real, persisted Activation Points rendered base-only.** `RenderActivationPoints`
   passed the point's own payload for the test-store loop but `nullptr` for the
   real-config loop. `EnumerateResolvedSubPoints` treats a null instance as "no payload"
   and falls back to the single synthetic base key, so every authored sub-point on every
   real Crosswalk/TrafficLight/BusStop was silently not drawn.
   **This was a regression introduced by this same week's payload-persistence work**: that
   change moved the payload onto `FNexusActivationPoint` and updated the GIZMO's
   `FindClosestSubPointHit` to read it there, but left this RENDERER on the old
   pass-it-in path. Net effect: real points became hit-testable but invisible — the exact
   inverse of the "clickable must never diverge from visible" invariant that
   `UNexusActivationGizmoTool::IsGizmoSelectable` states in its own comment.

2. **Both dummy types were silently non-selectable.** `Dummy.BaseOnly` and `Dummy.Array`
   declared `DefaultDebugCategory = "Runtime.Dummy"` — a category id that appears nowhere
   else in the codebase and is never registered. `GetRuntimeConfig()` returned null, so
   `IsGizmoSelectable` rejected both outright. This silently disabled `Dummy.Array`, whose
   entire stated purpose is "proving Gizmo array sub-point selection/drag". Because
   `RenderActivationPoints` iterates every test-store point regardless of type, they were
   still DRAWN under `Runtime.ActivationPoints` — visible but unclickable, the same
   invariant broken in the same direction as (1).

3. **Array element type was never validated before `reinterpret_cast`.**
   `ResolveSubPointOffsetPtr`'s fixed-field branch verifies `structProperty->Struct ==
   FNexusSubPointOffset::StaticStruct()`; the array branch cast
   `arrayHelper.GetRawPtr(index)` to `FNexusSubPointOffset*` with no equivalent check. A
   key naming a `TArray` of any other element type would stride by the wrong element size
   and reinterpret unrelated memory — on the write path, corrupting neighbouring elements,
   which is exactly the invariant this phase exists to hold.
   `NexusBusStopActivation.h`'s Phase 66 decision comment had already identified this as a
   known sharp edge and chose to constrain every payload to `TArray<FNexusSubPointOffset>`
   rather than generalise the resolver — but that constraint was only enforced where keys
   are BUILT (`EnumerateDeclaredSubPointFields` filters by inner type), never where they
   are CONSUMED.

**Verified correct (no change needed):**

- Element independence holds by construction — one key resolves to exactly one
  `FNexusSubPointOffset`, and `SetSubPointOffset` writes through that single pointer.
- `HandleGizmoTransformChanged` only READS the anchor transform, never writes it —
  satisfying the "no gizmo edit may write Landscape transforms" Not-Allowed rule.
- `FNexusGizmoSubPointSelection` carries the key, never a resolved pointer, so an array
  resize cannot dangle it.

## Changes

- `Private/Debug/NexusDebugRuntimeGroupRenderers.cpp` — `DrawOneActivationPoint`'s
  `payloadInstance` parameter REMOVED and both call sites updated; the function now
  resolves through the point-only `EnumerateResolvedSubPoints` overload the gizmo already
  uses. Removing the parameter (rather than just passing the right value at the real-point
  call site) is deliberate: it makes renderer and gizmo structurally incapable of
  disagreeing about where the payload lives.
- `Private/Representation/NexusActivationDummyTypesRegistration.cpp` — both dummy types'
  `DefaultDebugCategory` changed `"Runtime.Dummy"` -> `"Runtime.ActivationPoints"`.
  Registering a real `Runtime.Dummy` category would NOT have fixed it: visibility would
  still be governed by `Runtime.ActivationPoints` (whose renderer ignores type) while
  selection gated on the new category — the same divergence, relocated.
- `Private/Representation/NexusActivationSubPointResolver.cpp` — array branch now verifies
  `arrayProperty->Inner` is an `FStructProperty` of `FNexusSubPointOffset` before the cast.
- `Public/UI/NexusPanelSharedTypes.h` — corrected a comment claiming
  `FNexusGizmoSubPointSelection::ActivationPointId` is always a test-store point; real
  config points became selectable on 2026-08-22.
- `project-specifications/phases/phase-79.md` — enumeration table, defect list,
  static-audit results, and the manual verification matrix; `## Status` ->
  `Ready for Review`.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development` (UE 5.8) — **Succeeded**, run twice
  (after the resolver fix, and again after the renderer + dummy-category fixes).
- **No automated test written or run; the editor was NOT launched** (AGENT-RULES.md Agent
  Testing Policy). None of the three fixes is confirmed working in-editor — only that the
  code builds and the reasoning is sound.

## Result

`Ready for Review`. Phase 79's single Completion Criterion ("100% pass rate across every
gizmo-enabled category") is deliberately left UNCHECKED — it requires manual in-editor
runs that an agent may not perform.

## Important Notes

- **Defect (1) would have made a manual Phase 79 pass fail outright**, and is the reason
  running this phase before Phase 80 was worthwhile rather than a formality. It also means
  any earlier manual verification of real (non-test) Activation Point sub-points was
  testing something that could not have worked.
- **The fastest confirmation for the user** is to create a real, persisted Crosswalk and
  check that `StartPoint`/`EndPoint`/`PedestrianWaitingPoints` all draw. Before this fix
  only a single base marker appeared.
- **Standing lesson**: the payload-persistence change updated one of two consumers of the
  same data. When a struct's storage location moves, grep for EVERY reader — here the
  renderer and the gizmo had to agree, and a silent disagreement produced a
  visible-vs-clickable split in both directions at once.
- 13-v6-gizmo-system.md names Crosswalk's array `WaitingPoints[]`; the implemented field is
  `PedestrianWaitingPoints`. Doc/code drift, deliberately NOT renamed — renaming a
  `UPROPERTY` risks corrupting saved `.uasset` content (v6-coding-standard.md).
- The five "Runtime Compilation & Export" phases remain `Blocked`/deferred; Phase 80
  ("Runtime Compiler — HighwayPoint Export") is the next phase under the resequence
  decision. Read Phase 80's own 2026-08-10 note first — it lists five extra
  `FNexusHighwayPoint` fields that must be exported and are not in its Allowed list.
