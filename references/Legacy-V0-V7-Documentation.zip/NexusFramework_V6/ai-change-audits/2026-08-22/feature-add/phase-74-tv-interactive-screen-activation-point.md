# Phase 74 — TV / Interactive Screen Activation Point

Date: 2026-08-22
Category: feature-add
Phase: 74

## Context

Second of the 2026-08-22 six-phase batch (73, 74, 75, 76, 77, 78). Follows Phase 73's
Advertisement type directly — both are base-offset-only panel types, so this phase is also
the first real measurement of whether the second such type costs less than the first.

## Problem / Goal

Implement the TV/NewsTv activation type through the generalized registry instead of V5's
closed `ENexusDynamicInteractableType` enum, and confirm in writing that all four of V5's
original enum values are now representable.

## Findings

- V5's enum had exactly four values: `TrafficLight`, `HighwayLight`, `NewsTv`, `AdsBoard`.
  Their V6 registry counterparts are `TrafficLight`, `CityLight`, `Tv`, `Advertisement` —
  the last two only existing as of Phases 73/74. This phase therefore closes V5 feature
  parity for this subsystem.
- **"Activation distance override" needs no payload field.**
  `FNexusActivationPoint::ActivationDistance` has been exactly that since Phase 21
  (`-1` = global default, `>0` = per-instance override, this codebase's standing
  convention). Re-declaring it on the TV payload would store the same authored number
  twice with no rule for which wins — the duplicate-data shape Phase 93's own
  "Memory/Duplicate-Data Audit" exists to catch. Implemented as a *resolution helper*
  against the base field instead, so the override genuinely works rather than merely being
  re-declared. Recorded explicitly, in the same spirit as
  `FNexusParkingActivation`'s `AllowVehicles`→`Metadata` note.
- `ENexusStaticObjectType` had no TV rows. Added them, per that enum's own documented
  growth protocol ("a new object type gets a new value here AND a new
  `ResolveClassification` case in the same change"). Verified by grep first that nothing
  anywhere declares this enum as a `UPROPERTY` or persists its integer value, so inserting
  the pair next to the Advertisement rows (rather than appending) cannot corrupt saved
  `.uasset` content — the specific risk `v6-coding-standard.md`'s serialization-risk
  section warns about.

## Changes

- **New** `Public/Representation/NexusTvActivation.h` — `FNexusTvActivation` with
  `ContentReference` (`TSoftObjectPtr<UObject>`, typed loosely on purpose to avoid adding a
  `MediaAssets` module dependency to the Editor module for a reference it never
  dereferences) and `ChannelId` (`FName`, V5's NewsTv "which channel"), plus `HasContent()`
  and `ResolveActivationDistance()`.
- **New** `Private/Representation/NexusTvActivation.cpp` — the one out-of-line member,
  split out purely to keep `NexusActivationPoint.h` out of the header.
- **New** `Private/Representation/NexusTvActivationRegistration.cpp` — registers type key
  `"Tv"`; `Nexus.Representation.AddTestTv`; and
  `Nexus.Representation.VerifyV5InteractableCoverage`, which checks the V5→V6
  correspondence table against the LIVE registry rather than asserting it in prose, so a
  future rename reports a real gap instead of leaving a convincingly-wrong doc line.
- **Edited** `Public/Generation/NexusGenerationObjectType.h` — added `TvScreenMesh` and
  `TvInteractiveContent`.
- **Edited** `Private/Generation/NexusGenerationClassificationTable.cpp` — the matching
  `ResolveClassification` cases (`Static` / `RuntimeActivated`) and `GetFullTable` rows;
  also corrected a now-stale "only 0-15 are defined" comment to 0-17.
- **Edited** `Private/Debug/NexusDebugInfrastructureGroupRenderers.cpp` — two more leaves,
  `Infrastructure.TvScreen` (Static housing + mount arm) and `Infrastructure.TvContent`
  (violet lit screen; its label additionally reports the RESOLVED activation distance,
  which is what keeps the "override lives on the base struct" decision observable rather
  than merely documented).

## Verification

- `NexusFrameworkEditor` compiles clean (UE 5.8, Development, Win64), 2026-08-22.
- No automated tests written or run, per `project-specifications/AGENT-RULES.md`.

## Result

Implemented. Awaiting the user's manual editor verification.

## Manual verification the user should do

1. `Nexus.Representation.VerifyV5InteractableCoverage` — expect all four V5 values
   `REGISTERED`, `4/4 covered`, and a list of the further types the closed enum could never
   have expressed.
2. `Nexus.Generation.DumpClassificationTable` — expect 18 rows, including
   `TvScreenMesh -> Static` and `TvInteractiveContent -> RuntimeActivated`.
3. `Nexus.Representation.AddTestTv <HighwayPointId> News.Default 1500`, then enable
   **TV Screen** / **TV Content** under Infrastructure — expect a grey 16:9 housing with a
   mount arm to the anchor, a violet content panel inside it, and a label reading
   `... (activates at 1500)`.
4. Re-run with no distance argument on a second point and confirm the label reads
   `activates at 1200` (the command's own default), then set `ActivationDistance` to `-1`
   in the Details panel and confirm it falls back to the 800 stand-in.

## Onboarding-cost observation (feeds Phase 75)

Adding TV after Advertisement cost: one payload header, one tiny `.cpp`, one registration
file, two renderer functions, and two `ENexusStaticObjectType` rows. The two renderer
functions reused Phase 73's `FindBaseSubPoint`/`DrawPanelOutline` unchanged — no new shared
machinery of any kind. This is the datapoint Phase 75 then measured properly across five
more types.

## Important Notes

- **Export not done**, same as [[phase-73-advertisement-activation-point]]: no Compilation
  stage exists (Phases 80–85 own it; Phases 55/59 are `Blocked` on the same wall). The
  register/visualize/edit legs are complete; export is not, and is recorded as such rather
  than counted.
- See [[phase-75-onboarding-checklist-proof-five-types]] for the batch's third phase.
