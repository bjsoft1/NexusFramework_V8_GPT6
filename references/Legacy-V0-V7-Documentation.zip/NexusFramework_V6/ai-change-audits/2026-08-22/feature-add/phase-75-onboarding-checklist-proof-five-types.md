# Phase 75 — Future Object Types — Onboarding Checklist Proof (all five types)

Date: 2026-08-22
Category: feature-add
Phase: 75

## Context

Third of the 2026-08-22 six-phase batch. This is the phase `v6-phase-verification.md`
Section C item 2 flagged as `⚠️ PARTIAL` — its original scope proved the onboarding pattern
against *one* type, leaving Hospital / Police Station / Petrol Station / Charging Station /
Service Garage unbuilt at the end of the roadmap. The phase file was already broadened
(per that verification doc's own recommendation (a)) to require **all five**. This entry
records executing that broadened scope.

## Problem / Goal

Add every remaining named-but-unbuilt object type using ONLY Phase 45's documented
three-step onboarding checklist, with **zero framework-file edits**; record per-type
onboarding cost; and report — not route around — any framework gap found.

## Findings

### The checklist held. All five, flat cost.

Phase 45's checklist is: (1) payload `USTRUCT`, (2) one `FNexusActivationTypeAutoRegister`,
(3) nothing else. All five types onboarded in exactly those two authored steps. **Step count
did not grow from the first type to the fifth**, and no framework file was edited.

Two results came out *better* than the checklist promises:

- **The test-placement path needed no per-type code either.** One generic console command
  (`Nexus.Representation.AddTestServiceFacility`) places any registered type by discovering
  its payload struct and declared sub-point fields through the registry plus property
  reflection — including resizing dynamic-array sub-point fields and seeding each element.
  It would place a type added tomorrow, unchanged.
- **The debug renderer needed no per-type code either.** One generic renderer body
  (`RenderServiceFacility`) is bound five times with a different type key and accent color.
  The fifth facility's entire debug cost was one registration line.

### Inheritance works with the reflection walk (checked, not assumed)

`EnumerateDeclaredSubPointFields` uses `TFieldIterator<FProperty>` (which includes super
fields by default) and `EnumerateSubPointKeysForInstance`/`ResolveSubPointOffsetPtr` use
`UStruct::FindPropertyByName` (which walks the super chain). A future payload family CAN
therefore share a `USTRUCT` base without the resolver losing sub-points. Not used here on
purpose — see below — but worth knowing it is available.

### Why five independent structs rather than one shared base

A shared base would have made types 2–5 cheaper than a genuinely new type would be,
understating the exact number this phase exists to measure. The repeated `EntrancePoint`
declaration across five structs is that honesty's price.

## Framework gaps found (reported, NOT routed around)

These are the phase's most valuable output. None were worked around by editing framework
code, per the phase's own rule. All three are also emitted by
`Nexus.Representation.DumpOnboardingBenchmark` so they stay re-checkable.

**GAP 1 — specialized-payload persistence is still unresolved (pre-existing, confirmed).**
`UNexusConfigAsset::ActivationPoints` holds base-only `FNexusActivationPoint` values with no
payload storage; its own doc comment has flagged this as open since Phase 46 ("flat array?
per-type arrays? `FInstancedStruct`-based heterogeneous storage?"). Consequence: **any type
declaring sub-point fields can only live in the session-only test store** — that is all five
of this phase's types, and Traffic Light / Crosswalk / Bus Stop before them. The *export*
leg of "register/visualize/edit/export" therefore cannot complete for any sub-pointed type
yet. Owner: the Phase 80–85 Runtime Compiler arc, plus an explicit persistence decision.
This is the same root wall Phases 55/59 are `Blocked` on, seen from the authoring side.

**GAP 2 — the Generation-side classification is a closed enum plus a hand-written switch
(new).** `ENexusStaticObjectType` + `FNexusGenerationClassificationTable::ResolveClassification`
require edits to **two framework files** to classify the paired `Static` half of any new
object type (a hospital building, a fuel pump, a charger). This is precisely the closed-enum
pattern the Activation Point layer deliberately rejected
(`12-v6-activation-point-system.md`'s "Type registry, not a closed enum"), still present one
layer down. Not edited during this phase, by rule — so the five facilities' Static halves
are currently unclassifiable. Suggested owner/fix: a registry-backed classification lookup
mirroring `FNexusActivationTypeRegistry`. Phase 74 hit the same wall one phase earlier and
*was* allowed to edit it (adding the TV pair), which is what makes the cost visible: every
new object type pays a two-framework-file edit on the Generation side that it does not pay
on the Activation Point side.

**GAP 3 — no shared debug-leaf factory (new, minor).** `MakeInfrastructureLeaf` is file-local
to `NexusDebugInfrastructureGroupRenderers.cpp`'s anonymous namespace, so a NEW renderer
file must re-declare an equivalent. Left duplicated on purpose — promoting a shared factory
would be a framework edit. Suggested owner/fix: a shared leaf factory next to
`FNexusDebugCategoryRegistry`.

## Changes

- **New** `Public/Representation/NexusServiceFacilityActivations.h` — five payload structs:
  `FNexusHospitalActivation` (EntrancePoint, EmergencyEntrancePoint, AmbulanceBayPoints[],
  BedCapacity, HasEmergencyDepartment), `FNexusPoliceStationActivation` (EntrancePoint,
  PatrolVehicleBayPoints[], CanDispatchPatrols), `FNexusPetrolStationActivation`
  (EntrancePoint, ExitPoint, FuelPumpPoints[], FuelTypes), `FNexusChargingStationActivation`
  (EntrancePoint, ExitPoint, ChargingBayPoints[], ConnectorTypes, MaxPowerKw),
  `FNexusServiceGarageActivation` (EntrancePoint, ExitPoint, ServiceBayPoints[],
  OfferedServices).
- **New** `Private/Representation/NexusServiceFacilityActivationsRegistration.cpp` — the five
  registrations, `Nexus.Representation.AddTestServiceFacility`, and
  `Nexus.Representation.DumpOnboardingBenchmark`.
- **New** `Private/Debug/NexusDebugInfrastructureGroupRenderers.Services.cpp` — five
  Infrastructure leaves off one generic renderer. A new file rather than an edit: partly the
  zero-edit rule, partly `09-development-rules.md`'s `.cpp`-splitting rule (the
  Infrastructure renderer file passed 1000 lines at Phase 74, and Services/Facilities is a
  distinct object CATEGORY per `v6-master-architecture.md` Section 3). The shared
  `NexusDebugInfrastructureGroupRenderers.` filename prefix keeps the "one file per GROUP"
  precedent visible.

**Framework files edited: zero.**

## Side effect worth noting

All five declare real sub-points (every facility needs an entrance —
`v6-master-architecture.md` Section 12's own required query "Where is the hospital
entrance?"), and four of five declare dynamic arrays. That widens Phase 79's
array-sub-point test coverage from two types (Crosswalk, Bus Stop) to six.

## Verification

- `NexusFrameworkEditor` compiles clean (UE 5.8, Development, Win64), 2026-08-22.
- No automated tests written or run, per `project-specifications/AGENT-RULES.md`.

## Result

Implemented — all five types, zero framework edits, three gaps reported.
Awaiting the user's manual editor verification.

## Manual verification the user should do

1. `Nexus.Representation.DumpOnboardingBenchmark` — expect `5/5 types onboarded`, each
   `REGISTERED - 2 checklist steps, 0 framework files edited`, then the three gaps.
2. `Nexus.Representation.AddTestServiceFacility PetrolStation <HighwayPointId> 4 1 FuelTypes=Petrol,Diesel,LPG`
   — expect `2 fixed + 1 array` declared fields and `6 sub-point keys` resolving
   (EntrancePoint, ExitPoint, FuelPumpPoints[0..3]).
3. Enable **Petrol Station** under Infrastructure — expect a yellow site sphere at the
   anchor, a green entrance sphere with an arrow out to it, an orange-red exit sphere with
   an arrow back, and four yellow bay boxes behind the anchor.
4. Repeat for `Hospital` (with `BedCapacity=400`), `PoliceStation`, `ChargingStation`
   (`MaxPowerKw=150 ConnectorTypes=CCS,Type2`), `ServiceGarage`.
5. **Array-sub-point independence** (this is the check that matters most, and the one
   Phase 79 will formally re-run): with a 4-bay facility, select bay `[1]` in Select Mode
   and drag it. Bays `[0]`, `[2]`, `[3]`, both fixed points, and the anchor must all stay
   put.

## Important Notes

- The user should decide what to do about **GAP 2**. It is the one gap that will be paid
  again by every future object type, and it is cheap to fix now (a registry mirroring one
  that already exists) versus after the Generation pipeline has more callers.
- **GAP 1** is the reason the "export" leg of Phases 73/74/75 is incomplete —
  see [[phase-73-advertisement-activation-point]] and
  [[phase-74-tv-interactive-screen-activation-point]].
