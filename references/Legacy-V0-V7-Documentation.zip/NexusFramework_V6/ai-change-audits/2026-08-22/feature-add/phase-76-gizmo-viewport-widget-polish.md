# Phase 76 — Gizmo — Viewport Widget Polish

Date: 2026-08-22
Category: feature-add
Phase: 76

## Context

Fourth of the 2026-08-22 six-phase batch (73, 74, 75, 76, 77, 78) — the first of the three
UI/gizmo polish phases the user actually asked for; 73–75 were taken first because Phase 76's
own audit scope is defined as "across all object types built so far (50–75)".

## Problem / Goal

Polish gizmo viewport integration across every object type: consistent widget behaviour,
optional grid/rotation snapping, and numeric precision entry as an alternative to drag.

## Findings (the audit)

Runnable as `Nexus.Gizmo.AuditTypeConsistency`.

1. **Per-type gizmo behaviour cannot diverge, by construction** — and this was worth
   establishing rather than assuming. Every registered type (Traffic Light, City Light,
   Crosswalk, Bus Stop, Seat, Parking, Advertisement, TV, and Phase 75's five facilities)
   registers `DefaultDebugCategory = "Runtime.ActivationPoints"`, and that single category's
   `IsSelectable`/`CanSupportGizmo` is the only gate `UNexusActivationGizmoTool` consults.
   One gate, one set of flags, no per-type branch anywhere. **The flip side is worth
   recording**: gizmo interactivity therefore cannot be enabled for one type and not
   another. That is fine today and is a real constraint tomorrow.
2. **No snapping existed at all.**
3. **No numeric entry existed for the gizmo-selected offset.** The Details tab bound a
   type's *payload* struct (Phase 51), which reaches named sub-point fields, but a
   base-offset-only type's one editable position (Advertisement, TV, Seat, Parking, and
   every facility's site offset) had **no numeric edit surface anywhere** — drag was the
   only way to set it.
4. **Real bug found: the anchor transform was cached at selection time.**
   `HandleGizmoTransformChanged` derived the local offset against
   `SelectedAnchorWorldTransform`, captured once in `SelectSubPoint`. Anything that moves
   the anchor while the selection stands (a HighwayPoint edit in the Details tab, an undo,
   a Representation refresh) makes a subsequent drag write a **silently wrong** local
   offset. Same class as the already-fixed
   `2026-08-12/bug-fixed/proxy-gizmo-drag-fights-stale-cache-snap-back.md`.
5. **Scale handling: correctly absent.** `ETransformGizmoSubElements::StandardTranslateRotate`
   means no scale handle exists for any type — the phase's Not-Allowed rule was already
   satisfied, and the audit command now says so explicitly so a future change cannot
   quietly break it.

## Changes

- **`UNexusEditorInteractionSettings`** — four new settings under a "Nexus|Gizmo Snapping"
  category: `IsGizmoGridSnapEnabled` / `GizmoGridSnapSize` (10cm) /
  `IsGizmoRotationSnapEnabled` / `GizmoRotationSnapDegrees` (15°). Both toggles default OFF
  (the phase says "optional"; a designer dragging freehand should not silently start
  quantising).
- **`UNexusActivationGizmoTool::ApplySnapping`** (new, public static) — snapping is applied
  to the authored **LOCAL** offset, never the world position. That is the only correct space
  here: an offset is authored relative to its anchor, so "snap to 10cm" must mean 10cm from
  the anchor, not 10cm on the world grid — which would land on a different local value for
  every anchor and make identical objects on different anchors non-identical. Public and
  static specifically so the drag path and the numeric path call the *same* function.
- **Stale-anchor fix** — new `ResolveLiveAnchorWorldTransform()`, used by the drag
  write-back instead of the cached transform (finding 4).
- **`FNexusGizmoSubPointSelection`** (new, `NexusPanelSharedTypes.h`) + subsystem
  `Get/Set/ClearGizmoSubPointSelection` + `OnGizmoSubPointSelectionChanged`. Deliberately
  separate from `FNexusDetailsTarget` rather than a fifth mode on it: selecting a sub-point
  must point the Details tab at the payload struct **and** offer numeric entry at the same
  time — one enum could only express a choice between them. Carries the sub-point KEY, never
  a resolved `FNexusSubPointOffset*`, because an array-element pointer dies on any resize of
  its array (six types now have one).
- **`SNexusDetailsPanel.GizmoEntry.cpp`** (new .cpp for the same widget, per
  `09-development-rules.md`'s splitting rule) — a section above the details view showing the
  selected sub-point's local offset as six numeric boxes (X/Y/Z, P/Y/R) in the native
  transform-tool axis colours, plus the two snap toggles and their increments. Collapsed
  whenever nothing is gizmo-selected, so the tab is unchanged the rest of the time. Values
  are `TAttribute` lambdas re-read every paint, which means **the boxes track a live gizmo
  drag** and need no subscription of their own.
- **`RefreshActiveGizmoFromAuthoredData()`** — a typed value moves the gizmo handle instead
  of leaving it stranded at the pre-edit position. Guarded against re-entrancy.
- **`Nexus.Gizmo.AuditTypeConsistency`** (new command) — the audit above, re-runnable.

## Verification

- `NexusFrameworkEditor` compiles clean (UE 5.8, Development, Win64), 2026-08-22.
- No automated tests written or run, per `project-specifications/AGENT-RULES.md`.

## Result

Implemented. Awaiting the user's manual editor verification.

## Manual verification the user should do

1. `Nexus.Gizmo.AuditTypeConsistency` — expect every type on one gating category, all
   `Sel`/`Giz` = yes, and the shape spread line.
2. Place three different test types (e.g. `AddTestTrafficLight`, `AddTestAdvertisement`,
   `AddTestServiceFacility PetrolStation …`). In Select Mode, click a sub-point on each:
   the Details tab should grow a "**\<name\> - \<sub-point\>**" section with six numeric
   boxes.
3. **Numeric entry**: type a value into X and press Enter — the debug marker AND the gizmo
   handle should both move to it. Verify on all three types.
4. **Snapping**: tick *Snap Location*, set 50, drag a sub-point — the value should land on
   multiples of 50. Then type `123` into X and commit: it should snap to `100` (typed and
   dragged quantise identically, on purpose). Repeat with *Snap Rotation*.
5. **Live tracking**: with the Details tab open, drag the gizmo and watch the numeric boxes
   update during the drag.
6. **Stale-anchor fix**: select a sub-point, then (without deselecting) move its anchor
   HighwayPoint, then drag the sub-point. It should stay attached to the anchor's new
   position rather than jumping.

## Important Notes

- Snapping deliberately does **not** quantise the gizmo handle mid-drag — only the authored
  value (and therefore the debug marker) snaps; the handle re-syncs on the next selection or
  numeric commit. Pushing the snapped transform back onto the proxy mid-drag risked fighting
  the drag, and could not be live-tested under `AGENT-RULES.md`. If the handle floating
  between snap steps reads badly in practice, that is the one thing to revisit.
- One constraint surfaced by the audit and worth a decision later: **gizmo interactivity is
  all-or-nothing across types** because they share one gating Debug category.
- See [[phase-77-gizmo-undo-redo-hardening]] — Phase 77's audit found that the numeric entry
  added here was initially **not undoable**, and fixed it.
