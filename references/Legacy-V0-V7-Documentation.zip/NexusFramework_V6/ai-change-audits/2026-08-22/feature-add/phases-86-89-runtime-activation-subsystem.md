# Phases 86-89 — Runtime Activation Subsystem

Date: 2026-08-22
Category: feature-add
Phase: 86, 87, 88, 89

## Context

Second batch of the day, at the user's "pick 5-10 phases at a time" instruction. Taken
together because all four are one class: a nearby query with no activation is useless, and
activation with no deactivation leaks Actors.

Built directly on Phase 85's Logical World Object vs. Actor design contract, written earlier
the same day, and on Phases 80-84's compiled Runtime Schema.

## Problem / Goal

Consume compiled `FNexusRuntimeResult` data at runtime: query nearby Activation Points,
bind Actors to the ones that currently matter, release them when they stop mattering, and
respect authored time-of-day and distance rules — all inside a packaged build with no editor
module present.

## Findings

**The Phase 47 spatial index did not need reimplementing.** `FNexusSpatialGridIndex` is pure
math with zero reflection — no `UPROPERTY`, `USTRUCT`, `UENUM`, or `GENERATED_BODY`. That
makes it categorically different from the enums Phase 80 declined to move (whose reflected
type paths are referenced by saved `.uasset` content): moving this carries no serialization
risk at all, and Phase 85's Allowed list explicitly sanctions relocating a misplaced type.
Only three files included it.

**`UDeveloperSettings` is a runtime type despite the name.** The `DeveloperSettings` module
is Runtime-type, so `UNexusRuntimeSettings` can live in `NexusFramework` without breaching
Phase 85's boundary — confirmed by the standalone game target linking successfully with it.

## Changes

All in `Source/NexusFramework/` (the runtime module):

- `Public/Spatial/NexusSpatialGridIndex.h` + `Private/Spatial/NexusSpatialGridIndex.cpp` —
  **moved** from `NexusFrameworkEditor` (`git mv`, API macro changed, 3 includes updated).
- `Public/Runtime/NexusRuntimeSettings.h` — `ENexusRuntimeTimeOfDay`,
  `FNexusRuntimeTypeRules`, `UNexusRuntimeSettings`.
- `Public/Runtime/NexusActivationSubsystem.h` + `Private/Runtime/NexusActivationSubsystem.cpp`.
- `NexusFramework.Build.cs` — added `DeveloperSettings`.
- `NexusRuntimeCompiler.cpp` — four new `static_assert`s guarding the time-of-day mirror.

### Decisions worth a reviewer's attention

1. **Nearest-first query ordering is load-bearing, not cosmetic.** Phase 88's
   `MaximumActiveActors` ceiling only delivers "closest wins" if candidates arrive
   closest-first. Sorting in Phase 86's query is what lets Phase 88's ceiling be a simple
   `break` with no second sort — the two phases' correctness is coupled through this.

2. **Deactivation runs before activation in each update.** Actors freed this frame become
   immediately reusable, so a player moving through dense geometry reuses rather than
   spawning-then-freeing.

3. **`ResolveDeactivationRadius` clamps rather than obeys.** If configuration ever resolves a
   deactivation radius at or below the activation distance, the hysteresis gap vanishes and
   objects thrash at the boundary. The resolver pushes the radius out to
   `activationDistance * MinimumHysteresisMultiplier` instead of honouring a setting that
   destroys the property it exists to provide.

4. **Re-registering a cell replaces its slice rather than appending.** A World Partition cell
   can stream out and back in repeatedly. Appending would double that cell's points every
   cycle — which would present as a memory leak and would fail Phase 88's "flat instance
   count" criterion for reasons having nothing to do with pooling.

5. **`DeactivationTimes` is evaluated before `ActiveTimes`.** That ordering is what expresses
   V5's removed `MidnightAutoDisabled` case generally rather than as a special enum value.

6. **The subsystem never recomputes a transform.** It reads
   `FNexusRuntimeActivationPoint::WorldTransform`, baked once at compile time through the
   same resolver the gizmo and debug renderer use. This is what makes
   `v6-master-architecture.md` Section 30's "one authoritative transform-resolution path"
   true by construction.

7. **A type absent from `TypeRules` spawns nothing.** Deliberate: most compiled points should
   never become Actors, which is the whole content of Phase 85's contract.

## Verification

- `Build.bat NexusFramework Win64 Development` — the standalone GAME target, no editor module
  compiled or linked — **Succeeded**. Every line of this subsystem is in the runtime module,
  so this is a genuine compile+link proof for all four phases' code, and independently
  re-proves Phase 85's boundary now that the runtime module has real content in it.
- **The EDITOR target could NOT be built this session.** `Build.bat` refused with "Unable to
  build while Live Coding is active" — the user's editor was open. Three editor-side changes
  are therefore **unverified**: the four new `static_assert`s in `NexusRuntimeCompiler.cpp`,
  the two include-path updates from the spatial-index move
  (`NexusEditorProxyPool.h`, `NexusSpatialGridIndexCommands.cpp`), and the separate Details
  panel crash fix in `agent-todos/active/`.
- **No automated test written or run; the editor was NOT launched** (AGENT-RULES.md). Every
  Completion Criterion across all four phases is a runtime *behaviour* test requiring a
  running game, so all are left unchecked.

## Result

All four `Ready for Review`, with every Completion Criterion deliberately unchecked. The
implementation is complete and the runtime module compiles and links standalone; nothing
about actual runtime behaviour has been observed by anyone yet.

## Important Notes

- **NEXT SESSION MUST BUILD THE EDITOR TARGET FIRST.** Close the editor (or Ctrl+Alt+F11),
  then `Build.bat NexusFrameworkEditor Win64 Development`. Three separate uncompiled changes
  are outstanding, listed under Verification above. Do not start new work before that build
  is clean.
- **Phase 87's Section 30 cross-check is the single highest-value manual test in this batch**
  and nothing else in the project performs it: compare a City Light's dynamic Actor transform
  against the Static Generator's baked transform for the same object. A mismatch means the
  editor's gizmo-adjusted location and the generated mesh's location have silently diverged —
  `v6-master-architecture.md` Section 19's critical requirement.
- **Phase 92 measures the invariant this subsystem exists to hold**:
  `GetLogicalObjectCount()` vs `GetActiveActorCount()` — 100,000+ logical objects against a
  few hundred live Actors (Section 31). Both accessors are exposed as `BlueprintCallable`
  specifically so that phase can measure them without new code.
- The per-type active-count scan inside `UpdateActivations` is O(active bindings) per
  candidate. Fine at the default 500-Actor ceiling; if a project raises
  `MaximumActiveActors` substantially, that is the first thing to profile and replace with a
  running per-type tally. Noted rather than pre-optimized.
