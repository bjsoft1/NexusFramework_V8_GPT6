# Phase 73 — Advertisement Activation Point

Date: 2026-08-22
Category: feature-add
Phase: 73

## Context

First of a six-phase batch the user asked for on 2026-08-22 ("5-6 phases UI related, first
priority"), taken in roadmap order: 73, 74, 75, then the Gizmo/UI polish phases 76, 77, 78.
Phases 73–75 were selected ahead of the UI phases specifically because Phase 76's and
Phase 79's own audit scope is defined as "across all object types built so far (50–75)" —
running them before 73–75 existed would have produced an audit that had to be re-run.

## Problem / Goal

Implement `FNexusAdvertisementActivation` (ContentId/PlaylistId payload), pairing a
`Static`-classified board mesh with `RuntimeActivated` interactive content per
`11-v6-static-dynamic-architecture.md`, and prove the two are independently classified on
a shared anchor.

## Findings

- `ENexusStaticObjectType` already contained `AdvertisementBoardMesh` and
  `AdvertisementInteractiveContent` (added at Phase 40 from
  `11-v6-static-dynamic-architecture.md`'s own mapping table), resolving to `Static` and
  `RuntimeActivated` respectively. Nothing needed adding on the Generation side for this
  phase — the classification half of the completion criterion was already satisfied by
  construction and only needed a runnable proof.
- Two docs pin this type's sub-point shape explicitly: `13-v6-gizmo-system.md`'s
  "Sub-point addressing" section and Phase 45's own Allowed list both name
  "Advertisement/TV/Seat/Parking" as the **zero declared sub-points, base offset only**
  case. That resolves the only real design question in the phase — the interactive
  content surface's position is the base `OffsetLocation`/`OffsetRotation`, and the board
  mesh is a separate Generation-stage object that never appears as a payload field (the
  same reasoning `FNexusCityLightActivation` records for the pole).
- No board-dimension data exists anywhere in the project, so the debug view uses fixed
  placeholder extents — the precedent `GCityLightPolePlaceholderHeight` already set.

## Changes

- **New** `Public/Representation/NexusAdvertisementActivation.h` —
  `FNexusAdvertisementActivation` with `ContentId`/`PlaylistId` (both `FName`, open keys),
  `HasContent()`, and `ResolveEffectiveContentKey()` (PlaylistId wins over ContentId).
  Zero declared `FNexusSubPointOffset` fields, deliberately.
- **New** `Private/Representation/NexusAdvertisementActivationRegistration.cpp` — one
  `FNexusActivationTypeAutoRegister` for type key `"Advertisement"`
  (`RuntimeActivated`, default Debug category `Runtime.ActivationPoints`), plus
  `Nexus.Representation.AddTestAdvertisement` and
  `Nexus.Representation.VerifyAdvertisementClassification`.
- **Edited** `Private/Debug/NexusDebugInfrastructureGroupRenderers.cpp` — added two leaves,
  `Infrastructure.AdvertisementBoard` (Static half: placeholder frame + support post,
  neutral grey) and `Infrastructure.AdvertisementContent` (RuntimeActivated half: content
  surface at the base offset, cyan when content is set, dull olive when blank). Added two
  file-local helpers both this phase and Phase 74 use: `FindBaseSubPoint` (the synthetic
  base key, which a name-based `FindSubPoint` can never locate for a zero-sub-point type)
  and `DrawPanelOutline`.

`RenderParkingBays`'s own inline ground-plane rectangle was deliberately left alone rather
than folded into `DrawPanelOutline` — different plane (Forward/Right vs Right/Up), and
Phase 71 is already through implementation.

## Verification

- `NexusFrameworkEditor` compiles clean (UE 5.8, Development, Win64) — build run
  2026-08-22, `Result: Succeeded`.
- No automated tests written or run, per `project-specifications/AGENT-RULES.md`.

## Result

Implemented. Awaiting the user's manual editor verification.

## Manual verification the user should do

1. `Nexus.Representation.VerifyAdvertisementClassification` — expect
   `AdvertisementBoardMesh -> Static`, `AdvertisementInteractiveContent -> RuntimeActivated`,
   `independently classified: YES`.
2. `Nexus.Representation.AddTestAdvertisement <HighwayPointId>` against a real mapped
   point, then enable **Advertisement Board** and **Advertisement Content** under
   Infrastructure in the Debug Tree — expect a grey frame with a post down to the anchor,
   and a cyan content panel inset inside it, both on the same anchor.
3. Re-run `VerifyAdvertisementClassification` — expect the shared-anchor line naming one
   `HighwayPointId` carrying both halves.
4. In Select Mode, click the content marker and drag — both the frame and the content
   panel should move together (both derive from the same base offset), and the anchor
   should not move.

## Important Notes

- The **export** leg of this phase's "register/visualize/edit/export cycle" is NOT done and
  cannot be: no Compilation stage / `FNexusRuntimeResult` exists anywhere yet — the same
  wall Phase 55 and Phase 59 are `Blocked` on, owned by Phases 80–85. Recorded here rather
  than quietly counted as complete. Unlike 55/59 (which are *entirely* export phases), the
  rest of Phase 73 is real and independent of it, so this phase is not marked `Blocked`.
- See [[phase-74-tv-interactive-screen-activation-point]] and
  [[phase-75-onboarding-checklist-proof-five-types]] for the rest of this batch.
