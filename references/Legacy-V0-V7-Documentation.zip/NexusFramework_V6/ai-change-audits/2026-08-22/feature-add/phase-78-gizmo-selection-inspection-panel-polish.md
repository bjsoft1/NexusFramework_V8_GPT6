# Phase 78 — Gizmo — Selection & Inspection Panel Polish

Date: 2026-08-22
Category: feature-add
Phase: 78

## Context

Sixth and last of the 2026-08-22 batch (73, 74, 75, 76, 77, 78).

## Problem / Goal

Polish the selection/inspection experience across all object types: consistent Details panel
presentation, and an owning-hierarchy breadcrumb (State > City > Highway > HighwayPoint >
ActivationPoint) with working click-through to the Hierarchy tree.

## Findings

1. **Selection only ever flowed one way.** `SNexusHierarchyPanel::PublishHierarchySelection`
   writes the shared details target; nothing anywhere drove the tree's selection *from* that
   target. So breadcrumb click-through was not merely missing UI — the mechanism it needs
   did not exist and had to be added.
2. **Base-struct presentation cannot diverge per type** — `FNexusActivationPoint`'s fields
   (Code/Name/Description/Offset*/ActiveTimes/…) live on the shared base, so only the
   per-type **payload** can drift. That narrowed the audit to something checkable.
3. **A viewport-originated selection had no context at all.** Every gizmo selection comes
   from the viewport, not the tree, and the Details tab showed only the payload's own fields
   — a HighwayPoint's properties look identical whichever Highway/City/State own it. With
   the Hierarchy tab closed (they are independently dockable) there was no way to tell.
4. **A HighwayPoint does not store its owning HighwayId** — membership is expressed the other
   way round, via `FNexusHighway::OrderedPointIds`. So the breadcrumb resolves the owner by
   scanning Highways, and a **junction point legitimately belongs to several Highways at
   once**, which the breadcrumb reports as `Name (+N)` with an explanatory tooltip rather
   than silently presenting the first match as the whole truth.

## Changes

- **New `Private/UI/SNexusDetailsPanel.Breadcrumb.cpp`** (third `.cpp` for this widget) —
  builds the breadcrumb into an `SWrapBox` above everything else in the tab. Handles both
  entry cases: a real persisted entity names itself, while a **session-only test Activation
  Point** (every gizmo selection) has no Hierarchy row, so the chain starts at its anchor
  HighwayPoint and the test point is appended as a trailing, deliberately non-clickable
  `[session-only]` crumb.
- **Every level is optional.** An unassigned Highway (no City) or a City with no State is a
  real supported authoring state in this project — the breadcrumb simply starts lower rather
  than inventing a placeholder parent.
- **A broken anchor renders as a dead crumb**, `(unresolved anchor 1a2b3c4d)`, with a
  tooltip. Showing nothing would read as "this object has no anchor" rather than "its anchor
  is broken" — Phase 22 treats an unresolved anchor as a real validation error.
- **New `SNexusHierarchyPanel::SyncTreeSelectionToDetailsTarget`** — the reverse leg
  (finding 1). Selects and `RequestScrollIntoView`s the matching row. Two deliberate
  behaviours: a feedback-loop guard (the tree's own publish sets the target this handler
  reads, so it early-outs when the target already names the current selection), and it
  **leaves the existing selection alone** rather than clearing it when the target names
  something the tree cannot show (a test point, a Debug category) — clearing would make an
  unrelated selection vanish for a reason the user never asked for.
- **New `Nexus.UI.AuditDetailsPresentation`** — walks every registered type's payload via
  reflection and reports field counts, `Category` headings, uncategorised fields, fields with
  no tooltip, and any category outside the `Nexus|…` convention. Deliberately a report, not
  an enforcement gate: a deviation may be correct, the point is that it becomes visible.

## Verification

- `NexusFrameworkEditor` compiles clean (UE 5.8, Development, Win64), 2026-08-22.
- No automated tests written or run, per `project-specifications/AGENT-RULES.md`.

## Result

Implemented. Awaiting the user's manual editor verification.

## Manual verification the user should do

1. `Nexus.UI.AuditDetailsPresentation` — expect every type's payload categorised under
   `Nexus|…`, and the summary line reporting 0 uncategorised / 0 off-convention.
2. **Breadcrumb, hierarchy selection**: select a HighwayPoint in the Hierarchy tree — the
   Details tab should show `State › City › Highway › HighwayPoint`.
3. **Breadcrumb, viewport selection**: place a test Advertisement/TV/Petrol Station and click
   one of its sub-points in Select Mode. The breadcrumb should show the chain down to the
   anchor plus a trailing `Test … [session-only]` crumb (plain text, not a link).
4. **Click-through on at least three object types** (the phase's own criterion): click the
   City crumb, then the Highway crumb, then the HighwayPoint crumb — each should select AND
   scroll to the matching Hierarchy tree row, with the Details tab rebinding to it.
5. **Junction case**: find a HighwayPoint shared by 2+ Highways and confirm the Highway crumb
   reads `Name (+1)` with the junction tooltip.
6. **No feedback loop**: click rows in the Hierarchy tree repeatedly and confirm no flicker,
   no reselection fighting, and no hang.
7. **Collapse behaviour**: select a Debug Tree category — the breadcrumb should disappear
   entirely, leaving the tab looking as it did before this phase.

## Important Notes

- Click-through to a **real, persisted** Activation Point works (it has a Hierarchy row);
  click-through to a session-only test point is intentionally absent because no such row
  exists. That asymmetry is Phase 75's GAP 1 again — see
  [[phase-75-onboarding-checklist-proof-five-types]].
- Related: [[phase-76-gizmo-viewport-widget-polish]], [[phase-77-gizmo-undo-redo-hardening]].
