# Phase 77 — Gizmo — Undo/Redo Hardening

Date: 2026-08-22
Category: feature-add
Phase: 77

## Context

Fifth of the 2026-08-22 six-phase batch. Directly follows Phase 76, whose numeric-entry
feature this phase's audit found to be un-undoable.

## Problem / Goal

Stress the undo/redo path across multi-step gizmo edit sequences and across editor sessions,
closing any gap found. Per `AGENT-RULES.md` no automated tests were written; the phase was
executed as a **code audit + fixes + runnable inspection aids**, with the long-chain
exercise handed to the user as manual steps.

## Findings

Phase 48 deliberately relied on `UTransformProxy`'s built-in undo integration — the tool's
own header comment states real undo/redo works "without needing a second, custom
`FToolCommandChange`". That reasoning is sound for the simple case and has **three real
gaps**:

**GAP 1 — the undo record was addressed by PROXY, not by DATA (the serious one).**
`FTransformProxyChange` is stored against the `UTransformProxy` UObject. This tool creates a
new proxy per selection and drops the old one on deselect. Undoing an edit after changing
selection replays a transform onto a proxy that is no longer bound to anything — and because
`HandleGizmoTransformChanged` writes to whatever is **currently** selected
(`SelectedActivationPointId`/`SelectedSubPointKey`), a surviving stale proxy could write an
old sub-point's transform into a **different** sub-point. That is silent data corruption, not
just a missed undo.

**GAP 2 — Phase 76's numeric entry produced no undo record at all.** No drag gesture occurs,
so `FTransformProxyChangeSource` recorded nothing. Phase 76 documented that session-only
test-store data has no UObject to `Modify()` — true, and the wrong conclusion: that is a
reason to record an `FChange`, not a reason to skip undo.

**GAP 3 — undo granularity was unspecified.** Nothing guaranteed one entry per drag gesture
rather than per intermediate tick, and nothing gave entries a meaningful Undo History name.

**GAP 4 — the Diagnostics panel validated no Activation Points whatsoever.** Found while
auditing this phase's own "does an undone edit correctly clear a validation warning it
caused?" item, which turned out to be **untestable** because nothing could raise such a
warning: `NexusDiagnostics.cpp` called `ValidateRepresentationStage(TArray<FNexusActivationPoint>(), …)`
— an empty array — even though that function has always accepted them and Phase 22 already
defines their rules.

## Changes

- **New `Private/Gizmo/NexusActivationGizmoTool.Undo.cpp`** (fourth `.cpp` responsibility
  split for this class) containing `FNexusSubPointOffsetChange : FToolCommandChange`. It
  stores only `(ActivationPointId, SubPointKey, OldOffset, NewOffset)` and **re-resolves its
  target through `FNexusActivationSubPointResolver` on every Apply/Revert** — so it survives
  selection changes, tool teardown on Select-Mode switches, and array resizes, none of which
  a proxy-addressed record survives. `HasExpired()` returns true once the target no longer
  resolves, so the transaction system drops it rather than applying it to nothing.
- **`UNexusActivationGizmoTool::ApplySubPointOffsetEdit`** (new public static) — now the ONE
  way any authored offset edit reaches the data. Applies snapping once on the way in (so the
  recorded value is the stored value), **skips no-op edits** so a released-but-unmoved gizmo
  or a retyped identical value leaves no empty Undo History entry, writes through the
  resolver, and emits exactly one record via `UInteractiveToolManager::EmitObjectChange`
  against the subsystem (a stable session-lifetime UObject — deliberately not the test point,
  which is not a UObject, and not the proxy, which dies on the next selection).
- **One undo entry per drag gesture** — bound `OnBeginTransformEdit` (snapshot pre-drag
  offset) and `OnEndTransformEdit` (emit the single record). Intermediate
  `OnTransformChanged` ticks still write through for live feedback but record nothing.
- **`SetActiveTarget(proxy, nullptr)`** — the transaction provider is now null, so the engine
  no longer records its own `FTransformProxyChange`. Keeping both would push two records per
  drag and one Ctrl+Z would appear to do nothing.
- **Foreign-proxy guard** — `HandleGizmoTransformChanged` now rejects callbacks from any
  proxy other than the currently bound one (closes GAP 1's corruption path directly).
- **Numeric entry routed through the same entry point** (`SNexusDetailsPanel.GizmoEntry.cpp`)
  — closes GAP 2, and guarantees typed and dragged edits can never diverge in snapping,
  no-op handling, or undo behaviour.
- **Undo History names** — `ToString()` returns `Nexus Sub-Point Offset (VehicleLED)` /
  `(FuelPumpPoints[2])`, so a 10-deep chain reads as ten distinguishable entries.
- **Diagnostics fix (GAP 4)** — now passes `configAsset->ActivationPoints`.

## Verification

- `NexusFrameworkEditor` compiles clean (UE 5.8, Development, Win64), 2026-08-22.
- No automated tests written or run, per `project-specifications/AGENT-RULES.md`.

## Result

Implemented — four gaps found, all four fixed. Awaiting the user's manual editor verification.

## Manual verification the user should do

1. **10+-step chain**: place a Bus Stop or Petrol Station test point (several sub-points).
   Make 12 distinct edits, mixing gizmo drags and typed values across different sub-points.
2. `Nexus.Gizmo.DumpUndoHistory 20` — expect **exactly 12** Nexus entries, each naming its
   own sub-point, with `<- next Ctrl+Z` on the newest.
3. Press Ctrl+Z twelve times, checking the marker position after **each** step, then Ctrl+Y
   twelve times back. Re-run `DumpUndoHistory` between presses to confirm the marker moves.
4. **The GAP 1 case specifically**: edit sub-point A, then click sub-point B (changing
   selection), then Ctrl+Z. A must return to its previous position and **B must not move at
   all**. This is the corruption path.
5. **No-op suppression**: click a gizmo and release without moving; commit a numeric box at
   its existing value. Neither should add an Undo History entry.
6. **Across a mode switch**: edit, switch to Landscape Mode, switch back to Select Mode, then
   Ctrl+Z. The undo should still work (the record is data-addressed, not proxy-addressed).
7. **Diagnostics**: with a real, persisted Activation Point whose anchor is broken, confirm
   the Diagnostics tab now shows a Representation-stage entry for it — it previously showed
   none for any Activation Point.

## Important Notes

- **`SetActiveTarget(…, nullptr)` is the one change with live-behaviour risk** and could not
  be exercised under `AGENT-RULES.md`. If drags stop producing undo entries entirely, that
  line is the first thing to look at.
- **Gizmo edits still cannot raise a Diagnostics warning**, because the gizmo edits
  session-only test-store data which is not part of the config asset. That is Phase 75's
  GAP 1 (specialized-payload persistence unresolved) surfacing again, not a separate issue —
  once sub-pointed types can be persisted they land in the array Diagnostics now validates,
  and this phase's second criterion becomes fully exercisable. See
  [[phase-75-onboarding-checklist-proof-five-types]].
- Related: [[phase-76-gizmo-viewport-widget-polish]].
