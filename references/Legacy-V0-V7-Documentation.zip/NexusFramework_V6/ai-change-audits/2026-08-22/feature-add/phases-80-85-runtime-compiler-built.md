# Phases 80-85 — The Runtime Compiler, Built

Date: 2026-08-22
Category: feature-add
Phase: 80, 80a, 81, 82, 83, 84, 85

## Context

Picked up as a batch at the user's explicit instruction ("pick 5-10 phases at a time"),
which overrides `/TODO`'s normal one-item-per-invocation rule. The seven were taken together
because they build ONE system: the Runtime Schema has to be designed as a whole, not
discovered six times.

This is the infrastructure whose absence blocked Phases 55/59/63/68/72 from 2026-08-12 to
2026-08-22, and left the export leg of Phases 73/74/75 incomplete — eight phases waiting on
one missing piece. The user resequenced those five to after Phase 85 earlier the same day
(see `../others/runtime-compilation-phases-resequenced-after-85.md`), which is what made this
batch the critical path.

## Problem / Goal

Build the Compilation stage: turn authored `UNexusConfigAsset` data into a
runtime-consumable, cooked-build-loadable Runtime Schema, closing the gap list in
`10-v6-runtime-schema.md` and honouring the module boundary every one of Phases 80-85
repeats.

## Findings

**The runtime module was a bare three-file stub.** `Source/NexusFramework/` contained only
`NexusFramework.Build.cs`, `.cpp`, `.h` — no schema types at all. The dependency direction
was already correct (`NexusFrameworkEditor` depends on `NexusFramework`, never the reverse),
so the boundary did not need repair, only respecting.

**`FNexusHighwayPoint::ConnectedHighwayIds` cannot be trusted as a source.** It is documented
(`2026-08-10/bug-fixed/highwaypoint-connectedhighwayids-never-populated.md`) as never actually
maintained for real Mapping-stage output. Exporting it directly would have shipped empty
connectivity for every real point while passing any test built on hand-constructed fixtures —
a silent failure that looks exactly like success. The compiler recomputes it.

**Two editor enums are genuinely part of the runtime contract**
(`ENexusGenerationClassification`, `ENexusJunctionType`), but a runtime struct may not name an
editor type. Moving them would change their reflected type paths, and
`FNexusHighwayPoint::CategoryMask` names one such path as a literal string in its `UPROPERTY`
meta with saved `.uasset` content already on disk.

**Phase 80a needed no work.** Its checkpoint report was already written in full and its two
criteria already `[x]` — only its `## Status` line had never been advanced off `Not started`.

**Phase 81 had nothing to remove.** Its criterion "redundant per-type export code removed"
presumes per-type exporters existed. They never did — the five phases that would have written
them were blocked. The generic path is the first and only export path.

## Changes

**Runtime module** — `Source/NexusFramework/Public/Schema/Runtime/`:
`NexusRuntimeTypes.h` (mirrored enums), `NexusRuntimeHighwayPoint.h`,
`NexusRuntimeActivationPoint.h`, `NexusRuntimeStationPoint.h`, `NexusRuntimeResult.h`
(hierarchy + flat aggregate + `UNexusRuntimeDataAsset`).

**Editor module** — `{Public,Private}/Compilation/`: `NexusRuntimeCompiler`,
`NexusRuntimeCompilationValidation`, `NexusRuntimeCompilerIO` (+ three console commands:
`Nexus.Compilation.Compile`, `.CompilePerCell`, `.CompileAndSave`).

Seven phase files updated with implementation notes, criteria checked where genuinely met,
and manual verification steps written down where not.

### The four decisions worth a reviewer's attention

1. **Enum mirrors, guarded by `static_assert`.** Rather than moving the editor enums (a real
   `.uasset` serialization risk) or naming them from runtime (forbidden), the runtime module
   mirrors them and the compiler `static_assert`s all 14 enumerators against the originals.
   Drift becomes a compile error rather than a wrong exported byte. `ECategories`/
   `ESubCategory` were deliberately NOT mirrored — the raw `int32` mask and `uint8` value
   carry full meaning without the enum type, so mirroring them would add drift surfaces for
   nothing.

2. **Compilation freezes live geometry, which the editor deliberately never caches.** This is
   not a re-introduction of the V5 staleness bug. V5 cached geometry in the AUTHORING
   representation, where it drifted from the Landscape while authoring continued. Here the
   freeze happens at the end of the pipeline; re-compiling is what re-reads, and frozen data
   never feeds back into authoring. A cooked build has no Landscape Spline data and no editor
   module to read it with, so compilation is the one sanctioned moment for this.

3. **The validation gate is enforced by API shape, not documentation.** There is no public
   "save this result" entry point that skips it — `CompileAndSaveAll` runs
   compile → validate → save as one indivisible operation. A rule enforced by there being no
   other way through survives future callers in a way a documented rule does not. Validation
   is also all-or-nothing across cells, so a Blocking finding in a later cell cannot leave
   earlier cells freshly written and later ones stale.

4. **Specialized payloads export generically, by name.** `ExportPayloadFieldsGenerically`
   reflects over each payload `USTRUCT` into name-keyed containers, and sub-points carry their
   `(FieldName, ArrayIndex)` key. This is what makes Phase 80a's "round-trips by NAME, not
   just exports correctly generically" requirement literally checkable, and it means a new
   object type ships with zero export code — the extensibility contract
   `12-v6-activation-point-system.md` exists to protect.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development` (UE 5.8) — **Succeeded.**
- `Build.bat NexusFramework Win64 Development` — the standalone GAME target, no editor module
  compiled or linked — **compiled and linked `NexusFramework.exe` successfully.** This is
  Phase 85's two build-verifiable criteria proven rather than asserted: the runtime module has
  zero editor dependencies, and a non-editor build links referencing only it.
- **No automated test written or run; the editor was NOT launched** (AGENT-RULES.md Agent
  Testing Policy). Every round-trip and multi-cell criterion needs a human with a real mapped
  Landscape — those are written down per phase, unchecked.

## Result

All seven `Ready for Review`. Phase 85 is fully criteria-complete; 80/81/82 are partially
checked (the gap-closure and code-removal criteria, which are confirmable statically); 83/84
are unchecked pending the fixtures only a human can build.

## Important Notes

- **The five deferred phases (55/59/63/68/72) are now technically unblockable** — their
  prerequisite exists. They stay `Blocked` deliberately: the resequence decision defers them
  until Phase 85 is **done**, and 85 is `Ready for Review`, not `Complete`. Advancing 85 is
  the user's call, and that is the signal that releases the back-fill.
- **When they are back-filled, Phases 73/74/75's incomplete export leg should go in the same
  pass.** It is blocked by the identical gap and is easy to overlook because those three
  already read as `Ready for Review`.
- **A likely-redundant discovery for the back-fill:** the generic exporter (Phase 81) may
  already satisfy most of what 55/59/63/68/72 were scoped to do by hand, since it exports any
  registered type's payload with no per-type code. Whoever picks them up should check whether
  each phase still has real work left, or whether its objective is already met generically —
  rather than writing per-type exporters the architecture no longer needs.
- **Bus Stop bays carry the station's own transform**, not per-bay geometry — Bus Stop authors
  no spacing/dimension fields the way Parking does. Documented rather than silently emitting a
  fabricated offset grid; per-bay bus geometry needs authored fields first.
- **`Nexus.Compilation.CompilePerCell` reporting one cell means the Phase 83 test is
  inconclusive, not passing.** It needs a genuinely multi-State map with distinct
  `DataLayerAssetName` values.
- The compiler refuses to compile on an unresolved `SourcePoint` or a dangling anchor rather
  than substituting a fallback — `05-v6-data-flow.md`'s "unresolved reference is a validation
  error, not a fallback value". Expect a hard failure with a named point, not a silent partial
  export, if the Mapping stage has errors.
