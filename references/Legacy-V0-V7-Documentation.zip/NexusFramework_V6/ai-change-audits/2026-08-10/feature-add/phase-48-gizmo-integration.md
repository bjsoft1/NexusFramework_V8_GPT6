# Phase 48 — Activation Point — Gizmo Integration (Base)

Date: 2026-08-10
Category: feature-add
Phase: 48

## Context

Phase 48's own required first task (resolve whether the Interactive Tools Framework is
reachable without a custom `UEdMode`) was already done earlier this session - see
`ai-change-audits/2026-08-10/research/phase-48-itf-reachable-without-custom-mode.md`
(finding: yes, via `ILevelEditor::GetEditorModeManager().GetInteractiveToolsContext()`).
That session deliberately stopped there, flagging the rest of the phase (tool
registration, selection, drag write-back, undo/redo) as needing a dedicated pass with
real in-editor testing available - "not a blind implementation at the tail of a long
session."

This session picks up exactly that remaining work, per the user's own explicit standing
instruction (new this session, saved to this agent's cross-session memory) to prioritize
V6 work with visible Editor UI/debug results over console-only verification - gizmo
dragging is the canonical example of that kind of work.

## Problem / Goal

Wire a real viewport gizmo (translate/rotate) to Phase 21's `FNexusActivationPoint`
offset, generically across both the fixed-field and dynamic-array sub-point cases
(`13-v6-gizmo-system.md`'s "Sub-point addressing"), using Phase 45's dummy test types,
without ever touching the underlying Landscape/HighwayPoint geometry, and with real
undo/redo.

## Findings

- No selection/click-handling mechanism existed anywhere in this codebase before this
  phase (confirmed by search: no `HHitProxy`, no viewport click override, no picking
  code). Phase 46's debug markers are plain `DrawDebugSphere` calls - not real primitive
  components, so the engine's normal actor-click-select path has nothing to hit-test
  against. This had to be built from scratch as a manual ray-vs-sphere test.
- `FNexusDebugRenderConfig` already had both `IsSelectable` and `CanSupportGizmo` fields
  (added Phase 25), but nothing in the codebase consumed either one, and it was
  previously undecided whether selection should require one, the other, or both. This
  phase decides: **both** (the conservative default - see `13-v6-gizmo-system.md`'s own
  updated "Selection model" section).
- Phase 46's renderer only ever drew ONE marker per Activation Point, at its own base
  `OffsetLocation`/`OffsetRotation` - it never actually read a payload struct's
  `FixedPoint`/`ArrayPoints` fields, so the `Dummy.Array` type had nothing rendered (or
  selectable) beyond a single, meaningless base-offset sphere. Proving Phase 48's own
  explicit array-case completion criterion required first teaching the renderer to draw
  one marker per resolved sub-point.
- `UTransformProxy::AddComponentCustom` requires a non-null `USceneComponent*` even
  though its `GetTransformFunc`/`SetTransformFunc` lambdas fully override the actual
  get/set behavior - confirmed by reading `TransformProxy.cpp`: `Obj.Component.IsValid()`
  gates whether `SetTransformFunc` is even called. Worked around with a transient,
  never-registered `USceneComponent` held as a `UPROPERTY` (keeps it alive via GC,
  `bModifyComponentOnTransform=false` so its own (irrelevant) `Modify()` never fires).
- The edited data (`FNexusActivationPointTestStore`'s plain `FNexusActivationPoint`/
  payload bytes) is not a `UObject`, so the usual `Modify()` + `FScopedTransaction`
  snapshot-diff undo mechanism does not apply. Read `TransformProxy.cpp`/
  `CombinedTransformGizmo.cpp` engine source directly to confirm `UTransformProxy` has
  its own built-in undo integration for exactly this situation:
  `SetActiveTarget(Proxy, GetToolManager())` wires an internal
  `FTransformProxyChangeSource` that records each drag gesture (bounded by
  `Proxy->BeginTransformEditSequence()`/`EndTransformEditSequence()`, confirmed as the
  actual call sites via source grep) as one `FTransformProxyChange` through
  `GetToolManager()`'s `IToolContextTransactionProvider` - the same real `GEditor`
  transaction system `FScopedTransaction` itself wraps. On Undo/Redo the engine replays
  `Proxy->SetTransform(old/new)`, which re-fires `OnTransformChanged` - since this tool's
  own handler always fully re-derives the local offset from whatever world transform it
  receives (never an incremental delta), Undo/Redo works correctly without a second,
  hand-written `FToolCommandChange`. This is a correct reading of engine source, not
  something verifiable without a live editor session - flagged explicitly as unverified
  in `phase-48.md`'s own Manual QA section.
- `ModelingToolsEditorMode` plugin is enabled in this project's `.uproject` (pre-existing,
  not added this session) - not depended on directly, but confirms ITF/gizmo engine
  modules are already a normal part of this project's plugin footprint.

## Changes

- New `Public/Private/Representation/NexusActivationPointTestStore.*` - Phase 46's
  session-only `GTestActivationPoints` promoted to a shared class (same session-only/
  never-persisted contract, same console command names), now also owning each point's
  optional allocated payload struct instance (`UScriptStruct::InitializeStruct`/
  `DestroyStruct`, not raw bytes - correctly constructs/destructs a
  `TArray`-bearing payload like `FNexusDummyArrayActivationPayload`).
- New `Public/Private/Representation/NexusActivationSubPointResolver.*` -
  `EnumerateResolvedSubPoints`/`GetSubPointOffset`/`SetSubPointOffset`, the one generic
  mechanism shared by the Debug renderer (read) and Gizmo tool (read+write). A synthetic
  `(NAME_None, INDEX_NONE)` key always means "the ActivationPoint's own base offset
  fields" - used whenever a type declares zero sub-point fields (base-only types).
- `Private/Debug/NexusDebugRuntimeGroupRenderers.cpp` (Phase 46) - revised to read/write
  through `FNexusActivationPointTestStore` instead of a local array; `RenderActivationPoints`
  now draws one marker per resolved sub-point via the new resolver; new
  `Nexus.Representation.AddTestActivationPointArray` console command seeds a real
  multi-element `Dummy.Array` payload. See phase-46.md's own appended Revision.
- `Public/Subsystem/NexusFrameworkSubsystem.h` (Phase 30) - added one public const
  getter, `GetRenderSnapshot()`, for the Gizmo tool's hit-test/anchor resolution to reuse
  the same cached snapshot every renderer already reads (never a second, independently-
  resolved copy). See phase-30.md's own appended Revision.
- New `Public/Private/Gizmo/NexusActivationGizmoTool.*` -
  `UNexusActivationGizmoToolBuilder`/`UNexusActivationGizmoTool` (an always-active
  `UInteractiveTool`): manual ray-vs-sphere selection via `ULocalSingleClickInputBehavior`,
  gizmo activation via `UE::TransformGizmoUtil::CreateCustomTransformGizmo`
  (`ETransformGizmoSubElements::StandardTranslateRotate` - translate+rotate only, no
  scale), drag write-back via `UTransformProxy::OnTransformChanged` ->
  `FNexusActivationSubPointResolver::SetSubPointOffset`.
- New `Public/Private/Gizmo/NexusActivationGizmoManager.*` - registers the tool type +
  `UCombinedTransformGizmoContextObject` against the level editor's shared
  `UModeManagerInteractiveToolsContext` once, then Activates/Deactivates (Start/EndTool)
  alongside built-in Landscape Mode.
- `Public/Private/UI/NexusLandscapeModeExtension.*` - new `GizmoManager` member;
  `RegisterToFirstLevelEditor()` calls `GizmoManager.RegisterToolType(...)`;
  `OnEditorModeIDChanged()` calls `Activate()`/`Deactivate()` on Landscape Mode
  enter/exit; `Unregister()` calls `UnregisterToolType()`.
- `NexusFrameworkEditor.Build.cs` - added `InteractiveToolsFramework` and
  `EditorInteractiveToolsFramework` to `PublicDependencyModuleNames`.
- `project-specifications/13-v6-gizmo-system.md` - "Selection model" section updated:
  `bSupportsGizmo` renamed in-doc to the actually-implemented `CanSupportGizmo`, and a
  new note recording the `IsSelectable && CanSupportGizmo` (both required) decision.

## Verification

Build-only (`project-specifications/AGENT-RULES.md`'s Agent Testing Policy - no
automated tests, no editor launch by this agent):

```
Build.bat NexusFrameworkEditor Win64 Development -project=NexusFramework.uproject
```

Result: **Succeeded**, clean compile, no warnings in the build log, 18/18 actions.

No in-editor verification was performed or attempted - see `phase-48.md`'s own "Manual
QA still required" section for the full numbered checklist (select/drag/undo-redo/array-
case/deselect/gizmo-handle-priority/repeated mode toggling), and this record's own
Findings section above for the specific undo/redo mechanism that most needs a live
click-test before being trusted.

## Result

Phase 48 build-implemented end-to-end (mechanism registration, selection, sub-point
resolution for both the fixed and array cases, drag write-back, and undo/redo via the
engine's own `UTransformProxy` integration). Status set to `Ready for Review` - all
three Completion Criteria left unchecked pending real in-editor QA (see that phase file's
own Manual QA section for exact steps). This is the first click/selection and first
gizmo-driven-edit code in this project - treat the undo/redo path in particular as
"probably correct by source reading" rather than "proven," until a user manually
confirms Ctrl+Z/Ctrl+Y really reverts a drag.

## Important Notes

- Whether this tool's own always-on `USingleClickInputBehavior` (default input capture
  priority) correctly yields to the gizmo's own built-in translate/rotate handle
  click-drag behaviors (rather than swallowing a handle-drag as a new selection click)
  is the single biggest unverified risk - flagged explicitly, not glossed over.
- The real Activation Point storage architecture (replacing the session-only
  `FNexusActivationPointTestStore`) is still an open question for Phase 50+ (Traffic
  Light) - unchanged by this phase. When that lands, this phase's write path
  (`FNexusActivationSubPointResolver::SetSubPointOffset`) does not need to change; only
  the caller needs to add a real `UObject::Modify()` call at the appropriate point (the
  resolver was deliberately kept UObject-agnostic for this reason).
