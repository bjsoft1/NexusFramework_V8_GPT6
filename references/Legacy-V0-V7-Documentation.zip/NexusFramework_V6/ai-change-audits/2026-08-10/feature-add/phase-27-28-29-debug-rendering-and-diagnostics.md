# Phases 28, 29, 27 — Debug Rendering (Wireframe Primitives / Labels & Text) + Diagnostics Panel & Viewport Rendering

Task: Phases 28, 29, 27
Category: feature-add
Phase: phases/28, phases/29, phases/27
Status: Ready for Review
Completed Date: 2026-08-10
Completed Time: 03:10 NST (+0545)

## Context

Follows directly from the previous batch (Phases 23-26), which deliberately STOPPED
before Phase 27 because 27's own Allowed list requires rendering "via Phase 28/29's
shared primitives" — phases that didn't exist yet. That was raised with the user, who
explained the intent behind Debug Mode in their own words and asked whether it was
harder to build now given how young the system is.

**User's framing, confirmed correct and worth recording**: Debug Mode exists because the
authored city (highways, crosswalks, lanes, traffic lights, city lights, cross/T
junctions — ~30-40 distinct item types) must be previewable and adjustable in-editor
BEFORE the Static Generator merges anything into real meshes. Rendering actual static
meshes for a GTA-V-scale city during authoring would hang the editor; wireframe draw
calls cost a flat, scale-independent amount. This matches `06-v6-debug-system.md` and
`11-v6-static-dynamic-architecture.md` exactly — recorded here because the user
articulated the *motivation* more concretely than the specs do.

**Key finding that unblocked the batch**: Phases 28/29 turned out NOT to depend on the
30-40 item types existing. They are a generic toolkit (primitive draw functions + world-
space labels); each item type gets its own later "Debug Visualization" phase (53 Traffic
Light, 57 City Light, 62 Crosswalk, 67 Bus Stop, ...) that registers a renderer into
Phase 23's registry. So the dependency was resolvable by doing 28 → 29 → 27 in that
order, with no roadmap jumping and no guessing at a later phase's interface. User
approved proceeding.

## Problem / Goal

Implement `phase-28.md` (shared wireframe-primitive draw library), `phase-29.md`
(world-space text labels), and `phase-27.md` (Diagnostics panel wired to all three
stage gates + viewport rendering of flagged entities).

## Findings

1. **Implemented in dependency order (28, 29, then 27), not phase-number order** — 27
   consumes both of the others. Reported here in that same implementation order for
   clarity, unlike the previous batch's phase-number-ordered report.
2. **`FNexusDebugPrimitives` enforces `Config.bVisible` at the lowest level** — every
   draw function early-outs on it, so no caller can accidentally bypass the per-category
   master switch (06's "checked once per category per frame" performance rule). Chosen
   over trusting each future renderer to check it themselves.
3. **`bPersistentLines=false` + `LifeTime=0.f`** — single-frame draws, exactly 06's
   documented "short LifeTime, redrawn every tick, not persistent" mechanism. What makes
   them appear continuous is the subsystem's `Tick`, not any caching in the library.
4. **Phase 28's benchmark measures issue-time, not display-time** — all 10,000
   `DrawLine` calls happen synchronously inside one console-command invocation (one
   frame's processing), so the elapsed-ms figure is the real cost being baselined for
   Phases 33-35. A 100x100 grid at the world origin, so it's also visually inspectable.
5. **`FNexusDebugLabelOverlay` ported from V5's own proven mechanism** — an
   `SConstraintCanvas` added to the first active level viewport via
   `SEditorViewport::AddOverlayWidget`, positioned per-label with
   `UUnrealEditorSubsystem::WorldToScreen`. V5's reference notes this is confirmed NOT
   PIE-gated, unlike `DrawDebugString` (needs a PlayerController/HUD that a plain editor
   world doesn't have). Verified both APIs still exist with these signatures in UE 5.8's
   own headers before writing against them.
6. **Deliberate simplification vs. V5: no STextBlock pooling.** V5 pools and repositions
   a reused set of widgets; this rebuilds the canvas's children each `UpdateLabels()`
   call. Correct for Phase 29's own completion criteria at today's label counts, and
   allocation-efficiency at scale is explicitly Phase 33-35's ("Debug Performance") job —
   flagged in the class's own header comment so the trade-off isn't invisible later.
7. **Phase 29's "camera-facing" criterion holds trivially, and that's worth stating
   plainly**: the labels are 2D screen-space `STextBlock`s, not 3D world-space
   billboards, so there is no billboard rotation to implement or get wrong. Written into
   the phase file so a reviewer doesn't look for rotation code that shouldn't exist.
8. **`UNexusFrameworkSubsystem` gained `FTickableEditorObject`** — 06's documented
   mechanism, and V5's own hard-won lesson (`v5-complete-reference.md`): driving the
   render loop from the panel widget's `Tick()` instead "silently stopped updating when
   switching tabs/modes." The subsystem outlives any tab; a `SCompoundWidget` doesn't.
   First time V6's subsystem has done anything beyond hold `ActiveConfig`.
9. **Split refresh responsibility deliberately**: viewport markers/labels are driven from
   the *subsystem's* mode-independent Tick (must draw whether or not the Nexus tab has
   focus); the Diagnostics *panel list* refreshes from the *panel widget's* own Tick
   (only needs to be current while visible). Two tick sites, two different correct
   lifetimes — not an oversight.
10. **All three per-stage validation entry types gained `bHasWorldLocation`/
    `WorldLocation`** (`FNexusSourceValidationEntry`, `FNexusMappingValidationEntry`,
    `FNexusRepresentationValidationEntry`). Populated at call sites where a control
    point's `Location` was already in scope. Deliberately a `bool` + value rather than
    an optional/sentinel: **an entry about something that doesn't exist has no correct
    location to point at** (e.g. "HighwayPoint has an unresolved SourcePoint" — the
    thing to mark is precisely what's missing), and a silent `FVector::ZeroVector` would
    put a misleading marker at the world origin. Those entries are list-only, honestly.
11. **`FNexusDiagnostics::GatherDiagnostics` re-runs all three gates fresh every call, no
    caching** — so "results update live as Mapping/Representation are re-run" (Phase 27's
    own requirement) is true by construction. Same rebuilt-fresh discipline
    `FNexusRepresentationGraph` already uses.
12. **Diagnostics category classification is a message-content heuristic, and that's a
    known weak point.** None of the three validation entry types carry a structured
    category field, only a human-readable message — so routing an entry to one of the
    Diagnostics group's four fixed leaves (Validation Errors / Broken References /
    Duplicate IDs / Bounds) is done by substring matching ("duplicate", "unresolved",
    "does not exist", "cross-map", ...). It works for today's exact message set but is
    brittle against message rewording. The robust fix is a structured category field on
    each stage's own entry type, which would mean touching three already-QA'd phases'
    types — deliberately not done unprompted. **Flagged for the user as a possible
    follow-up `agent-todos` task.**
13. **`Diagnostics.Bounds` is registered with no producer** — nothing through Phase 27
    emits a bounds-related check. Registered as an empty leaf rather than omitted, same
    precedent as Phase 23's six groups starting empty, since 06's Diagnostics leaf list
    names it explicitly.
14. **`GetRegisteredCategoryId`'s switch is not a violation of the "no `if CategoryName
    == X` branches" rule.** That rule (every Debug-* phase's Not Allowed list) is about
    not branching over the *open, extensible* registry. This switch maps a *fixed,
    doc-specified 4-value enum* (`ENexusDiagnosticsCategory`) that this system owns
    outright to its own four registered CategoryIds — it is the registration site's own
    identity mapping, not registry-consuming dispatch. Adding a 51st category still
    requires zero edits here. Recording the reasoning since it superficially resembles
    the banned pattern.
15. **Click-to-focus focuses the camera but does NOT select the entity — a real,
    documented deviation from Phase 27's criterion wording.** Two independent blockers:
    (a) `ULandscapeSplineSelection::SetSplineSelected` is a confirmed engine crash per
    `01-v5-analysis.md`, so programmatic control-point selection is off-limits; (b) the
    Hierarchy tree is still Phase 04 placeholder content with no real entities to select.
    Implemented `GEditor->MoveViewportCamerasToBox` instead (verified present in UE 5.8's
    `EditorEngine.h`) and wrote the deviation into the phase file rather than silently
    claiming the criterion.
16. **`OnDiagnosticsSelectionChanged` ignores `ESelectInfo::Direct`** — otherwise the
    list's own reselection during `RequestListRefresh` would yank the viewport camera
    on every rebuild. Similarly, `RefreshDiagnostics` diffs before rebuilding, so a
    per-frame refresh doesn't fight the user's selection/scroll state.
17. **The Diagnostics panel's Phase 03/04 placeholder shell was fully replaced** —
    `EmptyDiagnosticsItems` (`TArray<TSharedPtr<FString>>`) and `OnGenerateEmptyListRow`
    are gone, replaced by a real `SListView<TSharedPtr<FNexusDiagnosticsEntry>>`. Phase
    03's own comment already designated this as "real wiring is Phase 27."

## Changes

- New `Public/Debug/NexusDebugPrimitives.h` / `Private/Debug/NexusDebugPrimitives.cpp` —
  `FNexusDebugPrimitives` (DrawLine/Box/Sphere/Arrow/Capsule/TangentHandle/
  DirectionArrow, all config-driven) + `Nexus.Debug.BenchmarkPrimitives`.
- New `Public/Debug/NexusDebugLabelOverlay.h` / `Private/Debug/NexusDebugLabelOverlay.cpp`
  — `FNexusDebugLabelRequest` + `FNexusDebugLabelOverlay` (Findings #5-7).
- New `Public/Debug/NexusDiagnosticsEntry.h` — `ENexusDiagnosticsSeverity`,
  `ENexusDiagnosticsCategory`, `FNexusDiagnosticsEntry`.
- New `Public/Debug/NexusDiagnostics.h` / `Private/Debug/NexusDiagnostics.cpp` —
  `GatherDiagnostics` (all three stage gates normalized into one list),
  `GetRegisteredCategoryId`, and the four `Diagnostics.*` leaf registrations.
- `Public/Reader/NexusLandscapeReader.h`, `Public/Mapping/NexusMapping.h`,
  `Public/Representation/NexusRepresentationGraph.h` — each validation entry struct
  gained `bHasWorldLocation`/`WorldLocation` (Findings #10); populated in
  `NexusLandscapeReader.Validation.cpp` and `NexusMapping.Validation.cpp`.
- `Public/Subsystem/NexusFrameworkSubsystem.h` / `Private/.../NexusFrameworkSubsystem.cpp`
  — now also an `FTickableEditorObject`; owns `FNexusDebugLabelOverlay`; new
  `RenderDiagnosticsOverlay()` (Findings #8, #9).
- `Private/UI/SNexusFrameworkPanel.h`/`.cpp` — Diagnostics section rebuilt as a real
  list view with Blocking/Warning colour+prefix distinction, per-frame diffed refresh,
  and click-to-focus (Findings #15-17).
- `project-specifications/phases/phase-27.md`, `phase-28.md`, `phase-29.md` — Status →
  `Ready for Review`; Phase 28's "zero production-mesh references" checked off as a
  structural fact; the other five criteria left unchecked with exact manual-check steps,
  including how to produce a deliberate validation failure (Phase 27) and the
  click-to-focus deviation (Findings #15). Phase 29 gained a "Note on scope" section for
  its deferred per-category label-builder half.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, 0 errors; 22 `.cpp` files compiled (every file touching the
  three changed validation-entry headers rebuilt). First attempt was blocked by a running
  editor with Live Coding active (same as the Phase 19 session); asked the user rather
  than closing it, user closed it, second attempt passed.
- `node html-docs/build.js` — regenerated `PHASE-STATUS.md`/`phase-data.js`/
  `phase-tracker.html` after the three status writes.
- **No automated tests written or run** — per `AGENT-RULES.md`'s Agent Testing Policy.
  Five of six completion criteria need the user's own in-editor session.

## Result

Phases 28, 29, 27 implemented and build-verified — this closes the "Debug Architecture"
arc (23-27) and the first two phases of the "Debug Rendering" arc (28-32). The Debug
system is now end-to-end functional for its first real consumer (Diagnostics): registry →
tree UI → per-category config → persistence → primitives → labels → live viewport
rendering. Phase 30 ("Debug Rendering — Landscape Group") is the next natural item and
has no comparable forward dependency: it registers real leaf renderers using exactly the
primitive/label library built here.

## Important Notes

- **Possible follow-up task for the user to consider**: replace Finding #12's
  substring-matching category heuristic with a structured category field on each
  stage's validation entry type. Not done unprompted (would touch three already-QA'd
  phases' types); belongs in `agent-todos/` if wanted.
- Phase 27's click-to-focus deviation (Finding #15) is the one place implementation
  knowingly differs from a criterion's literal wording — documented in the phase file
  itself, not just here.
- The viewport markers only draw when an active config exists AND a Diagnostics entry
  carries a world location. A completely clean project draws nothing, which is correct
  but means "nothing appears" is not by itself evidence of a bug.
- Phase 30+ renderers should call `FNexusDebugPrimitives`/`FNexusDebugLabelOverlay` and
  must not issue raw `::DrawDebug*` calls — that's what keeps config-sourcing in one
  place (Phase 30's own "no renderer duplicates logic already in Phase 28/29's shared
  library" criterion).
