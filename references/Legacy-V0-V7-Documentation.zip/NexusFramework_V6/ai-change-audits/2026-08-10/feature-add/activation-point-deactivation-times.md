# ActivationPoint — DeactivationTimes field + MidnightAutoDisabled removal

Date: 2026-08-10
Category: feature-add
Phase: N/A (ad-hoc data-model enhancement, prerequisite for Phase 89's future runtime
evaluation - see that phase's own file)

## Context

User request: "we have activation time, i want similar deactivation time this could help
us make more advanced, and remove the: Mid Night auto disabled options it should be handle
by or deactivation time."

`FNexusActivationPoint::ActiveTimes` (a bitmask of `ENexusActiveTimes`: Day/Night/
Afternoon/Midnight) is carried over unchanged from V5's `FNexusDynamicInteractable`. V5 also
had a fifth enum value, `MidnightAutoDisabled` ("active at midnight but auto-disabled, e.g.
a shop light that switches off overnight") - a single hard-coded special case bolted onto
the same enum used for "on".

No runtime consumer of `ActiveTimes` exists anywhere in this repo yet - the runtime
Activation subsystem is a separate, not-yet-built module (Phase 88/89, both still "Not
started"). This is a pure editor-side data-model change with no behavior to migrate.

## Problem / Goal

`MidnightAutoDisabled` only ever expressed "on at midnight, but forced off" - a bespoke
combination baked into the enum, unable to express any OTHER on-then-forced-off combination
(e.g. "on at Night AND Midnight, but forced off specifically during Afternoon" has no way to
be represented). The user wants a general mechanism instead: an independent deactivation
bitmask, mirroring `ActiveTimes`' own shape, that can force any bucket off regardless of
what `ActiveTimes` says - letting `MidnightAutoDisabled`'s one specific case become just one
of many expressible combinations, not a special enum value.

## Changes

- `Source/NexusFrameworkEditor/Public/Representation/NexusActivationPoint.h`:
  - `ENexusActiveTimes`: removed `MidnightAutoDisabled = 4`. Now `Day=0, Night=1,
    Afternoon=2, Midnight=3` only. Enum's own header comment rewritten to explain the
    removal and point at the new field below.
  - `FNexusActivationPoint`: added `int32 DeactivationTimes = 0;` immediately after
    `ActiveTimes`, same `Bitmask, BitmaskEnum = "/Script/NexusFrameworkEditor.
    ENexusActiveTimes"` meta (reuses the SAME enum as `ActiveTimes`, not a new one) - a
    checkbox multi-select in the Details panel, same as `ActiveTimes`. Doc comment
    explains precedence intent (a bucket set here forces this instance off even if the
    same bucket is set in `ActiveTimes`) and explicitly defers actual runtime evaluation/
    precedence logic to Phase 89 (data shape only, no consumer wired up - same scoping
    already established for `IsEnabled`/`DebugOverride` on this struct).
- `project-specifications/12-v6-activation-point-system.md`: updated the base-field list
  (the doc's own `FNexusActivationPoint { ... }` block) to add `DeactivationTimes` alongside
  `ActiveTimes`, so the architecture doc stays in sync with the actual struct shape.

No other file referenced `ActiveTimes` or `MidnightAutoDisabled` anywhere in
`Source/` - confirmed by a repo-wide search before making this change. Nothing else needed
updating.

## Verification

Build: `Build.bat NexusFrameworkEditor Win64 Development` - **Succeeded**, 7 actions
(~18s), first attempt.

No automated test run/added (`project-specifications/AGENT-RULES.md`'s Agent Testing
Policy). Manual verification the user should do in-editor: open an existing or new
ActivationPoint's Details panel, confirm both `Active Times` and `Deactivation Times`
appear as independent checkbox multi-selects (Day/Night/Afternoon/Midnight only - no
"Midnight Auto Disabled" entry on either), and that setting bits on one does not affect the
other.

## Result

Data model change only - no runtime behavior exists yet to test end-to-end (Phase 88/89 not
started). The struct now supports the general on/forced-off combination the user asked for;
Phase 89, when picked up, evaluates `ActiveTimes`/`DeactivationTimes` together against the
runtime world-clock (its own Objective already names this).

## Important Notes

- **Serialization risk assessed as low, not zero.** `ActiveTimes` remains the same
  UPROPERTY name/type (`int32`) - untouched, so `v6-coding-standard.md`'s UPROPERTY-rename
  corruption warning does not apply here. Removing `MidnightAutoDisabled`'s enum VALUE (bit
  4) is a different, smaller risk: a bitmask int32 serializes as a raw integer, not
  per-enum-name, so any already-saved `.uasset` with bit 4 set keeps that bit set (no
  corruption/crash) - it simply has no labelled checkbox for it anymore in the Details
  panel's bitmask widget, and no code currently reads bit 4 for any purpose (confirmed no
  consumer exists). Given Phase 21 is still base-struct-only and this project is a fresh
  V6 rebuild, this was judged an acceptable, low-probability-of-mattering risk rather than
  a reason to keep the stale enum value around.
- `DeactivationTimes` deliberately reuses `ENexusActiveTimes` rather than introducing a
  second, differently-shaped enum - same bucket vocabulary on both sides is what makes "the
  same bucket in both fields = forced off" a coherent rule to evaluate later.
