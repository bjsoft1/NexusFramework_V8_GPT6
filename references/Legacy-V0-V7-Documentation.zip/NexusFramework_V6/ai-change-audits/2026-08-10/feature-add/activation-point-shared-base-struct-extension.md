# Activation Point / City-Object Shared Base Struct — Extension

Date: 2026-08-10
Category: feature-add
Phase: 21 (base struct owner) — prerequisite work requested directly by the user before
starting Phase 49.

## Context

Direct user instruction, given before Phase 49 ("Activation Point — End-to-End Smoke
Test") was allowed to start: inspect the V6 roadmap/phases and code for whichever phase
owns "the shared Activation Point / city-object data structure" the future 20-50 object
types (Traffic Light, City Light, Crosswalk, Bus Stop, Parking, Advertisement, TV, ...)
will all build on, and — rather than inventing something new — extend that existing
structure with a specific field list, then stop and report back for review before any
further Phase 49 work.

## Problem / Goal

Identify the owning phase/struct, confirm it's real (not just planned), compare its
current field set against the user's requested list (Id, Name, Code, Description,
Location/Rotation, Highway/Point reference, enabled/visibility, debug overrides: color,
text color, text size, line thickness), and implement only what's missing — structure
only, no downstream wiring.

## Findings

- The owning struct already exists: `FNexusActivationPoint`
  (`Public/Representation/NexusActivationPoint.h`), implemented by Phase 21
  ("Representation — ActivationPoint Base Struct", currently `In Review`) per
  `project-specifications/12-v6-activation-point-system.md`. Its own doc comment already
  states this is "the shared base every specialized Activation Point type builds on" —
  exactly the concept the user described as "Activation Point / city-object data
  structure". `12-v6-activation-point-system.md` itself lists every planned specialized
  type (`FNexusTrafficLightActivation`, `FNexusBusStopActivation`,
  `FNexusCrosswalkActivation`, `FNexusParkingActivation`, etc., Phase 50+) as containing
  or inheriting this base, confirming it is the single correct extension point — not a
  new struct to invent.
- Comparing the user's requested field list against the struct as it stood before this
  change:
  - Already present: `ActivationPointId` (Id), `HighwayPointId` (Highway/Point
    reference), `OffsetLocation`/`OffsetRotation` (Location/Rotation, composed onto the
    live anchor via `ComputeFinalTransform`).
  - Missing: `Name`/`Code`/`Description` (the identity convention every OTHER Nexus
    authoring struct — State/City/Highway/HighwayPoint — already has, but Phase 21's own
    original scope explicitly excluded per `12-v6-activation-point-system.md`'s original
    field list, which never included them), a per-instance enabled/active toggle
    (`IsAlwaysDraw` exists but is debug-visibility-only, not a general on/off), and any
    per-instance debug-visual override (only a per-CATEGORY `FNexusDebugRenderConfig`
    exists — Phase 25/26 — with no per-instance equivalent).
- Phase 45/46/47/48 (Type Registry, Debug Visualization, Spatial Query Index, Gizmo
  Integration — all `In Review`/`Ready for Review`) already build real, working
  infrastructure ON TOP of `FNexusActivationPoint` — confirming it is actively load-
  bearing, not a stale/abandoned draft. Phase 46's own Implementation Notes independently
  already flag the one part of this area still genuinely undecided: no real
  `UNexusConfigAsset.ActivationPoints` persistence array exists yet ("the real storage
  architecture ... remains an open question for whichever phase first needs to persist a
  real object type"). That question is explicitly OUT of scope for this task — the user
  asked for the shared structure only, not to resolve Activation Point persistence.
  Everything Phase 45-48 built (registry, debug rendering, spatial index, gizmo) instead
  runs against `FNexusActivationPointTestStore`, a session-only, never-persisted list —
  unaffected by this change (adding fields to `FNexusActivationPoint` doesn't touch how
  or where instances are stored).
- V5 comparison (per the user's own fallback instruction, "if V6 is incomplete inspect
  V5") was NOT needed to resolve the missing-fields question — V6's OWN existing
  Name/Code/Description convention on `FNexusHighwayPoint`/`FNexusState`/`FNexusCity`/
  `FNexusHighway` was already the directly reusable precedent, and 12-v6-activation-
  point-system.md itself already documents V6's OWN deliberate improvement over V5's
  `FNexusDynamicInteractable` (shared base + specialized payloads, replacing V5's single
  overloaded struct) — re-deriving that from V5 source would have re-litigated an
  already-made, already-documented V6 architecture decision. `E:\...\NexusFramework_V5\
  ...\Schema\Runtime` was not read for this specific question as a result; flagging this
  explicitly per the instruction to always name what was/wasn't consulted.
- No existing `-1 = inherit` sentinel convention (used elsewhere in this codebase, e.g.
  `FNexusDebugRenderConfig`'s Phase 34 fields) extends cleanly to `FLinearColor` — chose
  one explicit `bool HasOverride` gate covering all four new debug-override fields
  together, rather than four independent per-field sentinels/opt-ins, since an instance
  either has a custom look or it doesn't (no realistic case needs Color overridden but
  not TextSize).

## Changes

- New `Public/Debug/NexusDebugInstanceOverride.h` — `FNexusDebugInstanceOverride`
  (`USTRUCT`): `HasOverride` (bool, default false) gating `Color`/`TextColor`/`TextSize`/
  `LineThickness`. Deliberately its own small reusable struct (not fields inlined
  directly onto `FNexusActivationPoint`) so any future authored city-object type can
  embed it the same way — matches this codebase's existing "shared struct, not
  per-feature duplication" precedent (`FNexusDebugRenderConfig`, `FNexusSubPointOffset`).
- `Public/Representation/NexusActivationPoint.h` (`FNexusActivationPoint`, Phase 21's own
  base struct):
  - Added `Code` (`FName`), `Name` (`FString`), `Description` (`FString`) — same
    identity convention as State/City/Highway/HighwayPoint. Blank by default; `MakeNew()`
    deliberately does NOT auto-generate a "Point 1"-style default the way
    `FNexusHighwayPoint::MakeDefault(index)` does, since no real per-array creation index
    exists yet for Activation Points (same open storage-model question Phase 46 already
    flagged) — revisit once that's decided.
  - Added `IsEnabled` (bool, default true) — a general per-instance active/inactive
    toggle, distinct from the existing `IsAlwaysDraw` (debug-visibility override only)
    and from a Debug category's own per-CATEGORY `IsVisible`. Intended to eventually gate
    Generation/Compilation/runtime activation AND Debug rendering, but that wiring is
    explicitly deferred — see Important Notes below.
  - Added `DebugOverride` (`FNexusDebugInstanceOverride`, default-constructed/inert).
  - Updated `MakeNew()`'s own doc comment (previously said "No Code/Name fields... 12's
    own field list doesn't include them" — now stale, corrected to explain the new
    fields' blank-by-default behavior instead).
- `project-specifications/phases/phase-21.md` — appended a Revision section (base struct
  extended as prerequisite work for Phase 49; not a new phase, not a Status change —
  treated the same way Phase 46 already extended this same struct with `IsAlwaysDraw`).
- `project-specifications/phases/phase-49.md` — appended a forward-pointing Note (this
  work happened first; the new fields are not yet wired into anything Phase 49's own
  smoke test would exercise).

## Verification

Build-only (`AGENT-RULES.md`'s Agent Testing Policy):
```
Build.bat NexusFrameworkEditor Win64 Development -project=NexusFramework.uproject
```
New `USTRUCT` (`FNexusDebugInstanceOverride`) — expected the same Live Coding "new
reflected type" block seen repeatedly earlier this same day; editor was closed first
(confirmed via `tasklist`) before building.

No in-editor verification performed or needed — this pass adds inert fields only
(defaults preserve every existing behavior exactly: `IsEnabled` defaults `true`,
`DebugOverride.HasOverride` defaults `false`, nothing anywhere reads either yet). No
manual QA checklist for this record — there is nothing user-visible to check until a
later pass wires these fields into the Details Panel/renderer/persistence/Gizmo/
validation, per the user's own explicit "implement only the prerequisite structure...
STOP... I will review the data structures before you continue" instruction.

## Result

`FNexusActivationPoint` (Phase 21's existing base struct — confirmed as the single real
owner of "the shared Activation Point / city-object data structure", not a new struct)
now carries every field the user's list asked for: `ActivationPointId` (Id), `Name`/
`Code`/`Description` (new), `OffsetLocation`/`OffsetRotation` (Location/Rotation,
pre-existing), `HighwayPointId` (Highway/Point reference, pre-existing), `IsEnabled`
(enabled/visibility, new), `DebugOverride` (color/text color/text size/line thickness,
new). Build-verified. Awaiting user review before Phase 49 (or any wiring of the new
fields) begins.

## Important Notes

- **Structure only — nothing consumes the 3 new fields yet.** `IsEnabled` is not read by
  Generation, Compilation, the runtime activation flow, or the Phase 46 Debug renderer;
  `DebugOverride` is not read by the Phase 46 renderer either (which still always draws
  using the owning category's `FNexusDebugRenderConfig` only). This is intentional scope
  per the user's own instruction, not an oversight — wiring these in is separate,
  later work.
- **Debug visualization represents real authoring data, not disposable debug-only
  data** (the user's own stated design principle for this task) — already true of this
  change: `IsEnabled`/`DebugOverride`/`Name`/`Code`/`Description` live directly on
  `FNexusActivationPoint` itself (the same struct Generation/Compilation/the runtime flow
  will eventually consume), not on some parallel debug-only shadow struct. The ONE
  still-session-only/non-persisted piece in this whole area (`FNexusActivationPointTestStore`)
  predates this change and is unrelated to it — that store holds instances of the real
  `FNexusActivationPoint` struct, it just isn't backed by real `UNexusConfigAsset`
  persistence yet (Phase 46's own flagged gap, untouched by this task).
- **Editor vs. Runtime separation already holds and is unaffected** — every field added
  this pass lives in `NexusFrameworkEditor`'s `Public/Representation/` and
  `Public/Debug/` folders (Editor-schema, UObject/UPROPERTY-bearing), the same module
  every other Editor-schema struct already lives in; nothing was added to or implied
  about the separate Runtime-consumed export schema (`project-specifications/
  10-v6-runtime-schema.md`, Phase 80+) - that remains a distinct, not-yet-built
  optimized-export step, same as it already was for every other Editor-schema field
  (e.g. the HighwayPoint schema fields added earlier the same day - see phase-80.md's
  own appended Note).
- **Serialization risk**: all 3 new fields (`Code`/`Name`/`Description`) plus `IsEnabled`
  plus `DebugOverride` are pure ADDITIONS to `FNexusActivationPoint` — no existing
  `UPROPERTY` was renamed or removed, so `v6-coding-standard.md`'s renaming/redirect
  concern does not apply here. `FNexusActivationPoint` itself is not yet part of
  `UNexusConfigAsset`'s own saved shape (no `ActivationPoints` array exists there yet —
  see Findings), so there is no already-saved asset data to worry about for this
  specific struct at all, additions or otherwise.

## Follow-up — 2026-08-10 — `IsAlwaysDraw` moved into `DebugOverride`

Direct user instruction: "put this `Is Always Draw` inside: Debug Override." By this
point `ActivationPoints` was already real, persisted, undo/redo-capable data (see the
sibling record `activation-point-persistence-and-details-editing.md`, same date), so this
is a genuine `UPROPERTY` move on a struct with potential saved instances, not another
inert-field addition — flagged per `v6-coding-standard.md`'s renaming/serialization-risk
rule even though this is a relocation, not a rename.

**Change**: `FNexusActivationPoint::IsAlwaysDraw` (a standalone `bool` field, added Phase
46) removed from `Public/Representation/NexusActivationPoint.h`; a same-named `bool
IsAlwaysDraw = false` `UPROPERTY` added to `FNexusDebugInstanceOverride`
(`Public/Debug/NexusDebugInstanceOverride.h`), deliberately NOT gated by that struct's own
`HasOverride` (it's a visibility override, a different concern than the `HasOverride`-gated
look fields — see that struct's own updated top comment). Every C++ read/write site
updated from `activationPoint.IsAlwaysDraw` to `activationPoint.DebugOverride.IsAlwaysDraw`:
`Private/Gizmo/NexusActivationGizmoTool.cpp` (the click-hit gate), `Private/Debug/
NexusDebugRuntimeGroupRenderers.cpp` (the renderer's own visibility gate, both console-
command test-point setters, and both log format calls). Comment-only references (no field
access) in `NexusActivationGizmoTool.h`, `NexusDebugCategory.h`, and
`NexusFrameworkSubsystem.cpp` updated or left as generic terminology where no code path
was affected.

**Serialization note**: since `UNexusConfigAsset::ActivationPoints` is real persisted
data as of the sibling record above, any `.uasset`/config saved between that record and
this one with a non-default `IsAlwaysDraw = true` on a real (non-test-store) Activation
Point will silently reset to `DebugOverride.IsAlwaysDraw = false` on next load — Unreal's
property serialization matches by name+owning-struct, and the property no longer exists
on `FNexusActivationPoint` itself. In practice this window was same-day and the feature
had no in-editor authoring UI wired to it yet (Details Panel editing was wired the same
day but this specific field's own UI exposure was not separately verified as used), so
real data loss is considered unlikely — noted here per the coding standard's rule rather
than confirmed-fine.

**Verification**: build-only, editor closed first (confirmed via `tasklist`) —
`Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject`
succeeded (10 actions, ~14s). No in-editor verification performed (`AGENT-RULES.md`'s
Agent Testing Policy) — user should confirm any previously-authored real Activation
Point's Always-Draw checkbox (now under Debug Override in the Details Panel) still
reflects what they expect after this change.
