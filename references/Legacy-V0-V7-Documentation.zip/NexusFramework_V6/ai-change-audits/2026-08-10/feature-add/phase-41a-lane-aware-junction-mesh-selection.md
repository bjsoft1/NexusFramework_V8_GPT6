# Phase 41a: lane-aware junction mesh selection key

Date: 2026-08-10
Category: feature-add
Phase: 41a (Static Generator - Junction Mesh Selection, Lane-Aware)

## Context

Closing the "Static Generator" cluster of the current work batch (41, 41a, 42-44).
This phase was itself inserted earlier in the project's history (see
`ai-change-audits/2026-08-10/others/phase-41a-inserted-lane-aware-junction-mesh-selection.md`)
to close a gap the master-architecture audit found: nothing in the roadmap decided which
mesh piece to place at a junction where the connecting Highways have different lane
counts.

## Problem / Goal

Compute a mesh-selection KEY per HighwayPoint combining topology (Phase 36) with every
connected Highway's resolved lane count (Phase 37), distinguishing symmetric (same-lane)
from asymmetric junctions, with a documented tie-break for equal-lane-count 3+-way
junctions - without repeating V5's own recorded "duplicate-4 bug" (several distinct
lane/topology combinations sharing one flat enum value).

## Findings

1. **`ComputeJunctionType` (Phase 36) always requires a resolvable live `SourcePoint`**
   for every point involved, even for the 3+-connection (T/Cross/Multi) case - traced
   through `GatherNeighborDirections`/`ComputeJunctionType` in
   `NexusRepresentationGraph.JunctionResolver.cpp` before writing any new code. This
   means the JunctionType half of a selection key cannot be exercised with a purely
   synthetic, Landscape-free graph - only a real mapped Landscape can produce a
   resolvable `SourcePoint`.
2. **The lane-count/asymmetry half needs no geometry at all** - only
   `FNexusHighwayPoint::ConnectedHighwayIds` (a plain `TArray<FGuid>`, fully settable via
   `FNexusRepresentationGraph::AddPointToHighway`'s own public, Landscape-independent
   API) and each connected Highway's `LaneCount`/City/State chain. This is also the
   ENTIRE new logic this phase actually introduces (JunctionType itself is pure Phase 36
   reuse) - split into its own function (`ComputeLaneAsymmetryKey`) specifically so it
   could be unit-tested with a synthetic graph, rather than bundled into one
   untestable-without-a-Landscape `ComputeSelectionKey` call.
3. **Chose a structured-data key (array of lane counts + booleans), not a flat enum**,
   specifically because V5's own recorded design history (`v5-complete-reference.md`)
   shows a real "duplicate-4 bug" where `Highway_6_4_T_Junction`/`Highway_6_2_T_Junction`/
   `Highway_4_2_T_Junction`/`Highway_Cross_Junction` all shared enum value 4 before being
   fixed - a flat enum requires remembering to add a new value per combination and is
   exactly the kind of thing that regresses silently. A structured key (`TArray<int32>`
   equality) cannot collapse two different combinations to the same value by construction.
4. **Tie-break rule chosen deliberately, not left implicit**: first-in-
   `ConnectedHighwayIds`-order among Highways tied for the highest lane count. Considered
   and rejected: FGuid comparison (stable but arbitrary/unintuitive to a human reading
   the data), "leave undefined" (violates the phase's own explicit completion criterion
   requiring a documented rule).

## Changes

- New: `Source/NexusFrameworkEditor/Public/Generation/NexusJunctionMeshSelector.h` +
  `Private/.../NexusJunctionMeshSelector.cpp` - `FNexusJunctionMeshSelectionKey`
  (structured key + informational `PriorityHighwayId`/`HasAmbiguousPriority` fields) and
  `FNexusJunctionMeshSelector` (`ComputeLaneAsymmetryKey` + `ComputeSelectionKey`).
- New: `Source/NexusFrameworkEditor/Private/Generation/NexusJunctionMeshSelectorCommands.cpp`
  - `Nexus.Generation.TestJunctionMeshSelection`, 6 synthetic cases covering every
  completion criterion, buildable/runnable with zero Landscape/map setup.
- `phases/phase-41a.md` - Status set to Ready for Review; completion criteria annotated
  as hand-traced-but-not-yet-executed (honest about what an agent can and cannot verify
  without launching the editor).

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` -
  **Result: Succeeded**, 5 actions (incremental), 0 errors.
- **No automated test run/added** - per `AGENT-RULES.md`'s Agent Testing Policy. The 6
  synthetic cases were hand-traced against the algorithm for this record, not executed
  (no editor launch) - see phase-41a.md's own Manual Verification section for the single
  command (`Nexus.Generation.TestJunctionMeshSelection`, no map needed) that produces
  real PASS/FAIL output.

## Result

A real, structured junction mesh-selection key now exists, consuming only Phase 36/37
output as required, with a documented tie-break rule and a synthetic test harness that -
uniquely among this session's Generation-stage work - needs no Landscape/mapped test
data to actually run.

## Important Notes

- **This phase does not place or reference any actual mesh asset** - per its own Not
  Allowed rule ("do not hardcode specific mesh asset references beyond what's needed to
  prove the selection KEY is correct"). Wiring `FNexusJunctionMeshSelectionKey` to real
  junction mesh assets is future Static Generator work, not invented speculatively here.
- **`FNexusJunctionMeshSelectionKey::operator==` deliberately excludes
  `PriorityHighwayId`/`HasAmbiguousPriority`** - two different physical junctions with
  the same topology/lane combination need the same mesh piece regardless of which
  specific Highway is "through" at each one. Worth knowing before using this key as a
  cache/lookup key elsewhere - equal keys do NOT mean identical `PriorityHighwayId`.
