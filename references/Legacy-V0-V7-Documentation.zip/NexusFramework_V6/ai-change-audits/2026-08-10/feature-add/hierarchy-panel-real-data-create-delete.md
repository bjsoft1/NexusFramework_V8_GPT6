# Hierarchy Panel — Real Data + Create/Delete State/City

Date: 2026-08-10
Category: feature-add
Phase: N/A (ad-hoc, direct user request — not a `/TODO` phase pickup)

## Context

User asked why the Hierarchy panel's right-click menu only showed Delete/Rename/Focus
and not Create City/Create State/Create Highway. Answer: it never had them — the whole
Hierarchy tree has been Phase 04's hardcoded placeholder rows
(`FNexusPlaceholderTreeItem`, "Placeholder State > Placeholder City > ...") since that
phase, with no later phase ever wiring it to real data (already flagged as an open gap
in `ai-change-audits/README.md`'s "Current open threads" from an earlier session:
"Hierarchy tree panel is still 100% hardcoded placeholder data"). User asked for it to
be built, live, with iterative clarifications mid-session:

- Real dynamic Create AND Delete (not just Create).
- Create dialog fields: Name, Code, Description; Id never editable.
- Name/Code required, no duplicates - "just put basic validation."
- On reflection, replaced with a simpler flow: no modal dialog at all - Create
  auto-generates "New City N"/"New State N", selects it immediately, and the ALREADY-
  EXISTING Details panel (generic `IStructureDetailsView`, same mechanism Phase 25 uses
  for Debug categories) is where the user actually names/describes it - "we already has
  details panel this should we need to used as possible."
- Deleting down to zero States (or zero Cities) must auto-recreate a default
  State/City/Highway chain, generically/reusably ("we need to use this method later in
  many places") - implemented for State/City; Highway deliberately excluded (see
  Findings).

## Problem / Goal

Replace the Hierarchy tree's Phase 04 placeholder content with real
State/City/Highway/HighwayPoint data read from the active `UNexusConfigAsset`, with
working Create/Delete/Assign actions and live Details-panel editing - a genuine
visible-UI feature matching the user's own standing preference (this session's earlier
memory note) for visible Editor UI work over console-only verification.

## Findings

- Phase 12's own `Nexus.Mapping.CreateCity`/`CreateState`/`AssignHighwayToCity`/
  `AssignHighwayInterCity`/`SetCityState` console commands already did the real backend
  work (`FNexusMapping::FindOrCreateCityByName` etc.) - this task's job was the UI layer
  and a few new Mapping-layer capabilities (auto-name creation, deletion, the
  never-empty guarantee), not re-deriving Phase 12's own logic.
- Highways are Landscape-derived (Phase 11's `MapHighways`), never manually created.
  The user's own "auto-recreate a default chain on total delete" ask names a Highway
  too, but fabricating a fake one with no real `OrderedPointIds`/geometry would silently
  break every downstream consumer that assumes Highway membership implies real
  Landscape-backed geometry (Static Generator, Debug rendering, Diagnostics). Decided:
  `FNexusMapping::EnsureHierarchyHasDefaults` covers State and City only (both pure,
  Nexus-owned organizational entities, safe to fabricate) - Highway deletion/auto-
  recreation is not implemented, flagged here rather than silently built wrong.
- `FUIAction::CreateSP`'s payload-argument binding deduces the bound member function's
  expected parameter types via `std::decay_t<VarTypes>`, which strips references -
  handler methods bound this way (`HandleFocusItem` etc.) must take their payload
  arguments BY VALUE (`FTreeItemPtr`/`FGuid`), not `const&`; the const-ref versions
  failed to compile with a confusing cascade of "AddMenuEntry can't convert FText to
  FUIAction" errors (the real failure was several lines earlier, in the `CreateSP` call
  itself - the AddMenuEntry errors were downstream noise from the same broken
  expression).
- `IStructureDetailsView`'s own `OnFinishedChangingProperties` callback is not safe to
  rebind (`SetStructureData`) from within - doing so (to refresh a renamed entity's
  tree-row label immediately) risks re-entrancy. Deferred instead: a
  `HierarchyLabelRefreshPending` flag set in the commit handler, consumed on the next
  `Tick()` (by which point the details view's own call stack has unwound) - same
  deferred-tick pattern already available on this widget for Diagnostics refresh.
- Undo/redo for a Hierarchy entity edit needed the SAME `NotifyPreChange`/
  `FScopedTransaction` plumbing Phase 26a already built for Debug category edits, but
  with an IMPORTANT difference on the post-undo rebind: a Debug category's
  `FNexusDebugRenderConfig*` stays valid across undo (owned by a `TUniquePtr` inside a
  `TMap`, per that system's own dangling-pointer fix), but a Hierarchy entity's pointer
  is INTO a plain `TArray` (`config->Cities`/`States`/etc.) that undo/redo can reallocate
  wholesale - reusing the old pointer after undo would be exactly the class of bug
  `RuntimeConfigs` was redesigned to avoid. Generalized both callbacks
  (`OnDetailsViewFinishedChangingProperties`/`HandleConfigAssetPostEditUndo`) via a new
  `EDetailsViewContentMode` enum (replacing the old single
  `IsDetailsViewShowingDebugCategory` bool) so each path does the correct one of
  "sync to a second copy" (Debug category) vs. "re-resolve by Id, never reuse the old
  pointer" (Hierarchy entity).

## Changes

- `Public/Representation/NexusState.h`/`NexusCity.h`/`NexusHighway.h` - added
  `FString Description;` (free-text, no uniqueness rule) to all three.
- `Public/Mapping/NexusMapping.h` + `Private/Mapping/NexusMapping.CityStateMapping.cpp`
  (Phase 12) - added:
  - `ValidateCityNameAndCode`/`ValidateStateNameAndCode` (excludeId param so a RENAME
    check doesn't trip on the entity's own current values).
  - `CreateNewCityWithAutoName`/`CreateNewStateWithAutoName` ("New City N"/"New State N",
    first untaken N, Name and Code both set to the same generated string).
  - `RemoveCity`/`RemoveState` (unassigns member Highways/Cities rather than
    cascade-deleting them - "never silently drop Landscape-backed data").
  - `EnsureHierarchyHasDefaults` (called automatically from the bottom of both `Remove*`
    functions - see Findings for the State/City-only scope decision).
- `Public/UI/NexusUIDialogs.h`/`.cpp` - added `ShowError` (simple Ok-only message
  dialog, used for the deferred Name/Code conflict warning).
- New `Public/UI/NexusHierarchyTreeItem.h` - replaces `FNexusPlaceholderTreeItem` for the
  Hierarchy tree; `Public/UI/NexusPlaceholderTreeItem.h`/`NexusPlaceholderDetails.h`
  deleted (fully superseded, confirmed unused elsewhere by search).
- `Private/UI/SNexusFrameworkPanel.h`/`.cpp` (Phase 03/04/24/25) - the Hierarchy half of
  this widget rewritten: `BuildHierarchyTreeFromConfig` (real State > City > Highway >
  HighwayPoint tree from the active config, with synthetic "(Unassigned Cities)"/
  "(Unassigned Highways)" grouping rows so an unassigned entity is still visible rather
  than silently hidden); `RefreshHierarchyTree` (rebuild + reselect-by-Id, called after
  every mutation); real context menu (Create State/Create City always available, Delete
  State/Delete City, Assign to State/Assign to City submenus, Focus - reusing
  `FNexusMapping::ComputeCityCenter`/live HighwayPoint locations); `EDetailsViewContentMode`
  generalization (see Findings). The Debug Tree/Diagnostics sections of this file are
  unchanged.

## Verification

Build-only (`project-specifications/AGENT-RULES.md`'s Agent Testing Policy - no
automated tests, no editor launch by this agent):

```
Build.bat NexusFrameworkEditor Win64 Development -project=NexusFramework.uproject
```

Result: **Succeeded** after fixing the `CreateSP` payload-signature mismatch above (first
attempt failed with a cascade of `AddMenuEntry`/`CreateSP` errors, all in
`SNexusFrameworkPanel.cpp`); second attempt clean; a follow-up no-op build confirmed
"Target is up to date."

No in-editor verification was performed or attempted. Manual QA needed:

1. Enter Landscape Mode on a mapped Landscape. Right-click in the Hierarchy tree -
   confirm "Create State..."/"Create City..." are always present.
2. Click "Create State" - confirm a "New State 1" row appears, selected, and the Details
   panel shows it with editable Name/Code/Description. Edit Name - confirm the change
   persists (re-select elsewhere and back) and the tree row's label updates (may take
   one frame - see HierarchyLabelRefreshPending).
3. Try renaming two States to the same Name, or the same Code - confirm the "Name/Code
   Conflict" warning dialog appears (does NOT auto-revert the value - see this record's
   own Findings on why).
4. Right-click a State - "Create City (in this State)..." - confirm the new City is
   nested under that State in the tree.
5. Right-click a City - "Assign to State" submenu lists every State; "Delete City"
   prompts to confirm, then unassigns (not deletes) any member Highways.
6. Delete every City - confirm a "New City 1" reappears automatically (unassigned, under
   "(Unassigned Cities)"). Delete every State - confirm "New State 1" reappears AND (if
   Cities were also empty) a "New City 1" appears already assigned to it.
7. Right-click a Highway - "Assign to City" submenu; "Focus" moves the viewport camera.
8. Ctrl+Z/Ctrl+Y after a Create/Delete/rename - confirm the tree and Details panel both
   correctly revert/reapply (this is the specific mechanism this record's Findings
   section flags as generalized-but-unverified-live).

## Result

Hierarchy panel build-implemented end-to-end: real data, Create/Delete for State/City,
Assign-to submenus for City→State and Highway→City, live Details-panel editing with
undo/redo, and a generic "never empty" auto-default guarantee. Highway Create/Delete
deliberately not implemented (Landscape-derived - see Findings). Status: complete,
build-verified, awaiting the user's own in-editor QA per the checklist above.

## Important Notes

- `FNexusMapping::EnsureHierarchyHasDefaults` is public and reusable by design (the
  user's own "we need to use this method later in many places" ask) - any future delete
  path (a console command, a different UI) gets the same guarantee automatically by
  calling `RemoveCity`/`RemoveState`, without having to remember to call it separately.
- Renaming a Hierarchy entity to an empty or duplicate Name/Code via the Details panel is
  WARNED about (a message box) but not blocked or auto-reverted - a real gap if a user
  ignores the warning and leaves a duplicate/empty value in place. A hard revert would
  need to interact with the same edit-transaction/details-view timing this record's
  Findings section already flags as re-entrancy-risky; left as an honest, documented
  limitation rather than a rushed fix.

## Follow-up — 2026-08-10 — config self-heal, empty-config seeding, Delete Highway

### Context

User reported, after the above was already build-verified: "the hierarchy nothing have
and i am not able to click or create any things" - the panel was live, but every
Create/Delete action was silently inert. Requested three improvements in the same
message: (1) auto-generate the config asset if the system doesn't have one yet
("this should be already done" - user suspected it existed but wasn't reliable); (2) an
empty config should auto-generate a default State > City > Highway; (3) pull real
segment data from the Landscape into the tree (pointed at Phase 07/10/11's
HighwayPointId/tangent-adjacent work and V5 precedent if V6's own docs were unclear on
this - they were not; see Findings).

### Root cause (the reported bug)

`SNexusFrameworkPanel` always read `UNexusFrameworkSubsystem::GetActiveConfig()`, which
is ONLY ever set by `FNexusLandscapeModeExtension::OnEditorModeIDChanged`'s
entering-Landscape-Mode branch (Phase 15's automatic enable flow). That handler only
fires on the EDGE (transitioning INTO Landscape Mode this session) - if the editor
starts already in Landscape Mode (UE persists the last-active editor mode across
restarts) the transition event never fires again, `ActiveConfig` stays null for the
entire session, and the Hierarchy tree/every Create/Delete/Assign handler silently
no-ops or shows an easy-to-miss "No Active Config" dialog. This matches the reported
symptom exactly and did not require a Landscape/data problem to reproduce.

### Findings

- The full "grab segment data from Landscape" pipeline (user's item 3) already exists
  and was already wired in: `ALandscape` spline control points ->
  `FNexusMapping::MapControlPoints` (Phase 10, HighwayPointId assignment) ->
  `FNexusMapping::MapHighways` (Phase 11, chain walk into `FNexusHighway::
  OrderedPointIds`) -> `ReconcileMappingStage` (Phase 16) -> `BuildHierarchyTreeFromConfig`
  already reads `config->Highways`/`HighwayPoints` directly. No V5 research was needed -
  V6's own phase-10/phase-11 docs and `NexusMapping.Reconciliation.cpp` already fully
  and unambiguously specify this pipeline; it just wasn't being *reached* because of the
  root cause above (no config -> nothing to map into). Real Landscape-derived Highways
  will show under a City once assigned, or under "(Unassigned Highways)" until then -
  City/State creation has no Landscape equivalent and is correctly never automatic.
- User's item 2 ("empty config should auto-generate State > City > Highway") directly
  overlaps this record's own earlier documented decision to keep
  `EnsureHierarchyHasDefaults` State/City-only (never fabricate a Highway, since
  Highways are Landscape-derived and a fake one could coexist with real ones forever
  with no way to remove it). Resolved by splitting these into two different trigger
  points rather than relaxing that decision: `EnsureHierarchyHasDefaults` (delete-to-
  empty, where real Landscape Highways may already coexist) stays State/City-only,
  unchanged; a NEW, narrower `SeedDefaultHierarchyIfEmpty` (config-resolve time) fires
  only when ALL FOUR arrays - States, Cities, Highways, AND HighwayPoints - are empty,
  i.e. provably nothing has ever been mapped from Landscape into this config yet. Only
  in that specific state is fabricating a placeholder Highway (zero OrderedPointIds)
  safe.
- The placeholder Highway from `SeedDefaultHierarchyIfEmpty` would otherwise become a
  permanent orphan the moment real Landscape spline data is later mapped in (Highway
  deletion was previously not implemented at all, deliberately, per this record's
  original Findings). Resolved with a narrowly-scoped `RemoveEmptyHighway` - deletable
  ONLY when `OrderedPointIds.Num() == 0`, which a real MapHighways-produced Highway can
  never be (every real chain has at least one point) - so this can only ever delete a
  placeholder, never real Landscape-backed data, without needing to special-case
  "is this one fake" some other way.

### Changes

- `Public/Mapping/NexusMapping.h` + `Private/Mapping/NexusMapping.CityStateMapping.cpp`
  - `SeedDefaultHierarchyIfEmpty(config)`: no-op unless States/Cities/Highways/
    HighwayPoints are ALL empty; otherwise creates "New State 1" > "New City 1" >
    "New Highway 1" (CityId assigned, matching the user's own example layout).
  - `RemoveEmptyHighway(config, highwayId)`: removes a Highway only if it resolves AND
    has zero `OrderedPointIds`; returns false (no-op) otherwise.
- `Private/Mapping/NexusMapping.EnableFlow.cpp` - `RunAutomaticEnableFlow` now calls
  `SeedDefaultHierarchyIfEmpty` right after `ReconcileMappingStage`, so both existing
  triggers (Landscape Mode entry AND the new panel self-heal below) get seeding for
  free without duplicating the empty-check logic.
- `Private/UI/SNexusFrameworkPanel.h`/`.cpp`
  - New `ResolveActiveConfig(forceResync)`: if `ActiveConfig` is already set and no
    resync was requested, returns it as-is; otherwise resolves the active Landscape and
    re-runs the same `RunAutomaticEnableFlow` + `SetActiveConfig` +
    `RestoreRuntimeConfigsFromConfigAsset` sequence `OnEditorModeIDChanged` uses -
    called from `RefreshHierarchyTree` (self-heal, `forceResync=false`, so an existing
    config is never redundantly re-synced on every tree refresh) and from the new
    button below (`forceResync=true`).
  - New "Re-sync from Landscape" button next to the Hierarchy label
    (`HandleResyncFromLandscapeClicked`) - a visible, discoverable, user-triggered way
    to pull in new/changed Landscape spline segments on demand, not only automatically/
    invisibly on Landscape Mode entry; shows a `ShowError` dialog if no Landscape
    resolves at all.
  - `RefreshHierarchyTree` now appends a single non-interactive `InfoMessage` tree row
    (new `ENexusHierarchyItemType` value) explaining WHY the tree is empty (no
    Landscape actor in the level, vs. a Landscape found but its level never saved to
    disk) in the one remaining case `SeedDefaultHierarchyIfEmpty` can't fix - no
    `ALandscape` resolves at all, so no config can exist (Landscape is the identity
    root - see `FNexusConfigAssetIO::LoadOrCreateConfigAsset`).
  - New "Delete Highway" context-menu entry - always visible on a Highway row, but only
    enabled (`FCanExecuteAction`) when `OrderedPointIds.Num() == 0`; disabled tooltip
    explains real Highways can only be unassigned from a City, never deleted.
    `HandleDeleteHighway` confirms via `ConfirmDestructiveAction` then calls
    `RemoveEmptyHighway`.

### Verification

Build-only (`AGENT-RULES.md`'s Agent Testing Policy):
```
Build.bat NexusFrameworkEditor Win64 Development -project=NexusFramework.uproject
```
Result: **Succeeded** on the first attempt; a follow-up no-op build confirmed "Target is
up to date."

No in-editor verification performed. Manual QA needed:

1. Restart the editor fresh already IN Landscape Mode from a prior session (or just open
   the Nexus tab without toggling Landscape Mode at all) - confirm the Hierarchy tree is
   no longer permanently blank: either real/seeded data appears, or the new
   `InfoMessage` row explains why not.
2. On a level with no `ALandscape` at all - confirm the tree shows "No Landscape actor
   found..." and Create still shows the existing "No Active Config" dialog (unchanged
   behavior, now reachable in a state the user can actually diagnose).
3. On a freshly mapped Landscape with a spline network but never opened via this panel
   before - confirm real Highways/HighwayPoints appear under "(Unassigned Highways)"
   (or under a City once assigned), sourced from the actual spline data, not
   placeholders.
4. On a Landscape with zero spline data mapped - confirm "New State 1 > New City 1 >
   New Highway 1" appears automatically, and that "Delete Highway" is enabled for that
   placeholder Highway specifically.
5. After manually mapping real spline data later (or via "Re-sync from Landscape") -
   confirm "Delete Highway" becomes disabled (grayed, with the real-data tooltip) for
   any Highway that now has real points, and that the seeded placeholder Highway (if
   still present, unedited) is unaffected by the resync.
6. Click "Re-sync from Landscape" with no Landscape in the level - confirm the "No
   Landscape" error dialog appears instead of a silent no-op.

### Result

The reported "nothing works" bug is root-caused to `ActiveConfig` only ever being set on
the Landscape-Mode-entry transition event, now self-healed from the panel itself on
every refresh and via an explicit "Re-sync from Landscape" button. Empty-config
bootstrapping (State > City > Highway) is implemented as a narrowly-scoped, safe
addition (`SeedDefaultHierarchyIfEmpty`) that cannot coexist-forever with real
Landscape data thanks to the new points-based `RemoveEmptyHighway` escape hatch. The
Landscape-segment-to-tree pipeline itself (user's item 3) required no new code - it was
already correctly implemented in Phase 10/11/16, just previously unreachable due to the
root cause. Build-verified; awaiting the user's own in-editor QA per the checklist
above.
