# Phase 19 — Representation — Highway/City/State Graph

Task: Phase 19
Category: feature-add
Phase: phases/19
Status: Ready for Review
Completed Date: 2026-08-10
Completed Time: 02:13 NST (+0545)

## Context

Picked up via `/TODO`. `agent-todos/active/` and `agent-todos/ready-for-development/`
were both empty (only `.gitkeep`), so per the TODO workflow this fell through to the
roadmap phases: `PHASE-STATUS.md` showed Phase 19 as the lowest-numbered `Not started`
phase, first of the "Representation" arc (18-22) continuing after Phase 18's
single-phase pickup.

## Problem / Goal

Implement `project-specifications/phases/phase-19.md`: the full in-memory
State->City->Highway->HighwayPoint graph with FGuid-keyed maps, `AddState`/`AddCity`/
`AddHighway`/`AddPointToHighway`-style mutation methods, O(1) lookup by any ID, and the
InterCityHighway cross-reference — V6's equivalent of V5's `FNexusWorldData`.

## Findings

1. **This is deliberately a NEW, separate in-memory structure, not a rework of
   `UNexusConfigAsset`.** `UNexusConfigAsset` (Phase 13) stays Mapping's own persisted
   `TArray`-based storage, still read/written by `FNexusMapping`'s existing linear
   `FindByPredicate` lookups exactly as before — untouched by this phase. The new
   `FNexusRepresentationGraph` is populated FROM a `UNexusConfigAsset` (Mapping's
   output) via `PopulateFromConfigAsset()`, matching the phase's own "Do not read
   Landscape directly - only via Mapping's output" boundary and `05-v6-data-flow.md`'s
   "Representation snapshot" framing (Static Generator/Runtime Compiler both run off
   "the same Representation snapshot" — the word used there is literally "snapshot",
   confirming a rebuilt-fresh value-copy graph is the intended shape, not a live wrapper
   over Mapping's arrays).
2. **`v5-complete-reference.md` does not document `FNexusWorldData`'s own field/method
   shape** (only cross-references from other structs' comments, e.g. `SitableStructures`
   TMap key, `WorldData.RemoveHighway`) — V5's own container internals weren't in the
   original extraction. Phase 19's design was worked from the phase file's explicit
   wording (`AddState`/`AddCity`/`AddHighway`/`AddPointToHighway`, FGuid-keyed maps, O(1)
   lookup) rather than a literal V5 port.
3. **Find\*() returns `const` pointers only; the four `TMap`s are `private`.** This makes
   the "no code outside this graph's own methods mutates the maps directly" completion
   criterion true by construction (only `Add*()`/`AddPointToHighway()` can insert or
   modify an entry), not just a spot-check convention — a stricter reading than "Add\*
   happens to be how everyone currently does it."
4. **`AddPointToHighway` is the graph-wide O(1) `ConnectedHighwayIds` maintenance Phase
   18's own header comment forward-referenced**: `NexusHighwayPoint.h`'s
   `RecomputeConnectedHighwayIds` comment says "Phase 18 provides this point-scoped
   recompute only; Phase 19/20 build the full graph-wide O(1) version and own calling it
   after every membership-changing mutation." Since a mutation always knows exactly
   which Highway a point is being attached to, `AddPointToHighway` updates that point's
   `ConnectedHighwayIds` with a single `Contains`+`Add` (O(1)) instead of Phase 18's
   O(AllHighways) rescan — no future full-graph rescan is needed as long as all
   membership changes route through this method.
5. **`GetInterCityBridgedCities`** is the phase's specific "InterCityHighway
   cross-reference" ask — deliberately narrower than a general relationship-query API
   (that's Phase 20's own title, "Representation - Relationship Queries", and explicitly
   not this phase's job): it only resolves one Highway's already-stored `CityId`/
   `EndCityId` pair (Phase 12's Mapping output) into two live `FNexusCity` pointers
   within this graph, proving the O(1) `FindCity` lookup actually closes the loop on
   Mapping's stored Guids rather than leaving callers to dereference both by hand.
6. **`PopulateFromConfigAsset` derives HighwayPoint membership by walking each Highway's
   own `OrderedPointIds`**, not any field stored on the point — matching
   `NexusHighwayPoint.h`'s own "derived, never hand-edited" rule and the same walk
   order V5's `ComputeSyncDiff` used (a junction point shared by two Highways is
   cross-referenced once per owning Highway). A points-not-yet-claimed-by-any-Highway
   pass follows, so a point mapped by Phase 10 but not yet chain-walked by Phase 11
   still lands in the graph rather than being silently dropped. A local
   `TMap<FGuid, const FNexusHighwayPoint*>` built once up front keeps this whole
   population O(States+Cities+Highways+Points) instead of O(Highways × Points).
7. **Build was blocked mid-session by a running `UnrealEditor.exe` with Live Coding
   active** (`Build.bat` failed immediately: "Unable to build while Live Coding is
   active"). Per this project's care-before-destructive-actions rule, the agent asked
   the user rather than closing the editor itself; user closed it, build then succeeded
   on retry.

## Changes

- New `Source/NexusFrameworkEditor/Public/Representation/NexusRepresentationGraph.h` —
  `FNexusRepresentationGraph` class: private `TMap<FGuid, FNexusState/City/Highway/
  HighwayPoint>` ×4; `Reset()`; `PopulateFromConfigAsset(const UNexusConfigAsset&)`;
  `AddState`/`AddCity`/`AddHighway` (insert-or-overwrite by the struct's own Id, return
  the stored copy); `AddPointToHighway(HighwayId, Point)` (insert-if-new + append
  membership + O(1) `ConnectedHighwayIds` update); `FindState`/`FindCity`/`FindHighway`/
  `FindHighwayPoint` (O(1), `const` pointer, no linear scan); `GetInterCityBridgedCities`;
  `NumStates`/`NumCities`/`NumHighways`/`NumHighwayPoints`. Plain C++ class (no
  `NEXUSFRAMEWORKEDITOR_API`/reflection), matching `FNexusMapping`/
  `FNexusLandscapeReader`'s existing convention for module-internal, non-Blueprint
  utility/container classes.
- New `Source/NexusFrameworkEditor/Private/Representation/NexusRepresentationGraph.cpp`
  — method bodies + `Nexus.Representation.DumpGraph` console command (Findings above),
  following the `FAutoConsoleCommand` verification-hook pattern every phase since 05 has
  used.
- `project-specifications/phases/phase-19.md` — Status → `Ready for Review`; both
  Completion Criteria checked off (both are structural/code-inspection facts — private
  maps + `TMap::Find`-based lookup — provable by reading the header, not requiring an
  editor session); added a "Manual verification" section with exact
  `Nexus.Representation.DumpGraph` steps for the user.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded** (second attempt, after the user closed the Live-Coding-active
  editor blocking the first attempt — see Findings #7). `NexusRepresentationGraph.cpp`
  and the regenerated `Module.NexusFrameworkEditor.cpp` compiled clean, 0 errors.
- `node html-docs/build.js` — regenerated `PHASE-STATUS.md`/`phase-data.js`/
  `phase-tracker.html` after the status write.
- **No automated tests written or run** — per `AGENT-RULES.md`'s Agent Testing Policy.
  `Nexus.Representation.DumpGraph`'s log-output check (see phase file's "Manual
  verification" section) is left for the user's own in-editor session against a real
  config asset with an InterCityHighway.

## Result

Implementation complete, build-verified. Both Completion Criteria are checked off as
structural facts proven by the header's own access control (private maps, const-only
Find*); the new `Nexus.Representation.DumpGraph` console command is left for the user to
run in-editor as a real-data sanity check, not because either criterion depends on it.

## Important Notes

- `FNexusRepresentationGraph` is not yet wired into any consumer (subsystem, panel,
  Mapping stage) — this phase only establishes the container + query API per its own
  Allowed list. `UNexusConfigAsset`/`FNexusMapping` remain the actual persisted
  read/write path used everywhere else in the codebase today; only the new
  `Nexus.Representation.DumpGraph` console command currently builds a
  `FNexusRepresentationGraph` instance (as a local, transient rebuild-and-discard, not
  stored anywhere).
- Phase 19 deliberately does NOT implement `Remove*`/`Delete*` mutators (V5's
  `FNexusWorldData` has a `Remove`/`Delete` family) or general relationship-query
  methods ("all Highways for a City", "all Cities for a State") — the phase file's
  Allowed list only names `Add*`-style mutation + ID lookup; general relationship
  queries are Phase 20's own explicit title/scope.
