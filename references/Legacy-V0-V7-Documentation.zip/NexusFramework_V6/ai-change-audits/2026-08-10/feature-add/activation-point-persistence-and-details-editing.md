# Activation Point Persistence, Details Panel Editing, Undo/Redo

Date: 2026-08-10
Category: feature-add
Phase: 21 (base struct owner) / 46 (renderer owner) — prerequisite work requested
directly by the user before starting Phase 49, follow-up to the same-day
`activation-point-shared-base-struct-extension.md` record.

## Context

Immediately after that record's structure-only field additions (`Code`/`Name`/
`Description`/`IsEnabled`/`DebugOverride` on `FNexusActivationPoint`) were reviewed,
direct user instruction before continuing to Phase 49: `FNexusDebugInstanceOverride`
data will be edited from the Details Panel, so make sure it supports undo/redo and
saves inside the main editor config (`UNexusConfigAsset`).

## Problem / Goal

The previous record deliberately left `FNexusActivationPoint` un-wired - no
persistence, no Details Panel binding, no undo/redo, per the user's own "structure
only, I will review before you continue" instruction. This record resolves exactly
what was flagged as deferred: give the base struct (and therefore `DebugOverride`,
which lives on it) a real home in `UNexusConfigAsset`, wire it into the same
Details-Panel/Hierarchy-tree/undo-redo infrastructure every other Nexus entity
(State/City/Highway/HighwayPoint) already uses, and make it actually visible (a debug
override with no visible effect would be pointless).

## Findings

- Every other Nexus entity gets undo/redo and persistence "for free" the same way:
  by being a plain `UPROPERTY` `TArray<...>` directly on `UNexusConfigAsset` (a
  `UDataAsset`), edited through `IStructureDetailsView` with `NotifyPreChange`/
  `OnFinishedChangingProperties` wrapping each edit in `FScopedTransaction` +
  `config->Modify()`. This machinery in `SNexusDetailsPanel.cpp` is already fully
  generic over `ENexusHierarchyItemType` - no per-type undo/redo code exists to
  duplicate; adding a new `case` to one `switch` was the entire undo/redo change.
  `UNexusConfigAsset::PostEditUndo()` needed NO changes - it only special-cases
  `DebugCategoryConfigs` because that field has a SEPARATE live copy in
  `FNexusDebugCategoryRegistry`'s `RuntimeConfigs`; `ActivationPoints` has no such
  second copy (single source of truth, like `Highways`/`HighwayPoints`), so it's
  already covered by the transaction system generically.
- `FNexusActivationPointTestStore` (Phase 46/48's session-only storage) is NOT a
  `UObject` and holds no `UPROPERTY` - by construction it can never support real
  undo/redo or persistence, confirming it was never a candidate for what the user is
  now asking for. It remains exactly what its own header comment already says it is:
  Phase 45/48's dummy-payload-type proof mechanism, deliberately session-only.
  Untouched by this change.
- Phase 46's own flagged "real storage architecture" question (flat array? per-type
  arrays? `FInstancedStruct`-based heterogeneous storage for varying payload types?)
  is about SPECIALIZED payload persistence (Traffic Light's sub-offsets, etc.), which
  doesn't exist yet (Phase 50+). `DebugOverride`/`Name`/`Code`/`Description`/
  `IsEnabled` all live on the BASE struct, which has no payload - a flat
  `TArray<FNexusActivationPoint>` fully solves persistence for everything the user
  asked about without needing to resolve that harder, separate question. Confirmed
  this explicitly rather than assuming it away.
- A real, persisted-but-invisible Activation Point would be a confusing half-feature -
  the whole point of `DebugOverride` is a VISUAL effect. Decided to extend Phase 46's
  generic `RenderActivationPoints` to draw from BOTH the test store (unchanged) and
  the new real array, through one shared per-instance helper (`DrawOneActivationPoint`)
  - "debug visualization represents real authoring data" (the user's own stated
  principle from the original prerequisite-work request) is now literally true: a
  Details-Panel-created, real ActivationPoint renders through the identical code path
  a test one does, not a second/different renderer.
- Deliberately did NOT redirect the Phase 48 Gizmo tool
  (`NexusActivationGizmoTool.cpp`) to the real array in this same pass - it still only
  reads/writes `FNexusActivationPointTestStore`. The user's request was specifically
  about Details-Panel editing; gizmo-dragging a real, config-persisted point is a
  distinct capability this pass does not claim to provide. Flagged explicitly (see
  Important Notes) rather than silently leaving a gap the user might assume was
  covered.
- Reused the EXISTING `ENexusDetailsTargetMode::HierarchyEntity` + a new
  `ENexusHierarchyItemType::ActivationPoint` value, rather than inventing a new
  `Mode` - an ActivationPoint is conceptually a Hierarchy entity (nested under its
  anchor HighwayPoint), exactly like State/City/Highway/HighwayPoint already are;
  `SNexusDetailsPanel::RebindToCurrentTarget`'s existing `switch
  (target.HierarchyItemType)` already generically resolves any of them via
  `FNexusMapping::Find*ById` - one new `case` was sufficient, `NexusPanelSharedTypes.h`
  itself needed zero changes.

## Changes

- `Public/Mapping/NexusConfigAsset.h` - new `TArray<FNexusActivationPoint>
  ActivationPoints` (`UPROPERTY(VisibleAnywhere, BlueprintReadOnly)`), same shape as
  `Highways`/`HighwayPoints`. `#include "Representation/NexusActivationPoint.h"` added.
- `Public/UI/NexusHierarchyTreeItem.h` - added `ActivationPoint` to
  `ENexusHierarchyItemType`.
- `Public/Mapping/NexusMapping.h` + new `Private/Mapping/NexusMapping.ActivationPoint.cpp`
  (new file, matching this class's existing per-responsibility `.cpp` split
  convention) - `FindActivationPointById`, `CreateActivationPointAtHighwayPoint`
  (fails/returns an invalid Guid if the anchor HighwayPoint doesn't resolve - never
  fabricates an unanchored point), `RemoveActivationPoint`. Same `config.Modify()`-
  before-every-real-mutation convention as every other CRUD helper in this class.
- `Private/UI/SNexusHierarchyPanel.h/.cpp`:
  - `BuildHierarchyTreeFromConfig`'s `makeHighwayPointChildren` now nests each
    HighwayPoint's own real `config->ActivationPoints` (filtered by `HighwayPointId`)
    as tree children, via a new `makeActivationPointChildren` lambda.
  - `OnTreeSelectionChanged`'s real-entity check now includes `ActivationPoint`
    (publishes it as a `HierarchyEntity` Details target, same as every other type).
  - Context menu: a HighwayPoint row now has a "Create Activation Point" entry; an
    ActivationPoint row has "Focus" + "Delete Activation Point".
  - `HandleFocusItem` now resolves an ActivationPoint's location via
    `FNexusMapping::FindActivationPointById` + `FindHighwayPointById` +
    `ComputeFinalTransform` (the same composed-offset transform the renderer/Phase 21
    already use - never the raw anchor location).
  - New `HandleCreateActivationPoint(FGuid highwayPointId)`/
    `HandleDeleteActivationPoint(FTreeItemPtr item)`, same `FScopedTransaction` +
    confirm-dialog-on-delete pattern as every other Create/Delete handler in this file.
- `Private/UI/SNexusDetailsPanel.cpp` - `RebindToCurrentTarget`'s
  `switch (target.HierarchyItemType)` gained `case ActivationPoint:` resolving via
  `FNexusMapping::FindActivationPointById` + `FNexusActivationPoint::StaticStruct()` -
  the ENTIRE undo/redo + persistence wiring for Details-Panel edits (NotifyPreChange/
  OnDetailsViewFinishedChangingProperties/HandleConfigAssetPostEditUndo were already
  fully generic over `HierarchyEntity` targets - zero further changes needed there).
- `Private/Debug/NexusDebugRuntimeGroupRenderers.cpp` (`RenderActivationPoints`):
  - Extracted the existing per-point gating/resolve/draw logic into a new
    `DrawOneActivationPoint` helper.
  - Added an `IsEnabled` gate (skips rendering entirely if false - stronger than
    `IsAlwaysDraw`, matching that field's own "disabled = doesn't exist right now"
    contract).
  - Added `DebugOverride` handling: when `HasOverride` is set, the instance's own
    `Color`/`LineThickness` override the category's for its wireframe draw calls, and
    `TextColor`/`TextSize` override the label's color/font size - every OTHER instance
    in the same category is completely unaffected (the override is applied to a local
    copy, never written back into the shared category config).
  - Label text now prefers the new `Name` field when set, falling back to `Type`
    exactly as before (every existing test point leaves `Name` blank, so this is a
    no-op behavior change for Phase 45-48's own dummy-type tests).
  - Added a second loop over `activeConfig->ActivationPoints` (resolved via
    `GEditor`/`UNexusFrameworkSubsystem::GetActiveConfig`), calling the same
    `DrawOneActivationPoint` helper with `payloadInstance = nullptr` (base-only -
    real entries never have specialized payloads yet).
  - Updated the file's own top comment block (Revision, 2026-08-10) - the "no real
    Activation Point persistence exists" statement it originally made is now only
    true for SPECIALIZED payload data, not the base struct; explained the change and
    explicitly flagged that the Gizmo tool was NOT redirected in this pass.

## Verification

Build-only (`AGENT-RULES.md`'s Agent Testing Policy):
```
Build.bat NexusFrameworkEditor Win64 Development -project=NexusFramework.uproject
```
New source file (`NexusMapping.ActivationPoint.cpp`) triggered the expected Live Coding
"working set of source files changed" makefile-invalidation block; editor was already
closed (confirmed via `tasklist`) before building, so the build itself succeeded on the
first real attempt. Follow-up no-op build confirmed "Target is up to date."

No in-editor verification performed or attempted. Manual QA needed:

1. Enter Landscape Mode on a mapped Landscape. Right-click a HighwayPoint row in the
   Hierarchy tree - confirm "Create Activation Point" appears and creates a new,
   selected ActivationPoint row nested under that HighwayPoint.
2. With the new ActivationPoint selected, confirm the Details tab shows its fields
   (Name/Code/Description/OffsetLocation/OffsetRotation/IsEnabled/DebugOverride/...).
   Edit `Name`, then Ctrl+Z - confirm the name reverts; Ctrl+Y - confirm it re-applies.
3. Set `DebugOverride.HasOverride = true` and pick a distinct `Color`. Enable
   `Runtime.ActivationPoints` in the Debug Tree - confirm this specific point renders
   in the overridden color while any OTHER visible Activation Point (e.g. one added via
   `Nexus.Representation.AddTestActivationPoint`) keeps the category's normal color.
4. Set `IsEnabled = false` on the same point - confirm it disappears from the viewport
   even with the category visible and even if `IsAlwaysDraw` is also true.
5. Save the level/asset, close and reopen the editor (or just re-run
   `Nexus.Mapping.LoadOrCreateConfig`) - confirm the created ActivationPoint and its
   field values (including `DebugOverride`) are still present - real persistence, not
   session-only.
6. Right-click the ActivationPoint row - "Focus" - confirm the camera jumps to its
   composed offset location, not the anchor HighwayPoint's own location. "Delete
   Activation Point" (with confirm dialog) - confirm it's removed from both the tree
   and the viewport.

## Result

`FNexusActivationPoint` (including the new `DebugOverride`/`IsEnabled`/`Name`/`Code`/
`Description` fields from the prior record) is now genuinely editable from the Details
Panel, with real undo/redo and real persistence in `UNexusConfigAsset` - exactly what
was asked. Build-verified. Phase 49 may now proceed.

## Important Notes

- **Gizmo tool NOT redirected** - `NexusActivationGizmoTool.cpp` still only selects/
  drags points in the session-only `FNexusActivationPointTestStore`, not
  `config->ActivationPoints`. A real, Details-Panel-created ActivationPoint renders in
  the viewport (per this record's renderer change) but cannot currently be gizmo-
  dragged - only edited via the Details Panel's own property fields (OffsetLocation/
  OffsetRotation included). If gizmo-editing of real, persisted points is wanted, that
  is separate follow-up work, not covered here.
- **Specialized payload persistence remains unresolved** - `config->ActivationPoints`
  only ever holds base-only instances (no `PayloadStructType`/sub-point array support).
  This is unchanged from Phase 46's own flagged gap and is intentionally out of scope
  here - it only matters once a real specialized type (Phase 50+, Traffic Light) needs
  it.
- **No new validation added** - `FNexusMapping::ValidateMappingStage`/Phase 22's
  Representation-stage validation gate were not extended to check ActivationPoints
  (e.g. "HighwayPointId doesn't resolve" - though `CreateActivationPointAtHighwayPoint`
  already prevents creating one with an invalid anchor through the UI, a raw/imported
  entry could theoretically still have one). Not requested this pass; flagged for
  whichever future validation pass covers Activation Points.
