# Nexus.Status — quick-status console command

Date: 2026-08-10
Category: feature-add (small tooling addition, not tied to a specific roadmap phase)

## Context

Directly traceable to a real support cycle this session: the user reported "cannot see
debug lines / diagnostics" after a fresh editor build; several exchanges later the root
cause turned out to be that `ActiveConfig` was simply unset (Landscape Mode's automatic
enable flow hadn't run yet in the new editor session) - confirmed only after asking the
user to run `Nexus.Mapping.ValidateMappingStage` and read its "no active config"
message. Asked what debugging tool to build next; user chose "a quick-status console
command" over filling in the empty Infrastructure/Runtime debug groups.

## Changes

- `Private/Subsystem/NexusFrameworkSubsystem.cpp` — new `Nexus.Status` console command.
  Read-only, gathers and logs: resolved Landscape name (or "NONE"), whether
  `ActiveConfig` is set (and if not, a one-line explanation of what sets it and why it
  might not have run yet), and if set, its name/LandscapeId plus
  States/Cities/Highways/HighwayPoints/DebugCategoryOverrides counts.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, part of a larger batch build, 0 errors.
- Not run by the agent this session (Agent Testing Policy) - this command exists
  specifically to be the first thing a human runs when something looks blank, so its own
  manual check is simply "run it and confirm the log line matches whatever the real
  current state is" (no dedicated phase file - see Important Notes).

## Result

`Nexus.Status` is now the single first command to reach for when any other `Nexus.*`
command or debug rendering shows nothing - answers "is there even an active config
right now" in one call instead of needing to run an unrelated stage command and read
its own not-quite-diagnostic error message.

## Important Notes

- Not tied to any specific roadmap phase file - this is a small, general-purpose
  debugging convenience, same category as the Diagnostics panel's "Copy All" button
  earlier today, not a unit of planned roadmap work.
