# Phases 30, 31, 32 — Debug Rendering (Landscape / Roads / Mapping Groups)

Task: Phases 30, 31, 32
Category: feature-add
Phase: phases/30, phases/31, phases/32
Status: Ready for Review
Completed Date: 2026-08-10
Completed Time: 03:25 NST (+0545)

## Context

Picked up via `/TODO`, user asked to pick "next 2-10 phases." `agent-todos/active/`/
`ready-for-development/` were both empty. Chose the remaining three "Debug Rendering"
group phases (30-32) as one batch — they're the first REAL renderers this project has
written, share the same new caching infrastructure, and stop cleanly before Phase 33
("Debug Performance — Visibility Cost Model"), which is a profiling/benchmarking phase
this session's Agent Testing Policy hands to the user rather than an agent.

## Problem / Goal

Implement `phase-30.md` (Landscape group: Segments/Tangents/Start-End/Connections),
`phase-31.md` (Roads group: Highways/Lanes/Lane Direction/Sidewalks/Junctions), and
`phase-32.md` (Mapping group: HighwayPointId Labels/City-State Membership/Resolution
Status) — the first phases to actually populate `FNexusDebugCategoryRegistry` with
working renderers.

## Findings

1. **New caching layer, `FNexusDebugRenderSnapshot`, built before any renderer** -
   06-v6-debug-system.md's performance rule ("renderers read cached Representation-
   stage data, never recompute Landscape geometry per frame") had no concrete mechanism
   yet; Phases 23-29 never needed one (Diagnostics gathers fresh each tick, a much
   smaller/rarer computation). A renderer drawing every HighwayPoint every frame is
   exactly the case the rule exists for. `Refresh()` is the ONE place `SourcePoint.
   LoadSynchronous()` happens for rendering purposes, throttled to every 0.25s
   (`RefreshIntervalSeconds`) rather than every tick - deliberately NOT the config's own
   authoritative store (still `UNexusConfigAsset`/`FNexusRepresentationGraph`), purely a
   render-loop convenience that can only make drawing briefly stale, never wrong data
   propagating anywhere else (V6's "no cached field becomes authoritative" rule).
2. **The renderer delegate signature was revised TWICE this session, both times because
   writing a real renderer exposed what the previous signature couldn't do.** Phases
   23-26 shipped `(const FNexusDebugRenderConfig&)` only, explicitly flagged as
   "worth double-checking once a real one is written." Phase 30 needed `World` (nothing
   to draw with) and the `Snapshot` (nothing to draw from) - straightforward. Phase 32's
   `HighwayPointIdLabels` leaf then found there was no channel back to the label overlay
   at all - fixed by adding an `OutLabelRequests` accumulator param. Recording both
   revisions plainly since a reviewer will otherwise wonder why the signature doesn't
   match the original design.
3. **One shared label accumulator per `Tick()`, not one `UpdateLabels()` call per
   source.** `FNexusDebugLabelOverlay::UpdateLabels()` replaces its entire content each
   call (Phase 29's own design). Before this batch, only `RenderDiagnosticsOverlay` ever
   called it. Adding category renderers that ALSO want to emit labels meant two
   independent callers would fight over the same canvas, each wiping the other's labels
   every other frame. Fixed by collecting one `TArray<FNexusDebugLabelRequest>` in
   `Tick()`, passing it by reference into both `RenderDiagnosticsOverlay` and
   `DispatchDebugRenderers`, and calling `UpdateLabels()` exactly once at the end.
4. **`FNexusHighway`/`City`/`State` had NO width/lane fields at all before Phase 31** -
   confirmed by grep before starting. `05-v6-data-flow.md` already documents the
   "-1/0/>0... width, gap, length..." convention as a standing rule, but no earlier
   phase (01, 10-14) had actually added concrete fields for it. Phase 31's own Allowed
   list requires rendering "from Representation-stage width/gap fields," so this phase
   added `HalfWidth`/`LaneWidth`/`SidewalkWidth`/`LaneCount` (all `float`, default -1,
   V5's own exact field-naming precedent per `v5-complete-reference.md`'s `FNexusHighway`
   Lanes & Sidewalks fields) to all three structs - the same "add the type a phase
   concretely needs, even though it conceptually belongs to an earlier phase" precedent
   already set by Phase 21 adding `ENexusGenerationClassification`.
5. **Inheritance resolution happens exactly once, in `FNexusDebugRenderSnapshot::
   Refresh()`, never inside a renderer.** Each `FNexusDebugSnapshotHighway` carries
   already-resolved `Resolved*` fields (via `NexusInheritance::ResolveInheritedValue`
   walking Highway -> City -> State) - Phase 31's five renderers only ever read
   `Highway.ResolvedHalfWidth` etc., never re-walk the chain themselves. A member-
   pointer-based `ResolveChain` helper (`float FNexusCity::* CityMember`) avoided
   writing the same three-line walk four times (Half/Lane/Sidewalk-Width, LaneCount).
6. **Road/lane/sidewalk outlines are straight per-segment offsets, not curve-following
   geometry.** For each consecutive point pair, the perpendicular ("right") direction is
   computed independently at each endpoint from that point's own live tangent, and a
   straight line is drawn between the two offset positions. This is visibly coarser than
   what the eventual Static Generator (Phase 41+) will produce, and said so directly in
   the file's own top comment - correct scope for a debug wireframe, wrong scope for
   final mesh generation, not a shortcut trying to pass as the real thing.
7. **A resolved value of exactly 0 means "don't draw this outline at all", not a
   zero-width line** - consistent application of the -1/0/>0 convention. `RenderHighways`/
   `RenderSidewalks` gate on `> 0.f` before drawing anything.
8. **`Roads.Junctions` and `Landscape.Connections` intentionally duplicate the same
   ~4-line junction check** (`ConnectedHighwayIds.Num() >= 2`) rather than sharing a
   helper - they are independently toggleable debug categories a user may want on
   separately (one under Landscape, one under Roads), not the same subsystem split
   across two files. Not the kind of duplication Phase 30's "no renderer duplicates
   logic already in Phase 28/29's shared library" criterion is about (that criterion
   means primitive-drawing logic - don't hand-roll `DrawSphere`).
9. **`Mapping.ResolutionStatus` can only ever render the GREEN half of "green=resolved,
   red=broken."** A HighwayPoint whose `SourcePoint` doesn't resolve has, by this
   project's own "resolve-or-fail, never a fallback location" rule (Phase 18), no
   drawable world position — `FNexusDebugRenderSnapshot` still lists it
   (`bResolved=false`) but its `Location` is a meaningless default, not a real place.
   Fabricating an approximate location (e.g. averaging neighbors) was considered and
   rejected as inconsistent with the discipline already applied throughout this session
   (Phase 19/22/27 all made the same call for the same reason). Documented plainly in
   the phase file rather than silently only implementing half the criterion.
10. **Diagnostics (Phase 27) was deliberately NOT switched to read
    `FNexusDebugRenderSnapshot`** even though it now duplicates a similar
    rebuild-from-config pattern - re-touching already-reviewed Phase 27 code for a
    performance nicety no phase in this batch actually required would be unrequested
    scope creep. Noted in `NexusFrameworkSubsystem.h`'s own comments so it doesn't read
    as an oversight.
11. **All three phases' "does X visually look right" completion criteria are left
    unchecked**, consistent with this session's established policy (`AGENT-RULES.md` +
    the Phase 12/19/20/21 precedent): a rendered-wireframe claim is a runtime/visual
    fact only the user's own editor session can confirm. Two "structural fact, provable
    by inspection" criteria (Phase 30's "no duplicated primitive logic") were checked
    off the same way Phase 19/25/28 did the equivalent.

## Changes

- New `Public/Debug/NexusDebugRenderSnapshot.h` / `Private/Debug/
  NexusDebugRenderSnapshot.cpp` — `FNexusDebugSnapshotPoint`/`FNexusDebugSnapshotHighway`/
  `FNexusDebugRenderSnapshot` (Findings #1, #5).
- `Public/Debug/NexusDebugCategory.h` — `FNexusDebugCategoryRendererDelegate` revised to
  4 params (`World`, `Snapshot`, `Config`, `OutLabelRequests`) (Findings #2).
- `Public/Subsystem/NexusFrameworkSubsystem.h` / `.cpp` — new `DispatchDebugRenderers()`
  (throttled snapshot refresh + registry walk + per-category visibility gate);
  `RenderDiagnosticsOverlay`/`DispatchDebugRenderers` now both take an `OutLabelRequests`
  out-param instead of each calling `UpdateLabels()` themselves; `Tick()` owns the one
  shared accumulator and the one `UpdateLabels()` call (Findings #3).
- `Public/Representation/NexusHighway.h`, `NexusCity.h`, `NexusState.h` — added
  `HalfWidth`/`LaneWidth`/`SidewalkWidth`/`LaneCount` (Findings #4).
- New `Private/Debug/NexusDebugLandscapeGroupRenderers.cpp` — Phase 30's four leaves.
- New `Private/Debug/NexusDebugRoadsGroupRenderers.cpp` — Phase 31's five leaves
  (Findings #6, #7, #8).
- New `Private/Debug/NexusDebugMappingGroupRenderers.cpp` — Phase 32's three leaves
  (Findings #9).
- `project-specifications/phases/phase-30.md`/`31.md`/`32.md` — Status → `Ready for
  Review`; Phase 30's "no duplicated logic" checked off structurally; all other criteria
  left unchecked with exact manual-check steps; Phase 31 gained a note on the added
  width/lane fields; Phase 32 gained a note on the resolution-status limitation.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, 0 errors, 23 actions (first attempt after resolving; blocked
  once more by a Live-Coding-active editor, same as every prior batch this session -
  asked the user, they closed it, retry passed clean).
- `node html-docs/build.js` — regenerated `PHASE-STATUS.md`/`phase-data.js`/
  `phase-tracker.html`.
- **No automated tests written or run** — per `AGENT-RULES.md`'s Agent Testing Policy.
  Every visual-correctness criterion across the three phases needs the user's own
  in-editor session; exact steps are in each phase file.

## Result

Implementation complete for Phases 30-32, build-verified. This closes the "Debug
Rendering" group-renderer arc; Phase 33-35 ("Debug Performance") are profiling/stress-
test phases squarely in the user's own manual-verification territory per
`AGENT-RULES.md`, not natural agent pickups. Phase 36 ("HighwayPoint — Junction
Classification") is the next roadmap item with no comparable dependency gap.

## Important Notes

- The renderer delegate signature (`World`, `Snapshot`, `Config`, `OutLabelRequests`)
  should now be stable for the remaining Debug Rendering-adjacent work in this arc, but
  flagging again (as the Phase 23-26 record did) that it's only been exercised by these
  three phases' renderer shapes so far - worth a final look once a future phase's
  renderer needs something these three didn't (e.g. per-instance gizmo interaction,
  Phase 76+).
- `Mapping.ResolutionStatus`'s green-only limitation (Finding #9) and
  `Roads`/`Landscape`'s straight-segment outline approximation (Finding #6) are both
  real, durable facts about this system's current shape, not TODOs — recorded here so a
  future phase doesn't "fix" them without realizing they're deliberate.
- Width/lane fields (Finding #4) are today only consumed by Phase 31's own renderers -
  nothing in Mapping/Generation reads them yet. They'll matter for real once the Static
  Generator (Phase 40+) needs actual road geometry.
