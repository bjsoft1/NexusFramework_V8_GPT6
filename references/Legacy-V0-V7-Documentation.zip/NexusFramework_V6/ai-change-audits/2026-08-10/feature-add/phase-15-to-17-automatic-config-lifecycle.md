# Phases 15-17 — Automatic Config Lifecycle (Plugin Enable, Reconciliation, Multi-Landscape Support)

Task: Phases 15, 16, 17 — the Automatic Config Lifecycle arc
Category: feature-add
Phase: phases/15, phases/16, phases/17
Status: Ready for Review (all three)
Completed Date: 2026-08-10
Completed Time: 03:05 NST (+0545)

## Context

Picked up via `/TODO` immediately after Phases 10-14 (Nexus Mapping) were moved to
`Ready for QA` by the user, who also ran the full `Nexus.Mapping.*` command set against
the real 10-point test Landscape/config and pasted the results, then said "i think
looks good. is okay next phase." That verification pass (what it did and did not
actually exercise - Phase 12's assignment commands were called with no arguments and
only hit their usage-message path) is recorded as a new dated section appended to
`phase-10-to-14-nexus-mapping.md`, and as phase-file checkbox edits to `phases/10.md`,
`11.md`, `13.md`, `14.md` (not `12.md` - nothing to check off there yet) - not repeated
here. Phases 15-17 (all three "Automatic Config Lifecycle" phases) were then batched
together per the user's "3-5 small phases per go" instruction, as the next natural
architectural unit.

## Problem / Goal

Implement `project-specifications/phases/phase-15.md` through `phase-17.md`: wire
Phases 10-14's Mapping functions into the actual automatic, zero-user-action enable
flow (project-specifications/05-v6-data-flow.md), handle session-to-session
Landscape/config divergence, and verify/harden/document the single-vs-multi-Landscape
scope.

## Findings

1. **The automatic trigger point was already decided, not a new design question** -
   project-specifications/04-v6-architecture.md's Editor-surface section already says
   entering Landscape Mode "is what triggers LandscapeId resolution and config load,"
   naming `FNexusLandscapeModeExtension` as the integration point. Phase 15 wires into
   that extension's existing `OnEditorModeIDChanged` entering-branch (Phase 02/03's
   own, already-QA'd code) - the tab-opening logic itself is untouched, the new call is
   purely additive right after it.
2. **Phase 15's own Allowed list says "Mapping re-run/reconcile," and Phase 16 is
   specifically the reconciliation phase** - rather than have Phase 15 call the bare
   Phase 10/11 `MapControlPoints`/`MapHighways` functions directly, its
   `RunAutomaticEnableFlow` calls Phase 16's `ReconcileMappingStage` instead, since
   every automatic re-entry into Landscape Mode after Landscape edits genuinely IS the
   reconciliation moment Phase 16 describes - avoids Phase 15 needing its own separate,
   thinner re-run path that Phase 16 would then duplicate.
3. **Reconciliation's "broken entries" check is deliberately NOT a duplicate of Phase
   14's validation gate** - Phase 14's `ValidateMappingStage` is a stateless snapshot
   ("what's currently wrong"); Phase 16's `ReconcileMappingStage` is a diff against
   what the config looked like *before this call's re-map* ("what's newly broken/newly
   mapped since we last touched this config"), computed by snapshotting known
   StableIds/HighwayIds beforehand and comparing after - a genuinely different question
   answered from different data, not the same check under two names.
4. **"Reconcile: flag broken entries (never silently drop)... map new points
   automatically" (Phase 16's Allowed list) is satisfied by construction**, not by new
   deletion-guarding code - `ReconcileMappingStage` never removes anything from
   `Config.HighwayPoints`/`Highways`, and "map new points automatically" is just
   Phase 10/11's own idempotent `MapControlPoints`/`MapHighways` being called again, so
   there's no separate "auto-map" logic to write.
5. **Phase 17's own Allowed list reads as "verify" language throughout ("Verify...
   Verify... Verify... Document"), not "build a Landscape picker"** - and nothing in
   the codebase (UI or data model) has any concept of "which Landscape" beyond
   `ResolveActiveLandscape()` picking the first one found. Building real multi-Landscape
   UI is out of scope for a "verify/harden/document" phase with no Allowed-list mention
   of new UI work; the phase file's own "Document the single-Landscape-per-map
   assumption if V6's first version deliberately narrows scope here" is an explicit
   escape hatch for exactly this situation. Took it: documented the limitation
   (project-specifications/04-v6-architecture.md's new section) rather than building
   picker UI this phase.
6. **The one real code change Phase 17 still earned**: `ResolveActiveLandscape()`
   silently returning "whichever Landscape TActorIterator finds first" with zero signal
   if a second one exists is a real, if minor, gap - a user with two Landscapes in one
   map would see only one mapped with no explanation why. Added a Warning log (count +
   which one was picked) without changing the function's actual selection behavior or
   return value - a deliberate, small, additive edit to Phase 05's already-QA'd file,
   made because Phase 17 explicitly calls for "harden the lifecycle" here, not a
   drive-by change.
7. **LandscapeId/config-asset independence across multiple Landscapes required no new
   code to verify** - confirmed via review, not a new mechanism: `LandscapeId` comes
   from `ALandscape::GetLandscapeGuid()` (unique per actor) and the config package path
   is derived purely from `LandscapeId` (Phase 13), so two Landscapes already produce
   two non-overlapping config asset paths by construction. This is what makes Phase 17
   a "verify and document" phase rather than a "build isolation" phase - the isolation
   already existed as a side effect of Phase 13's own design.

## Changes

- `Source/NexusFrameworkEditor/Public/Mapping/NexusMapping.h` - added
  `FNexusReconciliationResult` (Phase 16) and `ReconcileMappingStage`/
  `RunAutomaticEnableFlow` declarations.
- New `Private/Mapping/NexusMapping.Reconciliation.cpp` (Phase 16) -
  `ReconcileMappingStage` (before/after StableId+HighwayId snapshot diff) +
  `Nexus.Mapping.ReconcileMappingStage` console command.
- New `Private/Mapping/NexusMapping.EnableFlow.cpp` (Phase 15) -
  `RunAutomaticEnableFlow` (LandscapeId resolve -> config load/create ->
  `ReconcileMappingStage`, with `FPlatformTime::Seconds()` elapsed-time logging) +
  `Nexus.Mapping.RunAutomaticEnableFlow` console command (manual re-trigger/re-timing
  without toggling Landscape Mode).
- `Source/NexusFrameworkEditor/Private/UI/NexusLandscapeModeExtension.cpp` - the
  entering-Landscape-Mode branch of `OnEditorModeIDChanged` now also calls
  `FNexusMapping::RunAutomaticEnableFlow` and stores the result on
  `UNexusFrameworkSubsystem::ActiveConfig`, right after the existing (unchanged)
  tab-opening logic.
- `Source/NexusFrameworkEditor/Private/Reader/NexusLandscapeReader.cpp` -
  `ResolveActiveLandscape()` now counts every `ALandscape` found (not just the first)
  and logs a Warning if more than one exists, still returning the first either way -
  no behavior change for the single-Landscape case (see Findings #6).
- `project-specifications/04-v6-architecture.md` - new "Multi-Landscape scope (Phase 17
  decision, 2026-08-10)" section.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development` - **Result: Succeeded** twice: a
  full compile of all new/changed files, then an immediate re-run confirming "Target is
  up to date, 0 actions" - both clean, no errors.
- **No automated tests written or run, no editor launched for verification** - per
  `AGENT-RULES.md`'s Agent Testing Policy. Exact manual-check steps for every
  Completion Criterion across all three phases are written into each phase's own file.

## Result

Implementation complete, build-verified only, for all three phases. Every Completion
Criterion that needs a real Landscape/editor session is left unchecked pending the
user's own manual pass; Phase 17's "explicit scope decision recorded" criterion is
checked - it's a documentation deliverable completed this session, not something
requiring an editor session to confirm.

## Important Notes

- This is the first phase where an agent has modified `FNexusLandscapeModeExtension.cpp`
  (Phase 02/03's own, already-`Ready for QA` file) since the false-negative-test saga
  earlier in this project - the change here is purely additive (one new block calling
  into Phase 15's new function, right after the existing, unchanged tab-opening logic)
  and was made because Phase 15's own objective explicitly is "wire Phase 02's
  subsystem," not incidental. Worth a specific look from the user given that file's
  history, even though the tab-open/close behavior itself was not touched.
- `RunAutomaticEnableFlow` now fires every single time Landscape Mode is entered - on a
  large real Landscape this means `MapControlPoints`/`MapHighways`'s full re-enumeration
  runs on every mode-entry, not just the first. No performance problem has been
  observed (nothing to observe against yet - no real large-Landscape test has happened),
  but this is exactly what Phase 15's own "time the flow... record a baseline" criterion
  exists to catch before it becomes one - see the `ElapsedMs` log field.
- Phase 17 deliberately did NOT build any Landscape-picker UI or change
  `ResolveActiveLandscape`'s selection behavior - see Findings #5. If a future need for
  genuine multi-Landscape support arises, start from this record's Findings #7 (the
  data-model isolation already exists) rather than assuming new Mapping-layer work is
  needed.
- Neither Phase 16's `ReconcileMappingStage` nor Phase 15's `RunAutomaticEnableFlow` has
  been exercised against an actually-diverged config yet (deleted point + natively-added
  point, per Phase 16's own Completion Criterion) - only Phase 10-14's straightforward
  idempotent-rerun paths have real user-verified log output so far.
