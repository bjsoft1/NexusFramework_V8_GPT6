# Phase 42: Static Generator instancing pipeline (ISM/HISM grouping)

Date: 2026-08-10
Category: feature-add
Phase: 42 (Static Generator - Instancing Pipeline)

## Context

Third item in the Static Generator cluster of the current work batch (41, 41a, 42-44).
User then redirected mid-Phase-43-research to stop implementing further phases in this
batch and switch to documentation-only for the rest (43, 44, 45-49) - this record covers
only the completed Phase 42 work.

## Problem / Goal

Group `Instanced`-classified generated objects into `UHierarchicalInstancedStaticMeshComponent`s
by mesh+material combination, wire at least one test object type end-to-end, and prove
exact instance-count match plus idempotent re-runs.

## Findings

- No existing actor/component host for generated instanced content anywhere in the
  codebase - this phase is the first to need one.
- No real per-object-type placement data set exists yet for any `Instanced`-classified
  object type (City-Light poles are Phase 56, Bus Stop shelters Phase 64, Seats Phase
  66/69 - none implemented). Used `HighwayPoints` (one instance per resolved point) as an
  explicitly-flagged stand-in source purely to prove the grouping mechanism, not as a
  real feature - matches the phase's own "e.g. city-light poles" wording, read as an
  illustrative example rather than a hard requirement to have real City Light data first.
- `AActor::AddInstanceComponent`/`GetComponents<T>` (component discovery/registration)
  and `UInstancedStaticMeshComponent::AddInstance`/`ClearInstances`/`GetInstanceCount`
  (engine-source-verified signatures) were sufficient - no new module dependency needed
  (`Engine` module, already present).

## Changes

- New: `Source/NexusFrameworkEditor/Public/Generation/NexusGeneratedInstancedMeshHost.h`
  + `Private/.../NexusGeneratedInstancedMeshHost.cpp` - `ANexusGeneratedInstancedMeshHost`,
  a minimal actor holding one HISM component per mesh+material combination.
- New: `Source/NexusFrameworkEditor/Public/Generation/NexusInstancingGenerator.h` +
  `Private/.../NexusInstancingGenerator.cpp` - `FNexusInstancingGenerator::
  FindOrCreateInstanceComponent` (mesh+material grouping, never duplicates a component)
  and `GenerateHighwayPointPoleInstances` (the end-to-end test wiring, idempotent via
  `ClearInstances()` before re-adding).
- New: `Source/NexusFrameworkEditor/Private/Generation/NexusInstancingGeneratorCommands.cpp`
  - `Nexus.Generation.GeneratePoleInstances`, `Nexus.Generation.TestInstancingIdempotency`.
- `phases/phase-42.md` - Status set to Ready for Review; completion criteria annotated
  with what's implemented vs. still needing a manual editor run.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` -
  **Result: Succeeded**, 7 actions (incremental), 0 errors.
- **No automated test run/added** - per `AGENT-RULES.md`'s Agent Testing Policy. Neither
  console command was executed (no editor launch) - see phase-42.md's own Manual
  Verification section.

## Result

A real, working ISM/HISM grouping pipeline exists and compiles clean. The actual
instance-count/idempotency proof against live data, and the "does it actually render
correctly in the World Outliner" check, remain manual steps for the user.

## Important Notes

- **Not a real City-Light system** - see Findings above. Do not treat
  `GenerateHighwayPointPoleInstances` as Phase 56's own deliverable; it is Phase 42's
  pipeline-proof only, using HighwayPoints as placeholder source data.
- **Phase 43 (Streaming/Data Layer Grouping) was NOT implemented this session** - user
  redirected mid-research (the `UDataLayerManager`/World Partition Data Layer API chain
  was proving to need a real Data Layer asset already set up in the project to verify
  meaningfully, and the user asked to stop implementing further phases in this batch and
  switch to documentation only). `ANexusGeneratedInstancedMeshHost` is currently a
  single global host, not yet grouped per streaming cell - that grouping is Phase 43's
  own future work, not silently done here.
