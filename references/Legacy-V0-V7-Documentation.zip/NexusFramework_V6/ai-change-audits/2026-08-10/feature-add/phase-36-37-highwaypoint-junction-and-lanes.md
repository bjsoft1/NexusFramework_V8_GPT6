# Phases 36, 37 — HighwayPoint (Junction Classification / Lane Relationship Data)

Task: Phases 36, 37
Category: feature-add
Phase: phases/36, phases/37
Status: Ready for Review
Completed Date: 2026-08-10
Completed Time: 07:56 NST (+0545)

## Context

Picked up via `/TODO` while the user reviewed the previous (Debug Rendering) batch.
`agent-todos/active/`/`ready-for-development/` were both empty. Phases 33-35 ("Debug
Performance") were deliberately skipped even though they're numerically next — their own
Not Allowed list says "do not optimize a subsystem that hasn't been correctness-verified
first," and Phase 28-32's correctness verification is exactly what the user is doing
right now (still `Ready for QA`/being reviewed, not yet `Complete`). Picked the
"HighwayPoint" arc (36-37) instead — self-contained, no such dependency. Stopped there
rather than also picking up 38-39 (a "Validation" arc with its own open architectural
question, see Important Notes) to keep this batch focused, given Phase 36 alone carries
real weight (see below).

## Problem / Goal

Implement `phase-36.md` (junction classification + V6's own closed-form junction
rotation solver - flagged by `v6-phase-verification.md` as "the highest-severity
carried-forward engine crash risk in the whole roadmap") and `phase-37.md` (lane
identity/side/direction data model, needed by the future Traffic Light
`ControlledLaneIds[]` work).

## Findings

1. **`ENexusJunctionType` is a deliberately simpler 3-value taxonomy than V5's own
   7-value `ENexusNodeType`** (Straight/SmoothCorner/Corner/TJunction/CrossJunction/
   MultiJunction/DeadEnd). V6's classification is keyed off Representation-stage Highway
   MEMBERSHIP (`ConnectedHighwayIds`, Phase 20's own junction definition), not raw
   Landscape segment topology — Representation code may not read Landscape segments
   directly, and Phase 11's chain-splitting already guarantees a point belonging to 2+
   Highways is a genuine branch, so V5's finer angle-based sub-classification isn't
   needed at this layer.
2. **Classification is a live query (`FNexusRepresentationGraph::ComputeJunctionType`),
   never a stored field** — distinguishing Passthrough from DeadEnd needs a neighbor
   lookup (`GetPointNeighbors`), which needs the graph, not just the point's own fields
   in isolation, so this couldn't live on `FNexusHighwayPoint` itself the way
   `ConnectedHighwayIds` does. This also makes "updates live with no manual recompute
   step" true by construction, matching the Phase 20 `ComputeCityCenter` precedent.
3. **The rotation solver's crash-avoidance is architectural, not just tested-against.**
   `ComputeJunctionForwardDirection` never constructs an `FQuat` via an axis-angle pair —
   the exact pattern `01-v5-analysis.md`'s crash trace names (an unguarded
   `FQuat(Axis, Angle)` fed a zero-length Hermite-curve derivative). The whole solver
   works in plain `FVector`/`float` (bisector subtraction; `atan2`/`cos`/`sin` for the
   largest-angular-gap case) and only ever reaches `FVector::Rotation()` if a caller
   needs an `FRotator` — an atan2-based conversion with no quaternion axis-angle
   construction in it at all. Every direction is guarded with `IsNearlyZero()`/
   `GetSafeNormal()` before use. This is prevention (the risky code path is structurally
   unreachable), which is a real form of evidence but explicitly NOT the same as the
   user's own reproduction-and-confirm — recorded as such in the phase file rather than
   overclaiming.
4. **One bisector formula covers V5's separate Straight/Corner/TJunction/Cross/Multi
   cases**, dispatched purely on how many resolvable neighbor DIRECTIONS were found (not
   on `ComputeJunctionType`'s own classification): 0 -> fall back to existing live
   Rotation; 1 -> that direction (true dead-end); 2 -> `(DirectionB - DirectionA)`
   bisector (reduces to the through-direction for a straight run, correctly bisects for
   a corner); 3+ -> largest-angular-gap. A 2-Highway junction where each Highway
   contributes exactly one neighbor direction lands in the SAME 2-direction bisector
   branch as an ordinary Passthrough point — geometrically the same problem, so reusing
   the same formula is correct, not a missed case.
5. **`ENexusJunctionType` is exposed to Phase 32's `Mapping.HighwayPointIdLabels`
   renderer** (Phase 36's own explicit ask) by adding a `JunctionType` field to
   `FNexusDebugSnapshotPoint`, computed once in `FNexusDebugRenderSnapshot::Refresh()`
   (which already builds a `FNexusRepresentationGraph` locally) rather than recomputed
   per-renderer-call - renderers don't have direct graph access, only the snapshot.
6. **`FNexusLane` is deliberately minimal** — `LaneId`/`Side`/`IndexFromCenter` only, no
   per-lane width/mesh override (`FNexusHighway::LaneWidth`, added Phase 31, already
   covers uniform width; Phase 37 doesn't ask for a per-lane override and none was added
   speculatively).
7. **`ReconcileHighwayLanes`'s "won't orphan references" guarantee is achieved by a
   specific removal order, not by refusing to shrink**: existing lanes are split by
   side and sorted ascending by `IndexFromCenter`; shrinking trims from the tail
   (outermost first) via `SetNum`; growing only ever appends fresh
   `FNexusLane::MakeDefault()` entries. An existing `LaneId` is therefore either kept
   exactly as-is or removed outright — never reassigned to a different physical lane.
   This is the actual content of "won't orphan references": the method's contract is
   "never silently repurposes an existing Id," not "a removed lane's old references
   automatically get fixed up" (nothing yet holds such references — Traffic Light's
   `ControlledLaneIds[]` doesn't exist until Phase 50+).
8. **`ReconcileHighwayLanes` resolves its own Highway -> City -> State inheritance
   chain**, independently of `FNexusDebugRenderSnapshot::Refresh()`'s own resolution of
   the same fields. This is two legitimate consumers of the same shared
   `NexusInheritance::ResolveInheritedValue` utility (Representation-stage lane
   reconciliation vs. Debug-stage rendering), not duplicated business logic — each
   domain has its own real reason to need the resolved value.
9. **Phase 31's `Roads.Lanes` renderer was judged "already sufficient" and left
   unchanged** — it already draws the correct NUMBER of lane-divider lines from
   `ResolvedLaneCount`/`ResolvedLaneWidth`; per-lane `LaneId` identity doesn't change
   what's drawn, only what a lane can be REFERENCED by (a concern for Phase 50+, not
   Phase 31's own renderer). Phase 37's own Allowed list frames this as conditional
   ("if not already sufficient"), so no change was made — recorded here so the decision
   not to touch it is visible, not silent.
10. **`ReconcileHighwayLanes`/`GetLanesAtPoint` operate on `FNexusRepresentationGraph`'s
    own throwaway copy, same as every other Representation-stage query this session** —
    calling them doesn't persist anything back to `UNexusConfigAsset`. The verification
    console command's own log output reflects this (a fresh reconcile against
    already-populated data), consistent with every other `Nexus.Representation.*`
    command's read-only-snapshot nature.

## Changes

- `Public/Representation/NexusHighwayPoint.h` — new `ENexusJunctionType` enum
  (DeadEnd/Passthrough/Junction), never stored on the struct (Findings #1, #2).
- `Public/Representation/NexusRepresentationGraph.h` — new `ComputeJunctionType`,
  `ComputeJunctionForwardDirection`, `ReconcileHighwayLanes`, `GetLanesAtPoint`.
- New `Private/Representation/NexusRepresentationGraph.JunctionResolver.cpp` — Phase 36
  method bodies (Findings #3, #4) + `Nexus.Representation.DumpJunctionClassification`
  console command.
- `Public/Representation/NexusHighway.h` — new `ENexusLaneSide` enum, new `FNexusLane`
  USTRUCT (Findings #6), new `FNexusHighway::Lanes` field.
- New `Private/Representation/NexusRepresentationGraph.LaneRelationships.cpp` — Phase 37
  method bodies (Findings #7, #8) + `Nexus.Representation.ReconcileAndDumpLanes` console
  command.
- `Public/Debug/NexusDebugRenderSnapshot.h`/`.cpp` — new `FNexusDebugSnapshotPoint::
  JunctionType` field, resolved in `Refresh()` (Findings #5).
- `Private/Debug/NexusDebugMappingGroupRenderers.cpp` — `HighwayPointIdLabels`' label
  text now appends `[Passthrough]`/`[Junction]`/`[DeadEnd]` (Findings #5).
- `project-specifications/phases/phase-36.md`/`phase-37.md` — Status → `Ready for
  Review`; Phase 37's "queryable by HighwayPointId" criterion checked off as a
  structural fact; the other four criteria (all runtime/data-dependent or requiring a
  real crash-scenario reproduction) left unchecked with exact manual-check steps; Phase
  36 gained a dedicated note on the solver's crash-avoidance reasoning.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, first attempt, 0 errors, 12 actions (no Live-Coding block this
  time).
- `node html-docs/build.js` — regenerated `PHASE-STATUS.md`/`phase-data.js`/
  `phase-tracker.html`.
- **No automated tests written or run** — per `AGENT-RULES.md`'s Agent Testing Policy.
  Four of five completion criteria across the two phases need the user's own in-editor
  session; exact `Nexus.Representation.*` console-command steps are in each phase file.

## Result

Implementation complete for Phases 36-37, build-verified. Phase 36's own crash-scenario
reproduction (the highest-severity flagged risk in the whole roadmap per
`v6-phase-verification.md`) is the one criterion in this batch most worth the user's
close attention before treating it as settled — the architectural reasoning is sound but
is not a substitute for the actual repro.

## Important Notes

- **Phases 38-39 ("Validation" arc) were not picked up this round.** Skimming Phase 39's
  own wording ("broken-junction checks - Representation says junction, Landscape
  segments don't actually meet there") surfaces a real tension worth flagging before
  it's picked up: Representation-stage code cannot read Landscape segments directly
  (every Debug-*/Representation-* phase's shared Not Allowed rule), so "segments don't
  actually meet" isn't literally checkable from Representation's own snapshot — by this
  project's architecture, a junction IS defined by shared HighwayPointId membership (a
  single `SourcePoint`), so two Highways sharing a point cannot geometrically "not meet"
  at the Representation layer; whatever Phase 39 means by this check likely belongs at
  the Mapping stage (comparing Phase 07's raw adjacency graph against Representation's
  derived membership) rather than purely within Phase 22's existing gate. Worth the
  user's read of `14-v6-validation.md`'s own wording before that phase is scoped.
- `Phase 36`'s rotation solver output (`ComputeJunctionForwardDirection`) is not yet
  consumed by anything — no phase through 37 pushes a resolved rotation back onto a
  live control point (V6 never writes Landscape geometry from Representation code
  anyway; this solver's real consumer is likely a future Static Generator or Gizmo
  phase that needs a deterministic junction-facing direction for placed geometry).
- `FNexusLane`/`ReconcileHighwayLanes` are not yet consumed by anything either — Traffic
  Light's `ControlledLaneIds[]` (Phase 50+) is the intended first real consumer.

## Revision — 2026-08-10 (same day)

### Context

Immediately after the batch above shipped, the user ran the console verification
commands and noticed `Nexus.Representation.DumpJunctionClassification`'s output never
showed anything resembling V5's "T-Junction"/"smooth corner" labels, asked if that was
still pending development, then — before waiting for an answer — pointed out V5 already
has this system built and working, and to pick it up from there rather than treat it as
out of scope. This is a direct, load-bearing correction to Finding #1 above (which had
framed the 3-value taxonomy as an intentional simplification): the user's read is that
V6 should match V5's proven classification, not simplify it, now that doing so is
actually possible within this phase's own architectural constraints.

### Findings

1. **A real (separate) bug was caught and fixed first**: the verification console
   command's `ConnectedHighways=%d` log field read `Point.ConnectedHighwayIds.Num()`
   straight off `Config->HighwayPoints`'s raw, never-derived array entry, not the
   freshly-populated `Graph`'s own copy — `ConnectedHighwayIds` is a derived field
   (`RecomputeConnectedHighwayIds`/`AddPointToHighway`) that only gets computed on the
   Graph's own internal copies during `PopulateFromConfigAsset`, so the raw config
   array's copy stayed at its default-constructed empty state unless something else
   (Phase 18's own dump command) had separately mutated it in place first. This made
   every single logged point show `ConnectedHighways=0` regardless of its real,
   correctly-computed `Type` — actively misleading, and very likely what made the
   original classification look "not really working" at a glance. Fixed by reading the
   count off `Graph.FindHighwayPoint(...)` instead.
2. **V5's raw `ConnectedSegments.Num()` (from `ULandscapeSplineControlPoint`) is fully
   reconstructable at the Representation stage without violating "no direct Landscape
   read"**: for each of a point's `ConnectedHighwayIds`, `GetPointNeighbors` already
   answers whether that point sits at the MIDDLE of that Highway's `OrderedPointIds`
   (both Previous and Next resolve → contributes 2 virtual segments, matching a real
   control point with two spline connections along that road) or at an END (exactly one
   resolves → contributes 1). Summing this across every connected Highway reproduces
   V5's exact per-point segment count using only Highway chain membership + live
   neighbor location reads (`GetLiveLocation`) — the same sanctioned read path this
   phase always used. This was already being computed, unused for classification, by
   `GatherNeighborDirections` (written for the rotation solver) — `NeighborDirections.
   Num()` IS this count. `ComputeJunctionType` now classifies from the same array
   `ComputeJunctionForwardDirection` already builds, rather than the coarser
   `ConnectedHighwayIds.Num()` used in the original cut.
3. **This is a genuine correctness improvement over the original cut, not just added
   granularity**: the original `ConnectedHighwayIds.Num() >= 2 → Junction` rule would
   have misclassified a point where exactly two DIFFERENT Highways each simply END at a
   shared point (e.g. two Highway naming ranges meeting with nothing continuing
   through) as a branch/junction, when topologically — same as V5 would see it — that's
   just an ordinary 2-segment node (Straight/Corner/SmoothCorner), not a real branch.
   The new segment-count-based rule gets this right because it doesn't care which
   Highway a segment belongs to, only how many real connections meet at the point,
   matching V5's own topology-first definition.
4. **`CornerSharpDetectionAngleDegrees` (new inheritable field, Highway -> City ->
   State) deliberately does NOT go through `NexusInheritance::ResolveInheritedValue`**,
   unlike every other field in this family (`HalfWidth`/`LaneWidth`/`SidewalkWidth`/
   `LaneCount`). That shared resolver's terminal fallback is `DisabledValue` (0) when
   nothing in the chain overrides — for an angle threshold, a resolved 0 degrees would
   make `cos(0) = 1` the corner-sharpness cutoff, so `Dot > Threshold` could never be
   true and `Corner` would never be reported at all regardless of test data, silently
   defeating the whole point of porting V5's system. Used a small dedicated resolver
   instead (same Highway -> City -> State walk, first value `>= 0` wins) with a terminal
   default of 100 degrees — V5's own literal default
   (`project-specifications/v5-complete-reference.md`'s `ResolveCornerSharpDetectionAngle`)
   — so out-of-the-box behavior (nothing configured anywhere) matches what V5 users
   would actually see, not a degenerate always-smooth result.
5. **`ComputeJunctionForwardDirection`'s own dispatch (0/1/2/3+ resolved directions) was
   deliberately left unchanged**, even though V5's rotation solver further splits its
   4+ case (`CrossJunction`/`MultiJunction` → lowest-angle-sorted direction) from its
   exactly-3 case (`TJunction` → largest-angular-gap). V6's solver already generalized
   the largest-gap formula to any count >= 3 in the original Phase 36 cut, which this
   session's own Finding #4 (original record above) already argued is more principled
   for 4+-way points than V5's arbitrary lowest-angle pick, not an oversight. Revising
   the classification LABELS didn't require revisiting that reasoning, so the rotation
   solver's bucket boundaries stay exactly as before — the two functions remain
   consistent (same `NeighborDirections.Num()` signal drives both) without the forward-
   direction formula regressing.
6. **The crash-avoidance property from the original record (Finding #3 above) is fully
   preserved**: the added Corner/SmoothCorner Dot-product test and the
   `CornerSharpDetectionAngleDegrees` resolver are both plain `float`/`FVector::
   DotProduct` math on already-guarded (`IsNearlyZero`-checked, `GetSafeNormal`-ed)
   directions — no new `FQuat` construction anywhere.

### Changes

- `Public/Representation/NexusHighwayPoint.h` — `ENexusJunctionType` expanded from
  `{DeadEnd, Passthrough, Junction}` to V5's full `{DeadEnd, Straight, Corner,
  SmoothCorner, TJunction, CrossJunction, MultiJunction}`; doc comment rewritten to
  describe the segment-count reconstruction (Finding #2).
- `Public/Representation/NexusHighway.h`, `NexusCity.h`, `NexusState.h` — new
  `CornerSharpDetectionAngleDegrees` inheritable field (Finding #4).
- `Private/Representation/NexusRepresentationGraph.JunctionResolver.cpp` — rewritten:
  `ComputeJunctionType` now classifies from `GatherNeighborDirections`'s resolved
  direction count (with the Dot-product Straight/Corner/SmoothCorner split for exactly
  2) instead of `ConnectedHighwayIds.Num()`; new `ResolveCornerSharpDetectionAngleDegrees`
  local resolver; `JunctionTypeToString` and the verification console command's log
  format updated for all 7 values; the `ConnectedHighways=%d` log bug (Finding #1) fixed
  in the same pass.
- `Private/Debug/NexusDebugMappingGroupRenderers.cpp` — `JunctionTypeToDisplayString`
  updated for all 7 values (V5's own display strings: "T-Junction", "Cross Junction",
  "Multi Junction", "Smooth Corner", "Dead End").
- `project-specifications/phases/phase-36.md` — new `## Revision` section; first
  completion criterion's "To check" steps updated to reference the new enum values
  (the old steps referenced `Passthrough`/`Junction`, which no longer exist).

### Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, 0 errors, 12 actions.
- `node html-docs/build.js` — regenerated.
- **Still no automated tests** — per `AGENT-RULES.md`. The corrected
  `Nexus.Representation.DumpJunctionClassification` output (with the `ConnectedHighways`
  bug fixed) still needs the user's own pass against known 2-way/3-way/4-way/dead-end
  test points — same open completion criterion as before, now checkable against the
  right enum values.

### Result

`ENexusJunctionType` now matches V5's proven 7-value taxonomy, reconstructed entirely
from Representation-stage-legal reads (Highway chain membership + live neighbor
location), plus a real logging bug fix that was very likely the actual reason the
original output looked incomplete. Not yet user-verified against real junction
geometry — the "To check" steps in `phase-36.md` are the next thing to run.
