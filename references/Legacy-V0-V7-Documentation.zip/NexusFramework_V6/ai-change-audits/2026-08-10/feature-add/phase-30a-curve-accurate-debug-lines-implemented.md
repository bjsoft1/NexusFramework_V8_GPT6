# Phase 30a implemented — Curve-Accurate Segment/Offset Debug Lines

Task: Phase 30a
Category: feature-add
Phase: phases/30a
Status: Ready for Review
Completed Date: 2026-08-10
Completed Time: 11:10 NST (+0545)

## Context

`phases/phase-30a.md` was inserted earlier today, tracking-only (see
`ai-change-audits/2026-08-10/others/phase-30a-inserted-curve-accurate-debug-lines.md`),
right after the same-day world-space location fix. Once the user re-tested and confirmed
the location fix worked ("now location is connect"), they immediately asked for the
curve half too ("but the line not curve, so make similar V5 types curve") — implemented
in the same session, not deferred to a later `/TODO` pick, since the phase file already
had full scope written down and the ask was explicit.

## Problem / Goal

`Landscape.Segments` and `Roads.Highways`/`Lanes`/`Sidewalks` all drew a single straight
line between two Highway points, even when the real Landscape spline segment between
them curves — making visual QA against the actual Landscape geometry unreliable.

## Findings

1. **Confirmed the exact engine Hermite convention from UE 5.8 source** rather than
   guessing at a curve formula: `Engine/Source/Runtime/Landscape/Private/
   LandscapeSplines.cpp`'s `ULandscapeSplineSegment::UpdateSplinePoints` builds a
   2-point `FInterpCurveVector` where the START connection's tangent
   (`Rotation.Vector() * TangentLen`) is used as-is, but the END connection's tangent is
   **negated** first. This exactly determines the `T0`/`T1` inputs
   `FMath::CubicInterp` needs to reproduce the real curve — getting this sign wrong
   would have produced a curve bulging the wrong way, silently "looking plausible" but
   still incorrect.
2. **`FNexusSegmentEndpointRead::TangentVector` (Phase 06, already shipped) computes the
   RAW, un-negated tangent for both ends uniformly** — correct as Phase 06's own scope
   (preserve sign, don't interpret), so the End-negation is applied at THIS phase's own
   layer (`FNexusDebugRenderSnapshot::FindSegmentTangents`), not retrofitted into
   Phase 06's struct.
3. **Reused, not duplicated, this session's own earlier world-space fix** — the new
   `FNexusLandscapeReader::TryResolveSegmentEndpointWorldTangent` applies the exact same
   `ULandscapeSplinesComponent::GetComponentTransform()` the location fix uses, just via
   `TransformVector` (rotation+scale only) instead of `TransformPosition` — correct for
   a tangent (direction*length), not a position.
4. **One shared curve implementation, not two** — `FNexusDebugPrimitives::
   SampleHermiteCurve` (pure `FMath::CubicInterp` sampling, no drawing) is called by
   both `NexusDebugLandscapeGroupRenderers.cpp` and `NexusDebugRoadsGroupRenderers.cpp`;
   neither reimplements Hermite math itself.
5. **The Roads group's offset lines needed a genuinely curve-following right-vector, not
   just curved sample points** — `DrawOffsetPolyline` computes a per-sample local
   direction via finite difference between neighboring curve samples (not the analytic
   Hermite derivative — a simpler, still-accurate-enough approach for a debug aid, not
   production geometry) so the lateral offset (Highway edges, lane lines, sidewalks)
   stays a consistent distance from the now-curved centerline along its whole length.
6. **Graceful fallback preserved everywhere** — if no matching native
   `ULandscapeSplineSegment` is found for a given (PointA,PointB) pair (e.g. a
   virtually-mapped pair not yet synced to Landscape), both renderers fall back to the
   original straight-line behavior rather than drawing nothing.
7. **New per-Refresh() data, same live-read boundary as everything else on the
   snapshot** — `FNexusDebugRenderSnapshot::Refresh()` now also calls
   `FNexusLandscapeReader::EnumerateSegments(Landscape)` once per refresh (throttled by
   the existing `RefreshIntervalSeconds`), builds a `ControlPoint* -> HighwayPointId`
   lookup from the already-in-progress Points loop, and populates a new `Segments`
   array — Phase 30's own "no renderer reads live Landscape geometry per frame" rule is
   about renderers, not `Refresh()` itself (which already resolves `SourcePoint.
   LoadSynchronous()` for every point).

## Changes

- `Public/Debug/NexusDebugPrimitives.h` / `.cpp` — new `SampleHermiteCurve` (pure
  `FMath::CubicInterp` sampler, `NumSubdivisions+1` points).
- `Public/Reader/NexusLandscapeReader.h` / `Private/Reader/NexusLandscapeReader.cpp` —
  new `TryResolveSegmentEndpointWorldTangent` (world-space tangent vector, same
  `GetOuterSafe()`-resolved component transform as the location fix, via
  `TransformVector`).
- `Public/Debug/NexusDebugRenderSnapshot.h` / `.cpp` — new `FNexusDebugSnapshotSegment`
  struct, `Segments` array, `FindSegmentTangents` (resolves the correctly-oriented,
  sign-flipped tangent pair for a requested direction, hiding the native-segment-
  orientation-vs-requested-direction reversal logic in one place). `Refresh()` populates
  `Segments` via `EnumerateSegments` + the control-point lookup.
- `Private/Debug/NexusDebugLandscapeGroupRenderers.cpp` — `RenderSegments` samples the
  Hermite curve (12 subdivisions) instead of one straight `DrawLine`, with fallback.
- `Private/Debug/NexusDebugRoadsGroupRenderers.cpp` — `DrawOffsetPolyline` samples the
  curve and computes a per-sample offset via finite-difference local direction, with
  fallback.
- `project-specifications/phases/phase-30a.md` — `Status` -> `Ready for Review`; gained
  an Implementation note; 2 of 4 completion criteria checked as structural fact (shared
  implementation, world-space correctness), 2 left unchecked for the user's own visual
  in-editor pass.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, 0 errors, 13 actions.
- **No automated test run/added** — per `AGENT-RULES.md`'s Agent Testing Policy. Manual
  re-verification for the user: tick `Landscape.Segments` and `Roads.Highways`/`Lanes`
  on a Highway with a real curve, confirm the debug lines now bend with the visible
  Landscape spline curve instead of cutting a straight chord across it.

## Result

Both halves of the user's original report (location offset, and now curve shape) are
implemented and build-verified. `Landscape.Segments` and the Roads group's offset lines
now follow the real Landscape Hermite curve, sourced from the same live per-segment
tangent data the native engine itself uses for tessellation, transformed into world
space via the same fix as the location bug.
