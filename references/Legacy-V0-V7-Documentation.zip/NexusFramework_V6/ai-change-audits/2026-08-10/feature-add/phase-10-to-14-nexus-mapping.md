# Phases 10-14 — Nexus Mapping (Landscape Entity → HighwayPointId, Highway/City/State Membership, Config Asset Persistence, Mapping Validation)

Task: Phases 10, 11, 12, 13, 14 — the full Nexus Mapping stage
Category: feature-add
Phase: phases/10, phases/11, phases/12, phases/13, phases/14
Status: Ready for Review (all five)
Completed Date: 2026-08-10
Completed Time: 02:20 NST (+0545)

## Context

Picked up via `/TODO` after Phases 05-09 (Landscape Reader arc) were moved to `Ready
for QA` by the user, who also pasted real console-log output from manually running all
five `Nexus.Reader.*` commands against a live 10-point closed-loop test Highway on
`Landscape_0` and said "i think done, next phase if you okay." That verification pass
and its exact criterion-by-criterion coverage is recorded as a new dated section
appended to `phase-06-to-09-landscape-reader.md` (this file's own sibling record) and
as edits to `phases/05.md`-`09.md`'s own Completion Criteria checkboxes — not repeated
here. Phases 10-14 (all five "Nexus Mapping" phases) were then batched together per the
user's standing "3-5 small phases per go" instruction, since they form one natural
architectural unit (all build on the same new `UNexusConfigAsset`/`FNexusMapping`
module) with no other phase's scope in between.

## Problem / Goal

Implement `project-specifications/phases/phase-10.md` through `phase-14.md`: the
Mapping stage of the five-stage pipeline (project-specifications/04-v6-architecture.md)
- Landscape entity -> Nexus ID + relationships, still no generation/meshing, still no
Location/Rotation/Tangent caching (shared Not Allowed list across all five phases).

## Findings

1. **Where the Mapping-stage data actually lives had to be decided up front**, since
   Phase 13 ("Config Asset Persistence") is explicitly what makes it durable, but
   Phases 10-12 need somewhere to write to before Phase 13 exists in isolation. Rather
   than building a throwaway subsystem-owned array for 10-12 and migrating it into a
   Data Asset for 13, `UNexusConfigAsset : public UDataAsset` (Phase 13's own class)
   was built first and Phases 10/11/12/14 all operate on its arrays directly - no
   redundant/duplicate storage, no migration step.
2. **Phase 01's own doc comments on `NexusHighway.h`/`NexusCity.h` attributed City
   ownership to Phase 11** ("Point order, City ownership ... populated by ... Phase
   11"), but the actual phase-11.md/phase-12.md task split gives City ownership to
   Phase 12 specifically (phase-11.md's Allowed list only covers OrderedPointIds/
   bIsClosedLoop/junction-splitting; phase-12.md's Allowed list explicitly owns City/
   State assignment and InterCityHighway). Followed the actual phase files, not the
   older Phase 01 comment - `NexusHighway.h`'s own comment now cross-references this
   record instead of repeating the stale attribution.
3. **`ALandscapeProxy::GetLandscapeGuid()` confirmed as the actual "stable per-Landscape
   identity" API** (`LandscapeProxy.h`, UE 5.8) - verified against engine source before
   using it, matching 04-v6-architecture.md's "not the map package name" requirement
   directly: this Guid lives on the actor, unaffected by renaming/moving the containing
   map.
4. **Config asset save/load pattern ported from V5's exact proven code**
   (`NexusFrameworkEditorSubsystem.cpp`'s Layout-asset save path), specifically its
   documented lesson: "Reuse an existing object at this path if one's already loaded -
   unconditional CreatePackage/NewObject on a re-save breaks SavePackage with
   'partially loaded'." `FNexusConfigAssetIO::LoadOrCreateConfigAsset` checks
   `LoadObject` first, only falling to `CreatePackage`+`NewObject` when nothing is
   loaded yet - same shape V5 uses.
5. **Chose `UPackage::SavePackage`/`LoadObject` (CoreUObject) over V5's own
   `UEditorAssetLibrary`/`EditorScriptingUtilities`-plugin approach** - functionally
   equivalent for this job, but avoids enabling a new plugin in the .uproject (V5's
   `EditorScriptingUtilities` is `EnabledByDefault: false` and V5 explicitly turns it
   on) for what CoreUObject's own `SavePackage.h`/`UObjectGlobals.h` APIs already cover.
   Only new Build.cs dependency added this batch: `AssetRegistry` (for
   `FAssetRegistryModule::AssetCreated`, needed once per newly-created asset).
6. **Highway chain decomposition (Phase 11) needed a new algorithm, not a bigger reuse
   of Phase 07's `WalkChainFrom`** - Phase 07's walk starts from one given point and
   stops at the first junction/dead-end/closed-loop-return, which is exactly right for
   a single sample walk but doesn't by itself decompose an ENTIRE graph into all its
   constituent Highway chains with junction-splitting. Implemented as a standard
   two-pass graph decomposition instead (`FNexusMapping::MapHighways`,
   `NexusMapping.HighwayMapping.cpp`'s own top comment has the full algorithm
   description): pass 1 walks every edge anchored at a junction/dead-end outward until
   the next one (this is what splits a junction into multiple distinct Highways rather
   than one merged chain); pass 2 hands whatever's left over - by construction,
   entirely degree-2 with no junction ever reached - to Phase 07's own `WalkChainFrom`
   directly, reusing its already-proven closed-loop termination rather than
   reimplementing it. A junction/dead-end point legitimately appears as the shared
   boundary entry of more than one resulting Highway - this is expected, not a
   duplicate-mapping violation (Phase 14 checks HighwayPoints for duplicate StableId,
   never duplicate Highway membership).
7. **Idempotency required an explicit re-run guard for Phase 11 too**, even though
   phase-11.md's own Completion Criteria don't list it directly (unlike Phase 10's,
   which does) - re-running `MapHighways` naively would recreate every chain as a
   second, duplicate Highway entry each call, which would visibly break the very first
   thing a user testing this the same way they tested the Reader phases (running a
   command twice) would notice. `IsChainAlreadyMapped` compares a freshly-walked
   chain's `OrderedPointIds` (forwards or reversed) against every existing Highway
   before creating a new one.
8. **"City assignment for a Highway (existing City or new)" (Phase 12's Allowed list)
   interpreted as find-or-create by Name**, not spatial/automatic City detection -
   nothing in the architecture docs defines a spatial City-boundary concept, and
   City/Highway grouping reads as a human/UI decision in the full product (no City/
   Highway-assignment UI exists yet, that's many phases away). Phase 12 builds the
   correct underlying operations (single-owner vs InterCityHighway invariant enforced
   by `AssignHighwayToCity`/`AssignHighwayAsInterCity`, live-derived center) exercised
   via manual console commands, not automatic spatial inference.
9. **City->Highway membership is deliberately NOT stored** (no `HighwayIds` array on
   `FNexusCity`), only the forward reference (`Highway.CityId`/`EndCityId`) - avoids a
   second, easily-stale copy of the same relationship; a reverse-lookup query is
   Phase 20's ("Representation - Relationship Queries") explicit job, not duplicated
   here. Matches the same "derive, don't cache" reasoning City center's own live
   computation already follows.
10. **Both new Representation-struct types needed a `TSoftObjectPtr`** -
    `FNexusHighwayPoint.SourcePoint` (`TSoftObjectPtr<ULandscapeSplineControlPoint>`) -
    matching V5's own `FNexusRoadPoint::SourcePoint` field and
    04-v6-architecture.md's explicit "keyed via the same renamed-control-point identity
    trick V5 proved works" instruction; resolved live via `LoadSynchronous()` every
    read (ComputeCityCenter, Phase 14's validation), never cached.

## Changes

- `Source/NexusFrameworkEditor/Public/Representation/NexusHighwayPoint.h` - added
  `StableId` (Phase 08's rename-tag join key) and `SourcePoint`
  (`TSoftObjectPtr<ULandscapeSplineControlPoint>`).
- `Source/NexusFrameworkEditor/Public/Representation/NexusHighway.h` - added
  `OrderedPointIds`, `bIsClosedLoop` (Phase 11), `CityId`, `EndCityId`,
  `bIsInterCityHighway` (Phase 12).
- `Source/NexusFrameworkEditor/Public/Representation/NexusCity.h` - added `StateId`
  (Phase 12).
- New `Public/Mapping/NexusConfigAsset.h` (Phase 13) - `UNexusConfigAsset : public
  UDataAsset` (`LandscapeId` + `States`/`Cities`/`Highways`/`HighwayPoints` arrays);
  data only, no behavior.
- New `Public/Mapping/NexusConfigAssetIO.h` / `Private/Mapping/NexusConfigAssetIO.cpp`
  (Phase 13) - `GetConfigAssetName`/`GetConfigPackagePath`
  (`/Game/NexusConfigs/<LandscapeId-digits>_nexusconfig`),
  `LoadOrCreateConfigAsset`/`SaveConfigAsset` + `Nexus.Mapping.LoadOrCreateConfig`/
  `.SaveConfig` console commands.
- New `Public/Mapping/NexusMapping.h` - `FNexusMapping` static class declarations for
  all four remaining phases plus shared Find*ById/ByName lookup helpers, and
  `ENexusMappingValidationSeverity`/`FNexusMappingValidationEntry` (Phase 14's own
  Blocking/Warning types - a separate type from Phase 09's Source-stage equivalent,
  deliberately, since Mapping and Source are independent stage modules that don't share
  types across the boundary).
- New `Private/Mapping/NexusMapping.PointMapping.cpp` (Phase 10) - shared lookup-helper
  definitions, `MapControlPoint`/`MapControlPoints`/`FindDuplicateStableIdMappings` +
  `Nexus.Mapping.MapControlPoints`/`.DumpGraph` console commands.
- New `Private/Mapping/NexusMapping.HighwayMapping.cpp` (Phase 11) - `MapHighways`
  (two-pass junction-splitting/closed-loop decomposition, see Findings #6) +
  `Nexus.Mapping.MapHighways` console command.
- New `Private/Mapping/NexusMapping.CityStateMapping.cpp` (Phase 12) -
  `FindOrCreateCityByName`/`FindOrCreateStateByName`/`AssignHighwayToCity`/
  `AssignHighwayAsInterCity`/`AssignCityToState`/`ComputeCityCenter` +
  `Nexus.Mapping.CreateCity`/`.CreateState`/`.AssignHighwayToCity`/
  `.AssignHighwayInterCity`/`.SetCityState`/`.ComputeCityCenter` console commands.
- New `Private/Mapping/NexusMapping.Validation.cpp` (Phase 14) -
  `ValidateMappingStage` (duplicate-mapping, orphaned/foreign SourcePoint, Highway/
  City/State membership consistency, all Blocking-only) + `Nexus.Mapping.
  ValidateMappingStage` console command.
- `Source/NexusFrameworkEditor/Public/Subsystem/NexusFrameworkSubsystem.h` - added
  `ActiveConfig` (`TObjectPtr<UNexusConfigAsset>`, Transient) + `GetActiveConfig`/
  `SetActiveConfig` - the "loaded config asset ... must survive the tab closing and
  reopening" role project-specifications/04-v6-architecture.md already assigned to this
  subsystem, now actually populated. No `.cpp` change needed (inline accessors).
- `Source/NexusFrameworkEditor/NexusFrameworkEditor.Build.cs` - added `AssetRegistry`
  (see Findings #5).

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development` - **Result: Succeeded**, all new
  Mapping files plus every touched Representation/Subsystem file compiled cleanly,
  first attempt. Build was blocked once by Live Coding (the user's own running editor
  session held the lock); user chose to have the editor closed so a full offline build
  could run rather than routing through in-editor Live Coding.
- **No automated tests written or run, no editor launched for verification** - per
  `AGENT-RULES.md`'s Agent Testing Policy. Exact manual-check steps for every
  Completion Criterion across all five phases are written into each phase's own file.

## Result

Implementation complete, build-verified only, for all five phases. Every Completion
Criterion that needs a real Landscape/editor session is left unchecked pending the
user's own manual pass (console commands provided for each); the two purely
code-shape criteria (Phase 13's "no asset picker," Phase 14's "clean pass = zero
entries") are checked via review, consistent with how Phases 05/09 handled the same
kind of criterion.

## Verification — 2026-08-10 (user manual pass, real Landscape/config)

User ran the full `Nexus.Mapping.*` command set against the same real 10-point
closed-loop test Landscape (`Landscape_0`) used for the Phase 05-09 verification pass,
reusing the config asset that pass's `LoadOrCreateConfig` had already created, and
pasted the Output Log results.

**Confirmed by this run** (phase files updated accordingly):
- Phase 10's idempotency criterion: `MapControlPoints` logged `TotalHighwayPoints=10
  NewThisRun=0` against the already-mapped Landscape.
- Phase 11's closed-loop criterion: `MapHighways` logged `Highway[0] PointCount=10
  ClosedLoop=true`, `NewThisRun=0` (also confirms MapHighways' own re-run idempotency,
  Findings #7).
- Phase 13 (partial): `LoadOrCreateConfig` resolved the SAME config asset path
  (`/Game/NexusConfigs/06AD7994...490783B500BC81A27A951F63_nexusconfig`) already
  populated with the prior run's data (`States=1 Cities=1 Highways=1
  HighwayPoints=10`) - real evidence the asset persists and reloads correctly across
  separate command invocations (the load-if-present half). The specific "map renamed"
  scenario the criterion actually asks for was not exercised.
- Phase 14's clean-pass criterion (in addition to the existing code-review
  confirmation): `ValidateMappingStage` logged "clean - zero validation entries"
  against this real, fully-mapped config.

**Still open / not exercised by this run**:
- Phase 10's double-assignment-guard criterion - only the zero-conflict path was
  logged ("guard held"); no deliberate StableId conflict was injected.
- Phase 11's junction-splitting criterion - this test data has no junction (single
  closed loop, every point 2-connected) - same gap Phase 07's own equivalent criterion
  already has.
- **Phase 12 entirely** - `AssignHighwayToCity`/`AssignHighwayInterCity`/
  `SetCityState`/`ComputeCityCenter` were all invoked with no arguments, which only
  exercises each command's usage-message path, not its actual logic. The trailing
  `DumpGraph` confirms this directly: every Highway/City still shows an all-zero
  `CityId`/`EndCityId`/`StateId`. `CreateCity`/`CreateState` (called with no name
  argument either) did create new entries (`City 2`/`State 2`, find-or-create's
  create-path), so those two functions' happy path is at least minimally exercised,
  but neither of Phase 12's own two Completion Criteria (cross-city bridging,
  live-updating center) has been.
- Phase 13's actual "renamed map" scenario, and Phase 14's deliberate-break criterion -
  neither attempted this run.

None of the open items point to a suspected bug - Phase 12 in particular just hasn't
been exercised with real arguments yet, not exercised-and-failed. Consistent with
`/TODO`'s Step B7 and the same reasoning used for the Phase 06-09 batch's own
verification gap, this doesn't block moving on to Phase 15 - Phase 15 only wires
Phase 10/11's control-point/Highway re-run into the automatic enable flow, it doesn't
depend on Phase 12's City/State assignment commands, which stay manually/UI-driven
regardless.

## Important Notes

- The full manual-verification console-command set added this batch: `Nexus.Mapping.
  LoadOrCreateConfig`, `.SaveConfig`, `.MapControlPoints`, `.MapHighways`, `.CreateCity`,
  `.CreateState`, `.AssignHighwayToCity`, `.AssignHighwayInterCity`, `.SetCityState`,
  `.ComputeCityCenter`, `.ValidateMappingStage`, plus the general-purpose `.DumpGraph`.
  Together with the five `Nexus.Reader.*` commands from Phases 05-09, this is now a
  reasonably complete Source+Mapping smoke-test toolkit exercisable entirely from the
  Output Log console, with no UI yet.
- `Nexus.Mapping.LoadOrCreateConfig` and `.MapControlPoints`/`.MapHighways`/etc create
  and, on first creation, immediately save a real `.uasset` file under
  `/Game/NexusConfigs/` in the project's Content folder - this is a real, visible
  side effect of running the verification command, not a no-op dry run. Safe to delete
  the folder afterward if it was only a test.
- Neither `MapControlPoints` nor `MapHighways` nor any Phase 12 function is wired to run
  automatically - every one of them is manually triggered via its own console command
  only. Phase 15 ("Automatic Config Lifecycle - Plugin Enable") is explicitly what wires
  LandscapeId resolve -> config load/create -> Mapping re-run into the actual
  enter-Landscape-Mode flow; nothing in this batch does that yet.
- `FNexusMapping::ComputeCityCenter` counts an InterCityHighway's points toward BOTH
  bridged cities' centers (not split/weighted) - a reasonable first interpretation of
  "bridges two cities," not verified against any V5 precedent (V5's own City center
  computation wasn't checked for this specific edge case this batch) - worth a second
  look if a later phase's behavior depends on the exact split.
- Phase 20 ("Representation - Relationship Queries") is where City->Highway and
  City->State reverse-lookup helpers belong, per Findings #9 - don't duplicate that
  work when this batch's forward-reference-only design is exactly why Phase 20 still
  has real work to do.
