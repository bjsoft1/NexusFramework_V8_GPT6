# Phase 18 — Representation — HighwayPoint Struct

Task: Phase 18
Category: feature-add
Phase: phases/18
Status: Ready for Review
Completed Date: 2026-08-10
Completed Time: 04:10 NST (+0545)

## Context

Picked up via `/TODO` after Phase 13's config-path refactor. The user asked to complete
only this one phase this round (context budget), breaking from the earlier "3-5 small
phases per go" batching pattern used for Phases 05-09/10-14/15-17 - so unlike those, this
is a single-phase report. Confirmed via `agent-todos/active/` and
`agent-todos/ready-for-development/` (both empty) and `PHASE-STATUS.md` that Phase 18 is
the correct next item - the lowest-numbered `Not started` phase, first of the
"Representation" arc (18-22) following the just-completed "Automatic Config Lifecycle"
arc (15-17).

## Problem / Goal

Implement `project-specifications/phases/phase-18.md`: give `FNexusHighwayPoint`
live-resolved geometry accessors (Location/Rotation/Tangent, reading through Mapping's
`SourcePoint` reference, never a cached field) and a derived `ConnectedHighwayIds` field,
per `05-v6-data-flow.md`'s "no persisted geometry, always live" rule.

## Findings

1. **`SourcePoint`/`StableId` already existed on `FNexusHighwayPoint`** (added by Phase
   10, "Nexus Mapping - Landscape Entity to HighwayPointId") - Phase 18's job was purely
   the accessor/derived-field layer on top, not the join itself.
2. **The accessors deliberately do NOT apply a Landscape-space-to-world-space
   transform** - `ULandscapeSplineControlPoint::Location`/`Rotation` are documented by
   the engine header as "in Landscape-space," but `FNexusLandscapeReader`'s own Phase
   05/06 code (`NexusLandscapeReader.cpp`, `.Segments.cpp`) already reads these same
   fields raw, with no `SplinesComponent->GetComponentTransform()` conversion - and that
   exact raw-read behavior is what the user already manually verified against a real
   10-point test Landscape earlier this session. Phase 18's accessors match that
   established, already-proven convention rather than introducing a new transform that
   would make Location comparisons inconsistent between the Reader stage and the
   Representation stage.
3. **"Tangent" has no single meaningful value at the per-point level** - tangent LENGTH
   is a per-segment-connection value (`FLandscapeSplineSegmentConnection::TangentLen`,
   Phase 06's `FNexusSegmentEndpointRead`), not a scalar owned by the point itself; a
   point's own `Rotation` only defines a shared tangent DIRECTION for every segment
   touching it. `GetLiveTangentDirection()` returns that direction (unit vector) only -
   there is no `GetLiveTangentLength()`, since Phase 06's segment-level reads are already
   the correct place for that value and duplicating it here would risk two divergent
   "sources of truth" for the same underlying data.
4. **`bool GetLive*(Out...) const` (resolve-or-fail, no value written on failure) matches
   the codebase's existing `TryParseStableId`-style contract** - chosen specifically so
   "no silent zero-vector" (this phase's own Completion Criterion) is enforced by the
   type signature itself, not just by convention. `SourcePoint.LoadSynchronous()` is the
   same resolution call already used in `NexusMapping.Validation.cpp`/
   `.CityStateMapping.cpp`/`.Reconciliation.cpp` - no new resolution pattern introduced.
5. **`ConnectedHighwayIds`'s recompute is deliberately point-scoped, not graph-wide** -
   `RecomputeConnectedHighwayIds(AllHighways)` does a linear scan of one point against
   every Highway's `OrderedPointIds`. Phase 19 ("Representation - Highway/City/State
   Graph") is explicitly scoped to build the real graph container with FGuid-keyed maps
   and O(1) lookups (see its own Allowed list) and Phase 20 builds junction detection on
   top of the resulting field - Phase 18 only needed to establish the field itself and a
   correct (if not yet optimized) way to populate it, matching V5's own precedent
   (`ConnectedHighwayIds` "rebuilt by `FNexusWorldData` mutators" -
   `project-specifications/v5-complete-reference.md`) where the mutator/graph layer, not
   the point struct, owns keeping it in sync at scale.
6. **New manual-verification console command**: `Nexus.Representation.
   DumpHighwayPointGeometry`, following the same `FAutoConsoleCommand` hook pattern every
   phase since 05 has used - recomputes `ConnectedHighwayIds` and logs live Location/
   Rotation/TangentDirection (or an explicit `UNRESOLVED`) for every HighwayPoint in the
   active config. Placed in a new `Private/Representation/NexusHighwayPoint.cpp` (the
   `Representation/` subfolder previously held header-only structs; this is the first
   `.cpp` there).

## Changes

- `Source/NexusFrameworkEditor/Public/Representation/NexusHighwayPoint.h` - added
  `ConnectedHighwayIds` (`TArray<FGuid>`, `VisibleAnywhere`/derived) +
  `RecomputeConnectedHighwayIds`, `GetLiveLocation`, `GetLiveRotation`,
  `GetLiveTangentDirection` (all inline member functions, matching the file's existing
  `MakeDefault()` style); added `#include "Representation/NexusHighway.h"` for the
  recompute signature's `TArray<FNexusHighway>` parameter (no circular include -
  `NexusHighway.h` doesn't reference `NexusHighwayPoint.h`).
- New `Source/NexusFrameworkEditor/Private/Representation/NexusHighwayPoint.cpp` -
  `Nexus.Representation.DumpHighwayPointGeometry` console command (Findings #6).
- `project-specifications/phases/phase-18.md` - Status → `Ready for Review`; Completion
  Criteria rewritten with exact manual-check console-command steps.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` -
  **Result: Succeeded**. `NexusHighwayPoint.cpp` and the regenerated
  `Module.NexusFrameworkEditor.cpp` compiled clean, 0 errors.
- **No automated tests written or run, no editor launched for verification** - per
  `AGENT-RULES.md`'s Agent Testing Policy. Both Completion Criteria need a real editor
  session (drag a control point live; delete one and check for `UNRESOLVED` +
  `Nexus.Mapping.ValidateMappingStage`'s Blocking entry) and are left unchecked, with
  exact steps written into the phase file per policy.

## Result

Implementation complete, build-verified only. Both Completion Criteria require the
user's own manual editor session and are left unchecked pending that.

## Important Notes

- This is a single-phase report, not a batch - the user explicitly asked to complete
  only one phase this round due to context budget, a deliberate departure from this
  session's usual "3-5 small phases per go" pattern (Phases 05-09/10-14/15-17). The next
  natural batch starting point is Phase 19.
- `GetLiveLocation`/`GetLiveRotation`'s "no world-transform" behavior (Findings #2) is a
  convention match with the existing Reader code, not an independent design decision -
  if a future phase ever adds a proper Landscape-space-to-world-space conversion to the
  Reader stage, this struct's accessors should be updated the same way, at the same
  time, to keep both stages consistent.
