# Phase 43/44 — Streaming/Data Layer Grouping + Generation Validation Gate

Date: 2026-08-10
Category: feature-add
Phase: 43 (Static Generator — Streaming/Data Layer Grouping), 44 (Static Generator —
Validation Gate)

## Context

Picked up as the next batch after the Phase 45 module-load crash's permanent fix was
built and confirmed working in-editor by the user (see `ai-change-audits/2026-08-10/
research/editor-shutdown-crash-live-coding-new-reflected-types.md`'s second
`## Correction` section). Phase 45/46/47 (the Activation Point cluster) had already
landed out of numeric order in an earlier part of this session; Phase 43/44 were the
next genuinely `Not started` phases, deliberately picked over jumping to Phase 48
(Gizmo Integration) — that phase's own `## Progress note` already flags real
interactive-viewport code as needing a dedicated in-editor-testable pass, not a
tail-of-batch implementation, and Phase 49/50+ explicitly depend on Phase 48 signing off
first (`phase-49.md`: "Sign off this phase as the proof point that Phases 50+ build on a
validated foundation"). Batch stopped at two phases for this reason, not bundled with 48.

## Problem / Goal

Phase 43: generated Static (merged mesh) and Instanced output had zero streaming-cell
awareness — `NexusStaticGeneratorCommands.cpp` wrote every Highway's mesh to one flat
`/Game/NF/Generated/Highways/` folder, and `ANexusGeneratedInstancedMeshHost` was a
single shared actor for the entire world, spawned once and reused forever. Neither
`11-v6-static-dynamic-architecture.md`'s "batches these per streaming cell" rule nor
`10-v6-runtime-schema.md`'s `DataLayerAssetName` precedent had any real implementation —
`FNexusState` didn't even have the field yet.

Phase 44: `Public/Generation/NexusGenerationValidation.h` existed (an earlier session's
partial work) declaring `FNexusGenerationValidationGate` with a documented "scoped to
unclassified-object check only, streaming-assignment consistency is N/A until Phase 43
exists" comment — but had no `.cpp` at all. Genuinely dead code (nothing included the
header, nothing implemented the two declared functions).

## Findings

- V5's own `FNexusState::DataLayerAssetName` (grep-verified across
  `NexusFramework_V5/Source/`) was itself never wired to anything beyond the schema
  field — no V5 code resolves it into a real engine Data Layer, no V5 code groups
  generated output by it. "Reusing V5's precedent" means the SCHEMA shape, not a
  battle-tested implementation to port.
- A HighwayPoint can belong to more than one Highway at a junction
  (`ConnectedHighwayIds`, Phase 36/37) — an inter-City/inter-State bridge junction can
  therefore have connected Highways resolving to two different streaming cells. No
  existing code handled this; the new resolver picks `ConnectedHighwayIds[0]`
  deterministically and Phase 44's validation gate flags the mismatch as a Warning
  rather than leaving it a silent, unexplained tie-break.
- `AActor`'s own direct Data Layer assignment API
  (`FAssignActorDataLayer::AddDataLayerAsset`) is a private, friend-class-only method —
  not callable from arbitrary editor code. The sanctioned public entry point is
  `UDataLayerEditorSubsystem::AddActorToDataLayer` (module `DataLayerEditor`, not
  previously a dependency of this project) — the same API the Data Layer Outliner UI
  itself uses.
- `UDataLayerManager::GetDataLayerManager(UWorld*)` returns null on a non-World-
  Partition-enabled level (it's `Within = WorldPartition`) — every real-Data-Layer code
  path treats that as a normal, logged no-op, never an error, since this project's
  current test map(s) may not be WP-enabled yet.

## Changes

**Phase 43:**
- `Source/NexusFrameworkEditor/Public/Representation/NexusState.h` — added
  `FName DataLayerAssetName = NAME_None` (new UPROPERTY, additive — no rename, no
  `v6-coding-standard.md` serialization risk).
- New `Public/Generation/NexusStreamingCellResolver.h` + `Private/Generation/
  NexusStreamingCellResolver.cpp` — `FNexusStreamingCellResolver`
  (`ResolveStreamingCellForHighway`/`ResolveStreamingCellForHighwayPoint`/
  `MakeCellFolderName`/`TryAssignActorToRealDataLayer`). Plain static-method class, no
  UObject/UCLASS — deliberately keeps this batch's only new reflected-type surface to
  two plain `UPROPERTY` data members (see Hidden-Bug Audit below).
- `NexusStaticGeneratorCommands.cpp` — `GenerateHighwayMeshesConsoleCommand` nests
  generated package paths under `/Game/NF/Generated/<Cell>/Highways/...` (`"Default"`
  for an unset cell) instead of one flat folder.
- `Public/Generation/NexusGeneratedInstancedMeshHost.h` — added
  `FName StreamingCellName` (new UPROPERTY).
- `NexusInstancingGenerator.h`/`.cpp` — `GenerateHighwayPointPoleInstances` gained a
  `FName cellName` filter parameter; only instances points resolving to that cell.
- `NexusInstancingGeneratorCommands.cpp` — replaced the single-shared-host
  `FindOrSpawnHost` with `FindOrSpawnHostForCell` (one actor per resolved cell, real
  Data Layer assignment attempted via the resolver); both console commands now loop over
  every distinct streaming cell present in the active config.
- New `Private/Generation/NexusStreamingCellResolverCommands.cpp` —
  `Nexus.Generation.DumpStreamingCellAssignment` (read-only, logs every Highway/
  HighwayPoint's resolved cell).
- `NexusFrameworkEditor.Build.cs` — added `DataLayerEditor` to
  `PrivateDependencyModuleNames` (for `UDataLayerEditorSubsystem`).

**Phase 44:**
- `Public/Generation/NexusGenerationValidation.h` — `ValidateGenerationStage` signature
  changed from no-args to `(const UNexusConfigAsset& config)` (the header had no
  compiled callers yet, so this isn't a breaking change to anything real).
- New `Private/Generation/NexusGenerationValidation.cpp` — implements
  `ValidateObjectTypeIsClassified` (via `UEnum::IsValidEnumValue`) and
  `ValidateGenerationStage` (classification check + Phase 43's streaming-consistency
  check); `Nexus.Generation.ValidateStage` and
  `Nexus.Generation.TestValidationGateCatchesUnclassified` console commands.
- `Debug/NexusDiagnostics.h`/`.cpp` — `GatherDiagnostics` now folds Generation-stage
  entries in as a fourth stage (Source/Mapping/Representation/Generation), same pattern
  as the other three.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -WaitMutex -NoHotReloadFromIDE` —
  Succeeded, 0 errors, 0 warnings (one `UDataLayerInstance::GetDataLayerFName`
  deprecation warning on the first pass, fixed by switching to `GetFName()` before the
  final clean build). Editor was closed for the build (no file-lock failure).
- Console-command-level logic is exercised by
  `Nexus.Generation.TestValidationGateCatchesUnclassified` (deterministic, no active
  config needed) — not yet run (agent cannot launch the editor).
- No automated test written/run (`AGENT-RULES.md`'s Agent Testing Policy).

## Result

Both phases build-verified and functionally complete against their own Allowed lists;
both left at `Ready for Review` with explicit unchecked completion criteria for the
parts that need a real multi-cell/multi-Data-Layer test map and manual in-editor
verification — see each phase file's own "Manual QA still required" section for the
exact steps.

## Important Notes

- Phase 41's "Static Generator only commits a `UStaticMesh` asset, no level actor" scope
  was deliberately NOT expanded — real per-object World Partition streaming of baked
  static geometry stays Phase 83's job ("Runtime Compiler — Streaming Integration...
  reusing Phase 43's grouping"), consistent with that phase file's own framing. Static
  content's "streaming cell grouping" in this pass is package-path nesting only.
- `ANexusGeneratedInstancedMeshHost` now spawns N actors per world (one per distinct
  resolved cell) instead of always exactly one — any future code enumerating this actor
  type via `TActorIterator` expecting a single instance needs to account for this.
- No generated assets existed on disk at the old flat `/Game/NF/Generated/Highways/`
  path before this change (checked — empty), so the package-path nesting change orphans
  nothing.

## Hidden-Bug Audit (per this batch's own stop-condition rules)

- **Namespace/global/static constructors**: no new global calls a reflected type's
  `StaticStruct()`/`StaticClass()` at construction time — the exact Phase 45 pattern.
  `StaticEnum<ENexusStaticObjectType>()` is only ever called from inside a function body
  (`ValidateObjectTypeIsClassified`), same as the pre-existing `ObjectTypeToString`
  helper it sits next to.
- **New UCLASS/USTRUCT/UPROPERTY**: two new plain `UPROPERTY` data members on EXISTING
  reflected types (`FNexusState::DataLayerAssetName`, `ANexusGeneratedInstancedMeshHost::
  StreamingCellName`) — no new UCLASS/USTRUCT introduced this batch.
  `FNexusStreamingCellResolver`/`FNexusGenerationValidationGate` are deliberately plain,
  non-reflected static-method classes (same shape as `FNexusMapping`/
  `FNexusLandscapeReader`), so this batch adds zero new reflected TYPE surface, only two
  new fields on already-safe existing types.
- **Module dependencies**: `DataLayerEditor` added to Build.cs — a link-time-only
  declaration, no runtime static-init implication.
- **Delegates/tickers**: none added.
- **UObject/world/viewport/component ownership**: `ANexusGeneratedInstancedMeshHost` now
  spawns multiple instances via the same `SpawnActor`/engine-GC-owned pattern the
  single-host precedent already used — no manual destroy anywhere, no new lifetime risk.
- **Raw/cached pointers**: `UDataLayerManager*`/`UDataLayerInstance*` in
  `TryAssignActorToRealDataLayer` are used and discarded within one function call, never
  cached.
- **Generated vs manual transform consistency**: not touched by this batch (no mesh/
  curve math changed, only package-path/actor-grouping logic).
