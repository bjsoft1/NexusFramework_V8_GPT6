# V6 UI + Hierarchy + Highway Point Schema Improvements

Date: 2026-08-10
Category: feature-add
Phase: N/A (ad-hoc, direct user request - not a `/TODO` phase pickup). Touches ground
Phase 80 ("Runtime Compiler - HighwayPoint Export") will later need to extend - see
that phase file's own appended note.

## Context

Nine-item direct user request, building on the same day's earlier Hierarchy panel
work (`ai-change-audits/2026-08-10/feature-add/hierarchy-panel-real-data-create-delete.md`):
Details/Diagnostics as independently dockable tabs, Debug Tree collapsed-by-default,
a resizable Hierarchy/Debug Tree splitter (~45% initial), removing the top-level
"Unassigned Highway" group in favor of an automatic fallback hierarchy, a consistent
"Name (Code)" tree-label convention, new editable HighwayPoint fields (Description,
CrossWalk, TrafficLight, Category, SubCategory), a real `ECategories` bitmask (V5's own
`ENexusPointTarget` precedent used sequential, non-power-of-two values under
`ENUM_CLASS_FLAGS` - a real bug), a locked-numeric-band `ESubCategory` enum, and new
Mapping-stage validation checks.

## Problem / Goal

Implement all nine items while preserving existing architecture/patterns and without
rewriting unrelated working systems (explicit user instruction).

## Findings

- `ECategories`/`ESubCategory`/`FNexusFinalPointData`/any Runtime export pipeline did
  not exist anywhere in V6's actual Source code before this task - only in
  `project-specifications/v5-complete-reference.md` (V5's own precedent docs) and
  `project-specifications/10-v6-runtime-schema.md` (a still-Drafted proposal). Phase 80
  ("Runtime Compiler - HighwayPoint Export"), the phase that would implement
  `FNexusRuntimeHighwayPoint` and actually propagate Editor-schema fields into a
  Runtime-consumed struct, is still `Not started`. Building a full export pipeline now
  would be exactly the "modify unrelated systems" the user's own instruction warned
  against, and would preempt Phase 80's own scope - implemented the Editor-schema
  fields only, and left an explicit forward-pointing note in `phase-80.md` (Note -
  2026-08-10) instead of silently doing nothing or silently over-building.
- User's item 6 code sample listed `PointFeatures` as a required field but did NOT
  include it in the actual property list, and separately said "if PointFeatures is an
  existing bitmask/struct, reuse it instead of creating duplicate concepts." It does
  not exist anywhere in V6. V5's own `ENexusHighwayPointFeature` precedent
  (TrafficLight/Crosswalk bits) covers exactly the same ground as the requested
  `bHasCrossWalk`/`bHasTrafficLight` bools. Decision: did not add a separate
  `PointFeatures` field - the two bools already cover it, and adding both would be the
  literal "duplicate concept" the user's own instruction said to avoid.
- User's item 4 ("auto-generate default hierarchy for orphaned Highways") directly
  overlaps a decision from the earlier same-day Hierarchy panel record: never fabricate
  a Highway with fake `OrderedPointIds` (Landscape-derived data must never be
  fabricated). Resolved WITHOUT relaxing that rule: the new fallback logic
  (`FNexusMapping::AdoptUnassignedHighwaysIntoFallbackHierarchy`) only ever reassigns
  `CityId` on a Highway that MapHighways already produced from real Landscape data -
  it never touches `OrderedPointIds`/`HighwayId`/`IsClosedLoop`, so it can never
  conflict with reconciliation/staleness detection (`CityId` is a pure
  ownership/organizational field, completely orthogonal to topology). "Imported
  Connector" (named in the user's message as something to preserve) turned out to be a
  V5-only term (`02-v5-feature-inventory.md`: "register 'Imported Connector' highways
  for untracked adjacencies") for exactly what V6's `ReconcileMappingStage`/
  `MapHighways`/`NewlyMappedHighways` already does - confirmed nothing extra was
  needed there.
- A brand-new placeholder Highway (`SeedDefaultHierarchyIfEmpty`, from the earlier
  same-day record) has zero points and no way to ever gain real Landscape data - if it
  were adopted into the SAME "Default City" the new fallback logic uses, it would sit
  there forever. Kept `SeedDefaultHierarchyIfEmpty`'s own "New State 1/New City 1" pair
  and `AdoptUnassignedHighwaysIntoFallbackHierarchy`'s "Default State/Default City"
  pair as two DELIBERATELY DIFFERENT, separately-reserved-Code pairs (`ST-DEFAULT`/
  `CITY-DEFAULT` vs the auto-incrementing "New State N" scheme) - a fresh, fully-empty
  config gets one; real-but-unassigned Landscape data gets the other; they never
  collide or need to interoperate.
- The Hierarchy Tree height splitter (item 3) only produces a meaningful proportional
  split once the Hierarchy tree is the ENTIRE content of its own tab - inside the OLD
  combined widget's AutoHeight-stacked layout (Nexus Panel / Details / Diagnostics as
  three sequential sections), `FillHeight`/`SSplitter` have no bounded parent height to
  divide. This made item 1 (the dockable-tabs split) a hard PREREQUISITE for item 3,
  not an independent, separately-orderable item - implemented the splitter as part of
  the new `SNexusHierarchyPanel`'s own root content (a real `FillHeight(1.f)` slot
  directly inside its owning `SDockTab`) rather than retrofitting it into the old
  layout first and redoing it.
- Splitting Details into its own dockable tab breaks the OLD design's direct
  same-object method calls (`BindDetailsViewToHierarchyItem` called straight from
  `OnTreeSelectionChanged` in the same widget). `UNexusFrameworkSubsystem` was already
  this codebase's established home for long-lived, mode-independent, editor-session-wide
  state (`ActiveConfig`, `RenderSnapshot`) - extended it with `FNexusDetailsTarget`
  (`Public/UI/NexusPanelSharedTypes.h`) + `GetDetailsTarget()`/`SetDetailsTarget()`/
  `OnDetailsTargetChanged` (Hierarchy tab publishes what's selected; Details tab reacts,
  including pulling the current value at its own Construct() time, so opening Details
  AFTER a selection already happened still shows the right thing) + a second delegate
  `OnActiveConfigDataChanged` (Details tab broadcasts after a HierarchyEntity edit
  commits; Hierarchy tab refreshes its tree/labels in response - replaces the OLD
  same-widget `HierarchyLabelRefreshPending`-deferred-to-Tick() mechanism, which no
  longer works once the tree lives in a different widget instance).
- A subtler correctness requirement the split surfaced: the OLD widget's
  `RefreshHierarchyTree` always ended by either rebinding DetailsView fresh or clearing
  it, REGARDLESS of whether the just-completed mutation touched the currently-selected
  entity - because any Create/Delete/Assign can reallocate the SAME backing `TArray`
  (`config->States`/`Cities`/`Highways`/`HighwayPoints`) the selected entity's struct
  pointer lives in, even when a DIFFERENT entity was mutated. `SNexusHierarchyPanel::
  RefreshHierarchyTree` preserves this by re-publishing (`PublishHierarchySelection`)
  on every successful reselect, not just when the reselected id actually changed - the
  Details tab's `RebindToCurrentTarget` always does a fresh `FNexusMapping::Find*ById`
  lookup on every publish, so this never leaves it holding a stale/dangling pointer.

## Changes

- New `Public/Representation/NexusPointCategoryTypes.h` - `ECategories` (real
  bit-shifted `1<<0`..`1<<7` bitmask, `None=0`, `ENUM_CLASS_FLAGS` applied correctly -
  fixes V5's sequential-value bug) and `ESubCategory` (locked numeric bands, ported
  verbatim from V5's `ENexusPointDescription`). `GetAllValidCategoryBits`/
  `GetExpectedCategoryForSubCategory` are `inline` (deliberately no companion .cpp - a
  new translation unit forces a full relink Live Coding can't do against a running
  editor; see Important Notes).
- `Public/Representation/NexusHighwayPoint.h` - added `Description` (FString),
  `bHasCrossWalk`/`bHasTrafficLight` (bool), `CategoryMask` (int32, `meta=(Bitmask,
  BitmaskEnum="/Script/NexusFrameworkEditor.ECategories")`), `SubCategory`
  (`ESubCategory`).
- `Public/Mapping/NexusMapping.h` + `Private/Mapping/NexusMapping.PointMapping.cpp`/
  `CityStateMapping.cpp` - added `FindCityByCode`/`FindStateByCode`,
  `GetFallbackStateCode`/`GetFallbackCityCode` (reserved `ST-DEFAULT`/`CITY-DEFAULT`),
  `AdoptUnassignedHighwaysIntoFallbackHierarchy` (CityId-only reassignment + a
  one-time "Imported Highway N" rename, see Findings).
- `Private/Mapping/NexusMapping.Reconciliation.cpp` - `ReconcileMappingStage` calls
  `AdoptUnassignedHighwaysIntoFallbackHierarchy` right after `MapHighways`.
- `Private/Mapping/NexusMapping.Validation.cpp` - `ValidateMappingStage` extended with:
  Highway without City ownership (Warning - see Findings on why this should be rare/
  transient now), HighwayPoint not belonging to any Highway's `OrderedPointIds`
  (Warning), missing HighwayPoint Code (Warning), invalid CategoryMask bits (Warning),
  Category/SubCategory band incompatibility (Warning), duplicate fallback State/City
  Code (Blocking - a proof the find-or-create guarantee held, not a normal check),
  malformed fallback City (Blocking), duplicate "Imported Highway N" naming collision
  (Warning). First use of `ENexusMappingValidationSeverity::Warning` in this function
  (previously Blocking-only).
- Three new widgets replacing the old single `SNexusFrameworkPanel` (deleted):
  - `Private/UI/SNexusHierarchyPanel.h/.cpp` - Hierarchy tree + Debug Tree, now the
    entire content of its own dockable tab. `FormatHierarchyLabel` (Name (Code)
    convention, sensible fallbacks for empty Name/None Code). `BuildDebugTreeFromRegistry`
    wraps every real category under one synthetic "Debug" root; nothing force-expands
    on construct (collapsed by default). Root layout: header row (Hierarchy label +
    "Re-sync from Landscape" button) + `SSplitter` (Orient_Vertical, 0.45/0.55) holding
    the Hierarchy tree and the Debug Tree section. Publishes selection via
    `UNexusFrameworkSubsystem::SetDetailsTarget` instead of a direct `DetailsView` call.
  - `Private/UI/SNexusDetailsPanel.h/.cpp` - `IStructureDetailsView`, now reads
    `GetDetailsTarget()`/reacts to `OnDetailsTargetChanged` instead of receiving a
    selection directly; `NotifyPreChange`/`OnDetailsViewFinishedChangingProperties`/
    undo-handling preserved, adapted to the subsystem-mediated target.
  - `Private/UI/SNexusDiagnosticsPanel.h/.cpp` - lift-and-shift, unchanged behavior
    (already fully self-contained, no dependency on the other two tabs).
  - New `Public/UI/NexusPanelSharedTypes.h` - `ENexusDetailsTargetMode`/
    `FNexusDetailsTarget`.
- `Public/Subsystem/NexusFrameworkSubsystem.h` - added `DetailsTarget` state +
  `GetDetailsTarget`/`SetDetailsTarget`/`ClearDetailsTarget` +
  `OnDetailsTargetChanged`/`OnActiveConfigDataChanged` delegates.
- `Public/UI/NexusLandscapeModeExtension.h/.cpp` - three Nomad tab spawners
  (`NexusFrameworkPanel`/`NexusDetailsPanel`/`NexusDiagnosticsPanel` ids), all three
  opened together on Landscape Mode entry and closed together on exit; only the
  Hierarchy tab's own close still triggers `OnNexusTabClosed`/`GetActiveNexusTab()`
  (Details/Diagnostics can be independently closed/reopened without that meaning "Nexus
  is closed" - matches normal per-tab Nomad-tab semantics).
- `project-specifications/07-v6-ui-design.md` - appended a Revision section
  documenting the reversal of the original "one combined panel, fewer tabs than V5"
  design goal.
- `project-specifications/phases/phase-80.md` - appended a Note flagging the five new
  Editor-schema fields that phase will need to add to its own `FNexusRuntimeHighwayPoint`
  export struct.

## Verification

Build-only (`AGENT-RULES.md`'s Agent Testing Policy):
```
Build.bat NexusFrameworkEditor Win64 Development -project=NexusFramework.uproject
```
First attempt (schema-only changes) failed - not a code error: UnrealBuildTool refuses
to relink while Live Coding is active for ANY new reflected type (`UENUM`), not just a
new `.cpp` file, when the editor is running. Confirmed by removing the new file's
companion `.cpp` (converting its two functions to `inline`) and retrying - still failed
identically, proving it was the new `UENUM` itself, not "source file added." User
closed the editor to unblock verification. Full build then failed with two real
compile errors (`SNexusDetailsPanel.cpp` - a ternary mixing `MakeShared<FStructOnScope>`
(`TSharedRef`) and `nullptr` has no common type; `TSharedRef`/`nullptr_t` don't unify
via `?:`) - fixed by using an explicit `TSharedPtr<FStructOnScope>` local + if-statement
instead of a ternary, at both call sites. Rebuild: **Succeeded**. Follow-up no-op build
confirmed "Target is up to date."

No in-editor verification performed or attempted. Manual QA needed:

1. Enter Landscape Mode - confirm three separate tabs open (Nexus Hierarchy, Nexus
   Details, Nexus Diagnostics), each independently dockable/undockable/closable/
   reopenable (Window menu) without affecting the others.
2. Confirm the Debug Tree shows one collapsed "Debug" line initially; expanding it
   reveals the real category tree.
3. Confirm the Hierarchy tree gets a visibly larger, splitter-resizable area (~45%
   of the tab) instead of the old tiny fixed `MaxHeight(160)` clamp; drag the splitter
   to confirm it's user-resizable.
4. On a Landscape with real, currently-unassigned mapped Highways (or after deleting a
   City that owned one) - click "Re-sync from Landscape" (or re-enter Landscape Mode)
   and confirm they appear under "Default State (ST-DEFAULT) > Default City
   (CITY-DEFAULT)", each renamed once to "Imported Highway N", NOT under a top-level
   "(Unassigned Highways)" group.
5. Confirm every tree row (State/City/Highway/HighwayPoint) shows "Name (Code)"
   consistently, with `(Unnamed)`/`NO-CODE` fallbacks visible for any entity missing
   either half.
6. Select a HighwayPoint - confirm Description/Has Cross Walk/Has Traffic Light/
   Category Mask (multi-select bitmask dropdown)/Sub Category are all editable in the
   Details tab, and that Category Mask actually allows multiple simultaneous flags
   (not a single-select radio behavior).
7. Set a HighwayPoint's SubCategory to a value from a DIFFERENT band than its
   CategoryMask (e.g. `Shop_Convenience` with only `Highway` set) and run
   `Nexus.Mapping.ValidateMappingStage` - confirm the Category/SubCategory
   incompatibility Warning appears in the Diagnostics tab.
8. Close the Details tab, select a different Hierarchy entity, then reopen the Details
   tab (Window menu) - confirm it shows the newly-selected entity, not blank or stale.

## Result

All nine items implemented within existing architecture: no unrelated system rewrites,
the previously-established "never fabricate Landscape-backed data" and "PointFeatures
duplicate-concept" rules were preserved rather than relaxed, and the Runtime-export gap
(item 6's last sentence) is honestly flagged forward to Phase 80 rather than
silently skipped or prematurely built. Build-verified (two real compile errors found
and fixed); awaiting the user's own in-editor QA per the checklist above.

## Important Notes

- **Live Coding blocks any new `UENUM`/`USTRUCT`/`UCLASS` while the editor is running**,
  confirmed directly this session (not just inferred from the earlier gizmo-phase
  finding) - `Build.bat` fails with "Unable to build while Live Coding is active" even
  for a header-only new reflected type with no companion `.cpp`. Future work adding new
  reflected types should expect this and ask the user to close the editor before a
  verification build, same as this session did.
- `GetAllValidCategoryBits`/`GetExpectedCategoryForSubCategory` are `inline` in the
  header specifically to minimize new-translation-unit risk under the constraint above -
  if either grows non-trivial, moving them to a `.cpp` is fine functionally, just
  re-triggers the same "editor must be closed" requirement on the next build.
- `SNexusHierarchyPanel::RefreshHierarchyTree` re-publishes the Details target on every
  successful reselect even when the (type, id) pair is unchanged - this is
  intentional, not a missed optimization (see Findings' last bullet on why).

## Follow-up — 2026-08-10 — checkbox hierarchy, double-click focus, naming revert, Details gating

Same day, immediate user feedback on the above:

1. **Debug Tree checkbox hierarchy** - `FNexusDebugCategoryRegistry::IsAnyAncestorHidden`
   (new) walks `ParentCategoryId` upward from a category, true if any ancestor's own
   `IsVisible` is false. Used two places: the checkbox's `IsEnabled` binding
   (`SNexusHierarchyPanel::OnGenerateDebugTreeRow` - greys out/disables a child's
   checkbox while an ancestor is off, without touching the child's own stored
   `IsVisible`, exactly as requested - "no uncheck required"), and
   `UNexusFrameworkSubsystem::DispatchDebugRenderers` (an ancestor being off now
   actually stops a checked descendant from drawing, closing a real gap the checkbox-only
   fix would otherwise have left: previously dispatch checked each category's own
   `IsVisible` independently with no ancestor awareness at all, so a child could show as
   "checked" while its parent group was off and still render in the viewport). This is a
   hard override even a `SupportsAlwaysDraw` leaf does not bypass - see that function's
   own comment for why an ancestor GROUP toggle and a single always-draw INSTANCE
   override are treated as different intents.
2. **Double-click focus** - `HierarchyTreeView.OnMouseButtonDoubleClick` now calls the
   same `HandleFocusItem` the context menu's "Focus" entry already used.
3. **"Name (Code)" reverted** - direct user feedback: "this make confused." 
   `FormatHierarchyLabel` is back to Name-with-Code-fallback (Code shown only when Name
   is empty, never appended alongside it) - the convention this codebase used before
   this whole task started.
4. **Details tab disabled outside Landscape Mode** - `SNexusDetailsPanel`'s root widget
   now has `SetEnabled(TAttribute<bool>)` bound to `GLevelEditorModeTools().
   IsModeActive(EM_Landscape)`, re-evaluated live every paint - greys out the whole
   panel (context/last-selected values stay visible, just non-editable) the moment the
   user leaves Landscape Mode, without needing new focus-tracking plumbing (Landscape
   Mode active is already this codebase's established "user is working with Nexus"
   signal - every tab already opens/closes with it). Also added a defensive guard at
   the same check in `NotifyPreChange` (the real write-commit boundary) in case an edit
   gesture is already in flight when the mode changes mid-drag. Deliberately does NOT
   attempt to track "switched to an unrelated tab while still in Landscape Mode" -
   Slate has no simple, robust "is any of MY tabs focused" API, and every other
   cross-tab signal in this system already uses the same Landscape-Mode-active gate.

Build: **Succeeded** (no new reflected types this pass - still required the editor to
be closed, because UBT's adaptive-unity "working set changed" makefile invalidation is
ALSO refused under Live Coding while the editor runs, not only new `UENUM`/`USTRUCT`
types as the original record above concluded - a broader version of the same
constraint). Follow-up no-op build confirmed "Target is up to date." No in-editor
verification performed - manual QA needed: toggle a parent Debug category off and
confirm child checkboxes grey out AND their markers actually disappear from the
viewport; double-click a City/Highway/HighwayPoint row and confirm the camera jumps;
confirm tree rows no longer show "(Code)"; exit Landscape Mode with the Details tab
still open and confirm it greys out.

## Follow-up — 2026-08-10 — Debug root checkbox now clickable, Details gating now focus-aware

Same day, two more corrections from direct user feedback on the Follow-up above:

1. **Top-level "Debug" checkbox wasn't clickable** - root cause: the synthetic "Debug"
   root row (`BuildDebugTreeFromRegistry`) uses `CategoryId = NAME_None` as a sentinel
   for "not a real category," but the checkbox in `OnGenerateDebugTreeRow` bound
   straight to `GetRuntimeConfig(NAME_None)`/`GetMutableRuntimeConfig(NAME_None)` -
   `FNexusDebugCategoryRegistry` has no real category registered under `NAME_None`, so
   the checkbox always read Unchecked and every click was a genuine no-op (not a UI
   bug, a missing-backing-state bug). Also, because real top-level groups (Landscape/
   Roads/etc.) have `ParentCategoryId = NAME_None` themselves, the existing
   `IsAnyAncestorHidden` walk stops the instant it reaches `NAME_None` (its "no more
   ancestors" terminator) - so even if the root row's checkbox HAD toggled something,
   nothing would have propagated down to disable the six real top-level groups anyway.
   Fixed by giving the root a real backing switch:
   `FNexusDebugCategoryRegistry::IsRootVisible()`/`SetRootVisible(bool)` (new, defaults
   `true`, deliberately transient - not part of `SaveRuntimeConfigsToConfigAsset`, a
   session-level "mute everything" switch rather than a per-category setting worth
   persisting). `IsAnyAncestorHidden` now checks `!bRootVisible` first, before walking
   the ancestor chain, so one `SetRootVisible(false)` call cascades through the exact
   same disable path every other ancestor-hidden category already used - no new
   propagation logic needed, and `DispatchDebugRenderers`'s existing
   `IsAnyAncestorHidden` call (from the first Follow-up above) picked this up for free,
   so toggling the root off also stops every category from rendering, not just from
   showing an enabled checkbox. `OnGenerateDebugTreeRow` now special-cases the root row
   (`categoryId.IsNone()`) to bind its checkbox to `IsRootVisible`/`SetRootVisible`
   instead of a nonexistent per-category config, and always reports itself `IsEnabled`
   (nothing sits above the root to disable it).
2. **Details tab still showed as "active" after clicking away from Nexus's own tabs,
   even while still in Landscape Mode** - direct user report: navigating to "the
   landscape panel, or others panel" (Landscape Mode's own Sculpt/Paint side panel, or
   any unrelated dockable tab) left the Details tab fully editable, since the previous
   Follow-up's fix only gated on `IsModeActive(EM_Landscape)` and explicitly documented
   (at the time) that it could not see this exact case - "Slate has no simple, robust
   'is any of MY tabs focused' API." Built that API: `UNexusFrameworkSubsystem` gained
   `SetHierarchyUIWidget`/`SetDetailsUIWidget`/`SetDiagnosticsUIWidget` (each of the 3
   independently-dockable Nexus tabs registers its own root `SWidget` here, as a
   `TWeakPtr`, at the end of its own `Construct()` - `SNexusHierarchyPanel`,
   `SNexusDetailsPanel`, `SNexusDiagnosticsPanel`) and `IsAnyNexusUIWidgetFocused()`
   (true if `SWidget::HasAnyUserFocusOrFocusedDescendants()` is true for any of the 3 -
   confirmed against UE 5.8's own `STableRow`/`SCheckBox::OnMouseButtonDown`, both of
   which call `SetUserFocus` on click, so selecting a Hierarchy row or clicking a Debug
   Tree checkbox genuinely grants focus to that tab's subtree, not just a visual
   selection highlight with no real focus behind it). `SNexusDetailsPanel`'s
   `SetEnabled` binding and `NotifyPreChange` guard both now require BOTH conditions -
   `IsModeActive(EM_Landscape)` AND `IsAnyNexusUIWidgetFocused()` - so leaving Landscape
   Mode entirely still disables it (unchanged from the prior fix), and now clicking into
   Landscape's own side panel while STILL in Landscape Mode disables it too (the actual
   gap reported). No explicit `Unregister` on tab close - the weak pointers simply fail
   to `Pin()` once a closed tab's content widget is destroyed, and
   `IsAnyNexusUIWidgetFocused` already skips those.

Build: **Succeeded** on the first attempt (editor was already closed from the prior
session before these changes started - confirmed via `tasklist` before building, no
Live Coding block hit this time).
```
Build.bat NexusFrameworkEditor Win64 Development -project=NexusFramework.uproject
```
No in-editor verification performed - manual QA needed: click the top-level "Debug"
checkbox and confirm it toggles Checked/Unchecked, and that unchecking it greys out
(disables, does not un-check) every real top-level group's checkbox beneath it AND
stops all Debug rendering in the viewport; re-check it and confirm everything
re-enables. Select a Hierarchy row (Details shows it, editable) then click into
Landscape Mode's own Sculpt/Paint tool panel (staying in Landscape Mode) and confirm
the Details tab visibly greys out; click back into the Hierarchy or Details tab and
confirm it re-enables without having lost the selection/values.

## Follow-up — 2026-08-10 — regression: dropdown clicks inside Details disabled the panel

User-reported regression from the Follow-up immediately above: "when i click highway
points (inside the hierarchy treeview) then details panel loaded, good, but if i
clicked dropdowns: Sub Category, Category Mask then panel disabled."

**Root cause**: the cross-tab focus-gating fix from the prior Follow-up polled
`SWidget::HasAnyUserFocusOrFocusedDescendants()` on the Details tab's own root widget
every paint. Slate does not host a combo/dropdown's popup content (a `SComboButton`/
`SComboBox` list - exactly what the property editor uses for both an enum dropdown
like Sub Category and a bitmask-flags dropdown like Category Mask) as a descendant
widget of whatever spawned it; `FSlateApplication::PushMenu` opens it in a brand-new
top-level `SWindow` instead. The instant such a dropdown opened, focus moved into that
separate window, the poll on the Details tab's own widget subtree (correctly, by its
own logic) read "no focus here," and `SetEnabled` greyed the whole panel out from
underneath an interaction that was still actively happening inside it - closing/
breaking the dropdown the user was mid-click on.

**Fix**: replaced the per-paint poll with an event-driven, sticky `bool bNexusUIActive`
on `UNexusFrameworkSubsystem`, updated only by a new
`HandleSlateFocusChanging` handler bound to `FSlateApplication::Get().OnFocusChanging()`
in `Initialize()` (unbound in `Deinitialize()`). The handler explicitly no-ops (leaves
`bNexusUIActive` exactly as it was) whenever the NEW focus target's owning window is
not a "regular" window (`SWindow::IsRegularWindow()` false - true for a popup/menu/
tooltip, confirmed against UE 5.8's own `SComboButton`/property-editor combo
implementation, which route through exactly this popup-window mechanism) - only a
focus change landing in an actual regular window (a real dock area/editor window)
re-evaluates whether that widget path (`FWidgetPath::ContainsWidget`) contains the
Hierarchy/Details/Diagnostics tab's own registered root widget. `IsAnyNexusUIWidgetFocused()`
(the public API `SNexusDetailsPanel` already calls - unchanged call site, only the
implementation underneath it changed) now just returns the sticky bool instead of
polling. `SetHierarchyUIWidget`/`SetDetailsUIWidget`/`SetDiagnosticsUIWidget`
registration (from the prior Follow-up) is unchanged - still called once per tab at the
end of each panel's own `Construct()`.

Build: **Succeeded** on the first attempt. Editor was open (user was actively testing/
reporting the bug in it) - asked before building; user chose to close it themselves,
confirmed closed via `tasklist` before running `Build.bat`.

No in-editor verification performed - manual QA needed: select a HighwayPoint in the
Hierarchy tree, open the Sub Category dropdown and pick a value, confirm the Details
panel stays enabled and editable throughout (does not grey out while the dropdown is
open or after picking a value); repeat for the Category Mask bitmask-flags dropdown,
toggling multiple flags in the popup, confirming the panel never disables mid-interaction;
re-confirm the actual regression-fix target from the prior Follow-up still works
(click into Landscape Mode's own Sculpt/Paint panel and confirm Details still greys
out correctly - this fix must not have silently reverted that behavior).

## Important Notes (addendum, 2026-08-10)

- Any FUTURE property type added to the Details tab's editable schema that opens its
  OWN popup/floating window (a color picker, an asset picker, a curve editor, etc.)
  should be safe under this same fix for the same reason (popups are non-regular
  windows) - but if a future control instead reparents its content INTO the main
  editor window rather than a true popup `SWindow` (uncommon, but not impossible for a
  custom-built widget), it would need the same `IsRegularWindow()` carve-out
  reconsidered for that specific case.
