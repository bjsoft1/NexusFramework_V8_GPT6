# Debug Performance batch (Phases 33-35): visibility-cost audit, V0-derived LOD, profiling tooling

Date: 2026-08-10
Category: feature-add (plus a correctness audit with zero findings for Phase 33)
Phase: 33 (Visibility Cost Model), 34 (Spatial/Viewport Filtering), 35 (Massive-World
Stress Validation)

## Context

User selected the "Debug Performance" phase cluster (33-35) as part of a larger next
work batch (33-35, 40a, 41/41a-44, 45-49), chosen via an explicit menu of
similarity/complexity-grouped clusters. This is the first batch worked after Phase 20a's
architecture-review checkpoint closed.

## Problem / Goal

Phase 33 asks to verify (and fix if needed) that an invisible Debug category costs
effectively zero per frame. Phase 34 asks for real distance-based LOD (not just a binary
cutoff) for high-instance-count categories, explicitly requiring the V0-derived
closest-point-to-AABB / dual-threshold / impostor / per-frame-cap mechanism per
`v6-master-architecture.md` Section 22. Phase 35 asks for a 50+-category,
thousands-of-instance stress pass.

## Findings

1. **Phase 33's correctness requirement was already met before this session touched
   it.** `UNexusFrameworkSubsystem::DispatchDebugRenderers`'s per-category `IsVisible`
   check (checked once, before `RendererFn.Execute` is even called) already satisfies
   the "checked once per category per frame, not per object" rule - confirmed by reading
   all four renderer .cpp files (Landscape/Roads/Mapping groups + the Diagnostics
   overlay); none is reachable except through that one gate, none recomputes
   Landscape/Mapping data inside the draw loop. No renderer needed fixing.
2. **No pre-existing binary debug-radius/LOD mechanism existed at all** - Phase 34's
   revision note assumed one to "retain" as the outer cull, but `06-v6-debug-system.md`
   only ever documented it as a requirement, never implemented it. Built fresh
   (`DebugRadius` on `FNexusDebugRenderConfig`) rather than assuming prior code to
   preserve.
3. **V0's `RoadGraphEditorLOD` namespace** (`NexusFramework_V0/Source/
   NexusFrameworkEditor/Private/NexusRoadGraphEditorVisualizer.cpp`, lines ~529-696) was
   read directly and ported: `GetDistanceSquaredToBounds` (closest-point-to-AABB, via
   per-axis `FMath::Clamp` against the camera location) and
   `ClampFullDetailHighwaysByDistance` (sort candidates by distance, truncate to a max
   count) are the two load-bearing algorithms; V6's `FNexusDebugLOD::SelectLOD` is a
   generic (candidate-list-based, not Highway-specific) reimplementation of both.
4. **No existing camera-location access existed in V6's Debug code** - resolved via
   `GCurrentLevelEditingViewportClient->GetViewLocation()` (`Editor.h` /
   `LevelEditorViewport.h`, `UnrealEd` module, already a dependency) - the standard
   editor-global for "first active level viewport's camera," same "only the first pane"
   limitation `FNexusDebugLabelOverlay` already documents for the same underlying reason.
5. **Neither phase's own completion criteria can be fully closed by an agent** - both
   explicitly ask for profiling/stress numbers, and `AGENT-RULES.md`'s Agent Testing
   Policy forbids launching/driving the editor for automated verification. Built
   dedicated console-command tooling instead (see Changes) so the user's manual
   verification step is a single command + a number to read, not something to construct
   from scratch.

## Changes

- `Source/NexusFrameworkEditor/Public/Debug/NexusDebugRenderConfig.h` - 4 new
  `UPROPERTY(EditAnywhere)` fields: `DebugRadius`, `FullDetailDistance`,
  `LabelMaxDistance`, `MaxFullDetailObjects`, all default `-1` (off/unlimited) so every
  existing category (28-32) is behaviorally unchanged unless it opts in.
- New: `Source/NexusFrameworkEditor/Public/Debug/NexusDebugLOD.h` +
  `Private/Debug/NexusDebugLOD.cpp` - `FNexusDebugLOD::SelectLOD`, generic over any
  category's own `FNexusDebugLODCandidate` list (world-space AABB per object), returns
  `ENexusDebugLODState` (Culled/Impostor/FullDetail) + independent label-visibility bool
  per candidate.
- `Source/NexusFrameworkEditor/Private/Debug/NexusDebugRoadsGroupRenderers.cpp` -
  `RenderLaneDirection` (`Roads.LaneDirection`, the pilot category - "lane markers" is
  this phase's own Objective wording) rebuilt to go through `SelectLOD`: FullDetail draws
  the normal direction arrow, Impostor draws an AABB box, Culled draws nothing. Default
  config for this one leaf set to real (demo-scale) values -
  `FullDetailDistance=1500cm`, `LabelMaxDistance=800cm`, `MaxFullDetailObjects=150` - so
  the mechanism is visibly active by default, not just present but dormant. No other
  category was touched.
- `Source/NexusFrameworkEditor/Public/Subsystem/NexusFrameworkSubsystem.h` +
  `Private/.../NexusFrameworkSubsystem.cpp` - new public `ProfileDebugRenderers()` +
  `Nexus.Debug.ProfileRenderers` console command: times each bound category's renderer
  for one frame (respecting current Debug Tree visibility), logs per-category +
  total microseconds.
- New: `Source/NexusFrameworkEditor/Private/Debug/NexusDebugPerformanceCommands.cpp` -
  `Nexus.Debug.SimulateLaneMarkerLOD [Count=500]` (synthetic grid of candidates through
  the real `SelectLOD`, logs FullDetail/Impostor/Culled split + timing, warns if the
  `MaxFullDetailObjects` cap is ever violated) and
  `Nexus.Debug.RegisterStressCategories [Count=50]` (session-only synthetic leaf
  categories under a `StressTest` group, for Phase 35's Tree/Config-UI stress pass).
- `phases/phase-33.md`, `phase-34.md`, `phase-35.md` - Status set to Ready for Review;
  completion criteria checked where code-verifiable, left unchecked (with an explicit
  "Manual Verification Needed" section) where only an in-editor run can confirm.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` -
  **Result: Succeeded**, 15 actions (incremental), 0 errors.
- **No automated test run/added** - per `AGENT-RULES.md`'s Agent Testing Policy.
- Code-level review only for the "no violation found"/"cap always holds"
  completion-criteria claims above - not a substitute for the manual runs each phase file
  now lists under its own "Manual Verification Needed" section.

## Result

Phase 33: confirmed correct by construction, no code change needed for correctness
itself; a profiling tool now exists to produce the actual before/after numbers. Phase 34:
real V0-derived LOD chain implemented and demonstrated on one pilot category, fully
data-driven (no category-specific branching in the LOD code itself), other categories
unaffected. Phase 35: stress-test tooling built; the actual large-scale editor
responsiveness check remains a manual, in-editor step (Agent Testing Policy).

## Important Notes

- **Only `Roads.LaneDirection` has LOD enabled by default.** Applying it to every
  category (or to future high-count categories like Activation Points, Phase 45+) is
  each of those categories' own future opt-in (set `FullDetailDistance >= 0` on
  registration), not something this batch retrofitted broadly - matches Phase 34's own
  "at least one high-count test category" scope.
- **`DebugRadius` (the outer binary cull) is left at -1/off even on the pilot category.**
  Only `FullDetailDistance`/`LabelMaxDistance`/`MaxFullDetailObjects` are demo-enabled -
  the LOD chain alone was enough to demonstrate the mechanism without also making
  far-away arrows disappear outright, which would be harder to visually distinguish from
  a bug. A user wanting the full "nothing draws past N meters" behavior can set
  `DebugRadius` themselves from the Details panel.
- **`Nexus.Debug.RegisterStressCategories`'s dummy categories are session-only and
  additive-only (no unregister command)** - restarting the editor is the only way to
  clear them. Acceptable for a manual stress-test tool; flagged here so it isn't mistaken
  for a bug if a future session notices a lingering `StressTest` group.
