# Diagnostics panel — "Copy All" button

Date: 2026-08-10
Category: feature-add
Phase: phases/27 (already `Ready for QA` before this change)

## Context

While testing the stale-Highway fix (see this same day's `bug-fixed/
stale-highway-not-detected-on-landscape-removal.md`), the user's Diagnostics panel had
accumulated a large list of entries and they had no way to copy that text out of the
editor (unlike the Output Log, which they'd been pasting from all session).

## Problem / Goal

The Diagnostics list (`SNexusFrameworkPanel::OnGenerateDiagnosticsRow`) renders each
entry as a plain `STextBlock`. Slate `STextBlock` has no built-in text selection/copy
support, and the row's mouse-click is already claimed by Phase 27's own click-to-focus
behavior (`OnDiagnosticsSelectionChanged`), so making individual rows selectable/
copyable text wasn't a clean fit without breaking that. Needed some way to get the
list's contents onto the clipboard.

## Changes

- `NexusFrameworkEditor.Build.cs` — added `ApplicationCore` module dependency
  (`FPlatformApplicationMisc::ClipboardCopy` lives there, not Slate/SlateCore/Core).
- `Private/UI/SNexusFrameworkPanel.cpp`/`.h` — `BuildDiagnosticsSection` now wraps the
  existing `DiagnosticsListView` in a small `SVerticalBox` with a "Copy All" `SButton`
  above it (disabled when the list is empty). New `OnCopyAllDiagnosticsClicked` builds
  one line per currently-listed entry (`[Severity] [Stage] Message`, matching
  `OnGenerateDiagnosticsRow`'s own row-text format exactly) and calls
  `FPlatformApplicationMisc::ClipboardCopy`.
- `project-specifications/phases/phase-27.md` — already `Ready for QA`; appended a
  `## Revision` section (original three criteria untouched) plus one new unchecked
  criterion for this button.

## Verification

- First build attempt failed: `LNK2019` unresolved external for
  `FWindowsPlatformApplicationMisc::ClipboardCopy` - confirmed the missing dependency
  was `ApplicationCore`, added it, rebuilt.
- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded** on the second attempt, 0 errors.
- `node html-docs/build.js` — regenerated.
- Not run by the agent this session (Agent Testing Policy) - manual check steps are in
  `phase-27.md`'s new criterion.

## Result

A single "Copy All" button above the Diagnostics list copies every currently-listed
entry to the clipboard as plain text. Per-row copy (vs. whole-list) was deliberately not
attempted - would need either replacing `STextBlock` with a read-only editable-text
control or a right-click context menu, both of which risk interfering with the existing
click-to-focus row-click behavior; "Copy All" solves the reported need (getting the data
out of the editor at all) without that risk.
