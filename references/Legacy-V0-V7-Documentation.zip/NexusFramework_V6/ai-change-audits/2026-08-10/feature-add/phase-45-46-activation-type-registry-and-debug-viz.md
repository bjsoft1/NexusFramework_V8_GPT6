# Phases 45-46: Activation Point type registry + generic Debug visualization

Date: 2026-08-10
Category: feature-add
Phase: 45 (Type Registry), 46 (Debug Visualization Integration)

## Context

Continuing the Activation Point cluster (45-49) after the earlier Static Generator
cluster (41-42) and the closed-loop-highway bug fix. Phase 43/44 (Streaming/Validation
Gate) were deferred earlier this session per explicit user direction to stop and "just
do the docs" - not revisited in this pass; user asked to proceed through 49.

## Findings

- **No real Activation Point storage exists anywhere** - `UNexusConfigAsset` has no
  `ActivationPoints` array; confirmed by reading Phase 22's own `ValidateRepresentationStage`
  signature, whose own comment says nothing produces them yet. This blocks any
  "render/query/gizmo-edit REAL data" proof for Phases 46-49 until a real object type
  (Phase 50+) or a dedicated storage-architecture decision exists. Handled by using
  session-only, explicitly-flagged test instances anchored to real HighwayPoints,
  rather than inventing the real persistence model under time pressure (an Architecture
  Gap, not silently decided - see phase-46.md's own Implementation Notes).
- **Sub-point fields need a distinguishable type for reflection to find them** - a bare
  `FVector`/`FRotator` pair by naming convention (what `FNexusActivationPoint`'s own
  base offset uses) can't be reliably discovered via `FProperty` iteration. Introduced
  `FNexusSubPointOffset` (one `OffsetLocation`/`OffsetRotation` pair) specifically so
  `FStructProperty`/`FArrayProperty` reflection can find every sub-point field by
  matching `Struct == FNexusSubPointOffset::StaticStruct()`.
- **`USTRUCT(BlueprintType)` is required whenever any member is `BlueprintReadWrite`** -
  hit this as a real compile error (`FNexusDummyArrayActivationPayload` first written as
  plain `USTRUCT()`), fixed immediately.

## Changes

- New: `Public/Representation/NexusSubPointOffset.h` - `FNexusSubPointOffset`.
- New: `Public/Representation/NexusActivationTypeRegistry.h` +
  `Private/.../NexusActivationTypeRegistry.cpp` - `FNexusActivationPointSubPointKey`,
  `FNexusActivationTypeDefinition`, `FNexusActivationTypeRegistry` (Meyer's singleton,
  same shape as Phase 23's Debug registry), `EnumerateDeclaredSubPointFields` (static
  reflection) + `EnumerateSubPointKeysForInstance` (instance-level, real array length).
- New: `Public/Representation/NexusActivationDummyTypes.h` +
  `Private/Representation/NexusActivationDummyTypesRegistration.cpp` - the two
  Phase-45-mandated dummy types + `Nexus.Representation.DumpActivationTypeRegistry`.
- `Public/Representation/NexusActivationPoint.h` - added `IsAlwaysDraw` (Phase 46).
- `Public/Debug/NexusDebugCategory.h` - added `FNexusDebugCategory::SupportsAlwaysDraw`
  (default false, zero behavior change for every existing category).
- `Private/Subsystem/NexusFrameworkSubsystem.cpp` - `DispatchDebugRenderers`'s
  visibility gate now has a `SupportsAlwaysDraw` exception (calls the renderer anyway,
  passing `IsVisible=false` through so the renderer can self-filter).
- New: `Private/Debug/NexusDebugRuntimeGroupRenderers.cpp` - `RenderActivationPoints`
  (the one generic renderer for the new `Runtime.ActivationPoints` category),
  `Nexus.Representation.AddTestActivationPoint`/`ClearTestActivationPoints`.
- `phases/phase-45.md`, `phase-46.md` - Status set to Ready for Review; completion
  criteria annotated per what's code-verified vs. needing a manual editor run.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development` - **Result: Succeeded** for both
  phases (one intermediate failure on Phase 45's `BlueprintType` issue, fixed and
  reverified clean before moving to Phase 46). Live Coding contention required the user
  to close the editor between some of this session's build attempts.
- **No automated test run/added** - per `AGENT-RULES.md`'s Agent Testing Policy. Neither
  phase's console commands were executed by this agent - see each phase file's own
  Manual Verification section.

## Result

A real, generic, zero-edit-extensible Activation Point type registry exists, with
reflection-based sub-point discovery proven (declaration-level) and instance-level array
enumeration proven correct including after a resize. A single generic Debug renderer now
exists for any registered type, with a working Always-Draw override mechanism that
required only a 4-line, opt-in change to the shared dispatch loop - not a second
rendering path.

## Important Notes

- **The real Activation Point storage/persistence architecture is still undecided** -
  this is the single biggest open item blocking Phases 47-49 from testing against real
  data rather than session-only test instances. Whoever picks up Phase 50 (the first
  real object type, Traffic Light) will need to resolve this - flagged explicitly, not
  guessed at here.
- **`Runtime.ActivationPoints`'s `CanSupportGizmo` was set to `true` at registration**
  (`DefaultConfig.CanSupportGizmo = true`) even though no gizmo mechanism exists yet
  (Phase 48) - this only affects whether the category is flagged selectable in config,
  it does not by itself make anything interactive; harmless to have set early, but
  worth knowing it was set now, not deferred to Phase 48.
