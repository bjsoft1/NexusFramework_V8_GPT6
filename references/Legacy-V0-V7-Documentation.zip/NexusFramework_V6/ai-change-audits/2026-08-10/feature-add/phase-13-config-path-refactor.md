# Phase 13 refactor — config asset path convention (level-relative, not LandscapeId-keyed)

Task: small refactor to the config asset's naming/path convention, direct user request
Category: feature-add
Phase: phases/13 (also touches 15, 17's own docs since they describe the same path)
Status: Done (build-verified; no automated test/editor launch, per AGENT-RULES.md)
Completed Date: 2026-08-10
Completed Time: (same session as Phase 15-17's report)

## Context

Immediately after the Phase 15-17 (Automatic Config Lifecycle) report was delivered, the
user asked directly (not via `/TODO`) for "small refactor: the config file should
generate /[level folder]/levelname/[human redable name]". Clarified via two questions:
the asset name should be a fixed, human-readable `NexusConfig` (not repeating the level
name or a GUID in the filename), and the user explicitly accepted that this makes the
path move if the level is renamed — noting "this same approach [as] the landscape
material layer system so, maybe this is good," i.e. deliberately matching how UE's own
built-in Landscape material layer system saves its generated assets next to the level.

## Problem / Goal

Phase 13's original design (`/Game/NexusConfigs/[LandscapeId]_nexusconfig`, a single flat
folder keyed by GUID) was intentionally rename-proof but not human-navigable — every
config asset lived in one folder with a cryptic GUID-digits filename, disconnected from
its level. Refactor to save each config asset alongside its own level instead.

## Findings

1. **The new path is `<LevelFolder>/<LevelName>/NexusConfig`**, derived from
   `Landscape->GetOutermost()->GetName()` (the Landscape's own containing level package,
   e.g. `/Game/Maps/TestMap`) via `FPackageName::GetLongPackagePath`/`GetShortName` - not
   from `LandscapeId` at all. `LandscapeId` (`ALandscape::GetLandscapeGuid()`) is still
   computed and stored on the asset (`UNexusConfigAsset::LandscapeId`) for
   identity/lookup purposes, it just no longer determines *where* the asset saves.
2. **This inverts Phase 13's original "unaffected by map renames" property on purpose** -
   the user explicitly accepted this trade-off (see Context) after being asked directly.
   Renaming/moving a map's `.umap` now orphans its config asset at the old path, same as
   any other level-relative UE asset. `phases/phase-13.md`'s "Landscape moved to a
   differently-named map still resolves the same config asset" Completion Criterion is
   now marked **Superseded** in the phase file itself rather than deleted - the original
   verification evidence under the old path convention is preserved, not erased.
3. **New consequence for Phase 17's multi-Landscape scope, not previously true**: under
   the old GUID-keyed path, two `ALandscape` actors in the same map would already
   produce two independent config assets by construction (each has its own
   `LandscapeId`). Under the new level-keyed path, two Landscape actors in the SAME map
   now resolve to the SAME path (`<LevelFolder>/<LevelName>/NexusConfig` has no
   per-actor component) - a real collision if that restriction is ever lifted. Since
   Phase 17 already scopes V6 to exactly one mapped Landscape per map
   (`ResolveActiveLandscape()` only ever picks the first), this has no live effect today,
   but it changes what "lifting the restriction later" would require - now a
   path-disambiguation change (e.g. keying on the Landscape actor's label when more than
   one exists) as well as picker UI, not UI alone. Documented in
   `project-specifications/04-v6-architecture.md`'s "Multi-Landscape scope" section
   rather than left as a silent doc/behavior mismatch.
4. **A genuinely new failure mode this refactor introduces**: an unsaved/transient level
   has no on-disk package path (`FPackageName::IsValidLongPackageName` fails), so there's
   nowhere to derive `<LevelFolder>/<LevelName>` from. `LoadOrCreateConfigAsset` now
   checks for this explicitly and returns `nullptr` with a Warning log instead of
   attempting (and failing) `CreatePackage` on a garbage path - the old LandscapeId-keyed
   design never had this failure mode since `/Game/NexusConfigs/` was a fixed root
   independent of the level's own save state.

## Changes

- `Source/NexusFrameworkEditor/Public/Mapping/NexusConfigAssetIO.h` - `GetConfigAssetName()`
  now takes no args (fixed `"NexusConfig"`); `GetConfigPackagePath`/
  `LoadOrCreateConfigAsset` now take `const ALandscape*` instead of `const FGuid&`, to
  have access to the Landscape's containing level.
- `Source/NexusFrameworkEditor/Private/Mapping/NexusConfigAssetIO.cpp` - implements the
  new `<LevelFolder>/<LevelName>/NexusConfig` derivation; added the
  unsaved-level/invalid-package-name guard (Findings #4); updated
  `Nexus.Mapping.LoadOrCreateConfig`'s call site and console-command help text.
- `Source/NexusFrameworkEditor/Private/Mapping/NexusMapping.EnableFlow.cpp` -
  `RunAutomaticEnableFlow`'s call to `LoadOrCreateConfigAsset` updated to pass
  `Landscape` instead of a bare `LandscapeId`.
- `Source/NexusFrameworkEditor/Public/Mapping/NexusConfigAsset.h` - doc comments updated
  to describe the new path convention and clarify `LandscapeId`'s remaining role
  (identity, not path derivation).
- `project-specifications/04-v6-architecture.md` - new "Config asset path (refactored
  2026-08-10)" subsection; "Multi-Landscape scope" section updated per Findings #3;
  ASCII enable-flow diagram updated.
- `project-specifications/05-v6-data-flow.md` - enable-flow diagram's Data Asset line
  updated.
- `project-specifications/phases/phase-13.md` - Objective/Allowed updated with a dated
  Note pointing at this record; the now-superseded rename-resilience Completion
  Criterion annotated (not deleted - original evidence preserved) per Findings #2.
- `project-specifications/phases/phase-15.md` - one Completion Criterion's manual-check
  text updated to name the new asset/path instead of the old `_nexusconfig` suffix.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` -
  **Result: Succeeded**. All 8 changed/affected `.cpp` files recompiled cleanly
  (`NexusConfigAssetIO.cpp`, `NexusMapping.EnableFlow.cpp`, plus the rest of the
  `NexusMapping.*.cpp` family rebuilt as part of the same module), 0 errors.
- **No automated tests written or run, no editor launched** - per `AGENT-RULES.md`'s
  Agent Testing Policy. This refactor touches Phase 13 (already `Ready for QA`) and
  Phase 15 (already `Ready for Review`) - their own phase files' manual-check steps
  still apply; the specific criterion invalidated by this refactor is called out above
  rather than left silently wrong.

## Result

Refactor complete, build-verified. Config assets now save at
`<LevelFolder>/<LevelName>/NexusConfig` next to their level instead of a flat
`/Game/NexusConfigs/[LandscapeId]_nexusconfig` folder. Any config assets already created
under the old convention during this session's earlier manual testing (the user's real
10-point test Landscape) are now orphaned at their old `/Game/NexusConfigs/...` path -
the user was told this in Phase 13/15's original reports ("safe to delete after
testing"), and re-running `Nexus.Mapping.LoadOrCreateConfig` will create a fresh asset at
the new path rather than finding the old one.

## Important Notes

- **This changes behavior in two already-reviewed phases (13, 15) without re-running
  their own manual verification** - the build compiles clean and the logic is a narrow,
  mechanical path-derivation swap, but neither phase's Completion Criteria have been
  manually re-checked against the NEW path by the user yet. Worth a fresh
  `Nexus.Mapping.LoadOrCreateConfig` run to confirm the new path resolves as expected
  before treating Phase 13/15 as fully settled again.
- Old config assets from this session's earlier testing under
  `/Game/NexusConfigs/06AD7994...` are now dead weight - safe to delete from the Content
  Browser (same guidance as when they were first created).
- Findings #3 (multi-Landscape path collision) is a real, if currently dormant,
  architectural note for whoever eventually lifts Phase 17's single-Landscape
  restriction - start there rather than rediscovering it.
