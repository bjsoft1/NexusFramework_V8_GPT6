# Roads.Highways / Roads.Lanes — high-contrast debug colors

Date: 2026-08-10
Category: feature-add
Phase: phases/31 (already `Ready for QA` before this change)

## Context

User said manual QA via console-command output (`Nexus.Representation.*`,
`Nexus.Mapping.*`) is hard to follow, and asked for the next debug-rendering-related
work to make Highway/Lane debug rendering large and pink so verification can happen
visually in the viewport instead. Checked the roadmap first: Phases 23-32 (the whole
Debug Architecture/Rendering arc) are all already `Ready for QA`; Phases 33-35
(Debug Performance) are `Not started` but explicitly gated on correctness being
verified first (which is what the user is doing right now) - so there was no new
"Not started" draw-debug phase to pick up. Treated this as a revision to the already-
implemented Phase 31 (Roads group) instead, matching this session's established pattern
for user feedback on already-QA'd work (Phase 14/16/27 all got the same treatment
today).

## Problem / Goal

`Roads.Highways` and `Roads.Lanes` (Phase 31) both defaulted to the same dull grey
`(0.65, 0.65, 0.68)` at `LineThickness=2` as every other Roads-group leaf - low
contrast against typical Landscape terrain, and visually indistinguishable from each
other or from Segments/Tangents/StartEnd/Connections/LaneDirection/Sidewalks/Junctions.

## Changes

- `Private/Debug/NexusDebugRoadsGroupRenderers.cpp` — `MakeRoadsLeaf` now takes
  optional `Color`/`LineThickness` parameters (defaulting to the existing grey/2px, so
  the three untouched leaves - LaneDirection/Sidewalks/Junctions - are unaffected).
  `Roads.Highways` registered with hot pink `(1.0, 0.05, 0.55)` at thickness 10;
  `Roads.Lanes` registered with bright gold `(1.0, 0.85, 0.05)` at thickness 8 -
  deliberately a different color from Highways (not also pink) so the two stay visually
  separable when both are toggled on together, and gold matches the real-world yellow/
  white lane-marking convention. No renderer logic changed - `RenderHighways`/
  `RenderLanes` already draw entirely through the shared `Config` parameter
  (`FNexusDebugPrimitives::DrawLine`), so this was purely a registration-site change.
- `project-specifications/phases/phase-31.md` — already `Ready for QA`; appended a
  `## Revision` section (original two criteria untouched) plus one new unchecked
  criterion for the color/thickness change.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, 0 errors (blocked once by Live Coding/editor open, user closed
  it, retried clean).
- `node html-docs/build.js` — regenerated.
- Not run by the agent this session (Agent Testing Policy) - manual check steps are in
  `phase-31.md`'s new criterion.

## Result

`Roads.Highways`/`Roads.Lanes` now default to large, high-contrast colors (hot pink /
gold respectively) instead of the same thin grey as every other Roads leaf, intended to
make visual QA in the viewport meaningfully easier than console-only verification. Only
the DEFAULT changed - a user's own already-saved per-category color override (if any,
via Phase 26's persistence) is unaffected.

## Important Notes

- Landscape group's own leaves (`Landscape.Segments` etc., Phase 30) were deliberately
  NOT touched - those render raw Source-stage geometry (a different, intentionally
  distinct purpose from Roads' resolved-width Representation view), and the user's ask
  named "Highway"/"lane" specifically, which map onto Roads.Highways/Roads.Lanes, not
  the Landscape group. Worth revisiting if the user wants Landscape.Segments bolded too.
