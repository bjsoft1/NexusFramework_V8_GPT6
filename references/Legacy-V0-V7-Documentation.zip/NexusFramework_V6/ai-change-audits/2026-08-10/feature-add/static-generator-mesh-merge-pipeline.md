# Phase 41: Static Generator mesh-merge pipeline (road surface + sidewalk)

Date: 2026-08-10
Category: feature-add
Phase: 41 (Static Generator - Mesh Merge Pipeline)

## Context

Second item in the "next batch" cluster after Debug Performance (33-35) + the 40a
checkpoint. First phase in the roadmap that produces real, savable game-content assets
(everything before this was editor-only data/debug tooling) - the Landscape → Editor
Authoring → Debug Visualization pipeline's first output into the Static Generator arc.

## Problem / Goal

Generate real road-surface and sidewalk `UStaticMesh` assets per Highway, from
Representation-stage data only (never a direct Landscape read), with idempotent
re-runs and a curve-accuracy guarantee.

## Findings

1. **No existing mesh-generation code anywhere in V6** - Phase 40 (Classification
   Tagging) only built the object-type/classification enum and lookup table, no
   geometry. This phase is the first real geometry producer.
2. **Engine API research before writing code**: confirmed `UStaticMesh::
   BuildFromMeshDescriptions` exists (`StaticMesh.h`) but the actually-used,
   editor-asset-authoring pattern is `CreateMeshDescription`/`CommitMeshDescription`/
   `Build` - verified against a real engine caller
   (`Engine/Plugins/Interchange/.../InterchangeStaticMeshFactory.cpp`'s own
   `CommitMeshDescriptions`/`BuildFromMeshDescriptions` methods) rather than guessing the
   API shape. `FStaticMeshAttributes`/`FMeshDescription` (modules `StaticMeshDescription`/
   `MeshDescription`) were not previously a dependency of `NexusFrameworkEditor.Build.cs`
   - added as Private dependencies (no public header exposes either type).
3. **Deliberately does NOT depend on `FNexusDebugRenderSnapshot`/Debug module** - Debug
   and Static Generator are sibling Representation consumers per the master
   architecture's pipeline, not a dependency chain; reusing Debug's snapshot type would
   have made Generation depend on the (editor-preview-only) Debug subsystem. Cost: this
   generator uses tangent DIRECTION only (`FNexusHighwayPoint::GetLiveTangentDirection`)
   with an auto-derived tangent LENGTH (`distance/3`, standard Catmull-Rom-style
   heuristic), not native `ULandscapeSplineSegment` tangent length like Debug's Phase
   30a curve rendering does - a documented, deliberate fidelity difference, not an
   oversight (see phase-41.md's own Implementation Notes).
4. **Triangle winding hand-verified via the cross-product test**, not assumed: for a
   ribbon strip advancing in +X with "right" = `cross(UpVector, direction)` (works out to
   +Y for a +X-facing strip, matching UE's own X-forward/Y-right/Z-up convention), the
   triangle order `(innerA, innerB, outerA)` / `(outerA, innerB, outerB)` gives
   `cross(edge1, edge2)` = +Z for both triangles:
   - Triangle 1: P0=innerA=(0,-1,0), P1=innerB=(1,-1,0), P2=outerA=(0,1,0).
     edge1=(1,0,0), edge2=(0,2,0), cross=(0,0,2) → +Z.
   - Triangle 2: P0=outerA=(0,1,0), P1=innerB=(1,-1,0), P2=outerB=(1,1,0).
     edge1=(1,-2,0), edge2=(1,0,0), cross=(0,0,2) → +Z.
   This matches the explicit `UpVector` vertex normal the generator assigns, so winding
   and normal agree - but this is paper math, not a rendered check; flagged explicitly in
   phase-41.md's Manual Verification section as still needing an actual in-viewport look.
5. **Idempotency mechanism**: `UStaticMesh::FCommitMeshDescriptionParams::
   bUseHashAsGuid=true` makes the built asset's Mesh GUID content-derived rather than a
   fresh `FGuid::NewGuid()` per commit - the real, verifiable idempotency signal (not
   just "vertex count matches"). Additionally, `FNexusGeneratedRibbonMesh::
   ComputeContentHash` (a simple FNV-1a over Positions/TriangleIndices) lets
   `Nexus.Generation.TestIdempotency` prove idempotency at the pre-asset data level too,
   without needing to round-trip through a committed `UStaticMesh`.
6. **Curve-accuracy proof is exact by construction, not just "within tolerance"**:
   `SampleCenterlineCurve` always emits each segment's own `alpha=0` sample (exactly
   `p0`, since `FMath::CubicInterp` at alpha=0 returns P0 exactly) plus, for the Highway's
   final segment only, an `alpha=1` sample (exactly `p1`) - so every source HighwayPoint
   is itself literally one of the generated curve's sample points, not merely close to
   one. `VerifyCenterlineMatchesSourcePoints`'s max-deviation output should read ~0.0 in
   practice; documented as an exactness guarantee, not a loose visual-similarity claim.

## Changes

- New: `Source/NexusFrameworkEditor/Public/Generation/NexusGenerationMeshTypes.h` +
  `Private/.../NexusGenerationMeshTypes.cpp` - `FNexusGeneratedRibbonMesh` (pure-data
  triangle mesh, `ComputeContentHash`).
- New: `Source/NexusFrameworkEditor/Public/Generation/NexusStaticGenerator.h` +
  `Private/.../NexusStaticGenerator.cpp` - `FNexusStaticGenerator`:
  `GenerateHighwayRoadSurfaceMesh`, `GenerateHighwaySidewalkMesh`,
  `BuildStaticMeshAsset`, `VerifyCenterlineMatchesSourcePoints`, plus the private
  `SampleHighwayCenterline`/`SampleCenterlineCurve`/`AppendRibbon` helpers.
- New: `Source/NexusFrameworkEditor/Private/Generation/NexusStaticGeneratorCommands.cpp`
  - `Nexus.Generation.GenerateHighwayMeshes`, `Nexus.Generation.TestIdempotency`,
  `Nexus.Generation.TestCurveTolerance` console commands.
- `Source/NexusFrameworkEditor/NexusFrameworkEditor.Build.cs` - added
  `PrivateDependencyModuleNames`: `MeshDescription`, `StaticMeshDescription`.
- `phases/phase-41.md` - Status set to Ready for Review; completion criteria annotated
  with what's code-proven vs. still needing a manual editor look.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` -
  **Result: Succeeded**, 11 actions (incremental, new source file triggered a makefile
  rebuild), 0 errors - first-attempt clean compile despite unfamiliar
  `FMeshDescription`/`FStaticMeshAttributes` API surface, thanks to pre-verifying the
  exact API shape against `InterchangeStaticMeshFactory.cpp` before writing the call
  site.
- **No automated test run/added** - per `AGENT-RULES.md`'s Agent Testing Policy. The
  idempotency/curve-tolerance "tests" are manually-triggered console commands (matching
  this project's existing `Nexus.Generation.TestUnclassifiedAssertion`/
  `Nexus.Debug.ProfileRenderers` precedent from Phase 33/40), not an automated test
  framework entry, and were not executed by this agent (no editor launch).

## Result

Real `UStaticMesh` road-surface and sidewalk assets can now be generated per Highway
from Representation data via `Nexus.Generation.GenerateHighwayMeshes`, idempotently, with
programmatic (not yet visual) proof of curve accuracy. The actual visual/backface-culling
check remains a manual step - see phase-41.md's Manual Verification section.

## Important Notes

- **Material**: `BuildStaticMeshAsset` accepts an optional `UMaterialInterface*`; every
  call site in this session passes `nullptr` (default engine material slot) - no road/
  sidewalk material asset exists yet in this project. Wiring a real material is left to
  whichever future phase actually needs the generated meshes to look like a road, not
  invented speculatively here.
- **Non-welded ribbon topology**: each curve sample contributes exactly 2 unique
  vertices (inner/outer edge), shared along the strip - correct and seam-free within one
  `AppendRibbon` call, but road-surface and sidewalk ribbons are NOT welded to each other
  (three independent ribbons per Highway: road, left sidewalk, right sidewalk, each with
  its own unwelded edge). Acceptable for this phase's own scope (idempotency + curve
  match); a follow-up optimization/welding pass is not blocking.
- **No collision setup, no LOD chain, no Nanite/material-atlas decisions** - out of this
  phase's stated scope (Allowed list: road-surface + sidewalk generation + the merge
  step + idempotency). `staticMesh->Build(true, ...)` uses the engine's own default
  build settings for everything not explicitly touched here.
