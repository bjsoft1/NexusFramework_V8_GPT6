# Phases 20-22 — Representation Arc Close (Relationship Queries / ActivationPoint Base / Validation Gate)

Task: Phases 20-22
Category: feature-add
Phase: phases/20, phases/21, phases/22
Status: Ready for Review
Completed Date: 2026-08-10
Completed Time: 02:28 NST (+0545)

## Context

Picked up via `/TODO`, user asked to batch "3-5 phases according to complexity" this
round (a return to the earlier "3-5 small phases per go" pattern after Phases 18/19 were
each done solo). `agent-todos/active/`/`ready-for-development/` were both empty. Phases
20, 21, 22 are the remaining three phases of the "Representation" arc (18-22, started by
Phase 18/19's prior solo pickups) - a natural batch boundary, stopping before Phase 23
starts the separate "Debug Architecture" arc.

## Problem / Goal

Implement `project-specifications/phases/phase-20.md` (Relationship Queries: junction
detection, live City center, tangent-aware Highway length, point neighbor lookup),
`phase-21.md` (the `FNexusActivationPoint` base struct + offset-transform composition),
and `phase-22.md` (Representation-stage validation gate) - closing out the arc Phase 19
started.

## Findings

1. **Implemented in dependency order (21, then 20, then 22), reported in phase-number
   order.** Phase 22's "dangling ActivationPoint -> HighwayPointId" check needs
   `FNexusActivationPoint` to exist, so Phase 21's struct was built first even though
   Phase 20 is numerically earlier; Phase 20's queries don't depend on either.
2. **Phase 20/22 both extend `FNexusRepresentationGraph` (Phase 19), not a new class** -
   the phase file's own top-level Objective frames "the full in-memory graph and its
   query API" as one combined deliverable, split into incremental-review-sized phases
   (19 = container + O(1) ID lookup, 20 = relationship queries, 22 = validation) rather
   than three separate types. New methods live in their own `.cpp` files per phase
   (`NexusRepresentationGraph.Queries.cpp`, `.Validation.cpp`), matching this project's
   "Source file organization" rule and the exact precedent `FNexusMapping`/
   `FNexusLandscapeReader` already set (one class, phase-split `.cpp` files) - the header
   itself stays the single source of the class's full interface.
3. **`ENexusGenerationClassification` (project-specifications/11-v6-static-dynamic-
   architecture.md) didn't exist in code yet** - Generation itself is Phase 40+, but
   Phase 21's `Classification` field (12's own spec: "almost always RuntimeActivated")
   needs a real type today. Added as its own header
   (`Public/Representation/NexusGenerationClassification.h`) since doc 11 frames it as a
   cross-cutting concept several future object types will share, not something owned by
   ActivationPoint specifically.
4. **`FNexusActivationPoint.Type` is `FName`, not a UENUM** - 12's own "Type registry,
   not a closed enum" section is explicit that V5's fixed 4-value
   `ENexusDynamicInteractableType` is exactly the pattern V6 must avoid. The real
   registry (type -> specialized struct/default classification/default Debug
   category/default gizmo behavior) is Phase 45's job; `FName` is a stable, extensible
   key today without inventing any switch-over-Type dispatch (this phase's own Not
   Allowed list), and needs no field-type migration when Phase 45 lands.
5. **`ENexusActiveTimes` reuses V5's exact bitmask shape** (`Day=0, Night=1,
   Afternoon=2, Midnight=3, MidnightAutoDisabled=4` - enumerator VALUE is the bit
   position, not a pre-shifted mask) with the containing field stored as plain `int32`
   + `meta = (Bitmask, BitmaskEnum = "...")`, per `v5-complete-reference.md`'s own
   documented "bitmask enums are stored as plain int32 UPROPERTYs... not as the enum
   type directly" convention (Cross-Cutting Architectural Notes #4).
6. **`FinalTransform = OffsetTransform * AnchorWorldTransform` in actual C++ operand
   order** - both 12-v6-activation-point-system.md and phase-21.md write the formula in
   prose as "HighwayPointTransform * OffsetTransform" (anchor first), but UE's
   `FTransform::operator*` composes as "this relative to Other" (`Local * Parent =
   World` - the same convention `USceneComponent` relative transforms use everywhere in
   the engine: `(A*B).TransformPosition(P) == B.TransformPosition(A.TransformPosition(P))`).
   Since the offset is explicitly documented as local to the anchor's frame, the
   mathematically correct call is `OffsetTransform * AnchorWorldTransform` - read the
   two docs' formula as naming the two ingredients, not dictating literal operand order.
   **Hand-verified during implementation** (not a substitute for the user's own manual
   check - see below): Anchor at Location=(0,0,0), Rotation=(Yaw=90,0,0); Offset
   OffsetLocation=(100,0,0), OffsetRotation=(0,0,0). `(Offset*Anchor).TransformPosition(0,0,0)
   = Anchor.TransformPosition(Offset.TransformPosition(0,0,0)) = Anchor.TransformPosition((100,0,0))
   = AnchorLocation + AnchorRotation.RotateVector((100,0,0)) = (0,0,0) + (0,100,0) = (0,100,0)`
   - i.e. exactly "anchor position plus the offset rotated into the anchor's facing
   direction," the expected parent-child composition result.
7. **`FNexusActivationPoint` has no `Code`/`Name`/`MakeDefault(Index)` factory**, unlike
   every other Nexus identity struct - 12's own field list for this struct doesn't
   include them, and Phase 21's Allowed list says "exactly as specified." Added
   `MakeNew()` (Id only) instead of the project's usual `MakeDefault(int32 Index)`
   convention, since there's no Code/Name to number.
8. **Highway length's tangent MAGNITUDE is a real architectural constraint, not an
   oversight** - "tangent-aware curve length" (Phase 20's own wording) needs a Hermite
   curve, which needs a tangent vector (direction + magnitude) at each endpoint.
   Direction is available via `FNexusHighwayPoint::GetLiveTangentDirection` (Phase 18),
   but the actual per-segment `TangentLen` lives on `FLandscapeSplineSegmentConnection`
   - a Source-stage-only read (`FNexusLandscapeReader`'s territory) that Phase 20's own
   Not Allowed list ("Do not read Landscape directly from Representation code - only via
   Mapping's output") puts off-limits here. Approximated tangent magnitude as chord
   distance between each point pair instead, matching V5's own documented "distance-
   based default... falls back to `MaterializeMissingPointGeometry`'s distance-based
   default" convention for an unauthored tangent length
   (`v5-complete-reference.md:172`). Numerically integrated via 16-sample cubic-Hermite
   evaluation per segment pair - a standard arc-length approximation, not a closed form
   (none exists for a general Hermite curve). **Hand-verified degenerate case**: two
   colinear points 100 units apart with both tangent directions pointing exactly along
   the connecting line reduce the Hermite curve to a straight line (a known identity
   when both tangent vectors equal the chord vector), giving `ComputeHighwayLength` ==
   100 exactly - confirms the arithmetic doesn't have a sign/order bug, though it is not
   a substitute for the user's own check against a real curved Highway (see below;
   real-curve accuracy depends on how well "chord distance" approximates the actual
   authored/auto tangent length V5's own formula would have used).
9. **Both completion criteria that were "hand-computed" during implementation (Findings
   #6 and #8) are still left UNCHECKED in their phase files** - `AGENT-RULES.md` is
   explicit: "Never claim that a feature is verified unless the user has manually
   verified it or explicitly provides verification results." This also matches Phase
   12's own established precedent (`ai-change-audits`'s Phase 10-14 record): even a
   provably-cache-free live recompute ("City center... never caches") was left unchecked
   pending the user's own drag-a-point-and-rerun check, not self-certified by the agent.
   Phase 19's two checked boxes remain a deliberately different case - those describe
   static/structural code facts (private map access, `TMap::Find` vs. linear scan) true
   for any input, not runtime numerical/behavioral claims about specific data.
10. **Phase 22's "deliberate-break test case is caught as Blocking" criterion is
    genuinely not exercisable with real data yet** - every field the validation reads
    is `VisibleAnywhere` (read-only in the Details panel, this codebase's own identity-
    field convention) and no phase through 22 implements deletion/un-mapping, so nothing
    in the current system can organically produce a dangling Representation-level
    reference. Deliberately did NOT add a synthetic corrupt-the-graph-for-testing
    console command to manufacture one - that would be test-only code, which
    `AGENT-RULES.md`'s Agent Testing Policy rules out ("Do NOT create test files,
    automation tests, unit tests, functional tests, or test-only code"). Left unchecked
    with an honest note in the phase file; will become naturally exercisable once a
    later phase adds real deletion.
11. **Phase 22's "ActivationPoint anchor" check takes `ActivationPoints` as an explicit
    parameter** (`const TArray<FNexusActivationPoint>& ActivationPoints = {}`) rather
    than requiring the graph to own ActivationPoint storage - Phase 19/20/21's Allowed
    lists never asked for the graph to store ActivationPoints (Phase 21 only defines the
    struct), so adding that storage now would be scope creep beyond what any of the
    three phases actually specifies. The check itself is fully implemented and correct;
    it is simply a no-op today since nothing yet produces `FNexusActivationPoint`
    instances to pass in.

## Changes

- New `Source/NexusFrameworkEditor/Public/Representation/NexusGenerationClassification.h`
  — `ENexusGenerationClassification` UENUM (Static/Instanced/MergedStatic/
  RuntimeActivated/RuntimePersistent/EditorOnly/DebugOnly), per 11-v6-static-dynamic-
  architecture.md (Findings #3).
- New `Source/NexusFrameworkEditor/Public/Representation/NexusActivationPoint.h` —
  `ENexusActiveTimes` bitmask enum (Findings #5) + `FNexusActivationPoint` USTRUCT
  (`ActivationPointId`/`HighwayPointId`/`OffsetLocation`/`OffsetRotation`/`Type`
  (`FName`)/`RuntimeClass` (`TSoftClassPtr<AActor>`)/`ActivationDistance`/`ActiveTimes`/
  `Classification`/`Metadata`), `MakeNew()`, `ComputeFinalTransform()` (Findings #4, #6,
  #7).
- New `Source/NexusFrameworkEditor/Private/Representation/NexusActivationPoint.cpp` —
  `Nexus.Representation.DumpActivationPointTransform` console command (Findings #6).
- `Source/NexusFrameworkEditor/Public/Representation/NexusRepresentationGraph.h` —
  added Phase 20 query method declarations (`IsJunction`/`ComputeCityCenter`/
  `ComputeHighwayLength`/`GetPointNeighbors`) and Phase 22's
  `ENexusRepresentationValidationSeverity`/`FNexusRepresentationValidationEntry`/
  `ValidateRepresentationStage()`; added `#include "Representation/NexusActivationPoint.h"`.
- New `Source/NexusFrameworkEditor/Private/Representation/NexusRepresentationGraph.Queries.cpp`
  — Phase 20 method bodies (including the Hermite-curve length helper, Findings #8) +
  `Nexus.Representation.DumpQueries` console command.
- New `Source/NexusFrameworkEditor/Private/Representation/NexusRepresentationGraph.Validation.cpp`
  — `ValidateRepresentationStage()` body (mirrors `FNexusMapping::ValidateMappingStage`'s
  own shape one stage up, Findings #10/#11) + `Nexus.Representation.ValidateStage`
  console command.
- `project-specifications/phases/phase-20.md`, `phase-21.md`, `phase-22.md` — Status →
  `Ready for Review`; all six completion criteria left unchecked with exact manual-check
  console-command steps (Findings #9, #10).

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, first attempt, 0 errors. All five new/changed `.cpp` files
  (`NexusActivationPoint.cpp`, `NexusRepresentationGraph.cpp` (unchanged, recompiled),
  `.Queries.cpp`, `.Validation.cpp`) plus the regenerated `Module.NexusFrameworkEditor.cpp`
  compiled clean.
- `node html-docs/build.js` — regenerated `PHASE-STATUS.md`/`phase-data.js`/
  `phase-tracker.html` after the three status writes.
- **No automated tests written or run** — per `AGENT-RULES.md`'s Agent Testing Policy.
  All six completion criteria across the three phases are left unchecked; exact
  `Nexus.Representation.*` console-command steps for each are written into their
  respective phase files.

## Result

Implementation complete for all three phases, build-verified. This closes the
"Representation" arc (Phases 18-22). All six completion criteria across Phases 20-22
require the user's own manual editor session and are left unchecked pending that,
consistent with `AGENT-RULES.md` and the Phase 12 precedent for this exact category of
claim (live-recompute/numerical-accuracy behavior, not static code structure).

## Important Notes

- Next natural batch start: Phase 23 ("Debug Architecture — Category Registry"), the
  first phase of a new arc — a clean place to stop rather than starting a fourth,
  differently-scoped phase in this same round.
- `FNexusRepresentationGraph` (Phases 19/20/22 combined) is still not wired into any
  consumer, same note as Phase 19's own record — `UNexusConfigAsset`/`FNexusMapping`
  remain the actual persisted read/write path used everywhere else; only the
  `Nexus.Representation.*` console commands currently instantiate the graph (each a
  local, transient rebuild-and-discard).
- `FNexusActivationPoint` is likewise not yet stored anywhere (no config field, no
  graph collection) — Phase 22's anchor-validation check is implemented and correct but
  exercises nothing until a future phase actually produces instances of it.
- Three genuinely-open verification gaps for the user, none blocking review: (1) City
  center live-update (Phase 20), (2) Highway length accuracy on a real curved Highway
  vs. the chord-distance tangent-magnitude approximation (Phase 20), (3) composition
  math + live-anchor-move (Phase 21) — all have exact console-command steps in their
  phase files. Phase 22's "deliberate break" criterion additionally can't be exercised
  at all yet (Findings #10) until a later phase adds deletion.
