# Phases 38, 39, 40 — Validation Hardening + Static Generator Classification Tagging

Task: Phases 38, 39, 40
Category: feature-add
Phase: phases/38, phases/39, phases/40
Status: Ready for Review
Completed Date: 2026-08-10
Completed Time: 10:05 NST (+0545)

## Context

Picked up via `/TODO` ("pick next phase", batch size "3-5") while the user continued
reviewing earlier batches (several phases moved to the new `In Review` status this
round). `agent-todos/` was empty. The lowest-numbered `Not started` phases were 33-35
("Debug Performance") - skipped again, same reasoning as every prior round this
session: their own Not Allowed list forbids optimizing a subsystem before it's
correctness-verified, which is exactly what the user is still doing for Phases 23-32.
Read Phase 38 and 39 in full before committing to this batch - confirmed Phase 39's own
"broken junction consistency" ask, previously flagged as an open architectural question
in this session's own Phase 36-37 audit record, is now cleanly resolvable thanks to
today's earlier stale-Highway fix (`ai-change-audits/2026-08-10/bug-fixed/
stale-highway-not-detected-on-landscape-removal.md`) - so the tension is resolved, not
just deferred again. Phase 40 was added to round the batch out to 3 (matching "3-5")
since it's a self-contained, non-optimization phase with no dependency on 33-35.

## Problem / Goal

Phase 38: combine Phase 09's Source-stage and Phase 14's Mapping-stage validation gates
into one callable pass. Phase 39: harden Phase 22's Representation gate with (a)
invalid City/Highway relationship checks and (b) broken-junction-consistency checks.
Phase 40: implement the Static Generator's classification enum (already existed) and
its per-object-type mapping table, per `11-v6-static-dynamic-architecture.md`.

## Findings

1. **Source/Mapping validation entry structs are already identical in shape** -
   `FNexusSourceValidationEntry` and `FNexusMappingValidationEntry` both have exactly
   `Severity`/`Message`/`bHasWorldLocation`/`WorldLocation`, in the same order - a
   deliberate, repeated precedent ("each pipeline stage gets its own type", stated
   explicitly in both structs' own header comments) rather than an oversight. Phase 38's
   combined gate returns `FNexusMappingValidationEntry` (converting Source entries
   field-by-field) instead of introducing a fourth near-identical struct.
2. **Nothing currently calls both Source+Mapping gates together as a pass/fail unit** -
   `FNexusDiagnostics::GatherDiagnostics` calls both, but for Diagnostics-Panel display
   (needs each entry's own stage tag), not as a Blocking/clean gate return. Phase 38's
   new `FNexusMapping::ValidateLandscapeMappingCombinedGate` is genuinely new
   functionality, not a refactor of existing logic.
3. **Diagnostics deliberately was NOT refactored to route through the new combined
   gate** - it needs to know WHICH stage produced each entry (its own `StageName` field:
   "Source"/"Mapping"/"Representation", already user-visible in the panel) to tag
   correctly; the combined gate's merged result discards that distinction by design.
   Routing Diagnostics through it would have been a real, silent panel regression
   (losing the stage prefix), not a legitimate consolidation - documented as a
   deliberate non-change in `phase-38.md` rather than silently deciding either way.
4. **Phase 39's "invalid City/Highway relationship" ask was already fully implemented**
   before this batch - `ValidateRepresentationStage` (Phase 22) already checks
   `Highway.CityId`/`EndCityId` resolve in `Cities`, and `City.StateId` resolves in
   `States`. Re-verified by reading the existing 159-line implementation in full before
   adding anything, rather than assuming either way. No new code for this half of Phase
   39 - re-implementing an existing check would be duplicated logic, not hardening.
5. **"Broken junction consistency" (the genuinely missing half of Phase 39) is now
   answerable without Representation ever reading Landscape**, thanks to this session's
   own earlier stale-Highway fix: a junction is exactly the set of Highways sharing a
   HighwayPointId (Phase 20's own definition); if every contributing Highway's chain
   still matches live Landscape (today's `DoesHighwayChainMatchLiveLandscape`), the
   junction is real by construction - Representation doesn't need to independently
   re-derive Landscape adjacency, only consume Mapping's own pass/fail verdict per
   Highway. Added `FNexusMapping::ComputeHighwaysNotMatchingLiveLandscape` (wraps the
   existing per-Highway check into a ready-to-use `TSet<FGuid>`) and a new, defaulted
   `HighwaysNotMatchingLiveLandscape` parameter on `ValidateRepresentationStage` - the
   CALLER (console command, Diagnostics) computes the set via Mapping's Landscape-aware
   function and hands over only the resulting Guid set, so `ValidateRepresentationStage`
   itself never touches an `ALandscape*`, staying inside this phase's own "no direct
   Landscape read" rule literally, not just in spirit.
6. **The new junction check is additive-only by construction, not just by testing** -
   gated entirely behind `if (HighwaysNotMatchingLiveLandscape.Num() > 0)`, with the
   parameter defaulting to an empty set. No existing behavior changes unless a caller
   explicitly opts in by passing a non-empty set - "no regression in Phase 22's original
   test cases" is a structural fact, not something that needed a live re-test.
7. **`ENexusGenerationClassification` already existed** (Phase 21, for
   `FNexusActivationPoint::Classification`) - Phase 40's real net-new scope was the
   object-type enum and the mapping table, not the classification enum itself (despite
   Phase 40's own Allowed list literally saying "implement the classification enum").
8. **The architecture doc's own starting object-type table has exactly 16 rows**, not
   the ~30-40 figure referenced earlier in this session's own conversation history - that
   larger future catalog isn't written down anywhere in the spec yet. `ENexusStaticObjectType`
   (new) covers exactly those 16 rows, no more, no less; growing it toward the larger
   eventual set is explicitly left to later Generation phases, not invented here.
9. **Several of the doc's 16 rows are genuinely ambiguous** ("Static or Instanced",
   "Static/Instanced") rather than clean 1:1 mappings - each ambiguous row's resolved
   choice (all resolved to `Instanced`, on "repeats identically across the world"
   reasoning - city-light poles, bus-stop shelters, seats) is commented at its own
   `case` in `ResolveClassification`, not silently picked with no trace of the decision.
10. **The unclassified-object assertion is `ensureAlwaysMsgf` + fallback, not a crash** -
    a Development-build `ensure` logs and continues rather than terminating, matching
    this project's own "manual console-command verification, never destructive testing"
    policy - the deliberately-broken test case (`Nexus.Generation.TestUnclassifiedAssertion`,
    passing raw value `255`) can be safely re-run by the user without crashing the
    editor.

## Changes

- `Public/Mapping/NexusMapping.h` — new `ComputeHighwaysNotMatchingLiveLandscape`
  (Finding #5) and `ValidateLandscapeMappingCombinedGate` (Findings #1-3) declarations.
- `Private/Mapping/NexusMapping.Validation.cpp` — `ComputeHighwaysNotMatchingLiveLandscape`
  implementation, next to its sibling `DoesHighwayChainMatchLiveLandscape`.
- New `Private/Mapping/NexusMapping.CombinedGate.cpp` — Phase 38's
  `ValidateLandscapeMappingCombinedGate` implementation + `Nexus.Mapping.ValidateCombinedGate`
  console command.
- `Public/Representation/NexusRepresentationGraph.h` — `ValidateRepresentationStage`
  gained the new defaulted `HighwaysNotMatchingLiveLandscape` parameter (Finding #5).
- `Private/Representation/NexusRepresentationGraph.Validation.cpp` — new broken-junction
  check loop (Finding #5); its own console command
  (`Nexus.Representation.ValidateStage`) updated to compute the set via Mapping and pass
  it in; log/registration text updated to mention Phase 39.
- `Private/Debug/NexusDiagnostics.cpp` — updated to compute
  `HighwaysNotMatchingLiveLandscape` and pass it to `ValidateRepresentationStage`, so the
  Diagnostics Panel picks up broken-junction entries too (still calls Source/Mapping
  gates separately - Finding #3).
- New `Public/Generation/NexusGenerationObjectType.h` — `ENexusStaticObjectType` (16
  values, Findings #8-9).
- New `Public/Generation/NexusGenerationClassificationTable.h` /
  `Private/Generation/NexusGenerationClassificationTable.cpp` — `ResolveClassification`
  (Findings #9-10), `GetFullTable`, `Nexus.Generation.DumpClassificationTable` and
  `Nexus.Generation.TestUnclassifiedAssertion` console commands. New `Generation/`
  folder pair (Public/Private) - the first code for the Static Generator pipeline stage,
  following this project's existing per-stage-folder convention (Reader=Source,
  Mapping=Mapping, Representation=Representation).
- `project-specifications/phases/phase-38.md`/`phase-39.md`/`phase-40.md` — Status ->
  `Ready for Review`; each gained an "Implementation note" section; completion criteria
  checked where structurally provable (see each phase file's own reasoning), left
  unchecked with exact manual-check steps otherwise.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, first attempt, 0 errors, 19 actions (bundled with the earlier
  `Nexus.Status` command in the same build).
- `node html-docs/build.js` — regenerated.
- **No automated tests written or run** — per `AGENT-RULES.md`'s Agent Testing Policy.
  Manual console-command steps for every non-structural criterion are in each phase
  file.

## Result

Implementation complete for Phases 38-40, build-verified. Phase 39's broken-junction
check is the one most worth the user's close attention - it directly answers a question
this session's own earlier Phase 36-37 audit record left open, and its manual-check
steps reuse the exact closed-loop-diagonal scenario the user already built while testing
the stale-Highway fix, so re-verifying it should be fast.

## Important Notes

- Phase 40's `ENexusStaticObjectType` (16 values) is a STARTING set, not the full future
  catalog - explicitly scoped to what `11-v6-static-dynamic-architecture.md` currently
  documents (Finding #8). Whoever picks up the object types this doesn't yet cover
  should add both a new enum value AND a new `ResolveClassification` case in the same
  change, never one without the other (the whole point of the hard-switch design).
- Phase 41 (Mesh Merge Pipeline) and 41a (Junction Mesh Selection, Lane-Aware - added
  earlier today) were NOT picked up this round - both are substantially larger pieces of
  actual mesh-generation work, better scoped as their own dedicated round than bundled
  into an already-large 3-phase batch.
