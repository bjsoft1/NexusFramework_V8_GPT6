# Phases 23-26 — Debug Architecture (Category Registry / Tree View / Per-Category Config / Config Persistence)

Task: Phases 23-26
Category: feature-add
Phase: phases/23, phases/24, phases/25, phases/26
Status: Ready for Review
Completed Date: 2026-08-10
Completed Time: 02:44 NST (+0545)

## Context

Picked up via `/TODO`, user asked to pick "2-5 phases" this round. `agent-todos/active/`/
`ready-for-development/` were both empty. Phase 23 is the lowest-numbered `Not started`
phase, first of the "Debug Architecture" arc (23-27). Read this arc's own phase files
before starting and found Phase 27 ("Diagnostics Panel & Viewport Rendering") has a real
forward dependency this session shouldn't resolve by jumping ahead: its own Allowed list
says to render flagged entities "via Phase 28/29's shared primitives," but Phases 28/29
("Debug Rendering — Wireframe Primitives"/"Labels & Text") are a separate, later arc,
still `Not started`. Building any of 28/29 early to unblock 27 would violate this
project's "Do not jump phases" rule (`09-development-rules.md`); implementing 27's
viewport-rendering half without that dependency would be guessing at an interface a
later phase actually owns. Batched 23-26 instead (the rest of the arc that has no such
gap) and stopped cleanly before 27, flagging this explicitly rather than pushing through.

## Problem / Goal

Implement `project-specifications/phases/phase-23.md` (category registry),
`phase-24.md` (real Debug Tree UI), `phase-25.md` (per-category config + editing panel),
and `phase-26.md` (config-asset persistence) per `project-specifications/
06-v6-debug-system.md` and `07-v6-ui-design.md`.

## Findings

1. **`FNexusDebugRenderConfig` (Phase 25's own named deliverable) was built complete in
   Phase 23, not deferred** — Phase 23's own Allowed list already names `DefaultConfig`
   as one of `FNexusDebugCategory`'s five fields to implement, and 06's field list for
   it is already 100% specified with no dependency on the registry existing first.
   Building a stub/partial version now and "completing" it in Phase 25 would have meant
   two divergent definitions of the same struct across two phases, which this project
   avoids elsewhere. Phase 25's own real net-new work ended up being: the editing panel
   binding + the group-level default colors + the "no bespoke fields" verification -
   not the struct's field list itself.
2. **The registry is a Meyer's singleton (`FNexusDebugCategoryRegistry::Get()`), not a
   `UEditorSubsystem`** - category registration is a static, compile-time-authored fact
   (which categories exist), unlike `UNexusFrameworkSubsystem::ActiveConfig` (genuinely
   per-editor-session state). The mutable, session-scoped part (RuntimeConfigs, current
   visibility/color per category) lives inside the same class instead, mirroring how
   `FNexusRepresentationGraph` (Phases 19/20/22) grew its query/validation surface on
   one class across phases rather than spawning a new type per phase.
3. **"Zero edits to the registry code itself" is enforced by construction, not just
   documented**: `FNexusDebugCategoryAutoRegister` mirrors this codebase's existing
   `FAutoConsoleCommand` self-registration idiom (a static object at namespace scope in
   any `.cpp`, calling `Get().RegisterCategory(...)` from its constructor) - safe against
   static-initialization order because `Get()`'s storage is a function-local static
   (constructed on first call, regardless of which translation unit's static object
   calls it first). The six top-level groups just happen to be registered in
   `NexusDebugCategoryRegistry.cpp` because they ARE this registry's initial content;
   nothing about the mechanism requires a new category's registration to live in that
   file.
4. **`RendererFn`'s signature is `DECLARE_DELEGATE_OneParam(..., const
   FNexusDebugRenderConfig&)`** - a deliberately narrow choice. 06's "given live data +
   config, draw" doesn't specify a "live data" shape, and it can't: a Highway renderer's
   live data is Representation Highways, a HighwayPoint renderer's is
   HighwayPoints - genuinely different per category, matching the performance rule that
   renderers read their own cached Representation-stage data rather than the registry
   handing them something generic. The delegate only carries the "config" half; a
   renderer is expected to close over (or otherwise source) its own data access. No
   renderer exists yet (Debug Rendering starts Phase 28) so this signature is
   unexercised - worth double-checking once a real one is written.
5. **Two "prove extensibility with N categories" completion criteria (Phase 23's dummy
   51st, Phase 24's 60-category stress test) were satisfied with ON-DEMAND console
   commands (`Nexus.Debug.RegisterTestCategory`, `Nexus.Debug.
   RegisterStressTestCategories`), not permanent test scaffolding** - both register real
   categories into the real (session-lifetime, in-memory-only) registry when the user
   explicitly runs them, same reasoning as every `Nexus.*` verification command
   elsewhere in this project (real functionality being exercised for verification, nothing
   synthetic-only baked in). `AGENT-RULES.md`'s Agent Testing Policy bars "test-only
   code," which a permanently-registered dummy category sitting in production code for
   no functional reason would have been.
6. **Debug Tree uses a NEW dedicated item type (`FNexusDebugTreeItem`), not the existing
   `FNexusPlaceholderTreeItem`** - the two trees are diverging in nature (Hierarchy stays
   placeholder-only pending a future Representation-consuming phase; Debug Tree is now
   real). Reusing the placeholder type would have meant adding a `CategoryId` field that
   only makes sense for one of the two trees, or double-keying by both `FGuid` (the
   placeholder's key) and `FName` (the registry's actual key) - a dedicated type avoided
   both.
7. **The Debug Tree's old Delete/Rename/Focus context menu (Phase 04 placeholder
   behavior) was DROPPED for the Debug Tree specifically, not ported forward** - deleting
   or renaming a code-registered category from a right-click menu doesn't correspond to
   anything real (categories are defined in code, not authored data), and Phase 24's own
   Allowed list doesn't ask for a replacement interaction. The Hierarchy tree's own
   context menu is untouched. `OnDebugTreeContextMenuOpening` was removed rather than
   left as a set of now-meaningless no-op menu entries.
8. **Every Debug Tree row gets the visibility checkbox, not just leaves** - 06's own
   wording is "per-leaf visibility checkbox," but today's tree is parent-only (no
   renderer/leaf exists until Phase 28+), so a strict leaf-only reading would mean zero
   functional checkboxes exist yet to test against. Every `FNexusDebugCategory`
   (including the six groups) already has its own `DefaultConfig`/`bVisible`, so
   applying the same checkbox uniformly costs nothing and gives the completion
   criterion ("toggling a leaf's checkbox is reflected immediately") something real to
   exercise today rather than waiting for Phase 28+.
9. **Details-panel binding for a Debug Tree selection points DIRECTLY at the registry's
   own live `FNexusDebugRenderConfig` via `GetMutableRuntimeConfig` (a pointer into the
   registry's own `TMap`), not a local copy** - same live-struct-pointer pattern Phase 04
   established for `FNexusPlaceholderDetails`, chosen so edits in the Details panel
   write straight through with no separate "commit" step. Stable as long as no new
   category is registered while the panel holds the pointer (`TMap` values move on
   `Add`/`Remove`, not on lookup) - true for a normal editing session; the two on-demand
   stress/test-category commands (Findings #5) are the only things that could register
   new categories mid-session, and neither is expected to run while the Details panel
   is actively open on an unrelated category.
10. **Persistence hooks were added by EXTENDING two already-existing, already-reviewed
    call sites** rather than inventing new ones: `FNexusConfigAssetIO::SaveConfigAsset`
    (Phase 13, "the one place a write to disk happens" per its own doc comment) now also
    calls `SaveRuntimeConfigsToConfigAsset` before writing; `FNexusLandscapeModeExtension::
    OnEditorModeIDChanged`'s entering-Landscape-Mode branch (Phase 15's automatic
    enable-flow trigger) now also calls `RestoreRuntimeConfigsFromConfigAsset` right
    after `RunAutomaticEnableFlow` resolves a config. Both are cross-domain calls
    (Mapping-domain files now referencing the Debug registry) - a deliberate,
    documented trade-off matching this project's own precedent of keeping "the one
    place a write/load happens" singular rather than requiring every future call site
    to remember a second sync step, and matching `NexusConfigAssetIO.cpp`'s own
    pre-existing cross-domain dependency on `FNexusLandscapeReader`.
11. **Tab-invoke-before-config-load ordering (pre-existing, unchanged by this batch) is
    not a real bug for the restore hook**: `OnEditorModeIDChanged` invokes the Nexus tab
    (constructing `SNexusFrameworkPanel`) BEFORE resolving/restoring config. This means
    the Debug Tree's checkboxes could theoretically render once against
    not-yet-restored values. Not an actual problem because
    `SCheckBox::IsChecked`/`OnCheckStateChanged` are bound via `_Lambda` (a live
    `TAttribute`/delegate Slate re-evaluates on repaint), not a value captured once at
    construction - the checkbox reflects whatever `GetRuntimeConfig` currently returns
    on its next paint, which is after the restore call completes a few lines later in
    the same function.
12. **`Nexus.Debug.DumpCategoryRuntimeConfigs` deliberately reuses the EXISTING
    `Nexus.Mapping.SaveConfig`/`Nexus.Mapping.RunAutomaticEnableFlow` commands for the
    save/restore halves of its own round-trip verification** rather than adding new
    `Nexus.Debug.Save`/`Nexus.Debug.Restore` commands - since both are now wired into
    those existing entry points (Finding #10), no new save/restore trigger was needed,
    only a way to inspect the result.

## Changes

- New `Source/NexusFrameworkEditor/Public/Debug/NexusDebugRenderConfig.h` —
  `FNexusDebugRenderConfig` USTRUCT, full field list per 06 (Findings #1).
- New `Source/NexusFrameworkEditor/Public/Debug/NexusDebugCategory.h` —
  `FNexusDebugCategoryRendererDelegate` + `FNexusDebugCategory` (Findings #4).
- New `Source/NexusFrameworkEditor/Public/Debug/NexusDebugCategoryRegistry.h` /
  `Private/Debug/NexusDebugCategoryRegistry.cpp` — `FNexusDebugCategoryRegistry`
  (register/find/get-children/get-all + runtime-config get/mutable-get + Phase 26's
  save/restore) + `FNexusDebugCategoryAutoRegister` (Findings #2, #3); six top-level
  group registrations with Phase 25's default colors baked in (Findings #1); console
  commands `Nexus.Debug.DumpCategoryRegistry`, `.RegisterTestCategory`,
  `.RegisterStressTestCategories`, `.DumpCategoryRuntimeConfigs` (Findings #5, #12).
- `Source/NexusFrameworkEditor/Public/Mapping/NexusConfigAsset.h` — added
  `TMap<FName, FNexusDebugRenderConfig> DebugCategoryConfigs`.
- `Source/NexusFrameworkEditor/Private/Mapping/NexusConfigAssetIO.cpp` —
  `SaveConfigAsset` now also calls `FNexusDebugCategoryRegistry::
  SaveRuntimeConfigsToConfigAsset` (Findings #10).
- `Source/NexusFrameworkEditor/Private/UI/NexusLandscapeModeExtension.cpp` —
  entering-Landscape-Mode branch now also calls `RestoreRuntimeConfigsFromConfigAsset`
  after resolving the config (Findings #10, #11).
- New `Source/NexusFrameworkEditor/Public/UI/NexusDebugTreeItem.h` —
  `FNexusDebugTreeItem` (Findings #6).
- `Source/NexusFrameworkEditor/Private/UI/SNexusFrameworkPanel.h`/`.cpp` — Debug Tree
  section rebuilt from the registry (`BuildDebugTreeFromRegistry`/
  `BuildDebugTreeChildrenRecursive`), new row generator with an `SCheckBox` bound to
  each category's `bVisible` (Findings #8), new selection handler binding the Details
  panel to the selected category's live `FNexusDebugRenderConfig` (Findings #9); removed
  `BuildPlaceholderDebugTree`/`OnDebugTreeContextMenuOpening` (Findings #7). Hierarchy
  section is untouched.
- `project-specifications/phases/phase-23.md` through `phase-26.md` — Status → `Ready
  for Review`; Phase 25's first criterion checked off as a structural fact (Findings #9
  supports the "no per-category special-casing" claim); the other seven completion
  criteria across the four phases left unchecked with exact manual-check steps.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, first attempt after each of the two build passes this batch
  (Phase 23+persistence wiring, then Phase 24/25 UI), 0 errors both times.
- `node html-docs/build.js` — regenerated `PHASE-STATUS.md`/`phase-data.js`/
  `phase-tracker.html` after the four status writes.
- **No automated tests written or run** — per `AGENT-RULES.md`'s Agent Testing Policy.
  Seven of eight completion criteria across Phases 23-26 require the user's own
  in-editor session; exact `Nexus.Debug.*` console-command steps are written into each
  phase file.

## Result

Implementation complete for Phases 23-26, build-verified. Phase 27 deliberately NOT
picked up this round - see Context section; it needs Phase 28/29 to exist first, or a
decision from the user about how to handle that forward reference, before an agent
should implement it.

## Important Notes

- **Phase 27 is the next natural item only if its Phase 28/29 dependency is resolved
  first** - either by doing 28/29 out of the normal roadmap order (a deliberate,
  user-approved exception to "do not jump phases," since 27 numerically precedes them
  but structurally needs them), or by the user clarifying that Phase 27's viewport
  rendering should use a simpler interim mechanism (e.g. calling `DrawDebugLine`/
  `DrawDebugSphere` directly, matching V5's own precedent per 06-v6-debug-system.md's
  "Mechanism, confirmed from V5's actual source" section) rather than "Phase 28/29's
  shared primitives" as literally written. Flagging this for the user rather than
  guessing which resolution they'd prefer.
- No renderer exists for any category yet (Debug Rendering starts Phase 28) - the
  Debug Tree today only ever shows the six empty top-level groups (or 60, if the
  stress-test command has been run) with no leaves, by design.
- `RegisterStressTestCategoriesConsoleCommand`'s registered categories are session-only
  (the registry is in-memory, not persisted) - restarting the editor clears them; no
  cleanup command was added since none is needed.
