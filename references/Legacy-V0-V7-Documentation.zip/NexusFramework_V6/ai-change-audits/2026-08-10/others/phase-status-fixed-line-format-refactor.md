# Phase status format refactor — fixed-line block replaces free-form sentence

Date: 2026-08-10
Category: others
Phase: N/A (tooling — affects every roadmap phase file, `html-docs/build.js`,
`html-docs/server.js`, `.claude/commands/TODO.md`)

## Context

User-requested refactor of the phase-tracking tooling. Every `project-specifications/
phases/phase-NN*.md` file's `## Status` section used to be a single free-form sentence,
e.g. `Ready for Review — 2026-08-10 15:10 GMT+5:45 (+0545).`, optionally followed by
trailing prose. Two real problems with that shape: (1) `build.js` (reading) and
`server.js` (writing) each kept their own separate regex/paragraph-scraping logic to
interpret it — the exact "keeping status logic in 2 places" duplication the user wanted
gone; (2) each stage transition overwrote the single line, so once a phase moved past
`Ready for Review` to `In Review`, the `Ready for Review` date was gone for good — no
permanent record of when each stage was actually reached.

Two design questions were confirmed with the user before touching ~60 already-in-flight
phase files: **(1)** the new format replaces the `## Status` section's content in place
(same heading, no new frontmatter block) - both recommended options. **(2)** migration
is "start fresh" — only each phase's currently-active stage gets its date carried over;
earlier stages already passed through are left blank rather than guessed at from git
history.

## Changes

**New format** (every phase file, `09-development-rules.md` rule 12):
```
## Status

<Stage>
Ready for Review: <date+time, or blank>
In Review: <date+time, or blank>
Ready for QA: <date+time, or blank>
Complete: <date+time, or blank>

<optional free-form notes, preserved untouched by any status change>
```
`<Stage>` is still the same seven-value vocabulary. Only the four listed stages get a
dedicated dated field — `Not started`/`In progress`/`Blocked` have none (matches the
user's own spec of exactly 4 dated fields). Setting a phase to one of the four dated
stages stamps ONLY that stage's own field with `nowTimestamp()`'s output — the other
three and any notes are carried over unchanged, so a phase's full stage history now
accumulates permanently instead of being overwritten transition-by-transition.

**`html-docs/build.js`**: added shared `parseStatusBlock(lines, statusHeaderIdx)` /
`serializeStatusBlock(stage, dates, notes)`, exported via `module.exports` alongside
`markdownToHtml`. `extractPhases()` rewritten to use them; `classifyStatus()` simplified
from substring-matching to an exact-match dictionary lookup (the stage field is now an
unambiguous keyword, not free text mixed with prose). The generated `statusText` field is
still synthesized in the exact same `"<Stage> — <date>. <notes>"` shape the old format
used, specifically so `PHASE-STATUS.md`'s table and `phase-tracker.js`'s rendering/
Complete-lock-timestamp regex keep working completely unchanged — this refactor only
changes on-disk storage and the two Node scripts' own parsing, not the browser-facing
contract. Generated phase objects (`phase-data.js`, `/api/phases`) also now carry the
raw structured `stage`/`dates` fields for any future consumer, in addition to the
existing `status`/`statusText`.

**`html-docs/server.js`**: `setPhaseStatus()` rewritten to call the same shared
`parseStatusBlock`/`serializeStatusBlock` from `build.js` instead of keeping its own
separate line-replacement regex — this is the actual fix for the "2 places" duplication.
The Complete-lock check now reads `parsed.dates['Complete']` directly instead of
regex-scraping a free-text status line (`parseDateFieldValue`, renamed from
`parseStatusTimestamp`, now parses a single already-isolated field value, not a whole
prose line). `ALLOWED_STATUSES` now derives from `build.js`'s own exported `ALL_STAGES`
instead of a second hardcoded copy of the same seven-value list.

**Migration**: all 108 existing phase files converted via a one-off Node script (run
once from the scratchpad, not kept in the repo). Verified via `git diff --stat`: 108
files changed, 542 insertions / 113 deletions, no warnings from the migration script
(every file matched the expected old-format shape on the first pass, including the one
irregular case — Phase 00's multi-line trailing prose paragraph, confirmed preserved
byte-for-byte as the new format's free-form notes).

**Docs updated to match**: `09-development-rules.md` rule 12 (full format
specification + example), `.claude/commands/TODO.md` Step B7 (agent must now write only
the `<Stage>` line and that stage's own dated field, never touch the other three or any
notes), `html-docs/README.md` (API description, Complete-lock description).

## Verification

- `node html-docs/build.js` — succeeded, wrote 20 doc pages + PHASE-STATUS.md (108
  phases, 6 complete, matching pre-refactor state) + phase-data.js + phase-tracker.html.
- `node --check` on both `build.js` and `server.js` — syntax OK.
- In-memory dry-run (no file writes) of the exact parse → advance-stage → serialize →
  splice → re-parse round-trip `server.js`'s `setPhaseStatus` now performs, run against a
  copy of `phase-41.md`'s real content: confirmed advancing `Ready for Review` →
  `In Review` stamps the new field while leaving the `Ready for Review` date from the
  original file completely intact - the core behavior this whole refactor was for.
- Separately confirmed `phase-00-v5-study.md`'s multi-line notes paragraph (the one
  file in the whole set with real trailing prose, not just a bare date) parses back out
  verbatim.
- **Not run**: `server.js` itself was not started/hit over HTTP (would bind a real port
  as a side effect) - the dry-run above exercises the same underlying functions the HTTP
  handler calls, which is what's actually new; the HTTP plumbing around it (routing,
  JSON responses) is unchanged from before this refactor and wasn't touched.

## Result

One shared parser/serializer in `build.js`, reused by both the read path
(`extractPhases`) and the write path (`server.js`'s `setPhaseStatus`) instead of two
independent regexes. Every phase's stage-transition history now survives past that
stage - a phase currently `In Review` still shows exactly when it first became `Ready
for Review`, which the old format could never preserve.

## Important Notes

`phase-data.js` was **kept**, not removed, despite the user's initial phrasing ("we made
phase.js array so, removed this"). Judgment call, flagged to the user rather than
guessed silently: re-reading the request, the actual complaint was about duplicated
*parsing/writing* logic (now fixed - one shared parser), not about a generated cache
file existing at all. `phase-data.js` remains 100% derived output (never hand-edited,
regenerated by `build.js`) and its removal would have silently broken
`phase-tracker.html`'s offline/no-server viewing mode (`file://`, no `node html-docs/
server.js` running) - it would render fully blank instead of read-only. If the user
still wants it gone after this explanation, that's a follow-up, not something this
record silently decided.
