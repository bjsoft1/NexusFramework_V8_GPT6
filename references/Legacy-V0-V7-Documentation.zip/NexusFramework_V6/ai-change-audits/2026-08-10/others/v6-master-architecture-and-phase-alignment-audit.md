# V6 Master Architecture doc added; full Phase 01-100 alignment audit against it

Date: 2026-08-10
Category: others (architecture decision + documentation-only roadmap revision)
Phase: 20a/34/40a/45/46/48/60a/62/64/65/66/69/70/71/72/79/80/80a/82/85/87/88/89/92/93
(all documentation/spec edits, no C++ changes)

## Context

User provided a full "V6 Final Architecture & Phase Alignment — Master Instruction"
document (35 sections) establishing V6 as the final production architecture (no future
V7 to fix fundamental mistakes), with an explicit pipeline (Landscape -> Editor
Authoring -> Debug Viz -> Gizmo -> Validation -> Runtime Compiler -> Runtime Schema ->
Mesh Generation/AI/Gameplay), a Landscape-source-of-truth rule, three object categories
(Transportation/Infrastructure/Services), a universal authoring model, an explicit
N-sub-point gizmo requirement, field-level specs for Parking/Bus Stop/Seat, debug
LOD/always-draw requirements (porting V0 concepts researched earlier this session),
junction rotation safety, and a massive-world static+dynamic actor strategy (logical
object data vs. a small pooled subset of active Actors). The user asked for this to be
saved as the new top-level architecture doc, and for Phase 01-100 to be audited against
it, with existing phases enhanced (never renumbered) where gaps are found, plus
mandatory Phase 20/40/60/80/100 "Architecture Review" checkpoints.

## Findings

1. **Saved as `project-specifications/v6-master-architecture.md`**, wired into
   `README.md`'s doc index and reading order (read second, after `AGENT-RULES.md`,
   before `v6-phase-verification.md`) and cross-referenced from `CLAUDE.md`.
2. **Full audit performed via 3 parallel Explore agents** covering phases 33-49, 50-75,
   76-93 (phases 1-32 covered by re-confirming the existing 2026-08-09
   `v6-phase-verification.md` audit plus the user's own direct confirmation earlier
   this session that Location/Rotation/Tangent are never cached in NexusConfig).
3. **Two previously-flagged gaps (junction rotation solver, Diagnostics viewport
   rendering) were found ALREADY CLOSED** — implemented earlier today by a concurrent
   process/session working the same repo (see this session's own earlier flagging of
   concurrent-commit activity, `01f2dee`/`c568906`). Not re-fixed; confirmed via direct
   file read before starting other work, to avoid duplicate/conflicting effort.
4. **The single largest genuine gap**: the gizmo system's "base" (Phase 48) only ever
   proved a single fixed `OffsetLocation`/`OffsetRotation` pair. Traffic Light (54)/City
   Light (58) each hardcoded a small fixed count of named sub-offsets rather than a
   generic mechanism. Crosswalk (60-63) and Bus Stop (64-68) — the two object types
   whose data models actually contain dynamic-length arrays
   (`WaitingPoints[]`/`PassengerWaitingPoints[]`/`SeatInteractionPoints[]`) — had zero
   mentions of "gizmo" anywhere (grep-confirmed across both phase groups).
5. **Seat (Phase 69) was a real conflict, not just a gap**: its own completion criteria
   asserted "zero Seat-specific code... registration alone is sufficient," directly
   contradicting the master doc's Section 8 (SeatType/Capacity/Occupancy/Spacing/
   Mesh/grouping, one physical object = N logical seats). Confirmed a **regression from
   V5's own `FNexusSittingSite`** (SiteCapacity, `FNexusOccupancyGrid`
   NumRows/NumColumns/OccupiedIndex, `OverrideMeshOptionsByCapacity` keyed by capacity)
   — V5 had modeled this correctly years earlier; the V6 phase spec as originally
   written would have thrown that capability away.
6. **Parking (70) and Bus Stop (64) field gaps**: Parking reused V5's narrower
   `SegmentRow`/`SegmentColumn`/`AllowVehicles`/`OccupiedIndex` shape, missing 6 of the
   master doc's 12 required fields (`RowGap`/`ColumnGap`/`SpotWidth`/`SpotLength`/
   `BaseMesh`/`ParkingIndicatorMesh`) — without spacing/dimension fields, an individual
   spot's exact resolved location/rotation cannot be computed, breaking the master
   doc's own required query surface ("where is that spot, what is its rotation").
   Bus Stop was missing 4 of 12 fields (`ShelterConfig`/`BaseMesh`/`IndicatorMesh`/
   Seat-chair config). Root cause traced up one level to
   `12-v6-activation-point-system.md`'s own `FNexusParkingActivation`/
   `FNexusBusStopActivation` lines, which were also updated, not just the phase files.
7. **New Runtime Compiler gap not previously flagged by anyone**: Phase 80 (HighwayPoint
   Export) never exported `ConnectedHighwayIds`/relationship/connectivity data, despite
   the master doc explicitly requiring "what highways connect / what objects are
   connected" runtime queries — `ConnectedHighwayIds` already exists as a derived
   Phase-18 field but was never wired into the export. Also, Phase 82 (Station Point
   Export) verified only via the Bus Stop (Phase 68) test fixture — Parking's own
   query-surface requirements were never actually exercised by that fixture.
8. **Massive-world dynamic-actor strategy (master doc Sections 24-31), assessed
   sub-point by sub-point**: actor pooling (Phase 88) was already solidly, explicitly
   covered — the strongest match of the five sub-points checked. The
   `HighwayPointTransform × OffsetTransform` unified-resolution formula was implemented
   for the dynamic-actor/AI-query side (Phase 87) but never cross-verified against the
   Static Generator's independently-baked mesh transforms (Phase 41-43) — i.e., the
   "one authoritative path, not independently-computed coordinates for each consumer"
   guarantee was asserted at the doc level but not enforced/tested anywhere. Phase 85
   ("Runtime Module Boundary")'s title suggested the Logical-Object-vs-Actor
   conceptual split but its actual content was the C++/link module boundary only.
   Configurable `MaximumActiveActors`/`PoolingEnabled`/`UpdateDistance`/
   `DeactivationRadius` were entirely absent (only `ActivationDistance` existed).
   Phase 93 ("Memory/Duplicate-Data Audit") conflated two different meanings of
   "duplication" — data-storage duplication (in scope) vs. visible-representation
   duplication, a static mesh and its dynamic-actor counterpart both rendering
   simultaneously (never in scope, despite the title inviting it).

## Changes

All documentation/spec-only, no C++ changed this pass:

- New: `project-specifications/v6-master-architecture.md` (the master doc, saved
  near-verbatim from the user's own text, formatted to this project's doc conventions).
- New: `project-specifications/phases/phase-20a.md`, `phase-40a.md`, `phase-60a.md`,
  `phase-80a.md` — the mandatory Architecture Review checkpoints (Phase 100 already
  serves as the final checkpoint per its own existing scope, so no `100a` was added).
- Modified (enhancement, no renumbering, per master doc Section 21's own rule):
  - `phase-34.md` — real distance-based LOD/AABB-impostor/full-detail-cap, porting
    `NexusFramework_V0`'s `RoadGraphEditorLOD` precedent (this session's earlier V0
    research).
  - `phase-45.md`/`phase-48.md` + `13-v6-gizmo-system.md` — generic N-sub-point/
    dynamic-array gizmo mechanism ("sub-point key" addressing via property reflection).
  - `phase-46.md` + `12-v6-activation-point-system.md` — per-instance `bAlwaysDraw`
    override, reusing the existing renderer (no second rendering path), porting V0's
    always-draw-overlay concept without needing V0's second-EdMode mechanism (V6's
    debug rendering already survives mode switches via `FTickableEditorObject`).
  - `phase-62.md`/`phase-65.md`/`phase-66.md`/`phase-79.md` — explicit per-type/
    per-array gizmo completion criteria, now that Phase 48 provides a real mechanism.
  - `phase-64.md` (Bus Stop) — ShelterConfig/BaseMesh/IndicatorMesh added.
  - `phase-69.md` (Seat) — full rewrite: `FNexusSeatActivation` with SeatType/
    SeatCapacity/Occupancy/Spacing/SeatMesh/grouping, explicit V5 `FNexusSittingSite`
    lineage note.
  - `phase-70.md`/`phase-71.md`/`phase-72.md` (Parking) — Row/Column/RowGap/ColumnGap/
    SpotWidth/SpotLength/BaseMesh/ParkingIndicatorMesh added; `Capacity` clarified as
    derived (`Row × Column`), never stored.
  - `phase-80.md` — `ConnectedHighwayIds` export added.
  - `phase-82.md` — separate Parking-fixture round-trip test added.
  - `phase-85.md` — explicit Logical-World-Object-vs-Actor design contract added
    alongside the existing C++ module-boundary scope.
  - `phase-87.md` — cross-check completion criterion: dynamic-actor transform must
    match the Static Generator's baked transform for the same object.
  - `phase-88.md` — `DeactivationRadius` (hysteresis), `MaximumActiveActors`,
    `PoolingEnabled`, `UpdateDistance` added.
  - `phase-89.md` — clarified `ActivationDistance` = master doc's `ActivationRadius`
    (same field, not a duplicate); cross-referenced against Phase 88's new fields.
  - `phase-92.md` — explicit "prove `MaximumActiveActors` holds under worst-case
    density" test added, distinct from frame-time profiling.
  - `phase-93.md` — visible-representation duplication (Section 28) added as a
    distinct, separately-tracked audit category alongside data-storage duplication.
  - `12-v6-activation-point-system.md` — `FNexusActivationPoint` base struct gained
    `bAlwaysDraw`; `FNexusSeatActivation`/`FNexusBusStopActivation`/
    `FNexusParkingActivation` lines updated to match the phase-level field additions
    above.
- `project-specifications/README.md` — `v6-master-architecture.md` added to the doc
  index and to "Reading order for a fresh session/agent" (position 3, after
  `AGENT-RULES.md`).
- `CLAUDE.md` — new "Related: master architecture" section pointing at the doc.

## Verification

- No C++ changed — no build required this pass.
- `node html-docs/build.js` — regenerated cleanly, 108 phases (104 + the 4 new
  checkpoint files), `PHASE-STATUS.md`/`phase-data.js`/`phase-tracker.html` all
  rewritten successfully.
- **No automated test run/added** — per `AGENT-RULES.md`'s Agent Testing Policy (N/A
  anyway, this pass touched zero C++).

## Result

`v6-master-architecture.md` is now the top-level architecture authority for V6, above
`v6-phase-verification.md` and the numbered `04`-`14` docs. Every phase from 34 through
93 that the 3-agent audit found genuinely gapped against it has been enhanced in place
(never renumbered) with concrete, evidence-based fixes — not just flagged. Two
already-known gaps (Seat's internal conflict, the gizmo system's single-offset
limitation) turned out to be the most severe findings and are now fully corrected at
both the phase-file and design-doc (`12`/`13`) level. Four mandatory checkpoint phases
(20a/40a/60a/80a) record what was reviewed, what was fixed, and what remains open
(mostly soft/systemic wording gaps in Debug Visualization phases, deferred as
lower-severity).

## Important Notes

- This was a documentation/spec-only pass — none of the enhanced phases have been
  implemented yet (all remain `Not started`). The fixes change what a future
  implementation pass must build, not anything already built.
- Two items were explicitly left open rather than fixed, per this project's own
  "don't silently resolve, flag for the user" convention: (1) Debug Visualization
  phases' generic "wireframe primitives only" wording never explicitly commits to
  dimensional/shape accuracy (Section 9) — a systemic, low-severity wording gap across
  53/57/62/67/71, not fixed this pass; (2) Services/Facilities (Hospital/Police/etc.)
  remains architecturally thinner than Transportation/Infrastructure even after Phase
  75's own 2026-08-09 fix (all five types share one generic proof phase, vs. 3-6
  dedicated phases per Transportation/Infrastructure type) — recorded as an accepted
  v1 scope boundary, not silently resolved either way, per Phase 75's own existing
  "if a type needs a framework change, report it, don't route around it" language.
- Concurrent-session activity was observed throughout this work (see this session's
  earlier flagging in conversation) — before starting any fix, each target phase file
  was freshly re-read to confirm it hadn't already been changed by that other process,
  to avoid stomping on or duplicating work in progress elsewhere in the same repo.
