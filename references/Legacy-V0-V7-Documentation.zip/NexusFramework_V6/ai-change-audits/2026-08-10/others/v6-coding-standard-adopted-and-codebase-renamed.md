# V6 C++ coding standard adopted; entire existing codebase brought into compliance

Date: 2026-08-10
Category: others (standing project policy + a project-wide mechanical rename)
Phase: N/A (explicitly not a phase per the user's own instruction — a cross-cutting
standard, not roadmap content; no phase renumbered, including Phase 30)

## Context

User provided a full C++ naming standard (PascalCase types/members/functions with an
`Is/Has/Can/Should/Was/Were` boolean prefix replacing Epic's own `b`-prefix convention;
camelCase parameters/locals including `const`/`static`/`constexpr`; `MAX_RETRY_COUNT`-style
global constants; `_BUILD_COUNT`-style static globals) and asked for it to be (1) saved
as a Git-tracked doc, (2) wired into agent-instruction reading order, (3) applied to the
entire existing V6 C++ codebase immediately, safely (no behavior change), with a
post-refactor build verification and a full report.

## Findings

1. **Saved as `project-specifications/v6-coding-standard.md`**, cross-referenced from
   `AGENT-RULES.md` (same standing weight as the Agent Testing Policy) and `CLAUDE.md`,
   and added to `README.md`'s doc index.
2. **Real serialization risk found before touching any code**: this project already has
   two saved `.uasset` files on disk (`Content/NexusConfigs/
   06AD7994490783B500BC81A27A951F63_nexusconfig.uasset`, `Content/NF/Maps/
   LV0_Development1/NexusConfig.uasset`) containing `UNexusConfigAsset` data, which
   transitively includes `UPROPERTY` boolean fields on `FNexusHighway`
   (`bIsClosedLoop`/`bIsInterCityHighway`) and `FNexusDebugRenderConfig`
   (`bVisible`/`bWireframe`/`bShowLabel`/`bSelectable`/`bSupportsGizmo`, reached via
   `UNexusConfigAsset::DebugCategoryConfigs`). A bare rename of any of these would
   silently drop that field's saved value on next load (UE matches serialized
   properties by name) — flagged to the user before proceeding, per this project's own
   "hard to reverse, ask first" convention and the user's own "no behavior change" rule.
3. **User chose CoreRedirects** (over skipping persisted booleans or accepting data
   loss) — added a `[CoreRedirects]` section to `Config/DefaultEngine.ini` with 7
   `PropertyRedirects` entries mapping every renamed persisted boolean to its new name,
   so the two existing saved assets still load correctly.
4. **Full-codebase scan and refactor via 4 parallel agents**, split by directory
   (`Debug/`; `Mapping/`+`Generation/`+`Inheritance/`; `Reader/`+`Representation/`;
   `UI/`+`Subsystem/`+`Tests/`+module roots), each given the coding standard doc plus a
   fixed rename table for the 10 boolean members that cross file/module boundaries, so
   references stayed consistent regardless of which batch owned the declaration.
5. **Both modules built clean on the first attempt** after all 4 batches landed —
   `NexusFrameworkEditor` (42 actions, 0 errors) and `NexusFramework` (11 actions, 0
   errors, first build of that module this session). Post-refactor greps for any
   remaining `bool bXxx`-style member and any remaining PascalCase range-`for` loop
   variable across the whole `Source/` tree came back empty.

## Changes

- New: `project-specifications/v6-coding-standard.md`.
- `project-specifications/AGENT-RULES.md` — new "C++ Coding Standard" section,
  same-priority footing as the Agent Testing Policy.
- `project-specifications/README.md` — doc index entry.
- `CLAUDE.md` — new "Related: C++ coding standard" section.
- `Config/DefaultEngine.ini` — new `[CoreRedirects]` section, 7 `PropertyRedirects`.
- 61 `Source/` files renamed in place (see `git status` for the exact list — every
  `.h`/`.cpp` under `NexusFrameworkEditor`'s `Debug/`, `Mapping/`, `Generation/`,
  `Inheritance/`, `Reader/`, `Representation/`, `Subsystem/`, `UI/`, `Tests/` folders,
  both module root files, and `NexusFramework`'s own root files where applicable):
  every function parameter and local variable (including `const`/`static`/`constexpr`
  locals, range-based-for variables, lambda parameters/captures, structured bindings)
  renamed PascalCase → camelCase; every boolean class/struct member renamed from
  Epic's `b`-prefix to an `Is/Has/Can/Should/Was/Were` semantic prefix.
- Boolean members renamed (10 total, all cross-file, applied consistently by every
  batch): `bIsClosedLoop`→`IsClosedLoop`, `bIsInterCityHighway`→`IsInterCityHighway`
  (both `FNexusHighway`, persisted, redirected), `bVisible`→`IsVisible`,
  `bWireframe`→`IsWireframe`, `bShowLabel`→`ShouldShowLabel`,
  `bSelectable`→`IsSelectable`, `bSupportsGizmo`→`CanSupportGizmo` (all
  `FNexusDebugRenderConfig`, persisted, redirected), `bHasWorldLocation`→
  `HasWorldLocation` (4 independent plain-struct fields of the same name across
  `Reader`/`Mapping`/`Representation`/`Debug`, not persisted, no redirect needed),
  `bResolved`→`IsResolved` (`FNexusDebugSnapshotPoint`, transient cache, not
  persisted), `bDetailsViewShowsDebugCategory`→`IsDetailsViewShowingDebugCategory`
  (`SNexusFrameworkPanel`, plain widget member, not persisted).

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject`
  — **Result: Succeeded**, 42 actions, 0 errors.
- `Build.bat NexusFramework Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, 11 actions, 0 errors (this module's own first build this
  session).
- Post-refactor repo-wide greps: zero remaining `bool b[A-Z]\w*(;|=)` matches; zero
  remaining PascalCase range-`for` loop variables in any `.cpp` file.
- **No automated test run/added** — per `AGENT-RULES.md`'s Agent Testing Policy. The
  4 existing `Tests/*.cpp` files had their own local variables/parameters renamed for
  consistency (pure rename, same policy applies — not executed).

## Result

Every `.h`/`.cpp` file under both V6 modules now conforms to `v6-coding-standard.md`.
No phase was created or renumbered. The two already-saved `.uasset` files will load
correctly under the new property names via the added `CoreRedirects`. Both modules
compile clean.

## Important Notes

- **Local boolean naming was not always forced into exactly one of the six prefixes.**
  The written standard's strict `Is/Has/Can/Should/Was/Were` requirement is stated
  under the PascalCase members/functions section; for camelCase locals specifically,
  agents were instructed to prefer a natural semantic-prefix reading
  (`bSucceeded`→`succeeded` or `wasSuccessful`) but allowed to fall back to a plain
  camelCase name where forcing a prefix would read awkwardly (`bOwnsAsPrimary`→
  `ownsAsPrimary`, `bChanged`→`changed`). This is an interpretation, not something the
  user's own text stated explicitly either way — flagged here for correction if a
  stricter reading was intended.
- **Engine-owned types were correctly left untouched** — e.g. `FDetailsViewArgs::
  bAllowSearch`/`bShowScrollBar` (an Unreal Engine struct, not a V6 type) keep their
  original names; only the local variable holding an instance of it was renamed.
- **Case-only shadowing between a renamed local/parameter and a same-named PascalCase
  member is intentional**, not a residual bug — e.g. a `highwayId` parameter next to a
  `HighwayId` member disambiguates by case alone, per the standard's own two-tier
  convention.
- If any other `.uasset` files exist outside `Content/NexusConfigs/` and
  `Content/NF/Maps/LV0_Development1/` that were not found by this session's search,
  they were not specifically checked against the `CoreRedirects` list — worth a quick
  Content Browser scan next time the editor is open.
