# V6 Editor Production Architecture Audit (Debug/Gizmo/Validation/Preview/Demo)

Date: 2026-08-10
Category: others (architecture audit, no phase renumbering)
Phase: N/A (cross-cutting, per the source doc's own "audit existing phases, do not
renumber" instruction)

## Context

User provided `v6-editor-production-audit-spec.md` (saved verbatim, see that file) mid-
session, immediately after this session's own Debug Performance / Static Generator work
(Phases 33-35, 40a, 41, 41a, 42). Asked for a gap audit against the current roadmap,
scoped strictly to Editor/authoring/debug/gizmo/validation/preview/compiled-data-prep
(explicitly NOT runtime gameplay).

**Budget constraint on this pass**: run under severe remaining context budget. This audit
relies on this session's own accumulated knowledge of the roadmap (phases read/enhanced
earlier in this same session - Debug LOD, gizmo sub-point addressing, Parking/Bus
Stop/Seat field specs, Activation Point structure, validation entry patterns) rather than
a fresh full re-read of all 100 phase files. Findings below are flagged by confidence
level; anything not directly re-verified this pass is marked as such rather than stated
as fact.

## Findings

### Strong / already covered (high confidence - implemented and verified this session or the earlier same-day master-architecture pass)

- Distance-based LOD, closest-point-to-AABB distance, AABB/impostor fallback, full-detail
  cap, distance ranking, radius filtering — Phase 34, implemented and built this session
  (`FNexusDebugLOD`). Frustum filtering specifically was NOT implemented (only radius) -
  see Gaps below.
- Gizmo generic sub-point addressing (single/multiple fixed/dynamic N-array/nested) —
  `13-v6-gizmo-system.md`'s "Sub-point addressing" section, added earlier this session
  (`(FieldName, OptionalArrayIndex)` key).
- Accurate Parking preview fields (Row/Column/SpotWidth/SpotLength/RowGap/ColumnGap,
  Free/occupied, Indicator) — `phase-70.md`, full rewrite earlier this session.
- Bus Stop (Shelter/BaseMesh/IndicatorMesh) and Seat (`FNexusSeatActivation`) field specs
  — `phase-64.md`/`phase-69.md`, full rewrites earlier this session.
- Debug config fields (IsVisible/Color/LineThickness/ShouldShowLabel/LabelFontSize) —
  `FNexusDebugRenderConfig`, implemented since Phase 25. `PointSize`/`TextColor` as
  distinct fields are NOT present (LineThickness/Color are reused) - minor gap, see below.
- Click-validation-issue → focus-in-viewport — Phase 27's Diagnostics panel, implemented.
- Always-Draw per-instance override — documented as Phase 46's scope
  (`bAlwaysDraw` on the base `FNexusActivationPoint` struct, added earlier this session);
  not yet implemented in code (Phase 46 itself is `Not started`).

### Partial / needs enhancement (medium confidence - structure exists, doesn't fully match the new doc's ask)

- **Validation severity model**: current code (`FNexusRepresentationValidationEntry`,
  `FNexusMappingValidationEntry`, etc.) is a 2-tier `Warning`/`Blocking` enum throughout
  the codebase, confirmed multiple times this session (Phase 22, Phase 44 draft). The new
  doc asks for 4 tiers: `Info`/`Warning`/`Error`/`Blocking`. Every existing
  validation-stage phase (14, 22, 38, 39, plus the Phase 44 draft this session started)
  would need its severity enum widened - a real, cross-cutting enhancement, not a new
  phase.
- **`FinalTransform = Anchor × GeneratedOffset × ManualOffset`**: the current
  `FNexusActivationPoint` base struct (`12-v6-activation-point-system.md`) composes
  `FinalTransform = HighwayPointTransform × OffsetTransform` - ONE offset, authored
  by the user via gizmo. There is no separate procedural `GeneratedOffset` distinct from
  the user's `ManualOffset` anywhere in the current architecture. This matters
  specifically for regenerable object types (Rule-Based/Decorative per the new doc's own
  generation-strategy taxonomy) where a user's manual gizmo correction must survive a
  regeneration pass - today's single-offset model cannot distinguish "the algorithm put
  it here" from "the user moved it here," so a regenerate would silently clobber manual
  work. This is the single most consequential gap found.
- **Per-object-type generation strategy (Sequential/Rule-Based/Decorative) with
  MinGap/MaxGap/MinDistance/MaxDistance/Probability/Priority/RandomSeed**: nothing in the
  current Static Generator arc (Phases 40-44, this session's own work) or in
  `11-v6-static-dynamic-architecture.md` models a randomized/rule-based placement pass at
  all - the classification table (Phase 40) decides Static/Instanced/RuntimeActivated per
  object TYPE, not how many instances to place or where. Decorative object types
  (Trash Can/Trash/Dust/Debris/small props) aren't even in Phase 40's 16-row starting
  table. This is a real, unimplemented generation capability, not just a missing field.

### Missing (high confidence - not found anywhere in the roadmap this session has touched or read)

- **Editor Demo/Test Systems (Demo Vehicle, Demo Character)** - no phase in the 00-99
  roadmap covers a lightweight editor-only agent that drives/walks generated data to
  prove spatial correctness. This is new scope, not a gap in an existing phase.
- **Explicit Transform-Parity test** (Debug view == Gizmo result == Preview == Final mesh
  == Compiled data == Demo target, all provably equal) - the project's underlying
  philosophy (Landscape as live source of truth, never cache) supports this being true
  by construction for Representation-stage reads, but nothing formalizes it as a checked
  invariant spanning all the way to compiled Runtime Schema output and a Demo agent's own
  target resolution. No test fixture or phase currently asserts this end-to-end.
- **Dedicated per-system test fixtures** (separate synthetic maps for Parking vs. Bus
  Stop vs. Seat vs. Traffic Light etc.) - existing phases each reference "a synthetic
  test map" generically (singular, reused) rather than mandating system-specific
  fixtures. Not confirmed as a fully missing capability (may be implicit in how a user
  actually tests) but not explicitly required by any phase text read this session.

## Architecture gaps requiring user input

Per the source doc's own "Architecture Gap Rule" - not silently invented:

1. **GeneratedOffset vs ManualOffset split** - Missing: a second offset transform on
   `FNexusActivationPoint` (or wherever offsets live) distinguishing procedural placement
   from user correction. Why it matters: without it, any future "regenerate this object
   type" action risks destroying manual gizmo work with no way to detect/preserve it.
   Affected: every Rule-Based/Decorative object type (Bus Stop, Parking, Seats, Ads/TV,
   decorative props) - Sequential types (City Light, Electricity Pole) may not need this
   split if they're never auto-regenerated after initial placement. Recommended options:
   (a) add `GeneratedOffset`+`ManualOffset` as two separate fields, compose at read time,
   with a "manual override present" flag a regenerate must check before overwriting; (b)
   keep one offset field but add an `IsManuallyOverridden` bool that blocks
   regeneration from touching that instance at all. Question: which model, and does it
   apply to ALL Activation Point types uniformly or only regenerable ones?
2. **Editor Demo/Test Systems scope** - Missing: no phase currently owns this. Why it
   matters: it's explicitly called out as this doc's own verification mechanism for
   "is the generated data actually usable," and per the doc's Critical Transform-Parity
   Test, it's the end-to-end check nothing else covers. Affected: cuts across Traffic
   Light, Parking, Bus Stop, Seat, Crosswalk phases (61-75 range). Recommended options:
   (a) insert new phase(s) in the 76-79 (Gizmo) or a new post-84 (post-Runtime-Compiler)
   window, since a Demo Vehicle/Character needs COMPILED data to navigate, not just
   Representation data; (b) scope it smaller - an editor-only debug-draw "predicted path"
   rather than an actual moving/ticking demo actor. Question: how much editor-simulation
   fidelity do you actually want here (a moving pawn with real movement code, vs. a
   static "here's where it would go" debug overlay)?
3. **Decorative/random object generation model** - Missing: MinGap/MaxGap/Probability/
   RandomSeed placement algorithm and where Trash/Dust/Debris/props fit in the
   classification table. Why it matters: without a seed/determinism rule, regenerating
   decorative props would produce different results each time, breaking the idempotency
   rule every other Generation-stage phase this session enforced. Affected: Phase 40's
   classification table (needs new object-type rows), a new Generation-stage phase.
   Question: is decorative-prop density/placement in scope for the NEAR-term roadmap, or
   a later addition once the core object types (Traffic Light through Facilities) are
   done?

## Result

Overall assessment: the user's own "60-80% already done" estimate reads as accurate
based on this pass - the Debug/LOD/gizmo-addressing/per-object-field-spec foundations
requested by this doc were already built (mostly earlier the same day, some this
session). The real gaps cluster into three areas, all flagged above rather than silently
patched: the generated/manual offset split, the Demo Vehicle/Character system, and the
decorative/randomized generation model. None of these were implemented this pass -
budget did not allow it, and two of the three are genuine product decisions per the
doc's own Architecture Gap Rule, not something to guess at.

## Important Notes

- **No phase files were modified or renumbered in this pass** - this is a documentation-
  only audit record plus the saved reference doc. Enhancing phase-70/64/69/12-etc. for
  the GeneratedOffset/ManualOffset split, or inserting new phases for Demo Vehicle/
  Character and decorative generation, is future work pending the user's answers to the
  three gaps above.
- **Validation severity widening (2-tier to 4-tier) was identified but not applied** -
  touches every validation-stage phase (14, 22, 38, 39, 44) - a real, moderate-sized
  cross-cutting change, deferred pending budget/explicit go-ahead rather than rushed.
- This audit did not re-verify every one of the 100 phase files individually (budget
  constraint, stated up front) - confidence levels are marked per finding; a future full
  pass (mirroring the earlier `v6-master-architecture-and-phase-alignment-audit.md`'s own
  thoroughness) would be needed before treating the "Missing" section as exhaustive.
