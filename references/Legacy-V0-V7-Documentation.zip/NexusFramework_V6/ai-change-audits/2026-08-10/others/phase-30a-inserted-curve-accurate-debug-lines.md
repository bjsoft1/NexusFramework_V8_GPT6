# Phase 30a inserted — Debug Rendering, Curve-Accurate Segment/Offset Lines

Date: 2026-08-10
Category: others (new-phase insertion, tracking only — not implemented this round)

## Context

Same user report as `bug-fixed/debug-render-landscape-space-not-world-space.md` (fixed
same day): after that fix landed, the debug points/spheres correctly sit on the real
Landscape geometry, but the CONNECTING debug line between two points is still a straight
line — the user's own words: "the segment joined line not flow with the landscape
segment tengent arc... this feature has in V5." Per the user's own standing instruction
from earlier this session ("let search if this features not has in upcoming TODO or your
compled todo then add new phase after this phase... [improve/update requirement]... this
will help we does not break any index for others"), searched first before adding
anything.

## Findings

- Both renderers that draw a line along a segment already document straight-line
  drawing as a **deliberate, explicit** Phase 30/31 scope decision, not an oversight —
  Phase 30's own Completion Criteria literally says "Segments traces the polyline";
  Phase 31's `DrawOffsetPolyline` comment says "A straight-per-segment approximation
  (not curve-following)... debug wireframe, not final mesh generation." Neither phase,
  nor `06-v6-debug-system.md`, ever asked for curve accuracy.
- The reason it can't already be curve-accurate: `FNexusDebugSnapshotPoint` only carries
  a tangent DIRECTION (no length) — by the Representation stage's own explicit design
  (`FNexusHighwayPoint`'s header comment: "there is no single meaningful tangent length
  for a point in isolation, only a direction... a per-segment-connection value"). Real
  per-segment tangent length data already exists at the Source stage
  (`FNexusSegmentEndpointRead::TangentVector`, Phase 06) but was never threaded through
  to the Debug snapshot.
- This is genuinely new scope (a real curve-sampling feature spanning Source-stage data
  threading + new shared Hermite-sampling math + two renderer files), not a same-day
  bug-fix revision — inserted as its own phase rather than folded into today's location
  fix.

## Decision

Inserted `project-specifications/phases/phase-30a.md` — "Phase 30a — Debug Rendering —
Curve-Accurate Segment/Offset Lines [improve/update requirement]", `Status: Not
started.` — immediately after Phase 30 (the more directly-referenced phase in the user's
own report: "landscape segment... landscape segment center"), with a cross-reference
also added to Phase 31 (`Roads.Highways`/`Lanes`/`Sidewalks` share the exact same
straight-line limitation via the same `DrawOffsetPolyline` helper). No existing phase
file's numbering changed. `html-docs/build.js`'s title-parsing regex already tolerates
letter-suffixed phase numbers (fixed earlier today for Phase 41a) — regenerated cleanly,
103 phases now tracked.

Not implemented this round — tracking only, per the same standing instruction that
produced Phase 41a earlier today.

## Result

`project-specifications/phases/phase-30a.md` exists, `Not started`, cross-referenced
from both Phase 30 and Phase 31's own References sections.
