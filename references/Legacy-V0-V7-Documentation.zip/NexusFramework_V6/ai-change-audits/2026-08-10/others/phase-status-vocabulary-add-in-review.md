# Phase status vocabulary — added "In Review"

Date: 2026-08-10
Category: others (project convention change, docs tooling — not a roadmap phase)

## Context

User had already started this themselves: `html-docs/js/phase-tracker.js` had a
git-staged, uncommitted edit adding `"in-review"`/`"In Review"` to its dropdown
`STATUS_OPTIONS`, `statusLabel`, and `badgeClass` — but nothing else in the toolchain
knew about it yet. Opened that file and asked to "add state In Review." Asked the user
where it should sit in the transition order before touching the authoritative rule
(`09-development-rules.md` rule 12) and its three consuming files; user chose: between
`Ready for Review` and `Ready for QA` — marking "the user is actively code-reviewing
this phase right now," distinct from just sitting queued.

## Problem / Goal

`09-development-rules.md` rule 12 still documented only 6 status values. Without
updating the rest of the toolchain, clicking "In Review" in the (already-edited)
dropdown would have round-tripped to `server.js` and failed with a 400 ("Unknown
status") — `server.js`'s `ALLOWED_STATUSES` whitelist is the actual enforcement point,
and it didn't have the new value yet.

## Changes

- `project-specifications/09-development-rules.md` rule 12 — added `In Review` to the
  vocabulary table (between `Ready for Review` and `Ready for QA`, "user only," "seven
  values" not six); noted it sits past the agent's `Ready for Review` boundary same as
  `Ready for QA`/`Complete`.
- `html-docs/server.js` — added `'In Review'` to `ALLOWED_STATUSES` (the actual
  enforcement whitelist `setPhaseStatus` checks - this was the one change that mattered
  functionally; everything else is display/discoverability). Deliberately NOT added to
  `UI_BLOCKED_STATUSES` - `In Review` is user-settable via the dropdown/API, same as
  `Ready for QA`/`Complete`/`Blocked`.
- `html-docs/build.js` — `classifyStatus()` now recognizes `"in review"` ->
  `'in-review'`; `buildPhaseTrackerPage()`'s filter-button row gained an "In Review"
  button (`data-filter="in-review"`).
- `html-docs/css/site.css` — new `--badge-review-bg`/`--badge-review-text` CSS variables
  in all three palette blocks (light `:root`, `:root[data-theme="dark"]`, and the
  `@media (prefers-color-scheme: dark)` block that mirrors it) plus a `.badge-review`
  rule - teal, distinct from every existing badge color (green=Complete, blue=Ready for
  Review, purple=Ready for QA, orange=In progress, red=Blocked, grey=Not started).
  `phase-tracker.js`'s already-staged `badgeClass()` edit maps `"in-review"` ->
  `"badge-review"`, which these variables/rule now back.
- `html-docs/README.md` — updated "six values" -> "seven values"; added `In Review` to
  the "convention-only, not technically enforced against the agent" sentence (nothing
  stops an agent from calling the API with `In Review` either, same as `Ready for QA`/
  `Complete` - this boundary relies on the agent following rule 12, not a technical
  block).
- `node html-docs/build.js` re-run — 102 phases, output clean.

## Verification

- `node -c html-docs/server.js`, `node -c html-docs/build.js`,
  `node -c html-docs/js/phase-tracker.js` — all syntax-clean.
- Did **not** live-round-trip test the API against a real phase file - rule 12 itself
  says to prefer reading the code over live status-toggling when verifying the status
  system, so relied on code review (the whitelist array literally contains the new
  string now) plus the syntax checks above.
- No C++ changes in this entry - Node/Markdown/CSS tooling only, nothing to `Build.bat`.

## Result

`In Review` is now a real, fully-wired status: selectable from the phase-tracker
dropdown, accepted by `server.js`'s API, recognized by `build.js`'s classifier/filter
bar, styled with its own teal badge, and documented as the authoritative vocabulary in
rule 12. Slots between `Ready for Review` and `Ready for QA`, user-only (same boundary
as `Ready for QA`/`Complete` - an agent may reach `Ready for Review` and no further).

## Important Notes

- The user's own `phase-tracker.js` edit (already git-staged before this session's
  changes) was left exactly as they wrote it - not modified, only built upon.
- No existing phase file's `## Status` was changed to `In Review` as part of this work -
  this only adds the CAPABILITY; deciding which currently-`Ready for QA`/`Ready for
  Review` phases should move to `In Review` is the user's own call, same as every other
  status transition.
