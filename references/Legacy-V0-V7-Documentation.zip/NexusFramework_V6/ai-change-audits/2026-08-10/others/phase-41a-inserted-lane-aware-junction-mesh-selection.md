# Phase 41a inserted — Junction Mesh Selection (Lane-Aware)

Date: 2026-08-10
Category: others (roadmap/architecture decision, not an implementation)
Phase: phases/36, phases/37, phases/41, phases/41a (new)

## Context

Immediately after the Phase 36/37 revision (porting V5's full `ENexusNodeType`
classification, see this same day's
`ai-change-audits/2026-08-10/feature-add/phase-36-37-highwaypoint-junction-and-lanes.md`
appended Revision section), the user asked a forward-looking question: does the V6
roadmap anywhere account for junction MESH selection that depends on the LANE COUNTS of
the connecting Highways, not just junction topology? Their concrete example: a 4-lane
Highway meeting a 2-lane Highway must place an asymmetric junction mesh (4-lane
continues straight, 2-lane merges in as the T's base), never a symmetric same-size
piece (2x2 or 4x4) - placing the wrong piece there is a real, visible bad-design defect,
not a cosmetic nitpick. The user explicitly asked me to search both the completed and
upcoming phases for this, and if it's missing, add a new phase for it without
renumbering anything already planned - "so this will help we does not break any index
for others."

## Problem / Goal

Determine whether lane-count-aware junction mesh selection is already covered anywhere
in the 100-phase roadmap; if not, insert a new tracked phase for it, following the
project's own numbering-stability constraint (phase identity is a fixed, numbered file
path other docs cross-reference - `CLAUDE.md`).

## Findings

1. **The user's quoted reference enums are not new/external information - they're
   already this project's own documented V5 precedent.** `project-specifications/
   v5-complete-reference.md` (lines ~659-682) documents `ENexusPointDescription`'s
   Highway-geometry band exactly matching what the user pasted: `Highway_Straight=1,
   Highway_Curve=2, Highway_T_Junction=3` (same-lane T), `Highway_6_4_T_Junction=4`,
   `Highway_6_2_T_Junction=5`, `Highway_4_2_T_Junction=6`, `Highway_Cross_Junction=7`
   (same-lane cross) - each already a lane-combination-specific value, not merely
   topological. The same doc also explicitly records the user's quoted `EHighwayLanes`
   (HumanWalk/OneLane_LeftEntry/OneLane_RightEntry/TwoLane/FourLane/SixLane) as "an
   earlier concept from early design notes", superseded by `ENexusLaneConfiguration`
   (TwoLanes/FourLanes/SixLanes/EightLanes/TenLanes/OneWayLeftLane/OneWayRightLane/
   HumanWalk). Both pieces of the user's message were already carried into this
   project's own V5 reference doc before this conversation - confirms the user is
   recalling a real, already-catalogued system, not proposing something untested.
2. **No V6 phase currently covers this.** Searched every phase file for
   `PointDescription`/`PointTarget`/`mesh selection`/`junction mesh`/`LaneConfiguration`/
   `Static Generator` - Phase 40 ("Classification Tagging") covers a DIFFERENT axis
   (Static/Instanced/Merged generation-classification, not junction geometry). Phase 41
   ("Mesh Merge Pipeline") is explicitly scoped to "Highway road surfaces" and
   "Sidewalks" only - no mention of junction-piece selection. Their shared reference doc
   `11-v6-static-dynamic-architecture.md` mentions junctions exactly once, in passing,
   about traffic-light pole placement - not mesh selection. This is a genuine, confirmed
   gap, not a phase whose scope already implicitly covers it.
3. **This is Generation-stage work, not a Phase 36/37 revision.** Junction mesh
   selection is squarely "which mesh piece to place," i.e. Generation - both Phase
   36/37's own Not Allowed lists ("do not perform generation from this stage") forbid
   this from living there. It belongs in the Static Generator arc (Phase 40+), as a new
   phase consuming Phase 36's `ENexusJunctionType` + Phase 37's per-Highway `LaneCount`
   as inputs.
4. **No existing letter-suffix phase-file precedent existed before this** - every one of
   phase-00 through phase-100 was already a plain numbered file. Verified `html-docs/
   build.js`'s phase-file discovery regex (`/^phase-\d{2,3}.*\.md$/`) already tolerates a
   trailing letter in the FILENAME (matches `phase-41a.md` as-is, no change needed), but
   the phase-title-line regex (`/^#\s+Phase\s+(\d+)\s+—\s+(.*)$/`) required whitespace
   immediately after the digits, so a header literally written as "# Phase 41a — ..."
   would have failed to extract its title and silently rendered as "TBD" in the
   generated docs/tracker. Fixed with a minimal, backward-compatible regex tweak
   (`(\d+)` -> `(\d+[a-z]?)`, both em-dash and hyphen variants) - `parseInt("41a", 10)`
   already equalled 41 either way, so only the TITLE extraction needed the fix, not the
   numeric sort/grouping. Verified after the fix: `node html-docs/build.js` now lists
   "Phase 41 — Static Generator — Junction Mesh Selection (Lane-Aware)
   [improve/update requirement]" correctly (not "TBD") in `PHASE-STATUS.md`, sorted
   immediately after Phase 41's own row and before Phase 42.

## Changes

- `html-docs/build.js` — `extractPhases()`'s title-line regex now accepts an optional
  trailing lowercase letter after the phase number (Finding #4).
- New `project-specifications/phases/phase-41a.md` — "Static Generator — Junction Mesh
  Selection (Lane-Aware) [improve/update requirement]", Status `Not started.`, full
  Objective/Context/Allowed/Not Allowed/Completion Criteria/References following the
  existing phase-file template. Not implemented - this is a roadmap addition only, per
  the user's explicit ask ("for reference"), not a request to build it now.
- `project-specifications/phases/phase-41.md` — added a one-line cross-reference in its
  own References section pointing to phase-41a, so a future reader of Phase 41 discovers
  the sibling phase without needing to already know it exists.
- `node html-docs/build.js` re-run — 102 phases now listed (was 101), `PHASE-STATUS.md`/
  `phase-tracker.html`/`js/phase-data.js` regenerated.

## Verification

- Confirmed via direct grep of `PHASE-STATUS.md` after rebuild: Phase 41a's row shows
  its real title (not "TBD") and sorts correctly between Phase 41 and Phase 42.
- No C++ changes in this entry - nothing to `Build.bat` here (this record was
  Node/Markdown tooling + planning docs only, not editor-module code).

## Result

Confirmed the lane-aware junction mesh selection feature was a genuine gap in the
existing roadmap (not already covered, not something Phase 36/37/40/41 implicitly
handled), and added `phase-41a.md` to track it without disturbing any existing phase's
number. Not implemented - a `Not started.` phase file only, ready to be picked up like
any other roadmap phase once its prerequisites (Phase 36 revision, Phase 37, and
presumably Phase 40/41 themselves) are further along.

## Important Notes

- This phase's own Completion Criteria call for an explicit tie-break rule for
  equal-lane-count 3+-way junctions - deliberately left unresolved in the phase file
  itself (a design decision for whoever implements it, not something to pre-decide
  while just adding the tracking phase).
- Actual mesh ASSET wiring is explicitly out of this phase's scope (Not Allowed list) -
  it only needs to prove the SELECTION KEY logic is correct; wiring real mesh assets
  follows Phase 41's own existing mesh-asset-set precedent.
