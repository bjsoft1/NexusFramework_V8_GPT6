# Research: editor shutdown crash after phase 41-46 work — hypothesis: Live Coding + new reflected types

Date: 2026-08-10
Category: research
Phase: cross-cutting — implicates Phase 41/41a/42/45/46 (all the reflected types added
this session), no single phase's own logic is at fault.

## Context

`agent-todos/` task `engine-crash-after-adding-new-phase-development-phase-43-49.md` —
the user dropped a raw Unreal Engine crash log (no other description) into
`ready-for-development/` after working through the Static Generator / Activation Point
phase cluster this session. Full investigation write-up lives in the task file itself
(`agent-todos/ready-for-review/engine-crash-after-adding-new-phase-development-phase-43-49.md`);
this record is the durable, project-memory copy of the same finding per `CLAUDE.md`.

## Finding

The crash is a null-deref inside `FRenderResourceList::ForEachReverse` during
`FRenderResource::ReleaseRHIForAllResources()`, called from `RHIExit()` during editor
shutdown (`FEngineLoop::Exit()`) — i.e. the engine's final teardown of every still-
registered render resource. A null/dangling node in that list means some
`FRenderResource` was `InitResource()`'d but never cleanly `ReleaseResource()`'d before
its owning memory was freed. **The callstack is 100% engine-internal frames** (RenderCore/
D3D12RHI/RHI/Launch) — no Nexus code appears anywhere in it, so the crash site itself
cannot name which system is responsible.

Audited every render-resource-touching line of code added this session
(`FNexusStaticGenerator::BuildStaticMeshAsset`'s `UStaticMesh::Build()` call,
`FNexusInstancingGenerator::FindOrCreateInstanceComponent`'s `NewObject` +
`RegisterComponent()` + `AddInstanceComponent()`) — both are standard, engine-blessed
editor-time APIs, not hand-rolled render-resource management. A project-wide grep for
`FRenderResource`/`FVertexBuffer`/`FIndexBuffer`/`BeginInitResource`/manual
`DestroyActor`/`DestroyComponent` on Generation-owned objects found nothing — there is no
place in the project where a render resource's owning object is torn down outside the
engine's own GC/BeginDestroy flow.

**Working hypothesis (not experimentally confirmed):** this exact phase range added
several **brand-new reflected types** in one sitting — a new `UCLASS`
(`ANexusGeneratedInstancedMeshHost`), new `USTRUCT`s (`FNexusDummyBaseOnlyActivationPayload`,
`FNexusDummyArrayActivationPayload`, `FNexusSubPointOffset`), and new `UPROPERTY` members
on existing structs (`NexusActivationPoint::IsAlwaysDraw`,
`FNexusDebugCategory::SupportsAlwaysDraw`) — and per this session's own build history, at
least one of these was compiled via **Live Coding (Ctrl+Alt+F11) inside the already-
running editor** rather than a full restart, because `Build.bat` repeatedly hit "Unable
to build while Live Coding is active." Live Coding reliably hot-patches existing
function bodies, but Epic's own documented limitation is that adding **new**
`UCLASS`/`USTRUCT`/`UENUM` types or new `UPROPERTY`/`UFUNCTION` members to a type the
running editor already loaded is not fully supported — the reflection system (UClass/
UScriptStruct construction, CDO creation, GC token stream generation, which is also what
downstream systems use to know which members carry render/GC-relevant resources) isn't
rebuilt the same way a cold process start does it. This is consistent with a render
resource silently falling out of proper teardown bookkeeping and only surfacing at the
one moment everything gets walked at once: full RHI shutdown. It also explains the
all-engine-frames callstack — the corruption would be in engine bookkeeping *about* our
types, not in our code misusing an engine API.

Checked both this project's and `NexusFramework_V5`'s `ai-change-audits/` for prior
precedent of this exact shape (Live Coding + shutdown render-resource crash) — V5
mentions Live Coding routinely as its own `Build.bat`-is-blocked fallback, but neither
project has a prior record of this specific crash shape. New finding, not a recurrence.

## Proposed resolution (operational, not a code change)

No Nexus code was changed — nothing in the newly-added code is itself incorrect. The
fix, if the hypothesis holds, is process: **after adding any new `UCLASS`/`USTRUCT`/
`UENUM` type, or any new `UPROPERTY`/`UFUNCTION` on an existing one, do a full editor
close + `Build.bat` + relaunch — not a Live Coding hot-patch.** Live Coding stays fine
for function-body-only changes (the common case for pure bug fixes). If the crash
recurs after a session with zero Live Coding use (full cold rebuild + fresh launch
throughout), this hypothesis is disproven and a proper memory-debugger repro would be
the next step (outside this agent's capability — no editor launch, per
`AGENT-RULES.md`'s Agent Testing Policy).

## Verification

Code-reading and project-wide grep only, cross-checked against V5's own `ai-change-audits/`
for precedent. Not experimentally reproduced — this agent cannot launch the editor
(`AGENT-RULES.md`'s Agent Testing Policy). The root cause is clearly labeled as a
hypothesis throughout, not a confirmed finding.

## Important Notes

Worth watching for recurrence: if a future crash of this exact shape (RHI-shutdown,
`FRenderResourceList`, zero application frames) happens again in a session that used
**only** full `Build.bat` + relaunch cycles (no Live Coding at all), that would falsify
this hypothesis and point back to project code after all — re-open this investigation
rather than assuming the same cause.

## Correction — 2026-08-10 (same day): root cause was upstream of this crash, now confirmed

This record's "Live Coding hot-patch of new reflected types" hypothesis is **superseded**.
User provided the real `Saved/Logs/NexusFramework.log`, which showed a failure that
happens *before* and *causes* the RenderResource crash this record investigated:

```
InternalLoadLibrary: 'NexusFrameworkEditor'
Assertion failed: FoundPackage [UObjectGlobals.cpp:6605]
Code not found for generated code (package /Script/NexusFrameworkEditor).
Failed to load ...UnrealEditor-NexusFrameworkEditor.dll (GetLastError=1114)
```

`StartupModule()` never runs (confirmed by log timing — the assertion fires during the
DLL's own static initialization, before Windows even finishes `LoadLibrary`). In a
modular editor build, `USE_PER_MODULE_UOBJECT_BOOTSTRAP` is hard-`0`
(`Engine/Source/Runtime/Core/Public/Misc/Build.h:461`), so `ConstructUPackage`
(`UObjectGlobals.cpp:6605`) has no "create package on the fly" fallback — if anything
asks for `/Script/NexusFrameworkEditor` before that package object exists, it's a hard
crash every time, including through a genuinely fresh "no existing makefile" rebuild
(confirmed reproducible that way too — rules out simple build-staleness/Live Coding
patch drift as the primary explanation).

**Root cause, found by exhaustively grepping every `::StaticStruct()`/`::StaticClass()`
call in the module (7 total; 5 safely inside function bodies)**: exactly two namespace-
scope globals in `Source/NexusFrameworkEditor/Private/Representation/
NexusActivationDummyTypesRegistration.cpp` (lines 16-28, Phase 45, commit `679f202`) —
`GRegisterDummyBaseOnly`/`GRegisterDummyArray` — call `FNexusDummyBaseOnlyActivationPayload::
StaticStruct()`/`FNexusDummyArrayActivationPayload::StaticStruct()` as part of their own
constructor ARGUMENT evaluation, i.e. during DLL static initialization, before
`StartupModule()`, with no guaranteed ordering relative to the module's own package-
bootstrap static initializer in the same Unity Build translation unit
(`Module.NexusFrameworkEditor.cpp`). Every other static-registration global in this
codebase (the pre-existing `FNexusDebugCategoryAutoRegister` pattern, Phase 23 onward,
including Phase 46's own new `GRegisterActivationPoints`) only ever builds plain
FName/FString/FLinearColor data at construction time — never touches UObject reflection.
AlwaysDraw itself (Phase 46) was investigated and **ruled out** — its own registration
has no reflection call.

**Experimentally confirmed** (2026-08-10, same day): commented out both globals,
`Build.bat NexusFrameworkEditor Win64 Development` succeeded, user relaunched the editor
cold (no Live Coding) — loads successfully. Verdict upgraded from STRONG SUSPECT to
**ROOT CAUSE CONFIRMED**. The two globals are currently disabled (commented out, not
deleted) — Phase 45's dummy-type registration is non-functional until a real fix lands;
proposed fix (not yet implemented): make `FNexusActivationTypeDefinition::
PayloadStructType` resolve lazily instead of being evaluated as a global-constructor
argument. See `agent-todos/ready-for-review/
engine-crash-after-adding-new-phase-development-phase-43-49.md` for the full task
record.

## Correction — 2026-08-10 (same day): permanent fix implemented and verified

The proposed lazy-resolution fix is implemented and confirmed working, superseding the
"still disabled" state above. `FNexusActivationTypeDefinition::PayloadStructType` (raw
`UScriptStruct*`) replaced with `PayloadStructTypeGetter` (`TFunction<UScriptStruct*()>`)
+ a caching `GetPayloadStructType()` accessor
(`Source/NexusFrameworkEditor/Public/Representation/NexusActivationTypeRegistry.h`); the
two dummy-type registration globals in `NexusActivationDummyTypesRegistration.cpp`
re-enabled, now passing a lambda instead of an eagerly-evaluated `::StaticStruct()`
result. `TFunction<UScriptStruct*()>` rejecting a bare `UScriptStruct*` argument makes the
original mistake a compile error at any future registration site — the regression guard
the user asked for, enforced by the type system rather than a comment.

Full cold build succeeded (0 errors, 6 actions, editor closed, no Live Coding). User ran
the complete verification checklist and confirmed **PASS**: editor opens, `Nexus.
Representation.DumpActivationTypeRegistry` shows both `Dummy.BaseOnly` and `Dummy.Array`
registered correctly, editor closes cleanly and reopens once more without issue.

**Standing lesson for all future phases** (carried forward per the user's own
instruction): a namespace-scope global's constructor must never eagerly call a reflected
type's `StaticStruct()`/`StaticClass()` — those calls are only safe once
`/Script/<ModuleName>` is guaranteed initialized (i.e., from inside a function body that
runs after `StartupModule()`), never as a constructor argument evaluated during the
module DLL's own static initialization. Prefer a deferred/lazy accessor
(`TFunction<...>`-typed member resolved on first real use) for any registry entry that
needs a reflected type.
