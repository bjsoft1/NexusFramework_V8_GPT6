# Phase 48 research: Interactive Tools Framework IS reachable without a custom UEdMode

Date: 2026-08-10
Category: research
Phase: 48 (Activation Point - Gizmo Integration (Base)) - this phase's own explicitly
required "first task" ("resolve 13-v6-gizmo-system.md's open mechanism question... before
implementing the rest of this phase against an assumption that may not hold").

## Question

`13-v6-gizmo-system.md`'s "Editing flow" section left open whether Unreal's Interactive
Tools Framework (ITF) is reachable from V6 at all, given V6 has no custom `UEdMode` (the
2026-08-09 architecture correction - a custom Mode alongside built-in Landscape Mode is a
confirmed engine crash, see `ai-change-audits/2026-08-09/research/
v5-custom-edmode-crash-vs-landscape-mode.md`). The doc's own fallback, if ITF turned out
unreachable, was a hand-rolled `FEditorViewportClient`/raw `IInputProcessor` override.

## Finding: YES, reachable - no custom Mode needed

Confirmed via direct engine header inspection (UE 5.8):

1. **`FEditorModeTools::GetInteractiveToolsContext()`**
   (`Editor/UnrealEd/Public/EditorModeManager.h:568`) returns a
   `UModeManagerInteractiveToolsContext*` - the SAME shared ITF context every built-in
   Mode (Landscape Mode, Modeling Mode, etc.) already uses. It is owned by the
   `FEditorModeTools` instance itself, not by any individual Mode - a Mode is a
   *consumer* of this shared context, not its owner.
2. **V6 already holds a reference to the exact `FEditorModeTools` instance needed** -
   `FNexusLandscapeModeExtension.cpp` (Phase 02/03's own Landscape Mode detection) already
   does `firstLevelEditor->GetEditorModeManager()` to get `FEditorModeTools&`, used today
   only for `OnEditorModeIDChanged()`. The exact same reference additionally exposes
   `GetInteractiveToolsContext()` - no new access pattern, reusing an already-proven one.
3. **`UEditorInteractiveToolsContext`** (`UModeManagerInteractiveToolsContext`'s base
   class, `Editor/UnrealEd/Public/Tools/EdModeInteractiveToolsContext.h`) has public
   `StartTool(FString ToolTypeIdentifier)`/`CanStartTool(...)` methods - callable by any
   code holding the context pointer, not gated behind "must be a UEdMode." A tool
   builder is registered against the context's own `ToolManager`
   (`RegisterToolType`/similar, standard ITF pattern), then started by identifier string
   - ordinary object composition, not inheritance from any Mode base class.

## Conclusion

V6's gizmo mechanism (Phase 48) can use real `UInteractiveTool`/`UCombinedTransformGizmo`
machinery via the level editor's own shared `UModeManagerInteractiveToolsContext`,
obtained through `ILevelEditor::GetEditorModeManager().GetInteractiveToolsContext()` -
the exact same accessor path V6's existing `NexusLandscapeModeExtension.cpp` already
uses for a different purpose. **The hand-rolled `FEditorViewportClient`/`IInputProcessor`
fallback `13-v6-gizmo-system.md` describes is NOT needed** - standard ITF gizmo machinery
is confirmed reachable.

## What this unblocks vs. what's still open

Unblocked: the mechanism question itself - Phase 48 can proceed against real ITF, not a
custom fallback.

Still open (genuinely Phase 48's own remaining implementation, not attempted this
session due to budget - real interactive viewport behavior cannot be verified without
launching the editor, which this agent cannot do):
- Registering a `UInteractiveToolBuilder` for the Activation Point selection/gizmo tool
  against the shared context.
- Wiring selection (clicking a debug-drawn Activation Point/sub-point) to
  `StartTool`/gizmo activation at the correct composed transform.
- The actual drag -> `Inverse(AnchorTransform) * NewWorldTransform` -> `OffsetLocation`/
  `OffsetRotation` write-back, wrapped in `FScopedTransaction`/`Modify()`.
- Verifying array-element edits don't disturb sibling elements (this phase's own
  explicit completion criterion).

## Changes

- `project-specifications/13-v6-gizmo-system.md` - "Editing flow" section's "open
  question" resolved in place (see that file's own updated text) rather than left
  describing a now-answered question as still open.

## Verification

Header-inspection only (`grep`/`Read` against installed UE 5.8 engine source) - no code
written or compiled against this finding yet. The NEXT step for whoever picks up the rest
of Phase 48 is to actually write and compile a minimal tool registration against
`GetInteractiveToolsContext()` and confirm `StartTool` really activates in V6's own
Nexus Nomad tab context (not just in theory from reading headers) before building the
full drag/undo-redo flow on top of it.
