# Research: self-closed-highway Start/End debug markers — root cause found, not yet fixed

Date: 2026-08-10
Category: research
Phase: 11 (Nexus Mapping — Highway Membership) — owns the bug; 30 (Debug Rendering —
Landscape Group) — confirmed not at fault, needs no change.

## Context

`agent-todos/` task `need-search-inside-the-close-segment.md` (investigation-only, "do
not modify code yet"). User asked whether Start/End debug boxes drawn at a
self-closed highway segment (start/end points resolving to the same point) are correct
behavior or a bug, distinct from Corner/Straight/Junction classification. Full
investigation write-up lives in the task file itself
(`agent-todos/ready-for-review/need-search-inside-the-close-segment.md`); this record
is the durable, project-memory copy of the same finding per `CLAUDE.md`.

## Finding

Confirmed bug, root-caused precisely, **not fixed** (task explicitly forbade code
changes this pass).

`RenderStartEnd` (`NexusDebugLandscapeGroupRenderers.cpp`, Phase 30) is already correct
— it skips Start/End markers whenever `highway.IsClosedLoop` is true. The actual bug is
in `FNexusMapping::MapHighways` (`NexusMapping.HighwayMapping.cpp`, Phase 11): its Pass
1 (chains anchored at a junction/dead-end) can walk all the way around a loop that has
exactly one extra branch at its own anchor point J (J has degree 3: two loop directions
+ the branch) and arrive back at J itself — the resulting `chain` array has
`chain[0] == chain.Last()` (same control point, verified by tracing the walk's own
break-condition timing: it's checked on `current` at the TOP of each iteration, so a
point reached via the previous iteration's `chain.Add(next)` — even one with degree != 2
— is already IN the chain before the loop notices and breaks). But
`BuildHighwayFromChain(config, chain, false, newHighwayCount)` hardcodes
`isClosedLoop=false` for every Pass-1-derived chain, never checking
`chain[0] == chain.Last()`. Result: a Highway with `OrderedPointIds[0] ==
OrderedPointIds.Last()` but `IsClosedLoop=false` — `RenderStartEnd`'s own (correct)
guard never fires, so it draws a Start box AND an End sphere stacked at the same
location, which is topologically a junction (already separately, correctly marked by
`RenderConnections`), not a real open dead-end.

Distinct from the earlier-this-session `closed-loop-highway-renders-open-after-
landscape-edit.md` bug fix (`Nexus.Mapping.RemoveStaleHighways`) — that one was about a
chain's shape going stale after a Landscape edit post-mapping; this one is Phase 11's
*original* chain-building logic never attempting closed-loop detection at all for a
Pass-1 walk that happens to return to its own start. Present since Phase 11 shipped,
not a regression.

V5 had a structurally-similar-shaped historical bug
(`NexusFramework_V5/ai-change-audits/bug-fixed/closed-loop-and-divider-save-load.md`) —
same "detection happens somewhere, recording doesn't" shape — but V5's actual bug/fix
was a Save/Load topology-loss issue specific to its WorldData-caches-Landscape
architecture, which doesn't apply to V6 (never caches geometry). Referenced for concept
validation only, per the task's own explicit "do not port V5 logic blindly" instruction
— nothing from V5's fix was copied.

## Proposed fix (NOT implemented — next agent/session picking this up should do so)

In `MapHighways`'s Pass 1, immediately before calling `BuildHighwayFromChain`:
1. Compute `isClosedLoop = chain.Num() > 1 && chain[0] == chain.Last()`.
2. If true, pop the duplicated trailing point from `chain` before converting to
   `orderedIds` — matching Pass 2's own established "closed loop `OrderedPointIds` never
   repeats the boundary point, `IsClosedLoop` alone implies the wrap" convention (the
   one every other closed-loop-aware consumer already assumes —
   `RenderSegments`'s `IsClosedLoop ? numPoints : numPoints-1` + modulo, `WalkChainFrom`
   itself). A fix that only flips the boolean without also stripping the duplicate point
   would leave two inconsistent "closed loop" shapes in the same codebase.

No schema/serialization change - both parts are internal to one function.

## Verification

Code-reading only, no build (no code changed). Cross-checked against `RenderConnections`
(confirmed it independently, correctly marks the junction regardless of this bug) and
against V5's historical record for concept parity only.

## Important Notes

This is a real, user-visible bug with a precise, cheap fix already designed — worth
picking up as a normal `agent-todos/` implementation task (or a phase-11 `## Revision`)
rather than waiting for it to resurface as a fresh bug report.
