# Bug: FNexusHighwayPoint::ConnectedHighwayIds never populated for real Mapping output

Date: 2026-08-10
Category: bug-fixed
Phase: 43/44 (found while the user was manually exercising both) — root cause sits in
Phase 11's `FNexusMapping::MapHighways`, not in 43/44 themselves.

## Context

User ran `Nexus.Generation.DumpStreamingCellAssignment` (new, Phase 43) against their
real test map (`Nexus.Status`: `States=0 Cities=0 Highways=4 HighwayPoints=11`) and every
one of the 11 real HighwayPoints logged `(0 connected Highway(s))`, even though 4 real
Highways exist in the same config and necessarily reference some of those points.

## Problem / Goal

Determine whether this is a real bug or expected given `States=0`/`Cities=0`, and whether
it affects Phase 43/44's own new code.

## Findings

`FNexusHighwayPoint::ConnectedHighwayIds` (`Public/Representation/NexusHighwayPoint.h:110`)
is documented as "derived, never hand-edited" via `RecomputeConnectedHighwayIds`
(same file, lines 114-124). Grepped every call site in `Source/` — there is exactly
**one**: `Nexus.Representation.DumpHighwayPointGeometry`, a Phase 18 manual-verification
console command (`Private/Representation/NexusHighwayPoint.cpp:33`). Neither
`FNexusMapping::MapHighways` (`NexusMapping.HighwayMapping.cpp:100-208`, the function
that actually builds Highways from Landscape chains) nor `MapControlPoint(s)`
(`NexusMapping.PointMapping.cpp:79-136`) ever call it. So for the real,
persisted `UNexusConfigAsset::HighwayPoints` array, `ConnectedHighwayIds` stays at its
default-constructed empty `TArray` forever, for every real user map, unless someone
happens to run that one unrelated debug command first (which has the side effect of
populating it for whichever points it touches, until the next `MapHighways` re-run adds
new points that were never covered).

Contrast: `FNexusRepresentationGraph::PopulateFromConfigAsset`/`AddPointToHighway`
(`Private/Representation/NexusRepresentationGraph.cpp:19-69, 86-105`) correctly derives
each point's connected-Highway set — but only on that class's own SEPARATE in-memory
graph copy, never written back onto `config.HighwayPoints` itself. So the derivation
logic exists and is correct, it just was never connected to the one array most other
code (including this session's new Phase 43/44 work) actually reads.

**Confirmed real, not `States=0`-related**: `States=0`/`Cities=0` correctly explains why
every resolved cell was `'Default'` (nothing to resolve up to) — that part of the log was
working as designed. The `0 connected Highway(s)` count is independent and wrong
regardless of State/City count.

## Changes

Fixed the two places THIS SESSION'S OWN Phase 43/44 code read
`FNexusHighwayPoint::ConnectedHighwayIds` directly, so neither depends on the broken
field anymore — both now derive the same information live by scanning `config.Highways`'
own `OrderedPointIds` (the same check `RecomputeConnectedHighwayIds` itself does
internally, just not cached):

- `FNexusStreamingCellResolver::ResolveStreamingCellForHighwayPoint`
  (`Source/NexusFrameworkEditor/Private/Generation/NexusStreamingCellResolver.cpp`) — was
  `config.HighwayPoints.FindByPredicate(...)->ConnectedHighwayIds[0]`, now
  `config.Highways.FindByPredicate([](highway){ return highway.OrderedPointIds.Contains(pointId); })`.
- `FNexusGenerationValidationGate::ValidateGenerationStage`'s streaming-consistency check
  (`Source/NexusFrameworkEditor/Private/Generation/NexusGenerationValidation.cpp`) — was
  iterating `config.HighwayPoints` and reading each point's own `ConnectedHighwayIds`
  (always < 2, so the junction-mismatch Warning could never fire on real data); now
  builds a live `PointId -> TArray<HighwayId>` map by walking every Highway's own
  `OrderedPointIds` once (`O(TotalPointReferences)`, not `O(HighwayPoints x Highways)`).

**Not fixed** (deliberately, out of Phase 43/44's own scope — see Important Notes):
`FNexusMapping::MapHighways` itself still never calls `RecomputeConnectedHighwayIds`, so
`config.HighwayPoints[i].ConnectedHighwayIds` remains unreliable for ANY other/future
consumer that reads it directly (the one existing Phase 18 debug command is unaffected -
it computes the value itself on demand, doesn't rely on it having been pre-populated).

## Verification

`Build.bat NexusFrameworkEditor Win64 Development -WaitMutex -NoHotReloadFromIDE` —
Succeeded, 0 errors. Not yet re-run against the user's real map (agent cannot launch the
editor) — user should re-run `Nexus.Generation.DumpStreamingCellAssignment` to confirm
HighwayPoints now report their real connected-Highway relationships (indirectly, via
correct cell resolution) once they have real City/State/DataLayerAssetName data to test
against.

## Result

Phase 43/44's own new code no longer depends on the broken field. The wider bug (the
field itself is still never populated on the real config array) remains open — available
for pickup as its own task (add a `RecomputeConnectedHighwayIds` call for affected points
inside `MapHighways`, or wherever the project decides is the right single write point).

## Important Notes

Two more things found in the same investigation, NOT fixed (both are pre-existing,
out-of-scope-for-Phase-43/44 architecture gaps, not regressions — flagging for
visibility/prioritization, not silently expanding this task):

1. **The Hierarchy tree panel (`SNexusFrameworkPanel`) is still 100% hardcoded
   placeholder data, never wired to real config data.** `BuildPlaceholderHierarchy`
   (`Private/UI/SNexusFrameworkPanel.cpp:86-110`) is called exactly once, in the
   constructor (line 53), and populates `HierarchyItems` with a fake
   `State > City > Highway > HighwayPoint` chain using `FNexusPlaceholderTreeItem`
   (`Public/UI/NexusPlaceholderTreeItem.h:15-20`, itself documented as "Hardcoded
   placeholder content only - no real Landscape/Mapping/Representation data yet").
   Grepped for any other write to `HierarchyItems` — none exist; the only other mutation
   is deletion (`RemoveTreeItemRecursive`). This is exactly what a user just hit: they
   deleted the tree's "Placeholder State" row via its Delete context-menu action
   (harmless — it only removes an in-memory `FNexusPlaceholderTreeItem`, never touches
   `UNexusConfigAsset`/States/Cities/Highways) and, understandably, expected the tree to
   reflect their real 4-Highway/11-Point/0-City/0-State map. It never has, for any user,
   at any point in this project's history so far. Real City/State creation/assignment
   only exists via `Nexus.Mapping.CreateCity`/`CreateState`/`AssignHighwayToCity`/
   `SetCityState` console commands (`Private/Mapping/NexusMapping.CityStateMapping.cpp`);
   Highway/HighwayPoint creation is fully automatic from Landscape splines
   (`MapControlPoints`/`MapHighways`). No phase file anywhere (grepped all of
   `project-specifications/phases/`) mentions wiring the tree to real data or adding a
   manual "Add City/State/Highway" UI action — Phase 04's own scope
   (`phase-04-ui-interaction.md`) was explicitly "context menu shell (Delete/Rename/Focus
   - stubbed actions)" against placeholder data, and nothing since has picked this up.
2. **No way exists yet — console or UI — to set `HalfWidth`/`LaneWidth`/`SidewalkWidth`
   on a REAL Highway/City/State.** These are plain `EditAnywhere` `UPROPERTY`s, normally
   set via the Details panel, but per Note 1 the Details panel is only ever bound to
   `FNexusPlaceholderTreeItem` selections (or Debug category config, a separate,
   already-real-and-working binding from Phase 23-26/the config-asset-dirty work), never
   to a real `FNexusHighway`/`City`/`State` struct. No `Nexus.Mapping.Set*Width` console
   command exists either (grepped `NexusMapping.CityStateMapping.cpp` and the rest of
   `Private/Mapping/`). Practical effect: `Nexus.Generation.GenerateHighwayMeshes`
   reporting "0 meshes... skipped (ResolvedHalfWidth <= 0)" is currently **unavoidable**
   for any real map — `HalfWidth`'s inheritance chain has no City/State override (Note 1)
   and no way to set it explicitly either, so it always resolves to
   `NexusInheritance`'s `DisabledValue` (0) fallback. This blocks Phase 41/43's own mesh
   generation from ever producing real output until either a console setter or real
   Details-panel binding exists — worth prioritizing before further manual QA of Phase
   41/43 is attempted.
