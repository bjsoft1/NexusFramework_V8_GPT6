# Stale Highway not detected after its Landscape segment is deleted

Date: 2026-08-10
Category: bug-fixed
Phase: phases/14, phases/16 (both already `Ready for QA` before this fix)

## Context

User was testing the just-revised Phase 36 junction classification: built a closed-loop
highway (a circle), drew a diagonal highway connecting two of the loop's own points
(creating T-junctions where the diagonal met the loop), then deleted the diagonal's
segment natively in the Landscape Spline tool. Re-running
`Nexus.Representation.DumpJunctionClassification` showed the exact same output as
before the removal - the diagonal's junction effect on the loop was still present. User
flagged this matches a known V5 bug class (V5's own `ai-change-audits/bug-fixed/
closed-loop-and-divider-save-load.md` - a divider/connector between two already-tracked
points) and asked whether the same class of fix should be applied here. Given the
choice between fixing immediately vs. tracking as a new phase (matching the phase-41a
precedent from earlier in the same session), the user chose to fix now.

## Problem / Goal

Determine why removing a Highway's Landscape segment doesn't get picked up by
Representation, and fix it without violating the project's existing "never silently
drop" data-integrity principle (Phase 16/`14-v6-validation.md`).

## Findings

1. **`FNexusMapping::MapHighways` (Phase 11) is append-only - it has no removal path at
   all.** `BuildHighwayFromChain`'s only mutation is `Config.Highways.Add(...)`;
   `IsChainAlreadyMapped` exists purely to skip RE-adding a chain that's already
   present, never to remove one that's disappeared. This is fine and expected on its
   own (Phase 11 is a one-directional "discover new chains" pass) - the gap is that
   nothing ELSE ever reconciles a Highway against the Landscape's CURRENT state either.
2. **Both existing "is this still good" checks are purely internal-to-Config, not
   Landscape-aware for Highways.** `ValidateMappingStage`'s (Phase 14) "Highway-
   membership consistency" section only confirms `Highway.OrderedPointIds` entries
   resolve to SOMETHING in `Config.HighwayPoints` - it never asks whether those points
   are still actually adjacent to each other in the live Landscape.
   `ReconcileMappingStage`'s (Phase 16) broken-entry detection only checks
   `HighwayPoint.SourcePoint.LoadSynchronous()` per POINT - there's no equivalent
   per-HIGHWAY check anywhere.
3. **This is exactly why the diagonal case is invisible to both**: deleting the
   diagonal's segment in Landscape doesn't delete its endpoint control points - they're
   shared with the loop, so they still exist and still resolve fine. The diagonal's own
   `FNexusHighway` record (`OrderedPointIds = [A, B]`) is therefore, by both existing
   checks' own logic, perfectly valid - both IDs resolve, nothing's a duplicate. Neither
   check has any way to know the LIVE spline segment directly connecting A and B no
   longer exists.
4. **This is a genuine scope gap in the original phase files, not a regression** -
   Phase 14's Objective ("every HighwayPointId resolves... every Highway's points
   exist") and Phase 16's Objective ("control point no longer resolves" / "new since
   last session") were both, as originally written, scoped to internal-Config
   consistency and point-level staleness only. The code faithfully implements what was
   asked; "does a Highway's chain still match live Landscape topology" was simply never
   asked for by either phase.
5. **The fix is a single shared check, not two separate implementations** -
   `FNexusMapping::DoesHighwayChainMatchLiveLandscape` walks a Highway's
   `OrderedPointIds` pairwise (wrapping last->first when `bIsClosedLoop`, matching
   `NexusMapping.HighwayMapping.cpp`'s own closed-loop convention) and confirms each
   consecutive pair's resolved `SourcePoint`s are still adjacent in a freshly-rebuilt
   `FNexusLandscapeReader::BuildAdjacency` result - the same adjacency data structure
   `MapHighways` itself already builds when discovering NEW chains, just used here to
   also disprove an EXISTING one. Both `ValidateMappingStage` (Blocking) and
   `ReconcileMappingStage` (`BrokenEntries`) call the same function, so there's one
   source of truth for "does this Highway still match reality," not two independently-
   maintained implementations that could drift apart.
6. **Performance**: `BuildAdjacency(Landscape)` (the expensive part - it walks the
   Landscape's actual spline component) is built ONCE per `ValidateMappingStage`/
   `ReconcileMappingStage` call and passed by reference into every per-Highway check -
   not rebuilt once per Highway. `ReconcileMappingStage` also skips the check entirely
   for a Highway that's newly-mapped THIS pass (it was just freshly derived from the
   current Landscape by the `MapHighways` call two lines above - checking it against
   itself would be redundant, not wrong, but wasted work).
7. **"Never silently drop" is preserved exactly as-is** - this fix only ADDS detection
   (a Blocking validation entry; a `BrokenEntries` report line). Nothing new was added
   that removes a `FNexusHighway` from `Config.Highways` - matches the same contract
   Phase 16's own header comment already documents for points, now extended to
   Highways.
8. **Edge case reasoned through, not just the reported scenario**: this same check also
   correctly catches a Highway whose middle got a NEW point inserted natively (splitting
   what used to be one direct segment into two) - the old two-point pair is no longer
   directly adjacent, so the old Highway record correctly flags as stale even though no
   deletion happened, just a topology change. This is the intended, consistent
   behavior, not a false positive - the stored chain genuinely no longer matches a
   single live segment between those two specific points; a fresh `MapHighways`/
   `ReconcileMappingStage` run is what's needed to pick up the new intermediate point.

## Changes

- `Public/Mapping/NexusMapping.h` — forward-declared `FNexusPointAdjacency`; new public
  static `DoesHighwayChainMatchLiveLandscape(Config, Highway, LandscapeAdjacency)`.
- `Private/Mapping/NexusMapping.Validation.cpp` — implemented the function; wired into
  `ValidateMappingStage`'s Highway loop as a new Blocking entry, gated on `Landscape !=
  nullptr` (same pattern the existing cross-map check already uses). `BuildAdjacency`
  built once at the top of `ValidateMappingStage`, reused per-Highway.
- `Private/Mapping/NexusMapping.Reconciliation.cpp` — `ReconcileMappingStage` now builds
  its own `LandscapeAdjacency` once and calls the same function per previously-known
  Highway, appending to `Result.BrokenEntries` on a mismatch; skips the check for a
  Highway newly-mapped this same pass (Finding #6).
- `project-specifications/phases/phase-14.md`/`phase-16.md` — both already `Ready for
  QA`; appended a `## Revision` section to each (their original, already-verified
  criteria left untouched) plus one new unchecked completion criterion each, with exact
  manual-check steps reproducing the user's own scenario.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, 0 errors, 10 actions.
- `node html-docs/build.js` — regenerated.
- **Not run by the agent this session** (per `AGENT-RULES.md`'s Agent Testing Policy) -
  the exact repro (closed loop + diagonal + native segment deletion +
  `Nexus.Mapping.ValidateMappingStage`/`ReconcileMappingStage`) is the new completion
  criterion in both phase files, left for the user's own manual pass.

## Result

`ValidateMappingStage` and `ReconcileMappingStage` now both detect a Highway whose
Landscape segment was deleted or rerouted natively, even when its own points remain
individually resolvable (the closed-loop-diagonal case that prompted this) - reported as
a Blocking validation entry and a Reconciliation `[BROKEN]` line respectively, never
auto-removed. Not yet confirmed against the user's own live repro.

## Important Notes

- This fix addresses Highway-chain staleness specifically. It does NOT add an
  equivalent check for City/State membership staleness (e.g. a City's `StateId`
  pointing at a State that still exists in Config but whose own real-world grouping
  changed) - out of scope for what was reported; flagging here in case a similar gap is
  found there later.
- `Nexus.Representation.DumpJunctionClassification`/other Representation-stage console
  commands still do not themselves run Mapping-stage validation - they rebuild
  `FNexusRepresentationGraph` fresh from whatever `Config.Highways`/`HighwayPoints`
  currently contain, stale entries and all. This fix makes the staleness DETECTABLE
  (via Phase 14/16's own commands), it does not make Representation-stage queries
  automatically refuse stale data - that would be Phase 22's Representation-stage
  validation gate's own concern (`ValidateRepresentationStage`), which is a separate,
  already-implemented check that currently only validates internal-to-Representation
  referential integrity, the same category of gap this fix just closed one stage up.
  Worth a follow-up look if the user hits the same class of staleness there.
