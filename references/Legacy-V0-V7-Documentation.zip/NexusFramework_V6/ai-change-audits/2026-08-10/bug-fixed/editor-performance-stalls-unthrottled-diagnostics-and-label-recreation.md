# Editor Performance Stalls — Unthrottled Diagnostics Gather + Label Widget Recreation

Date: 2026-08-10
Category: bug-fixed
Phase: N/A (ad-hoc, direct user-reported regression). Touches Phase 27 (Diagnostics
Panel & Viewport Rendering), Phase 29 (Debug Rendering — Labels & Text), Phase 33-35
(Debug Performance).

## Context

Direct user report: serious Editor performance regression noticed over the last 6-7
hours of this session. Editor reports ~120+ FPS but the UI freezes 1-10 seconds;
switching back to UE from another app can freeze; typing/editing Details Panel values
can freeze; adding an Activation Point/array item freezes (worse than adding a City/
Highway); the problem gets much worse with the full Debug Tree enabled; the test map/
debug geometry is very small, so the workload should be trivial. User explicitly asked
for an investigation report BEFORE any code changes, referencing V0's `NexusRoadGraph`
(`E:\Projects\Game\UE\NexusFramework_V0`) as a comparison point for a debug-render
architecture that scales to a massive open world smoothly.

## Problem / Goal

Find the actual bottleneck(s) via code inspection (no editor launch available - Agent
Testing Policy), compare against V0's architecture, then implement the smallest fix
that restores smooth UI interaction without hiding the problem by disabling features.

## Findings — confirmed bottlenecks

**1. `FNexusDiagnostics::GatherDiagnostics` ran unconditionally, unthrottled, from
`UNexusFrameworkSubsystem::Tick` every single frame** (`RenderDiagnosticsOverlay`,
called first thing in `Tick`) - regardless of whether the Diagnostics tab was open,
regardless of whether any `Diagnostics.*` category was visible, forever, for the whole
editor session once `ActiveConfig` was set. This one function call, per invocation:
- Runs `FNexusLandscapeReader::ValidateSourceStage` (a live read of every Landscape
  spline control point).
- Runs `FNexusMapping::ValidateMappingStage`.
- **Rebuilds a brand-new `FNexusRepresentationGraph` from scratch** via
  `PopulateFromConfigAsset` (walks every State/City/Highway/HighwayPoint).
- Calls `FNexusMapping::ComputeHighwaysNotMatchingLiveLandscape`, which itself calls
  `FNexusLandscapeReader::BuildAdjacency` - **another full, live read of the Landscape
  spline graph**.
- Runs `graph.ValidateRepresentationStage` and
  `FNexusGenerationValidationGate::ValidateGenerationStage` (the latter resolves a
  streaming cell per connected Highway for every junction point).

This is a direct violation of this project's OWN documented performance rule
(`project-specifications/06-v6-debug-system.md`: "Renderers read cached
Representation-stage data, never recompute Landscape geometry per frame - Landscape
reads happen at Mapping-stage refresh points, not inside the draw loop") - a rule
`FNexusDebugRenderSnapshot` (the geometry side) already correctly follows (throttled,
0.25s interval), but `RenderDiagnosticsOverlay`/`GatherDiagnostics` was never brought
under that same discipline. Running a multi-stage validation pass end-to-end 60-140+
times per second, forever, is expensive regardless of dataset size - it explains a
real, sustained per-frame tax even on a "very small" test map, and fully explains why
it gets worse with more data (more States/Cities/Highways/HighwayPoints/junctions to
re-walk every single time).

**2. The SAME expensive gather ran a SECOND, fully independent time, every frame** -
`SNexusDiagnosticsPanel::Tick` → `RefreshDiagnostics()` called
`FNexusDiagnostics::GatherDiagnostics` itself again, completely unaware of (1) above.
Two separate systems (the subsystem' Tick and this one widget's own Tick) were
redundantly re-running the identical expensive pipeline validation every frame -
exactly the "multiple Tick/render callbacks doing the same work" pattern the user
asked to check for.

**3. `FNexusDebugLabelOverlay::UpdateLabels` destroyed and recreated every single debug
label's Slate widget, every single frame.** `Canvas->ClearChildren()` followed by one
`SNew(STextBlock)` + `AddSlot()` PER label request, called unconditionally from
`UNexusFrameworkSubsystem::Tick` regardless of whether the label set actually changed.
This class's own header comment already documented this as a KNOWN, deliberate
simplification: *"Simplification vs. V5's own pooled-STextBlock implementation... at
today's small label counts - pooling/allocation-efficiency at scale is explicitly
Phase 33-35's ('Debug Performance') job, not this one's."* Phase 33-35 are marked `In
Review` (LOD/spatial-filtering work was done - `FNexusDebugLOD`) but never actually
circled back to implement the label pooling they were assigned - a real gap between
what those phases claimed to own and what was delivered. Slate widget construction +
destruction + the resulting layout invalidation is real per-frame cost, and this scales
directly with however many debug/diagnostics labels are currently on-screen - i.e. it
gets measurably worse the more Debug Tree categories are enabled with
`ShouldShowLabel=true`, matching the user's own "much worse with the full Debug Tree
enabled" report.

## Findings — checked and ruled out

- **Duplicate delegate registrations**: `SNexusHierarchyPanel`/`SNexusDetailsPanel`/
  `SNexusDiagnosticsPanel` each bind to `UNexusFrameworkSubsystem::
  OnActiveConfigDataChanged`/`OnDetailsTargetChanged`/`UNexusConfigAsset::
  OnPostEditUndo` via `AddSP` (weak-pointer-bound) in their own `Construct()`.
  `UNexusFrameworkSubsystem::Initialize()` itself (where `OnFocusChanging` is bound) is
  only ever called once per editor session (subsystems are process-lifetime
  singletons) - not a per-tab-open source of duplicate registrations. `AddSP` bindings
  auto-invalidate (skip firing) once their owning widget is destroyed; no unbounded
  accumulation found.
- **Full graph/category traversal every frame**: `DispatchDebugRenderers` DOES rebuild
  a `TArray<const FNexusDebugCategory*>` from the registry's `TMap` every Tick
  (`GetAllCategories`) - for the current ~60-category registry this is a cheap O(N)
  pointer-array build (microseconds), not a meaningful contributor on its own; left
  as-is rather than adding complexity for a cost this small (see Recommended Fix's own
  "not changed" list).
- **Rebuilding Details Panel/property data unnecessarily on every keystroke**: property
  edits already correctly batch into one `NotifyPreChange`/`OnFinishedChangingProperties`
  pair per commit (not per character) via `IStructureDetailsView`'s own standard
  behavior - no extra rebuild found beyond the one `OnActiveConfigDataChanged` broadcast
  already documented under "secondary, not changed" below.
- **Debug systems continuing to run while hidden**: `DispatchDebugRenderers` already
  correctly skips a renderer's actual draw work when its category is both invisible and
  not `SupportsAlwaysDraw` (checked once per category, before any drawing) - this gate
  was already correct; it's the DIAGNOSTICS gather (a different code path, not gated on
  any category's visibility at all) that was the actual problem.

## Why the Debug Tree makes it worse

Two independent multipliers, both confirmed above: (a) more registered/visible
categories means more `RendererFn.Execute` calls per Tick (each individually cheap
today, but a linear cost that grows with what's enabled) and, more significantly,
(b) more visible categories with `ShouldShowLabel=true` means more labels every frame,
which under finding #3's per-frame Slate-widget-recreation bug means proportionally
more widget construction/destruction/layout-invalidation cost every single frame - the
label bug's cost scales directly with "how much of the Debug Tree is currently on."
Finding #1 (unthrottled diagnostics) is a FIXED, always-on cost independent of the
Debug Tree's own state (it ran even with everything toggled off), so it explains the
baseline stall even on a supposedly-trivial dataset; the Debug Tree specifically makes
it *worse* on top of that baseline via (a) and (b).

## Comparison with V0

Read `NexusRoadGraphEditorVisualizer.h/.cpp` (V0's `NexusRoadGraph` debug-render path).
Two structural differences from V6's current (pre-fix) approach:

1. **V0 never mixes data validation into the render path.** Its visualizer
   (`FNexusRoadGraphEditorVisualizer::DrawRoadGraph`/`DrawRoadGraphAlwaysVisible`) only
   ever reads already-resolved `FHighwayData`/road-point data and issues draw calls
   (`FRoadGraphPrimitiveDraw::DrawLine`/`DrawPoint`, which prefer the real `PDI`
   primitive-draw interface when available, falling back to `DrawDebugLine`/
   `DrawDebugSphere` otherwise - the same fallback primitives V6 already uses via
   `FNexusDebugPrimitives`). There is no equivalent of V6's `GatherDiagnostics` running
   INSIDE the render loop - V0 has no per-frame "re-validate the whole road graph"
   step mixed into drawing at all. V6's own `FNexusDebugRenderSnapshot` (geometry)
   already matches this discipline correctly (throttled, cached, read-only from
   renderers); the Diagnostics overlay was the one path that never got the same
   treatment.
2. **V0's primitive-draw abstraction is not fundamentally different from V6's** - both
   ultimately fall back to the same engine `DrawDebugLine`/`DrawDebugSphere` helpers
   when no `PDI` is available, so this was not the source of the regression. The real
   difference is architectural discipline about WHEN expensive work happens (once,
   cached, on a change/throttle - V0 and V6's OWN geometry snapshot) versus happening
   unconditionally inside the per-frame draw call (V6's diagnostics gather, until this
   fix, and its label-widget rebuild).

## Recommended fix (implemented)

Smallest change that addresses all three confirmed bottlenecks, reusing patterns
already established elsewhere in this codebase rather than inventing new ones:

1. **Throttle + cache the Diagnostics gather** on `UNexusFrameworkSubsystem`
   (`RefreshDiagnosticsIfDue`, `CachedDiagnostics`) - same throttle interval
   `FNexusDebugRenderSnapshot::RefreshIntervalSeconds` (0.25s) already uses, not a new
   magic number. `RenderDiagnosticsOverlay` now reads the cache instead of calling
   `GatherDiagnostics` directly.
2. **Dedupe**: `SNexusDiagnosticsPanel::RefreshDiagnostics` now reads
   `UNexusFrameworkSubsystem::GetCachedDiagnostics()` instead of calling
   `FNexusDiagnostics::GatherDiagnostics` itself - the gather now happens in exactly
   ONE place per throttle tick, not twice per frame.
3. **Pool the label overlay's Slate widgets** (`FNexusDebugLabelOverlay`) - widgets are
   created once (first time a given index is needed this session) and reused
   thereafter (`SetText`/`SetColorAndOpacity`/`SetFont`/the slot's own `SetOffset`
   update an existing widget in place); a frame needing fewer labels than the current
   pool size hides the excess (`EVisibility::Collapsed`) instead of destroying them, so
   the pool only ever grows to its session high-water mark.
4. **Lightweight, always-on timing instrumentation** (per the user's own request to add
   scoped timings so any REMAINING stall can be pinpointed from a normal session's own
   log, without a profiler attached): `LogIfSlow` helpers in
   `NexusFrameworkSubsystem.cpp` (wrapping `Tick` total, `RenderSnapshot.Refresh`,
   `GatherDiagnostics`, `UpdateLabels`, and each individual category renderer by
   `CategoryId`) and in `SNexusHierarchyPanel.cpp` (wrapping `RefreshHierarchyTree`,
   via `ON_SCOPE_EXIT` to cover its several early-return paths in one place). Each logs
   a `Warning` to `LogNexusFrameworkEditor` only when a section takes >= 8ms (half a
   frame at 60fps) - silent/near-zero cost otherwise (one `FPlatformTime::Seconds()`
   call + a branch).

**Not changed** (reviewed, found acceptable, or deliberately deferred rather than
silently rewritten):
- `SNexusHierarchyPanel::RefreshHierarchyTree` still rebuilds the ENTIRE hierarchy tree
  (every State/City/Highway/HighwayPoint/ActivationPoint) on any single edit/create -
  a real inefficiency matching several of the user's own checklist items ("one
  Activation Point change causing all categories/all points to rebuild"), but for a
  "very small" dataset this is unlikely to be the multi-SECOND freeze culprit compared
  to finding #1/#3 above, and properly fixing it (incremental/targeted tree updates
  instead of full rebuild-and-reselect) is a larger, separate change than "smallest
  fix" calls for here. Now instrumented (see point 4) instead of rewritten - if the
  user's own log shows this section crossing the 8ms threshold after this fix, that's
  concrete evidence to justify a real follow-up rather than a speculative rewrite now.
- `DispatchDebugRenderers`'s per-Tick `GetAllCategories` TMap-to-array rebuild - cheap
  at today's ~60-category registry size, left as-is (see Findings' "checked and ruled
  out").
- The individual Debug renderer files (Landscape/Roads/Mapping/Runtime groups) -
  reviewed, all already correctly read from the cached, throttled
  `FNexusDebugRenderSnapshot` rather than live Landscape data; no per-renderer changes
  needed. `RenderActivationPoints` specifically (extended earlier today for real,
  persisted Activation Points) was reviewed and found NOT to be a new contributor - it
  already gates on `IsEnabled`/category visibility before doing any resolve work.

## Changes

- `Public/Subsystem/NexusFrameworkSubsystem.h` / `Private/.../NexusFrameworkSubsystem.cpp`:
  - New `GetCachedDiagnostics()`, `RefreshDiagnosticsIfDue()`, `CachedDiagnostics`,
    `LastDiagnosticsRefreshSeconds`.
  - `RenderDiagnosticsOverlay` now calls `RefreshDiagnosticsIfDue()` and iterates
    `CachedDiagnostics` instead of calling `FNexusDiagnostics::GatherDiagnostics`
    directly.
  - New anonymous-namespace `LogIfSlow` helper + timing wraps around `Tick` (total),
    `RenderSnapshot.Refresh`, the diagnostics gather, `LabelOverlay->UpdateLabels`, and
    each category's `RendererFn.Execute` call.
  - `#include "Debug/NexusDiagnosticsEntry.h"` added to the header.
- `Public/Debug/NexusDebugLabelOverlay.h` / `Private/.../NexusDebugLabelOverlay.cpp`:
  - `UpdateLabels` rewritten to pool/reuse `STextBlock` widgets + their
    `SConstraintCanvas::FSlot`s instead of `ClearChildren()` + recreate every call.
  - New `PooledLabelWidgets`/`PooledLabelSlots` members; both reset in `Unregister()`
    (which destroys `Canvas`, invalidating the pool along with it).
  - Header's own comment updated to record the perf-fix history (superseding the
    original "simplification... at today's small label counts" note).
- `Private/UI/SNexusDiagnosticsPanel.cpp`:
  - `RefreshDiagnostics` now reads `UNexusFrameworkSubsystem::GetCachedDiagnostics()`
    instead of calling `FNexusDiagnostics::GatherDiagnostics` itself. Removed now-unused
    `#include`s (`Debug/NexusDiagnostics.h`, `Landscape.h`, `Mapping/NexusConfigAsset.h`,
    `Reader/NexusLandscapeReader.h`).
- `Private/UI/SNexusHierarchyPanel.cpp`:
  - New local `LogIfSlow` helper (same pattern, not shared - see its own comment for
    why not a shared utility for two call sites) + `ON_SCOPE_EXIT`-wrapped timing
    around `RefreshHierarchyTree`.
  - `#include "HAL/PlatformTime.h"`, `#include "Misc/ScopeExit.h"`,
    `#include "NexusFrameworkEditorModule.h"` added.

## Verification

Build-only (`AGENT-RULES.md`'s Agent Testing Policy):
```
Build.bat NexusFrameworkEditor Win64 Development -project=NexusFramework.uproject
```
Succeeded on the first attempt (editor was already closed - confirmed via `tasklist`
before building). Follow-up no-op build confirmed "Target is up to date."

No in-editor verification performed or attempted (this agent cannot launch the
editor). Manual QA needed:

1. Enter Landscape Mode with the Debug Tree fully enabled (every category visible,
   labels on). Confirm the reported FPS counter no longer coincides with visible
   UI freezes - interact with the viewport (orbit/pan camera), type in a Details
   Panel field, create a City/Highway/Activation Point, and switch focus away from
   and back to the UE window, checking each for the specific freeze previously
   reported.
2. Watch the Output Log for `Nexus Perf:` Warning lines during steps above - each
   names the specific section that ran slow (`FNexusDiagnostics::GatherDiagnostics`,
   `FNexusDebugLabelOverlay::UpdateLabels`, `SNexusHierarchyPanel::RefreshHierarchyTree`,
   `UNexusFrameworkSubsystem::Tick (total)`, or a specific Debug category's own
   `CategoryId`). If freezes persist, these lines are the next concrete lead - report
   back which section(s) fire and their logged millisecond counts.
3. Confirm the Diagnostics tab still shows the correct, up-to-date validation entries
   (severity/message/click-to-focus) - only its REFRESH RATE changed (now throttled to
   ~4/sec instead of every frame), not its correctness.
4. Confirm debug labels (category labels, Diagnostics markers) still track their
   on-screen position correctly while orbiting the camera, and still appear/disappear
   correctly as their owning category is toggled or as they enter/leave view.

## Result

Three confirmed, fixed bottlenecks: an unthrottled, duplicated, multi-stage validation
pass running unconditionally every frame regardless of UI state (the primary driver of
a fixed per-frame tax independent of dataset size), and per-frame Slate widget
recreation for every debug/diagnostics label (a cost that scales directly with how much
of the Debug Tree is enabled, matching the user's own "much worse with full Debug Tree"
report). Build-verified; lightweight always-on instrumentation added so any remaining
stall reports back a specific, named section and a millisecond count instead of
requiring another blind investigation pass.

## Important Notes

- The label-pooling fix directly reverses a KNOWN, previously-documented deferral
  (Phase 29's own header comment explicitly deferred this to Phase 33-35 "Debug
  Performance," which never actually delivered it despite being marked `In Review`) -
  worth flagging to whoever reviews Phase 33-35's own completion status, since this
  gap existed unnoticed until now.
- `RefreshDiagnosticsIfDue`'s cache means the Diagnostics Panel/viewport markers can lag
  reality by up to 0.25s (same staleness bound `FNexusDebugRenderSnapshot` already
  accepts) - acceptable per this project's own "a stale snapshot can only ever make
  debug drawing lag reality by up to one refresh interval" precedent (that struct's own
  header comment), not a new risk class.
- If the user's own manual QA (via the new `Nexus Perf:` log lines) finds
  `SNexusHierarchyPanel::RefreshHierarchyTree` crossing the threshold, the follow-up fix
  would be incremental tree updates (patch only the changed subtree/row) instead of a
  full rebuild-and-reselect - flagged here as the most likely next target, not
  implemented speculatively in this pass.
