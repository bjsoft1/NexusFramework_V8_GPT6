# Landscape > Segments Rendering + Junction Classification — Architecture Fix

Date: 2026-08-10
Category: bug-fixed
Phase: N/A (ad-hoc performance investigation, cross-cutting Debug/Representation)

## Context

Direct continuation of the same-day performance investigation
(`editor-performance-stalls-unthrottled-diagnostics-and-label-recreation.md`). After that
first pass (throttled diagnostics/snapshot refresh, pooled labels), the user reported the
remaining freeze narrowed specifically to `Debug > Landscape > Segments`: enabling it made
the editor ~80% more laggy, disabling it ~80-90% smoother, and reducing line thickness to 1
gave another ~40% improvement (without fixing the underlying issue). The user also asked
for a separate, related investigation into junction/segment classification cost. Both were
investigated (see this file's own earlier chat-reported findings) before implementing.

## Problem / Goal

1. `Landscape.Segments` (and the Roads group's offset-polyline leaves: Highways/Lanes/
   Sidewalks) resampled a 12-point Hermite curve, from scratch, for every Highway segment,
   every single Tick (~every editor frame) - not throttled at all, only the underlying
   point/tangent DATA was throttled (0.25s). Confirmed via UE 5.8 engine source
   (`BatchedElements.cpp`) that `DrawDebugLine`'s non-zero-thickness path
   (`FNexusDebugRenderConfig::LineThickness` defaults to 2.0) builds a 4-triangle/
   12-vertex mesh per line with per-vertex clip-space transform math, vs. 2 raw vertices
   for `Thickness == 0` - explaining why thickness had an outsized effect without being
   the actual root cause.
2. `FNexusDebugRenderSnapshot::Refresh()` and `FNexusDiagnostics::GatherDiagnostics()` each
   independently rebuilt their own fresh `FNexusRepresentationGraph` (adjacency rebuild)
   every 0.25s, forever, regardless of whether Debug was visible at all - two full,
   redundant rebuilds per cycle for the same `ActiveConfig`.
3. `FNexusRepresentationGraph::ComputeJunctionType` re-issued live `GetLiveLocation` reads
   for a point AND every one of its neighbors, even though the exact same locations had
   already been resolved earlier in the very same `Refresh()` pass. Its neighbor lookup
   (`GetPointNeighbors` -> `TArray::IndexOfByKey`) was O(PointsOnHighway) per call, making
   a full classification pass over one H-point Highway cost O(H^2), redone from scratch
   every refresh. This ran even when nothing visible reads `JunctionType` (only one leaf,
   `Mapping.HighwayPointIdLabels`, ever does).
4. V0 comparison confirmed the fix direction: V0's `FRoadGraphPrimitiveDraw` submits via
   `PDI->DrawLine` directly from an `FEdMode::Render()` callback (once per viewport per
   real frame, with `IsLocationVisible`/distance-LOD culling BEFORE any curve work); V6
   goes through the global `DrawDebugLine`/`ULineBatchComponent` path from a
   `TickableEditorObject::Tick()`, with zero culling anywhere in the Landscape/Roads
   renderers before this fix (Phase 34's own `FNexusDebugLOD` utility existed but was only
   wired into one pilot leaf, `Roads.LaneDirection`).

## Changes

**Representation graph** (`Public/Representation/NexusRepresentationGraph.h`,
`Private/Representation/NexusRepresentationGraph.cpp`,
`NexusRepresentationGraph.JunctionResolver.cpp`, `NexusRepresentationGraph.Queries.cpp`):
- New `HighwayPointIndexByHighway` (`TMap<FGuid, TMap<FGuid,int32>>`), incrementally
  maintained by `AddHighway`/`AddPointToHighway` - `GetPointNeighbors` now does an O(1)
  double-lookup instead of `TArray::IndexOfByKey`'s O(H) scan, with the old scan kept as a
  defensive fallback only.
- New `ComputeJunctionType(highwayPointId, const TMap<FGuid,FVector>& resolvedLocationCache)`
  overload (and a `GatherNeighborDirections` overload taking the same optional cache) -
  reads already-resolved locations instead of re-issuing live reads, falling back to a
  live read for anything missing from the cache. The original single-arg overload is
  **untouched** - Generation's `FNexusJunctionMeshSelector` and the
  `Nexus.Representation.DumpJunctionClassification` console command keep calling it,
  unaffected. The actual classification switch (DeadEnd/Straight/Corner/SmoothCorner/
  TJunction/CrossJunction/MultiJunction) was factored into one shared
  `ClassifyFromNeighborDirections` helper so both overloads apply identical rules.

**Debug render snapshot** (`Public/Debug/NexusDebugRenderSnapshot.h`,
`Private/Debug/NexusDebugRenderSnapshot.cpp`):
- `Refresh()` now takes the caller's already-built `FNexusRepresentationGraph`, the
  already-resolved `ALandscape*`, and a `needsJunctionClassification` bool - no longer
  builds its own graph or resolves the Landscape itself.
- New `FNexusDebugSnapshotCurveSample { Location; RightVector; }` and
  `FNexusDebugSnapshotSegment::CurveSamples` - the Hermite curve (12 subdivisions) is
  sampled and each sample's perpendicular "right" vector computed **once per refresh**,
  not once per Tick per renderer. New `FindSegmentCurveSamples(pointAId, pointBId, ...)`
  returns these in the caller's requested order (reversing + negating RightVector when the
  native segment's stored order runs the other way, mirroring `FindSegmentTangents`' own
  reversal handling).
- `FNexusDebugSnapshotHighway` gained `BoundsCenter`/`BoundsExtent` (AABB over the
  Highway's resolved member points, computed once per refresh) - the LOD candidate every
  Landscape.Segments/Roads.Highways/Lanes/Sidewalks renderer now builds from.
- `JunctionType` is only actually computed (second pass, after every point's location is
  resolved) when `needsJunctionClassification` is true - otherwise left at its default.

**Diagnostics** (`Public/Debug/NexusDiagnostics.h`, `Private/Debug/NexusDiagnostics.cpp`):
- `GatherDiagnostics` gained an optional `const FNexusRepresentationGraph* prebuiltGraph`
  parameter - reuses the caller's graph instead of always building its own.

**Subsystem** (`Public/Subsystem/NexusFrameworkSubsystem.h`,
`Private/Subsystem/NexusFrameworkSubsystem.cpp`):
- New public `MarkRepresentationDirty()` + private `bRepresentationDirty` (default true).
- `RefreshDiagnosticsIfDue()` and `DispatchDebugRenderers`'s own inline snapshot-refresh
  block replaced by one shared `RefreshRepresentationIfDue()`: resolves the Landscape once,
  builds one `FNexusRepresentationGraph`, calls `RenderSnapshot.Refresh(...)` and
  `FNexusDiagnostics::GatherDiagnostics(...)` from that same graph/landscape. Runs when
  `bRepresentationDirty` is set OR the existing `RefreshIntervalSeconds` (0.25s) safety-net
  poll has elapsed - the poll remains because this plugin has no direct hook into a user
  dragging a raw Landscape spline control point in Landscape Mode's own spline tool.
- New `NeedsJunctionClassification()` - true only when `Mapping.HighwayPointIdLabels` is
  actually visible (`IsVisible` + `ShouldShowLabel` + not any-ancestor-hidden), matching
  that leaf's own full gating.

**Landscape group renderer** (`Private/Debug/NexusDebugLandscapeGroupRenderers.cpp`):
- `RenderSegments` now builds one `FNexusDebugLODCandidate` per Highway (from its cached
  bounds) and calls `FNexusDebugLOD::SelectLOD` once, BEFORE any per-segment work - a
  Culled Highway is skipped entirely; an Impostor one draws a single straight line per
  segment; FullDetail reads `FindSegmentCurveSamples` (no more per-Tick
  `SampleHermiteCurve` call in this file at all).

**Roads group renderer** (`Private/Debug/NexusDebugRoadsGroupRenderers.cpp`):
- New shared `SelectHighwayLOD` helper (same per-Highway LOD candidate pattern) used by
  `RenderHighways`/`RenderLanes`/`RenderSidewalks`.
- `DrawOffsetPolyline` takes the resolved `ENexusDebugLODState` for its Highway: Culled
  callers never call it; Impostor draws one straight offset line; FullDetail reads cached
  `CurveSamples` (`sample.Location + sample.RightVector * lateralOffset`) instead of
  resampling Hermite + recomputing right-vectors via finite difference every Tick.

**Mutation call sites** (`Private/UI/SNexusHierarchyPanel.cpp`,
`Private/UI/SNexusDetailsPanel.cpp`):
- `MarkRepresentationDirty()` added to `HandleCreateState/City`, `HandleDeleteState/City/
  Highway`, `HandleAssignCityToState/HighwayToCity`, `HandleResyncFromLandscapeClicked`,
  `HandleConfigAssetPostEditUndo` (unconditional - an undo/redo can revert anything, no
  cheap way to know what), and `SNexusDetailsPanel::OnDetailsViewFinishedChangingProperties`
  for `HierarchyEntity` edits.
- **Deliberately NOT added** to `HandleCreateActivationPoint`/`HandleDeleteActivationPoint`,
  nor to the Details panel's edit-commit path when `target.HierarchyItemType ==
  ActivationPoint` - an Activation Point has no effect on Landscape/Highway/HighwayPoint
  geometry or junction classification (the user's own explicit requirement).

## Verification

Build-only (`AGENT-RULES.md`'s Agent Testing Policy) - editor closed first (confirmed via
`tasklist`):
```
Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject
```
Succeeded first attempt, 17 actions, ~13s.

No in-editor verification performed or possible from this agent. **User should verify**:
- `Debug > Landscape > Segments` enabled - editor interaction (viewport orbit, window
  switching, entity creation) should feel substantially smoother than before this pass,
  approaching the "reasonably smooth idle" baseline already established.
- Visual output unchanged - Segments/Highways/Lanes/Sidewalks should still curve-follow
  the real Landscape spline exactly as before (only the CPU path changed, not the sampled
  geometry itself) at default LOD settings (every category still defaults to
  `FullDetailDistance = -1`, i.e. LOD off/FullDetail-always, same as every category since
  Phase 34 - this pass does not change any category's default visual behavior).
- The three-way Activation Point A/B/C test from the user's own request: Debug OFF + Add;
  Debug ON + Segments OFF + Add; Debug ON + Segments ON + Add - none should force a
  Landscape segment rebuild, since `MarkRepresentationDirty()` is never called from the
  ActivationPoint create/delete/edit paths.
- Root Debug checkbox / individual category toggles still work exactly as before (no
  change to `FNexusDebugCategoryRegistry`/`IsAnyAncestorHidden`).
- `Mapping.HighwayPointIdLabels` (if enabled) still shows correct Straight/Corner/
  TJunction/etc. classification text - confirms the conditional-classification /
  cache-aware `ComputeJunctionType` overload didn't change the classification RESULT,
  only when/how often it's computed.

## Result

`Landscape.Segments` (and `Roads.Highways/Lanes/Sidewalks`) no longer resample Hermite
curves or recompute offset-polyline geometry every Tick - that work now happens once per
Representation refresh (dirty-triggered or the 0.25s safety-net poll) and is cached;
per-Tick rendering is now pure "read cached points, submit draw calls." `FNexusDebugLOD`
(previously wired into only one pilot leaf) is now also wired into the four
highest-primitive-count leaves, defaulting to off (FullDetail-always) per the existing
Phase 34 opt-in convention - the user can enable actual distance culling per-leaf via the
Details panel. Junction classification only runs when a visible consumer needs it, uses
O(1) neighbor lookups instead of O(H) per call, and reuses already-resolved locations
instead of re-reading live geometry a second time. Diagnostics and the Debug snapshot now
share one Representation graph + one Landscape resolve per refresh instead of two of each.
Activation Point mutations are explicitly isolated from all of the above via
`MarkRepresentationDirty()`'s selective call sites.

## Important Notes

- **PDI migration was explicitly deferred, not attempted.** The user's own instructions
  allowed this ("If PDI migration is too invasive for this pass, first make the current
  renderer cached + culled, but keep the design ready for PDI migration"). Investigated:
  V6 deliberately does not own a custom `FEdMode`/mode-level `Render()` callback -
  `FNexusLandscapeModeExtension` only extends the BUILT-IN Landscape Mode via tab-spawning
  and the Interactive Tools Framework (`GetInteractiveToolsContext()`, Phase 48's own
  "reachable without a custom mode" finding) specifically to avoid the old custom-EdMode/
  Landscape-Mode conflict the user referenced. No mode-agnostic PDI hook was identified
  with confidence in the time available for this pass - true view-frustum culling (V0's
  `IsLocationVisible`) is therefore still unavailable; only the distance-based
  `FNexusDebugLOD` approximation (camera location only, no frustum) is wired in. This
  remains the next real architecture step if the cached+culled fix in this pass isn't
  sufficient on its own.
- **LOD defaults intentionally unchanged (opt-in, per Phase 34's own established
  convention)** - every category (including the four just wired) still defaults
  `FullDetailDistance = -1`/`DebugRadius = -1`/`MaxFullDetailObjects = -1`, meaning every
  Highway still draws at full detail regardless of camera distance UNLESS the user
  configures these fields via the Debug category's own Details-panel config. This pass
  delivers the LOD *mechanism*, not a new default visual behavior - flagged explicitly so
  "why didn't distant segments disappear" isn't a surprise.
- **Line thickness was not reduced anywhere** (`FNexusDebugRenderConfig::LineThickness`
  defaults untouched, including `Roads.Highways`/`Roads.Lanes`'s own much-larger 10.0/8.0
  defaults) - per the user's own explicit "do not use line thickness reduction as the
  actual fix" instruction. The engine-source-confirmed thick-line cost
  (`BatchedElements.cpp`'s `ThickLines` path, 4 triangles/12 vertices per line vs. 2 raw
  vertices at `Thickness == 0`) still applies per line drawn; this pass reduces HOW MANY
  lines get drawn/resampled per frame, not the per-line cost itself. Line thickness
  remains a valid secondary lever the user already has via the Details panel.
- **Serialization risk**: no `UPROPERTY` was renamed, removed, or had its type changed -
  every change in this pass is either a new field/overload (additive) or an internal
  C++-only implementation change (private members, function bodies, parameter lists on
  non-UFUNCTION C++ methods). `v6-coding-standard.md`'s renaming/redirect concern does not
  apply.

## Follow-up — 2026-08-10 — idle-poll fix, `-1` semantics correction, and remaining debt

The user asked for a second pass: (1) confirm the four high-count categories' *effective*
resolved LOD config, explicitly correcting "`-1` = disabled" to "`-1` = inherit" per this
project's general convention; (2) make `RefreshRepresentationIfDue` truly dirty-driven
instead of unconditionally rebuilding every `RefreshIntervalSeconds` while idle; (3) verify
cache granularity (does one HighwayPoint change rebuild every Highway's curve samples?);
(4) verify line-thickness cost with concrete numbers; (5) re-test guidance. Investigated all
five before making further changes, per the user's own "before implementation, explicitly
report" instruction.

### Finding: two different `-1` conventions exist in this codebase, and they were conflated

`NexusInheritance::ResolveInheritedValue` (`Inheritance/NexusInheritanceResolver.h`) is a
real project-wide chain: `-1 = inherit (walk to the next-less-specific level, ending at a
Global value)`, `0 = explicitly disabled`, any other value = an explicit override. It backs
`FNexusHighway`/`FNexusCity`/`FNexusState`'s `HalfWidth`/`LaneWidth`/`SidewalkWidth`/
`LaneCount`/`CornerSharpDetectionAngleDegrees` fields (Highway -> City -> State -> Global).

`FNexusDebugRenderConfig`'s own Phase 34 fields (`DebugRadius`/`FullDetailDistance`/
`LabelMaxDistance`/`MaxFullDetailObjects`) reuse the same `-1` SENTINEL VALUE but under a
different, independently-documented convention: `-1 = this specific mechanism is off/
unlimited for this category`, not "inherit from a Global tier" - confirmed directly from
that field's own pre-existing header comments (`NexusDebugRenderConfig.h`, written at Phase
34's original implementation, unrelated to this session). There is currently **no Global
Debug Performance config tier at all** - `FNexusDebugCategoryRegistry` gives every
registered category (`Landscape.Segments`, `Roads.Highways`, etc.) its own fully independent
`RuntimeConfig`, seeded once from that category's own `DefaultConfig` at registration; a
parent category's `ParentCategoryId` only drives visibility cascading
(`IsAnyAncestorHidden`), never a numeric-field fallback. So "inspect the existing global/
category config resolution and preserve this inheritance design" does not apply to these
four fields as literally stated - no such design exists for them today to preserve. This
was reported back to the user as a clarifying question (build a real Global Debug
Performance tier wired through `NexusInheritance::ResolveInheritedValue`, vs. keep today's
simpler per-category-DefaultConfig-only model and just tune those defaults) rather than
guessed at, since it is a real, unrequested architecture fork either way.

### Finding: effective resolved LOD config for the four high-count categories (before any
default-tuning)

All four currently resolve to the SAME effective values, since none has ever overridden
these fields beyond registration-time `Color`/`LineThickness`:

| Category | LineThickness | DebugRadius | FullDetailDistance | LabelMaxDistance | MaxFullDetailObjects |
|---|---|---|---|---|---|
| `Landscape.Segments` | 2.0 (struct default) | -1 (uncapped) | -1 (LOD off - always FullDetail) | -1 (n/a, no labels) | -1 (unlimited) |
| `Roads.Highways` | 10.0 (registration override) | -1 | -1 | -1 | -1 |
| `Roads.Lanes` | 8.0 (registration override) | -1 | -1 | -1 | -1 |
| `Roads.Sidewalks` | 2.0 (struct default) | -1 | -1 | -1 | -1 |

Per Phase 34's own documented meaning, this means: **culling/LOD is effectively OFF for all
four categories out of the box** - every Highway draws every segment at full detail
regardless of camera distance or count, confirming the "opt-in, off by default" note from
this file's original pass above was accurate but is also the reason a large map still has
no default protection.

### Change: `RefreshRepresentationIfDue` idle-poll fix (implemented, build-verified)

`RefreshRepresentationIfDue` still ran the FULL rebuild (graph + snapshot + diagnostics)
every time `RefreshIntervalSeconds` (0.25s) elapsed, dirty or not - i.e. roughly 4 full
rebuilds/second forever while the editor sat idle, exactly the "no periodic idle hitch"
requirement this call was made to satisfy but hadn't yet. Fixed by adding
`FNexusLandscapeReader::ComputeLandscapeRevisionFingerprint(const ALandscape*)` - an O(control
points + segments) hash over each control point's raw `Location`/`Rotation` and each
segment's raw `TangentLen` values only (no world-transform resolution, no graph/curve work).
`RefreshRepresentationIfDue` now: if `bRepresentationDirty` is already true (an explicit
mutation), rebuild immediately as before; otherwise, when the poll cadence elapses, compute
only this cheap fingerprint and compare it (plus the resolved `ALandscape*` identity) against
the last-known value - only promote to a real dirty rebuild if it actually changed. If
neither the dirty flag nor the poll cadence apply, the function now returns before even
resolving the Landscape. This is the literal "poll -> cheap change/revision check -> if
changed, mark dirty -> then rebuild" shape the user asked for, catching the one remaining
untracked mutation source (a raw Landscape Spline control-point/tangent drag in Landscape
Mode's own tool) without paying for a full rebuild every time the poll fires.

Files: `Reader/NexusLandscapeReader.h`/`.cpp` (new `ComputeLandscapeRevisionFingerprint`),
`Subsystem/NexusFrameworkSubsystem.h`/`.cpp` (`RefreshRepresentationIfDue` rewritten,
2 new private members: `LastLandscapeRevisionFingerprint`, `LastResolvedLandscape`).

### Change: default LOD/culling values for the 4 high-count categories (user-confirmed)

Presented the user with a fork: build a real Global Debug Performance config tier wired
through `NexusInheritance::ResolveInheritedValue` (Category -> Global, matching the
Highway/City/State chain exactly), vs. keep today's simpler per-category-`DefaultConfig`
model and just tune those defaults (still user-overridable per-category, no new
architecture). User chose the latter (2026-08-10, "Tune per-category defaults only
(Recommended)"). Applied the same three values to all four categories, since all four
render at Highway-level LOD granularity (one `FNexusDebugLODCandidate` per Highway's own
AABB, not per-segment/per-point):

- `DebugRadius = 150000.f` (1.5km) - outer hard cull, beyond which nothing draws at all.
- `FullDetailDistance = 30000.f` (300m) - inside this, full curve/offset detail; beyond it
  (but inside DebugRadius) draws a cheap straight impostor line instead.
- `MaxFullDetailObjects = 200` - per-frame cap on full-detail Highways, closest-first.

Not applied to `Roads.Junctions` (point-level, not Highway-level) or `Roads.LaneDirection`
(already has its own tuned Phase 34 pilot values: 1500/800/150). These are estimated,
reasonable-for-a-massive-city-editor defaults, not measured-and-tuned numbers (no in-editor
profiling was possible - AGENT-RULES.md's Agent Testing Policy) - flagged so they read as a
starting point the user can retune from the Details panel, not a benchmarked final answer.
Every value remains a per-category override, same as before this change.

Files: `Debug/NexusDebugLandscapeGroupRenderers.cpp` (new `MakeSegmentsCategory`),
`Debug/NexusDebugRoadsGroupRenderers.cpp` (new `ApplyHighwayLevelLODDefaults`, applied to
`Roads.Highways`/`Roads.Lanes`/`Roads.Sidewalks`).

### Verified: line-thickness cost (not changed - recommendation only, per explicit instruction)

Confirmed concrete numbers via UE 5.8 engine source (unchanged from the original pass's own
finding, just quantified per-category here): `Landscape.Segments`/`Roads.Sidewalks` default
`LineThickness = 2.0`, `Roads.Highways = 10.0`, `Roads.Lanes = 8.0`. Any non-zero thickness
takes `FBatchedElements`' `ThickLines` path (`BatchedElements.cpp`): 4 triangles / 12
vertices per line segment plus per-vertex clip-space transform + near-plane-clip math on the
render thread, regardless of the thickness VALUE (2.0 and 10.0 cost the same vertex/triangle
count - the difference is GPU fill-rate/overdraw from the wider quad, not primitive count).
Only `Thickness == 0.0` drops to the cheap 2-raw-vertex path. Not changed here - the user's
own repeated explicit instruction across this investigation ("do not use line thickness
reduction as the actual fix" / "Do not blindly change settings") and `Roads.Highways`/
`Roads.Lanes`'s own documented deliberate-visibility reasoning (hot pink/gold, "loudest
color in the group" for eyeball-verification) both argue against silently lowering these.
Recommendation only: if the LOD/culling defaults above are not sufficient on very large
maps, `Roads.Highways`/`Roads.Lanes` are the next lever (10.0/8.0 -> ~3-4 would cut overdraw
substantially while staying visually distinct from the group's grey 2.0 default) - left as
the user's own call via the Details panel, not applied.

### Build

Succeeded, 6 actions (~14s), first attempt for this change.

### Confirmed remaining scalability debt (not fixed this pass, reported as asked)

`FNexusDebugRenderSnapshot::Refresh()` still rebuilds **every** Point/Segment/Highway from
scratch on every call - there is no per-Highway or per-HighwayPoint dirty tracking. Changing
one HighwayPoint's location currently forces a full re-sample of every Highway's curve
geometry in the whole map, not just the affected Highway(s). `MarkRepresentationDirty()` is
a single global flag, not a per-entity dirty set. Fixing this properly means turning the
dirty flag into a per-entity (or per-Highway) dirty set threaded through every mutation call
site (`SNexusHierarchyPanel`/`SNexusDetailsPanel`) and a snapshot `Refresh` that can patch
just the affected Highways in place - a real architecture change, not attempted in this pass
per the user's own "report it clearly as remaining scalability debt" instruction rather than
implement speculatively.

### Build-only note (not a design finding)

Two build errors surfaced while compiling this follow-up, both fixed: (1)
`GetTypeHash(FRotator)` has no overload in UE 5.8 - hashed `Pitch`/`Yaw`/`Roll` individually
instead; (2) a genuine pre-existing name collision from the ORIGINAL pass above - both
`NexusDebugRoadsGroupRenderers.cpp` and `NexusDebugRenderSnapshot.cpp` independently defined
an identically-named, identically-signatured anonymous-namespace `ComputeRightVector`
helper, which only breaks when Unreal's Unity build merges both into one translation unit
(each file alone compiles fine) - the first build after the original pass happened not to
hit this Unity grouping; this one did. Fixed by renaming the snapshot's copy to
`ComputeCurveSampleRightVector`. Build: **Succeeded**, 6 actions (~14s), second attempt.
