# Debug Tree color/thickness settings silently lost on editor restart

Date: 2026-08-10
Category: bug-fixed
Phase: phases/26 (revision)

## Context

Immediately after reporting the location/curve debug-rendering fixes as working, and
right after this session's own config-asset dirty/undo/auto-save scoping work
(`others/config-asset-dirty-undo-autosave-scoping.md`, new `phases/phase-26a.md`), the
user reported: "I have setup the Debug tree view value (color, thinkness) restart engine
the config dsiaparing." — a Debug Tree color/thickness edit doesn't survive an editor
restart.

## Problem / Goal

Find out why a Debug category edit (color/thickness, set via the Details panel) is lost
on restart, and fix it.

## Findings

1. **This is exactly Phase 26's own original completion criterion, and it was failing**
   — `phase-26.md`'s own "To check" steps for "survives an editor restart" always
   required the user to manually run `Nexus.Mapping.SaveConfig` before restarting.
   Nothing in the UI ever prompted for this or did it automatically - if the user (as
   here) just edited the value and restarted, the change was gone.
2. **Root cause, confirmed by reading the actual edit path**: a Debug Tree edit only
   ever writes into `FNexusDebugCategoryRegistry::RuntimeConfigs` — a process-lifetime
   Meyer's-singleton `TMap`, not a UObject, not part of `UNexusConfigAsset` at all. That
   data is only ever copied into `ConfigAsset->DebugCategoryConfigs` (the actually-
   persisted field) inside `FNexusConfigAssetIO::SaveConfigAsset` — which, before this
   fix, only ever ran from the explicit `Nexus.Mapping.SaveConfig` console command or the
   asset's initial creation. Nothing marked the asset dirty on an edit either, so even
   this same session's brand-new `HandlePostSaveWorld` auto-save-on-level-save hook
   (`phase-26a`'s already-implemented half) wouldn't have caught it — the package was
   never dirty in the first place.
3. **Directly connects to, but is distinct from, Phase 26a's remaining scope** — Phase
   26a tracks real Ctrl+Z/Ctrl+Y support for this same edit surface (deliberately
   deferred, real crash risk per V5's own history if rushed). This bug is about data
   LOSS, not missing undo - a much lower-risk, immediately fixable gap: sync-on-edit +
   dirty-mark-on-edit, no transaction/undo machinery involved at all.

## Changes

- `Private/UI/SNexusFrameworkPanel.h`/`.cpp` — `DetailsView->GetOnFinishedChangingPropertiesDelegate()`
  now bound to new `OnDebugCategoryDetailsFinishedChangingProperties`. New
  `bDetailsViewShowsDebugCategory` bool (set in `OnDebugTreeSelectionChanged`, cleared in
  `OnTreeSelectionChanged`) tells the shared handler whether the just-finished edit was a
  Debug category edit (needs syncing) or a Hierarchy/Placeholder one (Phase 04 stub, not
  real data - nothing to do). On a real Debug-category edit: `ActiveConfig->Modify()`
  then `FNexusDebugCategoryRegistry::SaveRuntimeConfigsToConfigAsset(*ActiveConfig)` -
  the edit is written into the config asset and the package marked dirty the moment the
  edit completes, not only at an explicit Save.
- `project-specifications/phases/phase-26.md` — appended `## Revision` documenting root
  cause + fix; updated the restart-survival criterion's "To check" steps (manual
  `Nexus.Mapping.SaveConfig` is now optional, not required - saving the level or running
  the command either one now works).

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, 0 errors, 5 actions (editor was open at the start of this fix -
  user closed it on request before the build ran, per the standing Live Coding-lock
  process this session always follows).
- **No automated test run/added** — per `AGENT-RULES.md`'s Agent Testing Policy. Manual
  re-verification for the user: change a Debug category's Color/LineThickness, confirm
  the NexusConfig asset shows dirty in the Content Browser immediately (no explicit save
  needed first), then either save the level or run `Nexus.Mapping.SaveConfig`, restart
  the editor, and confirm `Nexus.Debug.DumpCategoryRuntimeConfigs` shows the changed
  value survived.

## Result

Debug Tree color/thickness/font-size/label/etc. edits now sync into the config asset and
mark it dirty the moment the edit finishes, closing the exact data-loss gap reported.
Real Ctrl+Z/Ctrl+Y for the same edits remains Phase 26a's own tracked, not-yet-
implemented scope.

## Important Notes

- This fix does NOT add undo/redo - it only prevents silent data loss. Phase 26a is
  still the phase to pick up for real Ctrl+Z/Ctrl+Y on these same edits.
- The same `OnFinishedChangingProperties`-binding pattern used here (sync-on-edit-finish
  + `Modify()`) is directly reusable once a real (non-Placeholder) Hierarchy details view
  exists for Highway/City/State/HighwayPoint editing - noted in `phase-26a.md`'s own
  References already.
