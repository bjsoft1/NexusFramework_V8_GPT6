# Details panel crash (EXCEPTION_ACCESS_VIOLATION) — dangling pointer into RuntimeConfigs after a TMap growth

Date: 2026-08-10
Category: bug-fixed
Phase: phases/26 (Correction)

## Context

Directly caused by this same session's own immediately-prior fix
(`debug-category-settings-lost-on-restart.md`): wiring a Debug category Details-panel
edit to call `FNexusDebugCategoryRegistry::SaveRuntimeConfigsToConfigAsset` on every
edit-finished event. The user hit a real, reproducible editor crash almost immediately
after and reported the full callstack unprompted.

## Problem / Goal

Diagnose and fix a `EXCEPTION_ACCESS_VIOLATION reading address 0xffffffffffffffff`
crash, callstack rooted in `FString::AssignRange` <- `FStrProperty::ExportText_Internal`
<- `FPropertyEditor::GetValueAsText` <- deep Slate `Prepass_Internal` recursion - i.e. a
Details-panel widget repaint reading a corrupted/dangling `FString` property.

## Findings

1. **The crash is a Details-panel repaint reading through a stale pointer**, not a
   logic bug in the edited VALUE itself - the callstack is 100% Slate prepass +
   PropertyEditor machinery evaluating a bound property's display text, reading garbage
   memory (`0xFFFFFFFFFFFFFFFF` is a classic "pointer/count read from freed or
   never-written memory" signature).
2. **`SNexusFrameworkPanel`'s Details panel binds directly to a raw
   `FNexusDebugRenderConfig*`** (`OnDebugTreeSelectionChanged`, via
   `FStructOnScope`/`IStructureDetailsView` - Phase 25's own established, reused-from-V5
   pattern) - the address of a VALUE living inside `FNexusDebugCategoryRegistry::
   RuntimeConfigs`, a `TMap<FName, FNexusDebugRenderConfig>` at the time.
3. **The just-added `OnDebugCategoryDetailsFinishedChangingProperties` handler calls
   `SaveRuntimeConfigsToConfigAsset`**, which (by its own existing, correct-for-its-own-
   purpose design) iterates EVERY registered category and calls `GetMutableRuntimeConfig`
   for each one, so a save always captures the full registered set, not just categories
   the user happened to open. For any category not yet touched this session, this
   INSERTS a new entry into the same `RuntimeConfigs` map the Details panel currently
   holds a pointer into.
4. **`TMap::Add` can reallocate the map's backing storage when it grows** - a well-known,
   documented container behavior: growing a `TMap`/`TSet` invalidates every pointer/
   reference previously returned into it, even to unrelated keys. Since dozens of
   categories exist (6 top-level groups + their leaves, more if the Phase 23/24 stress-
   test commands were ever run) and typically only a handful have been "touched" (lazily
   seeded into `RuntimeConfigs`) by the time a user edits one, calling
   `SaveRuntimeConfigsToConfigAsset` for the FIRST time in a session is very likely to
   grow the map - and did.
5. **The Details panel's own pointer, captured in `OnDebugTreeSelectionChanged` BEFORE
   this new sync call, was never re-fetched afterward** - so it kept pointing at memory
   that the map's growth had since freed/relocated. The very next Slate repaint (which
   happens essentially immediately - Slate ticks continuously) read through it and
   crashed.
6. **This is the exact class of bug this project's own V5 lessons already named** - a
   raw struct pointer surviving a container mutation it shouldn't have, same shape as
   V5's own documented `PostEditUndo()` crash (`EXCEPTION_ACCESS_VIOLATION` on repaint
   after Ctrl+Z, from a stale `FStructOnScope` binding) already written up in
   `phases/phase-26a.md`'s own Context section - written down as a cautionary precedent
   BEFORE this specific failure mode (a `TMap` growth, not an undo) actually reproduced
   it in a different form.

## Changes

- `Public/Debug/NexusDebugCategoryRegistry.h` — `RuntimeConfigs` changed from
  `TMap<FName, FNexusDebugRenderConfig>` to `TMap<FName, TUniquePtr<FNexusDebugRenderConfig>>`
  - growing/rehashing the map only ever moves the small `TUniquePtr` handles, never the
  `FNexusDebugRenderConfig` each one owns, so any raw pointer already handed out (the
  Details panel's included) stays valid no matter what else gets inserted afterward.
  Copy constructor/assignment explicitly deleted (required for this
  `NEXUSFRAMEWORKEDITOR_API`-exported class to compile with a non-copyable `TUniquePtr`
  member - DLL export forces the compiler to try to instantiate the implicit copy
  operations regardless of whether anything calls them; explicitly deleting them avoids
  that instantiation entirely - also just correct design for a singleton).
- `Private/Debug/NexusDebugCategoryRegistry.cpp` — `GetMutableRuntimeConfig`/
  `GetRuntimeConfig` updated for the `TUniquePtr` storage (`.Get()` on the found/
  inserted entry). `RestoreRuntimeConfigsFromConfigAsset` now updates an already-present
  entry's VALUE in place (`**Existing = Pair.Value`) instead of replacing its
  `TUniquePtr` wholesale, for the identical pointer-stability reason.
- `project-specifications/phases/phase-26.md` — appended `## Correction` section (the
  prior same-day `## Revision` is left untouched, append-only); updated the restart-
  survival criterion to also require no crash on the following repaint.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  first attempt **Failed**: `TMap<FName, TUniquePtr<T>>`'s implicit copy-assignment
  operator doesn't compile against a non-copyable `TUniquePtr` value, and this
  `NEXUSFRAMEWORKEDITOR_API`-exported class forced its instantiation regardless of use.
  Fixed by explicitly deleting `FNexusDebugCategoryRegistry`'s copy constructor/
  assignment. Second attempt - **Result: Succeeded**, 0 errors, 9 actions.
- **No automated test run/added** — per `AGENT-RULES.md`'s Agent Testing Policy. Manual
  re-verification for the user: edit a Debug category's Color/LineThickness repeatedly
  (including categories never opened before this session, to exercise the "first touch"
  map-growth path this bug depended on), confirm no crash on repaint, and that the
  earlier restart-persistence fix still works.

## Result

The Details panel's bound pointer into `RuntimeConfigs` is now stable across any future
insertion into that map, closing this specific crash and the entire class of bug it
belongs to (not just this one reproduction). Real Ctrl+Z/Ctrl+Y for these edits remains
Phase 26a's own separate, not-yet-implemented, deliberately-careful scope.

## Important Notes

- This was a same-day, same-session regression introduced by this project's own AI-
  assisted work, caught only because the user actually hit it and reported the full
  callstack unprompted - a reminder that "no automated tests" (this project's own Agent
  Testing Policy) means real user testing is the only net catching this class of bug;
  the fix here (pointer-stable storage) removes the underlying hazard class rather than
  just patching the one reproduction, specifically so a similar future addition doesn't
  reintroduce it.
