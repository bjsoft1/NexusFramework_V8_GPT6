# Bug fix: lettered phases (30a, 41a, etc.) unreachable through the phase-tracker API

Date: 2026-08-10
Category: bug-fixed
Phase: N/A (tooling — `html-docs/server.js`, `html-docs/js/phase-tracker.js`)

## Context

Found live, mid-session, by the user's own use of the phase-tracker UI (not a code
review) — they tried to advance Phase 30a's status ("Debug Rendering — Curve-Accurate
Segment/Offset Lines", currently `Ready for Review`) and got back: `Could not update
phase 30: This phase has been Complete for over 1 hour and is locked from further status
changes.` Phase 30a was never `Complete` — that error is Phase 30's own lock message,
for a phase the user never clicked.

## Finding

Root cause: every phase file's numeric `n` field (`build.js`'s `extractPhases()`,
parsed from `# Phase 30a — ...` via `parseInt("30a", 10)`) drops the letter suffix,
so `phase-30.md` and `phase-30a.md` both report `n: 30` — by design, so they sort/group
together in the tracker list, but that same non-unique number was also being used as
the API routing key. The phase-tracker's dropdown called `setStatus(phase.n, ...)` →
`POST /api/phases/30/status`, and server.js's old `findPhaseFile(id)` matched by
`Number(m[1]) === Number(id)` against every `phase-\d{2,3}...md` file — for id `30` that
matches BOTH `phase-30.md` and `phase-30a.md`, and `Array.find` silently returned
whichever sorted first in the directory listing (`"phase-30.md"` — `.` sorts before
`a`). So editing/viewing phase-30a through the UI was **silently operating on
phase-30.md instead**, for every one of the 7 lettered phase files that exist
(`20a`, `26a`, `30a`, `40a`, `41a`, `60a`, `80a`) — not just the status dropdown, the
"Open phase-NN.md" content popup had the identical bug (`fetch("/api/phases/" +
phase.n + "/content")`).

This is a pre-existing bug, not something introduced by today's status-format refactor
(`phase-status-fixed-line-format-refactor.md`, same date) — found only because that
refactor's own docs-site rebuild put the tracker in front of the user while they were
reviewing Phase 30a specifically.

## Changes

- `html-docs/server.js`: `findPhaseFile(id)` changed from numeric-prefix matching to an
  exact filename-stem match against the phase's own unique `id` (e.g. `"phase-30a"`,
  `"phase-01-core-structures"` — already unique 1:1 per file, unlike `n`). Both
  `POST /api/phases/:id/status` and `GET /api/phases/:id/content` routes changed from a
  `\d+` URL segment to `[a-z0-9-]+` accordingly.
- `html-docs/js/phase-tracker.js`: the status-dropdown's `setStatus()` call and the
  content-popup's `fetch()` call both switched from `phase.n` to `phase.id`. Display-only
  uses of `phase.n` (the "30" badge shown for both Phase 30 and Phase 30a, intentional
  grouping) are unchanged.

## Verification

- `node --check` on both changed files — syntax OK.
- Direct call to the new `findPhaseFile` logic (copied inline, since `server.js` binds a
  port as a side effect of being required and wasn't started) confirmed: `"phase-30"` →
  `phase-30.md`, `"phase-30a"` → `phase-30a.md`, `"phase-41"` → `phase-41.md`,
  `"phase-41a"` → `phase-41a.md` — each resolves to exactly its own file now.
- `node html-docs/build.js` — succeeded after the fix, same output shape as before
  (108 phases, 6 complete).
- **Not verified live in a browser** — no editor/GUI automation available to this agent;
  the user's own next click on Phase 30a's dropdown (or any of the other 6 lettered
  phases) is the real end-to-end confirmation.

## Result

Every lettered phase (`20a`/`26a`/`30a`/`40a`/`41a`/`60a`/`80a`) is now individually
addressable through the tracker's status dropdown and content popup — previously all
seven silently aliased to their base-numbered sibling.

## Important Notes

Landed in the same commit-worth-of-work as `phase-status-fixed-line-format-refactor.md`
(same date) because it was discovered while that refactor's rebuild was live in front of
the user, but it is an independent bug with an independent cause — the id-collision
existed long before today's status-format change and would have misbehaved under the old
single-line status format too.
