# Debug rendering / Diagnostics camera-focus used landscape-space Location as if it were world-space

Date: 2026-08-10
Category: bug-fixed
Phase: touches Representation (Phase 18), Source (Phase 05/09), Mapping (Phase 14/22), Debug (Phase 27/30/31)

## Context

Reported directly by the user during a fresh-build QA pass, right after the pink/gold
high-contrast debug colors (Phase 31 revision) made debug rendering visible again: "Now I
see the landscape segment draw point and sphere... the segment location and landscape
segment actual location is very different not align, around 200-300 meters maybe
different." User also flagged the connecting debug line not following the real Landscape
spline's curve (tracked separately — see `others/` record for the new Phase 30a this
also produced) and referenced that V5 already solved the location half of this ("we draw
from landscape segment center and this is main parent and valid location points").

## Problem / Goal

Find out why debug-rendered points/spheres/lines were offset by ~200-300 (thousand?)
units from the real Landscape geometry, and fix it.

## Findings

1. **Confirmed via the UE 5.8 engine header itself**
   (`Engine/Source/Runtime/Landscape/Classes/LandscapeSplineControlPoint.h`):
   `ULandscapeSplineControlPoint::Location` is documented `/** Location in Landscape-space
   */` and `Rotation` as `/** Rotation of tangent vector at this point (in
   landscape-space) */` — both are relative to the owning `ULandscapeSplinesComponent`
   (a component ON the `ALandscape` actor), NOT world space. If the Landscape actor
   isn't sitting exactly at world origin with identity rotation (the normal case for a
   real level), every raw `->Location`/`->Rotation` read differs from the true world
   position by exactly the Landscape actor's own world transform — matching the user's
   reported 200-300 (thousand-unit) offset precisely.
2. **`FNexusHighwayPoint::GetLiveLocation()`/`GetLiveRotation()`
   (`Public/Representation/NexusHighwayPoint.h`) — the single sanctioned "live read"
   accessor this whole project's architecture funnels through — returned this raw,
   landscape-space value directly**, and its own doc comment even called this out as
   intentional: "the same raw, no-world-transform convention... consistency with the
   rest of the Source stage". That reasoning is correct for Source-stage-INTERNAL math
   (dot-product angle comparisons for junction classification are self-consistent
   within one local space, unaffected by never transforming) but wrong for every
   consumer that hands the value to a WORLD-space API.
3. **`project-specifications/v5-complete-reference.md` independently confirms V5 already
   drew this distinction** — its own subsystem API list names `TryGetPointWorldLocation`/
   `TryGetPointWorldRotation` (line 315-316: "reading landscape-space Rotation
   transformed to world"), i.e. V5 had a dedicated transform step V6's initial port
   dropped.
4. **Every consumer of `GetLiveLocation`/`GetLiveRotation` was silently affected** —
   `FNexusDebugRenderSnapshot::Refresh()` (feeds every Debug-group renderer:
   Landscape/Roads/Mapping), `FNexusActivationPoint` (both header and .cpp),
   `FNexusRepresentationGraph`'s JunctionResolver/Validation/Queries files. Fixing the
   two accessors fixes all of these at once — this is why the project's own "one
   sanctioned live-read path" architecture (04/05-v6 docs) exists.
5. **Three OTHER call sites bypassed `FNexusHighwayPoint` entirely and read
   `ULandscapeSplineControlPoint::Location` raw**, each building a
   `bHasWorldLocation=true` validation entry consumed by the Diagnostics Panel's
   click-to-focus camera jump (`SNexusFrameworkPanel.cpp:354`,
   `FBox::BuildAABB(Item->WorldLocation, ...)`) — meaning double-clicking a Diagnostics
   entry to jump the camera to it was ALSO silently jumping to the wrong place:
   - `NexusLandscapeReader.Validation.cpp` (Phase 09, Source-stage gate) — 3 occurrences.
   - `NexusMapping.Validation.cpp` (Phase 14, Mapping-stage gate, cross-map entry).
6. **A fourth call site computed City centers from the same raw local value**
   (`NexusMapping.CityStateMapping.cpp::ComputeCityCenter`) — not currently rendered
   anywhere visible yet (no `ComputeStateCenter` exists yet either), but fixed for the
   same reason: an unresolved-until-later bug is still a bug.
7. **Fix**: added `FNexusLandscapeReader::TryResolveControlPointWorldTransform` (new,
   `Public/Reader/NexusLandscapeReader.h` / `Private/Reader/NexusLandscapeReader.cpp`) —
   resolves the control point's owning `ULandscapeSplinesComponent` via `GetOuterSafe()`
   (the same "point may have been deleted" -safe accessor Phase 08's
   `IsControlPointOnTargetLandscape` already uses elsewhere), then
   `ComponentTransform.TransformPosition/TransformRotation`. Returns false (no silent
   landscape-space fallback masquerading as world-space) if either the point or its
   outer component doesn't resolve — same resolve-or-fail contract as every other live
   read in this project. `GetLiveLocation`/`GetLiveRotation` now route through this;
   the three raw-Location validation call sites and `ComputeCityCenter` were updated to
   do the same (the last of these was simplified to just call
   `HighwayPoint->GetLiveLocation()` directly, since it already has the resolved
   `FNexusHighwayPoint` in scope).
8. **Source-stage internal math is unaffected and was deliberately left alone** —
   `NexusRepresentationGraph.JunctionResolver.cpp`'s dot-product angle classification
   compares directions that are ALL still landscape-space-consistent with each other
   (or now all world-space-consistent, post-fix, via `GetLiveRotation`) — a uniform
   rotation applied to every vector in a single Dot-product comparison doesn't change
   the angle between them, so this fix doesn't change any classification result, only
   where things are actually drawn/focused in world space. `Nexus.Reader.EnumerateControlPoints`'s
   own console-command log (which explicitly labels its output "raw Location/Rotation")
   was deliberately left untouched — it's a Source-stage diagnostic tool that says
   exactly what it is, not a bug.

## Changes

- `Public/Reader/NexusLandscapeReader.h` — new
  `static bool TryResolveControlPointWorldTransform(const ULandscapeSplineControlPoint*, FVector& OutWorldLocation, FRotator& OutWorldRotation)`.
- `Private/Reader/NexusLandscapeReader.cpp` — implementation (`GetOuterSafe()` +
  `GetComponentTransform()`).
- `Public/Representation/NexusHighwayPoint.h` — `GetLiveLocation`/`GetLiveRotation`
  rewritten to call the new helper instead of returning `Resolved->Location`/`->Rotation`
  raw; doc comments rewritten to explain the fix and link back to this record.
- `Private/Reader/NexusLandscapeReader.Validation.cpp` — the 3 `ControlPoint->Location`
  reads (Phase 09 gate) now resolve world location once per control point via the new
  helper and reuse it across all of that point's own entries.
- `Private/Mapping/NexusMapping.Validation.cpp` — the cross-map entry's `Resolved->Location`
  read now goes through the new helper.
- `Private/Mapping/NexusMapping.CityStateMapping.cpp` — `ComputeCityCenter` now calls
  `HighwayPoint->GetLiveLocation()` instead of reading `SourcePoint.LoadSynchronous()->Location`
  raw; removed the now-unused `LandscapeSplineControlPoint.h` include.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` —
  **Result: Succeeded**, 0 errors, 24 actions.
- **No automated test run/added** — per `AGENT-RULES.md`'s Agent Testing Policy. Manual
  re-verification for the user: re-tick any Debug Tree category (Landscape or Roads
  group) on the same map that showed the 200-300m offset, confirm points/spheres/lines
  now sit directly on the real Landscape spline geometry; double-click a Diagnostics
  Panel entry with a location and confirm the viewport camera jumps to the real point,
  not an offset one.

## Result

`FNexusHighwayPoint::GetLiveLocation`/`GetLiveRotation` — the project's own single
sanctioned live-read path — now returns true world-space values, fixing every debug
renderer, the Diagnostics Panel's click-to-focus, and City-center computation in one
change. The connecting-line-doesn't-follow-the-curve half of the user's report is a
separate, genuinely new feature (not a regression — both existing renderers documented
straight-line drawing as deliberate scope) — tracked as new Phase 30a, not fixed here.

## Important Notes

- If a future phase adds more raw `ULandscapeSplineControlPoint`/`Rotation` reads for
  anything that ends up in a world-space context (a marker, a camera jump, a spawn
  transform), it must go through `TryResolveControlPointWorldTransform` (or
  `FNexusHighwayPoint::GetLiveLocation`/`GetLiveRotation` if a resolved
  `FNexusHighwayPoint` is already in scope) — raw `->Location`/`->Rotation` is
  landscape-space by engine contract, never assume otherwise again.
- See `others/phase-30a-inserted-curve-accurate-debug-lines.md` for the companion new
  phase this same report produced.
