# Bug: closed Landscape spline loop still renders with an open gap

Date: 2026-08-10
Category: bug-fixed
Phase: 11 (Highway Membership), 16 (Reconciliation) — no phase file changed, this is a
targeted bug fix within their existing scope.

## Problem

User closed a Landscape spline chain into an oval (connected the last control point back
to the first), but the Debug Tree's Landscape → Segments rendering still showed it as
open — the line closing the gap never appeared.

## Root cause

Not a rendering bug. `FNexusDebugLandscapeGroupRenderers.cpp`'s `RenderSegments` and the
underlying `FNexusHighway::IsClosedLoop`/wraparound-index logic are correct. The actual
cause: `FNexusMapping::MapHighways` (Phase 11) is append-only — its idempotency guard
(`IsChainAlreadyMapped`) only skips a chain that's an *exact* re-discovery of an existing
Highway's `OrderedPointIds`; it never updates an *existing* Highway's `OrderedPointIds`/
`IsClosedLoop` when live Landscape topology changes under it. The user's Highway was
mapped while the chain was still open (`IsClosedLoop=false`, correct at the time); once
they closed the loop natively, nothing re-derived that already-existing entry. Phase 16's
`ReconcileMappingStage` already *detects* this exact mismatch
(`DoesHighwayChainMatchLiveLandscape`) and logs a `[BROKEN]` warning, but never acts on
it — and there was no way to remove the stale entry either (`UNexusConfigAsset::Highways`
is `VisibleAnywhere` but not `EditAnywhere`, so not editable from the Details panel; no
console command existed to remove one).

## Fix

Added `FNexusMapping::RemoveHighwaysNotMatchingLiveLandscape` (`NexusMapping.h`,
implemented in `NexusMapping.Reconciliation.cpp`) — reuses the existing
`ComputeHighwaysNotMatchingLiveLandscape` detection, removes exactly those Highways
(`config.Highways.RemoveAll`), returns the count. New console command
`Nexus.Mapping.RemoveStaleHighways`: removes stale Highways then immediately re-runs
`MapHighways` so the same still-valid points regenerate into a fresh, topology-correct
Highway (correctly `IsClosedLoop=true` for a genuinely closed loop) in one step.

Deliberately distinguished from the existing "never silently drop" `BrokenEntries` rule
(`ReconcileMappingStage`'s own comment) — that rule covers a `HighwayPoint` whose
`SourcePoint` stopped resolving (real data loss risk). A stale-but-fully-resolvable
Highway is provably outdated topology, not broken data — removing and letting
`MapHighways` regenerate it from the same valid points is a repair, not a drop. Still
kept explicit/user-invoked/fully logged (never automatic), consistent with that rule's
spirit.

## Changes

- `Source/NexusFrameworkEditor/Public/Mapping/NexusMapping.h` — new
  `RemoveHighwaysNotMatchingLiveLandscape` declaration.
- `Source/NexusFrameworkEditor/Private/Mapping/NexusMapping.Reconciliation.cpp` —
  implementation + `Nexus.Mapping.RemoveStaleHighways` console command.

## Verification

- Compiled via Unreal Editor Live Coding (user-triggered, `Ctrl+Alt+F11`) — confirmed via
  a subsequent `Build.bat` invocation reporting `Target is up to date` (0 actions), i.e.
  Live Coding had already picked up and successfully compiled the change.
- **Not yet run against real data** — the user still needs to run
  `Nexus.Mapping.RemoveStaleHighways` on their own closed oval and confirm the Debug Tree
  now shows it closed. No automated test added, per `AGENT-RULES.md`'s Agent Testing
  Policy.

## Important Notes

- This fix only removes Highways that are stale in this specific "topology no longer
  matches" sense. It does not touch `HighwayPoint`/`SourcePoint` broken-reference entries
  — those remain governed by the existing "never silently drop" rule, untouched by this
  change.
- If a stale Highway happens to be referenced by something else added later (e.g. a
  future Activation Point anchored to it), removing it would orphan that reference - not
  a concern as of this fix (no such referencing system exists yet), but worth checking
  before reusing this command once Activation Points (Phase 45+) exist.
