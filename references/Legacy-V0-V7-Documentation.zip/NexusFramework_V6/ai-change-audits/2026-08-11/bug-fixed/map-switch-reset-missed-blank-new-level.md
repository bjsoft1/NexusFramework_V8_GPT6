# Map Switch Reset Missed Blank "New Level"

Date: 2026-08-11
Category: bug-fixed
Phase: N/A (ad-hoc, `agent-todos/ready-for-review/when switch landscape still trigating old landscape.md`)

## Context

Direct follow-up to the same-day `nexus-not-ready-ready-initialization-state-machine.md`
task. That task built `UNexusFrameworkSubsystem`'s Not-Ready/Ready gate and bound its one
reset trigger (`HandleMapOpened`) to `FEditorDelegates::OnMapOpened`, explicitly claiming
it as "the precise signal for a map/level load or switch happened." Its own manual
verification checklist included "open a second/different level, confirm Not Ready
re-triggers" - the user tried this for real and reported the old level's debug/rendered
data could still remain visible in some cases, re-opening the `agent-todos` report with a
much more detailed 15-point spec ("Bulletproof Nexus Level/Map Switch Reset").

## Problem / Goal

Confirm (or rule out) that `OnMapOpened` really is broadcast for every way a user can
switch levels in the editor, since the user's repro showed the reset sometimes not
happening.

## Findings

Read the relevant UE 5.8 engine source directly rather than assuming the prior claim
still held:

- `FEditorFileUtils::LoadMap` (`FileHelpers.cpp`) is the only function that broadcasts
  `FEditorDelegates::OnMapOpened` (`OnMapOpened.Broadcast(InFilename, LoadAsTemplate)`,
  fired at the very end, after the map has fully loaded).
- `ULevelEditorSubsystem::NewLevelFromTemplate()` calls `FEditorFileUtils::LoadMap()` -
  covered, `OnMapOpened` fires correctly for a template-based new level.
- `ULevelEditorSubsystem::NewLevel()` (File > New Level > **Empty Level** - a genuinely
  blank level, no template) calls `GEditor->NewMap()` directly (`UEditorEngine::NewMap`,
  `EditorServer.cpp`) - this path **never** calls `FEditorFileUtils::LoadMap` and
  therefore **never** broadcasts `OnMapOpened`. It only broadcasts
  `FEditorDelegates::MapChange(MapChangeEventFlags::NewMap)`.
- `MapChangeEventFlags::NewMap` is also broadcast during a **normal** Open Level too (from
  inside the "MAP LOAD" exec command handler `UEditorEngine::HandleMapCommand`,
  `EditorServer.cpp` line ~2726) - alongside `OnMapOpened`, not instead of it. So
  `MapChange`'s `NewMap` flag is a strict superset of the switch events `OnMapOpened`
  covers, not an independent/different set.
- Every other requirement in the new, detailed task spec (debug/rendered data clearing,
  Tree/Details/Diagnostics clearing, no implicit auto-Re-sync, no stale
  UObject/Actor/Landscape pointers, repeated-switch safety with no duplicated delegates/
  primitives) was traced end-to-end and already correctly implemented by the prior
  Not-Ready/Ready state machine task - `RefreshRepresentationIfDue`'s unconditional
  no-ActiveConfig reset branch, `FNexusDebugLabelOverlay::UpdateLabels`'s full-replace
  semantics (called every frame from the always-active `FNexusDebugDrawEdMode::Render`,
  unconditionally, so stale labels are hidden the very next rendered frame regardless of
  `ActiveConfig`), `SNexusHierarchyPanel::HandleNexusReadinessChanged` synchronously
  rebuilding the tree to empty, `SNexusDetailsPanel::RebindToCurrentTarget` clearing
  `StructureData` (not just disabling the widget), and `FNexusEditorProxyPool`'s own
  independent `OnWorldCleanup`/`MapChange` full-teardown handling. The blank-New-Level gap
  was the one genuinely unhandled case.

## Changes

- `Subsystem/NexusFrameworkSubsystem.h/.cpp` - extracted the reset (`SetActiveConfig(nullptr)`/
  `ClearDetailsTarget()`/`SetNexusReady(false)`) out of `HandleMapOpened` into a new shared
  `ResetForMapSwitch()`; added `HandleMapChange(uint32 mapChangeFlags)` bound to
  `FEditorDelegates::MapChange` in `Initialize()` (unbound in `Deinitialize()`), which calls
  `ResetForMapSwitch()` only when `mapChangeFlags & MapChangeEventFlags::NewMap` is set
  (never on a `MapRebuild`/`WorldTornDown`-only broadcast, which is not a level switch).

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development` - succeeded, zero
  errors/warnings.
- Engine-source-verified (not assumed) per the Findings section above.
- **Not manually verified in-editor** - see the `agent-todos` task file's own Important
  Notes for the exact manual repro/verification sequence (this agent cannot launch the
  editor, per `AGENT-RULES.md`'s Agent Testing Policy).

## Result

Fixed. `MapChange`'s `NewMap` flag is a strict superset of what `OnMapOpened` alone
covered, so binding both (with the flag filter on `MapChange`) closes the blank-New-Level
gap without weakening or duplicating logic for the paths that already worked - both
handlers share one `ResetForMapSwitch()` implementation, and firing it twice for one real
Open Level (both delegates broadcasting for the same load) is a harmless no-op.

## Important Notes

- **Scope note, not implemented**: the new task spec's items 8/9/11 (auto-load/create the
  newly-active level's config on switch, before any user click, only deferring the
  Landscape *reconciliation* itself to Re-sync) directly contradicts the Not-Ready/Ready
  state machine's own deliberate design from earlier the same day ("do NOT use
  editor-mode switching - or opening/refreshing a tab - to initialize Nexus"). Flagged in
  the `agent-todos` task file's own Important Notes for an explicit user decision rather
  than silently reintroducing an implicit load trigger. There is currently no "load an
  existing config without also creating one / without also reconciling" primitive in
  `FNexusConfigAssetIO` to implement this without new API surface.
- If the user's original repro that led to this task's re-filing was NOT a blank New
  Level, this fix does not explain it - the manual verification steps in the
  `agent-todos` task file explicitly separate the blank-New-Level case (step 2, the new
  gap) from the already-covered normal Open-Level-to-existing-level case (step 3) so a
  failed step 3 would point to a still-open, different bug.
