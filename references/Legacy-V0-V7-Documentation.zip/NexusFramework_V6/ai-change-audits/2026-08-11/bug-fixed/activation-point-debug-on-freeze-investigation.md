# Activation Point creation freeze when Debug is ON — investigation + trace instrumentation

Date: 2026-08-11
Category: bug-fixed
Phase: N/A (ad-hoc performance investigation)

## Context

User report: Debug root OFF → adding one Activation/Interactive object is smooth. Debug
root ON → adding ONE object freezes the editor for ~1-3 seconds. FPS stays ~120 before/
after (steady-state rendering is unaffected - this session's earlier LOD/culling work,
`ai-change-audits/2026-08-10/bug-fixed/landscape-segments-and-classification-perf.md`, is
explicitly confirmed still working well and was NOT touched this pass). User's own read:
"this looks like a synchronous GameThread/Slate mutation hitch, not normal rendering FPS."
User asked for an exact call-count/timing trace of Debug OFF vs ON for one creation, and
explicitly: "First identify the exact blocking function(s). Do not guess."

Also fixed en route: a genuine build error the user hit (`GNexusSlowSectionThresholdMilliseconds`/
`LogIfSlow` redefinition between `SNexusHierarchyPanel.cpp` and `NexusFrameworkSubsystem.cpp`
under a Unity build) - see its own section below.

## Static trace performed (no editor access - AGENT-RULES.md's Agent Testing Policy)

Traced the FULL call chain for `SNexusHierarchyPanel::HandleCreateActivationPoint` by
direct source reading, checking every step for a branch on Debug visibility
(`FNexusDebugCategoryRegistry::IsRootVisible()`/`IsAnyAncestorHidden()`/any category's
`IsVisible`):

1. `HandleCreateActivationPoint` → `FNexusMapping::CreateActivationPointAtHighwayPoint`
   (`config.Modify()` + `config.ActivationPoints.Add(newPoint)`) - no Debug check.
2. → `PublishHierarchySelection` → `UNexusFrameworkSubsystem::SetDetailsTarget` →
   `OnDetailsTargetChanged.Broadcast()` - exactly ONE bound listener confirmed
   (`SNexusDetailsPanel::RebindToCurrentTarget`) - no Debug check anywhere in this chain.
3. → `RefreshHierarchyTree(true)` → `BuildHierarchyTreeFromConfig` (rebuilds the WHOLE
   State/City/Highway/HighwayPoint/ActivationPoint tree from `config`, every call,
   regardless of what changed - see "confirmed inefficiency" below) → `HierarchyTreeView->
   RequestTreeRefresh()` → `ExpandHierarchyTreeRecursive` → (since the just-created point
   is now the selection) reselect branch → **a SECOND `PublishHierarchySelection` call for
   the exact same (type, id) the caller already published in step 2** - see finding below.
4. `SNexusDetailsPanel::RebindToCurrentTarget` (fired once per broadcast) →
   `FNexusMapping::FindActivationPointById` (linear scan, small array) →
   `DetailsView->SetStructureData(...)`.

Checked and ruled out as Debug-conditional, with evidence:
- `OnGenerateTreeRow` (Hierarchy tree row widget) - a bare `STextBlock`, no Debug registry
  access at all (`SNexusHierarchyPanel.cpp:541-547`).
- The Debug Tree (`DebugTreeView`) - built ONCE at `Construct()`
  (`BuildDebugTreeFromRegistry`); `RequestTreeRefresh()` is never called on it anywhere
  outside construction - confirmed via a repo-wide grep for `DebugTreeView->`. ActivationPoint
  creation does not touch it.
- No custom `IPropertyTypeCustomization`/`IDetailCustomization` is registered ANYWHERE in
  this module (`grep -r "IPropertyTypeCustomization\|IDetailCustomization\|RegisterCustomPropertyTypeLayout\|RegisterCustomClassLayout"` → zero matches) - `SetStructureData` for
  `FNexusActivationPoint` (including its nested `DebugOverride`/`FNexusDebugInstanceOverride`
  field) uses plain generic reflection-based row generation; nothing queries
  `FNexusDebugCategoryRegistry` during Details panel rebuild.
- `UNexusActivationGizmoTool` (`FindClosestSubPointHit`, the one place that iterates
  `FNexusActivationPointTestStore` and checks a category's `IsVisible`/`CanSupportGizmo`) is
  only invoked from `OnIsHitByClick`/`OnClickedInViewport` - a VIEWPORT CLICK, not creation -
  and operates on a separate test store, not `config.ActivationPoints`. Not on the create
  path at all.
- `MarkRepresentationDirty()` - confirmed NOT called anywhere in
  `HandleCreateActivationPoint`/`HandleDeleteActivationPoint` (grep of every
  `MarkRepresentationDirty` call site in the repo). The Landscape/Representation
  snapshot-rebuild machinery from the previous investigation is not implicated.
- No synchronous `SaveConfigAsset`/`SaveRuntimeConfigsToConfigAsset` call anywhere on the
  create path (that call only exists in `SNexusDetailsPanel`'s property-changed handler,
  gated to `DebugCategory` targets, unrelated).
- No synchronous forced-redraw call (`RedrawAllViewports`/`RedrawLevelEditingViewports`/
  `ForceRedraw`) exists anywhere in this codebase (repo-wide grep, zero matches).

**Conclusion of the static trace: no branch anywhere in the ActivationPoint creation call
path checks Debug visibility.** This rules out several of the user's own listed suspects
as literally stated: full Debug Tree reconstruction on create (not triggered - the tree
isn't touched), recursive checkbox-state recalculation on create (Slate `TAttribute`
lambdas are evaluated on PAINT, not on create, and are cheap `IsAnyAncestorHidden` ancestor
walks regardless), all 30-50 categories refreshing on create (`DispatchDebugRenderers` only
runs from `Tick`, unrelated to creation), all ActivationPoints rebuilding (nothing iterates
the full `ActivationPoints` array except the tree-build's per-HighwayPoint filter, see
below), duplicate `ConfigChanged` chain (`OnActiveConfigDataChanged` is not broadcast by
Create at all - only `SNexusDetailsPanel`'s property-commit handler broadcasts it).

## Confirmed findings (not speculative - read directly from source)

1. **Genuine duplicate `PublishHierarchySelection`/`SetDetailsTarget` broadcast per
   creation**, independent of Debug state. `HandleCreateActivationPoint` publishes the new
   selection once, then calls `RefreshHierarchyTree(true)`, whose own reselect branch
   (`SelectedHierarchyEntityId` now equals the new point's id, since the caller just set it)
   finds the same item and republishes it a SECOND time - firing
   `SNexusDetailsPanel::RebindToCurrentTarget`/`SetStructureData` twice for one user action.
   This same `Publish...; RefreshHierarchyTree(true);` pattern exists in every other
   `HandleCreate*`/`HandleAssign*` handler in this file, so it is not
   ActivationPoint-specific either. **Not removed this pass** - the reselect branch's
   republish exists for a real reason (re-resolving the Details panel's bound raw pointer
   after `BuildHierarchyTreeFromConfig`/array mutations that may have reallocated
   `config`'s backing `TArray`s, per that branch's own pre-existing comment), and given no
   custom property customization exists (previous section), a second generic
   `SetStructureData` call on a ~15-field struct is unlikely to be a multi-second cost by
   itself. Flagged, not fixed, pending real timing data (see next section) to confirm
   whether it's worth the risk of touching.
2. **`BuildHierarchyTreeFromConfig` rebuilds the ENTIRE hierarchy tree from scratch on
   every single mutation, anywhere in the hierarchy** - `makeActivationPointChildren`
   does a full linear scan of `config->ActivationPoints` for EVERY HighwayPoint in the
   entire tree (not just the affected one), and `makeHighwayPointChildren` resolves each
   HighwayPoint via `config->HighwayPoints.FindByPredicate` (another linear scan) per point
   per Highway - an O(Highways x PointsPerHighway x TotalHighwayPoints) plus O(TotalPoints x
   TotalActivationPoints) pattern. This is real scalability debt (independent of Debug
   state - it runs identically Debug ON or OFF) but does not by itself explain a
   Debug-conditional freeze on the "tiny dataset" the user described.

Neither of these two real findings is proven to be THE 1-3 second Debug-ON-specific
bottleneck - both would cost the same regardless of Debug state, and this investigation
could not find any code that costs MORE specifically because Debug is ON. Per the user's
explicit "do not guess" instruction, no fix was applied for either pending real numbers.

## Changes: trace instrumentation added (no behavior change)

Added unconditional (not threshold-gated, unlike existing `LogIfSlow`) diagnostic timing +
call-count logging so a real Debug-OFF-vs-ON A/B run produces directly comparable numbers,
per the user's own requested format:

- `Debug/NexusDebugPerfLog.h` (new shared header) - `NexusDebugPerf::LogAlways` (always logs
  elapsed ms) and `NexusDebugPerf::NextCallIndex` (logs "`<name>` call #N", so a
  duplicate/repeated call within one action is directly visible in the log rather than
  needing to be inferred). Also where `LogIfSlow`/`GNexusSlowSectionThresholdMilliseconds`
  now live (see "build error fixed" below).
- `SNexusHierarchyPanel::HandleCreateActivationPoint` - total time, call index, UObject
  count before/after (`GUObjectArray.GetObjectArrayNum()`), current `DebugRootVisible`
  state, and sub-phase timings: transaction scope (mutation only) / transaction finalize
  (`FScopedTransaction` destructor / `EndTransaction`, isolated) / `PublishHierarchySelection`
  / `RefreshHierarchyTree`.
- `SNexusHierarchyPanel::RefreshHierarchyTree` - sub-phase timings for
  `BuildHierarchyTreeFromConfig` / `RequestTreeRefresh` / `ExpandHierarchyTreeRecursive` /
  the reselect branch's own republish.
- `SNexusHierarchyPanel::PublishHierarchySelection` - call index + `SetDetailsTarget` timing.
- `SNexusDetailsPanel::RebindToCurrentTarget` - call index + total timing.

All existing per-Tick `LogIfSlow` calls (`FNexusDebugRenderSnapshot::Refresh`,
`FNexusDiagnostics::GatherDiagnostics`, per-category renderer timing in
`DispatchDebugRenderers`, `FNexusDebugLabelOverlay::UpdateLabels`) were left as-is - they
already run every Tick and will already surface a spike on the exact frame a creation
happens, if one of them is implicated.

## Build error fixed en route

User hit a genuine Unity-build collision: `SNexusHierarchyPanel.cpp` and
`NexusFrameworkSubsystem.cpp` each independently defined an identically-named,
identically-signatured anonymous-namespace `GNexusSlowSectionThresholdMilliseconds`/
`LogIfSlow` (the first one deliberately duplicated rather than shared, per its own
original comment - "avoids a premature abstraction for two call sites"). This is the
SAME class of defect fixed once already this session for `ComputeRightVector`
(`ai-change-audits/2026-08-10/bug-fixed/landscape-segments-and-classification-perf.md`'s
follow-up section) - each file compiles fine alone, but Unreal's Unity build merges
multiple `.cpp` files into one translation unit, and the duplicate definitions collide
there. Given this is now a confirmed, repeating pattern (not a one-off), extracted a real
shared header (`Debug/NexusDebugPerfLog.h`, `inline` functions - safe under Unity by
construction) instead of continuing to duplicate-and-rename per file.

## Verification

Build: `Build.bat NexusFrameworkEditor Win64 Development` - **Succeeded**, 15 actions
(~36s), first attempt after the two fixes above.

## Result / Important Notes

**No fix was implemented for the reported freeze itself** - per the user's own explicit
"First identify the exact blocking function(s). Do not guess" and "implement only the
confirmed mutation/refresh bottleneck," and given the exhaustive static trace above found
no Debug-conditional branch anywhere in the creation call path to point at with confidence.
The two real inefficiencies found (duplicate republish, O(N)-ish tree rebuild) are
documented but NOT fixed this pass, since neither is proven to explain the Debug-ON-specific
1-3 second symptom, and fixing them speculatively risks the exact "guessing" the user
explicitly ruled out.

**Next step requires the user to run the editor** (this agent cannot, per
`AGENT-RULES.md`'s Agent Testing Policy): perform the exact A/B test (Debug root OFF, add
one ActivationPoint; then Debug root ON, add one ActivationPoint) and capture the
`Nexus Perf Trace:` log lines from both runs. That will show, with real numbers: whether the
per-Tick Debug renderers spike on the creation frame specifically (already-instrumented,
existing `LogIfSlow` `Warning`-level lines), the real cost of transaction finalize vs. tree
rebuild vs. Details rebind, and whether `RebindToCurrentTarget`/`PublishHierarchySelection`
genuinely fire twice as the static trace predicts. Once real numbers are available, the
actual blocking function can be fixed with confidence instead of guessed at.

**Landscape/Roads rendering, fade, LOD, culling, and line-detail system**: not touched this
pass, per explicit instruction.
