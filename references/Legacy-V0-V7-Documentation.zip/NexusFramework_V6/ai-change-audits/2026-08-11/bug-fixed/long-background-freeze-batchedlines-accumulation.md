# Long-Background-Freeze Investigation — BatchedLines Accumulation Evidence

Date: 2026-08-11
Category: bug-fixed (research/verification — no code changed by this record)
Phase: N/A (ad-hoc investigation, direct continuation of `nexus-performance-profiler-panel.md`'s
own Timeline/Stall Diagnostics and Time Range/Interval follow-ups)

## Context

Separately from the `Landscape > Segments` cache-hardening investigation
(`landscape-segments-freeze-cache-hardening.md`), the user reported a second, distinct
freeze pattern: a 10-30+ second editor hang after leaving UE backgrounded/unfocused for
2-5+ minutes, whose duration scales with how long the editor sat backgrounded. Two
profiler passes this same day added the instrumentation needed to investigate it: a
Timeline/Stall Diagnostics pass (per-second telemetry, direct `World->LineBatcher`
inspection, GC event timing) and a Time Range/Interval view (lets a specific window be
isolated and broken into buckets). This record captures the first real evidence gathered
using that instrumentation, pasted by the user from a live capture (`Copy Interval
Details`, range 0.0s-15.4s, 3s buckets).

## Prior finding this builds on

Reading UE 5.8's own engine source (`DrawDebugHelpers.cpp`/`LineBatchComponent.cpp`,
documented in `nexus-performance-profiler-panel.md`'s own Timeline/Stall Diagnostics
follow-up) established the mechanism: Nexus's `DrawDebugLine`/`DrawDebugSphere` calls pass
`LifeTime=0.f`, which the engine substitutes with `LineBatcher->DefaultLifeTime` (`1.0f`
by construction) rather than "one frame only." That lifetime is only decremented/removed
by `ULineBatchComponent::TickComponent` — an ordinary WORLD/level Actor Component tick,
separate from `UNexusFrameworkSubsystem::Tick` (`FTickableEditorObject`, ticked by the
editor's own loop regardless of whether the world/viewport is actually ticking). The
hypothesis: if the world's own tick throttles/pauses while backgrounded but Nexus keeps
submitting new debug lines every editor tick regardless, `BatchedLines` could accumulate
for the whole backgrounded period, then get processed in one shot on return to foreground.
This was explicitly flagged as unconfirmed at the time - a plausible mechanism, not yet
observed in real data.

## Findings (real capture data)

User pasted a `Copy Interval Details` report (session duration 15.4s, 3s buckets). The
`BatchedLines.Num`/`LineBatchBytes`/`ProcessMemory` columns (each the LAST 1s-Timeline
sample within that 3s bucket - see `FNexusProfiler::BuildRangeTelemetry`) across the six
buckets:

| Bucket | BatchedLines.Num | LineBatchBytes | ProcessMemory |
|---|---|---|---|
| 0.00s-3.00s | **1,196,120** | 99.70 MB | 5.34 GB |
| 3.00s-6.00s | 0 | 0 B | 6.02 GB |
| 6.00s-9.00s | 35,756 | 3.00 MB | 6.15 GB |
| 9.00s-12.00s | 0 | 0 B | 5.21 GB |
| 12.00s-15.00s | 0 | 0 B | 5.79 GB |
| 15.00s-15.42s | 36,044 | 3.00 MB | 5.13 GB |

Analysis:
- The first bucket's own `DrawLines` telemetry column (new lines Nexus submitted THIS
  bucket) was only 59,125 - nowhere near enough to explain 1,196,120 resident lines. The
  backlog necessarily predates this capture (i.e. accumulated before "Start Profiling" was
  clicked, most likely during a backgrounded period immediately prior).
- `99.70 MB / 1,196,120 lines ≈ 87.4 bytes/line`, consistent with `sizeof(FBatchedLine)`
  (two `FVector` + `FLinearColor` + two floats + `uint8` + `uint32`, ~80-88B with padding)
  - confirms this is a real resident-line count, not a display/computation error.
  - Buckets 6.00s-9.00s and 15.00s-15.42s show a "steady state" resident count of
  ~35-36k lines (~83 B/line, same sanity check) once the backlog is gone - the first
  bucket is running **~33x above that steady state**.
- Between bucket 1 and bucket 2, `BatchedLines.Num` dropped from 1,196,120 to 0 while
  `ProcessMemory` jumped +680MB (5.34GB -> 6.02GB) - consistent with a one-shot render-
  thread rebuild processing/uploading over a million batched line primitives in a single
  burst.
- No individual `Nexus.*` `NEXUS_PROFILE_SCOPE` anywhere in this capture exceeded ~26ms
  (`Nexus.Debug.Render.Runtime.ActivationPoints` peaked at 23.6ms in bucket 5) - consistent
  with every prior capture this investigation has produced: whatever cost that backlog
  flush paid is being paid entirely OUTSIDE every Nexus-instrumented call path, exactly
  where a `ULineBatchComponent` scene proxy rebuild would sit (render thread, not captured
  by this CPU-side tool at all).

## Result

This is the first DIRECT, real-data evidence for the accumulate-while-backgrounded /
flush-in-one-shot mechanism - previously only a hypothesis read from engine source. It is
still **correlational, not fully proven causal**, pending one more piece: the exact
Tick-to-Tick gap (from the Stall list, `GapMs`) that overlaps the bucket-1-to-bucket-2
transition. `Copy Interval Details` (used for this capture) deliberately does not include
the Stall/GC sections - only `Copy Full Details` does, at 1-second Timeline granularity
(finer than this 3s-bucket view). Requested from the user as the next step, from the SAME
session if still open (not re-run), to directly confirm: (a) whether a >100ms-or-larger
gap's own `StartTime` lands inside this window, (b) its measured `GapMs` (does it match a
perceived multi-second freeze?), and (c) its own `BatchedLinesBefore`/`BatchedLinesAfter`
snapshot (should read close to 1,196,120 / 0 if this is the same event).

## Important Notes

- **Not yet root-caused, only strongly evidenced.** Do not treat this as a confirmed fix
  target until the Stall-list cross-reference above lands - the memory jump and line-count
  crash are real and large, but a rigorous claim of "this IS the freeze" needs the paired
  wall-clock gap measurement.
- **No code was changed to produce this finding** - purely an analysis of data the user
  captured using the already-built Timeline/Stall/Interval instrumentation
  (`nexus-performance-profiler-panel.md`'s two follow-ups). If/when a fix is designed
  (e.g. gating Nexus's own debug-line submission on world-tick/foreground state, or
  periodically flushing/capping the transient LineBatcher), it belongs in a NEW dated
  section here, not a rewrite of this one.
- **Process memory is unusually volatile even outside the flush bucket** - 5.13GB to
  6.15GB across just 15 seconds, a >1GB swing with no user-visible operation beyond one
  Activation Point creation per ~3s (an artifact of the manual repro clicking "Add
  Activation Point" repeatedly to keep Nexus busy while capturing, per the user's own
  established repro pattern) - plausibly related to the same batched-primitive churn, not
  yet separately investigated.
