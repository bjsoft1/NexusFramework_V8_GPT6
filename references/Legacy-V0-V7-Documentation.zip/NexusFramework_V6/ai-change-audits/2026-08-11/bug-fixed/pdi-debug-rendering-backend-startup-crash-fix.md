# PDI Debug Rendering Backend — Editor Startup Crash Fix (ModeTools Init Order)

Date: 2026-08-11
Category: bug-fixed (crash fix - EdMode registration/activation lifecycle only)
Phase: N/A (same-day follow-up to `bug-fixed/pdi-debug-rendering-backend-implemented.md`,
which introduced the crash; see that file's own appended `## Correction` section)

## Context

The user attempted the manual in-editor verification steps listed at the end of
`pdi-debug-rendering-backend-implemented.md` and hit an immediate crash on editor
startup, with a stack trace pointing directly at
`FNexusFrameworkEditorModule::StartupModule()` line 39:

```
FNexusFrameworkEditorModule::StartupModule() line 39
-> GLevelEditorModeTools()
-> constructs FLevelEditorModeTools
-> UModeManagerInteractiveToolsContext::Initialize
-> delegate Add
-> access violation
```

The user's own diagnosis (confirmed correct by re-reading the actual line): this is an
initialization-ORDER bug in the new mode's registration/activation lifecycle, not
evidence against the PDI/passive-EdMode architecture itself. Explicit fix scope given:
do not revert the PDI backend, `FNexusDebugDrawEdMode`, the Tick/Render split, or any
existing V6 architecture - fix ONLY the EdMode registration/activation lifecycle so that
`StartupModule()` has zero direct `FEditorModeTools`/`GLevelEditorModeTools()` access,
with all real activation deferred and guarded.

## Problem / Goal

`StartupModule()` (in the version shipped by `pdi-debug-rendering-backend-implemented.md`)
called:

```cpp
DebugDrawEditorModeChangedHandle = GLevelEditorModeTools().OnEditorModeIDChanged().AddRaw(this, &FNexusFrameworkEditorModule::OnDebugDrawEditorModeIDChanged);
```

directly and unconditionally (inside an `if (FLevelEditorModule* levelEditor = ...)`
block, but with no further guard) - copied verbatim from `NexusFramework_V0`'s own
`StartupModule()`, which contains the exact same line
(`EditorModeChangedHandle = GLevelEditorModeTools().OnEditorModeIDChanged().AddRaw(...)`)
in the same position. `GLevelEditorModeTools()` is a global free function that LAZILY
constructs a whole `FLevelEditorModeTools` (a `FEditorModeTools` subclass) plus its own
`UModeManagerInteractiveToolsContext` the first time anything calls it. In this project's
own module/plugin startup order, `NexusFrameworkEditor::StartupModule()` runs too early
for that construction to be safe - the access violation happens deep inside the engine's
own `UModeManagerInteractiveToolsContext::Initialize`, not in any Nexus code.

## Findings

- **V0 does call `GLevelEditorModeTools()` from `StartupModule()` too**, at the same
  relative point, and is described (accurately, from prior research) as "a real, working,
  at-scale precedent." Re-reading V0's `NexusFrameworkEditorModule.cpp` line-by-line again
  did not find a materially different initialization order there - V0's module has no
  extra guard around this call either. The most likely explanation is a difference in
  module/plugin dependency graph or load order between the two projects (V6's
  `NexusFramework.uproject` additionally enables the `ModelingToolsEditorMode` plugin,
  which V0 does not have; plugin/module load order affects exactly when the `LevelEditor`
  module - and by extension `GLevelEditorModeTools()`'s first-call safety - is ready) -
  not investigated further/confirmed by file, since the fix below does not depend on
  knowing the exact reason: it simply never calls the unsafe accessor at all, from
  anywhere, at any point in this module's lifecycle.
- **V6 already has an established, proven-safe alternative accessor for this exact
  purpose**, unmodified and never touched by this fix:
  `FNexusLandscapeModeExtension::RegisterToFirstLevelEditor()`
  (`Private/UI/NexusLandscapeModeExtension.cpp`) resolves
  `FLevelEditorModule::GetFirstLevelEditor()` and reads that instance's OWN
  `GetEditorModeManager()` (an `ILevelEditor` method returning `FEditorModeTools&`) -
  never the global `GLevelEditorModeTools()` free function. This code is called from
  `FNexusLandscapeModeExtension::Register()`, itself called from THIS SAME
  `StartupModule()`, and has never crashed - proving that reading a per-level-editor
  `FEditorModeTools` via an already-valid `ILevelEditor` instance is safe even that
  early, in clear contrast to the global lazy-construction accessor. This became the
  fix's core mechanism.
- **3 pre-existing, unrelated call sites of `GLevelEditorModeTools()` remain in the
  codebase** (grepped after the fix, see the report below) - all confirmed safe by
  inspection and NOT modified by this fix, since none of them run during module
  startup.

## Changes

Both `FNexusFrameworkEditorModule.h` and `.cpp` were reworked so that **zero** ModeTools
access (of any kind - global or per-instance, read or write) happens inside
`StartupModule()`, directly or transitively:

1. **`StartupModule()`** now does exactly two things: (a) `FEditorModeRegistry::Get().
   RegisterMode<FNexusDebugDrawEdMode>(...)` - a plain registry insert, confirmed to
   construct nothing ModeTools-related; (b) bind two delegates
   (`FLevelEditorModule::OnLevelEditorCreated()` -> `OnDebugDrawLevelEditorCreated`, and
   `FCoreDelegates::GetOnPostEngineInit()` -> `TryActivateDebugDrawMode`). Neither
   delegate fires synchronously from within `StartupModule()` - both fire later, from the
   engine's own subsequent startup steps.
2. **New `RegisterDebugDrawModeToFirstLevelEditor()`** - the only place that reads
   `FEditorModeTools& modeManager = firstLevelEditor->GetEditorModeManager()`. Guarded by
   a new `bDebugDrawModeToolsBound` bool (never binds `OnEditorModeIDChanged` twice) and
   by `firstLevelEditor.IsValid()` (safely no-ops, tries again later, if no level editor
   exists yet). Only ever reached from `OnDebugDrawLevelEditorCreated` (fires AFTER a
   level editor finishes constructing) or from `TryActivateDebugDrawMode` once a level
   editor is already known valid - never synchronously from `StartupModule()`.
3. **New `TryActivateDebugDrawMode()`** (the single safe helper requested) - checks
   `!IsEngineExitRequested() && GEditor` before touching anything, binds via
   `RegisterDebugDrawModeToFirstLevelEditor()` if not yet bound, otherwise checks
   `IsModeActive` before calling `ActivateMode` (idempotent, no duplicate activation).
   Bound as the `OnPostEngineInit` handler and called again from
   `OnDebugDrawEditorModeIDChanged` (defensive re-assertion on any OTHER mode change).
4. **`OnDebugDrawEditorModeIDChanged`** now early-returns when the changed mode IS
   `EM_NexusDebugDraw` itself, preventing recursive re-entry from the module's own
   `ActivateMode`/`DeactivateMode` calls broadcasting back into this same handler.
5. **`ShutdownModule()`** now only touches ModeTools when `bDebugDrawModeToolsBound` is
   true (meaning a real, already-constructed `FEditorModeTools` was read once before) AND
   `!IsEngineExitRequested()` - reads it via the same `GetFirstLevelEditor()->
   GetEditorModeManager()` accessor, never the global one. `bDebugDrawModeToolsBound` is
   reset to `false` at the end.

`FNexusDebugDrawEdMode` itself, `UNexusFrameworkSubsystem::RenderDebugPrimitives`, and
`FNexusDebugPrimitives`' PDI backend are completely unchanged by this fix - it is
entirely confined to the mode's registration/activation lifecycle in
`NexusFrameworkEditorModule.{h,cpp}`.

## Verification

- **Old line 39 behavior** (removed): `DebugDrawEditorModeChangedHandle =
  GLevelEditorModeTools().OnEditorModeIDChanged().AddRaw(...)`, called unconditionally
  inside `StartupModule()`.
- **New `StartupModule()` flow**: `RegisterMode` -> bind `OnLevelEditorCreated` -> bind
  `GetOnPostEngineInit()`. No `FEditorModeTools`/ModeTools symbol appears anywhere in the
  function body.
- **Every remaining `GLevelEditorModeTools()` call in the Nexus codebase** (grepped
  `Source/` after the fix):
  | File:Line | Context | Why engine/editor init is guaranteed complete there |
  |---|---|---|
  | `SNexusDetailsPanel.cpp:68` | `TAttribute<bool>` lambda controlling the Details panel's `SetEnabled`, re-evaluated every Slate paint | Only ever evaluated once the Details tab widget exists and is being painted - the tab only opens via `FNexusLandscapeModeExtension::OnEditorModeIDChanged`'s `TryInvokeTab`, itself only reachable once Landscape Mode has actually been entered, which requires the level editor's mode tools to already exist |
  | `SNexusDetailsPanel.cpp:306` | Write-commit guard in the property-edit-commit handler | Only runs in response to a real user edit gesture on an already-open, already-rendering Details tab - same guarantee as above |
  | `NexusLandscapeModeExtensionTests.cpp:37` | `FNexusLandscapeModeExtensionTest::RunTest` | An `IMPLEMENT_SIMPLE_AUTOMATION_TEST(..., EAutomationTestFlags::EditorContext | ...)` - only executes when manually triggered from the Automation window, after the editor (including its level editor and mode tools) is already fully running |

  None of these were modified by this fix - all 3 were already safe before this change
  and remain unmodified.
- **`StartupModule()` ModeTools access: confirmed ZERO.** Re-read the final function body
  after the fix - it contains `FEditorModeRegistry::Get().RegisterMode<...>` (registry,
  not ModeTools) and two `AddRaw`/handle-assignment lines against
  `FLevelEditorModule::OnLevelEditorCreated()` and `FCoreDelegates::GetOnPostEngineInit()`
  - neither of which is `FEditorModeTools`/`GLevelEditorModeTools`/`ActivateMode`/
  `DeactivateMode`/`IsModeActive`, and neither of which executes synchronously within
  `StartupModule()`'s own call frame.
- **Build**: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject`. First attempt
  failed with `Unable to build while Live Coding is active` - the crashed `UnrealEditor.exe`
  and its `CrashReportClientEditor.exe` were still present in the process list (confirmed
  via `tasklist`); both had already exited on their own by the time this agent checked
  again a moment later (confirmed via a second `tasklist`, nothing needed to be
  force-closed). Rebuild succeeded with zero warnings/errors across all 4 touched
  translation units.

## Result

Fix implemented and build-verified. `StartupModule()` no longer performs any
`FEditorModeTools` access, directly or transitively - registration and delegate binding
only. All real mode activation is deferred to `TryActivateDebugDrawMode`, reached only via
`OnPostEngineInit`, `OnLevelEditorCreated`, or a subsequent `OnEditorModeIDChanged`
re-assertion, each of which is guaranteed to fire strictly after `StartupModule()` has
already returned. Duplicate delegate binding, duplicate activation, activation during
shutdown, and recursive re-entry from the module's own mode-change broadcasts are all
explicitly guarded.

## Important Notes

- **Still pending**: the user has not yet re-launched the editor to confirm this
  specific fix resolves the crash (this agent cannot launch/drive the editor -
  AGENT-RULES.md's Agent Testing Policy). If the crash recurs or a new one surfaces, it
  belongs in a NEW `## Correction` section appended to this file, not a rewrite.
- **The exact reason V0 doesn't hit this** (differing plugin/module load order,
  most likely `ModelingToolsEditorMode` being enabled in V6 but not V0) was not
  conclusively root-caused - the fix does not depend on knowing why, since it avoids the
  unsafe accessor unconditionally rather than working around a specific ordering. If a
  future investigation wants the precise mechanism, compare `.uproject` plugin lists and
  each module's `.Build.cs` `LoadingPhase`/dependency declarations between the two
  projects.
- **Once the manual in-editor verification from
  `pdi-debug-rendering-backend-implemented.md` (BatchedLines.Num staying near-zero,
  categories still rendering, gizmo/details still working, no background-freeze) is
  actually completed**, its result should be appended to THAT file (the original PDI
  migration record), not this one - this file's own scope is the startup crash and its
  fix, not the rendering migration's own functional verification.
