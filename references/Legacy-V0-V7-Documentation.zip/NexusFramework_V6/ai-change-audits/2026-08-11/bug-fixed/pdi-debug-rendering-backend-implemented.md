# PDI Debug Rendering Backend — Implemented (Draw Backend Migration)

Date: 2026-08-11
Category: bug-fixed (architectural fix - low-level debug draw backend replaced)
Phase: N/A (ad-hoc investigation/fix, direct continuation of this same day's
`research/pdi-debug-rendering-backend-v0-v1-v5-reference.md` proposal)

## Context

`research/pdi-debug-rendering-backend-v0-v1-v5-reference.md` (this same day, earlier)
proposed - but explicitly did NOT implement, per the user's own mid-turn gate ("just
generate .md file your fill fingig do not impletement yet") - replacing V6's low-level
debug-drawing backend (`DrawDebugLine`/`DrawDebugSphere` -> `ULineBatchComponent`) with a
scalable, V0-style viewport/PDI primitive renderer, after `bug-fixed/
long-background-freeze-batchedlines-accumulation.md` found real evidence of
`BatchedLines.Num` spiking past 1.2M transient entries on a ~10-segment map. The user
returned in a later session and explicitly authorized full implementation, restating the
same non-negotiable constraints from the original request (keep V6's data model,
categories, config, cache, LOD/fade/culling, Highway/Lane/Sidewalk/Junction/Mapping/
Activation logic, profiler, and gizmo behavior completely unchanged; replace ONLY the
draw backend; do not clear/cap the LineBatcher as a substitute fix; do not reintroduce
the old toolkit-based custom `UEdMode`). This record documents what was actually
implemented, following the proposal in the research record above essentially verbatim.

## Problem / Goal

Migrate every live Nexus Debug primitive submission from `DrawDebugLine`/`DrawDebugBox`/
`DrawDebugSphere`/`DrawDebugCapsule`/`DrawDebugDirectionalArrow` (all backed by the
world's persistent, lifetime-decayed `ULineBatchComponent`) to the engine's
`FPrimitiveDrawInterface` (PDI) - a transient, current-frame-only primitive list with no
persistent backing array - without changing what gets drawn, how categories are
configured, or any of V6's existing architecture layers above the 5-function
`FNexusDebugPrimitives` library.

## Findings

- Confirmed (grep, whole `Source/` tree, before AND after this change) that every
  `DrawDebug*` call in V6 lives in exactly one file, `NexusDebugPrimitives.cpp` - no
  category renderer, gizmo, or other system calls `::DrawDebug*` directly. This made the
  backend swap a genuinely contained, 1-file change at its core, exactly as the research
  record predicted.
- Confirmed UE 5.8 `PrimitiveDrawingUtils.h`/`PrimitiveDrawInterface.h`/`RotationMatrix.h`/
  `TranslationMatrix.h` API signatures directly from engine source before writing any
  call site (see Changes below for the exact mapping) - `FRotationMatrix::MakeFromX` and
  `FTranslationMatrix(FVector)` (both flagged "not yet grep-confirmed" in the prior
  research record) are real, generated via each header's own `UE_DECLARE_LWC_TYPE(...)`
  macro - confirmed by reading `RotationMatrix.h`/`TranslationMatrix.h` directly, not
  assumed.
- Confirmed `FNexusDebugRenderSnapshot`'s existing LOD/culling already resolves camera
  location independently of any `FSceneView` (via `NexusDebugLOD.cpp`, not through
  `Render()`'s own view parameter) - so category renderers need no `FSceneView` plumbed
  through them at all; the `RendererFn` delegate signature (`world, snapshot, config,
  outLabelRequests`) did not need to change. This confirmed the "zero changes to any of
  the ~14 category-renderer .cpp files" claim from the research record was actually true,
  not just planned.
- Confirmed `FNexusDebugLabelOverlay` (the Slate label overlay) has no dependency on PDI
  or `ULineBatchComponent` at all (`WorldToScreen`-based, own pooled `SConstraintCanvas`
  widgets) - not part of the accumulation bug, and not redesigned; only its call site
  moved (see Changes), matching the user's explicit "do not unnecessarily redesign the
  label overlay" instruction.

## Changes

1. **`FNexusDebugPrimitives`** (`Public/Private/Debug/NexusDebugPrimitives.h/.cpp`) - all
   5 primitive functions keep their exact original public signatures. Added a private
   static `FPrimitiveDrawInterface* ActivePDI` and a public nested RAII
   `FScopedActivePDI` (constructor sets `ActivePDI`, destructor restores the previous
   value). Each Draw* function now checks `ActivePDI` first:
   | Function | PDI path (when `ActivePDI` set) | Fallback (unchanged, when null) |
   |---|---|---|
   | `DrawLine` | `PDI->DrawLine(Start, End, Color, DepthPriority, Thickness)` | `DrawDebugLine` |
   | `DrawBox` | `DrawOrientedWireBox(PDI, Base, rotation.GetAxisX/Y/Z(), Extent, Color, DepthPriority, Thickness)` | `DrawDebugBox` |
   | `DrawSphere` | `DrawWireSphere(PDI, Base, Color, Radius, 12 sides, DepthPriority, Thickness)` | `DrawDebugSphere` |
   | `DrawArrow` | `DrawDirectionalArrow(PDI, ArrowToWorld, Color, Length, ArrowSize, DepthPriority, Thickness)` where `ArrowToWorld = FRotationMatrix::MakeFromX(direction) * FTranslationMatrix(start)` (verified against the engine's own `DrawDirectionalArrow` implementation: draws local origin -> local `(Length,0,0)`, exactly matching the old start/end semantics) | `DrawDebugDirectionalArrow` |
   | `DrawCapsule` | `DrawWireCapsule(PDI, Base, rotation.GetAxisX/Y/Z(), Color, Radius, HalfHeight, 16 sides, DepthPriority, Thickness)` | `DrawDebugCapsule` |

   `DrawTangentHandle`/`DrawDirectionArrow` (the two composite convenience functions) were
   NOT touched directly - they already only call `DrawLine`/`DrawSphere`/`DrawArrow`
   internally, so they pick up the PDI backend transparently. `TRACE_COUNTER_*` and
   `FNexusProfiler::Get().RecordDrawLine/RecordDrawSphere` calls are unchanged, still run
   on every call regardless of which backend serviced it.

2. **New `FNexusDebugDrawEdMode`** (`Private/Debug/NexusDebugDrawEdMode.h/.cpp`) - a
   toolkit-less `FEdMode`, ported directly from `NexusFramework_V0`'s proven
   `FNexusRoadGraphAlwaysDrawEdMode`. Overrides only `IsCompatibleWith` (true for every
   mode except itself), `Render(view, viewport, pdi)`, `ShouldDrawWidget`/
   `UsesTransformWidget` (both false). `Render()` resolves
   `GEditor->GetEditorSubsystem<UNexusFrameworkSubsystem>()` and forwards `pdi` to the new
   `RenderDebugPrimitives(pdi)` method below - nothing else. Never overrides
   `UsesToolkits()`/touches `FToolkitManager` (base `FEdMode` behavior for both is a
   no-op, confirmed from UE 5.8's own `EdMode.cpp` in the prior research pass) - cannot
   reproduce the `ToolkitManager.cpp` assertion V6's old custom `UEdMode` hit (see
   `ai-change-audits/2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md`).

3. **`UNexusFrameworkSubsystem`** (`Public/Subsystem/NexusFrameworkSubsystem.h`,
   `Private/Subsystem/NexusFrameworkSubsystem.cpp`) - `Tick()` now does ONLY state/cache
   maintenance: `RecordTickSample` (unchanged, unconditional) + `RefreshRepresentationIfDue()`
   (unchanged). The three drawing calls that used to run unconditionally every Tick
   (`RenderDiagnosticsOverlay`, `DispatchDebugRenderers`, `LabelOverlay->UpdateLabels`)
   moved verbatim into a new public method `RenderDebugPrimitives(FPrimitiveDrawInterface*
   pdi)`, wrapped in a new `FNexusDebugPrimitives::FScopedActivePDI` for the method's
   duration and a new profiler scope `Nexus.Render.DispatchDebugPrimitives` (replacing
   their former implicit position under `Nexus.Tick`). `RenderDebugPrimitives` is called
   ONLY from `FNexusDebugDrawEdMode::Render()`.

4. **`FNexusFrameworkEditorModule`** (`Public/NexusFrameworkEditorModule.h`,
   `Private/NexusFrameworkEditorModule.cpp`) - `StartupModule()` now also registers
   `FNexusDebugDrawEdMode` hidden (`bVisible=false`) via `FEditorModeRegistry`, and wires
   up V0's exact 3-hook keep-alive pattern: `FCoreDelegates::GetOnPostEngineInit()`,
   `FLevelEditorModule::OnLevelEditorCreated()`, and
   `GLevelEditorModeTools().OnEditorModeIDChanged()` (defensive re-assertion on ANY mode
   change, not just Landscape) all call a new `EnsureDebugDrawModeActive()` (activates the
   mode if not already active). `ShutdownModule()` guards all mode-tools access behind
   `!IsEngineExitRequested() && FModuleManager::Get().IsModuleLoaded("LevelEditor")` (V0's
   own documented "must not touch `GLevelEditorModeTools()` during engine exit" gotcha),
   deactivates the mode, removes all 3 delegate handles, then unregisters the mode type.
   `LandscapeModeExtension.Register()/Unregister()` and its own tab/gizmo lifecycle are
   completely untouched - the new mode is a fully separate, additive registration, always
   active regardless of whether Landscape Mode is entered (matching the fact that
   `ActiveConfig`/debug rendering already persists across Landscape Mode exit in the
   existing code, not gated by it).
   Used `FCoreDelegates::GetOnPostEngineInit()` (not the deprecated `OnPostEngineInit`
   V0's own source still uses) - UE 5.8 flagged the old form `UE_DEPRECATED(5.8, ...)`
   during the build; fixed immediately since this is new code, not a port that needs to
   match V0 byte-for-byte.

## Verification

- **Static**: grepped the whole `Source/` tree for every `DrawDebug(Line|Sphere|Box|
  Capsule|DirectionalArrow|Point|Circle|Cone|Cylinder)\(` call site after the change.
  Exactly 5 matches, all inside `NexusDebugPrimitives.cpp`, all inside the `if (ActivePDI)
  { ...; return; } DrawDebug*(...)` fallback branch of the 5 migrated functions - the
  complete, expected, intentionally-retained set (reachable only for a hypothetical
  future call site with no active PDI, e.g. a console command run outside a Render()
  pass - the existing `Nexus.Debug.BenchmarkPrimitives` command is one such case, and
  correctly still uses the fallback, which is fine: a manual one-shot burst is not the
  per-Tick-forever pattern that caused the accumulation bug). No migration misses.
- **Build**: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` (editor was not
  running). First pass succeeded with one deprecation warning
  (`FCoreDelegates::OnPostEngineInit`); fixed (see Changes #4); second pass succeeded
  with zero warnings/errors across all 4 changed/new translation units
  (`NexusDebugPrimitives.cpp`, `NexusDebugDrawEdMode.cpp`, `NexusFrameworkSubsystem.cpp`,
  `NexusFrameworkEditorModule.cpp`).
- **Not yet done (cannot be done by this agent - AGENT-RULES.md's Agent Testing Policy,
  no editor launch/drive)**: actual in-editor verification. See Important Notes below for
  the exact manual steps the user still needs to run.

## Result

Implementation complete and build-verified. Every live Nexus Debug category (Landscape.*,
Roads.*, Mapping.*, Runtime.ActivationPoints, Diagnostics markers) now submits its
primitives through `FPrimitiveDrawInterface` during the new `FNexusDebugDrawEdMode`'s
`Render()` callback instead of `DrawDebugLine`/`DrawDebugSphere`/etc. every Tick. No
category renderer, the Debug Tree, config/settings, hierarchy/details, the cache/LOD/fade/
culling system, Highway/Lane/Sidewalk/Junction/Mapping/Activation logic, the profiler, or
gizmo behavior/features were modified - only the 5-function primitive library's internals,
plus the Tick/Render split and mode registration needed to give it a valid PDI to route
through.

## Important Notes

- **This is a structural fix, not a mitigation.** No LineBatcher clear/cap/flush was
  added anywhere - the old `ULineBatchComponent` path is now reached only via the
  documented fallback (no active PDI), which normal live Nexus Debug rendering never
  hits. While the editor is backgrounded/minimized, no viewport renders, so
  `FNexusDebugDrawEdMode::Render()` simply never fires and `RenderDebugPrimitives` is
  never called during that time - nothing is submitted to accumulate, in addition to PDI
  itself having no persistent backing array regardless of call frequency.
- **Expected, not-a-bug side effect**: `RenderDebugPrimitives` runs once per
  actively-rendering viewport per frame (not once per "true" engine frame) - a 4-pane
  viewport layout will call it 4 times per frame, each with its own camera/frustum. This
  is inherent to any PDI-based approach (matches how the engine's own scene rendering and
  V0's precedent both already work), not a regression.
- **Manual verification still required from the user** (this agent cannot launch/drive
  the editor - AGENT-RULES.md's Agent Testing Policy): open the project, enter Landscape
  Mode, confirm every previously-working Debug category still renders with correct
  colors/thickness/labels/LOD/fade; add a State/City/ActivationPoint and confirm Details
  editing + the ActivationPoint gizmo still work; start the Nexus Profiler, leave Debug
  enabled, and confirm `World->LineBatcher->BatchedLines.Num()` (visible in the
  profiler's own Timeline/Stall Diagnostics telemetry, built earlier this same day) stays
  at/near zero instead of climbing into the hundreds of thousands; background the editor
  for several minutes and confirm no catch-up freeze on return. If any regression
  surfaces, it belongs in a NEW dated section appended to this file (or a new file in
  `bug-fixed/` if it's a genuinely distinct problem), never a rewrite of this record.
- **Gizmo rendering was not touched.** `FNexusActivationGizmoManager`'s actual gizmo
  visuals go through the Interactive Tools Framework (`UCombinedTransformGizmo`), a
  separate, already-safe system unrelated to `FNexusDebugPrimitives` - confirmed by this
  session not needing to modify `Gizmo/NexusActivationGizmoManager.*` or
  `Tool/NexusActivationGizmoTool.*` at all for this migration to build/link cleanly.
- **`FNexusDebugLabelOverlay` itself was not modified** - only its call site moved
  (from `Tick()` to `RenderDebugPrimitives()`, alongside the label-request-producing
  calls it always depended on), per the user's explicit "do not unnecessarily redesign
  the label overlay" instruction; see Findings above for why it was never actually part
  of the accumulation bug in the first place.

## Correction — 2026-08-11

The "manual verification still required" item above was attempted and hit a real editor
STARTUP crash (not a rendering-correctness issue) - `FNexusFrameworkEditorModule::
StartupModule()` line 39 called the global `GLevelEditorModeTools()` free function
directly (mirroring V0's own `StartupModule()` verbatim, per Changes #4 above), which
lazily constructs a whole `FLevelEditorModeTools` + `UModeManagerInteractiveToolsContext`
on first access - too early in this project's own startup order, causing an access
violation inside `UModeManagerInteractiveToolsContext::Initialize`. The PDI backend
architecture itself (the toolkit-less `FNexusDebugDrawEdMode`, the Tick/Render split, the
5-function primitive swap) was NOT the cause and was NOT reverted. Full root cause,
fix, and re-verification recorded in the same day's
`bug-fixed/pdi-debug-rendering-backend-startup-crash-fix.md` (a new file per this
project's append-only rule, since it's a distinct investigation thread, not a rewrite of
this record) - read that file for the actual fix. This section exists so anyone reading
this record top-to-bottom sees the correction and knows to check the follow-up before
treating this record's own "build succeeded, manual verification pending" Result as the
final state.
