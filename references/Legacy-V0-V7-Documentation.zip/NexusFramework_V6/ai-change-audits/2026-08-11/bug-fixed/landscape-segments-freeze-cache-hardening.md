# Landscape > Segments freeze - explicit per-segment cache hardening

Date: 2026-08-11
Category: bug-fixed
Phase: N/A (ad-hoc performance investigation, direct follow-up to this same day's
`activation-point-debug-on-freeze-investigation.md` and 2026-08-10's
`landscape-segments-and-classification-perf.md`)

## Context

User reported the freeze is still serious: Debug ON, especially `Landscape > Segments`,
causes 1-3s freezes and sometimes large memory growth. User's own stated hypothesis:
"debug rendering still queries Landscape spline data repeatedly." Explicit requirements
given: cache per segment (Start Location, End Location, Start Rotation, End Rotation,
Start Tangent, End Tangent, sampled curve/debug points), renderers must read ONLY cached
data, no live Landscape Location/Rotation/Tangent queries during normal Tick/render,
refresh only on real topology change, cache is debug/editor-transient only (never
Runtime export), explicit "Read-only debug cache. Modified internally by Nexus only. Do
not author manually." comments on cached fields, external code must not mutate the
cache, preserve existing LOD/fade/culling, extend the existing snapshot/cache instead of
building a new one, and verify ActivationPoint creation does not invalidate the
Landscape cache.

## Investigation (read before changing anything, per this project's own established
pattern of not guessing)

Read the existing architecture in full before touching code - `FNexusDebugRenderSnapshot`
(`Public/Debug/NexusDebugRenderSnapshot.h` / `Private/Debug/NexusDebugRenderSnapshot.cpp`)
already exists (Phase 30/30a, hardened twice more in 2026-08-10's perf passes) and is
exactly the cache this task asks for - confirmed, not assumed, by reading every renderer
and the refresh call site:

1. **Render path already reads ONLY the cache.** `NexusDebugLandscapeGroupRenderers.cpp`'s
   four leaves (`RenderSegments`/`RenderTangents`/`RenderStartEnd`/`RenderConnections`)
   read exclusively from `snapshot.Points`/`snapshot.Highways`/
   `snapshot.FindSegmentCurveSamples`/`FindSegmentTangents` - a repo-wide grep for every
   live-Landscape-read function (`GetLiveLocation`/`GetLiveRotation`/
   `GetLiveTangentDirection`/`SourcePoint.LoadSynchronous`/
   `TryResolveControlPointWorldTransform`/`TryResolveSegmentEndpointWorldTangent`/
   `EnumerateSegments`/`EnumerateControlPoints`/`ResolveActiveLandscape`) across every file
   in `Private/Debug/` turns up matches in exactly two files: `NexusDebugRenderSnapshot.cpp`
   (the sanctioned refresh-time read) and `NexusDiagnostics.cpp` (also a refresh-time
   gather, not a per-Tick renderer read) - and one harmless comment mention (not a call) in
   `NexusDebugMappingGroupRenderers.cpp`. No renderer reads live Landscape data.
2. **Refresh already only happens on real change.**
   `UNexusFrameworkSubsystem::RefreshRepresentationIfDue` (added/hardened
   2026-08-10) rebuilds immediately on an explicit `MarkRepresentationDirty()` call, or -
   on its 0.25s poll cadence - first computes a cheap O(control points + segments)
   fingerprint (`FNexusLandscapeReader::ComputeLandscapeRevisionFingerprint`, raw field
   reads only, no world-transform resolution, no curve work) and only promotes to a real
   rebuild if that fingerprint (or the resolved `ALandscape*`) actually changed. Idle with
   nothing changed = no rebuild.
3. **ActivationPoint creation already does NOT invalidate the Landscape cache** -
   re-verified directly against current source (not assumed from the older record):
   `SNexusHierarchyPanel::HandleCreateActivationPoint`
   (`SNexusHierarchyPanel.cpp:1080-1136`) and `HandleDeleteActivationPoint` (:1138-1167)
   call neither `MarkRepresentationDirty()` nor anything that would. Grepped every
   `MarkRepresentationDirty()` call site in the repo (9 total) - all are on
   State/City/Highway create/delete/assign/undo paths and the Details panel's non-
   ActivationPoint edit-commit path (`SNexusDetailsPanel.cpp:273-276`, explicitly gated
   `if (target.HierarchyItemType != ENexusHierarchyItemType::ActivationPoint)`). Confirmed
   unchanged by this session's own earlier work today.
4. **The cache is already debug/editor-transient only, never Runtime export.**
   `RenderSnapshot` is a plain (non-`UPROPERTY`, non-reflected) private member of
   `UNexusFrameworkSubsystem`, exposed externally only via
   `GetRenderSnapshot() const` (returns a `const&`) - nothing outside
   `NexusDebugRenderSnapshot.cpp` writes into its arrays (grepped for
   `RenderSnapshot.Points`/`.Segments`/`.Highways`/`.CityColors` direct mutation - zero
   hits). `NexusStaticGenerator.h`'s own header comment already states it "deliberately
   does NOT depend on `FNexusDebugRenderSnapshot`" - confirmed by grep, Generation/Runtime
   export never references it.

**What was genuinely missing**, per this task's own literal cache-field list: the segment
struct (`FNexusDebugSnapshotSegment`) cached tangents and sampled curve points, but not
explicit `StartLocation`/`EndLocation`/`StartRotation`/`EndRotation` fields - that data
existed (on `FNexusDebugSnapshotPoint`, reachable via a second `FindPoint` lookup) but a
segment record was not self-contained the way this task asks for. Also missing: the
literal `Read-only debug cache. Modified internally by Nexus only. Do not author
manually.` comment text on the cached struct fields (prior comments documented ownership
narratively, not with this exact phrasing).

## Changes

**`Public/Debug/NexusDebugRenderSnapshot.h`**:
- `FNexusDebugSnapshotSegment` gained `StartLocation`/`EndLocation` (`FVector`) and
  `StartRotation`/`EndRotation` (`FRotator`), each marked with the literal
  `Read-only debug cache. Modified internally by Nexus only. Do not author manually.`
  comment. Same marker added to `FNexusDebugSnapshotPoint`, `FNexusDebugSnapshotHighway`,
  and the existing `OutgoingTangentAtA`/`OutgoingTangentAtB`/`CurveSamples` fields.
- `FNexusDebugRenderSnapshot`'s own top comment extended with an explicit
  "DEBUG/EDITOR transient only - never exported" paragraph and a "Read-only debug cache...
  no renderer/UI panel/gizmo tool may write into Points/Highways/Segments/CityColors
  directly; external code only ever sees this via the const `GetRenderSnapshot()`
  accessor" paragraph - documenting (not changing) the enforcement mechanism that already
  existed structurally.

**`Private/Debug/NexusDebugRenderSnapshot.cpp`**:
- `Refresh()`'s segment-building loop now populates the four new fields via
  `FindPoint(*pointAId)`/`FindPoint(*pointBId)` (backed by `PointIndexById`, already fully
  populated earlier in the same `Refresh()` call, before the Segments loop runs) - a
  struct-to-struct copy from the already-resolved `FNexusDebugSnapshotPoint` entries, not
  a new Landscape read. Zero new live queries added.

**No renderer, subsystem refresh-gating, or LOD/culling logic was changed** - the
existing `FNexusDebugLOD` batching, `MaxFullDetailObjects`/`FullDetailDistance`/
`DebugRadius` defaults (2026-08-10), and the dirty/fingerprint refresh gate are untouched,
per this task's "preserve current LOD/fade/culling improvements" and "only change part"
instructions.

## Verification

Editor was running with Live Coding active, which blocks `Build.bat` (`Unable to build
while Live Coding is active`) - user chose to close the editor manually, then the build
was re-run:

```
Build.bat NexusFrameworkEditor Win64 Development -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject
```

**Result: Succeeded.** 5 actions (adaptive unity build excluded
`NexusDebugRenderSnapshot.cpp` since it changed), ~19s.

No automated test run/added - per `AGENT-RULES.md`'s Agent Testing Policy. No in-editor
verification performed (same policy) - **user should verify manually**:
- `Debug > Landscape > Segments` still visually curve-follows the real Landscape spline
  exactly as before (only new cache fields were added; no sampled-geometry math changed).
- The three-way Activation Point A/B/C test (Debug OFF + Add; Debug ON + Segments OFF +
  Add; Debug ON + Segments ON + Add) - none should force a Landscape segment rebuild,
  matching the untouched `MarkRepresentationDirty()` call sites confirmed above.
- Whether the reported 1-3s freeze / memory growth is actually reduced. See "Important
  Notes" below for why this pass may not be sufficient on its own.

## Result

`FNexusDebugSnapshotSegment` is now a fully self-contained per-segment cache record
(Start/End Location, Start/End Rotation, Start/End Tangent, sampled curve points) as this
task's cache-field list literally asks for, with explicit "do not author manually"
markers on every cached field across the three snapshot structs. Confirmed (not just
assumed from the prior day's records) that the render path, the refresh-gating, the
ActivationPoint isolation, and the Runtime-export isolation this task also asked to
verify were all already correctly in place before this pass - extended the existing
cache rather than building a duplicate system, per the task's own instruction.

## Important Notes

- **This pass did not find a code path that queries live Landscape data from a normal
  per-frame Tick/render call** - every live read is inside `Refresh()`, gated by the
  dirty flag or the change-detecting fingerprint poll. If the reported 1-3s freeze
  persists after this change, the likely remaining suspects (found but NOT touched this
  pass, since fixing them wasn't asked for and risks guessing rather than measuring, per
  this project's own repeated "do not guess" instruction) are:
  1. **`RefreshRepresentationIfDue` still runs its cheap fingerprint poll every 0.25s
     regardless of whether ANY Debug category is visible** - `UNexusFrameworkSubsystem::
     Tick` calls it unconditionally whenever `ActiveConfig` is set, not gated on the
     Debug root checkbox. This is a real, if cheap (O(control points + segments), raw
     field reads only), live Landscape query happening even with Debug fully OFF -
     flagged since the user's stated goal is literally "zero live Landscape geometry
     queries during idle rendering," which this poll does not currently satisfy to the
     letter, even though it is not expected to be the 1-3s cost by itself.
  2. **`Refresh()` still rebuilds the ENTIRE `Segments` array (full `EnumerateSegments`
     Landscape read + Hermite sampling for every segment) whenever it runs at all, with
     no gate on whether `Landscape.Segments`/`Roads.Highways/Lanes/Sidewalks` (the only
     four consumers of `Segments`/`CurveSamples`) are actually visible** - unlike
     `JunctionType`, which already skips its own computation via
     `NeedsJunctionClassification()` when nothing visible reads it. This is the most
     likely real remaining cost on a large map, and the most likely explanation for
     "especially Landscape > Segments" in the user's report if the freeze is triggered by
     a `Refresh()` call rather than by drawing. **Not implemented this pass** - doing this
     safely requires also marking the snapshot dirty on a category-visibility TOGGLE (not
     just on a data mutation), otherwise turning `Landscape.Segments` ON would show
     nothing until the next real topology change is polled, a new regression this session
     did not want to introduce without the user's sign-off given the "only change part"
     instruction. Available for pickup as a dedicated follow-up if the user confirms
     (with real `Nexus Perf Trace:`/`LogIfSlow` numbers from a live A/B run) that `Refresh`
     itself, not rendering, is the actual cost.
  3. The still-open, separately-tracked 2026-08-11 finding from this same day's earlier
     investigation (`activation-point-debug-on-freeze-investigation.md`): a genuine
     duplicate `PublishHierarchySelection`/`SetDetailsTarget` broadcast per
     ActivationPoint creation, and `BuildHierarchyTreeFromConfig`'s full O(N)-ish tree
     rebuild on every mutation - neither proven to be Debug-conditional, neither fixed,
     both still awaiting real trace numbers from an in-editor run.
- **Serialization risk**: none of this pass's changes are `UPROPERTY`s (plain C++ struct
  fields, `FNexusDebugSnapshotSegment` is not a `USTRUCT`) - `v6-coding-standard.md`'s
  renaming/redirect concern does not apply; every change here is additive (new fields) or
  internal-only (private, non-reflected implementation).
- **Next step requires the user to run the editor** (AGENT-RULES.md's Agent Testing
  Policy) with the existing `Nexus Perf Trace:`/`LogIfSlow` instrumentation already in
  place from today's earlier pass, specifically watching whether
  `FNexusDebugRenderSnapshot::Refresh` itself is the multi-second cost (vs. Slate/tree
  rebuild costs already flagged separately) - that would confirm suspect #2 above and
  justify implementing the visibility-gated Segments rebuild as a real fix rather than a
  guess.
