# Re-sync From Landscape Doesn't Initialize Proxy/Gizmo Interaction Without a Landscape Mode Cycle

Date: 2026-08-11
Category: bug-fixed
Phase: N/A (ad-hoc, `agent-todos/ready-for-review/still-not-fix.md`)

## Context

User report: after opening a project/map and clicking "Re-sync from Landscape," nearby
Editor Proxy Actors and the gizmo tool don't become interactive - entering Landscape Mode
and then leaving it again makes them start working. The user's own filed "Required fix"
already describes the intended architecture almost exactly as it already exists
(`FNexusLandscapeModeExtension::RefreshNexusInteractionState`'s `shouldBeInteractive =
isSelectModeActive && subsystem->IsNexusReady()` gate, built earlier the same day in
`2026-08-11/feature-add/editor-usability-select-mode-gizmo-sync-policy.md`), which made
this a "why does an already-correct-looking wiring not fire" investigation rather than a
missing-feature one.

## Problem / Goal

Find why `SetNexusReady(true)` (called at the end of a successful Re-sync) does not
appear to reach `RefreshNexusInteractionState` in practice, when the exact same function
demonstrably DOES run correctly from `OnEditorModeIDChanged` (proven by the user's own
"cycling Landscape Mode fixes it" workaround).

## Findings

- `RefreshNexusInteractionState` is called from exactly two places:
  `OnEditorModeIDChanged` (bound via `EditorModeChangedHandle`, known-working per the
  user's own workaround) and the `OnNexusReadinessChanged` broadcast (bound via
  `NexusReadinessChangedHandle`).
- `NexusReadinessChangedHandle` was bound in exactly ONE place,
  `FNexusLandscapeModeExtension::RegisterToFirstLevelEditor()`, itself only ever called
  from `OnLevelEditorCreated` in the normal case - a SINGLE best-effort attempt, gated on
  `GEditor->GetEditorSubsystem<UNexusFrameworkSubsystem>()` already being resolvable at
  that exact moment, with no retry anywhere if it returned null.
- This project already has one CONFIRMED case of exactly this ordering fragility in the
  immediately-adjacent startup path -
  `2026-08-11/bug-fixed/pdi-debug-rendering-backend-startup-crash-fix.md` ("too early in
  V6's own startup order," `GLevelEditorModeTools()` called from `StartupModule()` before
  the mode manager could safely exist) - and this codebase's OWN established fix for that
  exact class of problem is visible two functions away in the same module
  (`FNexusFrameworkEditorModule::TryActivateDebugDrawMode`/
  `RegisterDebugDrawModeToFirstLevelEditor`, which retries from BOTH
  `OnLevelEditorCreated` AND `FCoreDelegates::GetOnPostEngineInit()`, specifically because
  a single attempt was not considered reliable enough for LevelEditor/subsystem-dependent
  registration in this codebase).
- Could not empirically confirm this is the actual failure (this agent cannot launch the
  editor, per `AGENT-RULES.md`) - two other plausible-but-unconfirmed hypotheses were
  investigated and NOT ruled out (see Important Notes below): `FEditorModeTools::
  IsDefaultModeActive()`'s state timing right after a map load (`FEditorFileUtils::LoadMap`
  calls `DeactivateAllModes()` on every load, though `FEditorModeTools::Tick()` self-heals
  to Default mode within one frame if nothing is active - engine-source-confirmed, but the
  exact race window relative to a user's click could not be ruled out either way), and
  `GCurrentLevelEditingViewportClient` staleness right after a docked-panel button click
  (a separate gate inside `FNexusEditorProxyPool::TickUpdateNearbyProxies`, unrelated to
  the interactivity flag itself).

## Changes

- `UI/NexusLandscapeModeExtension.h/.cpp` - extracted the `NexusReadinessChangedHandle`
  bind into a new, idempotent `TryBindNexusReadinessHandle()` (early-returns if already
  bound). Called from both `RegisterToFirstLevelEditor()` (original call site, unchanged
  behavior when it already succeeds) and a new `FCoreDelegates::GetOnPostEngineInit()`
  binding registered in `Register()` (`OnPostEngineInitBindNexusReadinessHandle`) -
  mirrors `TryActivateDebugDrawMode`'s own established retry pattern exactly, not a new
  architecture. `OnPostEngineInit` is guaranteed to fire after full engine + subsystem
  init, strictly before a user could reach the Re-sync button, so whichever of the two
  attempts runs first successfully binds the handle and the other becomes a harmless
  no-op.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development` - succeeded, zero
  errors/warnings.
- **Not manually verified in-editor** - this fix's root-cause hypothesis is NOT
  empirically confirmed (see Findings/Important Notes) - the change is a safe,
  strictly-additive hardening of an already-correct subscription, not a proven fix.

## Result

Implemented and build-verified, confidence level stated honestly in both this record and
the `agent-todos` task file: this closes a real, confirmed-class-of-bug (single-attempt
subsystem-dependent delegate binding with no retry, already caught once before in this
exact module) but was not empirically proven to be THIS symptom's actual cause. Cannot
regress any currently-working behavior - purely adds a second, idempotent chance for an
existing subscription to succeed.

## Important Notes

- If the user retests and the symptom persists, do NOT assume this fix's hypothesis was
  correct - re-open with the two other suspects identified above (`IsDefaultModeActive()`
  state timing right after a map load; `GCurrentLevelEditingViewportClient` staleness
  right after a UI-panel click) as the next places to look, both already engine-source-
  investigated in the `agent-todos` task file's own Important Notes but not fixed pending
  real evidence they're the actual cause - the same "don't fix an unproven hypothesis
  further, get real numbers first" discipline this project already applied in
  `2026-08-11/bug-fixed/activation-point-debug-on-freeze-investigation.md`.

## Correction — 2026-08-12

**The user retested and the symptom persisted** - this fix's hypothesis (a missed
`OnNexusReadinessChanged` subscription) was NOT the true root cause, confirmed wrong
rather than assumed: `TryBindNexusReadinessHandle`/`OnPostEngineInitBindNexusReadinessHandle`
were re-read in full in the current codebase and are genuinely present and correctly
wired - the fix above did not regress or get lost, it was simply insufficient.

Picked up as a re-opened `agent-todos` task (`still-not-fix.md`, moved back to
`ready-for-development/` by the user, then through `active/` -> `ready-for-review/` this
pass). Traced the full call chain fresh rather than re-guessing: confirmed
`SetInteractionEnabled(true)` DOES correctly fire on Re-sync (the thing this fix's own
hypothesis was about) - the actual, previously-undocumented gate is a SEPARATE, later
check inside `FNexusEditorProxyPool::TickUpdateNearbyProxies`
(`NexusEditorProxyPool.cpp`): an unconditional hard-`return` whenever
`GCurrentLevelEditingViewportClient` (the engine's own "last viewport the mouse entered/
focused" global, confirmed via `Editor.h`'s own declaration) is null or non-perspective,
with no fallback. Nothing sets that global proactively at level-editor-open time - only a
real mouse-enter/focus event on a 3D viewport updates it - so it can legitimately still be
null immediately after opening a project and clicking a DOCKED PANEL button ("Re-sync
from Landscape") without the user ever having touched the 3D viewport first, exactly
matching this bug's own literal repro steps. `bInteractionEnabled` was correctly `true`
the whole time; this second, independent gate silently blocked all proxy binding
regardless, on every Tick, until some LATER action (e.g. a mode-toolbar click adjacent
to/inside the viewport, as entering/leaving Landscape Mode naturally involves) happened to
touch a viewport and populate the global as a side effect - directly explaining "works
after cycling Landscape Mode."

**Fixed**: `TickUpdateNearbyProxies` now resolves its viewport client via a new
`ResolveActiveLevelViewportClient` helper (same file), which falls back to
`GEditor::GetLevelViewportClients()` (confirmed real UE 5.8 API via engine source,
`EditorTransformGizmoUtil.cpp`'s own usage) - the first perspective Level Editor viewport
client GEditor already knows about - whenever the primary global is unusable. Also added
diagnostic logging (`SetInteractionEnabled`'s transitions, `RebuildSpatialIndex`'s
resulting indexed-point count, a one-shot log when the viewport fallback triggers) so a
further reproduction, if the symptom somehow still persists, yields concrete log evidence
instead of a fourth round of static-analysis guessing. Full record in `still-not-fix.md`'s
own newly-appended `## Completed (follow-up, 2026-08-12)` section (per
`AGENT-TODO-RULES.md` rule 8) - not duplicated here in full.

**Confidence, stated plainly**: higher than the original 2026-08-11 fix (a concrete,
directly-repro-matching hard-blocking code path found by tracing the actual call chain,
not a plausible-but-unconfirmed race) but still not empirically proven in a live editor
session (`AGENT-RULES.md`'s Agent Testing Policy). The `IsDefaultModeActive()` map-load
timing suspect was not independently re-investigated this pass - the viewport-client gate
fully and directly explains the reported symptom on its own.

## Correction — 2026-08-12 (second)

**The user reported the symptom a third time** (phrased slightly differently: "drag
gizmo not display... it display after visit landscape and back to same editor mode"),
after both the 2026-08-11 fix above and the first Correction's viewport-client fallback.
Traced the chain fresh rather than assuming either earlier fix was wrong: confirmed both
are genuinely present and structurally sufficient to reach `FNexusEditorProxyPool::BindSlot`
on the very first Tick after Re-sync. Neither was wrong - both closed real gaps - but a
third, later gap remained: `BindSlot`/`UnbindSlot` change a proxy Actor's visibility
(`SetIsTemporarilyHiddenInEditor`) and click-hit state (`SetActorEnableCollision`), but
nothing in this pool ever told the Level Editor viewport itself to redraw. A viewport
with Realtime OFF (a common, often-default editor setting) only re-renders - and only
re-runs its GPU hit-proxy click-picking pass - on demand: real viewport input, an
explicit invalidate, or an unrelated action that happens to force one. Entering/leaving
Landscape Mode was never special because of readiness-handle wiring or viewport-client
resolution (the two earlier hypotheses) - a mode-toolbar change simply forces a real
viewport redraw as a side effect, which was the one thing this pool itself was never
doing for its own bind/unbind state changes. This is a concrete, well-known engine
behavior (Realtime-off hit-proxy staleness), not a guess, and explains both halves of the
symptom (not visible, not draggable) consistently with everything already confirmed in
the two entries above.

**Fixed**: `TickUpdateNearbyProxies` (`NexusEditorProxyPool.cpp`) now tracks whether a
real bind/unbind happened this pass (never a pure anchor-refresh of an already-bound,
already-visible proxy) and, only then, calls `GEditor->RedrawLevelEditingViewports(true)`
once - forcing both the redraw and the hit-proxy invalidation, without adding any new
per-frame cost while the pool is otherwise idle. Full record in `still-not-fix.md`'s own
newly-appended `## Completed (follow-up, 2026-08-12, third pass)` section - not
duplicated here in full.

**Confidence, stated plainly**: this diagnosis rests on well-established, documented
Unreal Editor viewport behavior (Realtime-off viewports not auto-refreshing hit-proxy
state), not a novel guess, and is consistent with - not contradictory to - both earlier
entries in this file. Still not empirically proven live (`AGENT-RULES.md`'s Agent Testing
Policy - this agent cannot launch the editor). If the user's retest still shows the
symptom, see `still-not-fix.md`'s own Important Notes for the next instrumentation step
(logging whether `anyVisibilityChanged` actually goes true on the first post-Re-sync
Tick).

## Correction — 2026-08-12 (third): diagnostic instrumentation, no new fix claimed

**The user reported the redraw fix (second Correction above) did not resolve it either**,
and explicitly asked for logging to trace whether the relevant methods actually fire
during a Landscape Mode visit and during a Re-sync click, rather than another guess. Added
`UE_LOG` tracing end-to-end across the whole chain (Re-sync click ->
`TryBindNexusReadinessHandle` -> `OnEditorModeIDChanged` ->
`TickUpdateNearbyProxies`'s per-pass summary and redraw confirmation -> `BindSlot`/
`UnbindSlot`) - purely additive, no control flow changed, cannot regress anything. Full
detail in `still-not-fix.md`'s own newly-appended `## Completed (follow-up, 2026-08-12,
fourth pass)` section, including how to read the captured log once the user reproduces it.
No root cause chosen this pass, deliberately - three plausible-but-unconfirmed hypotheses
already exist in this file's history; the next entry here will be evidence-based rather
than a fourth guess.

## Correction — 2026-08-12 (fourth): real captured log points at a different, more fundamental failure - ActiveConfig itself going null

**The user provided a real captured Output Log** from the instrumentation added above.
It shows a fully successful bind pass (`TickUpdateNearbyProxies: pass - ...
desiredIds=61` followed by 61 matching `BindSlot` lines - proxies genuinely bound at
least once) immediately followed by a long, rapid, un-throttled, back-to-back run of
`RebuildSpatialIndex: indexed 0 Activation Point(s)` with nothing interleaved. That exact
pattern - rapid, no throttle gap, nothing else between the lines - only matches ONE code
path: `UNexusFrameworkSubsystem::RefreshRepresentationIfDue`'s own `!ActiveConfig` branch,
the only caller of `RebuildSpatialIndex` with no throttle at all (it runs every single
Tick unconditionally once `ActiveConfig` is null). This means `ActiveConfig` itself went
back to null sometime after the successful bind - a more fundamental failure than any of
the three previously-investigated hypotheses (missed readiness subscription; stale
viewport client; missing redraw/hit-proxy invalidation), all of which are moot once there
is no config to index.

**Instrumented, not yet fixed** (deliberately - only two call sites can null
`ActiveConfig`, and the evidence in hand couldn't yet distinguish which): `SetActiveConfig`
moved from an inline header setter to a logged function (every transition, every call
site, unconditional); `ResetForMapSwitch`/`HandleMapOpened`/`HandleMapChange` now log
unconditionally too (a real map switch is rare enough this can't spam). Full detail in
`still-not-fix.md`'s own newly-appended `## Completed (follow-up, 2026-08-12, fifth
pass)` section. Two candidate explanations remain open pending the next captured log: a
second Re-sync click whose `ResolveActiveLandscape()` call failed, or a genuinely spurious
map-change broadcast (possibly correlated with Landscape Mode entry/exit, which would be
a new, separate, real bug distinct from everything investigated so far).

## Correction — 2026-08-12 (fifth): real root cause found via engine source for "bound + selected but zero gizmo handles"

**The user provided a screenshot**, not a log this time: a proxy Actor genuinely bound
and selected (Outliner + Details panel both confirm it), correctly positioned, but with
NO translate/rotate/scale widget drawn around it at all. Traced UE 5.8's own engine
source (not this project's code) for what actually controls native transform-widget
visibility: `FEditorModeTools::GetShowWidget()` -> the built-in Select mode's own
`FLevelEditorSelectModeWidgetHelper::ShouldDrawWidget()`
(`Engine/Source/Editor/UnrealEd/Private/Tools/DefaultEdMode.cpp`), which reads
`GCurrentLevelEditingViewportClient` DIRECTLY and returns `false` outright if it's null -
no fallback of its own. This is the exact same global this file's own second Correction
(2026-08-12, second) already found to be legitimately null right after a docked-panel
Re-sync click - but that earlier fix (`ResolveActiveLevelViewportClient`'s
`GetLevelViewportClients()` fallback) only ever fixed THIS POOL's own reads of the
global; it never told the ENGINE the resolved viewport was "current," so the engine's own
native widget check kept failing independently, for every selected Actor, regardless of
every other fix already in place.

**Fixed at the actual source**: `ResolveActiveLevelViewportClient`'s fallback now calls
the resolved viewport's own `SetCurrentViewport()` - a real, public, exported UE 5.8 API
(`LevelEditorViewport.h`) that does exactly what a genuine mouse-enter/focus event does
(sets the global, `Invalidate()`s the old and new viewport correctly) - not a partial
workaround. Full detail in `still-not-fix.md`'s own newly-appended `## Completed
(follow-up, 2026-08-12, sixth pass)` section, including why this doesn't contradict or
replace any of the previous five passes (each fixed a separate, real gap earlier in the
chain) and why the `ActiveConfig`-going-null lead from the previous Correction remains a
separate, still-open question.
