# Gizmo Scalability Audit — Selection-Driven Architecture vs. 99,999+ Objects

Date: 2026-08-11
Category: research (verification of already-built code against a new mandatory
requirement — no code was changed by this record)
Phase: N/A (audits Phase 48's already-implemented gizmo tool; informs Phase 49 and all
future Traffic Light/City Light/Crosswalk/city-object authoring phases)

## Context

The user stated a mandatory, project-wide scalability requirement for V6's gizmo
architecture, in anticipation of 99,999+ authored city/debug objects: gizmos must be
strictly selection-driven — never one gizmo per object, O(1) gizmo creation relative to
total object count, no full-object-set scan every gizmo frame, and a gizmo drag must
only touch the selected object's own data/dirty state. This applies to Phase 49
(Activation Point — End-to-End Smoke Test, the currently-recommended next phase) and
every future Traffic Light/City Light/Crosswalk/city-object gizmo phase. Rather than
assume compliance, this record audits the actual, already-built Phase 48 gizmo code
(`UNexusActivationGizmoTool`/`FNexusActivationGizmoManager`, status `Ready for Review`)
line-by-line against each stated rule, since Phase 49 (and everything after it) inherits
this exact mechanism unchanged.

## Findings — rule-by-rule compliance

Source read: `Public/Private/Gizmo/NexusActivationGizmoTool.{h,cpp}`,
`Public/Private/Gizmo/NexusActivationGizmoManager.{h,cpp}`.

| Rule | Compliant? | Evidence |
|---|---|---|
| Never create/keep a gizmo per object | **Yes** | `ActiveGizmo`/`ActiveTransformProxy` are single `UPROPERTY` members on the tool (`NexusActivationGizmoTool.h:94-98`) — no per-object array or map anywhere. |
| Unselected objects have no active gizmo/tool instance | **Yes** | Nothing is created for any object until `SelectSubPoint` runs; unselected objects have zero associated engine objects. |
| Only the selected object/sub-point owns a gizmo | **Yes** | `SelectedActivationPointId`/`SelectedSubPointKey` are single scalar fields, not a set — one selection, one gizmo. |
| Changing selection deactivates/reuses the previous gizmo and binds to the new target | **Yes, via destroy-then-recreate** | `SelectSubPoint` calls `ClearSelection()` first (line 156), which calls `GizmoManager->DestroyGizmo(ActiveGizmo)` (line 190) before a fresh `UTransformProxy`/`UCombinedTransformGizmo` is created for the new target. This satisfies "deactivate" literally; it does not literally *reuse* the same gizmo instance object (see Important Notes for why this is a nuance, not a violation, of the O(1) requirement). |
| Deselecting removes/deactivates the gizmo completely | **Yes** | `ClearSelection()` (called on click-away, `OnClickedInViewport` line 150, and on tool `Shutdown`) destroys the gizmo and nulls both `ActiveGizmo`/`ActiveTransformProxy`. |
| Wireframe/PDI rendering stays independent, many objects via LOD/culling | **Yes, pre-existing/unrelated** | `RenderActivationPoints` (Phase 46) and the PDI backend (this same day's earlier migration) are untouched by the gizmo tool — the tool only reads the same `FNexusDebugRenderSnapshot`/test store the renderer already reads, never re-renders or gates rendering itself. |
| Gizmo creation is O(1) relative to total object count | **Yes, for the gizmo widget itself** | `UE::TransformGizmoUtil::CreateCustomTransformGizmo` (line 173) is one call producing one gizmo, regardless of how many total Activation Points exist — its cost is a function of the gizmo's own sub-elements (`StandardTranslateRotate`), not the object count. See Important Notes for the one real caveat (selection acquisition, not gizmo creation, is not O(1)). |
| No full-object-set scan every gizmo frame | **Yes, no per-frame scan** | The tool has no `Tick`/per-frame hook at all — `FindClosestSubPointHit` runs only from `OnIsHitByClick`/`OnClickedInViewport`, both driven by a discrete click event (`ULocalSingleClickInputBehavior`), not a frame timer. During an active drag, only `HandleGizmoTransformChanged` runs (per drag-delta, not a scan — see next row). |
| Gizmo drag updates only the selected object's data, marks only necessary dirty state | **Yes** | `HandleGizmoTransformChanged` (line 200) resolves exactly one point (`FNexusActivationPointTestStore::Get().FindPointById(SelectedActivationPointId)`) and writes exactly one sub-point's offset via `FNexusActivationSubPointResolver::SetSubPointOffset`. It does not call `UNexusFrameworkSubsystem::MarkRepresentationDirty()` — correct, since Phase 46/47's own notes already establish Activation Points are read live by the renderer every frame (no cached Representation entry exists for them to invalidate) and `MarkRepresentationDirty` is explicitly reserved for Landscape/Highway/HighwayPoint topology changes only (`NexusFrameworkSubsystem.h`'s own comment: "Deliberately NOT called for ActivationPoint mutations"). |

**9 of 9 literal rules are satisfied by the already-built Phase 48 code, with one real,
worth-flagging caveat below** — not a violation of anything stated, but the honest
answer to "will this actually hold up at 99,999+ objects."

## The one real gap: click-time selection is O(N × sub-points), not O(1)

`UNexusActivationGizmoTool::FindClosestSubPointHit` (called from both `OnIsHitByClick`
and `OnClickedInViewport`) does a full linear scan over EVERY currently-selectable,
currently-drawn `FNexusActivationPoint` in `FNexusActivationPointTestStore::Get().
GetPoints()`, and for each one calls `FNexusActivationSubPointResolver::
EnumerateResolvedSubPoints` (a property-reflection walk over the payload struct, not a
cheap operation) before doing the actual ray-vs-sphere distance test on each resolved
sub-point. This is a real O(N × average-sub-points-per-object) cost, paid once per click
attempt (both an actual click AND — because `ULocalSingleClickInputBehavior` calls
`IsHitByClickFunc` to answer "would a click here hit anything" — potentially once per
candidate click evaluation, though not per rendered frame while idle or during an
active drag).

This does not violate any rule as literally stated ("gizmo creation" and "every gizmo
frame" both refer to the gizmo widget/frame-tick, not the one-time selection-acquisition
click) — but it is the one place this architecture will not scale cleanly to 99,999+
objects without a further change: a 100,000-point scan on every click, each doing
reflection-based sub-point enumeration, will eventually become perceptible (though
likely still fast in absolute terms — a single-frame linear scan even at 100k simple
struct reads is sub-millisecond territory on modern hardware; reflection overhead per
element is the actual unknown, not yet benchmarked).

## Recommendation (not implemented — informational)

Phase 47 already built exactly the tool needed to fix this: `FNexusSpatialGridIndex`
(`Public/Private/Representation/NexusSpatialGridIndex.*`), a uniform-grid nearest-neighbor
structure, currently wired only to a synthetic benchmark command
(`Nexus.Representation.BenchmarkSpatialGridIndex`) with "not yet wired to any real data
source" explicitly flagged in its own phase file. Using it as a broad-phase filter before
`FindClosestSubPointHit`'s narrow-phase ray-vs-sphere test (query a small radius around
the click's ground-plane/camera-near intersection, or maintain per-viewport-frustum
candidate sets) would turn the click-time cost from O(N) into O(candidates-near-click),
independent of total object count — closing this one gap without changing anything about
the gizmo lifecycle itself (which is already fully compliant). This is a natural fit for
Phase 49's own "document any friction/gap found... escalate rather than silently patch"
completion criterion (see the note appended to `phase-49.md`), not a blocking issue for
Phase 49 itself at current/near-term object counts.

## Result

No code was changed. The already-built Phase 48 gizmo tool (`UNexusActivationGizmoTool`/
`FNexusActivationGizmoManager`) is confirmed, by direct code reading, to already
implement a strictly selection-driven, single-gizmo-instance architecture matching every
literal rule the user stated, with one flagged forward-looking gap (click-time selection
scan cost) that has a clear, already-partially-built fix path (Phase 47's spatial index)
rather than requiring new architecture. This requirement has been formally added to
`project-specifications/13-v6-gizmo-system.md` as a named, mandatory section (see that
file's own new "Scalability requirement" section) so it governs every future
authoring-gizmo phase (Traffic Light/City Light/Crosswalk/etc.), not just Phase 48/49.

## Important Notes

- **"Destroy and recreate" vs. "reuse the same gizmo instance"**: the current code
  destroys the previous `UCombinedTransformGizmo`/`UTransformProxy` and constructs new
  ones on every selection change, rather than repositioning a single long-lived gizmo
  instance. This is O(1) per selection change (constant cost, independent of object
  count) so it does not violate the stated O(1)/no-per-object-instance requirements —
  but if a future profiling pass finds gizmo construction itself measurably expensive
  under rapid reselection, switching to reposition-in-place is the natural next
  optimization. Not flagged as required work now — no evidence it's actually a problem,
  just noted so a future reader doesn't have to re-derive it.
- **This audit did not modify `NexusActivationGizmoTool.{h,cpp}` or
  `NexusActivationGizmoManager.{h,cpp}` in any way** — read-only verification, per the
  user's own request to "select and report," not implement.
