# PDI-Based Debug Rendering Backend — V0/V1/V5 Reference Investigation + Proposed V6 Substitution

Date: 2026-08-11
Category: research (design proposal — **NOT implemented**, see Status below)
Phase: N/A (direct continuation of this same day's long-background-freeze investigation:
`bug-fixed/long-background-freeze-batchedlines-accumulation.md`)

## Status

**Findings and proposed design only. No code was written or changed for this record.**
The user explicitly gated implementation ("just generate .md file your fill fingig do not
impletement yet") after the report below was delivered in chat but before any file edit
was made. This record exists so the design isn't lost before the user reviews it and
authorizes implementation in a future session/turn.

## Context

Two prior records this same day (`bug-fixed/long-background-freeze-batchedlines-accumulation.md`
and the Timeline/Stall Diagnostics follow-up inside `feature-add/
nexus-performance-profiler-panel.md`) established, from real captured data, that
`BatchedLines.Num` on the transient `World->LineBatcher` spikes to over a million entries
(vs. an observed ~35k steady state) during this project's live-editing sessions, with a
large (~680MB) process memory swing associated with the eventual clear. The direct
mechanism (confirmed from UE 5.8 engine source, not guessed): Nexus's `DrawDebugLine`/
`DrawDebugSphere` calls pass `LifeTime=0.f`, which the engine substitutes with
`ULineBatchComponent::DefaultLifeTime` (`1.0f`) rather than "one frame only"; that
lifetime is only decremented/removed by `ULineBatchComponent::TickComponent`, an ordinary
WORLD/level tick, separate from `UNexusFrameworkSubsystem::Tick` (an editor-session-wide
`FTickableEditorObject` that keeps running regardless of whether the world/viewport is
actually ticking).

The user's own conclusion from this: the architecture itself is the problem, not scale —
"V6 has only ~10 small segments yet reaches ~1.2M-1.8M transient BatchedLines. V0/V1
render massive city debug geometry smoothly." Instructed: replace ONLY the low-level
debug-drawing backend (`DrawDebugLine`/`DrawDebugSphere` → `ULineBatchComponent`) with a
scalable V0/V1-style viewport/PDI primitive renderer, referencing V0 (primary), V1
(secondary), V5 (curved road/highway reference) — while keeping every other V6 system
(structures/data model, Debug Tree/categories, config/settings, hierarchy/details, cache,
LOD/fade/culling, Activation/Junction/Mapping logic, Highway/Lane/Sidewalk logic,
profiler, gizmo) completely unchanged. Explicit "do not"s: don't redesign V6 feature
architecture, don't remove features or reduce debug quality, don't merely clear/cap the
LineBatcher (a mitigation, not a fix), don't reintroduce the old conflicting custom
`UEdMode`.

## Findings — V0 (primary reference)

`E:\Projects\Game\UE\NexusFramework_V0\Source\NexusFrameworkEditor\Private\
NexusRoadGraph*.{h,cpp}` — a real, working, at-scale precedent (city-scale road-graph
editing/visualization), not a toy example.

1. **Two custom `FEdMode`s, not one, with very different risk profiles.**
   - `FNexusRoadGraphEdMode` — the real interactive editing mode (click/drag road points,
     handles, box-select). Has a toolkit (implied by its full interactive feature set),
     competes for exclusivity — the same shape as V6's old, already-reverted
     `UNexusEdMode`/`FModeToolkit` (see `ai-change-audits/2026-08-09/research/
     v5-custom-edmode-crash-vs-landscape-mode.md`).
   - `FNexusRoadGraphAlwaysDrawEdMode` — a SECOND, deliberately passive mode. Its entire
     header:
     ```cpp
     class FNexusRoadGraphAlwaysDrawEdMode : public FEdMode
     {
     public:
         static const FEditorModeID EM_AlwaysDraw;
         virtual bool IsCompatibleWith(FEditorModeID otherModeId) const override;
         virtual void Render(const FSceneView* view, FViewport* viewport, FPrimitiveDrawInterface* pdi) override;
         virtual bool ShouldDrawWidget() const override { return false; }
         virtual bool UsesTransformWidget() const override { return false; }
     };
     ```
     No toolkit, no `Enter()`/`Exit()` override, `IsCompatibleWith` returns `true` for
     every mode ID except its own — i.e. explicitly designed to coexist with whatever
     else (including Landscape Mode) is active.

2. **Drawing happens ONLY from `Render()`, never from `Tick()` — with an explicit,
   load-bearing comment explaining why:**
   ```cpp
   void FNexusRoadGraphEditorAlwaysDraw::Tick(float deltaTime)
   {
       if (!CanUseLevelEditorModeTools() || GEditor->PlayWorld) { return; }
       // Road graphs are drawn in FNexusRoadGraphAlwaysDrawEdMode::Render with a valid view (LOD + frustum).
       // Do not draw here without a view — large maps would redraw every tile every tick and hang the editor.
       EnsureOverlayModeActive();
   }
   ```
   `Tick()`'s only job is to keep the passive mode active (defensive re-activation, in
   case something else deactivated every mode). All real drawing is driven by the
   engine's own per-viewport render cadence, with a real `FSceneView` (frustum + LOD
   data) supplied by the engine, not synthesized.

3. **Drawing itself is raw PDI, not `DrawDebugLine`:**
   ```cpp
   void FRoadGraphPrimitiveDraw::DrawLine(const FVector& start, const FVector& end, const FLinearColor& color, float thickness) const
   {
       if (PDI) { PDI->DrawLine(start, end, color, SDPG_Foreground, thickness); return; }
       if (World) { DrawDebugLine(World, start, end, color.ToFColor(true), false, 0.f, SDPG_Foreground, thickness); }
   }
   ```
   Dual-backend by design: PDI when available (the normal editor-viewport case), falling
   back to `DrawDebugLine` only when no PDI exists (used by `DrawRoadGraphAlwaysVisible`,
   a `World`-only variant for contexts without a Render() pass). **PDI primitives have no
   persistent backing array and no lifetime/decay bookkeeping at all** — each frame's
   `Render()` call re-issues draw calls fresh; the PDI-collected primitives are consumed
   by that single frame's render and discarded. There is no mechanism by which they could
   accumulate the way `ULineBatchComponent::BatchedLines` does — this is a structural
   property of PDI, not a tuning parameter.

4. **LOD/culling** (explicitly NOT proposed for V6 in this pass — see Scope below):
   `IsLocationVisible(view, location, radius)` does `view->ViewFrustum.IntersectSphere(...)`
   + `view->WorldToPixel(...)` before every draw call; beyond `EditorFullDetailDistance`,
   highways/cities render as simplified "impostor" markers instead of full geometry
   (`RoadGraphEditorLOD::DrawHighwayImpostor`/`DrawCityImpostor`).

5. **Registration/lifecycle** (`NexusFrameworkEditorModule.cpp`) — the exact sequence to
   mirror:
   ```cpp
   FEditorModeRegistry::Get().RegisterMode<FNexusRoadGraphAlwaysDrawEdMode>(
       FNexusRoadGraphAlwaysDrawEdMode::EM_AlwaysDraw, DisplayName, FSlateIcon(), /*bVisible=*/false);
   ```
   (`bVisible=false` — hidden from the Modes toolbar, never user-selectable). Kept
   continuously active via `EnsureOverlayModeActive()` (checks `IsModeActive`, calls
   `ActivateMode` if not), called from `FCoreDelegates::OnPostEngineInit`,
   `levelEditor->OnLevelEditorCreated()`, and every `OnEditorModeIDChanged` event
   (defensive re-assertion). Shutdown has one explicit, already-solved gotcha worth
   carrying forward verbatim: **`GLevelEditorModeTools()` must not be touched during
   engine exit** — checked via `IsEngineExitRequested()` before `DeactivateMode`/
   `OnEditorModeIDChanged().Remove(...)`, per V0's own comment: *"it lazily creates
   ModeManagerInteractiveToolsContext and asserts 'Object is not packaged'."*

## Findings — V1 (secondary reference)

**Not a useful rendering reference.** `E:\Projects\Game\UE\NexusFramework_V1\Source` has
no `NexusFrameworkEditor` module, no `FEdMode`, no PDI usage anywhere (confirmed by
project-wide grep). Its one `DrawDebugLine` call site (`ProceduralCityBuilder.cpp:520`)
uses `bPersistentLines=true, LifeTime=-1.f` — a one-shot generation-preview draw meant to
be issued once and stay until an explicit `FlushPersistentDebugLines` call, not a
live/interactive massive-scale visualizer. V1 went a different direction entirely
(procedural mesh generation with a basic preview draw), not a rendering-scale precedent.

## Findings — V5 (curved road/highway rendering reference)

**Not a PDI reference — confirms V6 inherited the exact same limitation.**
`E:\Projects\Game\UE\NexusFramework_V5\Source\NexusFrameworkEditor\Private\
NexusFrameworkEditorSubsystem.cpp` is 100% `DrawDebugLine`/`DrawDebugSphere`, Tick-driven,
self-expiring — line 5598-5600's own comment: *"The DrawDebugLine/Sphere/Box calls below
self-expire (bPersistent=false, short LifeTime...) once this function stops calling them
every Tick."* This is the SAME mechanism and the SAME latent accumulation risk V6 has —
V5 does not have a PDI-based solution to borrow. What V5 DOES provide — curve/tangent
math (Hermite sampling, the engine-verified tangent-sign convention) — V6 already sourced
directly from UE 5.8 engine source (`LandscapeSplines.cpp`), not from V5's renderer (see
`ai-change-audits/2026-08-10/feature-add/phase-30a-curve-accurate-debug-lines-implemented.md`),
and that math is explicitly out of scope for this pass anyway (curve/segment generation
stays unchanged — only the OUTPUT primitive call changes).

## Findings — safety check against V6's own documented crash

V6's Phase 02/03 already hit and fixed a real crash from a custom `UEdMode`:
`Assertion failed: !Toolkits.Contains(NewToolkit)` in `ToolkitManager.cpp` — a **toolkit**
registration collision between a custom mode's `FModeToolkit` and Landscape Mode's own.
Confirmed directly from UE 5.8 engine source (`Engine/Source/Editor/UnrealEd/Private/
EdMode.cpp`):
- `FEdMode::UsesToolkits()` — base implementation returns `false`.
- `FEdMode::Enter()` — base implementation never touches `FToolkitManager` at all (only
  updates selected-actor component render state and broadcasts
  `FEditorDelegates::EditorModeIDEnter`).

A mode that never overrides `UsesToolkits()`/never registers a toolkit in `Enter()`
(exactly V0's `FNexusRoadGraphAlwaysDrawEdMode` shape) **cannot** hit that assertion,
regardless of whether Landscape Mode is simultaneously active — it is a structurally
different, safe pattern from the one V6 already ruled out, not a reintroduction of it.
This has real-world precedent too: V0 is a working project actively using this exact
pattern.

## Proposed minimal V6 substitution (design only — not implemented)

1. **New toolkit-less `FEdMode`** (working name `FNexusDebugDrawEdMode`) — registered
   hidden (`bVisible=false`), overrides only `IsCompatibleWith` (true for all but itself)
   and `Render(view, viewport, pdi)`. Kept continuously active via the same
   `OnPostEngineInit`/`OnLevelEditorCreated`/`OnEditorModeIDChanged` re-assertion pattern
   V0 uses, with the same `IsEngineExitRequested()` shutdown guard. Registered/unregistered
   from `FNexusFrameworkEditorModule::StartupModule()`/`ShutdownModule()`, additively
   alongside the existing `LandscapeModeExtension.Register()`/`Unregister()` calls — no
   change to that class or its own lifecycle.

2. **Split `UNexusFrameworkSubsystem::Tick()`.** Today `Tick()` calls
   `RefreshRepresentationIfDue()` (cache/LOD maintenance) AND
   `RenderDiagnosticsOverlay`/`DispatchDebugRenderers`/`LabelOverlay->UpdateLabels`
   (drawing) unconditionally, every editor tick, regardless of whether anything is
   actually being rendered. Proposed: `RefreshRepresentationIfDue()` stays on `Tick()`
   completely unchanged (still "data-state maintenance," matching the user's own
   long-standing stated goal from the earlier periodic-callback-inventory round: "Background
   mode should keep only necessary data-state maintenance"). The three drawing calls move,
   verbatim (no internal changes), into a new public method
   `RenderDebugPrimitives(FPrimitiveDrawInterface* pdi)`, called ONLY from the new
   `FNexusDebugDrawEdMode::Render()` (via `GEditor->GetEditorSubsystem<
   UNexusFrameworkSubsystem>()`, the exact accessor pattern already used elsewhere in this
   codebase, e.g. `NexusActivationGizmoTool.cpp:58`). This split is not optional busywork —
   PDI is only valid inside an actual `Render()` callback, so drawing cannot stay in
   `Tick()` once it uses PDI at all. It is also what actually fixes the freeze as a
   structural consequence, not a bolt-on: while the editor is backgrounded/minimized, no
   viewport renders, so `Render()` simply never fires and no debug primitives are
   submitted during that time — nothing to accumulate, in addition to PDI itself having no
   persistent backing array regardless.

3. **`FNexusDebugPrimitives`** (`Public/Private/Debug/NexusDebugPrimitives.{h,cpp}`) — the
   5 primitive functions (`DrawLine`/`DrawBox`/`DrawSphere`/`DrawArrow`/`DrawCapsule`) keep
   their EXACT existing public signatures (`(world, ..., config)`) — zero changes needed
   to any of the ~14 category-renderer `.cpp` files, `NexusDebugCategoryRegistry`,
   `NexusDebugRenderConfig`, or `NexusDebugRenderSnapshot`. Internally, add a small ambient
   "active PDI" context (a private static pointer + a small RAII `FScopedActivePDI` helper,
   set once per `Render()` pass by the new `RenderDebugPrimitives`): when a PDI is active,
   route to the engine's own already-shipped PDI-based equivalents (confirmed present in UE
   5.8's `Runtime/Engine/Public/PrimitiveDrawingUtils.h`, no new geometry math needed):

   | Current (`DrawDebugHelpers.h`) | PDI equivalent (`PrimitiveDrawingUtils.h`) |
   |---|---|
   | `DrawDebugLine` | `PDI->DrawLine(Start, End, Color, DepthPriorityGroup, Thickness, DepthBias, bScreenSpace)` |
   | `DrawDebugBox` | `DrawOrientedWireBox(PDI, Base, X, Y, Z, Extent, Color, DepthPriority, Thickness, ...)` (axes via `FQuat::GetAxisX/Y/Z()`, confirmed present) |
   | `DrawDebugSphere` | `DrawWireSphere(PDI, Base, Color, Radius, NumSides, DepthPriority, Thickness, ...)` |
   | `DrawDebugCapsule` | `DrawWireCapsule(PDI, Base, X, Y, Z, Color, Radius, HalfHeight, NumSides, DepthPriority, Thickness, ...)` |
   | `DrawDebugDirectionalArrow` | `DrawDirectionalArrow(PDI, ArrowToWorld, Color, Length, ArrowSize, DepthPriority, Thickness)` — needs a small start/end→matrix adapter (`FRotationMatrix::MakeFromX(direction) * FTranslationMatrix(start)`, both confirmed-present engine APIs) since the PDI version takes a transform, not two endpoints |

   When no PDI is active (any call site outside a `Render()` pass, e.g. a console
   command), fall back to the EXISTING `DrawDebug*` call — preserves current behavior for
   any such edge case, mirroring V0's own dual-backend design exactly. `TRACE_COUNTER_*`
   and `FNexusProfiler::Get().RecordDrawLine/RecordDrawSphere` calls stay exactly as they
   are today (profiler untouched, per the user's explicit constraint).

4. **Explicitly OUT of scope for this pass** (per the user's own "keep completely
   unchanged" list, honored deliberately, not by oversight): no new frustum/distance-based
   LOD or impostor system (V6's existing `FNexusDebugRenderSnapshot` cache/LOD/fade stays
   untouched); no changes to any category renderer's own drawing logic/order/content; no
   changes to `NexusDebugCategoryRegistry`, Hierarchy/Details/Diagnostics panels, gizmo,
   Mapping/Activation/Junction logic, or the profiler's own code (only its EXISTING
   `NEXUS_PROFILE_SCOPE` call sites move along with the code they wrap, matching the
   Tick→Render split above — e.g. `Nexus.Debug.Dispatch` becomes a child of a new
   `Nexus.Render.DispatchDebugPrimitives` scope instead of `Nexus.Tick`, which is an
   expected, correct consequence of the split, not a profiler behavior change).

5. **Expected side effect worth flagging in advance**: `RenderDebugPrimitives` will be
   called once per open, actively-rendering editor viewport per frame (not once per "true"
   frame) if the user has multiple viewports open (e.g. a 4-pane layout) — this is correct
   and required (each viewport has its own camera/frustum, so per-viewport dispatch is
   inherent to any PDI-based approach, exactly matching V0's own characteristic and how the
   engine's own scene rendering already works), not a regression to flag as a bug later.

## Important Notes

- **This entire record is a proposal, not a change.** No `.h`/`.cpp` file in
  `NexusFrameworkEditor` was modified to produce this document — confirmed by this
  session's own tool-call history (Read/Grep/Glob only, against both `NexusFramework_V6`
  and the sibling `V0`/`V1`/`V5` projects, plus UE 5.8 engine source for API verification).
- **Two engine APIs referenced above were verified present but not yet compiled against
  V6's actual usage**: `FQuat::GetAxisX/Y/Z()` (confirmed declared in `Math/Quat.h`) and
  `FRotationMatrix::MakeFromX` (referenced from memory/typical UE API shape, not yet
  grep-confirmed in this session before implementation was paused) — worth a quick
  existence check at the start of implementation, not a blocking risk either way since a
  one-line equivalent (`FRotationMatrix(FRotator::MakeFromX...)` or manually orthonormalizing
  from the direction vector) is trivial if the exact name differs.
- **Next step, on explicit authorization**: implement in the order listed under
  "Proposed minimal V6 substitution" above (mode class + module registration first since
  it's inert until wired up, then the `Tick()`/`RenderDebugPrimitives` split, then the
  5-function backend swap last since it's the only part that changes visible behavior),
  building after each step. The profiler's own Timeline (`BatchedLines.Num` via direct
  `World->GetLineBatcher()` inspection, already built this session) is the intended
  verification tool — a post-fix capture should show `BatchedLines.Num` staying near-zero
  throughout a background/foreground cycle that previously produced a multi-hundred-
  thousand-line spike.
