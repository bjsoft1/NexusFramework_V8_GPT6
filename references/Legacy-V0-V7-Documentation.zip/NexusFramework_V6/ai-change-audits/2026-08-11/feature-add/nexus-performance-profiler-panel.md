# Nexus Performance Profiler Panel

Date: 2026-08-11
Category: feature-add
Phase: N/A (ad-hoc diagnostic tooling, direct continuation of this same day's two
"Landscape > Segments freeze" investigations - `activation-point-debug-on-freeze-
investigation.md` and `landscape-segments-freeze-cache-hardening.md`)

## Context

The cache-hardening pass earlier today did not resolve the user's reported freeze (Debug
ON + operations like Add City/Add State/Add Activation item causing CPU >50%, 5-15s
editor hangs, and memory spiking from ~4-5GB to as high as 20+GB before returning to
baseline). Rather than guess further, the user asked for a purpose-built diagnostic tool:
a dockable "Nexus Performance Profiler" panel, editor-only, Nexus-only, with an explicit
Start/Stop/Clear workflow, a sortable hierarchical TreeView (Method / Call Count / Total
Inclusive CPU / Total Exclusive CPU / Average / Max / allocation-ish columns), Unreal
Insights integration, and an explicit, detailed instruction to be HONEST about memory
attribution - no fabricated per-method byte counts, a documented "skip it and use a
lightweight alternative" fallback if real per-method allocation tracking would require
hooking the allocator.

## Goal

Build the tool so the NEXT session (the user's own manual 10-15s repro run) produces real
numbers - call counts, CPU totals, and honest memory deltas - for the actual freeze,
instead of another round of static-trace guessing.

## Design decisions

1. **No allocator hook, as instructed.** Real per-method allocation byte/count
   attribution would require wrapping `GMalloc` or enabling LLM (Low Level Memory
   tracking, a compile-time-gated engine subsystem not currently enabled in this
   project's build) - both explicitly listed by the user as "skip it" territory. Instead,
   every profiled scope samples `FPlatformMemory::GetStats().UsedPhysical` (process-wide,
   not per-call) at its own entry and exit, throttled to at most once every 2ms
   real time regardless of how many scopes push/pop in between (a real OS call, not
   free) - see `FNexusProfiler::SampleMemoryBytesThrottled`'s own comment. This is the
   literal "memory at method entry, memory at method exit, memory delta, peak memory
   during scoped operation" fallback the user's own instructions sanctioned.
2. **"Peak/Outstanding Bytes" per node**, not a per-method allocation count - the closest
   honest proxy to a per-call memory peak available without hooking the allocator: the
   largest (interior memory sample - this call's own entry sample) observed while the
   call was on the stack, propagated to every currently-open stack frame whenever a fresh
   sample is taken (a spike while three scopes are nested belongs to all three). Never
   fabricated as an exact byte count belonging to that method alone - the panel's own
   column tooltips say so explicitly.
3. **Hierarchical, not flat** - `FNexusProfilerNode` keys children by `FName` under
   their actual call-stack parent, so the SAME leaf name reached via two different
   parents (e.g. a shared `Refresh` reached from both `Tick` and a property-changed
   callback) becomes two separate tree entries with independent counters - directly
   answering the user's own "PropertyChanged -> Refresh vs. Tick -> Refresh, are we
   doing the same expensive work twice" question, not something that would show up in a
   flat function-name table.
4. **Two macros, not one** - `NEXUS_PROFILE_SCOPE(Literal)` (cheap, `TRACE_CPUPROFILER_
   EVENT_SCOPE_STR` under the hood - a static/cached event name) for every fixed call
   site, and `NEXUS_PROFILE_SCOPE_DYNAMIC(FString)` (`TRACE_CPUPROFILER_EVENT_SCOPE_TEXT`,
   explicitly documented by the engine as more expensive) reserved for the ONE genuinely
   dynamic call site this pass needed (the per-category debug renderer dispatch, where
   the category id is only known at runtime) - matches the user's own "prefer static
   names, dynamic only where actually needed" guidance.
5. **Near-zero overhead while stopped** - `FNexusProfilerScope`'s constructor/destructor
   degrade to a single `bool` read (`FNexusProfiler::IsActive()`) when not profiling; no
   `TMap` lookup, no `FPlatformTime`/`FPlatformMemory` call, nothing allocated. The
   Insights-side `TRACE_CPUPROFILER_EVENT_SCOPE_STR` call still runs regardless (that's
   the engine's own always-on-but-cheap design - a real Insights capture can be started
   independently of this custom tool), but it is already near-free when nothing is
   capturing (`CpuChannel` check short-circuits).
6. **Deliberately NOT instrumented: individual `FNexusDebugPrimitives::Draw*` calls.**
   These can run many thousands of times per Tick (one per curve segment/sample) -
   exactly the "do NOT add profiling scopes to every tiny function" case the user's own
   instructions warned against. Wrapping them in the full `NEXUS_PROFILE_SCOPE` (a TMap
   find/emplace per call) would itself become the performance problem being diagnosed.
   Instead they get a bare `TRACE_COUNTER_INCREMENT` (near-free) for the raw
   `Nexus/DebugLines`/`Nexus/DebugSpheres`/`Nexus/DebugItems` counters, and their
   AGGREGATE cost is already captured by the enclosing category renderer's own dynamic
   scope (`Nexus.Debug.Render.<CategoryId>`) - the "how many draw calls, from which
   category, cost how much in total" question is answered without touching the hot
   per-primitive path at all.
7. **Reused the existing Nomad-tab architecture exactly** - `SNexusProfilerPanel` is a
   fourth tab registered/opened/closed in lockstep with Hierarchy/Details/Diagnostics via
   `FNexusLandscapeModeExtension` (see that file's own established `RegisterNomadTabSpawner`/
   `TryInvokeTab`/`OnEditorModeIDChanged` pattern) - no new docking mechanism invented.

## Changes

**New: `Public/Profiling/NexusProfiler.h` + `Private/Profiling/NexusProfiler.cpp`**
- `FNexusProfilerNode` - one node per unique call PATH (`FName Name`, `CallCount`,
  `TotalInclusiveSeconds`, `TotalExclusiveSeconds`, `MaxCallSeconds`,
  `TotalMemoryDeltaBytes`, `MaxMemoryDeltaBytes`, `PeakOutstandingBytes`,
  `TMap<FName, TSharedPtr<FNexusProfilerNode>> Children`).
- `FNexusProfiler` - Meyer's singleton (`Get()`), game-thread-only (no locking, matches
  every instrumented call site's own real threading), `Start()`/`Stop()`/`Clear()`/
  `IsActive()`/`GetElapsedSeconds()`/`GetBaselineMemoryBytes()`/
  `GetPeakSessionMemoryBytes()`/`GetTotalCallCount()`/`GetRoot()`, and the
  `PushScope`/`PopScope` pair `FNexusProfilerScope`/`FNexusProfilerDynamicScope` call
  under the hood.
- `NEXUS_PROFILE_SCOPE(Literal)` / `NEXUS_PROFILE_SCOPE_DYNAMIC(FStringExpr)` macros -
  each drives BOTH this custom tree and a real `TRACE_CPUPROFILER_EVENT_SCOPE_*` Insights
  event, so the exact same call sites are visible in an Unreal Insights capture
  independently of this panel.
- Six `TRACE_DECLARE_INT_COUNTER` Insights counters: `Nexus/DebugLines`,
  `Nexus/DebugSpheres`, `Nexus/DebugLabels`, `Nexus/DebugItems`,
  `Nexus/LandscapeQueries`, `Nexus/RefreshCount` - monotonically increasing across the
  editor session (Insights shows the SLOPE during a capture window as the useful
  events/sec signal); not surfaced numerically inside the custom panel itself, Insights-
  only, per this task's own "add useful counters where appropriate" ask.

**New: `Public/UI/SNexusProfilerPanel.h` + `Private/UI/SNexusProfilerPanel.cpp`**
- Start Profiling / Stop Profiling / Clear buttons, live summary text (status, duration,
  peak process memory growth above baseline, total Nexus CPU across every top-level call
  path, total method calls).
- A 9-column sortable `STreeView` (`SMultiColumnTableRow`): Method, Call Count, Total
  Inclusive CPU, Total Exclusive CPU, Average Time, Maximum Single Call, Avg Memory
  Delta, Max Memory Delta, Peak/Outstanding Bytes - click any header to sort descending/
  ascending by that column (recursive per-node children sort, not a flat re-list).
  Column tooltips on the two memory columns explicitly state the "process-wide delta, not
  a per-method allocation count" limitation inline, not just in this document.
- Throttled (0.25s) live tree refresh while a session is active, so numbers visibly climb
  during the user's own 10-15s repro window instead of only appearing after Stop.

**Tab registration** (`Public/UI/NexusLandscapeModeExtension.h`,
`Private/UI/NexusLandscapeModeExtension.cpp`): new `ProfilerTabId`
(`"NexusProfilerPanel"`), `SpawnProfilerTab`, `ActiveProfilerTab` - registered in
`Register()`, invoked/closed alongside the other three tabs in `OnEditorModeIDChanged`,
unregistered in `Unregister()`. Purely additive to the existing four-method pattern.

**Instrumentation call sites** (additive `NEXUS_PROFILE_SCOPE`/`_DYNAMIC` +, where noted,
a counter increment - no existing logic changed at any of these sites):
- `Subsystem/NexusFrameworkSubsystem.cpp` - `Tick` (`Nexus.Tick`);
  `RefreshRepresentationIfDue` split into `Nexus.Representation.RefreshIfDue` (from
  right after the cheap dirty/poll gate, so its own CallCount means "got past the cheap
  check" not "Tick fired") and a nested `Nexus.Representation.Rebuild` (only the real,
  expensive graph+snapshot+diagnostics rebuild path, plus `TRACE_COUNTER_INCREMENT
  (NexusRefreshCount)` right there - directly answers "how often does the EXPENSIVE
  rebuild actually happen" from this session's own prior open question); nested
  `Nexus.Representation.PopulateGraph` and `Nexus.Diagnostics.Gather` around their own
  call sites; `DispatchDebugRenderers` (`Nexus.Debug.Dispatch`, plus a per-category
  `NEXUS_PROFILE_SCOPE_DYNAMIC("Nexus.Debug.Render.<CategoryId>")` around each renderer's
  own `Execute` call - generically covers every current AND future registered category
  from this one call site); `RenderDiagnosticsOverlay` (`Nexus.Debug.DiagnosticsOverlay`).
- `Debug/NexusDebugRenderSnapshot.cpp` - `Refresh` (`Nexus.Debug.Snapshot.Refresh`),
  sub-scoped by phase: `Nexus.Debug.Snapshot.ResolvePoints`,
  `Nexus.Debug.Snapshot.ClassifyJunctions`, `Nexus.Debug.Snapshot.BuildSegments`,
  `Nexus.Debug.Snapshot.BuildHighways` - the exact "RefreshDebugData ->
  BuildCityDebug/BuildHighwayDebug"-shaped breakdown the task asked for, and the
  function this session's two prior investigations have both pointed at as the likely
  real cost.
- `Reader/NexusLandscapeReader.cpp` / `.Segments.cpp` - `ResolveActiveLandscape`,
  `EnumerateControlPoints`, `ComputeLandscapeRevisionFingerprint`, `EnumerateSegments` -
  each scoped (`Nexus.Landscape.*`) and each incrementing `Nexus/LandscapeQueries`.
- `Mapping/NexusMapping.Reconciliation.cpp` - `ReconcileMappingStage`
  (`Nexus.Mapping.Reconcile`).
- `UI/SNexusHierarchyPanel.cpp` - `HandleCreateState`/`HandleCreateCity`
  (`Nexus.Hierarchy.CreateState`/`CreateCity`); `HandleCreateActivationPoint`
  (`Nexus.Hierarchy.CreateActivationPoint`, additive alongside this same day's earlier
  `NexusDebugPerf` trace instrumentation, which is left untouched); `RefreshHierarchyTree`/
  `BuildHierarchyTreeFromConfig` (`Nexus.UI.RefreshHierarchyTree`/
  `BuildHierarchyTreeFromConfig`); `OnTreeSelectionChanged` (`Nexus.UI.SelectionChanged`).
- `UI/SNexusDetailsPanel.cpp` - `OnDetailsViewFinishedChangingProperties`
  (`Nexus.UI.PropertyChanged`).
- `Debug/NexusDebugPrimitives.cpp` - `DrawLine`/`DrawSphere` increment
  `Nexus/DebugLines`/`Nexus/DebugSpheres` (+ `Nexus/DebugItems`); `DrawBox`/`DrawArrow`/
  `DrawCapsule` increment `Nexus/DebugItems` only - see Design Decision 6 above for why
  these are counters, not scopes.
- `Debug/NexusDebugLabelOverlay.cpp` - `UpdateLabels` (`Nexus.UI.LabelOverlay.UpdateLabels`,
  plus `TRACE_COUNTER_ADD(NexusDebugLabels, requests.Num())`).

## Verification

`Build.bat NexusFrameworkEditor Win64 Development -Project=E:\Projects\Game\UE\
NexusFramework_V6\NexusFramework.uproject` - editor was closed first (confirmed via
`tasklist`, Live Coding otherwise locks the DLL and Build.bat refuses to proceed, as it
did on the first attempt this session). **First real attempt: failed** -
`NexusDebugRenderSnapshot.cpp` used `NEXUS_PROFILE_SCOPE` without including
`Profiling/NexusProfiler.h` (a genuine missed include, not a design issue - every other
instrumented file got its include right the first time). Fixed, rebuilt. **Second
attempt: Succeeded** - 4 actions (incremental - only the one changed file + relink), ~5s.

No automated test run/added - per `AGENT-RULES.md`'s Agent Testing Policy. No in-editor
verification performed or possible from this agent (same policy) - **the user's own next
step, exactly as this tool was built for**:
1. Debug OFF, note baseline CPU/memory.
2. Open the new "Nexus Profiler" tab (opens automatically alongside Hierarchy/Details/
   Diagnostics on entering Landscape Mode, or via the Window menu if closed).
3. Click Start Profiling.
4. Enable all/most Debug checkboxes, Add City, Add State, Add one Activation/Interactive
   item, perform whatever previously caused the freeze.
5. Wait ~10-15 seconds.
6. Click Stop Profiling.
7. Sort by Total Inclusive CPU (click that column header) and by the memory columns to
   find the top offenders; expand the tree under whichever top-level entry
   (`Nexus.Tick`, `Nexus.Hierarchy.CreateActivationPoint`, etc.) is heaviest.
8. Optionally: capture the same window in Unreal Insights (all the same events are
   already traced) for a second, independent view including engine-level context this
   custom panel doesn't have (GC pauses, render thread, etc.).

## Result

A working, build-verified dockable Nexus Performance Profiler exists with real
instrumentation across every category the task listed (debug rendering/refresh/rebuild,
City/State/ActivationPoint creation, Landscape queries, mapping/reconciliation,
representation rebuild, tree/UI refresh, property-changed and selection-changed
callbacks, Tick) plus Unreal Insights events and six raw counters. Memory reporting is
honest (process-wide entry/exit/delta/peak-outstanding samples, explicitly documented as
such in both this record and the panel's own column tooltips) rather than fabricated
per-method byte attribution, per the task's own explicit instruction.

## Important Notes

- **This pass does not itself diagnose the freeze.** It is the tool the user asked for to
  produce real numbers on their own next repro run - no numbers exist yet from this
  agent, since AGENT-RULES.md's Agent Testing Policy forbids launching/driving the editor.
  Both of this session's earlier investigations remain open (see
  `activation-point-debug-on-freeze-investigation.md`'s duplicate-republish/O(N)-tree-
  rebuild findings, and `landscape-segments-freeze-cache-hardening.md`'s "Refresh()
  rebuilds Segments unconditionally regardless of visibility" and "0.25s fingerprint poll
  runs regardless of Debug visibility" open suspects) - this profiler is specifically
  built to confirm or rule out those suspects (and anything else) with real data instead
  of another guess.
- **Memory numbers are process-wide, not Nexus-isolated** - `FPlatformMemory::GetStats().
  UsedPhysical` reflects the WHOLE editor process, not just Nexus's own allocations.
  During a quiet moment this is a reasonable proxy (little else should be allocating at
  the same instant), but a large delta/peak during a scope is not proof that scope itself
  allocated that memory, only that the process's memory grew while it was running -
  documented in the panel's own column tooltips and repeated here so it isn't
  mis-read as more precise than it is.
- **`Nexus.Debug.Render.<CategoryId>` dynamic scopes add real per-category granularity to
  the existing `LogIfSlow(*category->CategoryId.ToString(), ...)` call already at that
  same site** - both now fire; the existing one was left untouched (no unrelated
  refactor), the new one is what makes that same per-category cost visible in the
  Profiler panel and Insights, not just the log.
- **Serialization risk**: none - no `UPROPERTY` touched, `FNexusProfilerNode`/
  `FNexusProfiler` are plain (non-`UStruct`/`UClass`) C++ types, and every other change is
  either a new file or an additive instrumentation line at an existing call site.
- **`Content/NF/Maps/LV0_Development1/NexusConfig.uasset` shows as modified in `git
  status`** at the time of this session's work but was never touched by this agent (no
  edit tool ever targeted it) - most likely the editor's own `HandlePostSaveWorld`
  auto-save firing during the user's own editor session between the two build attempts
  today. Flagged here rather than silently included in any future commit without the
  user's own review.

## Follow-up — 2026-08-11 — "Copy Full Details" button

User asked for one more button so the full profiling result can be copied out and pasted
back for analysis (their own stated plan: run the panel, then hand the pasted output over
"so you can batter [sic] research to find root [cause]"). Same "Copy All" precedent
already established by `SNexusDiagnosticsPanel::OnCopyAllDiagnosticsClicked`
(`FPlatformApplicationMisc::ClipboardCopy`, `ApplicationCore` module dependency already
present in `NexusFrameworkEditor.Build.cs` from that same precedent - no Build.cs change
needed here), extended from a flat list to a recursive tree walk.

### Changes

- `Public/UI/SNexusProfilerPanel.h` - new `OnCopyFullDetailsClicked()`/
  `IsCopyFullDetailsEnabled()`.
- `Private/UI/SNexusProfilerPanel.cpp`:
  - New "Copy Full Details" button in the toolbar, between Clear and the summary text.
  - New `AppendNodeDetailsRecursive` (anonymous namespace) - walks the ENTIRE tree
    (every node, not just what's currently expanded on screen), one line per node
    (indented 2 spaces per depth level), all nine metrics inline
    (Calls/Inclusive/Exclusive/Avg/Max/AvgMemDelta/MaxMemDelta/PeakOutstanding). Always
    sorted by Total Inclusive CPU descending regardless of the TreeView's own current
    on-screen sort column - a pasted report is for finding the hot path fast, not for
    matching whatever the user happened to have the UI sorted by.
  - `OnCopyFullDetailsClicked` prepends the same summary line `GetSummaryText()` already
    shows (status/duration/peak memory growth/total CPU/total calls) plus an explicit
    plain-text repeat of the memory-columns' "process-wide delta, not per-method
    allocation count" caveat, so that caveat travels WITH the pasted data instead of only
    living in a UI tooltip the recipient (this agent, next time, reading pasted text
    only) would never see.
  - `IsCopyFullDetailsEnabled` - disabled until at least one real call has ever been
    recorded (`FNexusProfiler::GetTotalCallCount() > 0`), same "nothing to copy yet"
    guard the Diagnostics panel's own button uses.

### Verification

Editor was closed (confirmed via `tasklist`) before `Build.bat NexusFrameworkEditor
Win64 Development -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject`
- **Succeeded** first attempt, 5 actions (incremental), ~10s.

### Result

The panel now has four buttons (Start Profiling / Stop Profiling / Clear / Copy Full
Details). No other behavior changed. Ready for the user's own next step: run a real
repro session, click Copy Full Details, and paste the result for analysis.

## Follow-up — 2026-08-11 — Timeline / Stall Diagnostics (long-background-freeze)

### Context

The user's own second capture (23s + a later 15s session) confirmed a real multi-second
freeze occurs, but no individual `NEXUS_PROFILE_SCOPE`-wrapped Nexus call path ever
exceeded ~25-28ms - proving the stall happens OUTSIDE every call path this tool had
instrumented so far. Before touching any new code, the user gated further work behind a
mandatory periodic-callback inventory ("do not modify code until you report..."); that
inventory was delivered as a text report (not a file - see the conversation) and found
exactly one true periodic Nexus source (`UNexusFrameworkSubsystem::Tick`, an
`FTickableEditorObject`), zero `FTSTicker`/`FTimerManager`/`RegisterActiveTimer`/async-task
mechanisms anywhere in the codebase, and confirmed every Nexus debug primitive uses
`DepthPriority=SDPG_World`/non-persistent/`LifeTime=0.f` (never overridden), meaning every
line targets `World->GetLineBatcher(UWorld::ELineBatcherType::World)` - the transient
batcher, never `PersistentLineBatcher`/`ForegroundLineBatcher`. Once that inventory was
reported, the user authorized this pass: add a Tick Gap Timeline, once-per-second
telemetry, direct `LineBatcher` inspection, GC event timing, and an empirical (not
assumed) explanation for the `Nexus.Tick=964` vs `Nexus.Debug.Dispatch=482` exact 2:1
ratio observed in that capture - explicitly instrumentation-only, no cache/LOD/Landscape/
ActivationPoint/Hierarchy/Details behavior changed.

### Findings (engine source, read-only - informs why this instrumentation targets what it does)

Reading the engine's own `LineBatchComponent.cpp`/`DrawDebugHelpers.cpp` (UE 5.8,
`Engine` module, not modified) surfaced a concrete, code-confirmed mechanism worth
recording even though it isn't yet proven to be THE cause:
- `DrawDebugLine(..., LifeTime=0.f, ...)` (Nexus's own `GNexusDebugLifeTime` constant)
  does NOT mean "draw for exactly one frame." `GetDebugLineLifeTime()`
  (`DrawDebugHelpers.cpp`) substitutes `LineBatcher->DefaultLifeTime` (constructor
  default `1.0f`, `LineBatchComponent.cpp:152`) whenever the caller passes `LifeTime <= 0`.
  So every Nexus line actually gets `RemainingLifeTime = 1.0` real second.
- That `RemainingLifeTime` is only decremented and removed inside
  `ULineBatchComponent::TickComponent` (an ordinary Actor Component tick, part of the
  WORLD's own tick group) - `LineBatchComponent.cpp:613-630`.
- `UNexusFrameworkSubsystem::Tick` is an `FTickableEditorObject` - ticked from the
  editor's own per-frame loop independently of whether the LEVEL/WORLD itself is
  ticking a viewport's realtime/backgrounded world tick can be throttled or paused under
  conditions where the editor-level `FTickableEditorObject` loop is not.
- **Hypothesis (unconfirmed, stated as a hypothesis, not a finding)**: if the world's own
  tick (and therefore `ULineBatchComponent::TickComponent`) is throttled/paused while
  Nexus's own `Tick`/`DispatchDebugRenderers` keeps running and keeps calling
  `DrawDebugLine` every editor tick, `BatchedLines` could accumulate (new entries added,
  old ones never decremented/removed) for the entire backgrounded duration, then get
  processed all at once when the world resumes real ticking - a duration-scales-with-
  background-time freeze, matching the user's own reported pattern. This is exactly what
  the new Timeline's `BatchedLines.Num`/`LineBatchBytes` columns (crossed against the
  `Foreground` column) are built to prove or disprove with real data - not asserted as
  fact here.

### Changes

**`Public/Profiling/NexusProfiler.h` / `Private/Profiling/NexusProfiler.cpp`**
- New structs: `FNexusProfilerTimelineSample` (once-per-second bucket: `TimeSeconds`,
  `bForeground`, `TickCount`, `DispatchCount`, `DrawLineCount`, `DrawSphereCount`,
  `LabelCount`, `BatchedLinesNum`, `LineBatchBytes`, `ProcessMemoryBytes`,
  `UObjectCount`), `FNexusProfilerStallEvent` (`StartTimeSeconds`, `GapMs`,
  `MemoryBeforeBytes`/`AfterBytes`, `BatchedLinesBefore`/`After`,
  `bForegroundBefore`/`After`), `FNexusProfilerGCEvent` (`TimeSeconds`, `DurationMs`).
- `FNexusProfiler::RecordTickSample(const UWorld*)` - called once per
  `UNexusFrameworkSubsystem::Tick`, unconditionally, before that function's own early
  logic. No-ops unless `IsActive()`. Per call: increments a raw `TickRawEntryCount`;
  compares `GFrameCounter` against the previous call's value to detect two Tick calls
  landing in the SAME engine frame (`DuplicateFrameTickCount`) - the empirical test for
  "is there a genuinely hidden second Tick call path"; reads OS foreground state via
  `FSlateApplication::IsActive()`; samples process memory (reusing the existing throttled
  `SampleMemoryBytesThrottled`); reads `World->GetLineBatcher(UWorld::ELineBatcherType::
  World)->BatchedLines.Num()` and the summed `GetAllocatedSize()` of
  `BatchedLines`/`BatchedPoints`/`BatchedMeshes` directly off the engine's own component
  (no shadow count Nexus itself maintains); detects a >100ms wall-clock gap since the
  last Tick and records a `FNexusProfilerStallEvent` bracketing it with the before/after
  memory and `BatchedLines.Num()` samples; closes and pushes a
  `FNexusProfilerTimelineSample` once ≥1 real second has elapsed since the current
  bucket opened.
- `RecordDispatchRawEntry()` / `RecordDispatchGuardFailNoConfig()` /
  `RecordDispatchGuardFailNoWorld()` / `RecordDispatchExecuted()` - four purely additive
  counters at `DispatchDebugRenderers`' own three existing points (top of function, the
  `!ActiveConfig` branch, the `!world` branch, and where its `NEXUS_PROFILE_SCOPE`
  already sits) - answers the Tick/Dispatch ratio question from which counter actually
  moves, not a guess.
- `RecordDrawLine()` / `RecordDrawSphere()` / `RecordLabels(int32)` - trivial (`if
  (bActive) ++counter`) additions feeding the current Timeline bucket's per-second
  rates; additive to, not a replacement for, the existing `TRACE_COUNTER_INCREMENT`/
  `_ADD` calls at those same sites (those feed Insights; these feed this tool's own
  Timeline).
- `Start()`/`Stop()` now bind/unbind `FCoreUObjectDelegates::
  GetPreGarbageCollectDelegate()`/`GetPostGarbageCollect()` (`AddRaw`/`Remove`, this
  singleton's own lifetime already exceeds any GC event) to record GC pause timing only
  - honest per this tool's own no-allocator-hook rule, timing only, never bytes freed.
- `Clear()` resets all of the above. All new arrays are capped (`MaxTimelineSamples=900`
  ≈15 min of 1s buckets, `MaxStallEvents`/`MaxGCEvents=500`) so an accidentally-long-left-
  running session cannot grow this tool's own memory unbounded.

**`Private/Subsystem/NexusFrameworkSubsystem.cpp`**
- `Tick`: resolves a local `world` and calls `FNexusProfiler::Get().RecordTickSample
  (world)` as the very first thing after the existing `NEXUS_PROFILE_SCOPE("Nexus.Tick")`
  line, before `RefreshRepresentationIfDue()`. Does not replace or gate
  `RenderDiagnosticsOverlay`/`DispatchDebugRenderers`'s own independent `world`
  resolution further down - purely additive.
- `DispatchDebugRenderers`: the four `RecordDispatch*` calls added at that function's
  existing guards/scope - same guards, same early returns, no control-flow change.

**`Private/Debug/NexusDebugPrimitives.cpp`**: `DrawLine`/`DrawSphere` each get one
`FNexusProfiler::Get().RecordDrawLine()`/`RecordDrawSphere()` line next to their existing
`TRACE_COUNTER_INCREMENT` calls. `DrawBox`/`DrawArrow`/`DrawCapsule` untouched (matches
this record's earlier Design Decision 6 - still deliberately not instrumented).

**`Private/Debug/NexusDebugLabelOverlay.cpp`**: `UpdateLabels` gets one
`FNexusProfiler::Get().RecordLabels(requests.Num())` line next to its existing
`TRACE_COUNTER_ADD`.

**`Public/UI/SNexusProfilerPanel.cpp`**: `OnCopyFullDetailsClicked` now prepends three
new sections before the existing CPU tree dump:
- `=== Diagnostic Counters (Nexus.Tick vs Nexus.Debug.Dispatch ratio) ===` - raw
  entry/guard-fail/executed counts for both functions, so the exact 2:1 (or whatever
  ratio the next capture shows) is explained from real counters.
- `=== Timeline / Stall Diagnostics (once-per-second) ===` - the exact user-specified
  header (`Time | Foreground | Tick/sec | Dispatch/sec | DrawLines/sec | DrawSpheres/sec
  | Labels/sec | BatchedLines.Num | LineBatchBytes | ProcessMemory | UObjectCount`), one
  row per `FNexusProfilerTimelineSample`.
- `=== Stalls (Tick-to-Tick wall-clock gap > 100ms) ===` - the exact user-specified
  format (`STALL | StartTime | GapMs | MemoryBefore | MemoryAfter |
  BatchedLinesBefore/After | Foreground transition`).
- `=== GC Events ===` - timing-only list, present even when empty (says so explicitly)
  so an empty section reads as "checked, none occurred," not "forgot to capture this."

### Verification

Editor was closed (confirmed via `tasklist`) before `Build.bat NexusFrameworkEditor
Win64 Development -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject`
- **Succeeded on the first attempt**, 9 actions (5 recompiled .cpp files + module/link/
metadata), ~15s.

No automated test run/added, no in-editor verification performed - per `AGENT-RULES.md`'s
Agent Testing Policy (unchanged from every earlier record this session). The user's own
next step (as they stated): reproduce one freeze again with this instrumentation active
and provide the Copy Full Details output, including the new Timeline/Stall/GC/Diagnostic-
Counters sections, for analysis.

### Result

`Copy Full Details` now pastes a single self-contained report containing (in order):
summary line, memory-honesty note, Tick/Dispatch raw-counter explanation, the
once-per-second Timeline (foreground state + per-second rates + direct
`BatchedLines.Num()`/allocated-bytes/process-memory/UObject-count samples), every
Tick-to-Tick gap over 100ms with before/after memory and BatchedLines snapshots and any
foreground/background transition, every observed GC pause, and finally the existing
call-path CPU tree. No cache, LOD, Landscape sampling, ActivationPoint, Hierarchy, or
Details code was touched - confirmed by this session's own diff (every change above is
either a new struct/method or a single additive line at an existing, already-guarded
call site).

## Follow-up — 2026-08-11 — Editable Time Range + Interval/Grouped Bucket TreeView

### Context

Immediately after the Timeline/Stall Diagnostics follow-up above, the user asked for two
UI-only additions to isolate a freeze precisely once found in a capture: (1) an editable
Time Range (`From Second`/`To Second`/`Apply`) that filters the Method Tree and `Copy Full
Details` to only that window, with the selected range echoed in the copied text
(`Range: 10.0s -> 25.0s`); (2) a second, independent TreeView grouping that range into
fixed-size Interval buckets (`Group Every [N] seconds`/`Apply`, e.g. `10-13`, `13-16`, ...,
`22-25` for range `10-25`/interval `3`), each bucket expandable into its own per-method
CPU/memory tree plus telemetry counters, so the user can directly compare methods/counters
immediately before, during, and after a stall bucket. Explicit constraint: "Do not change
existing profiling/instrumentation behavior" - this had to be a display/filtering feature
built on TOP of what already gets recorded, not a change to what gets recorded or how the
existing aggregate CPU tree computes its numbers.

### Findings / design decision

The existing `FNexusProfilerNode` tree only ever stores WHOLE-SESSION aggregates
(`CallCount`, `TotalInclusiveSeconds`, etc.) - individual calls' own start/end timestamps
were computed in `PushScope`/`PopScope` and then discarded once folded into the node.
There is no way to answer "what happened between 10s and 25s" from that tree alone - it
has no time axis. Answering the user's ask genuinely required capturing per-call
timestamps somewhere. The chosen design: a new, parallel, purely-additive
`FNexusProfiler::CallEvents` log (see `FNexusProfilerCallEvent`'s own header comment) -
`PushScope` now ALSO reserves one array slot (Name, ParentEventIndex, StartSeconds) using
the exact same `FPlatformTime::Seconds()` sample already being taken for the aggregate
tree (not a second call - avoids any timing skew between the two records), and `PopScope`
fills in the rest (`EndSeconds`/`InclusiveSeconds`/`ExclusiveSeconds`/`MemoryDeltaBytes`/
`PeakOutstandingBytes`) by reusing the EXACT SAME locals (`elapsedSeconds`, the newly-
extracted `exclusiveSeconds`, `memoryDelta`, `peakOutstanding`) already computed for the
aggregate node two lines above - the log can never disagree with the tree's own numbers
because it is never computed independently. The aggregate tree's own control flow and
formulas are otherwise byte-for-byte unchanged (confirmed by re-reading both functions
before and after editing) - satisfies "do not change existing profiling/instrumentation
behavior" in the sense that matters: the numbers the user has already been reading in the
CPU tree/Copy Full Details are computed exactly as before.

`FNexusProfiler::BuildRangeSummary(from, to)` is a new, pure (never mutates anything) query
that filters `CallEvents` by `StartSeconds`, then reconstructs a real hierarchical
`FNexusProfilerNode` tree for JUST that filtered subset by walking each qualifying event's
own `ParentEventIndex` chain to rebuild its root-to-leaf Name path - the same "identical
leaf name under two different parents = two separate tree entries" rule the live aggregate
tree already follows. `BuildRangeTelemetry(from, to)` does the analogous filter/sum over
the existing Timeline array (already built for the prior Timeline/Stall Diagnostics
follow-up) for the once-per-second counters. Both are `const` methods on `FNexusProfiler` -
callable freely from the UI without touching `bActive`/`RootNode`/`CallStack`/any counter.

### Changes

**`Public/Profiling/NexusProfiler.h` / `Private/Profiling/NexusProfiler.cpp`**
- New `FNexusProfilerCallEvent` struct (`Name`, `ParentEventIndex`, `StartSeconds`,
  `EndSeconds`, `InclusiveSeconds`, `ExclusiveSeconds`, `MemoryDeltaBytes`,
  `PeakOutstandingBytes`) and a new `TArray<FNexusProfilerCallEvent> CallEvents` member,
  capped at `MaxCallEvents=200000` (past the cap, `PushScope` simply stops assigning new
  events - the aggregate tree keeps recording normally either way, so the existing CPU-
  tree view is never affected by the cap).
- `FStackFrame` gained one field, `CallEventIndex` (`INDEX_NONE` past the cap).
- `PushScope`: hoisted its existing `FPlatformTime::Seconds()` call into a named local
  (`startSeconds`) reused by both the frame and the new event - a behavior-preserving
  refactor (same call, same place, same value), then reserves a `CallEvents` slot.
- `PopScope`: hoisted the existing inline `TotalExclusiveSeconds` expression into a named
  local (`exclusiveSeconds`, same formula, same value) reused by both the aggregate node
  and the new event, then fills in the event at `frame.CallEventIndex` if valid.
- `Clear()`: resets `CallEvents`.
- New `FNexusProfilerRangeSummary` struct (`Tree`, `CallCount`, `TotalExclusiveSeconds`,
  `MaxInclusiveSeconds`, `TotalMemoryDeltaBytes`, `MaxMemoryDeltaBytes`,
  `MaxPeakOutstandingBytes`) and `FNexusProfiler::BuildRangeSummary(fromSeconds,
  toSeconds) const` - see Findings above.
- New `FNexusProfilerRangeTelemetry` struct and `FNexusProfiler::BuildRangeTelemetry(...)
  const` - sums Tick/Dispatch/DrawLine/DrawSphere/Label counts and takes the LAST
  (latest-time) qualifying Timeline sample's point-in-time columns (BatchedLines/
  LineBatchBytes/ProcessMemory/UObjectCount), same "sampled at bucket close" semantics the
  Timeline table itself already uses.
- `GetTimelineInRange`/`GetStallEventsInRange`/`GetGCEventsInRange` - simple linear filters
  over the existing Timeline/StallEvents/GCEvents arrays by their own timestamp field.

**`Public/UI/SNexusProfilerPanel.h` / `Private/UI/SNexusProfilerPanel.cpp`**
- New `FNexusProfilerIntervalNode` struct - either a bucket HEADER row (range +
  `FNexusProfilerRangeTelemetry` + the safe-to-sum subset of `FNexusProfilerRangeSummary`)
  or a wrapped per-method row (`MethodNode` pointing into that bucket's own
  `BuildRangeSummary` tree); a bucket's children are its own top-level methods, a method's
  children are its own child methods.
- Time Range row: `From Second`/`To Second` `SSpinBox<double>` (MinValue=0, MaxValue bound
  live to `FNexusProfiler::GetElapsedSeconds()`), `Apply` button, `Copy Selected Range`
  button, a live "Showing: Xs - Ys (duration Zs)" label. Staged (what the spinboxes show,
  edited freely) vs Applied (what's actually filtering, updated only on Apply) state -
  matches the spec's explicit `[Apply]` button (filtering on click, not per keystroke).
  `OnApplyRangeClicked` clamps both to `[0, live duration]`, swaps if entered backwards,
  and resets to the full recorded duration if still degenerate (equal) after that -
  verified against a standalone Node.js transcription of this exact logic before writing
  the C++ (see Verification below). The `To` spinbox auto-tracks the live growing duration
  until the user actually types/drags a value (`bStagedRangeToUserEdited`), giving "default
  = full recorded duration" real-time behavior without fighting the user's own input.
- `RefreshDisplayedTree()` - the one place that decides whether `RootItems` (the Method
  Tree's data source) holds the LIVE root (`FNexusProfiler::GetRoot()`, unfiltered, the
  original behavior) or a rebuilt range-filtered root (`BuildRangeSummary(...).Tree`) -
  called from `OnStartClicked`/`OnClearClicked`/`OnApplyRangeClicked`/`Construct`.
- Interval row: `Group Every [N] seconds` `SSpinBox<double>` (MinValue=0.1, MaxValue bound
  to the CURRENTLY APPLIED range's own duration), `Apply`, `Copy Interval Details`.
  `RebuildIntervalTree()` clamps the interval to `(0, range duration]`, then further
  reduces it if it would generate more than `MaxIntervalBuckets=500` rows (protects the UI
  from a pathologically tiny typed interval over a long range), then walks
  `[rangeFrom, rangeTo)` in `interval`-sized steps (last bucket clipped to `rangeTo`, not
  overflowing) building one `BuildRangeSummary`+`BuildRangeTelemetry` pair per bucket.
- Second `STreeView<FIntervalNodePtr>` (`IntervalTreeView`) - same 9 metric columns as the
  Method Tree (no interactive sort - always pre-sorted by Inclusive CPU descending at
  build time) plus a `Telemetry` column populated only on bucket header rows. Both trees
  live in an `SSplitter` (vertical, user-resizable, ~55/45 default split) under the two new
  toolbar rows.
- `OnCopyFullDetailsClicked` now prepends a `Range: Xs -> Ys` line and passes that same
  window into `AppendTimelineSection`/`AppendStallSection`/`AppendGCEventsSection` (now
  range-aware via the new `*InRange` getters); the CPU tree dump reuses `RootItems`
  directly (already range-filtered by `RefreshDisplayedTree`) - guarantees the copied text
  can never disagree with what the Method Tree is currently showing on screen. The
  Diagnostic Counters section is explicitly labeled as whole-session (not range-filtered)
  since those are raw scalar counters, not individually timestamped.
- `OnCopySelectedRangeClicked` (new) - a lighter export: just the range header, one
  safe-to-sum aggregate line, and the range's own method tree (no Timeline/Stall/GC
  breakdown).
- `OnCopyIntervalDetailsClicked` (new) - the full bucket-by-bucket breakdown (every
  bucket's own header line + its complete method tree, indented), the direct
  "before/during/after" comparison text the user's own stated goal asked for.

### Verification

**Math verified standalone before writing any C++**: transcribed the planned
clamp/swap/reset (`OnApplyRangeClicked`) and bucket-generation (`RebuildIntervalTree`)
logic 1:1 into a throwaway Node.js script (`bucket_math_check.js`, scratchpad only, not
part of the project) and ran 18 assertions against it, including the user's own exact
worked example (range `10-25`, interval `3` -> `10-13, 13-16, 16-19, 19-22, 22-25`, PASS),
uneven division (`0-30`/interval `4` -> 7 full buckets + one clipped 2s remainder, not an
overflow), interval larger than the range (clamps to exactly one bucket spanning the whole
range), interval `<=0` (clamps to the `0.1` floor), the 500-bucket cap under a
pathologically tiny interval (`0-900`/interval `0.01` -> exactly 500 buckets, interval
auto-increased, full coverage with no gap/overlap), and a floating-point boundary case
(`0-0.3`/interval `0.1`, where `0.1*3` is `0.30000000000000004` in IEEE754 - confirmed the
`KINDA_SMALL_NUMBER` guard does not spawn a spurious 4th near-zero-width bucket). All 18
assertions passed before the equivalent C++ was written.

**Slate API verified against engine headers before use** (to avoid a guess-and-rebuild
cycle): `SSpinBox<NumericType>::FArguments`' `MinValue`/`MaxValue` are `TAttribute<
TOptional<NumericType>>` (not `TAttribute<NumericType>`) - confirmed via
`Widgets/Input/SSpinBox.h`, hence the `GetMaxRangeSecondsOptional`/
`GetMaxIntervalSecondsOptional` thin wrapper getters; `SLATE_EVENT`'s member-pointer-
binding overload (`.OnValueChanged(this, &Method)`) confirmed via
`DeclarativeSyntaxSupport.h`; `SSplitter::Slot()`/`.Orientation(Orient_Vertical)` confirmed
via `Widgets/Layout/SSplitter.h`.

**Build**: editor was closed (confirmed via `tasklist`) before `Build.bat
NexusFrameworkEditor Win64 Development -Project=E:\Projects\Game\UE\NexusFramework_V6\
NexusFramework.uproject` - **Succeeded on the first attempt**, 6 actions (2 recompiled
.cpp files + module/link/metadata), ~21s.

No automated test run/added, no in-editor verification performed - per `AGENT-RULES.md`'s
Agent Testing Policy (unchanged from every earlier record this session). The bucket/range
MATH was independently verified per above; the UI's actual on-screen behavior (spinbox
clamping feel, splitter resize, tree expand/collapse, clipboard content) has not been
visually confirmed in the running editor and is the user's own next step.

### Result

The Nexus Profiler panel now has two additional toolbar rows (Time Range, Interval) and a
second, independent TreeView, both built entirely on top of the existing recording
mechanism via a new parallel per-call timestamp log and two pure query methods
(`BuildRangeSummary`/`BuildRangeTelemetry`). Nothing about what gets recorded, when, or how
the existing CPU tree's numbers are computed changed - verified by re-reading `PushScope`/
`PopScope`'s full bodies before and after editing, confirming every pre-existing formula is
untouched and the new per-call log only ever mirrors values already computed for the
aggregate tree.

### Important Notes

- **`CallEvents` is a second, larger memory consumer than any prior addition** (capped at
  200,000 entries vs. 900/500/500 for Timeline/Stalls/GC) - proportional to total call
  count, not session duration, so a very high-call-count multi-minute background repro
  could approach the cap; past it, per-call time-range/interval filtering simply becomes
  less complete for whatever additional calls occurred beyond entry 200,000, while the
  whole-session aggregate CPU tree remains fully accurate regardless (it does not read
  from `CallEvents` at all).
- **The Interval tree's bucket header "Inclusive" column is intentionally left blank
  (`-`)**, not computed as a naive sum - summing `Inclusive` across sibling top-level calls
  would double count nested work in a way the per-method rows underneath do not have.
  `Exclusive` (sum of every call's own exclusive time, safe to add across different call
  paths by definition) is the bucket-level "real CPU time" figure instead - documented in
  both the column's own tooltip and this record.
- **Serialization risk**: none - no `UPROPERTY` touched; all new types are plain C++
  structs/classes.
- **Constraint compliance**: per the user's explicit "do not change existing profiling/
  instrumentation behavior," the only edits inside `PushScope`/`PopScope` are (a) two
  variable-hoisting refactors that preserve the exact prior value/formula, and (b)
  purely-additive code that writes into the NEW `CallEvents` array only - never reads from
  or alters `RootNode`/existing counters. Everywhere else in this pass is either a new
  file-local struct/method or new UI code; no cache/LOD/Landscape/ActivationPoint/
  Hierarchy/Details code was touched.

- **The `DefaultLifeTime=1.0f` / `TickComponent`-only-decrements-`RemainingLifeTime>0`
  finding above is read directly from UE 5.8 engine source, not fabricated** - but it is
  reported here as a plausible mechanism the new Timeline data can test, not as a
  confirmed root cause. Do not treat it as settled until a real capture shows
  `BatchedLines.Num()` actually climbing during a backgrounded period.
- **`DuplicateFrameTickCount`** is the direct empirical test for "is
  `UNexusFrameworkSubsystem::Tick` itself being called more than once per real engine
  frame" (the user's own "hidden duplicate loop" concern from the periodic-callback
  inventory) - if the next capture shows this at 0, that specific concern is ruled out
  even if the Tick/Dispatch ratio or BatchedLines growth turns out to have some other
  cause.
- **Serialization risk**: none - same as every earlier record in this file, no
  `UPROPERTY` touched.
- **Constraint compliance**: no cache/LOD/fade/Landscape-sampling/ActivationPoint/
  Hierarchy/Details logic was modified - every change in this follow-up is either a new
  standalone struct/method in `NexusProfiler.h`/`.cpp`, or a single additive
  instrumentation line inserted at an already-existing guard/scope in another file,
  verified by re-reading each edited function's surrounding control flow before and
  after editing.
