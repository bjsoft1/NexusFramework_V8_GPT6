# Editor Proxy Actor Pool — Near-Camera Native Interaction

Date: 2026-08-11
Category: feature-add
Phase: Ad-hoc (cross-cutting editor-usability pass, not a numbered roadmap phase — same
class of work as the same-day `editor-usability-select-mode-gizmo-sync-policy.md` pass
this one directly follows). New spec: `project-specifications/16-v6-editor-proxy-actor-system.md`.

## Context

Direct follow-up to `editor-usability-select-mode-gizmo-sync-policy.md`. The user
reported the custom `UNexusActivationGizmoTool` gizmo does not feel like manipulating a
normal Unreal Actor (grows visually huge at distance, competes with native selection
semantics), and asked for a two-layer architecture: PDI stays the global-visualization
mechanism for 99,999+ objects; a small, reusable pool of native, transient Editor Proxy
Actors gives camera-nearby objects real UE Actor selection + the standard transform
widget, writing back into Nexus authored data.

## Problem / Goal

Same objective as the user's own prompt:

```
99,999+ authored objects -> PDI wireframe/debug rendering globally
camera-nearby editable objects -> max ~100 reusable transient Editor Proxy Actors
                                -> native UE Actor selection
                                -> native UE transform widget
                                -> edits write back into Nexus authored data
```

Never spawn/destroy proxies per frame; never exceed a configurable max; a selected/
pinned proxy must never be recycled; UE Actor selection must become the authoritative
"what's currently being edited" state (unifying Nexus/UE selection, which previously
could go stale — selecting a normal Actor after a Nexus object left the old custom gizmo
logically "active").

## Investigation (17 questions, answered before implementation)

1. **Phase 48/49 gizmo** — `UNexusActivationGizmoTool` (ITF `UInteractiveTool`), single
   `ActiveGizmo`/`ActiveTransformProxy` pair created only on selection; manual ray-vs-
   sphere click test (no per-object hit proxies exist for Tick-drawn debug spheres).
   Phase 49 had additionally widened it to drag real, persisted
   `UNexusConfigAsset::ActivationPoints` — the piece this pass supersedes/reverts.
2. **Hierarchy/Details ownership** — already centralized on
   `UNexusFrameworkSubsystem::DetailsTarget` (`FNexusDetailsTarget`), broadcast via
   `OnDetailsTargetChanged` — mode-independent, survives mode switches for free (unlike
   the gizmo tool's own invented static "remembered selection").
3. **UE selection delegate** — `USelection::SelectionChangedEvent` (static multicast),
   filtered by `selectionThatChanged == GEditor->GetSelectedActors()`; actor selection
   itself via `GEditor->SelectActor(Actor, bSelect, bNotify)`.
4/5. **Transient/editor-only Actor lifecycle** — `bIsEditorOnlyActor = true` (never
   cooked) + `RF_Transient` on spawn (never saved) — confirmed correct/standard; NOT
   `RF_Transactional` (the proxy's own raw transform is never itself an undo step).
6/7. **Transform-drag hook + undo strategy** — `AActor::PostEditMove(bool bFinished)`.
   The native "Move/Rotate Actor" transaction is already open for the whole drag by the
   time `PostEditMove` fires, so `Modify()` inside it participates in that ambient
   transaction — no second, hand-rolled `FScopedTransaction`, same principle Phase 48/49
   already validated for the ITF gizmo's own transaction provider.
8. **`UBillboardComponent`** — confirmed correct: `UPrimitiveComponent` (real editor hit
   proxies, clickable), `bIsScreenSizeScaled`/`ScreenSize` gives constant apparent size.
9. **Phase 47 spatial index** — `FNexusSpatialGridIndex` is plain-data, baked-on-`Build()`
   — rebuild tied to the same dirty/throttle cadence `RenderSnapshot` already uses.
10. **Active viewport camera** — `GCurrentLevelEditingViewportClient`, guarded null +
    `IsPerspective()`.
11. **Select-Mode gating** — reuse the existing `FNexusLandscapeModeExtension::
    RefreshGizmoActiveState()` call site (renamed `RefreshNexusInteractionState`),
    already fires on every `OnEditorModeIDChanged`, already uses `IsDefaultModeActive()`.
12/13. **World/PIE lifecycle** — `FWorldDelegates::OnWorldCleanup` (filtered to the
    pool's bound world) + `FEditorDelegates::MapChange` for map switches;
    `GEditor->PlayWorld`/`GEditor->GetEditorWorldContext().World()` checks to guarantee
    proxies are only ever touched for the real editor world, never a PIE world.
14. **TreeView double-click** — new `EnsureProxyAndSelect()` path (focus, then
    `GEditor->SelectActor`).
15. **Recursive UE↔Nexus selection** — single `bIsSyncingSelection` reentrancy bool,
    `TGuardValue`-scoped.
16. **Pinned proxy survives range changes** — tracked by id (`PinnedActivationPointId`),
    excluded from both the "candidates competing for a slot" ranking and the "farthest
    evictable" pass.
17. **Reuse without destroying** — plain slot array with `BoundActivationPointId`
    (invalid = free); `SpawnActor`/`Destroy()` only at pool growth/full teardown.

No architecture blocker found — proceeded directly with implementation per direct user
instruction.

## Changes

New files:

- `Public/Settings/NexusEditorInteractionSettings.h` + `.cpp` — `UDeveloperSettings`
  (`ProxyActivationDistance`=2000, `ProxyReleaseDistance`=3000,
  `MaxActiveEditorProxies`=100, `ProxyIconScreenSize`).
- `Public/Proxy/NexusEditorProxyActor.h` + `.cpp` — `ANexusEditorProxyActor`
  (`bIsEditorOnlyActor`, `RF_Transient` on spawn, `UBillboardComponent` icon,
  `PostEditMove` notifies the pool, `IsProgrammaticTransformUpdate` feedback-loop guard).
- `Public/Proxy/NexusEditorProxyPool.h` + `.cpp` — `FNexusEditorProxyPool` (spatial
  query via Phase 47, lazy slot pool, pin/eviction, UE↔Nexus selection bridge, write-back,
  world/PIE lifecycle). Owned by `UNexusFrameworkSubsystem`.

Modified files:

- `Public/Subsystem/NexusFrameworkSubsystem.h` / `.cpp` — added `FNexusEditorProxyPool
  ProxyPool` member + `GetProxyPool()` accessor; `Initialize`/`Deinitialize` call
  `ProxyPool.Initialize()`/`Shutdown()`; `Tick()` calls `ProxyPool.TickUpdateNearbyProxies()`;
  `RefreshRepresentationIfDue()` calls `ProxyPool.RebuildSpatialIndex(ActiveConfig,
  RenderSnapshot)` in both its real-rebuild branch and its no-`ActiveConfig` early return.
- `Public/UI/NexusLandscapeModeExtension.h` / `Private/UI/NexusLandscapeModeExtension.cpp`
  — `RefreshGizmoActiveState()` renamed `RefreshNexusInteractionState()` (broadened
  scope, honest naming); now also calls `ProxyPool.SetInteractionEnabled(isSelectModeActive)`
  at the same call site as the existing gizmo Activate/Deactivate.
- `Private/UI/SNexusHierarchyPanel.cpp` — `OnTreeItemDoubleClicked` now additionally
  calls `ProxyPool.EnsureProxyAndSelect(item->EntityId)` for an `ActivationPoint` row,
  after the existing `HandleFocusItem` camera jump.
- `Public/Gizmo/NexusActivationGizmoTool.h` / `Private/Gizmo/NexusActivationGizmoTool.cpp`
  — **reverted** Phase 49's real-ActivationPoint widening: removed `FHitSubPoint::
  bIsRealConfigPoint`, `SelectedIsRealConfigPoint`, `bRememberedIsRealConfigPoint`, the
  second `activeConfig->ActivationPoints` loop in `FindClosestSubPointHit`, the
  real-point branch in `HandleGizmoTransformChanged`, and the real-point branch in
  `ResolveRememberedSelection`. The tool is back to `FNexusActivationPointTestStore`
  (session-only test data) exclusively — see `phase-49.md`'s own appended Correction
  section and `13-v6-gizmo-system.md`'s own appended revision note.
- `NexusFrameworkEditor.Build.cs` — added `DeveloperSettings` to
  `PublicDependencyModuleNames` (for `UDeveloperSettings`).

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development` — succeeded, zero
  warnings/errors, after closing the running editor (Live Coding was active; this pass
  adds brand-new `UCLASS` types, and this project has a documented history of Live
  Coding crashing on newly-added reflected types — see
  `2026-08-10/research/editor-shutdown-crash-live-coding-new-reflected-types.md` — so a
  cold build was used instead of a hot-reload).
- Static audit (grep-verified, not just asserted):
  - Real-object-backed spatial index only: `RebuildSpatialIndex` reads
    `config->ActivationPoints` through the same `IsEnabled`/category-`IsSelectable`/
    `IsVisible`-or-`IsAlwaysDraw` gate `UNexusActivationGizmoTool`'s own click-test
    already used — no synthetic/benchmark data path exists in this feature.
  - One undo transaction per drag: `NotifyProxyMoved` contains no `FScopedTransaction` —
    confirmed by grep; only comments referencing the ambient-transaction reasoning.
  - Pinned proxy never recycled: every eviction/release site
    (`TickUpdateNearbyProxies`'s release loop, `AcquireSlotFor`'s eviction loop,
    `HandleBeginPIE`) excludes `slot.BoundActivationPointId == PinnedActivationPointId` —
    confirmed by grep across all `PinnedActivationPointId` references.
  - World/map changes clear all bindings safely: `ReleaseAllForWorldTeardown` (the only
    place any slot's proxy is `Destroy()`'d) is wired to `HandleMapChanged`,
    `HandleWorldCleanup` (filtered to the bound world), `Shutdown()`, and
    `EnsureBoundToCurrentEditorWorld`'s own world-change detection.
  - No mass actor creation: `SpawnActor<ANexusEditorProxyActor>` has exactly one call
    site (`SpawnProxyActor`), reached only from lazy pool growth.
  - No per-object Tick: `ANexusEditorProxyActor::PrimaryActorTick.bCanEverTick = false`.
  - No new `DrawDebug*`/`ULineBatchComponent` calls anywhere in this feature.
  - No implicit full Landscape re-sync / no `RunAutomaticEnableFlow` call from this
    feature's write-back path (grep confirms zero occurrences in the new/changed Proxy
    files).
  - No Landscape writes: `NotifyProxyMoved` only ever calls
    `FNexusActivationSubPointResolver::SetSubPointOffset` on the base sub-point key of a
    `UNexusConfigAsset::ActivationPoints` entry — never touches
    `FNexusHighwayPoint`/`ULandscapeSplineControlPoint`.
  - Zero remaining references to the removed `bIsRealConfigPoint`/
    `SelectedIsRealConfigPoint`/`bRememberedIsRealConfigPoint`/`GActivationPointCategoryId`
    symbols in `NexusActivationGizmoTool.cpp` (grep-confirmed, one harmless prose comment
    remains).

## Result

Implemented, built, and statically audited. All three explicit user-added safeguards
(real-object-backed spatial index; single undo transaction per drag; pinned-proxy/
world-teardown safety) verified present by grep, not merely asserted in prose.

## Important Notes

- **Manual in-editor verification not performed** — this agent cannot launch/drive the
  Unreal Editor (`AGENT-RULES.md`'s Agent Testing Policy). The user's own acceptance-test
  list (far camera / move close / normal UE selection / transform / select normal Actor /
  empty viewport / proxy reuse / selected pinning / TreeView / undo-redo / save-reload /
  map switching / Landscape Mode / scale) is the outstanding next step, same pattern as
  every other UI-facing pass this session.
- **Icon is a placeholder** — `/Engine/EditorResources/S_TargetPoint`, a built-in engine
  sprite, per this pass's own explicit "do not generate/commit arbitrary content assets
  just to prove architecture unless necessary" instruction. A per-Type icon (Phase 45's
  type registry) is the intended real future source; `FNexusEditorProxyPool::BindSlot` is
  the one place that would need to change to assign it.
- **Phase 49's real-point gizmo editing is a genuine revert, not a rename** — a user
  clicking a real ActivationPoint's debug sphere in the viewport no longer selects the
  old custom gizmo; the equivalent interaction is now camera-proximity or Hierarchy
  double-click activating a native proxy Actor instead. `FNexusActivationPointTestStore`
  session-only test points are completely unaffected — still gizmo-draggable exactly as
  Phase 48 originally built.
- **Not yet connected**: no specialized payload type has real sub-point fields on a real
  config point yet (Phase 50+), so the "reinstate a real-point loop in
  `FindClosestSubPointHit` for non-base sub-point keys" note left in that file's own
  comments is not yet exercised by anything — a future phase's concern, flagged so it
  isn't forgotten.
