# Phase 50 — Traffic Light — Data Model

Date: 2026-08-11
Category: feature-add
Phase: 50

## Context

Picked up via `/TODO` after regenerating `PHASE-STATUS.md` (stale since 2026-08-10 —
Phase 49's status had already moved to `Ready for Review` earlier this same day but the
table was never regenerated; `node html-docs/build.js` fixed it before phase selection,
confirming Phase 50 as the true lowest-numbered `Not started` phase).

## Problem / Goal

Implement `FNexusTrafficLightActivation` per `12-v6-activation-point-system.md`: Pole/
VehicleLED/PedestrianLED sub-offsets, replacing V5's single-offset
`FNexusDynamicInteractable` shape for the TrafficLight case — the first REAL (non-dummy)
specialized Activation Point payload type.

## Findings

- `12-v6-activation-point-system.md`'s own diagram lists `ControlledLaneIds[]`/
  `ControlledRoadIds[]`/`SignalGroup` alongside the three sub-offsets for
  `FNexusTrafficLightActivation` — but `phase-51.md` ("Controlled Lane/Road References")
  and `phase-52.md` ("Signal Group Data") are separate, later phases for exactly those
  fields. Scoped this phase to the three sub-offsets only, per its own Allowed/
  Completion Criteria list and `09-development-rules.md`'s "do not jump phases."
- Confirmed (by reading `NexusDebugRuntimeGroupRenderers.cpp`'s `RenderActivationPoints`
  and `UNexusActivationGizmoTool::FindClosestSubPointHit`'s test-store loop in full) that
  BOTH are already fully generic over `FNexusActivationTypeRegistry` — neither contains
  any per-type branching. This meant registering the new type was sufficient to make it
  automatically debug-renderable and gizmo-draggable, with zero new renderer/gizmo code
  — the same "zero-edit extensibility" the Phase 45 dummy types proved, now proven for a
  real type too.
- Caught before finalizing: `DefaultDebugCategory` is read ONLY by
  `UNexusActivationGizmoTool`'s test-store click-test (`FindClosestSubPointHit`/
  `ResolveRememberedSelection`, gating `IsSelectable`/`CanSupportGizmo`) — the debug
  RENDERER (`RenderActivationPoints`) never reads it at all (rendering is gated on the
  category the renderer function itself is registered under, `Runtime.ActivationPoints`,
  uniformly for every test-store point regardless of `Type`). Registering a brand-new
  `Runtime.TrafficLight` `DefaultDebugCategory` (the first draft of this change) would
  have rendered fine but made the type gizmo-UNselectable until Phase 53 eventually
  registers that category — silently breaking this phase's own "independently editable"
  completion criterion. Fixed by reusing the existing, already-registered
  `Runtime.ActivationPoints` category instead (same one real ActivationPoints already
  use) — verified correct by re-reading both consumer call sites, not assumed.
- `UNexusConfigAsset::ActivationPoints`' own header comment explicitly flags specialized
  payload persistence as "open for Phase 50+ when a real specialized type first needs
  it." Phase 50's own Allowed/Completion Criteria list does not ask for persistence work
  (`phase-53.md`/`phase-54.md` — Debug Visualization / Gizmo Offset Editing — are
  separate, later phases too) — left explicitly open, not decided by this pass, matching
  the dummy-type precedent (session-only `FNexusActivationPointTestStore` data only).

## Changes

- `Public/Representation/NexusTrafficLightActivation.h` (new) —
  `FNexusTrafficLightActivation`, three `FNexusSubPointOffset` members (`Pole`/
  `VehicleLED`/`PedestrianLED`), nothing else.
- `Private/Representation/NexusTrafficLightActivationRegistration.cpp` (new) — registers
  the type via `FNexusActivationTypeAutoRegister` (`FName("TrafficLight")`,
  `RuntimeActivated`, `DefaultDebugCategory=FName("Runtime.ActivationPoints")` — the
  existing, already-registered, already gizmo-enabled category real ActivationPoints
  use; see Findings below for why NOT a new dedicated category). Same lazy-lambda
  `PayloadStructTypeGetter` pattern the
  dummy types already established (required — a bare `::StaticStruct()` call here would
  repeat the documented module-load crash). Adds
  `Nexus.Representation.AddTestTrafficLight <HighwayPointId> [AlwaysDraw]` — session-only
  test-store seeding, mirroring `AddTestActivationPointArrayConsoleCommand` exactly.
- `project-specifications/phases/phase-50.md` — Implementation section (comparison table
  + manual verification steps) appended; `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development` — succeeded, zero
  warnings/errors (editor was running this time with no Live Coding lock conflict,
  unlike the earlier Editor Proxy Actor pass the same day — no editor restart needed).
- Written comparison against V5's `FNexusDynamicInteractable` (Completion Criterion 2) —
  field-by-field table in `phase-50.md`'s own Implementation section; every V5 field maps
  onto an existing V6 base field, plus three new independently-editable positions V5
  could not express. Confirms strict superset.
- **Not verified**: Completion Criterion 1 ("three sub-offsets proven independently
  editable and independently rendered") requires the in-editor console-command check
  documented in `phase-50.md`'s own "Manual verification required" section — this agent
  cannot launch the editor (`AGENT-RULES.md`'s Agent Testing Policy). Left unchecked in
  the phase file rather than claimed.

## Result

Data model + registration implemented and build-verified. Written V5 comparison
complete. In-editor round-trip proof (render + independent gizmo-drag) is the one
remaining item, explicitly deferred to the user per standing policy.

## Important Notes

- Real `UNexusConfigAsset` persistence for specialized payloads (Traffic Light or any
  future type) remains an open architecture question — not decided by this phase, per
  its own scope and the existing flagged comment on `UNexusConfigAsset::ActivationPoints`.
  A future phase (persistence-focused, not yet numbered/assigned) will need to pick a
  storage model (flat array? per-type arrays? `FInstancedStruct`-based heterogeneous
  storage?) before Traffic Light data can survive a save/reload — today it only exists
  as `FNexusActivationPointTestStore` session-only data, same as the Phase 45 dummy
  types.
- `ControlledLaneIds[]`/`ControlledRoadIds[]`/`SignalGroup` are NOT on
  `FNexusTrafficLightActivation` yet — `phase-51.md`/`phase-52.md` add them as their own
  dedicated phases. Do not assume this struct is "done" for a real Traffic Light object
  until those land too.
- `DefaultDebugCategory` is `Runtime.ActivationPoints` (the existing, shared category),
  not a dedicated `Runtime.TrafficLight` one — deliberate, see Findings above. Phase 53
  ("Traffic Light — Debug Visualization") can introduce a dedicated category later if
  visual/UX polish calls for it; that's a one-line change to this registration, not a
  structural blocker.
