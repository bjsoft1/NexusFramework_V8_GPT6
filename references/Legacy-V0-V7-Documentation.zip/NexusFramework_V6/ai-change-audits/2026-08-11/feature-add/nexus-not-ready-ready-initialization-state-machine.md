# Nexus Not-Ready/Ready Initialization State Machine

Date: 2026-08-11
Category: feature-add
Phase: N/A (ad-hoc, `agent-todos/ready-for-review/need-inhancement.md`)

## Context

Picked up via `/TODO` from `agent-todos/ready-for-development/` (moved there by the
user between turns). Direct follow-up to the same-day editor-usability and Editor Proxy
Actor passes — this task removes the LAST implicit config-load triggers those passes
left behind, and replaces them with an explicit, visible Not Ready/Ready state machine.

## Problem / Goal

`UNexusFrameworkSubsystem::ActiveConfig` had zero map/level-change handling anywhere —
opening a second level silently left the first level's config active and editable
(matching the separate, still-unscoped `agent-todos/requirement-pending/when switch
landscape still trigating old landscape.md` report). Two implicit config-load call
sites also still existed (Landscape-Mode-entry load, Hierarchy-panel self-heal),
contradicting the user's explicit "do NOT use editor-mode switching to initialize
Nexus." `SNexusDetailsPanel.cpp` also still gated editing on
`GLevelEditorModeTools().IsModeActive(EM_Landscape)`, left over from before the same-day
editor-usability pass moved Nexus editing to Select Mode (matching the separate
`agent-todos/requirement-pending/details panel only enable in landscape mode.md`
report).

Required target: `Map Load/Switch → Not Ready → controls disabled, Re-sync highlighted
→ user clicks → successful sync → Ready → normal workflow`, with mode switching after
Ready never resetting readiness or re-triggering a full sync.

## Findings

- Confirmed via full read of `FNexusMapping.EnableFlow.cpp`/`ReconcileMappingStage` that
  Mapping reconciliation never touches `ActivationPoints`/offsets — only Highways/
  HighwayPoints/Cities/States. "Preserve authored offsets during re-sync" already holds
  structurally; no new code was needed to guarantee it.
- `FNexusConfigAssetIO::LoadOrCreateConfigAsset` returns the SAME already-loaded
  `UNexusConfigAsset*` for repeat calls against the same level's Landscape (standard UE
  asset-loading identity) — a same-level Re-sync never changes `ActiveConfig`'s pointer
  identity, so `FNexusEditorProxyPool`'s cached `BoundActivationPointId`s stay valid
  across repeat Re-syncs without any pool-specific fix. Only a genuine map/level switch
  changes identity, and that path was already correctly handled by the Editor Proxy
  Actor pass's own `FWorldDelegates::OnWorldCleanup`/`FEditorDelegates::MapChange`
  bindings — confirmed by re-reading `FNexusEditorProxyPool`, not assumed.
- `RefreshRepresentationIfDue`'s `!ActiveConfig` early-return branch (resets
  `CachedDiagnostics`/`RenderSnapshot`/the proxy pool's spatial index) runs
  unconditionally every Tick when `ActiveConfig` is null, with no throttle gate —
  setting `ActiveConfig = nullptr` on map-open is therefore sufficient on its own; no
  extra `MarkRepresentationDirty()` call was needed in `HandleMapOpened`.

## Changes

- `Subsystem/NexusFrameworkSubsystem.h/.cpp` — `IsNexusReady()`/`SetNexusReady()`/
  `OnNexusReadinessChanged` (defaults `false`); `HandleMapOpened` bound to
  `FEditorDelegates::OnMapOpened` (the precise "a map/level finished loading" signal,
  distinct from the broader/older `FEditorDelegates::MapChange`) — the ONE place
  `ActiveConfig` is cleared, `DetailsTarget` is cleared, and readiness resets to
  `false`.
- `UI/NexusLandscapeModeExtension.h/.cpp` — removed the Landscape-Mode-entry
  config-load block entirely (tabs still auto-open on entry, unchanged — a pure
  discoverability convenience, not an initialization trigger). `RefreshNexusInteractionState`
  now requires Select Mode AND `IsNexusReady()` together for gizmo/proxy-pool
  interactivity; binds the new `OnNexusReadinessChanged` delegate so becoming Ready
  reactivates interaction immediately without requiring a mode change first ("proxy
  actors/native selection must work immediately in Select Mode").
- `UI/SNexusHierarchyPanel.h/.cpp` — deleted `ResolveActiveConfig` (the self-heal load
  path) entirely; `HandleResyncFromLandscapeClicked` is now the ONLY place that
  loads/creates+reconciles a config, and sets `SetNexusReady(config != nullptr)` on
  every attempt (success or failure). Hierarchy tree widget disables (`IsEnabled_Lambda`)
  while Not Ready; the Re-sync button gets a warm highlight color and a
  context-sensitive tooltip (both TAttribute-bound, no new style asset); the tree's
  existing empty-state info row now says "Not Ready - click Re-sync" instead of the old
  Landscape-Mode-era wording.
- `UI/SNexusDetailsPanel.cpp` — replaced both `GLevelEditorModeTools().IsModeActive(EM_Landscape)`
  gates with `IsNexusReady()` — removes the last two production call sites of the
  unsafe `GLevelEditorModeTools()` free-function accessor in this module (the same
  accessor whose too-early call from `StartupModule()` caused the session's original
  startup crash — these two call sites were never at risk of THAT specific crash since
  they only ever run from live widget interaction, well after startup, but they were
  still a standing violation of this project's now-established "never call it, always
  resolve via `FLevelEditorModule::GetFirstLevelEditor()`" convention).
- `Mapping/NexusMapping.h` — fixed one stale comment referencing the just-deleted
  `SNexusHierarchyPanel::ResolveActiveConfig`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development` — succeeded, zero
  warnings/errors (editor was closed at build time; no Live Coding conflict this pass).
- Static audit (grep-verified): zero remaining production `GLevelEditorModeTools()`
  call sites in this module — every remaining hit is a prose comment explaining why
  it's not used, except the pre-existing `Tests/NexusLandscapeModeExtensionTests.cpp`
  (untouched, out of scope per `AGENT-RULES.md`'s Agent Testing Policy). Zero remaining
  references to the deleted `ResolveActiveConfig` symbol outside the one now-corrected
  `NexusMapping.h` comment.
- **Not manually verified in-editor** (this agent cannot launch the editor) — see
  Important Notes below for the exact manual test sequence.

## Result

Implemented and build-verified. The Not-Ready/Ready state machine is mode-independent by
construction (readiness is set ONLY by `HandleMapOpened`/`HandleResyncFromLandscapeClicked`
— no mode-change delegate touches it anywhere), directly satisfying "mode switching
after Ready must NOT reset readiness or trigger full sync" as a structural property, not
a behavior that has to be separately maintained.

## Important Notes

- **Manual verification required from the user** (this agent cannot launch the editor):
  1. Open a level with a mapped Landscape that already has a saved Nexus config from a
     previous session. Confirm the Hierarchy tab shows "Not Ready" (info row) and the
     tree/Details/proxy-pool selection are all inert, with the Re-sync button visibly
     highlighted.
  2. Click Re-sync. Confirm the tree populates, the info row disappears, the button
     returns to normal color, and (in Select Mode, near a real ActivationPoint) a proxy
     Actor becomes selectable/draggable immediately without touching Landscape Mode.
  3. Switch to Landscape Mode and back to Select Mode. Confirm Ready state and all
     controls remain exactly as they were (no reset, no re-sync log line).
  4. Open a second/different level. Confirm Not Ready re-triggers immediately (info row
     returns, button re-highlights, Details/proxy selection clears) — this is the
     specific bug (`agent-todos/requirement-pending/when switch landscape still
     trigating old landscape.md`) this task was filed to fix; worth confirming
     explicitly rather than just trusting the code read.
  5. Edit an ActivationPoint's offset (proxy drag or Details panel), then click Re-sync
     again on the SAME level. Confirm the offset survives (not reset by reconciliation).
- **Pre-existing, unrelated test staleness observed, not touched**:
  `Tests/NexusLandscapeModeExtensionTests.cpp` still asserts the Nexus tab closes on
  leaving Landscape Mode — already false since an earlier 2026-08-11 pass removed that
  auto-close behavior, unrelated to and unaffected by this task. Left as-is per the
  Agent Testing Policy.
- The two `agent-todos/requirement-pending/` reports this task's own findings correspond
  to (`when switch landscape still trigating old landscape.md`,
  `details panel only enable in landscape mode.md`) are now effectively resolved by this
  change, but remain in `requirement-pending/` — they were never formally scoped into
  this specific task file, so per `AGENT-TODO-RULES.md` they are not moved/closed here;
  the user may want to close them separately now that the underlying causes are fixed.
