# Editor Usability Pass — Select-Mode Gizmo Gating, Tab Decoupling, Sync Policy Rework

Date: 2026-08-11
Category: feature-add
Phase: N/A (ad-hoc, cross-cutting editor-usability pass — direct user request following
real interaction issues found during Phase 49 manual testing; touches Phase 48's gizmo
lifecycle, Phase 02/03's Landscape Mode extension, and Phase 15/16's automatic
enable/reconciliation flow, without redesigning any of their underlying data/architecture)

## Context

Manual testing of Phase 49 surfaced real editor-usability problems, all traced to one
root cause: Nexus's editor surface (tabs, gizmo interactivity, config sync) was too
tightly coupled to built-in Landscape Mode specifically, rather than treating
`Landscape = source geometry/data` and `Nexus = independent editor authoring/debug
system` as genuinely separate concerns. The user gave a 10-point requirement list and an
explicit "audit first, then implement the smallest clean changes" instruction, followed
mid-implementation by 7 additional safety constraints (loop-guard on the transacted-
object handler, centralize the gizmo scale constant, keep marker/pick-radius changes
selection-only, etc.) - all incorporated below.

## Investigation (all 10 requested items)

1. **What ties Nexus tabs/UI to `EM_Landscape`**: `FNexusLandscapeModeExtension::
   OnEditorModeIDChanged`, filtered strictly to `EM_Landscape` enter/exit — entering
   opened all 4 tabs (Hierarchy/Details/Diagnostics/Profiler) AND ran a full config
   load+reconcile; leaving closed all 4 tabs. One handler, one trigger, for three
   logically separate concerns (tabs, gizmo, sync).
2. **What creates/destroys the Nexus gizmo**: `FNexusActivationGizmoManager::Activate()/
   Deactivate()` (`StartTool`/`EndTool` against the shared `UModeManagerInteractiveToolsContext`),
   called from the SAME `EM_Landscape`-only handler — meaning the gizmo tool was only
   ever interactive WHILE Landscape Mode's own sculpt/spline tools were ALSO active,
   directly explaining the reported conflict. Within the tool itself,
   `UNexusActivationGizmoTool::SelectSubPoint`/`ClearSelection` create/destroy the actual
   `UCombinedTransformGizmo`/`UTransformProxy` per selection (unchanged by this pass -
   already verified scalability-compliant the same day, see `research/
   gizmo-scalability-audit-selection-driven-architecture.md`).
3. **Detecting standard Select Mode in UE 5.8**: `FEditorModeTools::IsDefaultModeActive()`
   — a real, direct engine API ("Returns true if the default modes are active"),
   confirmed via `EditorModeManager.h`. Simpler and more direct than checking
   `FBuiltinEditorModes::EM_Default` activation state manually.
4. **Gizmo visual scale/hit-size**: confirmed via engine source
   (`GizmoLineHandleComponent.cpp`'s `LineTraceComponent`, which derives both the
   rendered handle geometry AND the hit-test segment from `GetComponentToWorld()` —
   i.e. INCLUDING the actor's own scale) that `ACombinedTransformGizmoActor::
   SetActorScale3D()` is a safe, standard way to scale a spawned ITF gizmo's visuals
   and hit-test together, as a pure rendering-transform multiplier independent of the
   logical `UTransformProxy` transform. ITF gizmo components already maintain constant
   apparent screen size regardless of camera distance (`UE::GizmoRenderingUtil::
   CalculateLocalPixelToWorldScale`, computed per-component per-frame) — this multiplier
   stacks on top, so bigger AND still distance-readable. Not yet visually confirmed in a
   live editor session (this agent cannot launch one).
5. **Every automatic `SyncFromLandscape`/reconcile trigger**: exactly 2 call sites of the
   FULL `FNexusMapping::RunAutomaticEnableFlow` (config load + `ReconcileMappingStage` =
   `MapControlPoints`/`MapHighways`, a full Landscape scan) — `FNexusLandscapeModeExtension::
   OnEditorModeIDChanged`'s Landscape-Mode-enter branch, and `SNexusHierarchyPanel::
   ResolveActiveConfig`'s "self-heal if `ActiveConfig` is null" path (reached whenever the
   Hierarchy tab refreshes, e.g. on open). A SEPARATE, pre-existing, cheap, throttled,
   fingerprint-gated cache refresh (`UNexusFrameworkSubsystem::RefreshRepresentationIfDue`)
   is a different mechanism — it re-reads live Landscape geometry into the render/
   diagnostics cache from EXISTING config data, never mutates `ActiveConfig`'s own
   Highways/HighwayPoints arrays, and was correctly left untouched (needed for the PDI
   wireframe to reflect live Landscape state at all).
6. **Which happen during load/open/mode-change**: both of item 5's triggers ARE
   mode-change (Landscape Mode entry) and panel-open/refresh (Hierarchy self-heal) —
   confirmed no separate project-open/level-open hook exists (`RunAutomaticEnableFlow`
   is not bound to `FEditorDelegates::OnMapOpened` or any load delegate).
7. **Available UE 5.8 Landscape/Spline edit delegates/events**: `FCoreUObjectDelegates::
   OnObjectTransacted` — confirmed via V5's own prior hard-won research
   (`v5-complete-reference.md`'s `OnLandscapeSplineObjectTransacted` entry) as the ONLY
   delegate that reliably fires for a viewport gizmo drag on a
   `ULandscapeSplineControlPoint` (`PostEditChangeProperty`-based delegates only fire for
   Details-panel edits, not direct viewport manipulation — confirmed unreliable for this
   purpose by V5's own engine-source investigation, not re-derived from scratch here).
8. **How authored offsets survive re-sync**: confirmed by grep (`ActivationPoints` string
   search across `NexusMapping.PointMapping.cpp`/`NexusMapping.HighwayMapping.cpp`) —
   ZERO matches. Mapping reconciliation (`MapControlPoints`/`MapHighways`, and by
   extension the full `RunAutomaticEnableFlow`/manual "Re-sync from Landscape") never
   touches `UNexusConfigAsset::ActivationPoints` at all — it lives in a completely
   separate array. Combined with `FNexusActivationPoint::ComputeFinalTransform`'s
   existing `OffsetTransform * AnchorWorldTransform` composition (the anchor always
   live-resolved, never cached), "Landscape source position + Nexus authored offset =
   final preview position" was already structurally guaranteed before this pass, for
   BOTH the existing full sync and the new event-driven incremental sync added below.
9. **Manual "Re-sync from Landscape" button**: already existed
   (`SNexusHierarchyPanel::HandleResyncFromLandscapeClicked`, added 2026-08-10) and
   already worked independent of editor mode (never checked `EM_Landscape` at all) —
   confirmed no changes needed to make it mode-independent; it already was.
10. **Smallest clean changes**: see Changes below — no new persistence architecture, no
    new gizmo mechanism, no rewrite of the Mapping/reconciliation/offset-composition
    logic; only lifecycle wiring (which trigger calls what) and two small, contained
    additions (an event handler, a scale constant).

## Changes

### 1. Gizmo interactivity now follows Select Mode, not Landscape Mode

- `FNexusActivationGizmoManager` (`.h`/`.cpp`) — `Activate()`/`Deactivate()` made
  idempotent (new `bIsActive` guard) since they are now called on EVERY mode change, not
  just a genuine transition.
- `FNexusLandscapeModeExtension` (`.h`/`.cpp`) — new `RefreshGizmoActiveState()`, called
  unconditionally at the top of `OnEditorModeIDChanged` (every mode change) and once more
  from `RegisterToFirstLevelEditor()` (covers the case where the editor starts already in
  Select Mode, with no transition event to fire). Resolves `FEditorModeTools` via
  `FLevelEditorModule::GetFirstLevelEditor()` (never the global `GLevelEditorModeTools()`
  — see the same-day startup-crash-fix record for why that accessor is banned project-
  wide) and calls `GizmoManager.Activate()`/`Deactivate()` based on `IsDefaultModeActive()`.

### 2. Selection persists across mode switches (Select → Landscape → Select)

- `UNexusActivationGizmoTool` (`.h`/`.cpp`) — added `bHasRememberedSelection`/
  `RememberedActivationPointId`/`RememberedSubPointKey`/`bRememberedIsRealConfigPoint` as
  STATIC members (survive individual tool instance `Setup()`/`Shutdown()` cycles, unlike
  the existing instance members). `SelectSubPoint` sets both the instance AND remembered
  state; a mode-driven `Shutdown()` → `ClearSelection()` leaves the remembered statics
  alone; only an EXPLICIT deselect (`OnClickedInViewport`'s "clicked empty space" branch)
  additionally clears `bHasRememberedSelection`. New `ResolveRememberedSelection()`
  re-resolves the remembered Id/key into a fresh hit (same gating as a real click — category
  `IsSelectable`/`CanSupportGizmo`/`IsVisible`-or-`AlwaysDraw`/`IsEnabled`) — `Setup()`
  calls it and silently rebinds via `SelectSubPoint` if it still resolves, or forgets it
  otherwise. Net effect: leaving Select Mode deactivates/destroys the one gizmo but keeps
  the logical selection; returning to Select Mode rebinds the SAME single gizmo to it
  without a re-click, never more than one gizmo at any point.

### 3. Gizmo visual/hit size increased

- `NexusActivationGizmoTool.cpp` — `GSubPointPickRadius` 40 → 100 (click-test tolerance
  only — the rendered marker sphere size in `NexusDebugRuntimeGroupRenderers.cpp` is
  UNCHANGED, per the user's own "small visual point can still have larger invisible/
  selection hit radius" framing). New `GNexusGizmoVisualScale` (one centralized constant,
  `2.5`), applied via `ACombinedTransformGizmoActor::SetActorScale3D` right after
  `CreateCustomTransformGizmo` in `SelectSubPoint` — a pure rendering-transform
  multiplier, never touches the logical `UTransformProxy` transform or any authored data.

### 4. Tabs decoupled from Landscape Mode's own lifecycle

- `FNexusLandscapeModeExtension::OnEditorModeIDChanged` — the tab-closing block
  (`RequestCloseTab` × 4) on Landscape-Mode-EXIT was removed entirely. Tab-OPENING on
  Landscape-Mode-ENTRY is unchanged (a discoverability convenience). All 4
  `RegisterNomadTabSpawner` calls switched `SetAutoGenerateMenuEntry(false)` →  `true`, so
  every tab is now independently openable from the Window menu without ever entering
  Landscape Mode.

### 5. Implicit full-resync triggers removed; explicit button unchanged

- `FNexusLandscapeModeExtension::OnEditorModeIDChanged` (Landscape-Mode-entry config
  load) and `SNexusHierarchyPanel::ResolveActiveConfig` (self-heal when `ActiveConfig` is
  null, `forceResync=false` case) both switched from `FNexusMapping::
  RunAutomaticEnableFlow` (load + full `MapControlPoints`/`MapHighways` reconciliation) to
  `FNexusConfigAssetIO::LoadOrCreateConfigAsset` (load the existing on-disk config as-is,
  or create an empty one — zero reconciliation). `ResolveActiveConfig`'s `forceResync=true`
  path (i.e. `HandleResyncFromLandscapeClicked`, the "Re-sync from Landscape" button)
  still calls the FULL `RunAutomaticEnableFlow`, completely unchanged — confirmed by grep
  this is now the ONLY remaining automatic-trigger-adjacent call site of that function.

### 6. Event-based incremental sync for live Landscape Spline edits

- `UNexusFrameworkSubsystem` (`.h`/`.cpp`) — new `HandleObjectTransacted`, bound to
  `FCoreUObjectDelegates::OnObjectTransacted` in `Initialize()`/removed in `Deinitialize()`.
  **Loop-guard (explicit user requirement)**: the FIRST check is
  `Cast<ULandscapeSplineControlPoint>(object)` — a Nexus gizmo drag transacts
  `UNexusConfigAsset` (see `HandleGizmoTransformChanged`'s `Modify()` call) or a
  Details-Panel edit transacts the same; NEITHER is ever a `ULandscapeSplineControlPoint`,
  so this type check structurally guarantees a Nexus-driven edit can never be mistaken
  for a Landscape edit and loop back into re-marking anything dirty because of its own
  write — not just an optimization, the actual safety property. Second check: the
  point's owning Landscape (`GetOuterSafe()` → `ULandscapeSplinesComponent::GetOwner()`,
  `GetOuterSafe()` specifically per the engine type's own guidance for a possibly-just-
  deleted point) must match `FNexusLandscapeReader::ResolveActiveLandscape()` — an
  unrelated Landscape's edit in a multi-Landscape level is ignored. On a pass, calls
  `MarkRepresentationDirty()` only — deliberately does NOT run `ReconcileMappingStage`/
  `RunAutomaticEnableFlow`. A moved/rotated EXISTING control point is correctly picked up
  (the forced-immediate Representation rebuild re-reads live Landscape geometry
  regardless of why it was triggered); a genuinely NEW/DELETED point or segment (a
  topology change) is explicitly NOT auto-adopted by this handler — documented as a
  deliberate scope limit (V5's own equivalent topology-auto-adoption logic was ~130
  lines of documented special-casing; reproducing it here under time pressure, unable to
  test in a live editor, was judged out of scope for this pass) rather than silently
  attempted and possibly wrong. Manual "Re-sync from Landscape" remains the way to pick
  up topology changes.

## Verification

- **Build**: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` succeeded with
  zero warnings/errors on the first attempt (editor was open at the time; user confirmed
  closing it was fine, and it had already exited on its own by the time this agent
  re-checked `tasklist`).
- **Static verification** (grep, whole `Source/` tree, post-change):
  - `GLevelEditorModeTools()`: same 3 pre-existing, already-audited-safe call sites as
    before this pass (2 in `SNexusDetailsPanel.cpp`, 1 in an automation test) — zero new
    uses; the new `RefreshGizmoActiveState` explicitly uses the safe per-instance
    accessor instead, consistent with the same day's earlier startup-crash-fix
    convention.
  - `FNexusMapping::RunAutomaticEnableFlow(`: exactly one production call site remains
    (`SNexusHierarchyPanel.cpp`'s `forceResync=true` branch, i.e. the explicit button),
    plus the pre-existing manual console command — confirmed both implicit auto-triggers
    are gone.
  - `FNexusConfigAssetIO::LoadOrCreateConfigAsset(`: confirmed present at exactly the 2
    new intended call sites (`NexusLandscapeModeExtension.cpp`, `SNexusHierarchyPanel.cpp`)
    alongside its 2 pre-existing ones (the manual console command, and its own
    `RunAutomaticEnableFlow` internal use).
- **Not yet done (cannot be done by this agent — AGENT-RULES.md's Agent Testing Policy,
  no editor launch)**: the full manual acceptance test list the user specified (Select
  Mode gizmo usability, Landscape Mode gizmo inactivity, mode-switch selection
  preservation, no-auto-sync-on-restart, button-works-from-Select-Mode, live-edit
  incremental sync, no LineBatch/full-sync/per-frame-scan regressions).

## Result

Implemented and build-verified. Summary against the user's own target behavior table:

| | Before | After |
|---|---|---|
| Select Mode: tabs | Required entering Landscape Mode at least once | Independently openable (Window menu), no Landscape Mode required |
| Select Mode: gizmo | Inactive (only active during Landscape Mode) | **Active** |
| Landscape Mode: gizmo | Active (conflicted with Landscape's own tools) | **Inactive** |
| Mode switch | Tabs closed, selection lost | Tabs stay open, selection rebinds automatically |
| Editor/level load | Full Mapping reconciliation | Load-only, config as-is |
| Re-sync from Landscape button | Already worked mode-independently | Unchanged |
| Live spline point drag | No reaction until next poll (~0.25s) or manual resync | Immediate dirty-mark + rebuild via `OnObjectTransacted` |
| Authored offsets (ActivationPoints) | Never touched by any sync path | Still never touched (confirmed, unchanged) |

## Important Notes

- **Gizmo visual scale (`GNexusGizmoVisualScale = 2.5`) is reasoned from engine source,
  not visually confirmed** — this agent cannot launch the editor. If it turns out to
  have no visible effect (a plausible failure mode if some ITF gizmo component
  internally overrides/ignores actor-level scale in a way this session's engine-source
  reading didn't surface) or the wrong magnitude, `GNexusGizmoVisualScale` is the one
  centralized place to adjust or replace with a different mechanism (a custom
  `FCombinedTransformGizmoActorFactory` with larger `Length`/`Radius` params passed to
  `AGizmoActor::AddDefaultArrowComponent`/`AddDefaultCircleComponent` is the documented,
  supported fallback if actor-scale proves insufficient).
- **Topology-change auto-reconciliation (new/deleted spline points/segments) is a
  deliberate, documented gap**, not an oversight — escalated per the user's own "if
  reliable events don't exist for a specific edit type, document the limitation" rule.
  Manual "Re-sync from Landscape" remains the only way to pick up topology changes.
- **No changes to**: `FNexusDebugPrimitives`/PDI rendering backend, the Debug Tree/
  category registry, `UNexusConfigAsset`'s field shape, the offset-composition formula,
  `FNexusActivationSubPointResolver`, the Hierarchy/Details/Diagnostics/Profiler panels'
  own content (only their tab lifecycle), or any Mapping/Reconciliation logic itself
  (only which triggers call it).
