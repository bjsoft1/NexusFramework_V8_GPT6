# Phase 49 — Activation Point End-to-End Smoke Test: Real Gizmo Editing

Date: 2026-08-11
Category: feature-add
Phase: 49

## Context

Phase 49's own 2026-08-10 notes flagged the last remaining gap in the Activation Point
authoring round trip: `UNexusConfigAsset::ActivationPoints` was already real, persisted,
undo/redo-capable, and rendered (Details-Panel/Hierarchy-editable), but the Gizmo tool
(Phase 48) only ever read/wrote `FNexusActivationPointTestStore` — a session-only,
never-persisted list — so a real, config-backed Activation Point could not be dragged in
the viewport. The user gave direct authorization to proceed with Phase 49, restating the
target objective (`PDI wireframe → select object/sub-point → single gizmo → edit
authored data → immediate wireframe update → Undo/Redo → Save/Load → no Landscape
geometry modification`) and an explicit constraint: the Phase 48 gizmo scalability
architecture (verified compliant with the user's 99,999+-object requirement earlier the
same day — see `research/gizmo-scalability-audit-selection-driven-architecture.md`) must
remain completely unchanged; only close the real-data gap.

## Problem / Goal

Make real, persisted `FNexusActivationPoint` instances gizmo-selectable and
gizmo-draggable, with genuine undo/redo and Save/Load, without adding a second gizmo
mechanism, without inventing a specialized-payload persistence architecture (explicitly
out of scope — flagged as a Phase 50+ decision), and without changing anything about how
many gizmo/tool/proxy instances can exist at once.

## Findings

- `FNexusActivationSubPointResolver::GetSubPointOffset`/`SetSubPointOffset` already
  handle the "no payload" case entirely generically: the synthetic base key
  (`FieldName=NAME_None`) reads/writes `FNexusActivationPoint::OffsetLocation`/
  `OffsetRotation` directly, with zero dependency on `payloadStructType`/
  `payloadInstance` (both may be null). This meant real config points — which never have
  a payload — could be wired into the exact same resolver used for test-store points
  with zero changes to that resolver, and always resolve to exactly one sub-point (the
  base key), touching nothing related to the still-open specialized-payload persistence
  question.
- Confirmed from UE 5.8 engine source
  (`Engine/Source/Editor/UnrealEd/Private/Tools/EdModeInteractiveToolsContext.cpp`)
  that `UModeManagerInteractiveToolsContext`'s transaction provider opens a real
  `FScopedTransaction` on `BeginUndoTransaction` (held until `EndUndoTransaction`) — and
  that `UTransformProxy::BeginTransformEditSequence()`/`EndTransformEditSequence()`
  (called by the gizmo's own sub-elements around a drag) route through exactly this
  provider via `GetToolManager()`. This meant a plain `UNexusConfigAsset::Modify()` call
  from inside `HandleGizmoTransformChanged` — fired mid-drag, i.e. always inside that
  already-open transaction — participates in the SAME single transaction the ITF gizmo
  already opens per drag gesture, giving real undo/redo (one step per drag, matching
  `SNexusDetailsPanel.cpp`'s own established granularity) without a second, hand-rolled
  `FScopedTransaction`.
- Confirmed the renderer (`NexusDebugRuntimeGroupRenderers.cpp`'s `RenderActivationPoints`/
  `DrawOneActivationPoint`) already drew real config points through the identical draw
  path as test points (2026-08-10 prerequisite work) — so no renderer change was needed
  for "immediate wireframe update"; a gizmo-driven offset write is picked up on the very
  next render pass automatically, same as any other mutation to that array.
- Confirmed `UNexusFrameworkSubsystem::HandlePostSaveWorld` already auto-saves the config
  asset whenever its package is dirty on a real map save — `Modify()` marks that same
  dirty flag, so Save/Load needed zero new persistence code.
- A real config point's `Type` may be `NAME_None` (blank) — the existing test-store
  selection loop's gating (resolve a `FNexusActivationTypeDefinition` via the point's own
  `Type`, then check that type's `DefaultDebugCategory`'s `IsSelectable`/
  `CanSupportGizmo`) would silently reject every blank-`Type` real point, since
  `FNexusActivationTypeRegistry::Get().FindType(NAME_None)` returns null. The renderer
  doesn't have this problem (it draws under the fixed `Runtime.ActivationPoints`
  category directly, never via a per-Type lookup) — so the new real-config selection
  loop gates on that same fixed category directly, matching the renderer's own gating
  exactly instead of reusing the test-store loop's per-Type mechanism verbatim.

## Changes

`Source/NexusFrameworkEditor/Public/Private/Gizmo/NexusActivationGizmoTool.{h,cpp}` only
— no other file touched.

- `FHitSubPoint::bIsRealConfigPoint` (new bool) + matching
  `UNexusActivationGizmoTool::SelectedIsRealConfigPoint` member — tags which of the two
  data sources a hit/selection came from; reset in `ClearSelection`, set in
  `SelectSubPoint`.
- `FindClosestSubPointHit`: the existing per-point ray-vs-sphere test body was extracted
  into a local lambda (`testActivationPoint`) — a pure refactor, no logic change to the
  test-store path — then reused by a NEW second loop over `UNexusFrameworkSubsystem::
  GetActiveConfig()->ActivationPoints`, gated on the fixed `Runtime.ActivationPoints`
  category (`IsSelectable && CanSupportGizmo`, then per-instance `IsEnabled` and
  `IsVisible || DebugOverride.IsAlwaysDraw`, mirroring `DrawOneActivationPoint` exactly).
  Both loops feed the same closest-hit-wins comparison, so real and test points compete
  fairly for whichever is actually closer to the click.
- `HandleGizmoTransformChanged`: branches on `SelectedIsRealConfigPoint`. Real path:
  resolve `ActiveConfig`, find the point by Id, `ActiveConfig->Modify()`, then
  `FNexusActivationSubPointResolver::SetSubPointOffset(*point, nullptr, nullptr,
  SelectedSubPointKey, newOffset)` (payload always null/base-key-only). Test-store path:
  byte-for-byte unchanged from Phase 48.

## Verification

- **Build**: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` succeeded with
  zero warnings/errors (editor was not running at build time).
- **Gizmo instance-count/scalability property re-checked by inspection after this
  change**: no new `UCombinedTransformGizmo`/`UTransformProxy` creation path was added —
  `SelectSubPoint`'s existing single `ActiveGizmo`/`ActiveTransformProxy` creation is
  unchanged; this pass only widens which candidates `FindClosestSubPointHit` considers
  and which struct `HandleGizmoTransformChanged` writes into. Still exactly one gizmo
  regardless of source or total object count.
- **Not yet done (cannot be done by this agent — AGENT-RULES.md's Agent Testing Policy,
  no editor launch)**: the actual in-editor round trip (select a real point, drag,
  undo/redo, save/reload, confirm persistence) and the requested selection-responsiveness
  observation. Full manual verification steps recorded in `phase-49.md`'s own
  "Implementation (2026-08-11)" section.

## Result

Phase 49's own stated gap ("gizmo-driven edits of a real point are not yet possible") is
closed. `phase-49.md`'s Status moved to `Ready for Review` (agent implementation + build
verification complete, per this project's own status vocabulary — rule 12,
`09-development-rules.md`) — human review/QA (the manual round-trip + responsiveness
check) still required before `In Review`/`Ready for QA`/`Complete`.

## Important Notes

- **Specialized payload persistence (the `Dummy.Array`/sub-point case) remains
  explicitly out of scope and unchanged** — real config points still only ever hold
  base-only instances; that architecture decision stays open for Phase 50+, exactly as
  `UNexusConfigAsset::ActivationPoints`' own header comment already stated before this
  pass.
- **The click-time O(N) selection-scan gap** (documented earlier the same day in
  `research/gizmo-scalability-audit-selection-driven-architecture.md`) is now scanning
  TWO sources instead of one, but is still a single linear pass per click, not a
  per-object-instance or per-frame cost — the same conditional recommendation applies
  (wire Phase 47's `FNexusSpatialGridIndex` only if the user's own manual responsiveness
  observation finds it necessary).
- **No code outside `NexusActivationGizmoTool.{h,cpp}` was touched** — the renderer,
  resolver, type registry, config asset, Details Panel, and Hierarchy panel are all
  exactly as they were before this pass, confirming the round trip really was "one gap
  away" rather than requiring broader changes.
