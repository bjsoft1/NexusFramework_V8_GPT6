# Agent memory must stay in the repo — not the agent's own external memory

Date: 2026-08-09
Category: others
Phase: N/A (process/convention, not implementation)

## Context

Continuation of the same day's phase-tracker regression work
(`ai-change-audits/2026-08-09/bug-fixed/phase-tracker-status-ui-broken.md`). After
fixing that regression, a piece of workflow feedback came up (be economical about
status-changing writes during live testing — see `09-development-rules.md` rule 12's
new paragraph on this). That feedback was initially saved to the agent's own external,
per-machine Claude Code memory
(`C:/Users/<user>/.claude/projects/<project-hash>/memory/`) instead of this repo.

## Problem / Goal

The user caught this immediately: `NexusFramework_V6` is worked on by multiple
developers across multiple PCs. An agent's external memory directory is:

- **Per-machine, per-user** — invisible to any other developer, and to the same
  developer on any other machine.
- **Outside git entirely** — not backed up by the repo's own version control, not
  recoverable if that one PC's data is lost.
- **Not something `CLAUDE.md` allows anyway** — rule 1 already explicitly forbids
  `.claude/`, `<PROJECT_ROOT>/.claude/`, and
  `C:/Users/<user>/.claude/` (or equivalent) as memory locations, precisely for these
  reasons. This session's mistake wasn't a gap in the rule — the rule was already clear
  — it was applying the "external memory" system reflexively for something the agent
  judged to be "behavioral/collaboration feedback" rather than "project memory," without
  re-checking against this project's own stricter, explicit rule.

## Findings

Not every kind of durable note is automatically exempt from CLAUDE.md's "no external
memory" rule just because it's about *how an agent should work* rather than *what the
V6 architecture is*. On a solo project, an agent's own external memory and an in-repo
log are both viable places for that kind of note. On a multi-developer,
multi-machine project, only the in-repo location actually reaches every future
developer and every future agent session (regardless of which machine it runs on) — so
here, the in-repo location is the only correct one for anything meant to outlive the
current conversation.

## Changes

- Deleted the two files written to external memory
  (`feedback_batch_status_updates.md`, `MEMORY.md`).
- Moved the actual content into this repo instead:
  `project-specifications/09-development-rules.md` rule 12 (a new paragraph on being
  economical with status-changing writes during live testing) — the correct home since
  that file is literally "process rules for how V6 is planned, documented, and
  implemented," read by every fresh session per its own README's reading order.
- Added an explicit "never external memory" bullet to that same file's documentation-
  separation list, pointing back at this record, so a future agent sees the *why*
  (multi-developer, multi-PC, data-loss resilience), not just the rule.

## Result

Nothing from this session's work remains outside `NexusFramework_V6`'s own git history.

## Important Notes

- If a future agent is ever tempted to save "how to work with this user" feedback,
  the test is not "is this about the codebase" — it's "would every other developer on
  this project, on their own machine, need this too." On this project the answer is
  almost always yes, which means `ai-change-audits/` (or `09-development-rules.md` for
  a standing process rule, as here), not external memory.
