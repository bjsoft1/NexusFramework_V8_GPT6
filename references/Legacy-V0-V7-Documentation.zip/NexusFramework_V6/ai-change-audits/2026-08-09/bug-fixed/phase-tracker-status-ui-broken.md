# Phase-tracker status UI silently broken (dropdown always disabled; phase link 404s)

Task: Fix phase-tracker status dropdown + phase `.md` link
Category: bug-fixed
Phase: N/A (tooling, not a roadmap phase)
Status: Ready for Review
Completed Date: 2026-08-09
Completed Time: 22:34 NST (+0545)

## Context

User reported two problems while using `html-docs/phase-tracker.html` (served via
`html-docs/server.js`): clicking a phase's "Open phase-NN.md" link gave
`Not found: /project-specifications/phases/phase-01-core-structures.md`, and separately
asked whether `Ready for Review` phases were disallowed from changing status via the
HTML UI.

## Problem / Goal

Investigate and fix both.

## Findings

1. **404 on phase links**: `js/phase-tracker.js` built each row's link as
   `href="../project-specifications/" + phase.file`. `server.js`'s `serveStatic()` only
   ever served files relative to `HTML_DIR` (`html-docs/`) — but `project-specifications/`
   is a **sibling** of `html-docs/`, not nested inside it. Any request into it 404'd
   unconditionally, regardless of whether the file existed.
2. **Status dropdown always disabled, for every phase, regardless of server state** — a
   real, separate bug, not what the user asked about but found while investigating why
   "Ready for Review" specifically seemed blocked. `js/phase-tracker.js`'s
   `DOMContentLoaded` handler calls `checkServer();` at the very end, but `checkServer`
   was **never defined anywhere in the codebase** (confirmed via
   `grep checkServer html-docs/` — the call site was the only match). Calling an
   undefined function throws a `ReferenceError`, which happens *after* the first
   `render()` call (so the page wasn't blank) but *before* `poll()` is ever invoked -
   `poll()` is what flips `serverOnline` to `true` and starts the polling loop. Net
   effect: `serverOnline` stayed `false` forever, so
   `select.disabled = !serverOnline` kept every status `<select>` disabled permanently,
   whether or not `server.js` was actually running. This — not any status-specific
   restriction — is why the user saw "Ready for Review" (and every other status) as
   unchangeable from the browser.

## Changes

- `html-docs/js/phase-tracker.js`: added the missing `checkServer()` definition
  (`poll(); setInterval(poll, POLL_MS);` — the obviously-intended behavior given `poll()`
  was already fully implemented and `POLL_MS` already existed, just never wired up).
- `html-docs/server.js`: `serveStatic()` now serves `project-specifications/`,
  `ai-change-audits/`, and `agent-todos/` from `ROOT` (in addition to `html-docs/` itself)
  when a request path starts with one of those prefixes — so a raw phase `.md` link (or
  any doc link under those three folders) resolves instead of 404ing, whether or not the
  new content-popup feature (see the companion feature-add record) is used instead.

## Verification

- Started `node html-docs/server.js`, confirmed via `curl`:
  - `GET /project-specifications/phases/phase-01-core-structures.md` → `HTTP 200`
    (previously `404`).
  - `POST /api/phases/2/status {"status":"Ready for QA"}` → succeeds (proves status
    changes were never blocked by the API itself, only by the dead frontend polling
    loop) — reverted immediately after (see the record's note below; also see the
    companion feature-add record's Complete-lock addition, verified separately).
  - `POST /api/phases/0/status` (Phase 00, `Complete` since before this session) →
    correctly rejected once the Complete-lock feature (companion record) was added.
- Manual code read confirms `checkServer` now resolves to a real function; the dropdown
  will enable itself (`serverOnline = true`) once `poll()`'s first `fetch("/api/phases")`
  succeeds, same as the pre-existing (but previously unreachable) logic already intended.
- Did not verify in an actual browser DOM this session (no browser automation available
  here) — verified via the same HTTP requests the browser's `fetch()` calls would make,
  plus a manual read of the render/poll/checkServer control flow.

## Result

Both root causes fixed. `checkServer` bug in particular affected the *entire*
phase-tracker UI (every phase, every status), not just the one link/status the user
happened to notice.

## Important Notes

- Test mutations made while verifying this (Phase 01 → `Ready for QA`, Phase 02 →
  `Blocked` → `Ready for Review`) were reverted via direct file edit before finishing —
  `git diff`/`git status` should show no net change to either phase file's `## Status`
  line from this investigation.
- See the companion record
  `ai-change-audits/2026-08-09/feature-add/phase-content-popup-and-complete-lock.md` for
  the popup-modal replacement of the raw link, and the new Complete-lock rule added in
  the same session.

## Correction — 2026-08-09 (real regression: current-status gap, human hit it for real)

User report: "the in progress, not started task do not allow to switch status from
backend and frontend both side this is not allow for human. human can acidentally
changed and this happens now but i fixed goto direct source file." — a phase currently
`Not started` or `In progress` could be changed to ANY other status from the
phase-tracker dropdown, once the `checkServer` fix (above) made the dropdown work at
all. This is a real regression this session introduced: fixing `checkServer` made the
dropdown functional again, which made a **pre-existing, previously-unreachable gap**
reachable — `UI_BLOCKED_STATUSES`/`UI_BLOCKED` only ever checked the TARGET status
being set, never the phase's CURRENT one. The user hit this for real (accidentally
changed a phase's status) and fixed it themselves via a direct file edit before
reporting it.

In hindsight, this session's own Verification section (above) already exercised the
bug without recognizing it: `POST /api/phases/2/status {"status":"Ready for QA"}`
"succeeded" against Phase 2 while it was still `Not started` — logged at the time as
proof the API wasn't blocked by anything, which was true, but should have been read as
"this transition should have been refused and wasn't." Missed the significance until
the user hit it independently and reported it.

**Fix**: `server.js`'s `setPhaseStatus()` now also inspects the phase's CURRENT status
line (already being read for the Complete-lock check) and refuses the request outright
if it starts with `Not started` or `In progress`, regardless of the requested target.
`phase-tracker.js`'s `makeStatusSelect()` mirrors this — the whole `<select>` is
`disabled` (not just those two `<option>`s) whenever `phase.status` is
`not-started`/`in-progress`, with an explanatory `title`.

**Verified**: restarted `server.js`, confirmed via `curl`:
- `POST /api/phases/2/status` (Phase 02, currently `In progress`) → rejected, exact
  current-status text quoted back in the error.
- `POST /api/phases/3/status` (Phase 03, currently `Not started`) → rejected the same
  way.
- Set Phase 03 to `Blocked` (an agent-owned-but-not-blocked state) via direct file edit,
  then `POST /api/phases/3/status {"status":"Ready for Review"}` → succeeded, confirming
  the fix doesn't over-block legitimate transitions. Reverted Phase 03 back to
  `Not started.` immediately after (test scratch state, not real work).
- Confirmed via `grep` that Phase 02's actual file was untouched by the rejected
  request (no write occurs before the check).

Documented in `09-development-rules.md` rule 12 and `html-docs/README.md` alongside the
existing "blocked as a target" description, since this is the same rule, not a new one
— the original description was just incomplete.
