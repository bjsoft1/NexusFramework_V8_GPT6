# V5 tried a custom UEdMode alongside Landscape Mode and it crashed — V6's Phase 02/03 may have rebuilt the same bug

Date: 2026-08-09
Category: research
Phase: phases/02, phases/03 (both potentially affected)

## Context

User instruction, immediately after Phase 03 shipped: "we need to visible this panel
inside the Landscape tools due to our plugin depend on landscape mode. visit V5 and you
can understanding." Investigated `NexusFramework_V5`'s actual editor-UI source
(sibling project) to understand the real mechanism V5 uses.

## Problem / Goal

Understand exactly how V5 wires its editor UI relative to Landscape Mode, and whether
V6's current approach (Phase 02: `UNexusEdMode : UEdMode`, a fully separate custom
Editor Mode with its own Modes-toolbar entry — per `04-v6-architecture.md`'s "Editor
surface" section) is safe.

## Findings

**V5 does NOT use a custom `UEdMode` at all — and says explicitly why, in its own code
comment.** `NexusFramework_V5/Source/NexusFrameworkEditor/Public/UI/
NexusFrameworkLandscapeModeExtension.h`:

> "Shows/hides the Nexus Framework dockable tab in lockstep with built-in Landscape
> Mode. Deliberately NOT a custom UEdMode - that was tried first and reverted after a
> real crash (`Assertion failed: !Toolkits.Contains(NewToolkit)` in
> `ToolkitManager.cpp`): activating a second UEdMode alongside Landscape Mode conflicts
> with Landscape Mode's own toolkit registration, and there is no supported extension
> point into Landscape Mode's own panel. A dockable Nomad tab, opened/closed alongside
> Landscape Mode rather than living inside it, has no such conflict."

**V5's actual mechanism** (`NexusFrameworkLandscapeModeExtension.cpp`, driven from
`FNexusFrameworkEditorModule::StartupModule()`):

1. Three panels (main, details, sync-inspector) registered as **Nomad tabs** via
   `FGlobalTabmanager::Get()->RegisterNomadTabSpawner(...)` — ordinary `SDockTab`
   widgets, not injected into Landscape Mode's own toolkit UI (no `FLayoutExtender`,
   `ExtendToolBar`, or `FToolBarExtender` anywhere in the module).
2. Listens for `FEditorModeTools::OnEditorModeIDChanged()` on the level editor's own
   mode manager (`ILevelEditor::GetEditorModeManager()`), deferred until a level editor
   actually exists (mirrors `FLevelInstanceEditorModule::StartupModule()`'s own startup-
   crash avoidance).
3. Filters strictly on the **built-in** Landscape mode ID and auto-invokes/closes the
   tabs:

```cpp
void FNexusFrameworkLandscapeModeExtension::OnEditorModeIDChanged(const FName& InModeID, bool bIsEnteringMode)
{
	if (InModeID != FBuiltinEditorModes::EM_Landscape) { return; }
	if (bIsEnteringMode)
	{
		FGlobalTabmanager::Get()->TryInvokeTab(NexusFrameworkTab::TabId);
		FGlobalTabmanager::Get()->TryInvokeTab(NexusFrameworkTab::DetailsTabId);
		FGlobalTabmanager::Get()->TryInvokeTab(NexusFrameworkTab::SyncInspectorTabId);
	}
	else { /* unsaved-changes prompt, then RequestCloseTab() each */ }
}
```

So: entering Unreal's own built-in Landscape Mode auto-opens the three tabs; leaving it
auto-closes them. The UI *feels* like it lives inside the Landscape workflow (it only
ever appears alongside Landscape Mode) without ever being a second competing `UEdMode`.

**V4, for comparison, DOES use a fully independent custom `UEdMode`**
(`UNexusFrameworkMode : public UBaseLegacyWidgetEdMode`, own `FEditorModeInfo`, own
Modes-toolbar slot) with no Landscape Mode coupling — the same shape V6's Phase 02
just built. No crash is recorded against V4 specifically, but V5 (chronologically
later, and the project V6's own architecture is explicitly built from the lessons of)
hit this for real and reverted. Whether V4 simply never exercised the exact trigger
condition (running the custom mode at the same time Landscape Mode's own toolkit is
also active/registering) isn't confirmed — but V5's own comment is unambiguous that the
crash is real and reproducible for this class of approach.

## Why this matters for V6 right now

**Phase 02 (already marked `Complete` by the user) and Phase 03 (currently `Ready for
Review`) built exactly `UNexusEdMode : UEdMode` — the same shape V5's comment says
crashes.** Neither phase's own build/log verification this session would have caught
this: both only confirmed the module loads and compiles cleanly at editor *startup* —
neither session actually activated the mode from the Modes toolbar (Phase 02's report
said so explicitly), which is exactly the action that would trigger the
`ToolkitManager.cpp` assertion if V5's finding transfers to V6's engine version (both
are UE 5.8, so it very plausibly does). This plugin's whole purpose is reading
Landscape Spline data, meaning a user needing the Nexus mode active while Landscape
Mode is also relevant isn't a rare edge case — it's close to the normal workflow, so
this isn't a low-probability risk if it does reproduce.

## Result

Not yet resolved — flagged to the user directly rather than unilaterally rewriting
`04-v6-architecture.md`'s "custom Editor Mode" decision and reworking Phase 02/03,
given the scope of what changing this touches (this session's ai-change-audits records
for Phase 02/03, the phase files' own Allowed/Completion Criteria wording, and
`07-v6-ui-design.md`'s "Hosted inside a custom Editor Mode, not freestanding dockable
tabs" section, which would need to become the opposite conclusion V5 already proved).

## Important Notes

- Do not treat this as a routine "add to backlog" item — this is a **confirmed,
  reproducible engine crash** in the pattern Phase 02/03 already implemented, per V5's
  own hard-won, explicitly-documented lesson. The standing "carry forward what V5
  proved, don't rediscover it the hard way" principle already established for the
  control-point-rename trick (`04-v6-architecture.md`) applies equally here.
- If V6 adopts V5's Nomad-tab-synced-to-`EM_Landscape` approach instead: Phase 02's
  `UNexusEdMode`/`FEditorModeRegistry`-auto-discovery work and Phase 03's
  `FNexusEdModeToolkit`/`SNexusEdModePanel` would need to become
  `FNexusFrameworkLandscapeModeExtension`-style Nomad tabs + a plain `SCompoundWidget`
  panel instead of a `FModeToolkit` — a real rework, not a small patch, since the
  hosting mechanism itself changes.

## Correction — 2026-08-09 (full rework implemented and verified)

User authorized and requested the rework directly: "Replace the `UNexusEdMode` /
`FModeToolkit` / `SNexusEdModePanel` hosting model with V5's proven architecture."
Explicit follow-up instruction: do not report success on compilation alone — launch the
editor and verify real Landscape Mode enter/exit behavior; report NOT VERIFIED if that
can't be completed.

### Changes made

- Deleted `Source/NexusFrameworkEditor/{Public/EdMode,Private/EdMode}/` entirely
  (`NexusEdMode.h/.cpp`, `NexusEdModeToolkit.h/.cpp`) — the crashing pattern.
- New `Source/NexusFrameworkEditor/{Public,Private}/UI/NexusLandscapeModeExtension.h/.cpp`
  — `FNexusLandscapeModeExtension`, ported from V5's
  `FNexusFrameworkLandscapeModeExtension` (same `RegisterNomadTabSpawner` +
  `OnEditorModeIDChanged`/`TryInvokeTab`/`RequestCloseTab` pattern; V6 keeps its single
  combined panel instead of V5's three tabs, per `07-v6-ui-design.md`'s existing
  "fewer tabs than V5" goal).
- `SNexusEdModePanel` renamed to `SNexusFrameworkPanel` (content unchanged — same
  Hierarchy/Debug Tree/Details/Diagnostics sections built in Phase 03, now hosted in a
  Nomad tab instead of a toolkit's inline content).
- `NexusFrameworkEditorModule.h/.cpp` now owns and `Register()`/`Unregister()`s the
  extension directly from `StartupModule()`/`ShutdownModule()`.
- `NexusFrameworkEditor.Build.cs` — added `LevelEditor` (`FLevelEditorModule`/
  `ILevelEditor`), dropped nothing (still needs `UnrealEd`/`Slate`/`SlateCore`/
  `PropertyEditor`/`InputCore` for the panel content itself).
- Docs rewritten: `04-v6-architecture.md` ("Editor surface"), `07-v6-ui-design.md`
  (hosting section), `13-v6-gizmo-system.md` + `phases/phase-48.md` (flagged the
  `UInteractiveToolManager` gizmo assumption as an open question — V5 has zero
  Interactive Tools Framework usage anywhere, so V6's planned Phase 48 gizmo mechanism
  now has no proven precedent and needs its own research pass when that phase starts),
  `06-v6-debug-system.md` (confirmed V5's Tick-driven `DrawDebugLine`/overlay mechanism,
  not `UEdMode::Render()`), `README.md`, `v6-phase-verification.md`. `phases/phase-02-
  editor-tool.md` and `phases/phase-03-ui-shell.md` fully rewritten for the new
  architecture (titles, Objective/Allowed/Not-Allowed/Completion-Criteria), each with an
  explicit "do not implement a custom `UEdMode`/`FModeToolkit`" line in Not Allowed.
- New automation test `Source/NexusFrameworkEditor/Private/Tests/
  NexusLandscapeModeExtensionTests.cpp` (`NexusFramework.Editor.UI.LandscapeModeTabSync`)
  — drives the real, already-running extension instance via `GLevelEditorModeTools()
  .ActivateMode/DeactivateMode(EM_Landscape)`, not a test double.

### The automation-test detour (false negative, not a product bug)

The first several versions of this test, checking tab state via
`FGlobalTabmanager::Get()->FindExistingLiveTab(TabId)`, reported the tab as never
opening — reproduced identically across `UnrealEditor-Cmd.exe` (`-nullrhi` and without),
and the full interactive `UnrealEditor.exe`, with generous startup-settle delays (up to
8s) and per-tick polling (up to 300 ticks). Diagnostic `UE_LOG` instrumentation (since
removed) proved `OnEditorModeIDChanged` fired correctly every time and
`TryInvokeTab()`/`GetDockArea()` both reported success every time — only
`FindExistingLiveTab()`'s own answer, queried moments later, disagreed. OS-level window
enumeration (Win32 `EnumWindows` against the running `UnrealEditor.exe` PID, polled every
2s for the test's full run) proved no second native window was ever created for the tab
in any of these three launch configurations, despite the Slate-level objects reporting
success — pointing at UE's Automation Testing framework itself suppressing/deferring
real native window creation while a test runs (plausible: a CI-safety behavior so
automated tests can't pop up windows on headless runners), not a wiring defect.

**User manually launched the editor and visually confirmed the real behavior is
correct**: entering Landscape Mode opens/activates the Nexus tab, exactly as designed.
This settled it as a test-detection bug, not a production bug, and per the user's direct
instruction the investigation stopped digging into Slate/Automation internals and fixed
the test instead: `FNexusLandscapeModeExtension` now tracks its own invoked tab
(`TWeakPtr<SDockTab> ActiveTab`, set from `TryInvokeTab()`'s return value, cleared on
mode-exit and via the tab's own `OnTabClosed` callback) and exposes it as
`GetActiveNexusTab()`; the test reads that directly (via a new
`FNexusFrameworkEditorModule::GetLandscapeModeExtension()` accessor) instead of
re-deriving tab-live state through `FindExistingLiveTab()`. All diagnostic logging was
removed afterward — `FNexusLandscapeModeExtension` is back to matching V5's proven
pattern exactly (V5's own file has zero logging in this class).

### Verification

- **Manual/interactive (authoritative)**: user launched the real editor and visually
  confirmed entering Landscape Mode opens/activates the Nexus tab. This is the
  real-world confirmation the whole rework exists to satisfy.
- **Automated**: `NexusFramework.Editor.UI.LandscapeModeTabSync` — `Result={Success}`,
  confirmed in both `UnrealEditor-Cmd.exe -nullrhi` and non-`-nullrhi` runs, after the
  test-detection fix above.
- **Build**: `NexusFrameworkEditor` — `Result: Succeeded`, zero errors, across every
  rebuild in this session (deletion, new extension, rename, diagnostics added/removed,
  test rewrites).
- Whole-project search confirmed no remaining `UNexusEdMode`/`FModeToolkit`/
  `SNexusEdModePanel` references anywhere in `Source/` (only correctly-historical
  mentions remain in docs, describing what V6 used to do and why it changed).

### Result

**VERIFIED** — both automated (test passes) and manual (user visually confirmed in a
real interactive editor session). Not merely "compiles" — the actual Landscape Mode
enter/exit → tab open/close behavior works as designed, matching V5's proven mechanism.

### Important Notes

- A new project-wide coding convention was requested alongside this work (not specific
  to this rework, but recorded here for the session): large/growing `.cpp` files should
  be split by responsibility across multiple `.cpp` files sharing one `.h` — see
  `project-specifications/09-development-rules.md`'s "Source file organization" section
  for the full rule. Applies proactively to future phases; nothing in this rework
  currently needs it (all files stayed small and single-responsibility).
- If a future test needs to check Slate tab/window liveness again, prefer exposing
  authoritative state directly from the production code that owns it (as done here)
  over calling into `FGlobalTabmanager` query APIs from inside an Automation Test — this
  session's evidence suggests those queries are not reliable from that specific execution
  context, for reasons not fully root-caused (automation-driven window-creation
  suppression is the leading theory, not confirmed against engine source).
