# Phase 100 — Verification Tree & Publish Gate (new roadmap addition)

Task: Add a manual visual-QA/publish-gate phase to the roadmap
Category: feature-add
Phase: phases/100
Status: Not started (this record is the phase's *creation*, not its implementation)
Completed Date: 2026-08-09
Completed Time: 23:10 GMT+5:45 (+0545)

## Context

Direct user request: before a dynamically generated map ships, someone needs one tree
view of everything V6 generated (State → City → Highway → placed objects like Parking/
Bus Stop/Traffic Light), the ability to click an item to focus it in the editor
viewport, and a per-item manual sign-off checklist, gating "ready to publish." User
explicitly offered the checklist content ("UI Placement Correct", "Smoke Test Complete",
"Overall Test Complete") as a **demo of the idea, not a fixed spec** — "in future maybe
we plan more batter or someing elase just demo."

## Problem / Goal

Turn this into a properly-scoped roadmap phase, not just an ad-hoc implementation —
this is a whole new subsystem, comparable in shape to how Debug Architecture got its own
doc (`06-v6-debug-system.md`) before phases 23–35 implemented it.

## Findings

1. **Phase numbering was a real, not cosmetic, decision.** The roadmap is documented as
   "roughly 100 phase files, phase-00 through phase-99" (rule 3), with Phase 99 already
   titled "Final Validation." Asked the user to confirm 100 vs. 101 (a fixed,
   cross-referenced file path is expensive to rename later) — answered **100**.
2. **3-digit phase numbers silently broke existing tooling.** `server.js`'s
   `findPhaseFile()` and `build.js`'s `extractPhases()` fallback both used a hardcoded
   `phase-(\d{2})` capture (exactly 2 digits) to extract a phase's numeric id from its
   filename. For `phase-100-....md`, that captures `"10"` — not `"100"` — which would
   have made Phase 100 **permanently unreachable** through the content-popup/status-
   change API (`Number("10") !== Number(100)`, so `findPhaseFile(100)` could never
   match), regardless of which number was chosen. This wasn't specific to "100" — any
   3-digit exception would have hit it. Confirmed via `curl` before the fix (`ok:false`)
   and after (`ok:true`).
3. **This is a genuinely different concern from the existing Debug Architecture
   (Phases 23–35), not a duplicate of it.** The Debug Tree (Phase 24) is organized by
   *rendering category* (Landscape/Roads/Infrastructure/...) with per-category config
   (`FNexusDebugRenderConfig`, how something draws). This system needs a tree organized
   by *content hierarchy* (State/City/Highway/placed objects) with new *per-instance*
   state (has a human confirmed this specific object). Click-to-focus, however, is
   exactly Phase 27's existing "select the offending entity in the Hierarchy/viewport"
   mechanism — reusing it, not reimplementing it, is explicit in both the new phase file
   and the new architecture doc.

## Changes

- `project-specifications/15-v6-verification-system.md` — new architecture doc (matches
  the `04`–`14` numbered-doc convention). Documents: why this is separate from Debug
  Architecture; the `FNexusVerificationStatus`/`FNexusVerificationCheckItem` data model
  (array-based checklist, deliberately not fixed struct fields, so the list can change
  per object type later without a struct migration); persistence on the
  `[LandscapeId]_nexusconfig` asset (same place every other per-Landscape Nexus state
  lives); the publish-gate behavior (an instance with no record at all counts as
  unverified — "no record" is not treated as "approved").
- `project-specifications/phases/phase-100-verification-and-publish-gate.md` — new phase
  file, tightly scoped (5 Allowed items) precisely because it reuses Phase 24's tree
  mechanics and Phase 27's click-to-focus rather than rebuilding either.
- `project-specifications/README.md` — doc index (+15), phase-roadmap section (+100,
  notes the "1 complete" → "Phase 00 Complete, Phase 01 Ready for Review" correction
  that was already stale from the Phase 01 work).
- `project-specifications/09-development-rules.md` rule 3 — documents the 3-digit
  exception as deliberate-and-rare, not a pattern to reach for casually, and notes the
  `\d{2,3}` tooling constraint (not unlimited digits).
- `html-docs/server.js` (`findPhaseFile`) and `html-docs/build.js` (`extractPhases`'s
  filename fallback + file-discovery filter) — widened `\d{2}` → `\d{2,3}` (Findings #2).
- `html-docs/js/nav-data.js`, `html-docs/build.js`'s `DOC_PAGES` — registered the new
  doc so the sidebar links to it and `build.js` renders it.

## Verification

- `node html-docs/build.js` → `Wrote 19 doc pages... PHASE-STATUS.md (101 phases, 1
  complete)`.
- Restarted `html-docs/server.js` (required — the previous instance had the pre-fix
  `\d{2}` regex loaded in memory; a source edit alone doesn't affect a already-running
  process) and confirmed via `curl`:
  - `GET /api/phases/100/content` → `ok:true`, correct file/title (previously `ok:false`
    with the un-restarted/pre-fix server).
  - `GET /api/phases/10/content` → still correctly resolves to `phase-10.md` (Nexus
    Mapping), confirming the widened regex didn't introduce a collision with the
    existing 2-digit phases.
  - `GET /15-v6-verification-system.html` → `HTTP 200`.

## Result

Phase 100 exists as a properly-scoped, cross-referenced roadmap entry with its own
architecture doc, `Status: Not started` (this session only added the phase to the
roadmap — implementing it is separate future work, picked up via `/TODO` like any other
phase). Left `html-docs/server.js` running in the background.

## Important Notes

- The starting checklist (`UI Placement Correct`/`Smoke Test Complete`/
  `Overall Test Complete`) is explicitly provisional per the user's own framing — do not
  treat it as a locked spec when Phase 100 is actually implemented. The array-based
  `Checks` shape in `15-v6-verification-system.md` exists specifically so it can change
  without a struct migration.
- If a future phase ever needs a 4-digit phase number, the `\d{2,3}` tooling regex will
  need widening again — rule 3 now says this shouldn't be reached for casually in the
  first place.
