# Phase 02 — Editor Plugin Foundation — Custom Editor Mode

Task: Phase 02 — Editor Plugin Foundation — Custom Editor Mode
Date: 2026-08-09
Category: feature-add
Phase: phases/02
Status: In progress (2 of 3 Completion Criteria need human visual confirmation)
Completed Date: 2026-08-09
Completed Time: 23:20 GMT+5:45 (+0545)

## Context

Picked up via `/TODO` ("now move next phase") immediately after Phase 01. Phase 01 is
now `Ready for QA` (the user moved it there themselves via the now-working phase-tracker
dropdown), so per rule 12/"do not jump phases" the next work item is Phase 02, the
lowest-numbered `Not started` phase (Phase 100 exists but is explicitly out of numeric
order in the roadmap, not next).

## Problem / Goal

Implement `project-specifications/phases/phase-02-editor-tool.md`: stand up a real
custom Editor Mode (`UNexusEdMode : UEdMode`) with a Modes-toolbar entry, an empty
`FNexusEdModeToolkit : FModeToolkit` stub, and a `UEditorSubsystem` for future
mode-independent state — per `04-v6-architecture.md`'s "Editor surface" section
(the Landscape-Mode/Modeling-Mode architectural family, not a bare subsystem + floating
tabs).

## Findings

1. **"Create the plugin descriptor" (this phase's own Allowed-list wording) was already
   done, incidentally, by Phase 01.** Phase 01's audit record already established V6 is
   a standalone `.uproject` (not a `.uplugin`), and while implementing it I'd already
   registered `NexusFrameworkEditor` as a second `Editor`-type module in
   `NexusFramework.uproject`. So this phase's actual net-new work is the Build.cs
   dependency additions (UnrealEd etc.) and the mode/toolkit/subsystem code itself, not
   module scaffolding from scratch.
2. **Verified exact UE 5.8 engine APIs from the installed engine source before writing
   any code**, rather than from training-data memory (which can be wrong for a specific
   engine version) — via `Engine\Source\Editor\UnrealEd\Public\Tools\UEdMode.h`,
   `Toolkits\BaseToolkit.h`, `Editor\EditorFramework\Public\Tools\Modes.h`,
   `Editor\EditorSubsystem\Public\EditorSubsystem.h`, and the installed
   `ModelingToolsEditorMode` plugin (already enabled in this project's `.uproject` for
   the Editor target) as a concrete, shipping reference implementation. Key fact that
   shaped the implementation: **modern `UEdMode` subclasses need no explicit
   registration call** (unlike the legacy `FEdMode`/`FEditorModeRegistry::RegisterMode`
   pattern) — `UAssetEditorSubsystem::RegisterEditorModes()` auto-discovers every
   non-abstract `UEdMode` via a `UObject` class iterator and reads `GetModeInfo()`. So
   there is no `StartupModule()` registration code for the mode itself — it's
   discovered purely by existing as a `UCLASS()`.
3. **`CreateToolkit()` returns `void`, not the toolkit** — it assigns the protected
   `TSharedPtr<FModeToolkit> Toolkit` member. Confirmed from the header before writing
   the override, avoiding a wrong-signature compile error.
4. **`FSlateIcon()` default-constructs to a legal "no icon" state** — confirmed from
   `SlateIcon.h` and `FEditorModeRegistry::RegisterMode`'s own default parameter — so
   the mode doesn't need a custom `FSlateStyleSet` yet for Phase 02's stub scope.

## Changes

- `Source/NexusFrameworkEditor/NexusFrameworkEditor.Build.cs` — added `UnrealEd`
  (`UEdMode`/`FModeToolkit`), `EditorFramework` (`FEditorModeInfo`/`FEditorModeID`),
  `EditorSubsystem` (`UEditorSubsystem`), `Slate`/`SlateCore` (the toolkit's stub
  widget) to `PublicDependencyModuleNames`. `NexusFramework` (runtime module)
  untouched — still `Core`/`CoreUObject`/`Engine` only.
- `Source/NexusFrameworkEditor/Public/NexusFrameworkEditorModule.h` /
  `Private/NexusFrameworkEditorModule.cpp` — added a shared
  `DECLARE_LOG_CATEGORY_EXTERN(LogNexusFrameworkEditor, Log, All)` /
  `DEFINE_LOG_CATEGORY`, so every `.cpp` added this phase (and future ones) logs through
  one category instead of each inventing its own.
- `Source/NexusFrameworkEditor/Public/EdMode/NexusEdMode.h`,
  `Private/EdMode/NexusEdMode.cpp` — `UNexusEdMode : UEdMode`. Constructor sets `Info`
  (`FEditorModeId = "NexusFramework.NexusEdMode"`, display name "Nexus",
  `PriorityOrder = 5100`, no icon yet). `Enter()`/`Exit()` call `Super::` and log via
  `LogNexusFrameworkEditor`. `CreateToolkit()` assigns
  `MakeShared<FNexusEdModeToolkit>()`.
- `Source/NexusFrameworkEditor/Private/EdMode/NexusEdModeToolkit.h/.cpp` —
  `FNexusEdModeToolkit : FModeToolkit`. `Init()` just calls `Super::Init()`.
  `GetInlineContent()` returns a single `STextBlock` reading "Nexus Mode toolkit stub -
  Phase 02 (no content yet)." — the whole point being to prove the hosting mechanism,
  not to show real content (that starts Phase 03).
- `Source/NexusFrameworkEditor/Public/Subsystem/NexusFrameworkSubsystem.h`,
  `Private/Subsystem/NexusFrameworkSubsystem.cpp` — `UNexusFrameworkSubsystem :
  UEditorSubsystem`. `Initialize()`/`Deinitialize()` call `Super::` and log only — no
  config asset, no Representation graph yet (that's explicitly later phases' scope per
  `04-v6-architecture.md`).

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development` → **Result: Succeeded** (first try
  — the engine-source research in Findings #2–4 paid off; zero API-mismatch compile
  errors).
- `Build.bat NexusFramework Win64 Development` (the Game target, standalone,
  `NexusFramework.exe`) → **Result: Succeeded** — confirms Completion Criterion 2
  (both modules compile independently) directly, not just inferred from the Editor
  target's build succeeding.
- `grep -r "Slate|UnrealEd|EditorFramework|EditorSubsystem" Source/NexusFramework/` →
  only match is a commented-out template line in the wizard's own `NexusFramework.Build.cs`
  ("// Uncomment if you are using Slate UI") — confirms zero *actual* Slate/UnrealEd
  usage in the runtime module, the other half of Criterion 2.
- Launched the real `UnrealEditor.exe` (not `-nullrhi`/`-cmd` — the actual GUI
  application) against this project. Startup completed with **zero errors** in
  `Saved/Logs/NexusFramework.log`, and `LogNexusFrameworkEditor:
  UNexusFrameworkSubsystem::Initialize` fired exactly where expected (editor subsystems
  initialize automatically during startup) — confirms the subsystem is correctly wired
  and the module loads cleanly under a real (not headless) editor.
- **Not verified this session**: the mode actually appearing on the Modes toolbar, and
  the toolkit stub's text actually rendering when the mode is clicked active — both
  require literally looking at the editor window, which no screenshot/UI-automation
  tool was available to do. The zero-errors clean startup plus the subsystem's
  Initialize firing correctly is meaningful indirect evidence (a malformed `UEdMode`
  reflection/registration setup typically does surface as a startup error), but it is
  not the same as having actually seen it. The editor was left running specifically so
  this can be checked directly next.

## Result

Implementation complete and build-verified; 2 of 3 stated Completion Criteria need a
human to glance at the already-open editor to close out. Left both `## Status: In
progress` (not advanced to `Ready for Review`, since not every criterion is checked yet
— rule 12/`AGENT-TODO-RULES.md`'s ownership boundary is about *which* status an agent
may set, but the literal "every Completion Criterion met" bar in the `/TODO` process
still applies) and `UnrealEditor.exe` itself running, so confirming and finishing this
off should take under a minute.

## Important Notes

- `Source/NexusFramework/{NexusFramework.h,.cpp,.Build.cs}` remain the untouched wizard
  defaults (see Phase 01's audit record) — this phase didn't need to add anything to the
  runtime module.
- The mode's `FEditorModeId` (`"NexusFramework.NexusEdMode"`) and toolkit's
  `GetToolkitFName()` (`"NexusEdMode"`) are now effectively part of the public contract
  future phases may reference (e.g. anything that needs to programmatically activate the
  mode) — don't rename casually.

## Correction — 2026-08-10 (architecture replaced, superseding the above)

**Everything above this section describes `UNexusEdMode : UEdMode` — since replaced.**
Investigation the same day (`ai-change-audits/2026-08-09/research/
v5-custom-edmode-crash-vs-landscape-mode.md`) found this is the exact pattern that
crashed `NexusFramework_V5` for real (`Assertion failed:
!Toolkits.Contains(NewToolkit)` in `ToolkitManager.cpp` when active alongside built-in
Landscape Mode). User authorized and requested a full rework to V5's proven fix instead.

`UNexusEdMode`/`NexusEdModeToolkit` (the `EdMode/` folder) were deleted entirely and
replaced with `FNexusLandscapeModeExtension` (`UI/NexusLandscapeModeExtension.h/.cpp`)
— a plain class (not a `UEdMode`) that listens for
`FEditorModeTools::OnEditorModeIDChanged`, filtered to `FBuiltinEditorModes::
EM_Landscape`, and opens/closes a Nomad `SDockTab` (`SNexusFrameworkPanel`, renamed from
`SNexusEdModePanel`) in lockstep with it — ported byte-for-byte from V5's own
`FNexusFrameworkLandscapeModeExtension`. `NexusFrameworkEditorModule` now owns and
registers the extension directly. `Build.cs` gained `LevelEditor`
(`FLevelEditorModule`/`ILevelEditor`).

Both stated "not verified this session" items above (mode toolbar entry, toolkit
content rendering) are moot under the new architecture — there is no Modes-toolbar
entry or `FModeToolkit` anymore. The equivalent behavior (Nexus tab opens on entering
Landscape Mode, closes on leaving) **was verified**: user manually launched the real
interactive editor and visually confirmed it. Full details, including a lengthy
automated-test false-negative detour that turned out to be a test-detection bug (not a
product bug), are in the research record's own 2026-08-09 Correction section — this
note exists so a reader landing on this file directly (not the research record) isn't
misled by the "Not verified"/`UEdMode` content above into thinking that's still current.

Phase 02's `## Status` is `Ready for Review` as of this correction (see
`project-specifications/phases/phase-02-editor-tool.md`), based on the new
architecture's own Completion Criteria, not the ones this original record describes.
