# Phase 04 — UI Interaction

Task: Phase 04 — UI Interaction
Category: feature-add
Phase: phases/04
Status: Ready for Review
Completed Date: 2026-08-10
Completed Time: 00:41 NST (+0545)

## Context

Picked up via `/TODO` ("Next phase") immediately after Phase 02/03's architecture
correction shipped (both now `Ready for QA`, moved there by the user). Phase 04 is the
lowest-numbered `Not started` phase.

## Problem / Goal

Implement `project-specifications/phases/phase-04-ui-interaction.md`: wire selection,
expand/collapse, right-click context menu, and a reusable destructive-action confirm
dialog into Phase 03's `SNexusFrameworkPanel` shell — still against placeholder data,
no real backend.

## Findings

1. **`project-specifications/AGENT-RULES.md`'s Agent Testing Policy (added this
   session, just before this phase started) directly changes how this phase closes
   out** — no automated test written, no editor launch for verification; build-only,
   with exact manual-check steps written into the phase file instead. This is the
   first phase implemented entirely under that policy.
2. Researched `NexusFramework_V5`'s proven patterns before writing anything (per
   `07-v6-ui-design.md`'s "V5 precedent, kept" note) via a research subagent:
   - V5's tree selection does **not** talk to the Details panel directly — it updates
     an editor-subsystem-owned "active selection" that a separate, decoupled
     `SNexusFrameworkDetailsPanel` listens to via a delegate, then wraps the live
     struct pointer in a non-owning `FStructOnScope` and calls
     `DetailsView->SetStructureData(...)`. V6's Phase 04 keeps the two widgets
     un-decoupled (Details is still inside the same combined panel per Phase 03's
     "fewer tabs than V5" design goal) but reuses the exact same `FStructOnScope`
     wrapping mechanism — direct `OnSelectionChanged` -> `SetStructureData`, no
     subsystem indirection yet since there's no real subsystem-owned selection state
     this phase (placeholder data only).
   - V5's right-click menu is built via `FMenuBuilder` off `OnContextMenuOpening`, but
     is much richer than a plain Delete/Rename/Focus list (inline `SEditableTextBox`
     rename fields, no separate Focus entry — focus happens automatically on select).
     V6 keeps the simpler literal Delete/Rename/Focus shape the phase file asks for.
   - V5 has **no reusable confirm-dialog helper** — every delete call site inlines its
     own `FMessageDialog::Open(EAppMsgType::YesNo, ...)`. `07-v6-ui-design.md`
     explicitly wants a *reusable* one, so this is new plumbing (`FNexusUIDialogs`),
     not a direct port — same underlying `FMessageDialog::Open` mechanism V5 already
     proved works, just centralized.
   - V5's tree item struct (`FNexusOutlinerItem`: Type/Id/DisplayName/Children) is the
     model for V6's new `FNexusPlaceholderTreeItem` (Id/DisplayName/Children — no Type
     yet, not needed until real per-type data exists).
3. **`FUIAction`'s `CreateSP` payload-binding pitfall**: binding extra "payload"
   arguments after the member function pointer (`CreateSP(this, &Func, Arg1, Arg2)`)
   requires the deduced payload types to *exactly* match the function's parameter
   types — passing named lvalues deduces them as references, which then fails to match
   a function taking those parameters by value/const-ref in the normal way, producing
   confusing cascading overload-resolution errors on the *caller* (`AddMenuEntry`)
   rather than a clear message at the actual `CreateSP` call. Fixed by using
   `CreateLambda` with an explicit capture list instead — simpler to reason about and
   avoids the deduction pitfall entirely.

## Changes

- New `Source/NexusFrameworkEditor/Public/UI/NexusPlaceholderTreeItem.h` —
  `FNexusPlaceholderTreeItem` (Id/DisplayName/Children), shared by both Hierarchy and
  Debug Tree.
- New `Source/NexusFrameworkEditor/Public/UI/NexusPlaceholderDetails.h` —
  `USTRUCT() FNexusPlaceholderDetails` (DisplayName/Id/Notes), bound into the Details
  panel's `IStructureDetailsView` on selection.
- New `Source/NexusFrameworkEditor/{Public,Private}/UI/NexusUIDialogs.h/.cpp` —
  `FNexusUIDialogs::ConfirmDestructiveAction(Title, Body) -> bool`, the reusable
  confirm dialog `07-v6-ui-design.md` asks for (wraps `FMessageDialog::Open`).
- `SNexusFrameworkPanel.h/.cpp` — Hierarchy/Debug Tree switched from placeholder
  `TSharedPtr<FString>` items to `FNexusPlaceholderTreeItem`, pre-populated with a
  hardcoded multi-level placeholder hierarchy (State > City > Highway > HighwayPoint;
  Category > sub-category for the Debug Tree), both trees auto-expanded on construct.
  Added `OnSelectionChanged` (feeds the Details panel via `FStructOnScope`),
  `OnContextMenuOpening` (Delete/Rename/Focus via `FMenuBuilder`), `HandleDeleteItem`
  (confirm dialog -> recursive removal from the placeholder array -> tree refresh),
  `HandleRenameItem`/`HandleFocusItem` (stubbed no-ops, per phase scope). Diagnostics
  list untouched (still an empty shell — not in this phase's Allowed list).

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development` — first attempt failed
  (`FUIAction`/`CreateSP` payload-deduction error, Findings #3); fixed via
  `CreateLambda`, second attempt **Result: Succeeded**.
- **No automated test written or run, no editor launched for verification** — per
  `AGENT-RULES.md`'s Agent Testing Policy (new this session). Exact manual-check steps
  for all three Completion Criteria are written directly into
  `project-specifications/phases/phase-04-ui-interaction.md`'s Completion Criteria
  section for the user's own pass in Unreal Editor.

## Result

Implementation complete, build-verified only. All three Completion Criteria left
unchecked pending the user's manual verification (see the phase file for exact steps) —
this is the intended shape of a completed phase under the new Agent Testing Policy, not
a partial/incomplete session.

## Important Notes

- `FNexusPlaceholderTreeItem`/`FNexusPlaceholderDetails` are throwaway UI-plumbing
  types, not V6's real data model — whichever future phase wires real Hierarchy/Debug
  Tree data (Mapping/Representation-consuming phases, Phase 24) replaces them with
  real per-type structs, not extends them. Don't build on top of the placeholder
  shapes expecting them to survive past that point.
- `FNexusUIDialogs::ConfirmDestructiveAction` is now the one place any future phase
  should route destructive-action confirmations through — don't inline a new
  `FMessageDialog::Open` call at a new delete/clear site the way V5 did at each of its
  own call sites.
