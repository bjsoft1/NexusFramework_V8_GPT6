# Phase content popup + Complete-status 1-hour lock

Task: Phase-tracker popup viewer + Complete-status lock
Category: feature-add
Phase: N/A (tooling, not a roadmap phase)
Status: Ready for Review
Completed Date: 2026-08-09
Completed Time: 22:34 NST (+0545)

## Context

Two explicit user requests in the same session as
`ai-change-audits/2026-08-09/bug-fixed/phase-tracker-status-ui-broken.md`:
1. Replace the phase-tracker's dead raw-`.md` link with a large popup that renders the
   markdown properly (a JS library was explicitly permitted if needed).
2. Once a phase is `Complete`, and its recorded completion date+time is more than 1 hour
   in the past, block any further status changes to it — both from the backend and the
   frontend.

## Problem / Goal

Implement both without breaking the project's stated "no external dependencies, pure
Node/vanilla-JS builtins" convention (`html-docs/README.md`).

## Findings

- `html-docs/build.js` already contains a hand-rolled, dependency-free
  `markdownToHtml()` used to render every doc page (`01-v5-analysis.md` etc.) — reusing
  it for phase files keeps the popup visually identical to every other doc page for
  free, and avoids adding a markdown library (a real option the user offered, but
  unnecessary given this already existed and covers the phase files' own markdown
  constructs).
- `build.js`'s bottom section unconditionally ran the full build (`buildDocPages()` etc.)
  at load time — `require()`-ing it from `server.js` to reuse `markdownToHtml` would have
  triggered a full rebuild as an unwanted side effect of every server start/restart.
- `css/site.css`'s existing `.content` class (used by every generated doc page for
  headers/lists/tables/code) can be reused as-is for the popup body, so the popup needs
  no new prose styling, only overlay/panel chrome.

## Changes

- `html-docs/build.js`: wrapped the "Main" section in
  `if (require.main === module) { ... }` and added
  `module.exports = { markdownToHtml };` — `node build.js` (direct run, including
  `server.js`'s own `execFileSync` rebuild calls, which run it as a separate process)
  still does the full build; `require('./build.js')` (server.js's in-process reuse) does
  not.
- `html-docs/server.js`:
  - New `GET /api/phases/:n/content` → `{ ok, file, title, html }`, `html` via the
    reused `markdownToHtml()`.
  - `serveStatic()` extended (see companion bug-fix record) so a raw link still works as
    a fallback/direct-URL case even though the popup is now the primary path.
  - New `COMPLETE_LOCK_MS` (1 hour) + `parseStatusTimestamp()`, applied inside
    `setPhaseStatus()`: if the phase's *current* status line starts with `Complete` and
    parses to a timestamp more than an hour old, any status-change request is rejected
    before it touches the file, regardless of what new status was requested.
  - `parseStatusTimestamp()` handles both the current
    `Complete — YYYY-MM-DD HH:MM TZID (+HHMM).` convention and the legacy date-only
    `Complete — YYYY-MM-DD.` form (falls back to UTC midnight for the latter, which is
    always ≥ 1 hour old for any date other than "today" — the only distinction the lock
    actually needs to make).
  - Added `nowTimestamp()` and switched `setPhaseStatus()`'s own timestamp generation to
    it — the API-driven path was still only writing a bare date (`todayISO()`), which
    would have silently produced status lines inconsistent with the
    `09-development-rules.md` rule 12 convention this same session updated to include
    time. Format: `YYYY-MM-DD HH:MM <Intl short TZ name> (+HHMM)`, e.g.
    `2026-08-09 22:34 GMT+5:45 (+0545)`.
- `html-docs/js/phase-tracker.js`:
  - `completedTimestampMs()`/`isCompleteLocked()` — client-side mirror of the server's
    lock check, keyed off `phase.statusText` (already present in `js/phase-data.js`).
    Locked rows render their `<select>` `disabled` with an explanatory `title`, so the
    lock is visible before a click round-trips to a 400.
  - Replaced the plain `<a href="../project-specifications/"+phase.file>` with a
    `<button class="phase-open-link">` that calls a new `openPhaseModal(phase)`.
  - Added the modal itself: a single overlay+panel pair created once and reused,
    `fetch("/api/phases/"+phase.n+"/content")`, rendered into a `.content`-classed body
    (same styling every other doc page gets, see Findings). Closes via ✕ button,
    clicking the overlay backdrop, or Escape. Falls back to a plain error message
    (pointing at the raw file path) if the fetch fails, e.g. server not running.
  - Also fixed the pre-existing `checkServer` bug (see companion bug-fix record) in the
    same file, without which none of the above could ever be exercised from the browser
    (`serverOnline` never became `true`).
- `html-docs/css/site.css`: `.phase-modal-overlay`/`.phase-modal`/
  `.phase-modal-header`/`.phase-modal-body` (large: `min(900px, 100%)` wide, up to 90vh
  tall, scrollable body, full-screen on narrow viewports) + `.phase-open-link` button
  styling to replace the old plain `<a>`. Fully theme-aware — uses the same
  `--bg`/`--border`/`--shadow` tokens as the rest of the shell, no new colors introduced.
- `html-docs/README.md` and `project-specifications/09-development-rules.md` rule 12:
  documented the new route and the lock rule.

## Verification

Ran `node html-docs/server.js` and exercised every path with `curl`:

- `GET /api/phases/1/content` → `{ok:true, ...}`, rendered HTML matches
  `markdownToHtml()`'s output for every other doc page (headers, `<code>`, etc.).
- `POST /api/phases/0/status` (Phase 00, `Complete` since before this session, no time in
  its legacy status line) → rejected with the lock error, confirming the date-only
  fallback path works.
- `POST /api/phases/1/status {"status":"Ready for QA"}` (not locked) → succeeded,
  proving the lock doesn't over-fire on non-`Complete`/recent phases — reverted
  immediately after via direct file edit (test mutation, not a real state change; see
  Important Notes).
- `POST /api/phases/2/status {"status":"Ready for Review"}` → status line came back as
  `Ready for Review — 2026-08-09 22:34 GMT+5:45 (+0545).`, confirming `nowTimestamp()`
  produces the rule-12 format end-to-end — also reverted after.
- `node -c` / `node --check` on all three changed `.js` files: clean.
- Did not verify the modal's actual rendering/close interactions in a real browser this
  session (no browser automation available) — verified the underlying `fetch` contract
  and DOM-construction code by reading it, and confirmed the API it depends on returns
  exactly the shape the client expects.

## Result

Both requests implemented and verified server-side/API-level. Left `html-docs/server.js`
running in the background at the end of this session (port 4173) so the user can try the
popup/lock immediately without restarting it themselves.

## Important Notes

- All test-only status mutations made while verifying this (Phase 00 attempted-and-
  rejected — no write occurred; Phase 01 → `Ready for QA`; Phase 02 → `Blocked` →
  `Ready for Review`) were reverted via direct file edit before finishing. Phase 01 is
  back to `Ready for Review — 2026-08-09 22:22 NST (+0545).`, Phase 02 back to
  `Not started.`
- The Complete-lock is keyed entirely off the timestamp text already in the phase file's
  own `## Status` line — no separate lock-state storage exists anywhere. If a phase's
  status line is ever hand-edited to a fake/future `Complete` timestamp, the lock would
  (correctly, if unintuitively) treat it as still within its grace window.

## Correction — 2026-08-09 (real-usage bugs found immediately after shipping)

User tried the popup live (via the phase-tracker, once the `checkServer` fix actually
let the dropdown work) and found two real bugs in what this record called "verified":

1. **Background page scrolled along with the popup.** The overlay covers the viewport
   visually, but nothing had stopped `<body>` itself from being the element that
   actually scrolls on wheel/touch input while the modal is open. Fixed: `openPhaseModal`/
   `closePhaseModal` now toggle a `body.modal-open` class, `{ overflow: hidden; }` in
   `site.css`.
2. **Popup's own scrollbar looked broken/misaligned.** Two compounding causes in
   `.phase-modal-body`: (a) it was a flex child with no `min-height: 0` — a flex item's
   default `min-height` is `auto` (its content's natural height), which lets it grow
   past the panel's `max-height` instead of actually constraining to it and scrolling
   within that space; (b) its own `padding` pushed the scrollbar 28px away from the
   panel's right edge, reading as detached from the content. Fixed: added
   `flex: 1 1 auto; min-height: 0;`; moved padding onto a new inner
   `.phase-modal-body-inner.content` wrapper (`modalBodyEl` in `phase-tracker.js` now
   points at that inner div, not the scroll container itself) so the scrollbar sits
   flush against the edge; added a themed (not default-OS-ugly) `::-webkit-scrollbar`.

Both are exactly the kind of thing that only surfaces from actually clicking around in
a real browser — this session's original verification pass explicitly noted it could
only check the `fetch`/API contract, not real DOM/rendering behavior, and said so rather
than claiming otherwise. That caveat turned out to matter.

Verified this round: `node --check` clean on `phase-tracker.js`; confirmed via `curl`
that the running server serves the updated `site.css`/`phase-tracker.js` content
(`min-height: 0` and `phase-modal-body-inner` both present in the live response) — still
no real-browser check performed by the agent itself (same limitation as before), fixes
based on reading the CSS/layout logic plus the user's direct description of the
symptom.

