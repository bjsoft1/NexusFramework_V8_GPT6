# Phases 06–09 — Landscape Reader (Segment/Tangent, Connection Graph, Stable Identity, Validation)

Task: Phases 06, 07, 08, 09 — the rest of the Landscape Reader arc
Category: feature-add
Phase: phases/06, phases/07, phases/08, phases/09
Status: Ready for Review (all four)
Completed Date: 2026-08-10
Completed Time: 00:56 NST (+0545)

## Context

Picked up via `/TODO` after Phase 05. User asked to batch 3-5 small, related phases per
session going forward rather than one at a time. Phases 06-09 are the natural batch:
all four extend the same `FNexusLandscapeReader` (Phase 05) with no other phase's scope
in between, and are individually small per their own phase files.

## Problem / Goal

Implement `project-specifications/phases/phase-06.md` through `phase-09.md`: segment/
tangent extraction, raw connection-graph adjacency + chain walking, V5's proven stable-
identity rename trick, and the Source-stage validation gate — still Source-stage,
still zero Nexus ID assignment (Mapping's job, next stage), zero writes to the
Landscape.

## Findings

1. **Verified exact UE 5.8 engine APIs before writing code** (established practice):
   `LandscapeSplineSegment.h` (`Connections[2]`, `FLandscapeSplineSegmentConnection`
   with `ControlPoint`/`TangentLen`/`SocketName`), `LandscapeSplineControlPoint.h`
   (`FLandscapeSplineConnection` with `Segment`/`End` plus its own
   `GetNearConnection()`/`GetFarConnection()` convenience accessors — used throughout
   instead of manually computing `1 - End`, matching V5's own idiom exactly).
2. **`TangentLen` is a signed scalar, not a vector** — the actual 3D tangent direction
   is `ControlPoint->Rotation.Vector() * TangentLen` (Phase 06). Confirmed against V5's
   own usage (`ConnectControlPointsWithSegment`, `EnforceSegmentTangent` in
   `NexusFrameworkEditorSubsystem.cpp`) — V5 never stores/reads a separate tangent
   vector field, it always derives it from the control point's `Rotation` the same way.
3. **V5's exact stable-identity mechanism, read directly from source** (Phase 08):
   `IsControlPointOnTargetLandscape()` (`ControlPoint->GetOuter() == TargetSplines`)
   and the rename routine (`FString::Printf(TEXT("NexusPoint_%s"), ...)` +
   `ControlPoint->Rename(*NewName, nullptr, REN_DontCreateRedirectors)`) — ported
   near-verbatim. V6's version adds `TryParseStableId` (parse the tag back into a
   `FGuid`) so `EnsureStableIdentity` is idempotent — V5's own version doesn't need
   this because it always has a `FNexusRoadPoint::PointId` driving the name already;
   V6's Phase 08 has no such Nexus-side struct yet (that's explicitly Mapping's job),
   so the tag itself has to be the source of truth for "is this point already tagged."
4. **Where the assigned identity "lives" needed a deliberate call**: Phase 08's own
   Not Allowed list says "do not assign Nexus IDs yet," same as every other Landscape
   Reader phase, yet the whole point of this phase is giving each point an identity.
   Resolved by keeping the identity **in the engine object's own name** (the rename)
   rather than in any new Nexus-side struct/map — no `TMap<FGuid, ...>` bookkeeping is
   created this phase, so there's no "Nexus ID assignment" in the Mapping-layer sense;
   Mapping (Phase 10+) is what will read this same tag and build its own
   `HighwayPointId` bookkeeping against it.
5. **Junction threshold reused consistently across phases**: "more than 2 connected
   segments" (`> 2`) is used identically in Phase 07's adjacency
   (`[junction candidate]` tagging) and Phase 09's validation (near-zero-tangent-at-
   junction check) — a normal 2-connected point is just mid-chain, not a junction.
6. **Agent Testing Policy shapes all four phases' verification the same way as Phase
   05** — no automated test, no editor launch; a new console command per phase
   (`Nexus.Reader.EnumerateSegments`, `.BuildAdjacency`, `.TagControlPointIdentities`,
   `.ValidateSourceStage`), each following the pattern Phase 05 established.
7. **`.cpp` file organization**: per `09-development-rules.md`'s new "Source file
   organization" rule, `FNexusLandscapeReader` crossed the threshold where splitting by
   responsibility applies — one shared `.h`, five `.cpp` files
   (`NexusLandscapeReader.cpp` for Phase 05, `.Segments.cpp`/`.Graph.cpp`/
   `.Identity.cpp`/`.Validation.cpp` for 06-09). First real application of that rule.

## Changes

- `Source/NexusFrameworkEditor/Public/Reader/NexusLandscapeReader.h` — extended with
  all four phases' method declarations plus new supporting types
  (`FNexusSegmentEndpointRead`, `FNexusSegmentRead`, `FNexusPointAdjacency`,
  `ENexusSourceValidationSeverity`, `FNexusSourceValidationEntry`).
- New `Private/Reader/NexusLandscapeReader.Segments.cpp` (Phase 06) —
  `EnumerateSegments()` + `Nexus.Reader.EnumerateSegments` console command.
- New `Private/Reader/NexusLandscapeReader.Graph.cpp` (Phase 07) — `BuildAdjacency()`,
  `WalkChainFrom()` (visited-set-guarded, terminates on junction/dead-end/closed-loop)
  + `Nexus.Reader.BuildAdjacency` console command.
- New `Private/Reader/NexusLandscapeReader.Identity.cpp` (Phase 08) —
  `IsControlPointOnTargetLandscape()`, `TryParseStableId()`, `EnsureStableIdentity()` +
  `Nexus.Reader.TagControlPointIdentities` console command.
- New `Private/Reader/NexusLandscapeReader.Validation.cpp` (Phase 09) —
  `ValidateSourceStage()` (Blocking-only checks: null control point entries, orphaned/
  unresolved segment connections, foreign-Landscape connections via Phase 08's guard,
  near-zero tangent at a junction) + `Nexus.Reader.ValidateSourceStage` console command.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development` — **Result: Succeeded**, all five
  reader `.cpp` files compiled cleanly, first attempt.
- **No automated tests written or run, no editor launched for verification** — per
  `AGENT-RULES.md`'s Agent Testing Policy. Exact manual-check steps for every
  Completion Criterion across all four phases are written into each phase's own file.

## Result

Implementation complete, build-verified only, for all four phases. Every Completion
Criterion that needs a real Landscape/editor session is left unchecked pending the
user's own manual pass (console commands provided for each); the two purely
code-shape criteria (Phase 05's "no Nexus struct created" precedent, Phase 09's "clean
Landscape produces zero entries") are checked via review, consistent with how Phase 05
handled the same kind of criterion.

## Verification — 2026-08-10 (user manual pass, real Landscape)

User ran all five `Nexus.Reader.*` console commands against a real 10-point closed-loop
test Highway on `Landscape_0` and pasted the Output Log results. Also applies to Phase
05's own record/criteria (same commands, same test Landscape). Going criterion-by-
criterion against what the pasted log actually shows (per `AGENT-RULES.md`: only mark
something verified when the user's own result actually demonstrates it, not just
because a command ran without crashing):

**Confirmed by this run** (phase files updated accordingly):
- Phase 05: `EnumerateControlPoints` — real `ControlPointCount=10` with live Location/
  Rotation for each point, user confirmed it matches.
- Phase 06: `EnumerateSegments` — Start/End + signed `TangentLen` + `TangentVector` for
  all 10 segments; both positive and negative `TangentLen` values present in the same
  run, confirming sign is preserved (not normalized); curve direction confirmed by user.
- Phase 07 (closed-loop criterion only): `BuildAdjacency`'s sample chain walk listed all
  10 loop points exactly once and stopped — no hang/infinite loop.
- Phase 09 (clean-Landscape criterion, in addition to the existing code-review
  confirmation): `ValidateSourceStage` logged "clean - zero validation entries" against
  this real Landscape.

**Still open** — this run's test data was a single closed loop with no junction, no
restart, no second map, and no deliberately-broken point, so it cannot demonstrate
these regardless of how clean the run looked:
- Phase 07's 3-way-junction criterion — every point in this test logged
  `ConnectedSegmentCount=2`; no junction was present to exercise the
  `[junction candidate]` tagging path.
- Phase 08's both criteria — a baseline set of real `StableId` values was captured
  (useful for the eventual restart-comparison) but no restart-and-recompare or
  cross-map test was run yet.
- Phase 09's deliberately-broken-point criterion — only the clean case was exercised.

None of the open items point to a suspected bug; they're untested scenarios, not
failing ones. Consistent with `/TODO`'s Step B7, this doesn't block moving on to the
next phases — the open criteria stay unchecked in each phase file for whenever the user
gets to them.

## Important Notes

- All four phases' console commands (`Nexus.Reader.EnumerateSegments`,
  `.BuildAdjacency`, `.TagControlPointIdentities`, `.ValidateSourceStage`) plus Phase
  05's `.EnumerateControlPoints` are now a small but real "Source stage smoke-test
  toolkit" — whichever phase first builds real UI for this (Diagnostics Panel,
  Phase 27) should treat these as the reference behavior to match, not reinvent.
- `FNexusLandscapeReader` is still a static-method utility with no state and no wiring
  into `FNexusLandscapeModeExtension`/`UNexusFrameworkSubsystem` — unchanged from
  Phase 05's note. Whichever phase first needs automatic (not manually-triggered)
  reading decides that wiring, not any of 05-09.
- `EnsureStableIdentity`'s rename is NOT gated behind `IsControlPointOnTargetLandscape`
  — it operates on whatever `ULandscapeSplineControlPoint*` it's given, trusting the
  caller (the console command enumerates via the currently-resolved active Landscape,
  so this is safe in practice, but a future caller passing a foreign-map pointer would
  rename it unguarded). Worth a guard if a non-console-command caller appears later.
