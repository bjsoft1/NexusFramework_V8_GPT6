# Phase 01 — Core Structures

Task: Phase 01 — Core Structures
Date: 2026-08-09
Category: feature-add
Phase: phases/01
Status: Ready for Review
Completed Date: 2026-08-09
Completed Time: 22:22 NST (+0545)

## Context

First real implementation work on V6 — everything before this was
`project-specifications/` only, nothing under `Source/` existed yet. Picked up via
`/TODO` (agent-todos was empty, so it fell through to the roadmap; Phase 01 is the
lowest-numbered `Not started` phase after Phase 00).

## Problem / Goal

Implement `project-specifications/phases/phase-01-core-structures.md`: define V6's core
identity structs (`FNexusState`/`FNexusCity`/`FNexusHighway`/`FNexusHighwayPoint`) and the
`-1`/`0`/`>0` inheritance-resolution helper, per `05-v6-data-flow.md` — headers only, no
Landscape reading, mapping, or generation logic.

## Findings

1. **No Unreal project scaffold existed at session start** — `Source/`, `.uproject`, and
   `.uplugin` were all absent; the repo was specs-only. I initially assumed V6 would ship
   as a bare `.uplugin` (project-overview.md/04-v6-architecture.md both literally say
   "V6 is an Editor-Only plugin") and started building that: a `NexusFramework.uplugin`
   at repo root plus `NexusFrameworkModule.h/.cpp` boilerplate for a from-scratch
   `NexusFramework` module.
2. **Mid-session, the user generated a real `.uproject` via the Unreal Editor's own C++
   project wizard** (signaled by the mid-turn message "project name: NexusFramework" and
   confirmed by finding freshly-timestamped, unmistakably wizard-generated files:
   `IMPLEMENT_PRIMARY_GAME_MODULE`, `EnhancedInput`/`InputCore` deps, `// Copyright Epic
   Games, Inc.` headers, `.sln`/`.vs` caches). This produced a standard **Game project**
   named `NexusFramework` — `NexusFramework.uproject`, `Source/NexusFramework.Target.cs`
   (Game) + `Source/NexusFrameworkEditor.Target.cs` (Editor, both referencing a single
   `NexusFramework` runtime module), and the flat
   `Source/NexusFramework/{NexusFramework.h,.cpp,.Build.cs}` module — the same physical
   shape `NexusFramework_V4` uses (confirmed by reading `NexusFramework_V4`'s own
   `Source/` tree as a precedent), not a redistributable `.uplugin`. "V6 is an Editor-Only
   plugin" in the specs describes the *architectural role* of the `NexusFrameworkEditor`
   module (editor-only code, per `04-v6-architecture.md`'s module-boundaries section), not
   the physical packaging — V6 ships as a game project's own Source modules, same as V4.
3. **Reconciled by deleting the bare-`.uplugin` attempt** (`NexusFramework.uplugin`,
   `Source/NexusFramework/Public/NexusFrameworkModule.h`,
   `Source/NexusFramework/Private/NexusFrameworkModule.cpp` — all files I'd created this
   session, so safe to remove) and instead registering `NexusFrameworkEditor` as a
   **second module** in the wizard's own `NexusFramework.uproject` (`Modules` array,
   `Type: Editor`, `TargetAllowList: ["Editor"]`) and in
   `Source/NexusFrameworkEditor.Target.cs`'s `ExtraModuleNames`. Left the wizard's own
   `Source/NexusFramework/{NexusFramework.h,.cpp,.Build.cs}` untouched — reorganizing
   wizard boilerplate into a `Public`/`Private` split wasn't part of this task.
4. **Module placement for the Representation structs**: `04-v6-architecture.md`'s module
   boundaries section explicitly lists "Representation" (the State/City/Highway/
   HighwayPoint graph) under `NexusFrameworkEditor` ("editor-only"), and "Runtime Schema
   structs only" under `NexusFramework` ("runtime-safe"). Phase 01's own struct set is the
   Representation layer, not the (not-yet-designed, Phase 10+) Runtime Schema — so all
   four structs and the inheritance resolver live in the new `NexusFrameworkEditor`
   module, not `NexusFramework`.
5. **Scope boundary — deliberately excluded from this phase's structs**: relationship/
   membership fields (which City a Highway belongs to, which Highways a HighwayPoint
   connects to, `StartCityId`/`EndCityId`-style InterCityHighway ownership) and
   `ActivationPoint`. These are explicitly later phases' scope — Phase 10
   ("Landscape Entity → HighwayPointId"), Phase 11 ("Highway Membership"), Phase 12
   ("City/State Membership") under "Nexus Mapping", and Phase 21
   ("Representation — ActivationPoint Base Struct"). Phase 01's own Allowed list is
   scoped to "identity fields (IDs, Code, Name)" only, which the four structs now match
   literally — no `TArray<FGuid>` child/parent relationship fields were added, avoiding a
   guess at Phase 11/12's eventual field shape (V4/V5 used both a plural
   `ConnectedHighwayIds` pattern *and* a dual `StartCityId`/`EndCityId` pattern for
   different structs; picking either now for V6 would have been presumptive).
6. **`NexusFrameworkEditor.Build.cs` deliberately stays `Core`/`CoreUObject`/`Engine`/
   `NexusFramework` only** — no `UnrealEd`/`Slate` yet. `phase-02-editor-tool.md`'s
   Allowed list explicitly owns "Create the plugin descriptor... module split with
   correct Build.cs dependencies" and adding the UEdMode/Toolkit; Phase 01 only needed
   enough of a module to make its own structs actually compile.
7. Confirmed via `03-v5-problems-and-lessons.md` that the cross-map stale-`SourcePoint`
   bug (`IsControlPointOnTargetLandscape`) is exactly the hazard Phase 01's carried-
   forward design constraint refers to — irrelevant to this phase's actual diff since
   none of these structs hold any soft/cached external reference at all (by design,
   see Changes below).

## Changes

New files (all under the pre-existing `NexusFramework.uproject`'s `Source/` tree):

- `NexusFramework.uproject` — added the `NexusFrameworkEditor` module entry.
- `Source/NexusFrameworkEditor.Target.cs` — added `NexusFrameworkEditor` to
  `ExtraModuleNames`.
- `Source/NexusFrameworkEditor/NexusFrameworkEditor.Build.cs`,
  `Public/NexusFrameworkEditorModule.h`, `Private/NexusFrameworkEditorModule.cpp` — new
  module, `IModuleInterface` boilerplate only.
- `Source/NexusFrameworkEditor/Public/Representation/NexusState.h`, `NexusCity.h`,
  `NexusHighway.h`, `NexusHighwayPoint.h` — `USTRUCT(BlueprintType)`, each with exactly
  `Id` (`FGuid`), `Code` (`FName`, defaults `NAME_None`), `Name` (`FString`). No geometry,
  no relationship fields (see Findings #5). `FNexusHighwayPoint` explicitly documents why
  it carries no Location/Rotation/Tangent.
- `Source/NexusFrameworkEditor/Public/Inheritance/NexusInheritanceResolver.h`,
  `Private/Inheritance/NexusInheritanceResolver.cpp` —
  `NexusInheritance::ResolveInheritedValue(TConstArrayView<float>)`: walks a
  most-specific-first chain, returns the first value `!= -1`; an all-inherit chain falls
  through to `0`. Generic/reusable — no named inheritable field was added to any struct
  yet (none are in scope this phase; see Findings #5), so it's unit-tested standalone
  against synthetic Point→Highway→City→State→Global chains.
- `Source/NexusFrameworkEditor/Private/Tests/NexusInheritanceResolverTests.cpp` — 6 cases
  covering all-inherit, point override, mid-chain override, and critically the `0` =
  disabled case both mid-chain and at the point level (must win, not be treated as
  "empty").
- `Source/NexusFrameworkEditor/Private/Tests/NexusIdentityUniquenessTests.cpp` —
  generates 256 `FGuid::NewGuid()` ids per struct type and asserts no collisions, plus
  confirms `Code` defaults to `NAME_None`.

Deleted (created earlier this same session, before Finding #2 surfaced — never part of
any prior commit): `NexusFramework.uplugin`,
`Source/NexusFramework/Public/NexusFrameworkModule.h`,
`Source/NexusFramework/Private/NexusFrameworkModule.cpp`.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development -Project=NexusFramework.uproject` →
  **Result: Succeeded** (both `UnrealEditor-NexusFramework.dll` and
  `UnrealEditor-NexusFrameworkEditor.dll` compiled and linked; UE 5.8.0, MSVC 14.44
  toolchain).
- `UnrealEditor-Cmd.exe NexusFramework.uproject -ExecCmds="Automation RunTests
  NexusFramework.Editor;Quit" -unattended -nullrhi` → both tests actually executed
  headlessly and passed:
  `NexusFramework.Editor.Identity.IdUniqueness` — `Result={Success}`;
  `NexusFramework.Editor.Inheritance.ResolveInheritedValue` — `Result={Success}`
  (`Saved/Logs/NexusFramework.log`).
- Manually grepped the new `Representation`/`Inheritance` headers for
  `Landscape`/`Slate`/`UnrealEd` — zero matches outside doc comments.

## Result

Phase 01 complete; all three Completion Criteria checked off in
`phases/phase-01-core-structures.md`, Status set to `Ready for Review — 2026-08-09`.

## Important Notes

- **V6's physical repo layout is a standalone Game project (`NexusFramework.uproject`),
  not a distributable `.uplugin`** — matches V4's precedent. Future phases/agents: don't
  reintroduce a `.uplugin` at root.
- `Source/NexusFramework/{NexusFramework.h,.cpp,.Build.cs}` are still the Unreal wizard's
  untouched defaults (`EnhancedInput`/`InputCore` deps, `IMPLEMENT_PRIMARY_GAME_MODULE`).
  Nothing V6-specific lives there yet — Phase 10+ (Runtime Schema) is expected to be the
  first phase that actually adds content to the `NexusFramework` runtime module.
- Relationship/membership fields and `FNexusActivationPoint` are intentionally **not**
  on these structs yet (Findings #5) — Phases 10–12 and 21 add them. Don't assume the
  structs are "done" in their current four-field shape when those phases start.

## Correction — 2026-08-09 (identity default-naming convention added)

User review feedback on the shipped structs, given directly (not through `/TODO`):
`Id` must never be user-editable (already true — `VisibleAnywhere`, not `EditAnywhere`,
confirmed correct, no code change needed there), but `Code`/`Name` should get a real
auto-generated default instead of blank/`NAME_None`, following a
`"<TYPE>_<Index%02d>"` / `"<Type> <Index>"` pattern (matching V4/V5's own
`"CITY_01"`/`"HWY_01"`-style Code convention).

Added a `static MakeDefault(int32 Index)` factory to all four structs
(`FNexusState`/`FNexusCity`/`FNexusHighway`/`FNexusHighwayPoint`) producing
`Code = "STATE_01"`/`"CITY_01"`/`"HWY_01"`/`"PT_01"`-style and
`Name = "State 1"`/`"City 1"`/`"Highway 1"`/`"Highway Point 1"`-style defaults for
`Index = 1`. The factory takes `Index` as a parameter and does not track a counter
itself — deliberately, since deciding what "next index" means (global vs.
per-parent-scope) and where it persists belongs to whichever phase actually creates
instances (Nexus Mapping, Phases 10–14), not to Phase 01's plain identity structs.
Documented as the project's "global default-naming convention" in
`05-v6-data-flow.md`'s Identity rules section, since it applies to every identity type,
not just one struct.

New test: `NexusDefaultNamingTests.cpp` (`NexusFramework.Editor.Identity.DefaultNaming`)
— verifies the exact Code/Name pattern per type, and that two `MakeDefault()` calls with
the same `Index` still produce distinct `Id`s (Code/Name are index-derived and may
collide if the caller reuses an index; `Id` must never collide regardless).

Verified with a real rebuild (`Result: Succeeded`) and a real headless automation run —
all 3 tests (`IdUniqueness`, `ResolveInheritedValue`, `DefaultNaming`) `Result: Success`.

