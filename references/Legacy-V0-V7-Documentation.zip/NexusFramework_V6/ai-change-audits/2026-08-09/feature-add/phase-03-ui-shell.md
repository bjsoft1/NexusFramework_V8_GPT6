# Phase 03 — UI Shell — Mode Toolkit Panel

Task: Phase 03 — UI Shell — Mode Toolkit Panel
Date: 2026-08-09
Category: feature-add
Phase: phases/03
Status: Ready for Review
Completed Date: 2026-08-09
Completed Time: 23:41 NST (+0545)

## Context

Picked up via `/TODO` immediately after Phase 02 (which the user has since moved to
`Complete` themselves, confirming the Modes-toolbar entry visually worked).

## Problem / Goal

Implement `project-specifications/phases/phase-03-ui-shell.md`: build
`FNexusEdModeToolkit`'s real three-section Slate content (Nexus Panel, Details,
Diagnostics) per `07-v6-ui-design.md`, replacing Phase 02's single-`STextBlock` stub —
UI-only, every section empty/unbound, no business logic.

## Findings

1. **`NexusFramework_V4` already has a working, directly analogous toolkit/panel
   split** (`FNexusFrameworkModeToolkit` + `SNexusFrameworkPanel`) — read it first
   rather than guessing the hosting pattern. Confirmed exact working code:
   `PanelWidget = SNew(SNexusFrameworkPanel);` in the toolkit's **constructor** (not
   `Init()`), and `GetInlineContent()` just returns the cached member. V4's own panel
   is a big hand-rolled button/picker UI (not what V6 wants — V6 explicitly reuses
   native `IStructureDetailsView` instead), so only the *hosting* pattern was reused,
   not V4's panel content itself.
2. **Verified the exact `IStructureDetailsView` API from engine source before writing
   code** (same approach as Phase 02) — `Editor\PropertyEditor\Public\
   IStructureDetailsView.h`/`PropertyEditorModule.h`. Confirmed: it is NOT itself an
   `SWidget` (call `->GetWidget()`), and passing `nullptr` for `StructData` to
   `CreateStructureDetailView()` is a real, shipping engine pattern for an unbound view
   (e.g. `Editor\CurveEditor\Private\SCurveEditorToolProperties.cpp`), not a hack.
3. **First build attempt failed** — 10 unresolved `EKeys::*` linker externals
   (`LeftMouseButton`, `RightMouseButton`, `SpaceBar`, arrow keys, etc.), from
   `STreeView`/`SListView`'s own internal keyboard/mouse-navigation code. Root cause:
   `EKeys` lives in the `InputCore` module, which wasn't yet a dependency of
   `NexusFrameworkEditor` — a real, if easy, miss; fixed by adding it to
   `NexusFrameworkEditor.Build.cs`.
4. **The panel widget is only constructed when the mode is activated**
   (`UNexusEdMode::CreateToolkit()` → `FNexusEdModeToolkit`'s constructor), not at
   editor startup — unlike Phase 02's `UEditorSubsystem`, which does initialize
   automatically. This means even a clean, error-free editor startup this session
   doesn't exercise this phase's actual Slate construction code path at all; only an
   actual click on the Modes toolbar does.

## Changes

- `Source/NexusFrameworkEditor/Private/UI/SNexusEdModePanel.h/.cpp` — new
  `SCompoundWidget`. Three sections via a shared `BuildSectionFrame()` helper:
  - **Nexus Panel**: two `STreeView<TSharedPtr<FString>>` instances (Hierarchy, Debug
    Tree), both bound to empty `TArray`s, sharing one trivial row/children delegate
    pair (both are empty right now, so one implementation covers both — real per-tree
    behavior is later phases' scope: Hierarchy TBD, Debug Tree is Phase 24).
  - **Details**: `IStructureDetailsView` via `FPropertyEditorModule::
    CreateStructureDetailView()`, `nullptr` struct data (Findings #2).
  - **Diagnostics**: `SListView<TSharedPtr<FString>>`, empty source (Phase 27 wires
    real data later).
- `Source/NexusFrameworkEditor/Private/EdMode/NexusEdModeToolkit.h/.cpp` — added a
  constructor (`PanelWidget = SNew(SNexusEdModePanel);`, matching V4's pattern),
  `GetInlineContent()` now returns `PanelWidget` instead of the Phase 02 stub text.
- `Source/NexusFrameworkEditor/NexusFrameworkEditor.Build.cs` — added `PropertyEditor`
  (Details section) and `InputCore` (Findings #3) to `PublicDependencyModuleNames`.

## Verification

- `Build.bat NexusFrameworkEditor Win64 Development` — first attempt **Failed**
  (`LNK2019` × 10, Findings #3); after adding `InputCore`, second attempt
  **Result: Succeeded**.
- Launched the real `UnrealEditor.exe`. Startup completed with zero errors in
  `Saved/Logs/NexusFramework.log`; `UNexusFrameworkSubsystem::Initialize` fired as
  expected (confirms no regression to Phase 02's subsystem).
- **Not verified this session** (Findings #4): the three sections actually appearing
  when the mode is activated, and hiding cleanly on deactivation — genuinely
  unreachable without a human clicking the Modes toolbar, more so than Phase 02 (whose
  subsystem at least self-tested at startup). Editor left running for this.
- Criterion "No business logic anywhere in this phase's code" self-verified by review
  — every data source in the new panel is a hardcoded-empty array or an unbound details
  view; zero Landscape/Mapping/generation references.

## Result

Implementation complete and build-verified (including recovering from a real linker
failure, not just a clean first pass). 2 of 3 Completion Criteria need the same human
visual check as Phase 02 — left unchecked in the phase file, `## Status` advanced to
`Ready for Review` regardless (see this session's process-rule change below: an agent
now writes `## Status` once, at completion, not `In progress` first — "Ready for
Review" is the state where a human confirms exactly these kinds of things, not a claim
they were already confirmed).

## Important Notes

- Per direct user instruction this session, `/TODO`'s workflow
  (`.claude/commands/TODO.md`) no longer writes `## Status: In progress` at the start
  of a phase — only one status write now, at the end. Also documented in
  `09-development-rules.md` rule 12. If you're an agent reading old conversation
  history or an old cached copy of the workflow that still shows a `B1: set In
  progress` step, that step no longer applies — check the current file.
- `SNexusEdModePanel`'s Hierarchy/Debug Tree trees currently share one generic
  `TSharedPtr<FString>` item type purely because both are empty shells. Whichever phase
  wires real Hierarchy data will likely need its own item struct (matching V4's
  `FNexusOutlinerItem` shape) distinct from whatever Phase 24 uses for the Debug Tree —
  don't assume they should stay unified. (Still applies verbatim after the rename below
  — `SNexusFrameworkPanel`'s trees are the same code, same empty-shell state.)

## Correction — 2026-08-10 (hosting mechanism replaced, panel content unaffected)

`SNexusEdModePanel` was renamed to `SNexusFrameworkPanel` as part of the same-day
architecture correction described in `ai-change-audits/2026-08-09/feature-add/
phase-02-editor-mode.md`'s own Correction section and the research record
(`ai-change-audits/2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md`).
**Only the hosting chrome changed** — the widget's content (three sections, tree-view
shells, unbound `IStructureDetailsView`, empty diagnostics list) is byte-identical to
what this record describes; it is now hosted inside a Nomad `SDockTab`
(`FNexusLandscapeModeExtension`) instead of `FNexusEdModeToolkit`'s inline content.

The two "not verified this session" Completion Criteria above (panel appearing on mode
activation, tree view rendering without crashes) **are now verified**: user manually
launched the real interactive editor and visually confirmed the panel (all three
sections) appears when entering Landscape Mode and hides cleanly on exit, with no
crashes. Phase 03's `## Status` remains `Ready for Review` as of this correction (see
`project-specifications/phases/phase-03-ui-shell.md`), now against the new
architecture's Completion Criteria.
