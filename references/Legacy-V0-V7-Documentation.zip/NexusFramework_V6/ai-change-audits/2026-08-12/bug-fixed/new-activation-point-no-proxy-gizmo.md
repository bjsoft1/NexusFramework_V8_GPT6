# New Activation Point never gets an Editor Proxy Actor (create-time proxy pool staleness)
Date: 2026-08-12
Category: bug-fixed
Phase: N/A (ad-hoc, `agent-todos/ready-for-review/new-activation-point-no-proxy-gizmo.md`)

## Context

Direct user report during this session, after the multi-pass `still-not-fix.md`
investigation into proxy gizmo interactivity after Re-sync: a genuinely NEW symptom -
creating a brand new Activation Point never gives it an Editor Proxy Actor at all, and
neither switching editor mode nor moving the camera near/far makes one appear.

## Problem / Goal

User's own words: "the new created interactive point does not have gizmo actor in editor
after create. not possible to move it. switching mode, comes far, near stil not [working]."

## Findings

- `FNexusEditorProxyPool::RebuildSpatialIndex` - the only function that populates the
  Editor Proxy Actor pool's spatial index (`IndexedActivationPointIds`/etc., what
  `TickUpdateNearbyProxies` binds against) - is only ever called from
  `UNexusFrameworkSubsystem::RefreshRepresentationIfDue`, and only on that function's REAL
  rebuild path: gated on `bRepresentationDirty` (set by `MarkRepresentationDirty()`) OR its
  own idle-poll Landscape-geometry-fingerprint check noticing a change. The fingerprint
  check is about Landscape spline geometry only - completely blind to `ActivationPoints`
  array mutations.
- `SNexusHierarchyPanel::HandleCreateActivationPoint`/`HandleDeleteActivationPoint` never
  call `MarkRepresentationDirty()` - confirmed missing both before this fix (grep, current
  codebase) and independently already noted as a side-finding in the prior
  `2026-08-11/bug-fixed/activation-point-debug-on-freeze-investigation.md` record ("`MarkRepresentationDirty()`
  - confirmed NOT called anywhere in `HandleCreateActivationPoint`/`HandleDeleteActivationPoint`").
- Traced WHY this omission was originally made: `HandleCreateState`'s own comment (the
  precedent immediately above `HandleCreateActivationPoint` in the same file) states it was
  "Deliberately NOT called from the ActivationPoint handlers" - correct reasoning FOR THE
  DEBUG PDI WIREFRAME RENDERER (`RenderActivationPoints`, `NexusDebugRuntimeGroupRenderers.cpp`),
  which re-reads `ActiveConfig->ActivationPoints` LIVE every frame regardless of any dirty
  flag, so a new point's wireframe marker was genuinely never missing. But the Editor Proxy
  Actor pool (Phase 48, added 2026-08-11 - AFTER this reasoning was written) works
  completely differently: it is index-based, not a live per-frame read, and depends
  entirely on the same `RefreshRepresentationIfDue` dirty/poll gate `RenderSnapshot` uses.
  The original reasoning was correct for the system that existed when it was written, and
  was never revisited when the proxy pool's own, different data-freshness contract was
  added later - a real, confirmed gap, not a guess.
- This means a newly created Activation Point could go unindexed by the proxy pool
  indefinitely - not "eventually catches up," genuinely never - until an UNRELATED action
  happened to also mark the representation dirty (creating a State/City/Highway, or a full
  Re-sync). Camera movement and mode switching never touch this path, exactly matching the
  reported symptom.

## Changes

- `Private/UI/SNexusHierarchyPanel.cpp` - `HandleCreateActivationPoint` and
  `HandleDeleteActivationPoint` each now call `subsystem->MarkRepresentationDirty()`
  right after their own transaction - the identical one-line pattern `HandleCreateState`
  already pays for every State/City/Highway create, applied here for the first time to the
  ActivationPoint handlers specifically because they were the ones missing it.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` - succeeded,
  zero errors/warnings.
- **Not verified in-editor** (Agent Testing Policy, no editor launch) - manual test
  sequence documented in the agent-todos task file's own Important Notes.

## Result

A real, confirmed (not guessed) gap between two data-freshness contracts that were correct
independently but drifted apart once the Editor Proxy Actor pool was added on top of an
older, Debug-renderer-only assumption. Fixed with the smallest possible change (two
one-line calls, matching an already-established pattern in the same file) - no new
architecture, no change to the dirty/poll mechanism itself.

## Important Notes

- Does not reintroduce or risk the separate, still-open 2026-08-11 "Debug ON creation
  freeze" investigation (`activation-point-debug-on-freeze-investigation.md`) - that
  investigation traced `HandleCreateActivationPoint`'s entire call path and found zero
  Debug-conditional cost in it; the new call only sets a bool flag synchronously, and the
  rebuild it triggers runs on the NEXT Tick, the same cost/timing shape `HandleCreateState`
  already has unreported as a freeze source. Not fixed/assumed innocent for that
  investigation either - just not blindly ruled out.
- Distinct from the `still-not-fix.md` thread (six passes, still open as of this session) -
  that thread is about proxy binding/gizmo-widget behavior for points that DO get indexed;
  this bug is about points that never get indexed at all after creation. Kept as a
  separate task/record rather than folded into that thread.
