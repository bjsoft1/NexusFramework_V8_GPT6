# Duplicate `ComputeRightVector` Anonymous-Namespace Helper — Unity Build Collision

Date: 2026-08-12
Category: bug-fixed
Phase: N/A (ad-hoc, caught by the user's own build)

## Context

User opened `Saved/Logs/NexusFramework.log` and reported a build error from their own
build (compiling with real unity-build merging, not this agent's adaptive-unity test
builds): `error C2084: function 'FVector 'anonymous-namespace'::ComputeRightVector(const
FVector &)' already has a body`, pointing at both `NexusDebugRoadsGroupRenderers.cpp`
(Phase 31, pre-existing) and `NexusDebugInfrastructureGroupRenderers.cpp` (this session's
own Phase 53 work).

## Problem / Goal

Fix the duplicate-symbol compile error without reverting either file's actual
functionality.

## Findings

- Root cause: Phase 53 (this session, same date) added a SECOND file-local anonymous-
  namespace function named `ComputeRightVector` with an IDENTICAL body to
  `NexusDebugRoadsGroupRenderers.cpp`'s own pre-existing one - explicitly duplicated
  rather than shared, per that file's own comment at the time ("duplicated locally... a
  2-line helper with no shared header... rather than exporting a new cross-file
  dependency for one function").
- This is harmless under this agent's own test builds (`Build.bat` without extra flags)
  because Unreal's ADAPTIVE unity build excludes recently-git-changed files from the
  merged translation unit, compiling each individually - anonymous namespaces have
  internal linkage PER TRANSLATION UNIT, so two separate .cpp files each defining their
  own `ComputeRightVector` never actually collide when compiled as separate TUs. This
  agent's every build this session showed exactly that exclusion in its own output
  ("[Adaptive Build] Excluded from NexusFrameworkEditor unity file: ..."), which is why
  this was never caught before the user's own build surfaced it.
- Confirmed the exact reproduction: `Build.bat NexusFrameworkEditor Win64 Development
  -DisableAdaptiveUnity` forces every file into the shared `Module.NexusFrameworkEditor.cpp`
  unity blob - this genuinely reproduced a real unity-style build for the first time this
  session, and (before the fix) would have hit the identical C2084 the user reported.

## Changes

- `Public/Debug/NexusDebugPrimitives.h` / `Private/Debug/NexusDebugPrimitives.cpp` - new
  shared `static FVector ComputeRightVectorFromTangent(const FVector& tangentDirection)`,
  placed alongside the existing math-only `SampleHermiteCurve` (same "math only, no
  drawing/Config" pattern).
- `Private/Debug/NexusDebugRoadsGroupRenderers.cpp` - removed its own local
  `ComputeRightVector`; both call sites now use
  `FNexusDebugPrimitives::ComputeRightVectorFromTangent`.
- `Private/Debug/NexusDebugInfrastructureGroupRenderers.cpp` - same removal/redirect for
  its one call site.
- Checked for other potential duplicate-name collisions across every file touched this
  session (`grep` for repeated anonymous-namespace function names across
  `Private/Debug/*.cpp`, `Private/Representation/*.cpp`, `Private/Proxy/*.cpp`,
  `Private/Gizmo/*.cpp`) - none found beyond this one.

## Verification

- Build (normal, adaptive-unity): `Build.bat NexusFrameworkEditor Win64 Development` -
  succeeded, zero warnings/errors.
- **Build (forced unity, `-DisableAdaptiveUnity`)**: succeeded, zero warnings/errors -
  this is the first time this session a build actually exercised the same
  translation-unit-merging the user's own build does, and it now passes clean. This is
  real evidence the specific reported error is resolved, not just an assumption based on
  the source diff.

## Result

Fixed and verified against the actual failure mode (unity-build symbol merging), not
just a normal incremental build. The shared helper now has exactly one definition,
consumed by both renderer files.

## Important Notes

- **Standing lesson for this session's own future work**: this agent's own build
  verification (`Build.bat` with no extra flags) uses adaptive unity, which can silently
  hide a duplicate-anonymous-namespace-symbol bug that a real/full/unity build (or the
  user's own IDE build, or a clean CI build) will catch. When adding a small, generically-
  named helper function to a NEW file in a directory with existing similar renderer
  files (`Private/Debug/`, `Private/Representation/`, etc.), grep for the same function
  name across sibling files first, or add it to a shared header/class from the start
  (as this fix now does) rather than "duplicate it locally, it's just two lines."
- Worth occasionally forcing `-DisableAdaptiveUnity` on a build in this project going
  forward, specifically after adding a new file with anonymous-namespace helpers, to
  catch this class of bug before the user's own build does.
