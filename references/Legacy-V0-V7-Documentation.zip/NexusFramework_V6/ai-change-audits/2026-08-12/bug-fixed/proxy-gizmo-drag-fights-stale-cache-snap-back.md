# Editor Proxy Actor gizmo drag fights itself and snaps back after drop

Date: 2026-08-12
Category: bug-fixed
Phase: N/A (ad-hoc, `agent-todos/ready-for-review/proxy-gizmo-drag-fights-and-snaps-back.md`)

## Context

Direct user report during this session, after the earlier `still-not-fix.md` fix made
Editor Proxy Actor dragging reachable at all (Re-sync now correctly initializes proxy
interactivity without a Landscape Mode cycle). This is a *different*, newly-visible bug
in the drag behavior itself, not a continuation of that fix.

## Problem / Goal

User's own words: "when editor load the proxy `Nexus: Activation Point` which used to
drag our points as gizmo has bug, when i draw it showing lags, like 2 people try to move
same object, when i try to move next place, it proxy actor try to auto come back
previous place."

## Findings

- Read `FNexusEditorProxyPool::TickUpdateNearbyProxies`, `BindSlot`, `NotifyProxyMoved`,
  and `ANexusEditorProxyActor::PostEditMove` in full before forming a hypothesis, per
  this project's own "re-verify the premise against the current codebase" rule.
- `TickUpdateNearbyProxies` runs on a throttled cadence (~0.2s / >50cm camera movement)
  and its own "refresh already-bound proxies" pass calls `BindSlot` — which
  unconditionally calls `SetActorTransform` — for every proxy in `desiredIds`, WITH NO
  EXCEPTION for the currently pinned/selected one. A drag target is always pinned (native
  gizmo manipulation requires UE Actor selection, and selection sets
  `PinnedActivationPointId` via `HandleSelectionChanged`), so the proxy the user is
  actively dragging gets its transform forcibly overwritten by this refresh pass on every
  throttled tick.
- The transform pushed comes from `IndexedWorldTransforms`, populated by
  `RebuildSpatialIndex` — which the class's own header comment already documents as
  running "on the SAME dirty/throttle cadence... never per-frame, never a second
  independent poll", i.e. NOT live during a drag. So every refresh tick during a drag
  re-asserts the LAST-CACHED (pre-drag) position over the user's live drag delta — the
  "like 2 people try to move same object" lag, a genuine fight between the user's mouse
  input and the pool's own periodic push.
- After the user releases the mouse, `NotifyProxyMoved` had already written the final
  offset into `UNexusConfigAsset::ActivationPoints` — but never updated the
  `IndexedWorldTransforms` cache entry to match. The very next `TickUpdateNearbyProxies`
  tick (which can fire within a fraction of a second of the drop, e.g. on the next small
  camera movement) therefore re-pushes the STILL-stale pre-drag cached transform,
  visually snapping the just-dropped object back to its starting position — the "auto
  come back to previous place" half of the report. Both symptom halves trace to the same
  single root cause (a periodic push using a cache that isn't updated live).

## Changes

- `Public/Proxy/NexusEditorProxyActor.h` — new `bool IsMidDrag` member, documented.
- `Private/Proxy/NexusEditorProxyActor.cpp` — `PostEditMove` sets `IsMidDrag = !isFinished`
  for every real (non-programmatic) callback, before calling into the pool's write-back.
- `Private/Proxy/NexusEditorProxyPool.cpp`:
  - `TickUpdateNearbyProxies`'s refresh loop now skips the `BindSlot` call (and therefore
    the `SetActorTransform` push) for any already-bound slot whose proxy is currently
    `IsMidDrag` — a freshly-acquired slot is never mid-drag, so this only ever skips a
    refresh, never an initial bind.
  - `NotifyProxyMoved` now patches `IndexedWorldTransforms[indexedPos]` in place
    (targeted single-element update via `IndexOfByKey`, not a full `RebuildSpatialIndex`
    rescan) to the proxy's own just-committed live transform, on every callback — so the
    cache is never stale even momentarily after a write-back.
  - `BindSlot`/`UnbindSlot` both reset `IsMidDrag = false` defensively, so a prior
    incomplete drag (e.g. eviction mid-drag, an edge case) can never leave a proxy
    permanently stuck skipping refreshes after a rebind.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): the actual drag-feel and
  snap-back-after-drop fix — documented in the agent-todos task's own "Manual
  verification needed" section (5-step sequence, including camera-movement-after-drop and
  rotation coverage).

## Result

Both halves of the reported regression trace to one root cause (a periodic proxy-refresh
pass with no drag-awareness, reading a cache that isn't kept live) and are fixed by two
small, additive, low-risk changes — no architecture change, no new poll/tick added, and
the "never a second independent poll" performance contract `RebuildSpatialIndex` already
documents is preserved (the cache patch is a single-element update, not a rescan).

## Important Notes

- Deliberately did NOT add the same `IsMidDrag` guard to `HandlePostEditUndo`'s own
  unconditional per-proxy `SetActorTransform` loop — a real drag holds exclusive mouse
  input focus, so Ctrl+Z/Ctrl+Y cannot realistically fire mid-drag; guarding that path
  too would be speculative code for a scenario that cannot occur.
- If the user's re-test still shows any residual snap/lag, the next place to look is
  whether `TickUpdateNearbyProxies`'s OUTER throttle (`LastNearbyUpdateSeconds`/
  `LastCameraLocationForUpdate`) itself ever fires fast enough to slip in BETWEEN two
  `PostEditMove(false)` calls of the same drag in a way `IsMidDrag` wouldn't catch (it
  shouldn't — `IsMidDrag` is set synchronously on the game thread before any other work
  runs — but this is unconfirmed without a live repro).
