# Phase 53 — Traffic Light — Debug Visualization

Date: 2026-08-12
Category: feature-add
Phase: 53

## Context

Picked up via `/TODO` immediately after Phase 52 (same session) — the first of the
UI-flavored phases (53/54/57/58/62/67) the user specifically asked to prioritize, now
unblocked since its data-model prerequisites (Phase 50 sub-offsets, Phase 51
ControlledLaneIds, Phase 52 SignalGroup) all landed this session.

## Problem / Goal

Register Traffic Light-specific debug leaves ("Traffic Light", "Traffic-Light LED") under
the Infrastructure group, rendering Pole/VehicleLED/PedestrianLED as visually distinct
markers and ControlledLaneIds as connecting lines to the referenced lanes.

## Findings

- **The double-rendering question, worked out before writing any code**: Traffic Light
  points already render generically via `RenderActivationPoints`
  (`NexusDebugRuntimeGroupRenderers.cpp`, registered under the shared
  `Runtime.ActivationPoints` category every Activation Point type uses) — so adding a
  SECOND, type-specific renderer risked drawing the same 3 sub-points twice when both
  categories are visible. Considered redirecting `GRegisterTrafficLight`'s own
  `DefaultDebugCategory` away from `Runtime.ActivationPoints` and teaching the generic
  renderer to skip already-dedicated types, but found direct precedent AGAINST that:
  `NexusDebugRoadsGroupRenderers.cpp`'s own `RenderJunctions` comment already establishes
  that `Roads.Junctions` and `Landscape.Connections` intentionally draw overlapping
  content at the same points — "the two are independently visible/invisible debug
  categories a user may want on separately, not a shared subsystem." Followed that exact
  precedent instead: left `GRegisterTrafficLight`/`RenderActivationPoints` completely
  untouched, and treated the two new Infrastructure leaves as an ADDITIONAL, richer,
  type-aware view. Simpler, safer (zero risk to already-reviewed Phase 50-52 files), and
  consistent with an existing, already-accepted design decision rather than inventing a
  new one under time pressure.
- **Locating a "controlled lane" in world space required a new lookup, since the cached
  Debug snapshot doesn't carry it**: `FNexusDebugSnapshotHighway` (the one struct
  Representation-stage Debug rendering is allowed to read every frame,
  `NexusDebugRenderSnapshot.h`) caches only resolved SCALAR fields (`ResolvedLaneWidth`/
  `ResolvedLaneCount`/etc.), never the raw `TArray<FNexusLane>` with each lane's own
  `LaneId`/`Side`/`IndexFromCenter`. Confirmed this by reading the struct in full before
  assuming a shortcut existed. Resolved by reading `UNexusConfigAsset::Highways` directly
  inside the renderer (a plain, already-in-memory `TArray` — not a Landscape/spline
  query) to find the owning Highway and lane, then combining that with the SNAPSHOT's own
  cached `ResolvedLaneWidth` for the actual position math — confirmed this doesn't violate
  "no live Landscape geometry per frame" by finding the EXACT SAME pattern already in
  production: `RenderActivationPoints`'s own real-`ActivationPoints` loop already reads
  `subsystem->GetActiveConfig()->ActivationPoints` fresh every frame, so reading
  `config->Highways` the same way is not a new category of renderer behavior, just a new
  instance of an already-accepted one.
- Reused `NexusDebugRoadsGroupRenderers.cpp`'s own `ComputeRightVector` lateral-offset
  formula (duplicated locally — a 2-line helper with no shared header, not worth a new
  cross-file export for) rather than inventing a different lane-position formula, so a
  Traffic Light's controlled-lane connecting line lands at the same "lane center" position
  the Roads group's own lane-boundary lines are built from the same math against.

## Changes

- New file `Private/Debug/NexusDebugInfrastructureGroupRenderers.cpp` — registers
  `Infrastructure.TrafficLight` (Pole marker + grounding line + `ControlledLaneIds`
  connecting lines) and `Infrastructure.TrafficLightLED` (VehicleLED=red,
  PedestrianLED=amber, fixed per-LED colors so the two are distinguishable from each
  other, not just from Pole). `ResolveControlledLaneLocation` (same file) does the
  lane-lookup + lateral-offset math described above; returns false (draws nothing) for a
  dangling/unresolvable reference rather than guessing.
- No changes to any Phase 45-52 file — `GRegisterTrafficLight`'s `DefaultDebugCategory`
  and `RenderActivationPoints` are both untouched, per the Findings above.
- `project-specifications/phases/phase-53.md` — Implementation + manual-verification
  section appended; both Completion Criteria left unchecked (require in-editor visual
  confirmation); `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): both Completion Criteria are
  inherently visual ("visually distinguishable in the viewport", "connections render
  correctly") — require the in-editor round trip documented in `phase-53.md`'s own
  "Manual verification required" section. Left unchecked in the phase file rather than
  claimed.

## Result

Two new debug leaves implemented and build-verified, reusing the existing generic
Activation Point rendering machinery (sub-point resolver, snapshot, primitives) rather
than a parallel pipeline. The in-editor visual confirmation (marker colors/shapes,
connecting-line correctness, dangling-reference silence) is the one remaining item,
deferred to the user per standing policy.

## Important Notes

- Enabling both `Runtime.ActivationPoints` and the two new Infrastructure leaves at the
  same time will show overlapping markers at the same 3 sub-point positions — this is
  intentional/accepted (see Findings), not a bug to fix in a follow-up.
- This file (`NexusDebugInfrastructureGroupRenderers.cpp`) is meant to be the home for
  every future Infrastructure-group leaf (City Light — Phase 57, Crosswalk — Phase 62,
  Parking — Phase 71, ...), matching `NexusDebugRoadsGroupRenderers.cpp`'s own
  "one file per GROUP, not per TYPE" precedent (5 Roads leaves live together in one
  file) — a future phase should add its own leaf(s) to this same file rather than
  creating a new one per type, unless the file grows unwieldy enough to warrant a split.
