# Phase 70 — Parking — Data Model

Date: 2026-08-12
Category: feature-add
Phase: 70

## Context

Picked up via `/TODO`, eighth phase of the 9-phase batch (61, 62, 64-67, 69-71) the user
selected this session. First Parking phase — starts the final object-type group in this
batch.

## Problem / Goal

Implement Parking as a complete authoring system per `v6-master-architecture.md`
Section 6 — not merely "a point with a mesh," and not V5's narrower
`FNexusStationInfoBase` shape reused verbatim, per this phase's own 2026-08-10 revision.

## Findings

- Read Section 6 directly (`v6-master-architecture.md` lines 230-289) rather than
  trusting the phase file's own paraphrase — confirmed the full field list
  (`Row`/`Column`/`RowGap`/`ColumnGap`/`SpotWidth`/`SpotLength`/`BaseMesh`/
  `ParkingIndicatorMesh`/`OccupiedIndex[]`) and, critically, that `Capacity` must be
  computed (`Row × Column`), never stored — reused the Section 6 doc's own worked
  example (`Row=4, Column=10, Capacity=40, OccupiedIndex=[0,3,7,21]`) as the test
  console command's own seed data, for direct traceability back to the spec.
- Recognized `FNexusParkingActivation` fits the SAME "zero declared
  `FNexusSubPointOffset` fields, base-only-shaped" pattern Phase 69 already established
  for standalone Seat — Row/Column/RowGap/ColumnGap/SpotWidth/SpotLength/BaseMesh/
  ParkingIndicatorMesh/OccupiedIndex are all plain data, none of them a position to
  individually gizmo-drag. Confirmed this satisfies Section 6's own "allow gizmo
  adjustment" requirement via the EXISTING synthetic-base-key mechanism (the grid's
  overall position/rotation is the base ActivationPoint's own offset) with zero new
  resolver code, rather than assuming per-spot authored sub-points were needed.
- Section 6 explicitly requires runtime queries ("is available", "which spot",
  "next available", "its location", "its rotation") that V5's `FNexusParkingInfo` never
  had any equivalent of. Implemented these as real methods
  (`HasAvailableSpot`/`GetFreeSpotIndices`/`FindNextAvailableSpotIndex`/
  `ComputeSpotLocalTransform`/`ComputeSpotWorldTransform`) on the struct itself, with
  `ComputeSpotWorldTransform` following the exact same `Local * Parent = World`
  composition rule `FNexusActivationPoint::ComputeFinalTransform` already uses
  (confirmed by reading that function's own implementation before writing the new one),
  extended one more local level for the specific spot's row/column offset.
- Two design decisions this phase's own text explicitly left open, both documented in
  `NexusParkingActivation.h`'s own header comment rather than made silently: (1)
  `AllowVehicles` folded into the base `Metadata` map rather than given a dedicated
  bitmask field, since V5's `ENexusAllowedVehicles` enum doesn't exist anywhere in V6
  yet and nothing queries it; (2) `RowGap`/`ColumnGap`'s `-1` sentinel resolves to a
  fixed 50cm constant for query-math purposes, explicitly flagged as NOT a real
  State/City/Highway-style inheritance chain (no such chain exists for per-instance
  Parking spacing — building one was judged out of this phase's own scope).

## Changes

- `Public/Representation/NexusParkingActivation.h` (new) — `FNexusParkingActivation`:
  `Row`/`Column`, `RowGap`/`ColumnGap`, `SpotWidth`/`SpotLength`, `BaseMesh`,
  `ParkingIndicatorMesh`, `OccupiedIndex`, `GetCapacity`, and the full query surface.
- `Private/Representation/NexusParkingActivation.cpp` (new) — implements
  `GetFreeSpotIndices`/`FindNextAvailableSpotIndex`/`ComputeSpotLocalTransform`/
  `ComputeSpotWorldTransform`.
- `Private/Representation/NexusParkingActivationRegistration.cpp` (new) — registers
  `FName("Parking")` (`RuntimeActivated`/`Runtime.ActivationPoints`). Adds
  `Nexus.Representation.AddTestParking <HighwayPointId> [Row=4] [Column=10]
  [AlwaysDraw]` and `Nexus.Representation.QueryTestParking <ActivationPointId>`
  (exercises the full query surface against a live-resolved anchor transform).
- `project-specifications/phases/phase-70.md` — three of four Completion Criteria
  checked off (data model, query surface, V5-diff note); the visual/in-editor
  confirmation criterion left unchecked; Implementation Notes + "Manual verification
  required" section appended; `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): the visual grid placement
  and gizmo-drag of the overall anchor — documented in `phase-70.md`'s own "Manual
  verification required" section. The query surface itself IS logically exercised by
  the new `QueryTestParking` command, but running it in-editor to confirm the printed
  numbers match expectations is still a manual step.

## Result

`FNexusParkingActivation` implemented and build-verified as a complete authoring system
per Section 6, including the full runtime query surface V5 never had. Both open design
questions the phase text raised are resolved and documented, not left implicit. The
in-editor visual round-trip proof is the one remaining item, deferred to the user per
standing policy.

## Important Notes

- `AllowVehicles` is NOT a dedicated field on this struct — it lives in the base
  `FNexusActivationPoint::Metadata` map if ever needed. Don't add a redundant bitmask
  field later without checking this note first.
- `RowGap`/`ColumnGap`'s `-1` fallback is a flat 50cm constant, not a real inheritance
  chain — if a future phase wants State/City/Highway-style Parking-spacing inheritance,
  that's new work, not something this phase already built.
- Same open item every specialized payload type has flagged since Phase 46: real
  `UNexusConfigAsset` persistence remains undecided.
- Part of the same 9-phase batch (61, 62, 64-67, 69-71) — Phase 71
  ("Parking — Debug Visualization"), the last phase in this batch, is next.
