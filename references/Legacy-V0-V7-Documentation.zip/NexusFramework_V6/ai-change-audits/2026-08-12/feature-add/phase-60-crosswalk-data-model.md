# Phase 60 — Crosswalk — Data Model

Date: 2026-08-12
Category: feature-add
Phase: 60

## Context

Picked up via `/TODO` immediately after Phase 59 (Blocked, same session), continuing the
sequential run through Phases 54-60a.

## Problem / Goal

Implement `FNexusCrosswalkActivation` per `12-v6-activation-point-system.md`: start/end
points, width, pedestrian waiting points — a struct V5 had no equivalent of at all.

## Findings

- This is the FIRST real (non-dummy) type to need the dynamic-array sub-point shape
  (`PedestrianWaitingPoints[]`) — Traffic Light and City Light both only ever used fixed
  named sub-points. Confirmed the existing generic machinery already fully supports this
  (Phase 45's `EnumerateDeclaredSubPointFields`/`EnumerateSubPointKeysForInstance` already
  handle `TArray<FNexusSubPointOffset>` fields, previously only exercised by the Phase 45
  dummy `Dummy.Array` type) rather than assuming it or building a parallel path — reused
  `AddTestActivationPointArrayConsoleCommand`'s own `FArrayProperty`-resize pattern
  verbatim for the new console command.
- `12-v6-activation-point-system.md`'s own diagram lists `LinkedTrafficLightId` alongside
  `StartPoint`/`EndPoint`/`PedestrianWaitingPoints[]`/`Width` for
  `FNexusCrosswalkActivation` — but `phase-61.md` ("Crosswalk — Traffic-Light Linkage") is
  a separate, later phase for exactly that field. Scoped this phase to the other four
  per its own Allowed/Completion-Criteria list and the "do not jump phases" precedent
  Phase 50 already set for Traffic Light's own deferred fields.
- Checked `10-v6-runtime-schema.md`'s own gap-3 wording directly ("No crosswalk
  representation at all... start/end, width, pedestrian waiting points, or its
  relationship to a controlling traffic light") to write an honest, itemized gap-closure
  confirmation — three of the four named items are closed by this struct, the fourth
  (traffic-light relationship) is explicitly still open pending Phase 61, not silently
  treated as done.
- Test console command places `StartPoint`/`EndPoint` at opposite lateral offsets
  (local Y, perpendicular to the anchor's forward axis) specifically so the visual proof
  matches this phase's own "spans two Highway sides... across a road, not just along it"
  wording, rather than defaulting to some other arbitrary placement.

## Changes

- `Public/Representation/NexusCrosswalkActivation.h` (new) — `FNexusCrosswalkActivation`:
  `StartPoint`/`EndPoint` (fixed), `PedestrianWaitingPoints` (array), `Width` (plain
  float, not a sub-point).
- `Private/Representation/NexusCrosswalkActivationRegistration.cpp` (new) — registers
  `FName("Crosswalk")` (`RuntimeActivated`/`Runtime.ActivationPoints`). Adds
  `Nexus.Representation.AddTestCrosswalk <HighwayPointId> [WaitingPointCount=2]
  [AlwaysDraw]`.
- `project-specifications/phases/phase-60.md` — gap-closure Completion Criterion checked
  off with an itemized written confirmation; the visual "opposite sides" criterion left
  unchecked pending in-editor confirmation; Implementation + manual-verification section
  appended; `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): the visual "start/end on
  opposite sides" + independent array-element gizmo-editing round trip — documented in
  `phase-60.md`'s own "Manual verification required" section.

## Result

Data model + registration implemented and build-verified, proving the array sub-point
mechanism against a real type for the first time. Gap-closure against
`10-v6-runtime-schema.md` explicitly, honestly confirmed (3 of 4 named items; the 4th is
Phase 61's own job). The in-editor visual/gizmo round-trip proof is the one remaining
item, deferred to the user per standing policy.

## Important Notes

- `LinkedTrafficLightId` is NOT on this struct yet — `phase-61.md` adds it as its own
  dedicated phase. Do not assume `FNexusCrosswalkActivation` is "done" for a real
  crosswalk-controlled-by-a-traffic-light scenario until that lands too (same pattern
  Phase 50/51/52's own notes already established for Traffic Light).
- Same open item every specialized payload type has flagged since Phase 46: real
  `UNexusConfigAsset` persistence remains undecided — `FNexusCrosswalkActivation` only
  exists as session-only `FNexusActivationPointTestStore` data today.
