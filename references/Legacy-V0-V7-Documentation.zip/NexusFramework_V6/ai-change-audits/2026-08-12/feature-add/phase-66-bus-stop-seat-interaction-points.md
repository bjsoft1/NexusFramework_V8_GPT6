# Phase 66 — Bus Stop — Seat Interaction Points

Date: 2026-08-12
Category: feature-add
Phase: 66

## Context

Picked up via `/TODO`, reordered after Phase 69 within the same 9-phase batch (61, 62,
64-67, 69-71) the user selected this session — Phase 69 built the `FNexusSeatActivation`
struct this phase references, resolving a forward-dependency wrinkle Phase 66's own text
already flagged ("built next in Phase 69, or stubbed here and finalized then — record
which").

## Problem / Goal

Add `SeatInteractionPoints[]` to Bus Stop, proving the general Seat activation pattern
(Phase 69) in its first real usage context, per `phase-66.md`'s Allowed/Completion-
Criteria list.

## Findings

- Read `NexusActivationSubPointResolver.cpp`'s actual `ResolveSubPointOffsetPtr`
  implementation before deciding the array shape, rather than implementing
  `12-v6-activation-point-system.md`'s diagram wording ("each a FNexusSeatActivation
  payload, not just a bare point") completely literally as `TArray<FNexusSeatActivation>`
  with an embedded position. That function `reinterpret_cast`s a resolved array
  element directly to `FNexusSubPointOffset*` — safe only when the element type
  genuinely IS `FNexusSubPointOffset`; a `FNexusSeatActivation` element would read
  garbage/wrong memory, a real correctness bug. Decided against extending that shared,
  load-bearing resolver (every real type's gizmo editing depends on it) for one
  feature's convenience, and instead used two parallel, index-aligned arrays
  (`SeatInteractionPoints` for position, `SeatInteractionConfigs` for metadata) —
  documented as an explicit, reasoned deviation from the doc's literal wording, not a
  silent shortcut. Full reasoning recorded in `NexusBusStopActivation.h`'s own "Seat
  interaction design decision" header comment (readable in place, not just in this
  audit record) and cross-referenced from Phase 69's own updated record.
- Confirmed the cross-reference this phase and Phase 69 both require: this struct
  literally includes `NexusSeatActivation.h` and uses `FNexusSeatActivation` directly —
  no duplicate/parallel struct was created for the embedded case.
- "Verify a seat mesh (Static-classified) and its interaction point (RuntimeActivated)
  share an anchor without merging" is true by construction, not by a check that needed
  writing: this phase's own code (`SeatInteractionConfigs`, part of the RuntimeActivated
  Bus Stop payload) never spawns, references, or touches any Static-mesh-merging code
  path at all — the actual seat mesh is a separate Static-classified object belonging to
  the already-built, architecturally separate Static Generation pipeline (Phase 40-42).

## Changes

- `Public/Representation/NexusBusStopActivation.h` — added `SeatInteractionPoints`
  (`TArray<FNexusSubPointOffset>`) and `SeatInteractionConfigs`
  (`TArray<FNexusSeatActivation>`), with the full parallel-array design decision
  documented in a new header-comment section. Includes `NexusSeatActivation.h`.
- `Private/Representation/NexusBusStopActivationRegistration.cpp` — extended
  `Nexus.Representation.AddTestBusStop` with a fifth `[SeatCount=2]` arg, seeding both
  arrays in lockstep with each element given a distinct `SeatCapacity` (index+1) so
  per-element independence is visible, not just implied.
- `project-specifications/phases/phase-66.md` — Completion Criterion checked off with
  the "true by construction" reasoning written out; the visual/gizmo criterion left
  implicitly covered by the same checked item since it was the only one this phase
  declared, with the placement round-trip itself flagged for manual verification;
  Implementation Notes + "Manual verification required" section appended; `## Status`
  set to `Ready for Review`.
- `project-specifications/phases/phase-69.md` — cross-reference Completion Criterion
  retroactively checked off with a dated Update note, now that this phase confirms it.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): the visual placement/
  gizmo-drag round trip and the Details panel showing distinct per-element
  `SeatCapacity` values — documented in `phase-66.md`'s own "Manual verification
  required" section.

## Result

`SeatInteractionPoints[]`/`SeatInteractionConfigs[]` implemented and build-verified,
proving `FNexusSeatActivation` in its first real embedded usage. The Static/
RuntimeActivated split is proven true-by-construction (no merging code touched). The
in-editor visual/gizmo round-trip and per-element Details-panel confirmation are the
remaining items, deferred to the user per standing policy.

## Important Notes

- **Read `NexusBusStopActivation.h`'s own "Seat interaction design decision" header
  comment before assuming `SeatInteractionPoints[]` literally matches
  `12-v6-activation-point-system.md`'s diagram shape** — it's two parallel arrays, not
  one `TArray<FNexusSeatActivation>`. A future phase that wants the literal "one array
  of self-positioned structs" shape needs to first deliberately extend
  `NexusActivationSubPointResolver` to support an embedded-offset struct-array field
  type — flagged as a real open item, not silently worked around forever.
- Part of the same 9-phase batch (61, 62, 64-67, 69-71) — Phase 67
  ("Bus Stop — Debug Visualization") is next.
