# Phase 56 — City Light — Data Model

Date: 2026-08-12
Category: feature-add
Phase: 56

## Context

Picked up via `/TODO` immediately after Phase 55 (Blocked, same session), continuing the
sequential run through Phases 54-60a.

## Problem / Goal

Implement `FNexusCityLightActivation` per `12-v6-activation-point-system.md`: a single
`LightSource` sub-offset (the pole itself is a separate Static-classified object, not
part of this struct).

## Findings

- Directly mirrored Traffic Light's (Phase 50) exact file shape and registration pattern
  — same `USTRUCT`/lazy-lambda-`PayloadStructTypeGetter`/`Runtime.ActivationPoints`-reuse/
  session-only-test-store-console-command precedent — since this phase's own scope is
  structurally identical to Phase 50, just with one sub-offset instead of three.
- The two Completion Criteria ("pole and light source proven independently classified/
  queryable while sharing the same anchor", "no duplicate transform data between the
  two") turned out to be provable STRUCTURALLY rather than requiring an in-editor test:
  no "City Light Pole" Generation object exists anywhere in the codebase yet (Phase 40's
  classification tagging and Phase 42's Instancing Pipeline are generic mechanisms with
  zero City-Light-specific content — nothing has ever produced a pole instance to query).
  Checked this by grepping for "CityLight"/"City Light" under `Source/` before this
  phase's own changes — zero hits anywhere. Given that, "linked by shared HighwayPointId"
  and "no duplicate transform data" are true BY CONSTRUCTION of `FNexusCityLightActivation`
  declaring exactly one field (`LightSource`) and zero anchor/pole-transform fields of its
  own — checked both criteria off with a written structural proof in `phase-56.md`
  itself, the same "written comparison, not a live test" precedent Phase 50 already used
  for its own analogous "V5 field-by-field comparison" criterion.
- Confirmed (same reasoning already verified for Traffic Light at Phase 50, re-checked
  here rather than assumed to carry over silently) that registering the new type is
  sufficient for full generic debug-rendering and gizmo support — zero renderer/gizmo
  code needed.

## Changes

- `Public/Representation/NexusCityLightActivation.h` (new) — `FNexusCityLightActivation`,
  one `FNexusSubPointOffset LightSource` member.
- `Private/Representation/NexusCityLightActivationRegistration.cpp` (new) — registers
  `FName("CityLight")` (`RuntimeActivated`, `DefaultDebugCategory=Runtime.ActivationPoints`).
  Adds `Nexus.Representation.AddTestCityLight <HighwayPointId> [AlwaysDraw]`.
- `project-specifications/phases/phase-56.md` — both Completion Criteria checked off
  (structural proof, documented inline); Implementation + manual-verification section
  appended; `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): the in-editor render/gizmo
  round trip (`Nexus.Representation.AddTestCityLight`, enable the category, click-drag
  the LightSource marker) — documented in `phase-56.md`'s own "Manual verification
  required" section.

## Result

Data model + registration implemented and build-verified; both Completion Criteria
checked off via structural proof (no pole object exists yet to query against, so an
in-editor "prove they're linked" test isn't meaningful today — the linkage is guaranteed
by this project's own shared-anchor architecture, not by anything this struct could get
wrong). The render/gizmo round-trip proof is the one remaining item, deferred to the
user per standing policy.

## Important Notes

- Same open item Phase 50 already flagged for Traffic Light, now true for City Light too:
  real `UNexusConfigAsset` persistence for specialized payloads remains an open
  architecture question — `FNexusCityLightActivation` only exists as session-only
  `FNexusActivationPointTestStore` data today.
- No "City Light Pole" Static/Instanced Generation object exists anywhere yet — this
  phase's own Completion Criteria are about the DATA MODEL's structural correctness
  (anchor sharing, no duplication), not about a real pole+light pair actually rendering
  together in a generated scene. That's a future Generation-stage phase's job, not
  flagged as blocking here since nothing in this phase's own Allowed list asks for it.
