# Phase 64 — Bus Stop — Data Model

Date: 2026-08-12
Category: feature-add
Phase: 64

## Context

Picked up via `/TODO`, third phase of the 9-phase batch (61, 62, 64-67, 69-71) the user
selected this session. First Bus Stop phase — starts a new object-type group the same
way Phase 50 (Traffic Light) and Phase 60 (Crosswalk) each did.

## Problem / Goal

Implement `FNexusBusStopActivation` per `12-v6-activation-point-system.md` and
`v6-master-architecture.md` Section 7 — StoppingPoint/EntryPoint/ExitPoint sub-offsets,
generalizing V5's `FNexusBusStopInfo` occupancy-grid shape, plus the mesh/shelter fields
the original phase text omitted (this phase's own 2026-08-10 revision).

## Findings

- Read `v6-master-architecture.md` Section 7 directly rather than trusting the phase
  file's own paraphrase — confirmed the field list is `HighwayId/Anchor/Offset` (already
  base fields), `StoppingPoint/EntryPoint/ExitPoint`, `PassengerWaitingPoints[]`,
  `SeatInteractionPoints[]`, `Shelter configuration`, `BaseMesh`, `IndicatorMesh`, and
  `Seat/Chair configuration`. Cross-referenced Section 8 (the general seat system) and
  `12-v6-activation-point-system.md`'s own diagram to confirm "Seat/Chair configuration"
  is satisfied by `SeatInteractionPoints[]` itself (Phase 66, each backed by Phase 69's
  `FNexusSeatActivation`) — not a separate field needed on this struct, so not added
  speculatively.
- Read V5's `FNexusStationInfoBase`/`FNexusBusStopInfo` (`v5-complete-reference.md`
  lines 592-609) directly rather than assuming the shape — confirmed `SegmentRow`/
  `SegmentColumn`/`OccupiedIndex`/`GetTotalSegmentCount`/`HasFreeSegment` is the exact
  reusable subset this phase's own Allowed-list item names, and that
  `AllowVehicles`/`AllowLanes`/`SegmentWidth`/`SegmentLength`/the various identity
  fields either have no analogue in Section 7's list or are already superseded by the
  shared `FNexusActivationPoint` base — wrote up the full carried-over-vs-dropped
  disposition in `phase-64.md` per this phase's own explicit completion criterion, not
  left implicit.
- This phase's own Allowed list explicitly required a "decide and document which"
  choice for Shelter: an embedded config struct vs. a separate Static-classified
  companion object (City Light's Pole precedent). Decided embedded struct
  (`FNexusBusStopShelterConfig`) — Section 7's own diagram nests "Shelter configuration"
  as a sibling FIELD of Bus Stop alongside BaseMesh/IndicatorMesh, unlike a City Light
  Pole (which never appears in `FNexusCityLightActivation`'s own field list at all,
  because it's genuinely a separate object elsewhere). The architecture doc's own
  wording already answered the question; documented the reasoning in
  `NexusBusStopActivation.h`'s own header comment rather than leaving the choice
  implicit in the code.
- `BaseMesh`/`IndicatorMesh`/`ShelterMesh` are `TSoftObjectPtr<UStaticMesh>` — confirmed
  this is an existing, idiomatic pattern in this codebase
  (`FNexusActivationPoint::RuntimeClass` is already a `TSoftClassPtr<AActor>`), not a
  new convention invented for this phase. The test console command points them at
  Engine `/Engine/BasicShapes/*` meshes (always present in any UE project) specifically
  so the round-trip proof doesn't depend on project-specific content existing.

## Changes

- `Public/Representation/NexusBusStopActivation.h` (new) — `FNexusBusStopShelterConfig`
  (`HasShelter` + `ShelterMesh`) and `FNexusBusStopActivation`
  (`StoppingPoint`/`EntryPoint`/`ExitPoint`, `SegmentRow`/`SegmentColumn`/
  `OccupiedIndex` + `GetTotalSegmentCount`/`HasFreeSegment`, `ShelterConfig`,
  `BaseMesh`, `IndicatorMesh`).
- `Private/Representation/NexusBusStopActivationRegistration.cpp` (new) — registers
  `FName("BusStop")` (`RuntimeActivated`/`Runtime.ActivationPoints`). Adds
  `Nexus.Representation.AddTestBusStop <HighwayPointId> [SegmentRow=2]
  [SegmentColumn=2] [AlwaysDraw]` — seeds a multi-bay grid (one bay pre-occupied),
  configured shelter, and BaseMesh/IndicatorMesh.
- `project-specifications/phases/phase-64.md` — all three Completion Criteria addressed
  (two checked off as logically/data confirmed; the visual/gizmo one left unchecked
  pending in-editor confirmation); full V5-field-disposition + shelter-design-decision
  Implementation Notes appended; `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): the visual sub-point
  placement/gizmo-drag round trip and the Details panel showing
  ShelterConfig/BaseMesh/IndicatorMesh correctly — documented in `phase-64.md`'s own
  "Manual verification required" section.

## Result

`FNexusBusStopActivation` implemented and build-verified, covering every Section 7 field
except `PassengerWaitingPoints[]`/`SeatInteractionPoints[]` (Phase 65/66's own explicit
scope). V5 field disposition and the Shelter design decision are both explicitly
documented, not left implicit. The in-editor visual/gizmo round-trip proof is the one
remaining item, deferred to the user per standing policy.

## Important Notes

- `PassengerWaitingPoints[]` and `SeatInteractionPoints[]` are NOT on this struct yet —
  Phase 65 and Phase 66 add them as their own dedicated phases. Do not assume
  `FNexusBusStopActivation` is "done" for a real multi-passenger bus stop scenario until
  those land too (same pattern Phase 50/51/52 and Phase 60/61 already established for
  their own object types).
- Same open item every specialized payload type has flagged since Phase 46: real
  `UNexusConfigAsset` persistence remains undecided — this struct only exists as
  session-only `FNexusActivationPointTestStore` data today.
- Part of the same 9-phase batch (61, 62, 64-67, 69-71) — Phase 65
  ("Bus Stop — Passenger Waiting Points") is next.
