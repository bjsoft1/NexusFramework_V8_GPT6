# Phase 69 — Seat Activation Point — Generalization

Date: 2026-08-12
Category: feature-add
Phase: 69

## Context

Picked up via `/TODO`, reordered ahead of Phase 66 within the same 9-phase batch (61,
62, 64-67, 69-71) the user selected this session. **Deliberate reordering**: Phase 66
("Bus Stop — Seat Interaction Points") needs `FNexusSeatActivation` to exist, which this
phase is the one that builds. Phase 66's own text acknowledges the wrinkle ("referencing
the general Seat activation type (built next in Phase 69, or stubbed here and finalized
then — record which)") — chose to build the real thing first rather than a throwaway
stub, since both phases were already part of the same agreed batch (not skipping ahead
of unrelated earlier work, just fixing a real forward dependency the phase docs
themselves flagged).

## Problem / Goal

Implement `FNexusSeatActivation` as a real specialized payload struct per this phase's
own 2026-08-10 revision (`v6-master-architecture.md` Section 8) — SeatType/SeatCapacity/
Occupancy/Spacing/Mesh/GroupId, generalizing V5's `FNexusSittingSite`/
`FNexusOccupancyGrid`/`FNexusRandomSiteMeshOptions`, not the original "base fields are
sufficient" scoping that revision explicitly rejected.

## Findings

- Read `NexusActivationSubPointResolver.h`'s own header comment before designing the
  struct's position handling, rather than assuming a new `Offset` field was needed — it
  already explicitly names "Advertisement/TV/Seat/Parking... has exactly one sub-point
  key" as the synthetic-base-key case for a type with zero declared
  `FNexusSubPointOffset` fields. Confirmed `FNexusSeatActivation` fits that shape
  exactly for standalone usage (SeatType/SeatCapacity/Occupancy/Spacing/Mesh/GroupId
  are all plain data, none of them a `FNexusSubPointOffset`) — so a standalone Seat's
  position is its own base `FNexusActivationPoint::OffsetLocation`, already
  gizmo-editable with zero new resolver code, exactly the mechanism Phase 45/48 already
  built for this case.
- Read `NexusActivationSubPointResolver.cpp`'s actual implementation
  (`ResolveSubPointOffsetPtr`) before assuming the embedded-in-Bus-Stop case could work
  the same way — it `reinterpret_cast`s a resolved array element directly to
  `FNexusSubPointOffset*`, which is only safe when the array's element type genuinely
  IS `FNexusSubPointOffset`. A `TArray<FNexusSeatActivation>` element is a different,
  larger struct — reinterpreting it as `FNexusSubPointOffset` would read garbage/wrong
  memory, a real correctness bug, not a style question. This directly contradicts
  `12-v6-activation-point-system.md`'s diagram wording ("SeatInteractionPoints[] (each
  a FNexusSeatActivation payload, not just a bare point)") taken completely literally —
  documented the resulting design deviation (parallel `SeatInteractionPoints` +
  `SeatInteractionConfigs` arrays) in Phase 66's own record rather than either
  silently reinterpreting unsafely or silently deviating from the doc without saying so.
- Read V5's `FNexusOccupancyGrid`/`FNexusSittingSite`/`FNexusRandomSiteMeshOptions`
  directly (`v5-complete-reference.md` lines 111-131) to write an accurate carried-
  over-vs-new field disposition, per this phase's own explicit Not-Allowed rule against
  silently dropping V5's capability level.
- `GroupId` (plain `FName`, blank = ungrouped) was chosen over a `bAllowGrouping` bool
  — this phase's own Allowed list offered either — because it reuses
  `FNexusTrafficLightActivation::SignalGroup`'s exact already-established "blank means
  unset, never matches another blank" convention (Phase 52) rather than inventing a
  second grouping shape for the same concept.

## Changes

- `Public/Representation/NexusSeatActivation.h` (new) — `FNexusOccupancyGrid` (V5's
  shape, unchanged), `FNexusSeatMeshOptions` (V5's shape, unchanged), and
  `FNexusSeatActivation` (`SeatType`, `SeatCapacity`, `Occupancy`, `RowSpacing`/
  `ColumnSpacing`, `SeatMesh`, `MeshOptionsByCapacity`, `GroupId`,
  `GetTotalSeatCount`/`HasFreeSeat`).
- `Private/Representation/NexusSeatActivationRegistration.cpp` (new) — registers
  `FName("Seat")` (`RuntimeActivated`/`Runtime.ActivationPoints`) as a STANDALONE type.
  Adds `Nexus.Representation.AddTestSeat <HighwayPointId> [SeatCapacity=3]
  [AlwaysDraw]`.
- `project-specifications/phases/phase-69.md` — two of four Completion Criteria
  checked off; the visual-verification and Phase-66-cross-reference criteria left
  unchecked (the latter with an explicit note this phase's own text anticipated, to be
  updated once Phase 66 lands later this session); V5-field-disposition
  Implementation Notes appended; `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): the visual placement/
  gizmo-drag round trip for the standalone test Seat — documented in `phase-69.md`'s own
  "Manual verification required" section.

## Result

`FNexusSeatActivation` implemented and build-verified as a standalone `RuntimeActivated`
type, generalizing V5's `FNexusSittingSite`/`FNexusOccupancyGrid`/
`FNexusRandomSiteMeshOptions` per this phase's own 2026-08-10 revision. The
Bus-Stop-embedded half of this phase's own Completion Criteria is intentionally
incomplete until Phase 66 (next in this same session) lands — not silently claimed done.

## Important Notes

- **Architectural deviation from `12-v6-activation-point-system.md`'s own diagram
  wording**, discovered and documented here, finalized in Phase 66's own record: Bus
  Stop's `SeatInteractionPoints[]` is NOT `TArray<FNexusSeatActivation>` with an
  embedded offset — it's two parallel, index-aligned arrays
  (`SeatInteractionPoints: TArray<FNexusSubPointOffset>` for position,
  `SeatInteractionConfigs: TArray<FNexusSeatActivation>` for metadata). Root cause: the
  existing generic sub-point resolver (`NexusActivationSubPointResolver.cpp`) only
  safely supports `TArray<FNexusSubPointOffset>` elements by construction
  (`reinterpret_cast` to that exact type) — extending it to support an embedded-offset
  struct-array shape was judged out of scope for this batch (a cross-cutting change to
  shared, load-bearing infrastructure every other real type depends on, not something
  to risk for one feature's convenience without the user separately deciding it's
  worth it). If a future phase wants the literal "one array of self-positioned
  structs" shape, that requires deliberately extending the resolver first — flagging
  this as an open item, not silently working around it forever.
- Same open item every specialized payload type has flagged since Phase 46: real
  `UNexusConfigAsset` persistence remains undecided — this struct only exists as
  session-only `FNexusActivationPointTestStore` data today.
- Part of the same 9-phase batch (61, 62, 64-67, 69-71) — Phase 66
  ("Bus Stop — Seat Interaction Points") is next (reordered ahead of 67 too).

## Correction — 2026-08-12

Phase 66 is now done (same session) — see its own audit record. Cross-reference
confirmed: `NexusBusStopActivation.h` includes `NexusSeatActivation.h` and uses
`FNexusSeatActivation` directly in `SeatInteractionConfigs`, no duplicate struct.
`phase-69.md`'s own third Completion Criterion (previously left unchecked, pending Phase
66) has been checked off with a dated Update note in that file. Nothing about this
phase's own implementation changed — this section only closes out the criterion that
depended on later work.
