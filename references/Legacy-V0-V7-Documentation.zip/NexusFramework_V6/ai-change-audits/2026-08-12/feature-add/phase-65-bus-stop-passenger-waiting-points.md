# Phase 65 — Bus Stop — Passenger Waiting Points

Date: 2026-08-12
Category: feature-add
Phase: 65

## Context

Picked up via `/TODO`, fourth phase of the 9-phase batch (61, 62, 64-67, 69-71) the user
selected this session. Directly follows Phase 64 ("Bus Stop — Data Model"), which
deliberately left `PassengerWaitingPoints[]` off `FNexusBusStopActivation` for this
phase to add.

## Problem / Goal

Add `PassengerWaitingPoints[]` to Bus Stop — a concept V5's vehicle-occupancy-shaped
station data had no equivalent of — per `phase-65.md`'s Allowed/Completion-Criteria
list.

## Findings

- Read `10-v6-runtime-schema.md`'s "Confirmed gaps" section directly rather than
  assuming which gap item this phase closes — it's item 5 ("`FNexusStationInfoBase`'s
  segment-grid model is vehicle-occupancy-shaped, not passenger-shaped... no concept of
  'passenger waiting point'... as a first-class entity distinct from the vehicle bay
  itself"), not item 4 (the seat/passenger-point-TYPE gap, which is Phase 69's own
  scope) or item 3 (Crosswalk, already closed by Phase 60/61). Wrote an itemized,
  honest gap-closure note citing item 5 specifically rather than a vague "closes a gap"
  claim.
- This is the SECOND real (non-dummy) type to use the dynamic-array sub-point shape
  (`FNexusCrosswalkActivation::PedestrianWaitingPoints`, Phase 60, was the first) —
  confirmed the existing generic machinery (reflection, resolver, gizmo, Details-panel
  array UI) already fully supports a second unrelated array field with zero new code,
  rather than assuming Phase 60's proof only covered "one array per struct."
- This phase's own Allowed-list item ("verify waiting points don't interfere with
  vehicle bay occupancy tracking") is satisfied BY CONSTRUCTION, not by a runtime check
  that needs writing — `PassengerWaitingPoints` and `SegmentRow`/`SegmentColumn`/
  `OccupiedIndex` are unrelated fields on the same struct that no code path anywhere
  cross-reads. Extended the test console command to seed both from independent args
  specifically so this independence is demonstrable in one command run, rather than
  writing a separate "non-interference" test that would just be asserting the absence
  of code that was never written.
- "Implement a UI affordance for placing multiple waiting points per stop" and "verify
  each element is independently gizmo-editable" are both already satisfied by existing,
  generic machinery (`IStructureDetailsView`'s standard array UI; the
  `Runtime.ActivationPoints` category's existing `IsSelectable`/`CanSupportGizmo=true`)
  — confirmed rather than assumed, same as Phase 62's identical finding for Crosswalk.
  No new UI/gizmo code was needed or added.

## Changes

- `Public/Representation/NexusBusStopActivation.h` — added `PassengerWaitingPoints`
  (`TArray<FNexusSubPointOffset>`).
- `Private/Representation/NexusBusStopActivationRegistration.cpp` — extended
  `Nexus.Representation.AddTestBusStop` with a fourth `[WaitingPointCount=3]` arg,
  seeding that many array entries near `StoppingPoint` via the same
  `FArrayProperty`-resize pattern `AddTestCrosswalkConsoleCommand` already established.
- `project-specifications/phases/phase-65.md` — gap-closure criterion checked off with
  an itemized written confirmation; the independence/visual criterion left unchecked
  pending in-editor confirmation; Implementation Notes + "Manual verification required"
  section appended; `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): the visual placement/
  gizmo-drag round trip and the "dragging a waiting point doesn't touch bay occupancy
  in the live Details panel" check — documented in `phase-65.md`'s own "Manual
  verification required" section.

## Result

`PassengerWaitingPoints[]` implemented and build-verified, closing
`10-v6-runtime-schema.md`'s gap item 5 for Bus Stop's passenger-point half (the sibling
seat-interaction-point half is Phase 66/69's own scope). The in-editor visual/gizmo
round-trip proof is the one remaining item, deferred to the user per standing policy.

## Important Notes

- `SeatInteractionPoints[]` is still NOT on `FNexusBusStopActivation` — Phase 66 adds
  it (backed by Phase 69's `FNexusSeatActivation`). Do not assume Bus Stop's point
  model is complete until that lands too.
- Part of the same 9-phase batch (61, 62, 64-67, 69-71) — Phase 66
  ("Bus Stop — Seat Interaction Points") is next.
