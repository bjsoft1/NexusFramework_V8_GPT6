# Phase 51 — Traffic Light — Controlled Lane/Road References

Date: 2026-08-12
Category: feature-add
Phase: 51

## Context

Picked up via `/TODO` as the lowest-numbered `Not started` phase (`PHASE-STATUS.md`
confirmed 05–50 all `In Review`/`Complete`, 51 onward `Not started`). User had specifically
asked to sequence upcoming work toward the next UI-flavored phases (53/54/57/58/62/67 -
Debug Visualization/Gizmo phases), which all depend on this phase's own data-model
prerequisite work landing first.

## Problem / Goal

Add `ControlledLaneIds`/`ControlledRoadIds` to `FNexusTrafficLightActivation` (Phase 50's
struct), referencing Phase 37's lane relationship data, with a dangling-reference
validation check and a Details-panel UI affordance for assigning them, per
`phase-51.md`'s own Allowed/Completion Criteria list.

## Findings

- `FNexusTrafficLightActivation`'s own header comment (Phase 50) explicitly deferred
  `ControlledLaneIds`/`ControlledRoadIds`/`SignalGroup` to this phase and phase-52 - no
  surprise there, confirmed by reading it directly rather than assuming.
- **The real puzzle**: Phase 51's own Allowed list asks for "a UI affordance (Details
  panel) for assigning controlled lanes to a placed Traffic Light" - but as of this
  phase, NOTHING binds any Activation Point's specialized PAYLOAD struct into the Details
  panel, for any type, real or test. Pole/VehicleLED/PedestrianLED (Phase 50) never
  needed this because they're `FNexusSubPointOffset` fields, edited exclusively via
  `UNexusActivationGizmoTool` in the viewport - but `ControlledLaneIds`/`ControlledRoadIds`
  are plain `FGuid` arrays, which `FNexusActivationTypeRegistry::
  EnumerateDeclaredSubPointFields` (and therefore the Gizmo tool) has zero interest in.
  Without a Details-panel binding, these fields would be uneditable by ANY mechanism in
  the whole system - this phase's own "Verify against a test junction" Completion
  Criterion would be unprovable. Confirmed this gap is real (not an oversight) by reading
  `SNexusDetailsPanel::RebindToCurrentTarget` in full - its `HierarchyEntity` case binds
  only the shared `FNexusActivationPoint` BASE struct, never a payload.
- **A second surprise, discovered mid-investigation**: the Phase 49 audit record (read
  first) describes making REAL, persisted `UNexusConfigAsset::ActivationPoints`
  gizmo-draggable via `UNexusActivationGizmoTool` - but the CURRENT
  `NexusActivationGizmoTool.h`/`.cpp` contradicts that: its own header comment states this
  was reverted the SAME DAY by a later "Editor Proxy Actor Pool" pass (see
  `16-v6-editor-proxy-actor-system.md`, `ai-change-audits/2026-08-11/feature-add/
  editor-proxy-actor-pool-near-camera-interaction.md`) - real config points are now
  selected/dragged via a native `ANexusEditorProxyActor` pool (native transform widget),
  which already calls `SetDetailsTarget` for the BASE struct on click. The custom Gizmo
  tool went back to test-store-only data, its real ongoing purpose being specialized
  sub-point editing. This is why the audit trail alone was insufficient here - the git
  log's own most recent commits ("Editor Proxy Actor Pool: Native ActivationPoint
  Editing") had to be cross-checked against current source, not just the phase-49 audit
  record, to get an accurate picture. Recorded here so a future agent doesn't repeat the
  same stale-audit-record trap.
- Specialized payload persistence for a REAL, placed Traffic Light remains the same open,
  not-yet-decided architecture question flagged since Phase 46/49/50 - nothing in this
  phase's own Allowed/Completion Criteria list asks to resolve it, so "a placed Traffic
  Light" in this phase's context is necessarily the session-only test-store kind (same as
  every specialized-payload phase before it).
- "Road" has no separate entity in this codebase - `ControlledRoadIds` references
  `FNexusHighway::HighwayId` directly (confirmed via `12-v6-activation-point-system.md`'s
  own diagram wording and the total absence of any "Road"-named struct/field elsewhere in
  `Source/`).

## Changes

- `Public/Representation/NexusTrafficLightActivation.h` — `ControlledLaneIds`/
  `ControlledRoadIds` (`TArray<FGuid>`) added, plus a new
  `ValidateControlledReferences(...)` method declaration.
- `Private/Representation/NexusTrafficLightActivation.cpp` (new) — implements
  `ValidateControlledReferences`: every `ControlledLaneIds` entry must resolve via
  `FNexusRepresentationGraph::GetLanesAtPoint` at the Traffic Light's own anchor; every
  `ControlledRoadIds` entry must resolve via `FindHighway` anywhere in the graph.
  Deliberately NOT folded into `FNexusRepresentationGraph::ValidateRepresentationStage` -
  that function's own header comment establishes shared Representation-stage validation
  code never branches on a specific `Type`; a per-type reference check belongs in the
  type's own file instead (same "type-specific code lives with the type" precedent
  `NexusTrafficLightActivationRegistration.cpp` already set).
- `Private/Representation/NexusTrafficLightActivationRegistration.cpp` — two new console
  commands: `Nexus.Representation.AssignTrafficLightControlledLanes
  <ActivationPointId> [InjectDanglingLaneId 0/1]` (auto-assigns from the anchor's real,
  live lane/Highway data; optional flag appends one deliberately-unresolvable Guid) and
  `Nexus.Representation.ValidateTrafficLightControlledReferences <ActivationPointId>`
  (runs+logs the new validation, same log shape as `Nexus.Representation.ValidateStage`).
- `Public/UI/NexusPanelSharedTypes.h` — new `ENexusDetailsTargetMode::
  TestActivationPointPayload` + `FNexusDetailsTarget::TestActivationPointId`.
- `Private/UI/SNexusDetailsPanel.cpp` — `RebindToCurrentTarget` gains a
  `TestActivationPointPayload` branch: resolves the test-store point's payload struct type
  via `FNexusActivationTypeRegistry` (generic, no Traffic-Light-specific code) and binds it
  via the same `FStructOnScope`/`IStructureDetailsView` mechanism the base struct already
  uses. `NotifyPreChange`/`OnDetailsViewFinishedChangingProperties` both early-return for
  this mode — session-only test-store data is not a `UObject`, nothing to
  `Modify()`/transact through `UNexusConfigAsset`'s undo system.
- `Private/Gizmo/NexusActivationGizmoTool.cpp` — `SelectSubPoint` now also calls
  `SetDetailsTarget(TestActivationPointPayload, hit.ActivationPointId)`; the explicit-
  deselect path in `OnClickedInViewport` calls `ClearDetailsTarget()`, guarded on Mode
  still being ours and NOT triggered by a mode-driven `Shutdown()` (matches the existing
  `bHasRememberedSelection` "selection survives the mode switch" precedent — the Details
  panel binding follows the same rule as the remembered gizmo selection it's paired with).
- `project-specifications/phases/phase-51.md` — Implementation + manual-verification
  section appended; `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): both Completion Criteria
  ("multi-lane test junction's Traffic Light correctly references all intended lanes",
  "a dangling lane reference is caught by validation") and the new Details-panel binding
  itself require the in-editor console-command + click-to-select round trip documented in
  `phase-51.md`'s own "Manual verification required" section. Left unchecked in the phase
  file rather than claimed.

## Result

Data model, validation, and a new generic (registry-driven, not Traffic-Light-specific)
Details-panel payload-binding mechanism implemented and build-verified. The in-editor
round-trip proof (assign real lanes, confirm clean validation, inject a dangling
reference, confirm it's caught, confirm Details-panel editability, confirm
selection-survives-mode-switch) is the one remaining item, deferred to the user per
standing policy.

## Important Notes

- This is the FIRST phase to bind any Activation Point payload struct into the Details
  panel — a new, generic mechanism (`ENexusDetailsTargetMode::TestActivationPointPayload`),
  not scoped to Traffic Light. Any future type's own non-sub-point payload fields (e.g. a
  future Bus Stop's `ShelterConfig`) get the same Details-panel editability for free, with
  zero additional per-type UI code, once selected via the Gizmo tool.
- This mechanism is deliberately test-store-only, mirroring the Gizmo tool's own current
  scope (see `16-v6-editor-proxy-actor-system.md`). A REAL, persisted Traffic Light's
  `ControlledLaneIds` are not yet reachable this way — that's gated on the still-open
  specialized-payload-persistence architecture decision (Phase 46/49/50's own flagged open
  thread), unchanged by this phase.
- `ControlledLaneIds`/`ControlledRoadIds` editing today is raw `FGuid` array editing (the
  engine's default array/struct editor) — a human-readable picker (mapping a Guid to
  "Highway HWY_01, Right Lane 2") would be a real UX improvement but is explicitly not
  this phase's own Allowed-list scope; a natural candidate for Phase 78's "Gizmo —
  Selection & Inspection Panel Polish" pass, which already owns "consistent Details panel
  presentation... across all object types."
