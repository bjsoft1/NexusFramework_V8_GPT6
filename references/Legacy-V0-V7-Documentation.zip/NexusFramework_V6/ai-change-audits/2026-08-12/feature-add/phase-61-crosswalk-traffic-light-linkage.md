# Phase 61 — Crosswalk — Traffic-Light Linkage

Date: 2026-08-12
Category: feature-add
Phase: 61

## Context

Picked up via `/TODO` at the user's explicit request, as the first of a 9-phase batch
(61, 62, 64-67, 69-71) they selected to continue the visible Editor-UI/debug-viz work
pattern Phases 50-60 already established (data model → linkage → interaction points →
debug viz → gizmo, per city-object type). Directly follows Phase 60
("Crosswalk — Data Model"), which deliberately left `LinkedTrafficLightId` off
`FNexusCrosswalkActivation` for this phase to add.

## Problem / Goal

Add `LinkedTrafficLightId` to `FNexusCrosswalkActivation`, connecting a Crosswalk to a
Phase 50 Traffic Light's `PedestrianLED` for future runtime coordination, plus dangling-
reference validation — per `12-v6-activation-point-system.md`'s own diagram and
`phase-61.md`'s Allowed/Completion-Criteria list.

## Findings

- A Traffic Light is itself another Activation Point, which
  `FNexusRepresentationGraph` does not store (Activation Point persistence is still an
  open architecture question per `ai-change-audits/README.md`'s "Current open threads").
  So unlike `ControlledLaneIds`/`ControlledRoadIds` (which resolve against the graph's
  real Lane/Highway data), `LinkedTrafficLightId` cannot be validated the same way
  `FNexusTrafficLightActivation::ValidateControlledReferences` does. Instead reused the
  "storage-agnostic, caller resolves candidates" split
  `FindActivationPointsInSignalGroup` (Phase 52) already established: the new
  `ValidateLinkedTrafficLight` takes a plain `TArrayView<const FGuid>` of known Traffic
  Light `ActivationPointId`s, resolved by the caller from
  `FNexusActivationPointTestStore`.
- Deliberately filtered the candidate list to `Type == "TrafficLight"` only (same filter
  `FindTrafficLightsInSignalGroupConsoleCommand` uses for its own candidates) rather than
  checking "does this Guid exist as ANY Activation Point" — the phase's own wording is
  "connecting it to a Phase 50 Traffic Light" specifically, so a `LinkedTrafficLightId`
  that happens to collide with some other type's `ActivationPointId` (e.g. a City Light)
  is correctly still flagged as dangling.
- `LinkedTrafficLightId` deliberately stores the Traffic Light's own `ActivationPointId`,
  not any sub-field of it directly — the runtime module resolves it to that Traffic
  Light's own `FNexusTrafficLightActivation::PedestrianLED` at coordination time. Wrote
  this up as a new "Crosswalk LinkedTrafficLightId runtime pedestrian-signal contract"
  section in `12-v6-activation-point-system.md`, mirroring Phase 52's own SignalGroup
  contract section (same "data now, runtime behavior later" split, satisfying this
  phase's own "Document (not implement)" Allowed-list item).
- No sub-point/gizmo/renderer changes needed — `LinkedTrafficLightId` is a plain `FGuid`
  reference field, same "Details-panel-editable only, never gizmo-enumerated" precedent
  `ControlledLaneIds`/`ControlledRoadIds` already established (the sub-point
  resolver/Gizmo tool only ever look for `FNexusSubPointOffset`-typed fields).

## Changes

- `Public/Representation/NexusCrosswalkActivation.h` — added `LinkedTrafficLightId`
  (`FGuid`, invalid = unlinked) and the `ValidateLinkedTrafficLight` declaration; forward
  declares `FNexusRepresentationValidationEntry`.
- `Private/Representation/NexusCrosswalkActivation.cpp` (new) — implements
  `ValidateLinkedTrafficLight`: unset link is a no-op; a set link not present in the
  caller-supplied candidate list is flagged `Blocking`.
- `Private/Representation/NexusCrosswalkActivationRegistration.cpp` — two new console
  commands: `Nexus.Representation.LinkCrosswalkToTrafficLight
  <CrosswalkActivationPointId> <TrafficLightActivationPointId> [InjectDangling=0]` and
  `Nexus.Representation.ValidateCrosswalkLinkedTrafficLight <CrosswalkActivationPointId>`
  (builds the `Type == "TrafficLight"` candidate list from the test store, runs the
  validation, logs entries or "clean").
- `project-specifications/12-v6-activation-point-system.md` — new "Crosswalk
  LinkedTrafficLightId runtime pedestrian-signal contract (Phase 61, 2026-08-12)"
  section.
- `project-specifications/phases/phase-61.md` — Implementation Notes + "Manual
  verification required" section appended; Completion Criterion left unchecked pending
  in-editor confirmation; `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): the link/validate/dangling
  round trip and the Details-panel field showing up — documented in `phase-61.md`'s own
  "Manual verification required" section.

## Result

`LinkedTrafficLightId` + dangling-link validation implemented and build-verified, closing
the last item `10-v6-runtime-schema.md`'s own crosswalk gap named
("...or its relationship to a controlling traffic light") that Phase 60 explicitly left
open. The in-editor link/validate round trip is the one remaining item, deferred to the
user per standing policy.

## Important Notes

- This is the first Crosswalk field to cross-reference ANOTHER Activation Point rather
  than the Representation graph's own Highway/Lane data — future object types that need
  the same shape (cross-referencing a sibling Activation Point, not graph data) should
  reuse this same "caller-resolved candidate list" pattern rather than trying to route
  through `FNexusRepresentationGraph`.
- Same open item every specialized payload type has flagged since Phase 46: real
  `UNexusConfigAsset` persistence remains undecided — this field only exists as
  session-only `FNexusActivationPointTestStore` data today.
- Part of a 9-phase batch (61, 62, 64-67, 69-71) the user queued this session — Phase 62
  ("Crosswalk — Debug Visualization") is next.
