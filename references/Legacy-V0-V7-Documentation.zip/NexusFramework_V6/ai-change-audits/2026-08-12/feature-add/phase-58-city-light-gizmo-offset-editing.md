# Phase 58 — City Light — Gizmo Offset Editing

Date: 2026-08-12
Category: feature-add
Phase: 58

## Context

Picked up via `/TODO` immediately after Phase 57 (same session), continuing the
sequential run through Phases 54-60a.

## Problem / Goal

Enable gizmo editing for the LightSource offset, following Phase 54's pattern.

## Findings

- Same outcome as Phase 54 (Traffic Light's own gizmo phase), re-confirmed rather than
  assumed to carry over: `LightSource` is a single `FNexusSubPointOffset` field on
  `FNexusCityLightActivation` (Phase 56), found generically by
  `FNexusActivationTypeRegistry::EnumerateDeclaredSubPointFields`'s type-blind reflection,
  and City Light's `DefaultDebugCategory` (`Runtime.ActivationPoints`) already has
  `IsSelectable`/`CanSupportGizmo = true` from Phase 48. Zero new code needed.
- "Editing the light-source offset never affects the separately-classified pole object"
  is even more directly true-by-construction than Traffic Light's analogous criterion
  (Phase 54) — `FNexusCityLightActivation` has literally no pole field to affect at all
  (confirmed at Phase 56/57), not just "a different field the edit doesn't touch."

## Changes

None — no source file was touched. `project-specifications/phases/phase-58.md` —
Implementation section appended explaining why each Allowed/Completion-Criteria item is
already satisfied; the "pole unaffected" half of the one Completion Criterion checked by
construction in the phase file's own prose (no pole field exists to affect), the
gizmo-editable half left unchecked pending in-editor confirmation; `## Status` set to
`Ready for Review`. `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html`
regenerated via `node html-docs/build.js`.

## Verification

- Build: not run — no code changed, nothing to compile.
- **Not verified** (Agent Testing Policy, no editor launch): the gizmo-editable half of
  the one Completion Criterion requires the in-editor round trip documented in
  `phase-58.md`'s own "Manual verification required" section.

## Result

Confirmed, by reading the actual implementation rather than assuming the pattern
carries over silently, that this phase's scope was already delivered by Phase 45/48/56's
generic design. No new code needed or written.

## Important Notes

- Two-for-two now on "per-type gizmo phase turns out to need zero new code" (Traffic
  Light Phase 54, City Light Phase 58) — increases confidence that Crosswalk's/Bus Stop's
  own upcoming gizmo phases will likely follow the same shape, though each should still
  be individually re-checked against the actual code (per Phase 54's own Important Notes)
  rather than skipped on pattern-matching alone.
