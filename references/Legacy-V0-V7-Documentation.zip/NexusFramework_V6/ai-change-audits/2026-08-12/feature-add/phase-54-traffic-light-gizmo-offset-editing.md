# Phase 54 — Traffic Light — Gizmo Offset Editing

Date: 2026-08-12
Category: feature-add
Phase: 54

## Context

Picked up via `/TODO` immediately after Phase 53 (same session), continuing the
sequential run through Phases 54-60a the user asked for.

## Problem / Goal

Enable gizmo editing for all three Traffic Light sub-offsets (Pole/VehicleLED/
PedestrianLED) independently, building on Phase 48's proven base gizmo flow.

## Findings

- **This phase turned out to require zero new code.** `13-v6-gizmo-system.md`'s own
  "Sub-point addressing" section states directly: "Traffic Light (Phase 54) and City
  Light (Phase 58) are call sites that configure which sub-point keys exist for their
  type, not separate gizmo implementations." The actual "call site" work — declaring
  `Pole`/`VehicleLED`/`PedestrianLED` as three `FNexusSubPointOffset` fields on
  `FNexusTrafficLightActivation` — was already done by Phase 50, and Phase 50's own file
  header comment already stated the consequence explicitly: "this type is automatically
  debug-rendered... and gizmo-selectable/draggable... the moment it's registered, without
  either system needing type-specific code."
- Verified this claim rather than trusting the two prior phases' own comments at face
  value: re-read `FNexusActivationTypeRegistry::EnumerateDeclaredSubPointFields` in full
  (`NexusActivationTypeRegistry.cpp`) — it reflects over a payload struct's `FProperty`
  list for `FNexusSubPointOffset`-typed fields purely by C++ TYPE, with zero string/name
  comparison against "TrafficLight" or any other type name. Re-read
  `UNexusActivationGizmoTool.cpp` in full — `FindClosestSubPointHit`/`SelectSubPoint`/
  `HandleGizmoTransformChanged` are all generic over `FNexusActivationPointSubPointKey`,
  no per-type branch anywhere. Confirmed `GRegisterActivationPoints`
  (`NexusDebugRuntimeGroupRenderers.cpp`, Phase 48) already sets
  `IsSelectable`/`CanSupportGizmo = true` on `Runtime.ActivationPoints`, the category
  Traffic Light's own `DefaultDebugCategory` still points at (Phase 53's two new
  Infrastructure leaves are visualization-only and never consulted by the gizmo's
  click-test, which reads a type's single `DefaultDebugCategory`, not every category a
  type happens to render under).
- Checked "undo/redo per sub-offset edit" against Phase 48/49's own prior audit records
  (already fully investigated and verified by inspection there — `UTransformProxy`'s
  built-in transaction integration, one real `FScopedTransaction` per drag gesture) rather
  than re-deriving the same finding from scratch.

## Changes

None — no source file was touched. `project-specifications/phases/phase-54.md` —
Implementation section appended explaining, criterion-by-criterion, why each
Allowed/Completion-Criteria item is already satisfied by prior work, with references to
the specific existing code that satisfies it; `## Status` set to `Ready for Review`.
`PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
`node html-docs/build.js`.

## Verification

- Build: not run — no code changed, nothing to compile.
- **Not verified** (Agent Testing Policy, no editor launch): both Completion Criteria are
  inherently behavioral (drag three sub-offsets in sequence, confirm isolation; confirm
  undo/redo isolation) — require the in-editor round trip documented in `phase-54.md`'s
  own "Manual verification required" section. Left unchecked in the phase file rather
  than claimed.

## Result

Confirmed (by reading the actual implementation, not by trusting the phase file's own
pre-written wording) that this phase's entire scope was already delivered as a side
effect of Phase 45/48/50's own generic, reflection-driven design — exactly the "zero-edit
extensibility" this project's architecture has been aiming for since Phase 45. No new
code needed or written. The in-editor behavioral confirmation is the one remaining item,
deferred to the user per standing policy.

## Important Notes

- This is a useful data point for the REMAINING per-type gizmo phases in the roadmap
  (City Light Phase 58, Crosswalk's array sub-points, Bus Stop's, etc.) — each is likely
  to turn out the same way (zero new gizmo code, since the mechanism is fully generic),
  UNLESS a future type introduces a genuinely new sub-point SHAPE the current reflection
  path doesn't already handle (e.g. something beyond "fixed `FNexusSubPointOffset`
  field" or "`TArray<FNexusSubPointOffset>`" — both already covered). Worth checking this
  same way (read the actual code, don't assume) rather than skipping straight to "this
  one's free too."
