# Phase 52 — Traffic Light — Signal Group Data

Date: 2026-08-12
Category: feature-add
Phase: 52

## Context

Picked up via `/TODO` immediately after Phase 51 (same session), as the next
lowest-numbered `Not started` phase, continuing toward the UI-flavored phases (53/54)
that depend on both 51 and 52 landing first.

## Problem / Goal

Add `SignalGroup` to `FNexusTrafficLightActivation` so multiple Traffic Lights at one
junction can be coordinated at runtime, plus a grouping query, a UI affordance for
assigning/viewing a group, and documentation of the runtime coordination contract this
data enables (actual coordination logic explicitly out of scope).

## Findings

- Phase 21's own 2026-08-10 revision record already named `SignalGroup` explicitly as an
  example of a field that "only makes sense for one specialized type" and therefore must
  NOT go on the shared `FNexusActivationPoint` base — confirms the design decision (payload
  field, not base field) was already implied by prior work, not something this phase had
  to decide fresh.
- No V5 precedent exists for signal grouping (`SignalGroup`/`TrafficLightGroup` don't
  appear anywhere in `v5-complete-reference.md`) — this is a genuinely new V6 concept, so
  its shape (`FGuid` vs `FName` vs something else) had to be reasoned from this project's
  own conventions rather than ported from V5.
- Chose `FName` over `FGuid` deliberately: every other identity field in this codebase
  (`LaneId`, `HighwayId`, `ActivationPointId`, ...) is an `FGuid` generated once by its
  OWNING entity and never hand-typed — but a signal group has no owning entity of its own;
  it only exists implicitly as two-or-more lights sharing the same value. Forcing `FGuid`
  here would mean a level designer copy-pasting a 32-character hex string between every
  light in a group by hand — `FName` (a short, human-typed label, same convention as
  `Code`/`Name` fields elsewhere) is the usable choice for a "shared tag with no single
  owner" concept, which none of this codebase's existing Guid-identity precedent actually
  covers.
- Re-checked whether "assigning a group" needed new UI work: it did not.
  `FNexusTrafficLightActivation::SignalGroup` is just another `UPROPERTY` on the payload
  struct, so it's automatically Details-panel-editable via Phase 51's
  `ENexusDetailsTargetMode::TestActivationPointPayload` binding the moment a sub-point is
  selected — the exact "any future type's own non-sub-point payload fields get the same
  affordance for free" payoff that phase's own audit record predicted, now confirmed one
  phase later. Only the QUERY side ("viewing... at a junction") needed a new console
  command, since there's no existing UI surface that lists/searches Activation Points by
  an arbitrary field value.
- Phase 55's own Allowed list mentions "Compilation-stage validation... covers
  Traffic-Light-specific fields (e.g. dangling SignalGroup)" as a FUTURE concern — read
  this to confirm Phase 52 itself doesn't need to implement that validation (Phase 55
  hasn't landed the export pipeline this would even validate against yet), only to flag it
  as an open question in the new architecture-doc section for whoever picks up Phase 55.

## Changes

- `Public/Representation/NexusTrafficLightActivation.h` — `SignalGroup` (`FName`, default
  `NAME_None`) added; new `FNexusTrafficLightInstanceRef` struct (`{ActivationPointId,
  const FNexusTrafficLightActivation* Payload}`, storage-agnostic); new static
  `FindActivationPointsInSignalGroup(FName, TArrayView<const FNexusTrafficLightInstanceRef>,
  TArray<FGuid>&)`.
- `Private/Representation/NexusTrafficLightActivation.cpp` — implements the query: blank
  `signalGroup` always yields zero matches (matches the base struct's own "blank means
  unset" convention), otherwise an exact `FName` compare per candidate.
- `Private/Representation/NexusTrafficLightActivationRegistration.cpp` — two new console
  commands: `Nexus.Representation.SetTrafficLightSignalGroup <ActivationPointId>
  <SignalGroupName>` (console-scriptable equivalent of the Details-panel edit, for
  end-to-end scripted test setup) and `Nexus.Representation.FindTrafficLightsInSignalGroup
  <SignalGroupName>` (runs the query against every known test Traffic Light, logs matches).
- `project-specifications/12-v6-activation-point-system.md` — new "Traffic Light Signal
  Group runtime coordination contract" section: the DATA-ONLY contract this phase
  establishes (two-plus instances sharing a non-blank `SignalGroup` are declared one
  coordinated intersection; the actual phase/state-machine timing is the Phase 86-89
  runtime module's job, or a future dedicated Traffic Light runtime controller — never the
  Editor plugin), plus candidate Phase 55 validation checks flagged as open, not decided.
- `project-specifications/phases/phase-52.md` — Implementation + manual-verification
  section appended; Completion Criterion 2 (documentation) checked off directly (a
  documentation deliverable, confirmable by reading it — not an in-editor behavior needing
  manual QA); Criterion 1 (multi-light grouping test) left unchecked per Agent Testing
  Policy; `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): Completion Criterion 1 (the
  multi-light junction grouping test) requires the in-editor console-command round trip
  documented in `phase-52.md`'s own "Manual verification required" section. Left unchecked
  in the phase file rather than claimed.

## Result

`SignalGroup` field, grouping query, two console commands, and the runtime coordination
contract documentation are implemented and build-verified. "Assigning" a group required no
new code (Phase 51's Details-panel mechanism already covers it generically); "viewing" a
group is covered by the new query console command. The in-editor multi-light round-trip
proof is the one remaining item, deferred to the user per standing policy.

## Important Notes

- Real, persisted `UNexusConfigAsset::ActivationPoints` are untouched by this phase — same
  as Phase 51, `SignalGroup` only exists on the session-only test-store payload today;
  specialized payload persistence for a real, placed Traffic Light remains the same open
  architecture question flagged since Phase 46/49/50/51.
- The actual Traffic Light coordination state machine (which lights turn red/green when,
  in lockstep) is NOT implemented anywhere — this phase is data-shape-and-query only, per
  its own explicit "actual coordination logic is a runtime-module concern, out of scope
  here" Allowed-list wording. The new architecture-doc section is the load-bearing
  reference for whoever eventually builds that runtime piece (Phase 86-89 territory, or a
  new not-yet-numbered Traffic Light runtime controller phase).
- Phase 55's own Completion Criteria already anticipates a "dangling SignalGroup"
  Compilation-stage validation check — this phase deliberately does not implement it (no
  Compilation-stage export exists yet to validate against); left as an explicitly flagged
  open question in `12-v6-activation-point-system.md`'s new section, not silently decided.
