# Phase 67 — Bus Stop — Debug Visualization

Date: 2026-08-12
Category: feature-add
Phase: 67

## Context

Picked up via `/TODO`, seventh phase of the 9-phase batch (61, 62, 64-67, 69-71) the
user selected this session. Directly follows Phase 66 ("Bus Stop — Seat Interaction
Points"), which finished Bus Stop's full point/config field set this phase renders.

## Problem / Goal

Register Bus-Stop-related debug leaves: Bus Stop, Bus Stopping/Entry/Exit Points,
Passenger Points, Seat Points, per `phase-67.md`'s Allowed/Completion-Criteria list.

## Findings

- Noticed this phase's own Objective says leaves go **"under Runtime"**, while every
  prior debug-viz phase (53/57/62) says "under Infrastructure" — read it literally
  instead of assuming a copy-paste inconsistency, and confirmed by grep that "Runtime"
  is genuinely a separate, real top-level parent category
  (`Runtime.ActivationPoints`'s own `ParentCategoryId`). Added the four new leaves to
  `NexusDebugRuntimeGroupRenderers.cpp` (the Runtime group's own file) rather than
  `NexusDebugInfrastructureGroupRenderers.cpp` — same "one file per GROUP" precedent
  Phase 53 established, just pointed at the group this phase's own text actually named,
  rather than blindly following the majority pattern of prior phases.
- Bus Stop's occupancy grid/shelter data (`SegmentRow`/`SegmentColumn`/`OccupiedIndex`/
  `ShelterConfig`) has no `FNexusSubPointOffset` fields at all — drew it at fixed
  debug-only offsets from the anchor (a 2D grid of boxes, colored per occupancy) rather
  than trying to force it through the sub-point resolver, which would have been
  incorrect (there's nothing here to individually gizmo-drag).
- Read `NexusBusStopActivation.h`'s own "Seat interaction design decision" comment
  (from Phase 66) before rendering `SeatInteractionPoints[]` — since it's a parallel
  array to `SeatInteractionConfigs[]`, the renderer reads
  `SeatInteractionConfigs[subPoint.SubPointKey.ArrayIndex]` by the SAME index the
  resolved sub-point carries, to label each marker with its own `SeatCapacity` — proving
  the pairing visually, not just structurally.

## Changes

- `Private/Debug/NexusDebugRuntimeGroupRenderers.cpp` — four new leaves:
  `Runtime.BusStop` (occupancy grid + shelter marker), `Runtime.BusStopPoints`
  (Stopping/Entry/Exit, each its own color), `Runtime.BusStopPassengerPoints`
  (`PassengerWaitingPoints[]`), `Runtime.BusStopSeatPoints` (`SeatInteractionPoints[]`,
  labeled with each element's own `SeatInteractionConfigs[]` `SeatCapacity`). Top-of-file
  comment extended to document the Phase 67 addition and why it lives in this file
  rather than the Infrastructure one.
- `project-specifications/phases/phase-67.md` — Implementation Notes + "Manual
  verification required" section appended; Completion Criterion left unchecked pending
  in-editor confirmation; `## Status` set to `Ready for Review`.
- `PHASE-STATUS.md`/`html-docs/js/phase-data.js`/`phase-tracker.html` regenerated via
  `node html-docs/build.js`.

## Verification

- Build: `Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:\Projects\Game\UE\NexusFramework_V6\NexusFramework.uproject` — succeeded,
  zero warnings/errors.
- **Not verified** (Agent Testing Policy, no editor launch): the visual rendering of all
  four leaves and their independent toggling — documented in `phase-67.md`'s own
  "Manual verification required" section.

## Result

Bus Stop now has four dedicated, richer Runtime-group debug leaves alongside the
existing generic `Runtime.ActivationPoints` rendering, completing the visible-debug-work
half of the Bus Stop phase group (64-67, 69). The in-editor visual round-trip proof is
the one remaining item, deferred to the user per standing policy.

## Important Notes

- This closes out the Bus Stop object-type group for this batch (Phases 64/65/66/67/69
  all done). Same open item every specialized payload type has flagged since Phase 46:
  real `UNexusConfigAsset` persistence remains undecided.
- Part of the same 9-phase batch (61, 62, 64-67, 69-71) — Phase 70
  ("Parking — Data Model") is next.
