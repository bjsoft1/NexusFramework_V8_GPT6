# ai-change-audits — Category Index

Append-only history of AI-assisted work on `NexusFramework_V6`. See the root
`CLAUDE.md` for the full rules (structure, append-only discipline, record shape). This
file is the fast-orientation entry point — read it first, then follow into whatever
category/date folder is relevant.

First real entries logged 2026-08-09 (implementation started with Phase 01). Browse by
date folder, then category; see each record for full detail.

- `2026-08-09/feature-add/phase-01-core-structures.md` — Phase 01: core identity structs
  (`FNexusState`/`City`/`Highway`/`HighwayPoint`, identity-only) and the `-1`/`0`/`>0`
  inheritance resolver, in a new `NexusFrameworkEditor` module. Also records that V6's
  physical layout turned out to be a standalone Game project
  (`NexusFramework.uproject`), not a `.uplugin`.
- `2026-08-09/bug-fixed/phase-tracker-status-ui-broken.md` — the phase-tracker's status
  dropdown was silently disabled for everyone, always, regardless of server state
  (`checkServer()` was called but never defined); a phase's raw `.md` link 404'd. **Has
  a same-day Correction**: fixing `checkServer` made a second, pre-existing gap
  reachable for real — a phase currently `Not started`/`In progress` could be changed to
  *any* other status from the dropdown, skipping the agent's own review step. A human
  hit this for real and fixed it via direct file edit before it was caught in code.
- `2026-08-09/feature-add/phase-content-popup-and-complete-lock.md` — phase-tracker "Open
  phase-NN.md" now opens a rendered popup instead of a dead link; phases `Complete` for
  over an hour are now locked from further status changes. **Has a same-day Correction**
  — two real bugs (background scroll, broken scrollbar) found from actually using it.
- `2026-08-09/feature-add/phase-100-verification-system.md` — added Phase 100 (new,
  post-99 roadmap exception) + `15-v6-verification-system.md`: a manual visual-QA tree
  + per-instance sign-off, gating a generated map's publish readiness. Also fixed a
  latent tooling bug (`\d{2}` phase-number regex) that would have made any 3-digit phase
  permanently unreachable through `html-docs/server.js`'s API.
- `2026-08-09/feature-add/phase-02-editor-mode.md` — Phase 02, ORIGINAL implementation:
  `UNexusEdMode`/`FNexusEdModeToolkit`/`UNexusFrameworkSubsystem`. **Superseded — read
  its own 2026-08-10 Correction section**: this is the crash-prone pattern the research
  record below found; replaced with `FNexusLandscapeModeExtension`.
- `2026-08-09/others/agent-memory-must-stay-in-repo.md` — an agent briefly saved
  workflow feedback to its own external, per-machine memory instead of this repo. Caught
  immediately (this project is multi-developer, multi-PC). **Read this if you're an
  agent about to save anything you consider "durable" anywhere other than this
  `ai-change-audits/` tree or `project-specifications/`.**
- `2026-08-09/feature-add/phase-03-ui-shell.md` — Phase 03, ORIGINAL implementation:
  `SNexusEdModePanel` hosted by `FNexusEdModeToolkit`. **Superseded — read its own
  2026-08-10 Correction section**: panel content carried over unchanged, renamed
  `SNexusFrameworkPanel`, now hosted in a Nomad tab instead.
- `2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md` — **the canonical
  record for Phase 02/03's architecture.** V5's own code comment: a custom `UEdMode`
  alongside built-in Landscape Mode is a confirmed, reproducible engine crash
  (`ToolkitManager.cpp` assertion) — V5 reverted to Nomad tabs synced to
  `FBuiltinEditorModes::EM_Landscape` instead. Phase 02/03 originally built the exact
  `UEdMode` shape V5's comment warns against; **its own 2026-08-09 Correction section
  documents the full rework to V5's proven fix, including a lengthy automated-test
  false-negative investigation, and the final result: manually verified working by the
  user in a real interactive editor session.** Both phases are now `Ready for Review`.

- `2026-08-09/feature-add/phase-04-ui-interaction.md` — Phase 04: tree
  selection->Details panel binding, right-click Delete/Rename/Focus context menu, and a
  new reusable `FNexusUIDialogs::ConfirmDestructiveAction` — all against a hardcoded
  placeholder tree/struct, no real data. First phase implemented entirely under the new
  Agent Testing Policy (`project-specifications/AGENT-RULES.md`) — build-only
  verification, exact manual-check steps written into the phase file instead of an
  automated test.

- `2026-08-09/feature-add/phase-05-landscape-reader-control-points.md` — Phase 05: the
  first real read of engine Landscape Spline data. New `FNexusLandscapeReader`
  (`ResolveActiveLandscape`/`EnumerateControlPoints`, ported from V5's proven
  `ResolveTargetLandscape`) plus a new `Nexus.Reader.EnumerateControlPoints` console
  command — the first Agent-Testing-Policy-era "manual verification hook" pattern,
  reusable by later Source-stage phases (06–09).

- `2026-08-09/feature-add/phase-06-to-09-landscape-reader.md` — Phases 06-09 batched
  together (segment/tangent extraction, connection-graph adjacency + chain walk,
  V5's stable-identity rename trick, Source-stage validation gate). First batch of
  multiple small phases completed in one session, per the user's "3-5 small phases per
  go" request. All four extend `FNexusLandscapeReader`, now split across 5 `.cpp` files
  by responsibility (first real use of the new Source file organization rule). **Has a
  2026-08-10 Verification section appended**: user manually ran all five `Nexus.
  Reader.*` commands against a real Landscape and pasted the results — some Completion
  Criteria across Phases 05/06/07/09 are now checked off from that evidence, others
  (Phase 07's 3-way-junction case, both of Phase 08's) remain open since that test data
  didn't exercise them.

- `2026-08-10/feature-add/phase-10-to-14-nexus-mapping.md` — Phases 10-14, the full
  Nexus Mapping stage (Landscape entity → HighwayPointId, Highway/City/State
  membership with V5's InterCityHighway precedent, the `[LandscapeId]_nexusconfig`
  `UDataAsset` lifecycle, Mapping-stage validation gate). New `Public/Mapping/`
  module (`UNexusConfigAsset`, `FNexusConfigAssetIO`, `FNexusMapping`); extends the
  Phase 01 Representation structs with the fields those phases always said Mapping
  would add (`FNexusHighwayPoint.StableId`/`SourcePoint`, `FNexusHighway.
  OrderedPointIds`/`bIsClosedLoop`/`CityId`/`EndCityId`/`bIsInterCityHighway`,
  `FNexusCity.StateId`). Second batch under the "3-5 small phases per go" pattern.
  **Has a 2026-08-10 Verification section appended**: user ran the full
  `Nexus.Mapping.*` command set — Phase 10/11/14's criteria got real evidence, but
  Phase 12's assignment commands were called with no arguments (usage-text path only),
  so that phase's two criteria remain fully open, not partially confirmed.

- `2026-08-10/feature-add/phase-15-to-17-automatic-config-lifecycle.md` — Phases 15-17,
  the Automatic Config Lifecycle arc: wires Phase 10-14's Mapping functions into the
  real "enter Landscape Mode" trigger (`FNexusLandscapeModeExtension` — the first time
  an agent has touched that already-QA'd file since the Phase 02/03 false-negative-test
  saga, purely additive), adds session-to-session reconciliation
  (`FNexusMapping::ReconcileMappingStage`, distinct from Phase 14's stateless
  validation), and documents V6's single-Landscape-per-map scope decision (with a new
  Warning log if a second Landscape is silently being ignored). Third batch under the
  "3-5 small phases per go" pattern.

- `2026-08-10/feature-add/phase-13-config-path-refactor.md` — direct user-requested
  refactor (not a `/TODO` phase pickup): the config asset's save path changed from a flat
  `/Game/NexusConfigs/[LandscapeId]_nexusconfig` (GUID-keyed, rename-proof) to
  `<LevelFolder>/<LevelName>/NexusConfig` (level-relative, matches the built-in Landscape
  material layer system's own convention) - a deliberate, user-accepted trade-off that
  renaming/moving a map now orphans its old config asset. Touches Phase 13's (`Ready for
  QA`) and Phase 15's (`Ready for Review`) already-reviewed code; also flags a new,
  currently-dormant path-collision consequence for Phase 17's multi-Landscape scope if
  that restriction is ever lifted (two Landscapes in one map would now share one config
  path, unlike under the old GUID-keyed convention).

- `2026-08-10/feature-add/phase-18-highwaypoint-live-accessors.md` — Phase 18: gives
  `FNexusHighwayPoint` its live-resolved `GetLiveLocation`/`GetLiveRotation`/
  `GetLiveTangentDirection` accessors (resolve-or-fail, never a silent zero-vector) and a
  derived `ConnectedHighwayIds` field + point-scoped `RecomputeConnectedHighwayIds` (the
  full graph-wide version is Phase 19/20's job). Single-phase pickup, not a batch - user
  asked for one phase only this round.

- `2026-08-10/feature-add/phase-19-representation-graph.md` — Phase 19: new
  `FNexusRepresentationGraph` (`Public/Representation/NexusRepresentationGraph.h`) — the
  full in-memory State->City->Highway->HighwayPoint graph, FGuid-keyed `TMap`s (private,
  `const`-pointer-only `Find*()`) for O(1) lookup, `AddState`/`AddCity`/`AddHighway`/
  `AddPointToHighway` as the sole mutators, and `GetInterCityBridgedCities` resolving
  Phase 12's stored City-id pair into live City pointers. Populated FROM
  `UNexusConfigAsset` (Mapping's own persisted output) via `PopulateFromConfigAsset` —
  a rebuilt-fresh snapshot, not a second authoritative copy; `UNexusConfigAsset`/
  `FNexusMapping` themselves are untouched. Not yet wired into any consumer. Single-phase
  pickup (agent-todos was empty both `active/`/`ready-for-development/`).

- `2026-08-10/feature-add/phase-20-to-22-representation-arc-close.md` — Phases 20-22,
  closing the "Representation" arc (18-22): junction detection/live City center/
  tangent-aware Highway length/point neighbor queries added to `FNexusRepresentationGraph`
  (Phase 20); new `FNexusActivationPoint` base struct + `ComputeFinalTransform` offset
  composition, plus new `ENexusGenerationClassification`/`ENexusActiveTimes` enums
  (Phase 21); `ValidateRepresentationStage` dangling-reference/membership-consistency
  gate, mirroring `FNexusMapping::ValidateMappingStage` one stage up (Phase 22). Batch
  pickup per the user's "3-5 phases per go" request.

- `2026-08-10/feature-add/phase-23-to-26-debug-architecture.md` — Phases 23-26: new
  `FNexusDebugCategoryRegistry` (Meyer's singleton, `FNexusDebugCategoryAutoRegister`
  self-registration idiom mirroring `FAutoConsoleCommand`) + `FNexusDebugRenderConfig`/
  `FNexusDebugCategory`, the six top-level Debug groups registered with real default
  colors; `SNexusFrameworkPanel`'s Debug Tree rebuilt from the registry with a per-row
  visibility checkbox and Details-panel config editing bound live into the registry;
  persistence wired through the existing `FNexusConfigAssetIO::SaveConfigAsset`/
  `FNexusLandscapeModeExtension`'s enable-flow hooks. **Deliberately stopped before
  Phase 27** — its own Allowed list depends on Phase 28/29's not-yet-built "shared
  primitives"; flagged for the user rather than jumping ahead or guessing.

- `2026-08-10/feature-add/phase-27-28-29-debug-rendering-and-diagnostics.md` — Phases
  28/29/27 (done in dependency order): `FNexusDebugPrimitives` wireframe draw library,
  `FNexusDebugLabelOverlay` world-space labels (V5's `SConstraintCanvas` +
  `WorldToScreen` mechanism, minus its pooling), then Phase 27's `FNexusDiagnostics` —
  all three stage gates (09/14/22) normalized into one live list, wired to a real
  Diagnostics panel with Blocking/Warning distinction + click-to-focus, and rendered as
  viewport markers/labels from a new `FTickableEditorObject` on
  `UNexusFrameworkSubsystem`. **Records the user's own framing of why Debug Mode exists**
  (preview 30-40 item types as wireframe before the Static Generator merges real meshes,
  which would hang the editor at city scale). Two knowingly-imperfect spots flagged
  inside: a substring-matching diagnostics category heuristic (possible follow-up task)
  and click-to-focus focusing the camera without selecting the entity (engine crash risk
  + no real Hierarchy data yet).

- `2026-08-10/feature-add/phase-30-31-32-debug-rendering-groups.md` — Phases 30/31/32,
  the first REAL Debug category renderers: new `FNexusDebugRenderSnapshot` caching layer
  (the concrete mechanism for 06's "never recompute Landscape geometry per frame" rule,
  throttled 0.25s refresh); the renderer delegate signature revised twice
  (`World`+`Snapshot` for Phase 30, a label-request accumulator for Phase 32) as real
  renderers exposed what the Phase 23-26 placeholder signature couldn't do; new
  `HalfWidth`/`LaneWidth`/`SidewalkWidth`/`LaneCount` inheritable fields added to
  `FNexusHighway`/`City`/`State` (didn't exist anywhere before, needed by Phase 31).
  Two honest, documented half-criteria: `Mapping.ResolutionStatus` can only render
  "green" (a broken point has no drawable location by this project's own rules), and
  Roads/Landscape outlines are straight per-segment approximations, not curve-following
  geometry (correct for a debug wireframe, not final mesh generation).

- `2026-08-10/feature-add/phase-36-37-highwaypoint-junction-and-lanes.md` — Phases 36/37:
  `ENexusJunctionType` (originally DeadEnd/Passthrough/Junction, a live query never
  stored) + V6's own closed-form junction rotation solver
  (`FNexusRepresentationGraph::ComputeJunctionForwardDirection`) — the highest-severity
  carried-forward crash risk per `v6-phase-verification.md`, addressed by NEVER
  constructing an `FQuat` via axis-angle (the exact pattern the known `Q.IsNormalized()`
  crash trace implicates), so the risky code path is structurally unreachable rather
  than merely tested-against; plus `FNexusLane`/`ReconcileHighwayLanes` (stable per-lane
  identity that survives a Highway's LaneCount reconfiguration without reassigning
  existing LaneIds). **Flags an open architectural question for Phase 39** ("broken
  junction consistency" checks may not be literally checkable from Representation's own
  snapshot given the "no direct Landscape reads" rule) before that phase is picked up.
  **Same-day `## Revision`**: user review caught a real logging bug
  (`ConnectedHighways=%d` read the wrong, never-derived copy) AND asked for V5's full
  7-value taxonomy (Straight/Corner/SmoothCorner/TJunction/CrossJunction/MultiJunction/
  DeadEnd) instead of the original 3-value cut — ported it, reconstructing V5's raw
  segment count from Highway chain membership alone (no direct Landscape read).
- `2026-08-10/others/phase-41a-inserted-lane-aware-junction-mesh-selection.md` — added
  `phases/phase-41a.md` ("Static Generator — Junction Mesh Selection (Lane-Aware)",
  `Not started.`), a new letter-suffixed phase inserted between Phase 41 and Phase 42
  without renumbering anything, after confirming (by search) that no existing phase
  covers selecting a junction MESH piece from both topology (Phase 36) AND the lane
  counts of the connecting Highways (Phase 37) — V5's own `ENexusPointDescription`
  Highway-geometry band already did this (`Highway_6_4_T_Junction` etc.), V6 doesn't
  yet. Required a small `html-docs/build.js` regex fix so a letter-suffixed phase file's
  title parses instead of showing "TBD".
- `2026-08-10/bug-fixed/stale-highway-not-detected-on-landscape-removal.md` — a Highway
  whose Landscape segment is deleted natively is never flagged: `MapHighways` (Phase 11)
  only ever adds Highways, and neither `ValidateMappingStage` (Phase 14) nor
  `ReconcileMappingStage` (Phase 16) — both already `Ready for QA` — checked whether a
  Highway's point-chain still matches a LIVE, connected sequence of Landscape segments,
  only that its point IDs resolve within Config. Invisible whenever the Highway's own
  endpoints are shared with something else still valid (e.g. a diagonal/divider inside a
  closed loop) — exactly the scenario V5 had a related divider bug for (see V5's own
  `ai-change-audits/bug-fixed/closed-loop-and-divider-save-load.md`). Fixed with one
  shared `FNexusMapping::DoesHighwayChainMatchLiveLandscape` check, called from both
  functions — flags, never auto-removes (same "never silently drop" contract as every
  other check in this class). **Appended `## Revision` sections to both already-QA'd
  phase-14.md/phase-16.md** rather than rewriting their original (already-verified)
  criteria.
- `2026-08-10/feature-add/diagnostics-panel-copy-all-button.md` — the Diagnostics
  panel's list rows are plain `STextBlock`s with no text-selection/copy support at all,
  and the row click is already claimed by Phase 27's click-to-focus, so a per-row copy
  wasn't a clean fit. Added a "Copy All" button (`ApplicationCore` module dependency
  needed for `FPlatformApplicationMisc::ClipboardCopy` — first build attempt failed with
  a linker error until that was added). Appended a `## Revision` to already-QA'd
  phase-27.md.
- `2026-08-10/feature-add/roads-highway-lane-high-contrast-debug-colors.md` — user said
  console-only QA is hard to follow; checked the roadmap first (Phases 23-32 are all
  already `Ready for QA`, 33-35 is Performance and gated on correctness-first, so there
  was no new "Not started" draw-debug phase to pick up) and instead revised already-QA'd
  Phase 31: `Roads.Highways` now defaults to hot pink at 10px, `Roads.Lanes` to bright
  gold at 8px (deliberately a different color from Highways so both stay separable when
  on together) — was the same dull grey/2px as every other Roads leaf before. Pure
  registration-site change, no renderer logic touched.
- `2026-08-10/others/phase-status-vocabulary-add-in-review.md` — added a 7th phase
  status, `In Review` (between `Ready for Review` and `Ready for QA`, user-only) —
  finished wiring a change the user had already started themselves (a git-staged,
  uncommitted `phase-tracker.js` dropdown edit). Updated the authoritative vocabulary in
  `09-development-rules.md` rule 12, `server.js`'s `ALLOWED_STATUSES` whitelist (the
  real enforcement point — without it the dropdown would 400), `build.js`'s classifier/
  filter bar, a new `.badge-review` CSS color, and `html-docs/README.md`.
- `2026-08-10/feature-add/nexus-status-console-command.md` — new `Nexus.Status` command,
  a direct response to a real support cycle this session (user saw no debug lines/
  diagnostics after a fresh build; root cause was an unset `ActiveConfig`, only found
  after asking them to run an unrelated command and read its error). Logs Landscape/
  ActiveConfig/counts in one call — the first thing to run when anything looks blank.
- `2026-08-10/feature-add/phase-38-39-40-validation-and-generation.md` — Phase 38
  (combined Landscape+Mapping validation gate, `FNexusMapping::
  ValidateLandscapeMappingCombinedGate`); Phase 39 (Representation's "broken junction
  consistency" check — the exact architectural question left open in this session's own
  Phase 36-37 record, now resolvable because Representation consumes Mapping's own
  precomputed stale-Highway set rather than reading Landscape itself); Phase 40
  (`ENexusStaticObjectType`, 16 values matching `11-v6-static-dynamic-architecture.md`'s
  own starting table exactly — not the larger ~30-40 figure referenced earlier this
  session, which isn't written down in the spec yet — plus
  `FNexusGenerationClassificationTable::ResolveClassification`, a hard switch with an
  `ensureAlwaysMsgf` fallback for the "no object leaves Generation unclassified" rule).
- `2026-08-10/bug-fixed/debug-render-landscape-space-not-world-space.md` — user QA
  report: debug points/lines sat ~200-300 units off from the real Landscape geometry.
  Root cause: `ULandscapeSplineControlPoint::Location`/`Rotation` are documented by the
  engine as landscape-space (relative to the owning `ULandscapeSplinesComponent`, not
  world), but `FNexusHighwayPoint::GetLiveLocation`/`GetLiveRotation` — this project's
  single sanctioned live-read path — returned them raw, and three other call sites
  bypassed that accessor entirely with the same raw read (including the Diagnostics
  Panel's click-to-focus camera jump). Fixed with a new
  `FNexusLandscapeReader::TryResolveControlPointWorldTransform`, used everywhere a real
  world-space value is needed.
- `2026-08-10/others/phase-30a-inserted-curve-accurate-debug-lines.md` — same report's
  other half: debug lines connecting two points are still straight, not following the
  real Landscape spline curve (both Phase 30 and Phase 31 always documented this as
  deliberate, debug-wireframe-only scope). New `phases/phase-30a.md`
  (`[improve/update requirement]`) inserted after Phase 30, cross-referenced from Phase
  31 — tracking only at the time.
- `2026-08-10/feature-add/phase-30a-curve-accurate-debug-lines-implemented.md` — user
  confirmed the location fix worked and immediately asked for the curve half too;
  implemented same-day. Confirmed the exact Hermite tangent sign convention from UE 5.8
  engine source (`LandscapeSplines.cpp`) rather than guessing — the End connection's
  tangent must be negated, the Start's must not. New `FNexusDebugPrimitives::
  SampleHermiteCurve` (one shared curve implementation for both the Landscape and Roads
  renderers) + `FNexusDebugRenderSnapshot::Segments`/`FindSegmentTangents` (per-segment
  world-space tangent data, resolved once per `Refresh()`). Both `Landscape.Segments`
  and the Roads group's offset lines now curve-follow, with a straight-line fallback for
  any pair with no matching native segment yet.
- `2026-08-10/others/config-asset-dirty-undo-autosave-scoping.md` — user asked for
  NexusConfig dirty-tracking, an unsaved-file indicator, Ctrl+Z/Ctrl+Y, and auto-save on
  UE level save, with an explicit "sync FROM Landscape must never create an undo entry,
  only mark dirty" rule. V5 already solved this exact problem (with a real
  `EXCEPTION_ACCESS_VIOLATION` crash history along the way) — found and reused its proven
  design (`HandlePostSaveWorld`'s 3-guard auto-save, `OnLandscapeSplineObjectTransacted`'s
  bare-`Modify()`-never-`FScopedTransaction` rule, the `PostEditUndo()` rebroadcast fix)
  rather than re-deriving it. Implemented same-day: `Config.Modify()` at every real
  `FNexusMapping` mutation point (dirty-only, idempotency-guarded), `RF_Transactional` on
  `UNexusConfigAsset`, and `UNexusFrameworkSubsystem::HandlePostSaveWorld` (auto-saves on
  UE level save if dirty). New `phases/phase-26a.md` tracks the one remaining,
  genuinely-crash-risk-if-rushed piece: real Ctrl+Z/Ctrl+Y for Debug category
  Details-panel edits — full V5 recipe written down, one architecture question flagged
  for the user rather than picked silently.
- `2026-08-10/bug-fixed/debug-category-settings-lost-on-restart.md` — direct follow-on
  report: a Debug Tree color/thickness edit was silently lost on editor restart. Root
  cause: edits only ever wrote into the transient `RuntimeConfigs` singleton, never
  synced into the config asset or marked it dirty until the user manually ran
  `Nexus.Mapping.SaveConfig` (which nothing prompted for). Fixed by binding
  `DetailsView`'s `OnFinishedChangingProperties` to sync+dirty-mark the moment a Debug
  category edit finishes - data-loss prevention only, not undo (that's still Phase 26a).
- `2026-08-10/bug-fixed/debug-details-panel-dangling-pointer-crash.md` — the fix directly
  above caused a real, reproducible `EXCEPTION_ACCESS_VIOLATION` (user reported the full
  callstack). Root cause: `SaveRuntimeConfigsToConfigAsset` seeding every never-touched
  category grew the `RuntimeConfigs` `TMap`, which can reallocate its backing storage and
  invalidate every previously-handed-out pointer into it - including the Details panel's
  own binding to the category just edited. Fixed by switching `RuntimeConfigs` to
  `TMap<FName, TUniquePtr<FNexusDebugRenderConfig>>` - growing the map now only moves
  small handles, never the owned struct, so any outstanding raw pointer stays valid. Same
  class of bug V5's own `PostEditUndo()` crash history (quoted in `phase-26a.md`) already
  warned about, reproduced in a new form the same day it was written down.

- `2026-08-10/feature-add/phase-45-46-activation-type-registry-and-debug-viz.md` — Phase
  45 (`FNexusActivationTypeRegistry`, `FProperty`-reflection-driven sub-point discovery
  over two dummy payload structs) + Phase 46 (`IsAlwaysDraw`/`SupportsAlwaysDraw` opt-in
  always-draw dispatch path). Real Activation Point storage still doesn't exist — both
  phases proven against the dummy types only.
- `2026-08-10/feature-add/phase-47-spatial-grid-index.md` — `FNexusSpatialGridIndex`, a
  plain-C++/UObject-free uniform-grid spatial index (`Build`/`QueryNearby`) plus a
  benchmark console command, proven against simulated-scale synthetic data (no real
  Activation Point positions exist yet to index for real).
- `2026-08-10/research/phase-48-itf-reachable-without-custom-mode.md` — resolves Phase
  48's own required first question: the Interactive Tools Framework IS reachable without
  a custom `UEdMode`, via `ILevelEditor::GetEditorModeManager().GetInteractiveToolsContext()`.
  `13-v6-gizmo-system.md`'s "Editing flow" section updated accordingly. The rest of Phase
  48 (actual gizmo tool/drag/write-back) was not attempted — real interactive-viewport
  code deserves a dedicated in-editor-testable pass, not a blind tail-of-session
  implementation.
- `2026-08-10/research/self-closed-highway-start-end-markers-investigated.md` — user-
  reported bug: a self-closed highway (loop with one branch) shows Start/End debug
  markers stacked on its own junction point. Root cause: `FNexusMapping::MapHighways`'s
  Pass 1 walk can return to its own starting point (`chain[0] == chain.Last()`) but
  `BuildHighwayFromChain` hardcodes `isClosedLoop=false` for every Pass-1 chain
  regardless — the Debug renderer's own `IsClosedLoop` guard is correct and unaffected.
  Fix designed (flip the boolean + strip the duplicated boundary point to match Pass 2's
  own convention) but **not implemented** — available for pickup as a follow-up task.
- `2026-08-10/research/editor-shutdown-crash-live-coding-new-reflected-types.md` —
  **ROOT CAUSE CONFIRMED, own `## Correction` section, same day.** Original report (an
  `EXCEPTION_ACCESS_VIOLATION` in `FRenderResourceList::ForEachReverse` during editor
  shutdown) turned out to be a SECONDARY/downstream symptom — the real, earlier failure
  (found once the user supplied `Saved/Logs/NexusFramework.log`) is
  `NexusFrameworkEditor.dll` failing to load at all: `Assertion failed: FoundPackage
  ... Code not found for generated code (package /Script/NexusFrameworkEditor)`,
  `StartupModule()` never runs. Root cause: `NexusActivationDummyTypesRegistration.cpp`'s
  two `FNexusActivationTypeAutoRegister` globals (Phase 45) call `::StaticStruct()` as a
  constructor ARGUMENT — i.e. during DLL static initialization, before `StartupModule()`,
  unlike every other static-registration global in this codebase. **Experimentally
  confirmed**: commented out both globals, rebuilt, user relaunched cold — loads
  successfully. The original "Live Coding hot-patch" hypothesis is superseded (disproven
  as the primary cause, though not necessarily unrelated). **Currently disabled, not
  fixed** — Phase 45's dummy-type registration is non-functional until a real fix (lazy
  `PayloadStructType` resolution) lands; see
  `agent-todos/ready-for-review/engine-crash-after-adding-new-phase-development-phase-43-49.md`.

- `2026-08-10/bug-fixed/phase-tracker-lettered-phase-id-collision.md` — every lettered
  phase file (`20a`/`26a`/`30a`/`40a`/`41a`/`60a`/`80a`) was silently unreachable through
  the phase-tracker's status dropdown/content popup - both used the non-unique numeric
  `n` field (`"30a"` and `"30"` both report `n: 30`) as the API routing key, so any click
  on e.g. Phase 30a actually operated on `phase-30.md` instead. Found live when the user
  tried to advance Phase 30a and got Phase 30's own Complete-lock error back. Fixed by
  routing on each phase's already-unique `id` field instead.
- `2026-08-10/feature-add/phase-43-44-streaming-cells-and-validation-gate.md` — Phase 43
  (new `FNexusStreamingCellResolver`, `FNexusState.DataLayerAssetName`; Static mesh
  package paths and Instanced `ANexusGeneratedInstancedMeshHost` actors now grouped per
  resolved streaming cell, with best-effort real World Partition Data Layer assignment
  via a new `DataLayerEditor` module dependency) + Phase 44 (`NexusGenerationValidation.h`
  finally got its `.cpp` — unclassified-object + Phase 43 streaming-consistency checks,
  folded into the Diagnostics panel as a fourth stage). Deliberately stopped the batch
  here rather than jumping to Phase 48 (Gizmo) — that phase's own prior progress note
  already flags it as needing a dedicated in-editor-testable pass, and Phase 49/50+
  explicitly depend on it signing off first.
- `2026-08-10/bug-fixed/highwaypoint-connectedhighwayids-never-populated.md` — user
  report: `Nexus.Generation.DumpStreamingCellAssignment` showed every real HighwayPoint
  with "0 connected Highway(s)". Root cause: `FNexusHighwayPoint::
  RecomputeConnectedHighwayIds` is only ever called by one unrelated Phase 18 debug
  command, never by `MapHighways` — the field is silently empty on
  `config.HighwayPoints` for every real map. Fixed the two Phase 43/44 call sites to
  derive the same info live from `config.Highways`' own `OrderedPointIds` instead of
  trusting the stale field; the wider fix (a real call site inside `MapHighways`) is
  still open. **Also records two bigger, pre-existing gaps found in the same pass**: the
  Hierarchy tree panel is still 100% hardcoded placeholder data (never wired to real
  config data, at any point in this project's history), and there is currently no
  console command or working UI to set `HalfWidth`/`LaneWidth`/etc. on a real Highway/
  City/State at all — which makes `Nexus.Generation.GenerateHighwayMeshes` produce 0
  meshes on any real map today, not a Phase 41/43 bug.
- `2026-08-10/others/phase-status-fixed-line-format-refactor.md` — every phase file's
  `## Status` section changed from a single free-form sentence to a fixed-line block
  (stage keyword + one dated field per stage, dates permanent once stamped instead of
  overwritten on each transition) — see `09-development-rules.md` rule 12 for the exact
  new format. `build.js`/`server.js` now share one parser/serializer
  (`parseStatusBlock`/`serializeStatusBlock` in `build.js`) instead of each keeping its
  own regex. All 108 existing phase files migrated same-day (start-fresh: only each
  phase's current stage got its date carried over, earlier stages left blank).
- `2026-08-10/feature-add/phase-48-gizmo-integration.md` — Phase 48 (Activation Point -
  Gizmo Integration): the always-active `UNexusActivationGizmoTool` (manual ray-vs-sphere
  selection against `FNexusActivationSubPointResolver`'s resolved sub-points, since no
  `HHitProxy`/component exists per debug marker), standard `UCombinedTransformGizmo`/
  `UTransformProxy` for the drag itself, undo/redo via `UTransformProxy`'s own built-in
  transaction integration. Also promoted Phase 46's session-only test list to a shared
  `FNexusActivationPointTestStore` and taught its renderer to draw one marker per
  resolved sub-point (previously only the base offset), so the array case has something
  real to click.
- `2026-08-10/feature-add/hierarchy-panel-real-data-create-delete.md` — direct user
  request (not a `/TODO` phase pickup): the Hierarchy panel's right-click menu only had
  Phase 04's stubbed Delete/Rename/Focus against hardcoded placeholder rows, no Create at
  all. Wired the tree to real State/City/Highway/HighwayPoint data with working Create
  State/Create City (auto-named "New City N", no dialog — the existing Details panel is
  where the user actually names it), Delete (unassigns members, never cascade-deletes),
  Assign-to-State/Assign-to-City submenus, and a generic `FNexusMapping::
  EnsureHierarchyHasDefaults` guarantee so deleting every State/City auto-recreates a
  default one (State/City only — Highway is Landscape-derived, deliberately excluded).
- `2026-08-10/feature-add/v6-ui-hierarchy-schema-improvements.md` — direct user
  request, same day, building on the Hierarchy panel record above: split
  `SNexusFrameworkPanel` into three independently dockable tabs (Hierarchy, Details,
  Diagnostics — cross-tab selection now mediated through `UNexusFrameworkSubsystem`
  instead of a direct same-object call), Debug Tree collapsed-by-default under one
  synthetic "Debug" root, a resizable ~45/55 Hierarchy/Debug-Tree splitter (only
  meaningful once each tab owns its own bounded height), removed the top-level
  "Unassigned Highway" group in favor of `FNexusMapping::
  AdoptUnassignedHighwaysIntoFallbackHierarchy` (CityId-only reassignment into a
  reused "Default State/Default City" pair — never touches Highway topology), a
  consistent "Name (Code)" tree-label convention, new `FNexusHighwayPoint` fields
  (Description/bHasCrossWalk/bHasTrafficLight/CategoryMask/SubCategory), a real
  bit-shifted `ECategories` bitmask (fixes V5's own `ENexusPointTarget` sequential-value
  bug), a locked-band `ESubCategory` enum, and new Mapping-stage validation checks
  (first use of Warning severity in `ValidateMappingStage`, previously Blocking-only).
  Confirmed directly (not just inferred) that Live Coding blocks `Build.bat` for ANY new
  `UENUM`/`USTRUCT`/`UCLASS` while the editor is running, not just a new `.cpp` file —
  see that record's own Important Notes; related to but distinct from the
  editor-shutdown-crash finding referenced below.

- `2026-08-11/bug-fixed/activation-point-debug-on-freeze-investigation.md` — user report:
  Debug ON + adding one ActivationPoint freezes 1-3s. Exhaustive static trace (Agent
  Testing Policy — no editor access) found no Debug-conditional branch anywhere on the
  create path; two real-but-unproven-as-the-cause inefficiencies documented (duplicate
  `PublishHierarchySelection` republish, `BuildHierarchyTreeFromConfig`'s full O(N)-ish
  rebuild), neither fixed pending real trace numbers. Added unconditional
  `Nexus Perf Trace:` timing/call-count instrumentation
  (`Debug/NexusDebugPerfLog.h`, new shared header) so a real Debug-OFF-vs-ON A/B run
  produces comparable numbers. Also fixed a genuine Unity-build `LogIfSlow` collision hit
  along the way.
- `2026-08-11/bug-fixed/landscape-segments-freeze-cache-hardening.md` — direct follow-up:
  user asked for an explicit architecture hardening pass on `FNexusDebugRenderSnapshot`
  (Start/End Location/Rotation/Tangent cached per segment, `Read-only debug cache...`
  markers, confirm renderers/refresh/ActivationPoint-isolation/Runtime-export-isolation
  all hold). Investigation confirmed all of those were already true except the explicit
  per-segment Start/End Location/Rotation fields, which were added (struct-to-struct copy
  from already-resolved Point data, no new Landscape read). **Flags two real, unfixed
  remaining suspects** for the freeze itself: the 0.25s fingerprint poll runs regardless
  of Debug visibility, and `Refresh()` rebuilds the full `Segments` array (Landscape read
  + Hermite sampling) whenever it runs at all, with no visibility gate the way
  `JunctionType` already has — available for pickup once real in-editor trace numbers
  confirm `Refresh()` itself (not Slate/tree rebuild) is the actual cost.

- `2026-08-11/feature-add/nexus-performance-profiler-panel.md` — direct follow-up: the
  cache-hardening pass above did not resolve the user's reported freeze (Debug ON +
  Add City/State/Activation causing >50% CPU, 5-15s hangs, memory spiking 4-5GB→20+GB→
  back to baseline), so the user asked for a purpose-built dockable "Nexus Performance
  Profiler" panel instead of further guessing. New `FNexusProfiler` (hierarchical
  instrumenting profiler, `NEXUS_PROFILE_SCOPE`/`_DYNAMIC` macros driving both a custom
  call tree AND real Unreal Insights events) + `SNexusProfilerPanel` (Start/Stop/Clear,
  9-column sortable TreeView) registered as a fourth Nomad tab alongside Hierarchy/
  Details/Diagnostics. Instrumented Tick, Debug refresh/rebuild/render (sub-scoped to
  match this session's own `BuildCityDebug`/`BuildHighwayDebug`-style breakdown request),
  City/State/ActivationPoint creation, Landscape queries, Mapping reconciliation, tree/UI
  refresh, property/selection-changed callbacks. **Memory reporting is honest, not
  fabricated** — no allocator hook (explicitly ruled out by the user), just process-wide
  `FPlatformMemory::GetStats()` samples at scope entry/exit/peak, documented as such in
  both the record and the panel's own column tooltips. No freeze diagnosis yet — this is
  the tool for the user's own next manual repro run (Agent Testing Policy). **Has two
  same-day `## Follow-up` sections**: Timeline/Stall Diagnostics (per-second telemetry,
  direct `World->LineBatcher` inspection, GC event timing, raw Tick/Dispatch ratio
  counters) and an editable Time Range + Interval/Grouped Bucket second TreeView (isolate
  an exact window, slice it into buckets, compare methods/counters before/during/after a
  stall bucket) — both built on a new parallel per-call timestamp log that never changes
  what the existing aggregate CPU tree records or how it computes its numbers.
- `2026-08-11/bug-fixed/long-background-freeze-batchedlines-accumulation.md` — first real
  data from the instrumentation above: a live capture showed `BatchedLines.Num` hit
  1,196,120 (~33x the ~35k steady state) in the session's first 3s bucket, then dropped to
  0 by the next bucket alongside a +680MB process memory jump — direct evidence (not just
  the engine-source-derived hypothesis) for "Nexus keeps submitting debug lines every
  editor tick regardless of world-tick/foreground state, backlog gets flushed in one shot."
  Correlational, not yet fully proven causal — pending a Stall-list (`Copy Full Details`)
  cross-reference to confirm the exact gap duration lines up.
- `2026-08-11/research/pdi-debug-rendering-backend-v0-v1-v5-reference.md` — **design
  proposal only, nothing implemented.** User concluded the architecture itself (not scale)
  is the freeze's root cause and asked for the `DrawDebugLine`/`ULineBatchComponent`
  backend to be replaced with a V0-style PDI renderer. Investigated sibling projects: V0
  has a real, working precedent — a SECOND, toolkit-less, always-active `FEdMode`
  (`FNexusRoadGraphAlwaysDrawEdMode`) whose only job is a `Render(view, viewport, pdi)`
  callback issuing raw `PDI->DrawLine` calls (no persistent array, cannot accumulate);
  V1 has no PDI/EdMode at all (not a useful reference); V5 uses the same
  `DrawDebugLine`-every-Tick mechanism V6 does (confirms the shared lineage risk, not a
  fix to borrow). Verified from UE 5.8 engine source that a TOOLKIT-LESS `FEdMode`
  (`UsesToolkits()` defaults `false`, base `Enter()` never touches `FToolkitManager`)
  cannot hit the `ToolkitManager.cpp` assertion V6's Phase 02/03 already fixed once — a
  structurally different, safe pattern, not a reintroduction. Proposed substitution:
  new hidden toolkit-less mode as the sole PDI source; split
  `UNexusFrameworkSubsystem::Tick()` so cache refresh stays on Tick while drawing moves to
  a new `Render()`-driven method (forced by PDI's own Render()-only validity, and what
  actually fixes the freeze — Render() never fires while backgrounded); `FNexusDebugPrimitives`'s
  5 functions keep their exact signatures, swapping internals to the engine's own
  PDI-equivalent free functions (`DrawWireBox`/`DrawWireSphere`/etc., already shipped, no
  new geometry math) with a `DrawDebug*` fallback when no PDI is active. Zero changes
  proposed to any category renderer, cache/LOD, gizmo, or the profiler's own code.
- `2026-08-11/bug-fixed/pdi-debug-rendering-backend-implemented.md` — **implemented**
  (user explicitly authorized this in a later session) the substitution proposed in the
  research record directly above, essentially verbatim. New toolkit-less, hidden
  `FNexusDebugDrawEdMode` (ported from V0's `FNexusRoadGraphAlwaysDrawEdMode`) registered/
  kept-active from `FNexusFrameworkEditorModule` via V0's own `OnPostEngineInit`/
  `OnLevelEditorCreated`/`OnEditorModeIDChanged` pattern (with the `IsEngineExitRequested()`
  shutdown guard); `UNexusFrameworkSubsystem::Tick()` now does state/cache maintenance
  ONLY, with the old drawing calls (`RenderDiagnosticsOverlay`/`DispatchDebugRenderers`/
  `LabelOverlay->UpdateLabels`) moved verbatim into a new `RenderDebugPrimitives(pdi)`
  called only from the new mode's `Render()`; `FNexusDebugPrimitives`'s 5 functions keep
  their exact signatures, routing through a new `FScopedActivePDI`-gated ambient PDI
  pointer to `DrawOrientedWireBox`/`DrawWireSphere`/`DrawWireCapsule`/`DrawDirectionalArrow`
  (falling back to the original `DrawDebugLine`/etc. only when no PDI is active). Static
  grep after the change found exactly 5 remaining `DrawDebug*` call sites, all inside that
  intentional fallback branch — no migration misses. Build succeeded (one deprecation
  warning fixed: `FCoreDelegates::OnPostEngineInit` → `GetOnPostEngineInit()`). No category
  renderer, Debug Tree/config, cache/LOD/fade/culling, Highway/Lane/Sidewalk/Junction/
  Mapping/Activation logic, profiler, or gizmo code was changed. In-editor manual
  verification (BatchedLines.Num staying near-zero, no background-freeze, all categories
  still render correctly) is still pending from the user — this agent cannot launch/drive
  the editor (AGENT-RULES.md).
- `2026-08-11/bug-fixed/pdi-debug-rendering-backend-startup-crash-fix.md` — the manual
  verification above hit a real editor STARTUP crash: `FNexusFrameworkEditorModule::
  StartupModule()` called the global `GLevelEditorModeTools()` free function directly
  (copied from V0's own `StartupModule()` verbatim), which lazily constructs a whole
  `FLevelEditorModeTools`/`UModeManagerInteractiveToolsContext` on first access — too
  early in V6's own startup order, causing an access violation inside the engine's own
  `UModeManagerInteractiveToolsContext::Initialize`. NOT evidence against the PDI/passive-
  EdMode architecture — an initialization-order bug in registration/activation only,
  fixed by never calling `GLevelEditorModeTools()` anywhere in the module: reused V6's own
  already-proven-safe `FNexusLandscapeModeExtension::RegisterToFirstLevelEditor()`
  accessor pattern instead (`FLevelEditorModule::GetFirstLevelEditor()` →
  `ILevelEditor::GetEditorModeManager()`). `StartupModule()` now only registers the mode
  and binds two delegates (`OnLevelEditorCreated`, `GetOnPostEngineInit()`); all real
  `ActivateMode`/`DeactivateMode`/`IsModeActive` access moved into a new
  `TryActivateDebugDrawMode()`, reachable only from those delegates or a guarded
  `OnEditorModeIDChanged` re-assertion (recursion-guarded against its own mode's events).
  Grepped every remaining `GLevelEditorModeTools()` call site in Nexus post-fix (3, all
  pre-existing/unrelated — 2 in `SNexusDetailsPanel.cpp`, 1 in an automation test — all
  confirmed to only run once the editor/level-editor is already fully up). Build
  succeeded with zero warnings. In-editor re-verification still pending from the user.
- `2026-08-11/research/gizmo-scalability-audit-selection-driven-architecture.md` —
  user set a mandatory, project-wide requirement (before Phase 49 is picked up): gizmos
  must be strictly selection-driven at 99,999+-object scale — never one gizmo per
  object, O(1) gizmo creation, no full-object scan every gizmo frame, drag touches only
  the selected object's data. Read-only audit (no code changed) of the already-built
  Phase 48 gizmo tool (`UNexusActivationGizmoTool`/`FNexusActivationGizmoManager`) found
  it already satisfies every rule — single `ActiveGizmo`/`ActiveTransformProxy` pair
  created only on selection, destroyed on deselect/reselect, no per-frame scan,
  drag write-back touches exactly one point with no blanket cache invalidation. One
  forward-looking gap flagged (not a rule violation): click-time selection
  (`FindClosestSubPointHit`) is an O(N) linear scan over every selectable/drawn
  Activation Point, paid once per click not per frame — Phase 47's already-built
  `FNexusSpatialGridIndex` is the natural fix once object counts warrant it. Requirement
  formalized as a new mandatory section in `13-v6-gizmo-system.md` and cross-referenced
  in `phase-49.md` (per that phase's own "document friction" completion criterion) so it
  governs every future object-type gizmo phase automatically.
- `2026-08-11/feature-add/editor-usability-select-mode-gizmo-sync-policy.md` — Phase 49
  manual testing found real interaction conflicts (Nexus gizmo interactive at the same
  time as Landscape Mode's own sculpt/spline tools) and unwanted implicit full re-syncs.
  10-point investigation + fix: gizmo interactivity now follows standard Select Mode
  (`FEditorModeTools::IsDefaultModeActive()`) instead of Landscape Mode
  (`FNexusActivationGizmoManager::Activate/Deactivate` made idempotent, driven by a new
  `FNexusLandscapeModeExtension::RefreshGizmoActiveState` on every mode change) — the
  gizmo tool itself gained static "remembered selection" fields so `Select -> Landscape
  -> Select` preserves the selection across the tool's own Setup/Shutdown teardown
  instead of losing it. Nexus tabs no longer auto-close leaving Landscape Mode and are
  now independently Window-menu-openable. The 2 implicit full-`RunAutomaticEnableFlow`
  triggers (Landscape Mode entry, Hierarchy panel self-heal) were replaced with
  load-only (`FNexusConfigAssetIO::LoadOrCreateConfigAsset`) — the pre-existing "Re-sync
  from Landscape" button keeps the full flow, unchanged, already mode-independent. New
  `UNexusFrameworkSubsystem::HandleObjectTransacted` (bound to `FCoreUObjectDelegates::
  OnObjectTransacted`, confirmed via V5's own prior research as the only reliable
  viewport-drag-on-a-spline-point signal) does narrow, event-driven `MarkRepresentationDirty()`
  on a live control-point edit — type-checked against `ULandscapeSplineControlPoint`
  first, which structurally prevents a Nexus-driven config edit from ever looping back
  as a false "Landscape changed" signal. Gizmo visual+hit size increased
  (`ACombinedTransformGizmoActor::SetActorScale3D`, confirmed via engine source to be a
  safe render-only multiplier; centralized in one `GNexusGizmoVisualScale` constant) and
  click tolerance widened (`GSubPointPickRadius` 40→100) without touching the rendered
  marker size or any authored data. Confirmed by grep (zero `ActivationPoints` touches
  anywhere in Mapping reconciliation code) that authored offsets were already
  structurally immune to any form of Landscape re-sync, old or new. Build succeeded,
  zero warnings. Full manual acceptance testing still pending from the user.
- `2026-08-11/feature-add/phase-49-activation-point-smoke-test-real-gizmo-editing.md` —
  Phase 49 implemented: closed the last flagged gap ("gizmo-driven edits of a real point
  are not yet possible, only of the session-only test store"). `NexusActivationGizmoTool.
  {h,cpp}` only — `FindClosestSubPointHit` now also scans real, persisted
  `UNexusConfigAsset::ActivationPoints` (gated identically to the renderer), tagging
  which source a hit came from; `HandleGizmoTransformChanged` branches to call
  `UNexusConfigAsset::Modify()` (confirmed via engine source to correctly participate in
  the SAME real transaction the ITF gizmo drag already opens — real undo/redo, one step
  per drag, no second hand-rolled transaction) + the existing generic
  `SetSubPointOffset` for real points, leaving the test-store path byte-for-byte
  unchanged. No renderer/persistence/resolver changes needed — both were already wired
  from 2026-08-10 prerequisite work; this pass was genuinely one gap, not a redesign.
  Gizmo instance-count architecture (verified compliant with the 99,999+-object
  requirement earlier the same day) is unchanged — still exactly one gizmo regardless of
  source. Build succeeded, zero warnings. `phase-49.md` moved to `Ready for Review`;
  full manual round-trip + selection-responsiveness verification steps recorded there,
  still pending from the user (this agent cannot launch the editor).
- `2026-08-11/feature-add/editor-proxy-actor-pool-near-camera-interaction.md` — same-day
  follow-up: the custom gizmo doesn't feel like a normal UE Actor (grows huge at
  distance), so real, persisted ActivationPoints' base-object editing moved to a new
  Layer-B system — `FNexusEditorProxyPool`/`ANexusEditorProxyActor`, a small (default
  max 100), lazily-grown, reusable pool of transient, editor-only native Actors with
  standard UE selection + transform widget, spatially queried via Phase 47's
  `FNexusSpatialGridIndex` against real config data only. Write-back reuses the native
  viewport drag's own already-open transaction (one undo step per drag, not per
  `PostEditMove` callback); a selected/pinned proxy is excluded from every eviction pass;
  world/map switches fully release all bindings (`FWorldDelegates::OnWorldCleanup`/
  `FEditorDelegates::MapChange`). New spec:
  `project-specifications/16-v6-editor-proxy-actor-system.md`. This **reverts** Phase
  49's real-ActivationPoint gizmo widening (previous bullet) — `NexusActivationGizmoTool`
  is back to `FNexusActivationPointTestStore` (test-store-only) data, reserved for
  future specialized sub-point editing (Phase 50+) — see `phase-49.md`'s own appended
  Correction section and `13-v6-gizmo-system.md`'s own appended revision note. Build
  succeeded, zero warnings (cold build — Live Coding was active and this pass adds new
  `UCLASS` types, a documented Live Coding crash risk in this project). Static audit
  (grep-verified) confirms all three explicit safeguards the user added mid-task:
  real-object-backed spatial index, single transaction per drag, and pinned-proxy/
  world-teardown safety. Full manual acceptance testing (14-point list: far camera,
  proxy reuse, native selection, undo/redo, Landscape Mode gating, ...) still pending
  from the user (this agent cannot launch the editor).
- `2026-08-11/feature-add/phase-50-traffic-light-data-model.md` — Phase 50 (picked up
  via `/TODO`, after `node html-docs/build.js` fixed a stale `PHASE-STATUS.md` that
  hadn't been regenerated since Phase 49 moved to `Ready for Review` earlier the same
  day): `FNexusTrafficLightActivation` (`Pole`/`VehicleLED`/`PedestrianLED`, three
  `FNexusSubPointOffset` fields, nothing else — `ControlledLaneIds`/`ControlledRoadIds`/
  `SignalGroup` deliberately left for `phase-51.md`/`phase-52.md`), registered via Phase
  45's type registry. Confirmed both the debug renderer and the gizmo tool's test-store
  click-test are fully generic over the registry — registering the type alone makes it
  automatically debug-renderable and gizmo-draggable, zero new renderer/gizmo code
  needed. Caught and fixed a real bug before finalizing: `DefaultDebugCategory` is read
  by the gizmo's click-test (`IsSelectable`/`CanSupportGizmo` gate) but NOT by the
  renderer — a first-draft dedicated `Runtime.TrafficLight` category (not yet registered,
  that's Phase 53's job) would have rendered fine but left the type gizmo-unselectable,
  silently breaking this phase's own "independently editable" criterion; fixed by
  reusing the existing `Runtime.ActivationPoints` category instead. Added
  `Nexus.Representation.AddTestTrafficLight` (session-only test-store command, same
  precedent as the Phase 45 dummy types) and a full field-by-field written comparison
  against V5's `FNexusDynamicInteractable` confirming a strict superset. Real
  `UNexusConfigAsset` persistence for specialized payloads remains explicitly open, not
  decided by this phase. Build succeeded, zero warnings. `phase-50.md` moved to `Ready
  for Review`; in-editor round-trip verification (render + independent gizmo-drag) still
  pending from the user.
- `2026-08-11/feature-add/nexus-not-ready-ready-initialization-state-machine.md` —
  ad-hoc `agent-todos` task ("Refactor Nexus initialization flow"): replaced every
  remaining implicit config-load trigger (Landscape-Mode-entry load, Hierarchy-panel
  self-heal — both left over from earlier the same day's passes) with an explicit
  Not-Ready/Ready state machine (`UNexusFrameworkSubsystem::IsNexusReady`/
  `SetNexusReady`/`OnNexusReadinessChanged`) that resets to Not Ready on
  `FEditorDelegates::OnMapOpened` and becomes Ready only via the explicit "Re-sync from
  Landscape" button — directly fixing the previously-unaddressed
  `agent-todos/requirement-pending/when switch landscape still trigating old
  landscape.md` bug (opening a second level silently kept the first level's config
  active/editable, zero map-change handling existed anywhere before this). Also removed
  the last two production `GLevelEditorModeTools()` call sites in the module
  (`SNexusDetailsPanel.cpp`, replaced with `IsNexusReady()`), fixing the separate
  `agent-todos/requirement-pending/details panel only enable in landscape mode.md`
  report. Gizmo/proxy-pool interactivity now requires Select Mode AND Ready together.
  Confirmed by re-reading `FNexusMapping.EnableFlow.cpp` in full that Mapping
  reconciliation never touches authored ActivationPoint offsets, and that
  `FNexusConfigAssetIO::LoadOrCreateConfigAsset` returns the same config identity across
  a same-level Re-sync (no proxy-pool-specific fix needed for that case). Build
  succeeded, zero warnings. Task moved `agent-todos/active/` → `ready-for-review/`.
  In-editor verification (5-step manual sequence) still pending from the user.

- `2026-08-11/bug-fixed/map-switch-reset-missed-blank-new-level.md` — direct follow-up:
  the Not-Ready/Ready state machine's own manual-verification checklist ("open a second
  level, confirm Not Ready re-triggers") came back partially failing — old debug/rendered
  data could still linger after a switch. Engine-source read (`FileHelpers.cpp`/
  `LevelEditorSubsystem.cpp`/`EditorServer.cpp`) found the real gap:
  `ULevelEditorSubsystem::NewLevel()` (File > New Level > Empty Level) calls
  `UEditorEngine::NewMap()` directly and never broadcasts `FEditorDelegates::OnMapOpened`
  — the state machine's only reset trigger — only `FEditorDelegates::MapChange
  (MapChangeEventFlags::NewMap)`. Every other requirement in the user's new, more
  detailed "Bulletproof Nexus Level/Map Switch Reset" spec was traced end-to-end and
  found already correctly handled by the prior task. Fixed by also binding `MapChange`
  and resetting on its `NewMap` flag, sharing one `ResetForMapSwitch()` helper with the
  existing `OnMapOpened` handler. **Flags an explicit, un-implemented scope conflict**:
  the new task's items 8/9/11 (auto-load config on switch, before any user click) directly
  contradict the state machine's own deliberate "never implicitly initialize Nexus"
  design — left to the user to decide, not silently picked either way.

- `2026-08-11/bug-fixed/resync-proxy-gizmo-interaction-not-initializing.md` — user report:
  Editor Proxy Actors/gizmo don't become interactive after clicking "Re-sync from
  Landscape," only after cycling Landscape Mode on and off. The already-built
  `shouldBeInteractive = isSelectModeActive && IsNexusReady()` gate
  (`FNexusLandscapeModeExtension::RefreshNexusInteractionState`) was architecturally
  already correct — the real suspect found was that its `OnNexusReadinessChanged`
  subscription (`NexusReadinessChangedHandle`) was a single best-effort bind attempt at
  `OnLevelEditorCreated` time with no retry, the same class of
  subsystem-not-resolvable-yet ordering fragility this module already hit once before
  (`pdi-debug-rendering-backend-startup-crash-fix.md`). **Not empirically confirmed**
  (this agent cannot launch the editor) — fixed defensively by mirroring this codebase's
  own already-proven `TryActivateDebugDrawMode` retry pattern (idempotent bind, retried
  from both `OnLevelEditorCreated` and a new `OnPostEngineInit`), which cannot regress
  anything even if the hypothesis is wrong. Two other unconfirmed suspects documented for
  next-pass follow-up if the symptom persists.
  **Correction 2026-08-12** — the symptom persisted; that fix's hypothesis was wrong. The
  real gate: `FNexusEditorProxyPool::TickUpdateNearbyProxies` hard-`return`s whenever
  `GCurrentLevelEditingViewportClient` (only updated by real mouse-enter/focus on a 3D
  viewport) is null — legitimately still null right after opening a project and clicking
  a docked-panel button without ever touching the viewport, exactly this bug's own repro.
  Fixed with a `GEditor::GetLevelViewportClients()` fallback + diagnostic logging (see
  the record's own appended `## Correction — 2026-08-12` section). Higher confidence than
  the original fix, still not empirically proven live.


### 2026-08-22 — Phases 73–78 (object-type completion + the Gizmo/UI polish block)

Six phases in one session, user-directed ("UI related, first priority"), taken in roadmap
order because Phases 76/79 define their audit scope as "across all object types built so far
(50–75)" — running the UI phases first would have produced an audit needing a re-run.

- `2026-08-22/feature-add/phase-73-advertisement-activation-point.md` — `FNexusAdvertisementActivation`
  (ContentId/PlaylistId), a base-offset-only type, plus paired
  `Infrastructure.AdvertisementBoard` (Static) / `…Content` (RuntimeActivated) debug leaves on
  one shared anchor. `Nexus.Representation.VerifyAdvertisementClassification` proves the
  independent classification.
- `2026-08-22/feature-add/phase-74-tv-interactive-screen-activation-point.md` — `FNexusTvActivation`;
  closes V5 feature parity (all four `ENexusDynamicInteractableType` values now representable
  through the registry — checked against the LIVE registry by
  `Nexus.Representation.VerifyV5InteractableCoverage`, not asserted in prose). Records why
  "activation distance override" got NO payload field of its own: the base struct already is
  that field, and duplicating it is the shape Phase 93's duplicate-data audit exists to catch.
- `2026-08-22/feature-add/phase-75-onboarding-checklist-proof-five-types.md` — **all five**
  remaining named types (Hospital, Police Station, Petrol Station, Charging Station, Service
  Garage), zero framework-file edits. Closes `v6-phase-verification.md` Section C item 2.
  **Read this one for its three reported framework gaps**, especially GAP 2.
- `2026-08-22/feature-add/phase-76-gizmo-viewport-widget-polish.md` — optional local-space
  grid/rotation snapping, Details-tab numeric precision entry for the gizmo-selected
  sub-point, `Nexus.Gizmo.AuditTypeConsistency`. Fixed a real stale-cached-anchor bug in the
  drag write-back.
- `2026-08-22/feature-add/phase-77-gizmo-undo-redo-hardening.md` — **four gaps found and
  fixed**, most seriously that undo records were addressed by transform PROXY rather than by
  data, so undoing after a selection change could write an old sub-point's transform into a
  DIFFERENT sub-point. Undo is now a data-addressed `FNexusSubPointOffsetChange`, one record
  per gesture, named per sub-point, no-ops suppressed. Also fixed: the Diagnostics panel had
  been validating NO Activation Points at all (empty array passed to
  `ValidateRepresentationStage`).
- `2026-08-22/feature-add/phase-78-gizmo-selection-inspection-panel-polish.md` — owning-hierarchy
  breadcrumb in the Details tab with click-through, which required adding the reverse
  selection leg (`SyncTreeSelectionToDetailsTarget`) that never existed; plus
  `Nexus.UI.AuditDetailsPresentation`.

- `2026-08-22/others/activation-point-payload-persistence.md` — **the keystone gap, closed.**
  `FInstancedStruct Payload` on `FNexusActivationPoint`; the test store collapsed onto the
  same field; a shared `FNexusActivationPointLocator` and `FNexusActivationPayloadReconciler`;
  registry-driven type submenu when creating a point; and the gizmo's real-point sub-point
  editing reinstated (real points transact against the config asset, session-only points keep
  the Phase 77 `FChange`). Chosen by the user over starting Phase 80 directly.

- `2026-08-22/bug-fixed/details-panel-dangling-binding-crash.md` — the Details panel bound an
  `IStructureDetailsView` to `&Array[i]` and never re-resolved it on add/remove. Three fixes;
  the durable finding is that **`SWidget::Paint` executes active timers nine lines before it
  calls `Tick`** — deferring paint-unsafe work to a one-shot active timer does not move it
  outside paint. The working fix notifies from the mutation
  (`UNexusConfigAsset::OnStructuralChange` + `FScopedStructuralChangeBatch`). Live task record:
  `agent-todos/ready-for-review/details-panel-dangling-binding-crash-on-entity-add-remove.md`.

All six phases compile clean against UE 5.8. **None are manually verified** — each record carries its
own "Manual verification the user should do" section, per `AGENT-RULES.md`.

Several records above have same-day `## Correction` sections appended after new
information came in (test results, user review, or — for Phase 02/03 — a full
architecture rework) — read the whole file, not just the top, per the append-only rule
(`CLAUDE.md`).

## Current open threads

- V6's physical repo root (`NexusFramework.uproject`) is a standalone Game project, same
  shape as V4 — not a redistributable `.uplugin`. See the Phase 01 record's Important
  Notes before assuming otherwise.
- Relationship/membership fields (Highway↔City, HighwayPoint↔Highway) were added by
  Phases 10-12 (2026-08-10) — see `2026-08-10/feature-add/phase-10-to-14-nexus-mapping.md`.
  `FNexusActivationPoint` is still not yet on any struct — Phase 21 adds it. Don't treat
  the current struct shapes as final until Phase 21 lands too.
- Phase 19 (2026-08-10) added `FNexusRepresentationGraph`, an in-memory O(1)-lookup
  container built FROM `UNexusConfigAsset` — see `2026-08-10/feature-add/
  phase-19-representation-graph.md`. It is not yet wired into any consumer; the actual
  read/write path used everywhere else (`FNexusMapping`, the console commands) is still
  `UNexusConfigAsset`'s own `TArray`s, unchanged by this phase.
- Phase 100's starting verification checklist (`UI Placement Correct`/`Smoke Test
  Complete`/`Overall Test Complete`) is explicitly provisional, not a locked spec — see
  `15-v6-verification-system.md`.
- No agent has verified the phase-tracker popup/modal/scroll-lock fixes in a real
  browser — only via `curl`/reading the code. If something still looks off, that's why.
- Phase 13/15's config-asset path changed 2026-08-10 (see
  `2026-08-10/feature-add/phase-13-config-path-refactor.md`) after those phases were
  already manually tested under the OLD path — a fresh `Nexus.Mapping.
  LoadOrCreateConfig` run against the new `<LevelFolder>/<LevelName>/NexusConfig` path
  hasn't happened yet.
- ~~`NexusFrameworkEditor` module-load crash — ROOT CAUSE CONFIRMED but NOT FIXED.~~
  **RESOLVED 2026-08-10.** Permanent fix (lazy `TFunction<UScriptStruct*()>`
  `PayloadStructTypeGetter` resolution) implemented, cold-built clean, and confirmed
  working in-editor by the user (opens, registry dump shows both dummy types, closes and
  reopens cleanly) — see `2026-08-10/research/
  editor-shutdown-crash-live-coding-new-reflected-types.md`'s second `## Correction`
  section. Both `NexusActivationDummyTypesRegistration.cpp` globals are re-enabled and
  live again. **Standing rule for all future phases**: a namespace-scope global's
  constructor must never eagerly call a reflected type's `StaticStruct()`/
  `StaticClass()` — defer via a lazily-resolved accessor instead.
- `FNexusMapping::MapHighways` Pass 1 can produce a chain with `chain[0] == chain.Last()`
  (a self-closed loop with one branch) but hardcodes `isClosedLoop=false` — see
  `2026-08-10/research/self-closed-highway-start-end-markers-investigated.md` for the
  root cause and designed-but-not-implemented fix. Available for pickup.
- Phase 43/44 (2026-08-10) are `Ready for Review` but functionally unverified beyond
  build + deterministic console-command checks — no real multi-State/multi-Data-Layer
  test map has been built yet, so streaming-cell grouping and the Generation validation
  gate have never run against real varied data. See `2026-08-10/feature-add/
  phase-43-44-streaming-cells-and-validation-gate.md`'s "Manual QA still required"
  sections (also duplicated in `phase-43.md`/`phase-44.md` themselves) before assuming
  either is proven. Phase 48 (Gizmo Integration) and everything after it (49, 50+) is
  still the next real roadmap work once 43/44 are QA'd — deliberately not attempted this
  batch, see that record's own reasoning.
- **The Hierarchy tree panel (`SNexusFrameworkPanel`) has never shown real data, ever.**
  It's 100% hardcoded `FNexusPlaceholderTreeItem` stub content from Phase 04, with no
  phase since having wired it to `UNexusConfigAsset`. There is also currently no console
  command or working UI to set `HalfWidth`/`LaneWidth`/`SidewalkWidth` on a real
  Highway/City/State — see `2026-08-10/bug-fixed/
  highwaypoint-connectedhighwayids-never-populated.md`'s Important Notes for the full
  finding. Until one of these is picked up, `Nexus.Generation.GenerateHighwayMeshes`
  will keep reporting 0 meshes on any real map, and manually adding/inspecting real
  City/State/Highway data means console commands only (`Nexus.Mapping.CreateCity`/
  `CreateState`/`AssignHighwayToCity`/`SetCityState`/`DumpGraph`), never the tree UI.
  **RESOLVED (Hierarchy tree half only) 2026-08-10** — see `2026-08-10/feature-add/
  hierarchy-panel-real-data-create-delete.md`: the tree now reads real State/City/
  Highway/HighwayPoint data with working Create/Delete/Assign UI actions and live
  Details-panel editing (Name/Code/Description, and every other field, including
  HalfWidth/LaneWidth/etc., are already generically editable there once a real row is
  selected — no separate UI needed for that part). `GenerateHighwayMeshes`'s own
  0-meshes symptom is otherwise unchanged — no map has been manually verified
  end-to-end through Generation using this new UI yet.
  **Further improved same day** — see `2026-08-10/feature-add/
  v6-ui-hierarchy-schema-improvements.md`: the Hierarchy tree is now its own
  independently dockable tab (`SNexusFrameworkPanel` itself was split into three —
  Hierarchy/Details/Diagnostics, see that record), never shows a top-level "Unassigned
  Highway" group anymore (auto-adopted into a fallback State/City instead), and every
  row shows a consistent "Name (Code)" label.
- Phase 51 (2026-08-12) added the first mechanism that binds an Activation Point's
  specialized PAYLOAD struct (as opposed to just the shared base struct) into the Details
  panel — `ENexusDetailsTargetMode::TestActivationPointPayload`, set by
  `UNexusActivationGizmoTool::SelectSubPoint`. It is **session-only-test-store-only** by
  design (mirrors the Gizmo tool's own current scope, see
  `16-v6-editor-proxy-actor-system.md`) — a REAL, persisted Traffic Light's
  `ControlledLaneIds` are still not reachable this way; specialized payload persistence
  for real config points remains the same open architecture question flagged since Phase
  46/49/50. See `2026-08-12/feature-add/
  phase-51-traffic-light-controlled-lane-road-references.md`. Also worth noting for
  anyone reading Phase 49's own audit record cold: that record describes making REAL
  config points gizmo-draggable, which was reverted the SAME DAY by the later Editor
  Proxy Actor Pool pass (`2026-08-11/feature-add/
  editor-proxy-actor-pool-near-camera-interaction.md`) — check current source
  (`NexusActivationGizmoTool.h`'s own header comment), not just the Phase 49 record, before
  assuming that behavior still exists.

- **Phase 55 ("Traffic Light — Runtime Compilation & Export") is `Blocked` (2026-08-12) —
  no Compilation stage/Runtime Schema (`FNexusRuntimeResult` etc.) exists anywhere in
  `Source/` yet; that's Phase 80-85's own scope, all numbered AFTER Phase 55.** See
  `2026-08-12/others/phase-55-blocked-runtime-compiler-not-built-yet.md`. The identical
  "Runtime Compilation & Export" phase exists for every other object type (City Light 59,
  Crosswalk 63, Bus Stop 68, Parking 72) and almost certainly hits the same block — check
  this dependency FIRST when picking any of those up, don't assume they're
  straightforward. Needs a user decision: resequence these five phases to after Phase 85,
  or explicitly authorize an early minimal Compilation-stage stub.

- **Phase 60a's pre-drafted Checkpoint Report (written 2026-08-10, before Phases 50-60
  were actually implemented) overstated Traffic Light/City Light as "complete through
  runtime export" — corrected 2026-08-12 after actually implementing 51-60 this session
  and finding Phase 55/59 are `Blocked`, not complete.** See
  `2026-08-12/others/phase-60a-architecture-review-correction.md` and `phase-60a.md`'s
  own appended `## Correction` section. Doesn't change the overall PASS WITH REQUIRED
  CHANGES/Continue decision. Flag for whoever picks up Phase 80a: that checkpoint's own
  "Runtime data pipeline" category can't honestly PASS until Phase 80-85 exists and
  55/59/63/68/72 are un-blocked.

- **Open decision for the user (2026-08-22, Phase 75 GAP 2): the Generation-side
  classification is still a CLOSED enum.** `ENexusStaticObjectType` +
  `FNexusGenerationClassificationTable::ResolveClassification` require edits to TWO framework
  files to classify the paired `Static` half of any new object type — the exact closed-enum
  pattern the Activation Point layer deliberately rejected
  (`12-v6-activation-point-system.md`'s "Type registry, not a closed enum"), still present one
  layer down. Phase 74 paid that cost for the TV pair; Phase 75 refused to pay it (its own
  zero-framework-edit rule) and reported it instead, so the five Services/Facilities types
  currently have no classifiable Static half. Cheap to fix now — a registry mirroring one that
  already exists — and paid again by every future object type if not. See
  `2026-08-22/feature-add/phase-75-onboarding-checklist-proof-five-types.md`.
- **RESOLVED 2026-08-22 — specialized-payload persistence.** (Was: "remains unresolved,
  flagged since Phase 46".) `FNexusActivationPoint` now carries an `FInstancedStruct Payload`,
  so real, persisted points hold their specialized payload and sub-points. The session-only
  test store was collapsed onto the same field, so test and real data use one identical
  mechanism. See
  `2026-08-22/others/activation-point-payload-persistence.md` and
  `project-specifications/12-v6-activation-point-system.md`'s "Payload persistence" section.
  **Note what this did NOT unblock**: the Runtime Compiler. Phases 55/59 stay `Blocked` and
  the export leg of 73/74/75 stays incomplete — no Compilation stage exists yet, which is
  Phases 80–85's own scope and always was a separate wall.

## Category guide

- `bug-fixed/` — investigations, root causes, crash/regression fixes, verification.
- `feature-add/` — new features, systems, tools, editor functionality, architecture.
- `research/` — engine/API/architecture investigation, experiments.
- `others/` — architecture decisions, project conventions, general history.

## Related systems

- `project-specifications/AGENT-RULES.md` — **standing agent policy, read before
  starting any work** (currently: Agent Testing Policy — no automated tests unless the
  user explicitly asks; added 2026-08-10 after the false-negative test detour recorded
  in this session's research record).
- `agent-todos/` — live task queue for work that isn't a whole roadmap phase. See
  `agent-todos/AGENT-TODO-RULES.md`.
- `project-specifications/phases/` — the 100-phase roadmap; each phase's own `## Status`
  line is authoritative for that phase's progress (see
  `project-specifications/09-development-rules.md` rule 12), not tracked here.
- `project-specifications/v6-phase-verification.md` — the architecture/coverage audit of
  the roadmap itself (done once, 2026-08-09, before any implementation started) — not an
  `ai-change-audits/` record because it predates any actual implementation work to audit.
