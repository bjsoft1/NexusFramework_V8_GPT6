# V6 Coding Standard — C++ Naming

## Status

**Authoritative — 2026-08-10.** A permanent, Git-tracked V6 project rule, on the same
"every agent must read this" footing as `AGENT-RULES.md` and
`v6-master-architecture.md`. Applies to all C++ in both modules (`NexusFramework`,
`NexusFrameworkEditor`), for every phase from this point forward, and is the target for
the existing-code cleanup pass logged in `ai-change-audits/` (see that record for
exactly which files were changed and why some were deliberately left as-is).

This document does not create a new phase and does not renumber or reorder any existing
phase, including Phase 30 — naming is a cross-cutting standard, not roadmap content.

## Naming rules

### Types / members / functions — PascalCase

```cpp
FullName
HighwayName
BuildHighway()
IsValid()
```

Boolean names MUST clearly use an approved semantic prefix — no bare adjective/noun,
and (see "Relationship to Unreal's own `b`-prefix convention" below) no `b` prefix
either:

```text
Is...
Has...
Can...
Should...
Was...
Were...
```

Examples:

```cpp
IsSuccess
HasHighway
CanGenerate
ShouldRender
WasGenerated
```

### Parameters / local variables — camelCase

Including `const`, `static`, and `constexpr` locals:

```cpp
void BuildHighway(const FString& highwayName)
{
    const int laneCount = 4;
    static int buildCount = 0;
    constexpr int defaultCapacity = 32;

    int laneIndex = 0;
}
```

### Global constants

```cpp
const int MAX_RETRY_COUNT = 3;
constexpr int DEFAULT_CAPACITY = 32;
```

### Static globals

```cpp
static int _BUILD_COUNT = 0;
static constexpr int _MAX_ITEMS = 100;
```

### Unreal Engine's own conventions still apply where UE requires them

This standard governs identifier CASE/PREFIX choices; it does not override anything UE
itself requires to compile/reflect correctly:

- Type prefixes (`F`/`U`/`A`/`I`/`E`/`T`) stay exactly as UE requires
  (`FNexusHighway`, `UNexusConfigAsset`, `ENexusJunctionType`, ...) — these are not
  "PascalCase violations," they're mandatory UE type-category markers layered under
  this standard's own PascalCase rule for the name that follows the prefix.
- `UPROPERTY`/`UFUNCTION`/`GENERATED_BODY()` and all other UHT-facing macros are
  unaffected.
- Reflected/Blueprint-exposed identifiers still follow the PascalCase rule above (a
  `UPROPERTY` boolean is exactly the "Types / members / functions" case, not the
  "parameters / locals" case) — but see "Serialization risk" below before renaming one
  that's part of an already-persisted asset type.

### Relationship to Unreal's own `b`-prefix convention

Epic's own house style prefixes boolean members with `b` (`bVisible`, `bIsClosedLoop`).
This project's standard explicitly replaces that with the `Is/Has/Can/Should/Was/Were`
semantic-prefix rule above — e.g. `bVisible` → `IsVisible`, `bIsClosedLoop` →
`IsClosedLoop` (drop the redundant double "Is"), `bSupportsGizmo` → `CanSupportGizmo`,
`bShowLabel` → `ShouldShowLabel`. This is a deliberate project-level deviation from
Epic's default, not an oversight — chosen because the semantic prefix reads correctly
in both member and function-return-value position without a second convention.

### Serialization risk — read before renaming a `UPROPERTY` boolean

A `UPROPERTY` field's C++ identifier IS its on-disk serialization key. Renaming one
without a redirect causes any already-saved asset to silently lose that field's value on
next load (UE matches by name; a renamed property just reads as "not present," falling
back to the type's default) — this is a real behavior change, not a cosmetic one, and
this project already has saved `UNexusConfigAsset` content on disk
(`Content/NexusConfigs/`, `Content/NF/Maps/LV0_Development1/NexusConfig.uasset`) that
transitively includes `FNexusDebugRenderConfig`'s boolean fields. Before renaming a
`UPROPERTY` boolean that is (or is nested inside, via a `UPROPERTY` container) part of
`UNexusConfigAsset`'s own saved shape:

1. Prefer a `[CoreRedirects]` entry (`Config/DefaultEngine.ini`, `PropertyRedirects`)
   mapping the old name to the new one, so already-saved assets still resolve correctly
   on load, over a bare rename.
2. If no redirect is added, treat the rename as a genuine breaking change to saved
   data — call it out explicitly (do not silently rename), and confirm with the user
   whether existing saved `NexusConfig` assets in this repo are disposable test data or
   need to be preserved/migrated.
3. Non-`UPROPERTY` booleans (plain C++ members, locals, parameters) carry no
   serialization risk — rename those freely under the rule above.

## References

- `project-specifications/v6-master-architecture.md` (top-level architecture authority
  this standard sits alongside)
- `project-specifications/AGENT-RULES.md` (standing agent policy — same "read before
  starting work" weight as this file)
- `ai-change-audits/` — the record of which existing files were brought into
  compliance with this standard, and why any were deliberately left as-is
