# 05 — V6 Data Model & Data Flow

## Status

**Drafted — 2026-08-09.**

## Data model

```
FNexusState
  └─ FNexusCity
       └─ FNexusHighway  (ordered list of HighwayPointIds; may be InterCityHighway)
            └─ FNexusHighwayPoint
                 └─ FNexusActivationPoint[]   (0..N per HighwayPoint — see 12)
```

Same four-level hierarchy V5 proved out (State→City→Highway→Point), renaming `Point` to
**HighwayPoint** to make explicit that it's always anchored to a Landscape Spline control
point, never a freestanding Nexus-only location. `ActivationPoint` is new — every
gameplay-relevant object (traffic light, city light, bus stop, seat, ad, TV, parking)
is `HighwayPointId + OffsetLocation + OffsetRotation + Type + Metadata`, not a bespoke
struct per feature (see [12](12-v6-activation-point-system.md)).

### Identity rules (carried from V5, unchanged — these were correct)

- `FGuid` (`HighwayPointId`, `HighwayId`, `CityId`, `StateId`, `ActivationPointId`) is
  always the real structural key, generated once, never reused, never derived from
  array position.
- `FName Code` stays an optional, per-type-unique, user-editable alias — never a lookup
  key in engine-facing code. `Name` stays a pure display label. See
  [03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md) for why this split
  exists (V5's Id/Code/Name confusion history).
- **Global default-naming convention** (2026-08-09): the `Id` field is never
  user-editable (`VisibleAnywhere`, not `EditAnywhere` — it's the primary key). `Code`
  and `Name` ARE user-editable, but every Nexus identity type gets a real, non-blank
  default at creation instead of `NAME_None`/empty — a `MakeDefault(int32 Index)` static
  factory per struct (see `FNexusState`/`FNexusCity`/`FNexusHighway`/
  `FNexusHighwayPoint` in `Source/NexusFrameworkEditor/Public/Representation/`) produces
  `Code = "<TYPE>_<Index%02d>"` (e.g. `"CITY_01"`) and `Name = "<Type> <Index>"` (e.g.
  `"City 1"`), matching V4/V5's own `"CITY_01"`/`"HWY_01"`-style Code convention. The
  factory takes the next index as a parameter — it does not own or track a counter
  itself; whichever phase actually creates instances (Nexus Mapping, Phases 10–14) owns
  deciding what "next index" means (global vs. per-parent-scope) and where it persists.
- The `-1` = inherit / `0` = disabled / `>0` = override convention for inheritable
  numeric fields (width, gap, length, tangent-related, speed limit, etc.) is unchanged.
  Resolution order stays most-specific-wins: HighwayPoint → Highway → City → State →
  global generation settings.

### What's different from V5's struct shape

`FNexusHighwayPoint` does **not** carry `Location`/`Rotation`/tangent fields as
persisted, authoritative data (V5's `FNexusRoadPoint` did, as a cache). In V6 those are
always resolved live from the mapped Landscape control point at read time — see
[04](04-v6-architecture.md)'s mapping section. A HighwayPoint that fails to resolve is a
validation error, not a fallback-to-cache situation. This is a deliberate, stricter
break from V5, made specifically to close the class of stale-geometry bugs documented in
[03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md).

## Flows

### Plugin-enable flow (replaces V5's Load Layout entirely)

```
Map opened, plugin active
     ↓
Resolve LandscapeId for the map's Landscape actor
     ↓
Find/create <LevelFolder>/<LevelName>/NexusConfig Data Asset (path convention
                                                                refactored 2026-08-10 —
                                                                see 04-v6-architecture.md)
     ↓
Load internally — Mapping stage re-reads Landscape fresh, reconciles against
                   the config asset's stored IDs/relationships/metadata
     ↓
Ready
```

No wipe/merge/import choice ever surfaces to the user — because there is no second copy
of geometry to conflict with. The only per-session decision is what Mapping does when it
finds a config-asset entry whose control point no longer resolves (flag as broken,
never silently drop — see [14-v6-validation.md](14-v6-validation.md)).

### Live edit flow

Native Landscape Spline edits (drag a point, add a segment) are the *only* way geometry
changes. V6 listens via the same engine transaction-callback mechanism V5 used
(`OnLandscapeSplineObjectTransacted`) purely to keep the **Mapping** layer's
ID/relationship bookkeeping in sync (new point → assign HighwayPointId; segment deleted →
retire the mapping) — it never writes geometry back. This collapses V5's two asymmetric
directions (pull-only Save vs. push-only Build Landscape) into one direction that always
existed for a different reason: Mapping reacts to Landscape, never drives it.

### Generation flow

Representation → Static Generator (merge/instance static meshes) and → Runtime Compiler
(Activation Points, final schema) run independently off the same Representation
snapshot; neither depends on the other's output. Both are re-runnable idempotently from
Representation + Landscape state alone — no hidden state accumulates between runs.

### Batch-mutation scoping rule

Carried forward as a hard rule after a real V5 bug (`MaterializeMissingPointGeometry`
classifying every *visited* point instead of only *newly created* ones, stomping live
rotation on already-correct neighbors): any operation that walks many entities must track
the subset it actually created/mutated separately from the subset merely visited for
traversal, and only the mutated subset feeds into destructive follow-up steps
(reclassification, remeshing, furniture placement).

## References

- [03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md)
- [04-v6-architecture.md](04-v6-architecture.md)
- [12-v6-activation-point-system.md](12-v6-activation-point-system.md)
- [14-v6-validation.md](14-v6-validation.md)
