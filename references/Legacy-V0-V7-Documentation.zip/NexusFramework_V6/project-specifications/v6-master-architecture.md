# V6 Final Architecture & Phase Alignment — Master Instruction

## Status

**Authoritative — 2026-08-10.** This is the top-level architecture authority for V6,
above the numbered `04`–`14` docs and above `v6-phase-verification.md`. Every new
agent/chat must read this file, then `v6-phase-verification.md`, then the current phase
spec, before starting work (see "New-agent / new-chat rule" below) — do not repeat this
read every command within a session that has already loaded it.

V6 is the **final production architecture**, not another experimental V0/V5 iteration.
V0–V5 are historical/reference projects only. Do not design V6 in a way that requires a
future V7 to fix fundamental architectural decisions.

Before modifying code or phase specifications, understand this fundamental goal:

> **Landscape is the spatial source of truth. V6 Editor is the authoring, adjustment,
> validation, and data-generation tool. V6 Runtime Schema is the final authoritative
> dataset consumed by future mesh generation, AI, navigation, vehicles, pedestrians,
> traffic systems, services, and gameplay.**

---

## 1. Required architecture

The complete pipeline must remain:

```text
UE Landscape
    ↓
Landscape Reader / Mapping
    ↓
V6 Editor Authoring Data
    ↓
Debug Visualization
    ↓
Gizmo / Manual Adjustment
    ↓
Validation
    ↓
Runtime Compiler
    ↓
V5-compatible / V6 Runtime Schema
    ↓
Mesh Generation
AI Navigation
Vehicle Driving
Pedestrian Movement
Traffic Systems
Parking
Bus Systems
Services
Gameplay
```

The editor is NOT primarily a mesh generator.

The editor's primary responsibility is producing a **high-quality spatial dataset**.

Mesh generation is a consumer of that dataset.

---

## 2. Landscape source of truth

Never make cached Location, Rotation, or Tangent values in the configuration asset
authoritative.

Landscape remains the source of truth for:

- Location
- Rotation
- Tangent
- Spline/control-point geometry
- Landscape relationships

V6 may store:

- Landscape IDs
- Mapping IDs
- City IDs
- Highway IDs
- Object IDs
- Parent/child relationships
- Authoring offsets
- Editor-only metadata
- Configuration
- Validation/debug information

When required, V6 reads the current Landscape spatial information.

Final Runtime compilation may bake the resolved spatial information into the Runtime
Schema.

---

## 3. Three primary object categories

The architecture must support at least these three broad categories:

### Transportation

Examples:

- Highway
- Highway Point
- Bus Stop
- Parking
- Crosswalk
- Pedestrian points
- Other transportation-related objects

### Infrastructure

Examples:

- Traffic Light
- City Light
- Pole
- Road infrastructure
- Utility infrastructure
- Other infrastructure objects

### Services / Facilities

Examples:

- Hospital
- Police Station
- Petrol Station
- Charging Station
- Service Garage
- Other future facilities

The category/type system must be extensible.

Adding a new object type must NOT require redesigning the fundamental architecture.

---

## 4. Universal object authoring model

Every placeable object must be evaluated using this question:

> Can the editor discover its spatial anchor from Landscape, visualize it, allow precise
> manual adjustment, validate it, and export the final resolved information into Runtime
> Schema?

A placeable object may contain:

- Parent Landscape/Highway reference
- Landscape point ID
- Highway ID
- Anchor point
- Local offset location
- Local offset rotation
- Sub-points
- Dimensions
- Configuration
- Relationships
- Capacity
- Occupancy information
- Mesh information
- Debug information
- Validation information

Do NOT force every object to have identical fields.

Instead, create a reusable foundation with extensible object-specific data.

---

## 5. Gizmo requirement

The base gizmo architecture MUST support:

```text
Single transform
Multiple sub-points
Dynamic arrays of sub-points
Object-specific editable points
```

Do NOT design the gizmo system around only one Location/Rotation pair.

For example:

```text
Traffic Light
    Pole
    Vehicle LED
    Pedestrian LED

Crosswalk
    Start
    End
    WaitingPoints[]

Bus Stop
    StoppingPoint
    EntryPoint
    ExitPoint
    PassengerWaitingPoints[]
    SeatInteractionPoints[]

Future Object
    PointA
    PointB
    PointC[]
    PointD[]
```

The same generic gizmo framework should support all of these.

Gizmo edits should modify the object's **authoring offset**, not the Landscape itself.

Conceptually:

```text
FinalTransform =
    LandscapeAnchorTransform
    ×
    AuthoringOffsetTransform
```

The exact resolved transform must later be available to Runtime compilation.

---

## 6. Parking must be a complete authoring system

Parking is NOT merely a point with a mesh.

The phase design must support a customizable parking configuration similar to:

```text
Parking
 ├─ HighwayId
 ├─ AnchorPoint
 ├─ OffsetLocation
 ├─ OffsetRotation
 ├─ Row
 ├─ Column
 ├─ RowGap
 ├─ ColumnGap
 ├─ SpotWidth
 ├─ SpotLength
 ├─ BaseMesh
 ├─ ParkingIndicatorMesh
 └─ OccupiedIndex[]
```

`HighwayId` provides the relationship to the road/highway spatial system.

The parking editor must:

- Resolve the highway/anchor tangent information.
- Debug-render parking positions.
- Allow gizmo adjustment.
- Convert gizmo changes into local authoring offsets.
- Correctly visualize rows and columns.
- Support row/column spacing.
- Support spot dimensions.
- Support configurable meshes.
- Show individual parking spots.
- Show occupied/available state.
- Allow identifying the next available parking position.

Capacity must be represented conceptually as:

```text
Capacity = Row × Column
```

Do NOT store capacity as a redundant independently-editable variable unless there is a
demonstrated future requirement.

`OccupiedIndex[]` identifies which generated parking positions are occupied.

Example:

```text
Row = 4
Column = 10

Capacity = 40

OccupiedIndex = [0, 3, 7, 21]
```

The system must therefore be able to answer:

```text
Is parking available?
Which parking spot is available?
Which parking spot is occupied?
What is the next available spot?
Where is that spot located?
What is its final rotation?
```

This information must eventually be exportable into Runtime Schema.

---

## 7. Bus Stop must be fully authorable

Bus Stop must support more than a single location.

At minimum the architecture must allow:

```text
Bus Stop
 ├─ HighwayId
 ├─ Anchor
 ├─ Offset
 ├─ StoppingPoint
 ├─ EntryPoint
 ├─ ExitPoint
 ├─ PassengerWaitingPoints[]
 ├─ SeatInteractionPoints[]
 ├─ Shelter configuration
 ├─ BaseMesh
 ├─ IndicatorMesh
 └─ Seat/Chair configuration
```

The editor must be able to visualize and gizmo-edit these points.

---

## 8. Seat / chair system

The architecture must support customizable seat configurations.

Example:

```text
Seat Type A
    Fixed spacing
    N seats

Seat Type B
    Single seat object
    Capacity = 3/4/5/etc.
```

Do not hard-code one chair model.

The data system must support:

- Seat type
- Seat count
- Seat capacity
- Spacing
- Position
- Rotation
- Mesh
- Interaction point
- Optional grouping

A single physical seat object may represent multiple logical seats if required.

The Runtime representation must contain enough information for AI/gameplay to determine
available seating.

---

## 9. Debug visualization

Every major object must have a debug representation.

Debug rendering should visualize:

- Anchor
- Final transform
- Offset
- Direction
- Tangent
- Start/end
- Relationships
- Generated sub-points
- Mesh placement
- IDs
- Capacity
- Occupancy
- Validation errors
- Important object-specific information

Debug rendering is an editor authoring tool, not merely decoration.

The user must be able to understand:

> "If I generate the final mesh now, exactly where will it appear?"

The debug representation should therefore closely represent the eventual generated
geometry/data.

---

## 10. Debug performance

The V6 debug renderer must account for very large worlds.

Incorporate the useful V0 concepts:

- Distance-based LOD
- Closest-point-to-AABB distance
- Separate geometry and label distances
- AABB/impostor rendering
- Maximum full-detail object count
- Distance-ranked full-detail selection
- Spatial filtering/culling

Do not blindly render every object at full detail every frame.

---

## 11. Junction safety

The junction system must own the complete rotation/orientation solution.

It must include:

- Neighbor analysis
- Forward direction calculation
- Tangent calculation
- Junction orientation
- Degenerate-vector protection
- Zero-length vector protection
- Quaternion normalization
- Safe fallback rotation
- Validation before constructing rotation matrices

Explicitly protect against the V5 failure class:

```text
Q.IsNormalized()
```

Do not reproduce V5's unsafe rotation assumptions.

---

## 12. Runtime data requirement

The final Runtime Schema must contain enough information for future systems to answer
questions such as:

```text
Where is this highway?
What direction does it travel?
Where does this highway start/end?
What highways connect?
Where can a vehicle drive?
Where can a pedestrian walk?
Where is the bus stop?
Where can the bus stop?
Where is parking?
Is parking available?
Which parking spot is available?
Where is the hospital?
How do I reach the hospital?
Where is the hospital entrance?
Where are traffic lights?
Where are pedestrian waiting points?
Where are service facilities?
What objects are connected?
```

The Runtime Compiler must therefore export resolved spatial information such as:

- Location
- Rotation
- Tangent In
- Tangent Out
- Start/End
- Relationships
- IDs
- Object-specific data
- Activation points
- Station points
- Connectivity information

Do not export unnecessary editor-only state.

---

## 13. Phase development rule

There are approximately 100 phases (`Phase 01` … `Phase 100`).

Every phase must contribute directly toward the final architecture.

Before implementing any phase, determine:

1. What future requirement does this phase enable?
2. What Runtime data will eventually depend on it?
3. Does it preserve Landscape as source of truth?
4. Does it support editor authoring?
5. Does it support debug visualization?
6. Does it support gizmo adjustment where required?
7. Does it support future mesh generation?
8. Does it support future AI/navigation requirements?
9. Does it create technical debt that would require V7?

If a phase cannot answer these questions, STOP and reassess the phase.

---

## 14. Mandatory 20-phase checkpoints

After every 20 phases, perform a mandatory architecture review.

Checkpoints:

```text
Phase 20 — Architecture Review
Phase 40 — Architecture Review
Phase 60 — Architecture Review
Phase 80 — Architecture Review
Phase 100 — Final Architecture Review
```

Per Section 21 (existing phase index must never be broken), each checkpoint is its own
`phase-NNa.md`-style inserted file (`phase-20a.md`/`phase-40a.md`/`phase-60a.md`/
`phase-80a.md`), following the exact convention already established by
`phase-26a.md`/`phase-30a.md`/`phase-41a.md` — never a rename/insert that shifts
existing numbering. Phase 100 already IS the roadmap's final review point
(`phase-100-verification-and-publish-gate.md`); its own scope absorbs the "Phase 100 —
Final Architecture Review" checkpoint rather than needing a `100a`.

The review must explicitly answer:

> **Are the previous 20 phases still aligned with the main V6 future goal?**

The review must inspect:

### A. Architecture
Is the architecture still extensible?

### B. Data
Can the editor produce the required final Runtime dataset?

### C. Landscape
Is Landscape still the spatial source of truth?

### D. Authoring
Can the user adjust objects precisely?

### E. Gizmo
Can all required single-point and multi-point objects be edited?

### F. Debug
Can the user visually verify the final placement before mesh generation?

### G. Object Coverage
Are all required categories and object types supported?

### H. Runtime
Can the generated data support future AI/gameplay?

### I. Performance
Can the system scale to massive worlds?

### J. V7 Risk
Did any implementation create architectural debt that would require V7?

The review must produce:

```text
PASS
PASS WITH REQUIRED CHANGES
FAIL
```

If the result is not PASS, update the future phase specifications before continuing.

---

## 15. Phase checkpoint format

Use this exact conceptual format:

```text
Phase 20 — Architecture Review

Status: PASS / PASS WITH REQUIRED CHANGES / FAIL

Completed:
- ...

Verified:
- Landscape source of truth: PASS
- Runtime data pipeline: PASS
- Editor authoring: PASS
- Gizmo system: PASS
- Debug visualization: PASS
- Object extensibility: PASS
- AI/data requirements: PASS
- Performance architecture: PASS

Missing:
- ...

Required adjustments:
- ...

Impact on future phases:
- ...

Decision:
Continue / Modify future phases / Stop
```

Do not simply say "all good". The review must identify concrete evidence.

---

## 16. New-agent / new-chat rule

This document lives inside the V6 Git repository at
`project-specifications/v6-master-architecture.md`, tracked by Git alongside:

```text
project-specifications/
├── v6-master-architecture.md   (this file)
├── v6-phase-verification.md
├── 10-v6-runtime-schema.md
├── 12-v6-activation-point-system.md
├── 13-v6-gizmo-system.md
└── phases/
    ├── phase-01.md
    ├── ...
    └── phase-100.md
```

Every new AI agent/chat must read `v6-master-architecture.md` and
`v6-phase-verification.md` before starting project work, then identify the current phase
and read the relevant phase specification.

---

## 17. First-chat optimization

Do NOT repeatedly reread every document if the same AI session already loaded and
understood them.

At the beginning of a new AI session:

```text
Read v6-master-architecture.md
Read v6-phase-verification.md
Read the current phase specification
Read only the directly referenced supporting specifications
```

After that, maintain the architectural context for the remainder of that session. Do not
repeatedly reload the same documents before every command.

---

## 18. Existing phase audit

Before implementation continues, inspect all existing Phase 01–100.

Do NOT blindly trust existing phases.

For every phase determine:

```text
EXISTING
MISSING
PARTIAL
CONFLICTING
REDUNDANT
NEEDS REVISION
```

Pay special attention to:

- Generic N-sub-point gizmos
- Parking
- Bus Stop
- Seats
- Crosswalk
- Traffic Light
- City Light
- Hospital
- Police
- Petrol
- Charging
- Service Garage
- Junction rotation safety
- Runtime export
- Debug LOD
- Large-world performance
- AI/navigation data

If a requirement is missing, modify the phase plan.

Do not postpone fundamental architecture problems to V7.

---

## 19. Final acceptance test

V6 should ultimately be able to perform this complete workflow:

```text
Landscape
    ↓
Read Landscape geometry
    ↓
Create City / Highway relationships
    ↓
Create authoring objects
    ↓
Place Parking / Bus Stop / Traffic Light / Hospital / etc.
    ↓
Debug visualize
    ↓
Gizmo adjust
    ↓
Update offsets
    ↓
Validate
    ↓
Preview final placement
    ↓
Compile Runtime Data
    ↓
Export final Runtime Schema
    ↓
Generate meshes from Runtime/compiled data
    ↓
AI uses the same spatial dataset
```

The critical requirement is:

> **The location adjusted in the editor must be the location ultimately used by the
> generated mesh and Runtime systems.**

No duplicated competing spatial truth is allowed.

---

## 20. Final principle

Treat V6 as the **final foundation**.

Do not ask:

> "How can we finish this phase?"

Ask:

> **"Does completing this phase move us toward the final spatial-data authoring system
> that can generate the complete Runtime Schema for the future world?"**

Every phase must strengthen that foundation.

If an existing design conflicts with this principle, stop, document the conflict, and
update the phase plan before implementation.

**Do not create V7 to repair V6 architectural mistakes.**

---

## 21. Existing phase index must never be broken

The existing Phase 01–100 index is already established.

**DO NOT renumber, delete, reorder, or break the existing phase numbering.**

If a new requirement is discovered, first find the most appropriate existing phase and
enhance it.

Use this naming convention:

```text
Phase 33 — Debug Performance
Phase 33 — Enhancement: Distance-Based LOD
Phase 33 — Enhancement: AABB Impostor + Full-Detail Cap
Phase 33 — Enhancement: Always-Draw Visualization
```

or, if the phase document already has a title:

```text
Phase 33 — [Existing Title] — Enhancement
```

The goal is to preserve the roadmap while making existing phases more complete and
production-ready.

Only create a genuinely new phase if there is no suitable existing phase — and per this
project's own established convention (`phase-26a.md`/`phase-30a.md`/`phase-41a.md`), that
new phase is inserted as a `phase-NNa.md` sibling of the phase it extends, never a
renumbering.

---

## 22. Mandatory V0 debug-performance enhancements

The V0 research identified two valuable concepts that must be incorporated into suitable
existing V6 phases (Phase 33-35, per Section 21's enhancement convention).

### Distance-Based LOD

The system should support:

- Camera-distance evaluation
- Closest-point-to-AABB distance
- Full-detail rendering distance
- Simplified rendering distance
- Label rendering distance
- Distance-based object filtering
- Distance-ranked full-detail selection
- Maximum full-detail objects per frame
- Large-world scalability

For distant objects, use a cheap representation such as an AABB/Bounding Box/Impostor
instead of rendering every lane, point, label, sub-point, and primitive.

The purpose is to prevent massive-world editor visualization from becoming a performance
bottleneck.

---

## 23. Always-draw debug visualization

The debug visualization must be capable of being independent from whether:

- The editor panel is open
- The custom tool is currently active
- The object is selected

Support a concept similar to:

```text
Global Debug Category Visibility
        +
Per-Object / Per-Instance Always-Draw Override
```

Example:

```text
CityLight A
    AlwaysDraw = true

CityLight B
    AlwaysDraw = false
```

An object marked `AlwaysDraw` should remain visible in the editor viewport when
appropriate even when the main authoring panel/tool is not active.

Do not duplicate the rendering implementation. The Always-Draw system must reuse the same
debug renderer/category renderer used by the normal editor visualization system.

---

## 24. Massive-world dynamic actor / static mesh strategy

The world may contain thousands or millions of logical objects (Traffic Lights, City
Lights, TV Boards, Advertisement Boards, Poles, Parking, Bus Stops, Infrastructure, other
dynamic-capable objects). These objects may eventually be converted into Static Mesh,
Merged Mesh, Instanced Mesh, HLOD, or a Nanite-compatible representation for normal world
rendering.

However, V6 must preserve enough Runtime Schema information to make selected objects
**dynamically active near the player/character**.

The architecture should therefore separate:

```text
Logical World Object
        ↓
Authoritative Runtime Data
        ↓
Static/Merged World Representation
        +
Dynamic Near-Player Representation
```

Do NOT require every logical object to exist as a permanent Actor.

---

## 25. HighwayId-based dynamic object activation

Many dynamic objects are spatially attached to a Highway (Traffic Light, City Light, TV,
Advertisement Board, other Highway-attached objects).

The object may contain: `HighwayId`, `LandscapePointId`, `OffsetLocation`,
`OffsetRotation`, object-specific configuration.

The runtime system can therefore resolve:

```text
HighwayId
    ↓
Highway / Landscape spatial data
    ↓
Original anchor Location / Rotation / Tangent
    ↓
Object Offset
    ↓
Final Object Transform
```

Conceptually:

```text
FinalTransform =
    OriginalHighwayPointTransform
    ×
    ObjectOffsetTransform
```

This allows a dynamic actor to be spawned exactly where the editor-authored object exists
without storing redundant world-space transforms as the primary source of truth.

---

## 26. Near-player dynamic actor activation

The Runtime system should support proximity-based activation:

```text
World contains 5,000 City Lights
        ↓
Character approaches
        ↓
Find nearby logical CityLight objects
        ↓
Resolve their final transforms
        ↓
Spawn/activate only ~15–20 dynamic light actors
        ↓
Attach/configure them at exact authored locations
        ↓
Character moves
        ↓
Deactivate actors leaving the active range
        ↓
Activate/reuse actors for newly nearby lights
```

The exact number must be configurable — do not hard-code `15–20` as an architectural
requirement. Use configurable concepts such as `ActivationRadius`, `DeactivationRadius`,
`MaximumActiveActors`, `PoolingEnabled`, `UpdateDistance`.

Prefer actor pooling/reuse over constantly destroying and recreating actors.

---

## 27. Dynamic actor reuse / attachment

For very large object counts, prefer a small configurable subset of active dynamic actors
against a much larger logical object count (e.g. 5,000+ logical `CityLight_NNNN` objects,
existing only as Runtime data/static representation, against a handful of pooled
`DynamicLightActor_NN` instances that get rebound as the player moves:
`DynamicLightActor_01 → CityLight_3812` released and reused for `CityLight_3840`, etc.).

The system should therefore support: actor pooling, logical-object-to-actor binding,
runtime transform resolution, activation/deactivation, attachment/rebinding, maximum
active actor limits, distance-based prioritization.

The dynamic actor is a **temporary runtime representation**, not the authoritative
object.

---

## 28. Static + dynamic representation must coexist

```text
                  Runtime Schema
                       │
              ┌────────┴────────┐
              │                 │
        Static Representation   Dynamic Representation
              │                 │
       merged/instanced       near-player actor
       world geometry         temporary actor
              │                 │
       always available       activated nearby
```

Example (City Light): far away — merged/instanced static mesh only; near player — static
representation + dynamic light actor. The system must avoid visible duplication. When a
dynamic actor becomes active, the corresponding static representation must be handled
appropriately according to the rendering strategy.

---

## 29. The same model must work for other objects

Do not build a special "City Light hack." The architecture should be reusable for City
Light, Traffic Light, TV, Advertisement, Interactive Pole, Dynamic Sign, Dynamic Bus Stop
component, other future dynamic objects.

Each object type may define its own Activation Distance, Dynamic Actor Class, Static
Representation, Dynamic Configuration, Update Frequency, Pooling Requirements — but the
underlying activation framework should remain generic.

---

## 30. Editor → static → dynamic consistency

The most important rule is:

> **Static mesh placement, dynamic actor placement, and Runtime Schema placement must
> originate from the same authored spatial data.**

```text
Landscape Point
      +
CityLight Offset
      ↓
Final Authored Transform
      ↓
Runtime Schema
      ├── Static Mesh placement
      └── Dynamic Actor placement
```

Never create independent coordinates for Editor, Static Mesh, Dynamic Actor, AI — because
that creates synchronization bugs. There must be one authoritative logical object and one
deterministic transform-resolution path.

---

## 31. AI / gameplay benefit

This architecture is specifically intended for massive open-world environments. The
AI/gameplay system should be able to query the Runtime dataset without requiring
thousands of Actors to exist — e.g. find nearest hospital, hospital entrance, nearest/
available parking and which spot, nearest/next bus stop, traffic light, nearby city
lights, advertisement, service garage, charging station.

The AI can query data first. Only when an object requires active gameplay behavior should
a dynamic representation be activated. This keeps `Data Scale ≠ Actor Scale` — a world may
contain 100,000 logical objects while only ~500 dynamic actors are active around the
player. The exact numbers must remain configurable.

---

## 32. Phase alignment for these features

When auditing Phase 01–100, explicitly verify appropriate coverage for: distance-based
LOD, AABB impostors, full-detail render cap, always-draw visualization, logical object
representation, static representation, dynamic representation, near-player activation,
distance-based deactivation, actor pooling, runtime transform resolution, HighwayId
lookup, LandscapePointId lookup, object offset resolution, static/dynamic consistency,
massive-world scalability.

If missing, **enhance the most suitable existing phase** — do not break the phase
numbering. Use `[Existing Phase] — Enhancement` / `— Performance Enhancement` /
`— Dynamic Runtime Enhancement` / `— Architecture Enhancement`.

---

## 33. Mandatory 20-phase review addition

At every Phase 20/40/60/80/100 checkpoint, also verify:

> **Can this architecture support millions of logical world objects while keeping only
> the necessary subset as expensive runtime Actors?**

Specifically verify: logical data scalability, static representation scalability, debug
visualization scalability, dynamic actor scalability, actor pooling, proximity
activation, proximity deactivation, LOD, culling, runtime lookup, memory usage, CPU cost,
editor performance.

Mark each as `PASS` / `PASS WITH REQUIRED CHANGES` / `FAIL`.

---

## 34. Final massive-world principle

The V6 system must be designed around:

> **Millions of logical objects do not mean millions of Actors.**

The Runtime Schema represents the world. Static/merged/instanced representations render
the world cheaply. Dynamic Actors represent only the objects that currently need
behavior. The player/AI proximity determines which logical objects become active. The
same authored data determines the location of every representation.

```text
Landscape
    ↓
Authoritative Spatial Data
    ↓
Runtime Schema
    ├── Static World Representation
    ├── Debug Representation
    ├── AI/Data Queries
    └── Dynamic Near-Player Representation
```

This is a core V6 scalability requirement, not an optional future feature.

---

## 35. Final instruction to the AI

Before starting implementation:

1. Read this entire master architecture document.
2. Read the existing phase verification document (`v6-phase-verification.md`).
3. Read the current phase.
4. Audit the existing Phase 01–100 roadmap.
5. Identify where each requirement belongs.
6. **Do not break existing phase numbering.**
7. Enhance suitable phases where necessary.
8. Report every enhancement explicitly.
9. At every 20-phase checkpoint, verify alignment against the complete final
   architecture.
10. Never accept "works for now" if it creates a fundamental V7 requirement.

The objective is not merely to complete 100 phases.

The objective is to make **V6 the final scalable spatial-data authoring and Runtime
generation foundation for a massive open-world system.**

## References

- [v6-phase-verification.md](v6-phase-verification.md) — the requirement-by-requirement
  coverage audit this document sits above; re-run/extend that audit's method against
  Sections 3-12 above.
- [10-v6-runtime-schema.md](10-v6-runtime-schema.md), [11-v6-static-dynamic-architecture.md](11-v6-static-dynamic-architecture.md),
  [12-v6-activation-point-system.md](12-v6-activation-point-system.md), [13-v6-gizmo-system.md](13-v6-gizmo-system.md) —
  the detailed subsystem docs this file's Sections 5-12 constrain.
- `ai-change-audits/2026-08-10/others/` — the same-day scoping records (Phase 26a/30a/41a
  insertions) that established the `phase-NNa.md` enhancement-insertion convention Section
  21 formalizes project-wide.
