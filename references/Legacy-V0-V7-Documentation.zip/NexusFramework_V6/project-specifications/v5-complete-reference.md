# V5 Complete Reference

**Purpose: read this instead of opening the V5 codebase.** This is a complete, direct
extraction of every public header in `NexusFramework_V5`'s two modules (`NexusFrameworkEditor`
Public/ — Schema/Editor, the subsystem, and UI — plus `NexusFramework` Public/ — Schema/Runtime
and Schema/Shared), covering every type, every UPROPERTY field, every public (and
architecturally-relevant private) method, and every gotcha/invariant stated in the original
code comments. 34 header files, read in full, not skimmed. If a future agent needs a fact about
how V5 works, it should be findable here first — only go back to the actual V5 source if this
document is missing something or looks wrong.

Source root this was extracted from: `E:\Projects\Game\UE\NexusFramework_V5` (paths in this doc
are relative to `Source/NexusFrameworkEditor/Public/` or `Source/NexusFramework/Public/` unless
given in full). Organized by module, then by file.

**Relationship to the other docs in this folder**: [01-v5-analysis.md](01-v5-analysis.md),
[02-v5-feature-inventory.md](02-v5-feature-inventory.md), and
[03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md) are the short, narrative
distillation (architecture summary, feature checklist, lessons learned) — read those first for
orientation. This document is the deep, exhaustive backing reference underneath them — read it
when you need the actual field/method-level detail those summaries necessarily left out.

**Investigated and corrected during authoring of this doc**: a reported "after switching map,
the tool still points at the first landscape" bug was checked directly against the current V5
source and does **not** reproduce — `ResolveTargetLandscape()` re-resolves fresh every call (no
caching) and `HandleMapOpened` (see its entry under Editor Subsystem below) already does a full
reset. The real, related bug that *did* exist and was fixed is the cross-map stale `SourcePoint`
issue described under `IsControlPointOnTargetLandscape` below and in
[03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md) — a soft-reference resolving to a
still-resident *previous* map's control point, not a stale Landscape actor pointer. V6 should
still design defensively against this general class of bug (see
[phases/phase-01-core-structures.md](phases/phase-01-core-structures.md)) even though it's not
currently an open V5 bug.

---

## MODULE: Editor Schema (`Source/NexusFrameworkEditor/Public/Schema/Editor/`)

### `NexusRoadTypes.h`
Editor-authoring-only enums (draw tools, junction analysis, outliner). Enums needed by Tier 4 export structs live in `Schema/Shared` instead (e.g. `ENexusLaneConfiguration` is in `NexusSharedRoadTypes.h`, not here).

- **`ENexusSplinePointType`** (`uint8`, BlueprintType) — Mirrors `ESplinePointType`, controls how a point's tangents are interpreted. Values: `Linear, Curve, CurveClamped, Constant, CurveCustomTangent`. Gotcha: `Curve` is UE's auto-tangent mode — `ArriveTangent`/`LeaveTangent` are ignored for it; a point becomes `CurveCustomTangent` the instant its tangent handle is dragged in viewport, at which point those tangents become real authored data.
- **`ENexusNodeType`** (`uint8`, BlueprintType) — Derived point classification from connection count: `Unknown, DeadEnd, Straight, Corner, SmoothCorner, TJunction, CrossJunction, MultiJunction`. Gotcha: `SmoothCorner` is topologically still a Corner (2 connections at a real angle) but its hand-dragged tangents are smoothed enough to visually read as a gentle bend.
- **`ENexusAnchorKind`** (`uint8`) — Where a Draw Highway/Draw Point click landed: `EmptySpace, ExistingPoint, OnHighway`. See `FNexusRoadGraph::ResolveAnchorToPoint` (note: this class name appears only in comments; not found as a header in this file list — likely internal to the editor module's .cpp/other headers not requested).
- **`ENexusHighwayOwnershipKind`** (`uint8`, BlueprintType) — `InternalCityRoad` (exactly one of `StartCityId`/`EndCityId` set) vs `InterCityHighway` (both set). Derived live from `FNexusHighway`. Gotcha: no "global, owned by no city" case exists — every generated highway is always internal or bridging.
- **`ENexusHighwayStateSpan`** (`uint8`, BlueprintType) — `SingleState` vs `CrossState`, derived by resolving `StartCityId`/`EndCityId` through `FNexusCity::ParentStateId`. Only meaningful for `InterCityHighway`; an `InternalCityRoad` is always `SingleState`. No separate field stores this — always derived.
- **`ENexusOutlinerItemType`** (`uint8`) — Row kind in the world outliner tree: `Category, State, City, Highway, Point`. One more level than V4 (State sits above City).

### `NexusHighwayMeshAssetSet.h`
Editor-only art/mesh catalog for highways and street furniture. Depends on `NexusSharedRoadTypes.h` (for `ENexusLaneConfiguration` map key).

- **`ENexusMeshForwardAxis`** (`uint8`, BlueprintType) — `Unset, X, Y, Z`. Which local axis a mesh's "forward" (long) direction was modeled along. Gotcha: `Unset` (default) means NO forward-axis correction math runs at all — only explicitly picking X/Y/Z turns that math on.

- **`FNexusMeshConfig`** (USTRUCT, BlueprintType) — ONE placeable mesh + how to place it; base struct every mesh slot in the file builds from.
  - `StaticMesh` (`TSoftObjectPtr<UStaticMesh>`) — unset = nothing generates, skip entirely (never substitute a placeholder).
  - `OffsetLocation` (`FVector`, default zero)
  - `OffsetRotation` (`FRotator`, default zero)
  - `Scale` (`FVector`, default one)
  - `ForwardAxis` (`ENexusMeshForwardAxis`, default `Unset`)

- **`FNexusHighwayRoadMeshConfig : public FNexusMeshConfig`** (USTRUCT, BlueprintType) — a road mesh slot (straight/corner/T/cross).
  - `Width` (`float`, default -1, ClampMin -1) — how wide THIS mesh was authored, cm. **3-tier resolution chain**: 1) this slot's own Width, 2) owning `FNexusHighwayMeshSet`'s shared Width, 3) auto-measure `StaticMesh`'s bounding box. Each field resolves independently.
  - `Length` (`float`, default -1, ClampMin -1) — same chain, for one copy's front-to-back length.

- **`FNexusSpacedMeshConfig : public FNexusMeshConfig`** (USTRUCT, BlueprintType) — furniture that repeats along a road at intervals with a left/right side.
  - `Spacing` (`float`, default 1500, ClampMin 10) — min gap between placements.
  - `StartOffset` (`float`, default 0, ClampMin 0) — distance along road to first instance.
  - `EndOffset` (`float`, default 0, ClampMin 0) — length at road end left without an instance.
  - `SideOffset` (`float`, default 0, ClampMin 0) — sideways distance from road edge.
  - `bShouldRenderBothSide` (`bool`, default true) — place on both sides vs one.
  - `BothSideRenderOffsetRandom` (`float`, default 0, ClampMin 0, EditCondition on bShouldRenderBothSide) — max random longitudinal offset per side so left/right rows don't perfectly mirror-lockstep. 0 = perfectly aligned.

- **`FNexusAreaMeshConfig`** (USTRUCT, BlueprintType) — ground-level parking area's complete art: 3 independent `FNexusMeshConfig` parts.
  - `BaseMesh`, `SectionMesh` (repeatable bay piece), `MarkingMesh` (painted lines) — each own offset/rotation/scale/forward-axis.

- **`FNexusBusStopMeshConfig`** (USTRUCT, BlueprintType) — bus stop's complete art.
  - `BaseMesh`, `IndicatorMesh` (sign), `DirectionWaypointMesh` (marks pull-up point/facing, read by future traffic/AI) — fixed singles.
  - `ShelterMeshOptions` (`TArray<FNexusMeshConfig>`) — pool, ONE random pick per bus stop. Empty = no shelter.
  - `ChairMeshOptions` (`TArray<FNexusMeshConfig>`) — pool, each of up to `MaxAllowedChairs` chairs independently picks randomly. Empty = no chairs regardless of `MaxAllowedChairs`.
  - `MaxAllowedChairs` (`int32`, default 2, ClampMin 0) — upper bound on random chair count (0..this).

- **`FNexusHighwayDimensions`** (USTRUCT, BlueprintType) — lane/sidewalk layout measurements for FINAL-MESH layout (separate from `FNexusHighway::LaneWidth`/etc used for road-actor width/collision math). EVERY field defaults -1 = "not set at this level"; **3-tier chain**: 1) `FNexusHighwayMeshSet.Dimensions` (per-lane-config), 2) `UNexusHighwayMeshAssetSet::DefaultDimensions` (global editor default), 3) hardcoded built-in default. Each field resolves independently.
  - `LaneWidth`, `LaneGap`, `LaneGapFromCenterLeft`, `LaneGapFromCenterRight` (asymmetric center gap, independent of Left), `SidewalkWidth`, `SidewalkGap` — all `float`, default -1, ClampMin -1.

- **`FNexusHighwayMeshSet`** (USTRUCT, BlueprintType) — one lane configuration's complete road art + per-config furniture overrides. Keyed by `ENexusLaneConfiguration` in `UNexusHighwayMeshAssetSet::MeshSets`.
  - `Dimensions` (`FNexusHighwayDimensions`)
  - `Width`, `Length` (`float`, default -1) — shared authored size for the 4 road-mesh slots below (middle tier of `FNexusHighwayRoadMeshConfig::Width`'s chain).
  - `MainHighwayMesh` (`FNexusHighwayRoadMeshConfig`) — straight segment; used for Straight AND Smooth Corner points.
  - `CornerHighwayMesh` — 2-branch sharp-angle bend.
  - `TJunctionMesh` — 3-branch junction.
  - `CrossJunctionMesh` — 4-branch junction, AND the fallback for 5+-branch MultiJunction (no dedicated shape exists).
  - `OverrideLeftSideWalkMesh`, `OverrideRightSideWalkMesh`, `OverrideCrosswalkMesh`, `OverrideCrossWalkSignMesh`, `OverrideTrafficLightMesh` (`FNexusMeshConfig`) — per-lane-config overrides of the asset's shared slots; leaving `StaticMesh` unset means "use shared instead."
  - `OverrideCityLightMesh`, `OverrideElectricityPoleMesh`, `OverrideTrashCanMesh` (`FNexusSpacedMeshConfig`)
  - `OverrideMedianMesh` (`FNexusMeshConfig`)
  - `OverrideParkingAreaMesh` (`FNexusAreaMeshConfig`) — each of the 3 parts resolves independently against the shared set.
  - `OverrideBusStopMesh` (`FNexusBusStopMeshConfig`) — Base/Indicator/DirectionWaypoint resolve per-field; `ShelterMeshOptions`/`ChairMeshOptions` REPLACE wholesale if non-empty (no per-entry merge — mixing pools from two art kits would look mismatched).
  - `OverrideIntersectionMesh`, `OverrideIntersectionMeshMarking` (`FNexusMeshConfig`)

- **`UNexusHighwayMeshAssetSet : public UDataAsset`** (UCLASS, BlueprintType) — the saveable/swappable asset holding all mesh sets + shared street furniture. **Gotcha explicitly flagged in header**: street furniture fields are DESIGN ONLY as of writing — only road-mesh slots (Main/Corner/TJunction/CrossJunctionMesh) and `Width` are read by the Phase 3 Apply/Refresh pass; wiring a furniture generation pass is separate follow-up work.
  - `MeshSets` (`TMap<ENexusLaneConfiguration, FNexusHighwayMeshSet>`) — one entry per lane config with art defined; missing entry = no art yet.
  - `DefaultDimensions` (`FNexusHighwayDimensions`) — global/editor-level default, last stop before hardcoded default.
  - Shared street furniture (all `EditAnywhere, BlueprintReadWrite`, Category "Street Furniture"): `LeftSideWalkMesh`, `RightSideWalkMesh`, `CrosswalkMesh` (flat ground marking), `CrossWalkSignMesh` (pole/sign, separate from CrosswalkMesh), `TrafficLightMesh`, `CityLightMesh` (`FNexusSpacedMeshConfig`, street lighting distinct from TrafficLightMesh), `ElectricityPoleMesh` (`FNexusSpacedMeshConfig`), `WireMesh` (`FNexusMeshConfig` — NOT spaced; spans BETWEEN pole placements; one static mesh is a straight placeholder, no sag/spline geometry), `UtilityBoxMesh` (catch-all utility hardware), `TrashCanMesh` (`FNexusSpacedMeshConfig`), `MedianMesh` (representative-only, one ribbon per highway), `ParkingAreaMesh` (`FNexusAreaMeshConfig`), `BusStopMesh` (`FNexusBusStopMeshConfig`), `IntersectionMesh` (junction footprint), `IntersectionMeshMarking` (directional paint on top of IntersectionMesh, separate for independent mesh/material/offset).
  - **Methods**:
    - `const FNexusHighwayMeshSet* FindMeshSet(ENexusLaneConfiguration) const` — nullptr if no entry.
    - `static const FNexusMeshConfig& ResolveDecorationSlot(Override, Shared)` — returns Override if its `StaticMesh` is non-null else Shared. The universal "most-specific-wins-else-shared" rule.
    - `static const FNexusSpacedMeshConfig& ResolveSpacedDecorationSlot(Override, Shared)` — same rule for spaced slots.
    - `static FNexusAreaMeshConfig ResolveAreaDecorationSlot(Override, Shared)` — resolves Base/Section/Marking independently.
    - `static FNexusBusStopMeshConfig ResolveBusStopDecorationSlot(Override, Shared)` — Base/Indicator/DirectionWaypoint per-field; Shelter/Chair pools + `MaxAllowedChairs` resolve as ONE whole unit (if Override has ANY shelter/chair entries, its full pools+MaxAllowedChairs are used, never merged).

### `NexusSitableStructure.h`
Schema-only (no generation/placement/AI code reads/writes it yet, no UI surfaces it). Depends on `NexusSitableTypes.h` (Shared).

- **`FNexusOccupancyGrid`** (USTRUCT, BlueprintType) — row/column-addressable grid of occupiable slots (bus/cinema seating, future parking reuse).
  - `NumRows`, `NumColumns` (`int32`, default 0) — 0 = not grid-arranged (flat-pool fallback via `FNexusSittingSite::SiteCapacity`).
  - `CenterGap` (`float`, default -1) — gap at center aisle. -1 = global default, 0 = no gap, >0 = custom — same convention as other Gap/Width fields codebase-wide.
  - `OccupiedIndex` (`TArray<int32>`, BlueprintReadWrite only, not Edit) — runtime, flattened Row*Column index of occupied slots (or 0..SiteCapacity-1 when grid is 0/0). Not authored.

- **`FNexusRandomSiteMeshOptions`** (USTRUCT, BlueprintType) — one capacity bucket's mesh options. Exists purely because `TMap<int32, TArray<...>>` isn't UPROPERTY-reflectable — one-field wrapper struct works around that (same pattern as `TMap<ENexusLaneConfiguration, FNexusHighwayMeshSet>`).
  - `Meshes` (`TArray<TSoftObjectPtr<UStaticMesh>>`)

- **`FNexusSittingSite`** (USTRUCT, BlueprintType) — one seat/bench slot within a structure. Schema only, no consumer code yet.
  - `SiteCapacity` (`int32`, default 1) — capacity when NOT grid-arranged; ignored once grid IS set (NumRows*NumColumns is real capacity then).
  - `Occupancy` (`FNexusOccupancyGrid`)
  - `RotationOffset` (`FRotator`), `LocationOffset` (`FVector`)
  - `OverrideMeshOptionsByCapacity` (`TMap<int32, FNexusRandomSiteMeshOptions>`) — keyed by seat capacity (1=1-seater etc); random pick per bucket; falls back to owning structure's catalog default when empty. Resolution logic not implemented yet.

- **`FNexusSitableStructure`** (USTRUCT, BlueprintType) — a physical sittable structure placed inside a Highway/CityParks/BusStation/HotelResort owner. Can hold several `Sites`.
  - `StructureId` (`FGuid`, VisibleAnywhere/ReadOnly) — real key, matches `FNexusWorldData::SitableStructures` TMap key.
  - `Target` (`ENexusSitableTarget`, default `BusStation`)
  - `OwnerId` (`FGuid`) — interpretation depends on `Target` (see `ENexusSitableTarget` doc in Shared).
  - `Sites` (`TMap<FGuid, FNexusSittingSite>`)
  - **Gotcha/invariant**: Stored on `FNexusWorldData::SitableStructures`, a top-level map NOT nested under the State>City>Highway>Point chain. `RemoveSitableStructure` is NOT auto-called on City/Highway/Point removal EXCEPT for the OwnerId itself — `FNexusWorldData::RemovePoint`/`RemoveHighway` both cascade-delete any structure whose `OwnerId` they own, to avoid dangling references. `OwnerId` is NOT validated against `Target` at the storage layer (that's a placement/generation-time concern per `NexusWorldData.h`).

### `NexusDebugDrawSettings.h`
Depends only on `Engine/DataAsset.h`.

- **`ENexusDebugDrawCategory`** (`uint8`, BlueprintType) — one enum value per debug-draw category: `State, City, Highway, Lane, Junction, HighwayName, LaneIndex, LaneSide, SegmentName, SegmentBox, PointName, Sidewalk, TrafficLight, Crosswalk, Parking, BusStop, PetrolPump, ChargingStation, ServiceGarage, LandscapePathOverlay`. Each maps to one bool on `FNexusDebugDrawState`; `Lane/Junction/HighwayName/LaneIndex/LaneSide` are Highway sub-toggles, `SegmentName/SegmentBox` are Segment sub-toggles — neither sub-group is independent of its parent toggle.

- **`FNexusDebugDrawConfig`** (USTRUCT, BlueprintType, not marked NEXUSFRAMEWORKEDITOR_API explicitly — plain USTRUCT) — per-category color/thickness/font override.
  - `bShouldOverride` (`bool`, default false) — gate; when false the drawing code's hardcoded per-category base value is used unchanged.
  - `OverrideColor` (`FLinearColor`, default White, EditCondition bShouldOverride)
  - `OverrideThickness` (`float`, default 2, ClampMin 0.1, EditCondition bShouldOverride)
  - `OverrideFontSize` (`float`, default 12, ClampMin 1, EditCondition bShouldOverride) — only matters for text-label categories (HighwayName/LaneIndex/LaneSide/SegmentName); harmless no-op for line/box/sphere categories.
  - `OverrideFontColor` (`FLinearColor`, default White, EditCondition bShouldOverride)

- **`UNexusDebugDrawSettings : public UDataAsset`** (UCLASS, BlueprintType) — debug-draw APPEARANCE ONLY, no on/off toggles (those live in `FNexusDebugDrawState`, saved per-Layout, so two Layouts can share visual style while independently toggling categories). Referenced by a Layout via `UNexusLayoutAsset::DebugDrawSettingsAsset` rather than a global preference singleton (used to be a `UDeveloperSettings`). **Notable architectural note in comment**: floating text labels ARE possible in the plain (non-PIE) editor viewport via `UUnrealEditorSubsystem::WorldToScreen()` + `SEditorViewport::AddOverlayWidget()` — see `FNexusDebugLabelOverlay`.
  - `LandscapePathOverlayColor` (`FLinearColor`, default (1, 0.05, 0.9))
  - `LandscapePathOverlayThickness` (`float`, default 6, ClampMin 0.1)
  - `LandscapePathOverlayZOffset` (`float`, default 10)
  - `DebugDrawOverrides` (`TMap<ENexusDebugDrawCategory, FNexusDebugDrawConfig>`) — missing entry or `bShouldOverride=false` = hardcoded base value.
  - `LineZOffset` (`float`, default 10) — vertical offset for every Highway/Lane/Sidewalk debug line (all sample the tessellated Landscape spline curve so they sit flush with terrain and can z-fight). Separate from `LandscapePathOverlayZOffset` (only affects Landscape Segment Lines category). Does NOT affect State/City bounding boxes, Segment box, or Junction/decoration markers.

- **`FNexusDebugDrawState`** (USTRUCT, BlueprintType) — debug-draw STATE (which categories currently ON), saved per-Layout (`UNexusLayoutAsset::DebugDrawState`). Subsystem keeps a live in-memory copy the panel's checkboxes read/write directly, mirrored to/from `CurrentLayoutAsset` on Save/Load.
  - `bShouldDrawDebug` (default false) — MASTER switch, everything else inert while false.
  - `bShouldDrawState` (default true), `bShouldDrawCity` (default true)
  - Highway branch: `bShouldDrawHighway` (true), `bShouldDrawLane` (false, per-lane offset lines, approximate/diagnostic), `bShouldDrawJunction` (true), `bShouldDrawHighwayName` (false), `bShouldDrawLaneIndex` (false, composes into one label with LaneSide if both on), `bShouldDrawLaneSide` (false, shows Left/Right).
  - Segment branch: `bShouldDrawSegment` (false), `bShouldDrawSegmentName` (false, shows NodeType classification), `bShouldDrawSegmentBox` (false, alternate marker to Junction's sphere).
  - `bShouldDrawPointName` (false) — "Name (Code)" label, independent of Segment's NodeType label.
  - `bShouldDrawSidewalk`, `bShouldDrawTrafficLight`, `bShouldDrawCrosswalk`, `bShouldDrawParking`, `bShouldDrawBusStop`, `bShouldDrawPetrolPump`, `bShouldDrawChargingStation`, `bShouldDrawServiceGarage` — all default true.
  - `bShouldDrawLandscapePathOverlay` (default false).

### `NexusRoadPoint.h`
Depends on `NexusRoadTypes.h`, `NexusPointTargetTypes.h` (Shared), `NexusHighwayFeatureTypes.h` (Shared).

- **`FNexusRoadPoint`** (USTRUCT, BlueprintType) — one point in the authored road network. Owns Nexus-side config ONLY — Location/Rotation/tangents are NOT the primary source when `SourcePoint` resolves; they live on the referenced Landscape spline control point (Nexus-owns-config / Landscape-owns-geometry split). A point has no direct State/City reference — reached via its highway's ownership (`FNexusWorldData::GetPointOwnerCityIds()`).
  - `PointId` (`FGuid`, VisibleAnywhere/ReadOnly) — real key, never reused, never index-derived.
  - `Code` (`FName`, default `NAME_None`) — short, validated-unique (NAME_None always valid, never collides with another NAME_None).
  - `Name` (`FString`) — full display label, not required unique.
  - `SourcePoint` (`TSoftObjectPtr<ULandscapeSplineControlPoint>`, VisibleAnywhere/ReadOnly) — unset until Apply/Refresh materializes it. While resolvable, it (not Location/OutgoingTangentLen) is the live authoritative geometry source.
  - `Location` (`FVector`, default zero, VisibleAnywhere/ReadOnly, Geometry) — world-space snapshot of SourcePoint's Location, refreshed just before Save. Becomes the real persisted source of truth once `SourcePoint` no longer resolves (different/cleared Landscape), enabling `MaterializeMissingPointGeometry` to rebuild geometry from Nexus config alone. Meaningless (stays zero) until materialized at least once.
  - `Rotation` (`FRotator`, default zero, same category) — same idea for rotation; Nexus does not derive/author rotation itself, purely a captured record of Landscape's `AutoCalcRotation` or manual edits.
  - `OutgoingTangentLen` (`float`, default -1, ClampMin -1) — tangent length toward NEXT point in `OrderedPointIds`. -1 = not authored, falls back to `MaterializeMissingPointGeometry`'s distance-based default. Only meaningful if a next point exists in ITS OWN highway. For `bIsClosedLoop`, last point's "next" is the first point.
  - `IncomingTangentLen` (`float`, default -1, ClampMin -1) — independent counterpart for the segment coming IN from the PREVIOUS point (engine's `FLandscapeSplineSegmentConnection` stores each end independently — a single shared value cannot losslessly round-trip an asymmetrically-tangented segment). **Gotcha**: added AFTER `OutgoingTangentLen`; older saved Layouts deserialize this at -1 default gracefully (references a specific bug-fix audit doc: `ai-change-audits/bug-fixed/2026-08-09/tangent-lost-on-save-load-roundtrip.md`).
  - `AutoAdjustLandscape` (`int32`, default -1, ClampMin/Max -1/1) — whether segments touching this point auto-grade Landscape. -1 = inherit Highway→City→State→global. Deliberately ONE value per point (not incoming/outgoing split) — coarse by design. A segment (touching 2 points) resolves as the AND of both endpoints' resolved values (see `ResolveAutoAdjustLandscape`).
  - `ConnectedHighwayIds` (`TArray<FGuid>`, VisibleAnywhere/ReadOnly, Derived) — **"Never hand-edited"** rebuilt by `FNexusWorldData` mutators.
  - `NodeType` (`ENexusNodeType`, default `Unknown`, VisibleAnywhere/ReadOnly, Derived).
  - `bOverrideRenderColor` (`bool`, default false), `OverrideRenderColor` (`FLinearColor`, White, EditCondition), `bOverrideLineThickness` (false), `OverrideLineThickness` (`float`, default 2, EditCondition).
  - `PointFeatures` (`int32`, default 0, Bitmask `ENexusHighwayPointFeature`) — point-level decoration flags, carried verbatim into Tier 4 export.
  - `PointTargets` (`int32`, default 0, Bitmask `ENexusPointTarget`) — carried verbatim into `FNexusFinalPointData::PointTargets`.
  - `Description` (`ENexusPointDescription`, default `None`) — carried verbatim into `FNexusFinalPointData::Description`.
  - Decoration facts live directly here (single-source-of-truth rule), not a parallel struct — matches codebase convention.

### `NexusState.h`
Depends on `NexusHighwayMeshAssetSet.h`.

- **`FNexusState`** (USTRUCT, BlueprintType) — new root of V5 world hierarchy, above City. Purely logical container, no world-space transform/location of its own; position always computed live from cities' computed centers (`UNexusFrameworkEditorSubsystem::GetStateCenter()`). Creating a State never requires viewport interaction.
  - `StateId` (`FGuid`, VisibleAnywhere/ReadOnly) — real key.
  - `Code` (`FName`, default NAME_None) — short e.g. "STATE_01".
  - `Name` (`FString`) — full e.g. "California".
  - `bLockEdit` (`bool`, default false) — tools must refuse move/modify/delete when true.
  - `DataLayerAssetName` (`FName`, default NAME_None) — World Partition Data Layer streaming boundary; unset until wired.
  - `bLoaded` (`bool`, default true, VisibleAnywhere/ReadOnly) — mirrors runtime Data Layer loaded state, independently toggleable while Data Layer isn't wired yet.
  - `CityIds` (`TArray<FGuid>`, VisibleAnywhere/ReadOnly) — Derived, never edited directly, kept in sync by `FNexusRoadGraph`'s mutators. **Note**: comment references `FNexusRoadGraph` — this class name doesn't appear as a header file we were given; likely lives elsewhere in the module (not in the requested file list) or `FNexusWorldData` plays this role (comment appears in multiple files referencing "FNexusRoadGraph's mutators" — possibly an older/alternate name still in comments; flagging as a naming inconsistency to note for V6 doc, since `FNexusWorldData` is the actual mutator struct documented in `NexusWorldData.h`).
  - `HighwayIds` (`TArray<FGuid>`, VisibleAnywhere/ReadOnly) — Derived, every highway with this state as one of its owning states (includes cross-state highways touching it too).
  - `bOverrideRenderColor`/`OverrideRenderColor` (White)/`bOverrideLineThickness`/`OverrideLineThickness` (default 5).
  - `bOverrideFontSize` (false)/`OverrideFontSize` (`float`, default 12, ClampMin 1) — schema only, no renderer reads yet.
  - `MeshAssetSetOverride` (`TSoftObjectPtr<UNexusHighwayMeshAssetSet>`) — per-state override; city/highway below can override further.
  - `AutoAdjustLandscape` (`int32`, default -1, Clamp -1/1) — -1 inherit from `UNexusGenerationSettings::bAutoAdjustLandscapeByDefault`; 0 force off; 1 force on for everything under this state not overridden more specifically.
  - `CornerSharpDetectionAngle` (`float`, default -1, ClampMin -1, UIMax 180) — -1 inherit from `UNexusGenerationSettings::CornerSharpDetectionAngle`; 0-180 = inter-branch angle threshold for sharp Corner vs SmoothCorner classification.

### `NexusCity.h`
Depends on `NexusHighwayMeshAssetSet.h`; forward-declares `UNexusGenerationSettings`.

- **`FNexusCity`** (USTRUCT, BlueprintType) — logical container like State, no transform/location; position computed live from highways' control points (`GetCityCenter()`).
  - `CityId` (`FGuid`, VisibleAnywhere/ReadOnly).
  - `Code` (`FName`, default NAME_None, e.g. "CITY_01"), `Name` (`FString`, e.g. "New York").
  - `ParentStateId` (`FGuid`, VisibleAnywhere/ReadOnly) — ALWAYS valid, every city belongs to exactly one state (cities never shared between states, unlike highways). Set at creation, only changed by `FNexusRoadGraph::MoveCityToState` (again, method referenced only in comment; not in a header we read — likely lives on `FNexusWorldData` or an internal helper not in our file set) which keeps both states' `CityIds` in sync.
  - `bLockEdit` (`bool`, default false).
  - `bOverrideRenderColor`/`OverrideRenderColor`(White)/`bOverrideLineThickness`/`OverrideLineThickness`(default 4).
  - `bOverrideFontSize`(false)/`OverrideFontSize`(default 12, ClampMin 1) — schema only.
  - `MeshAssetSetOverride` (`TSoftObjectPtr<UNexusHighwayMeshAssetSet>`) — falls back to owning state's, then subsystem global default.
  - `LayoutSettingsOverride` (`TSoftObjectPtr<UNexusGenerationSettings>`) — per-city internal-grid recipe override; falls back to subsystem default `UNexusGenerationSettings` when unset.
  - `ConnectedHighwayIds` (`TArray<FGuid>`, VisibleAnywhere/ReadOnly, Derived) — every highway with this city as Start/EndCityId (own internal streets AND inter-city/cross-state highways touching it). Never edited directly.
  - `AutoAdjustLandscape` (`int32`, default -1, Clamp -1/1) — inherit chain: this city's State → global.
  - `CornerSharpDetectionAngle` (`float`, default -1, ClampMin -1, UIMax 180) — inherit: State → global.

### `NexusHighway.h`
Depends on `NexusRoadTypes.h`, `NexusSharedRoadTypes.h`, `NexusHighwayFeatureTypes.h`, `NexusHighwayMeshAssetSet.h`.

- **`FNexusHighway`** (USTRUCT, BlueprintType) — a road: ordered sequence of point ids. Connecting a new point to an existing highway's open endpoint extends `OrderedPointIds` in place via `FNexusRoadGraph::ConnectPoints` (again referenced only in comment — likely an internal method not exposed in the headers given us, possibly folded into `FNexusWorldData::AddPointToHighway` in the actual current implementation; flag this naming discrepancy), unless the connection would make the shared point a 3+-way junction.
  - `HighwayId` (`FGuid`, VisibleAnywhere/ReadOnly) — real key.
  - `Code` (`FName`, default NAME_None, e.g. "HWY_01"), `Name` (`FString`, e.g. "Main Street") — Code uniqueness rules match `FNexusRoadPoint::Code`.
  - `bLockEdit` (`bool`, default false).
  - `OrderedPointIds` (`TArray<FGuid>`) — points in path order. Only 2 endpoints = straight/naturally-curved segment; interior points subdivide further.
  - `bIsClosedLoop` (`bool`, default false) — true if `OrderedPointIds.Last()` connects back to `[0]` via an EXTRA segment forming a closed ring (roundabout/loop road). **Gotcha (heavily emphasized)**: `OrderedPointIds` never repeats the first point at the end — this flag is the ONLY record of the closing connection. Set by loop-detection during Sync From Landscape import. Consumed by `MaterializeMissingPointGeometry` which otherwise only connects consecutive pairs and would silently drop the closing segment on every Save/Load round-trip — the exact bug this field fixes. Must never be inferred from geometry after the fact — authored/discovered state, persisted like any other field.
  - `bIsMainHighway` (`bool`, default false) — every city has exactly one Main Highway.
  - `ParentHighwayId` (`FGuid`, VisibleAnywhere/ReadOnly) — set when this highway branched off another at a junction rather than extending in place. Invalid (`FGuid()`) = top-level/no parent.
  - `StartCityId`, `EndCityId` (`FGuid`, VisibleAnywhere/ReadOnly) — set by generation. Exactly one set = internal street; both set = bridges two cities. **No "neither set" case exists** — every generator-created highway belongs to at least one city.
  - **`GetOwnershipKind() const`** (inline) — returns `InterCityHighway` if both Start/EndCityId valid, else `InternalCityRoad`.
  - **`GetOwnerCityId() const`** (inline) — returns the single owning city id for `InternalCityRoad`; invalid `FGuid` for `InterCityHighway` (neither is "the" owner).
  - `bOverrideRenderColor`/`OverrideRenderColor`(White)/`bOverrideLineThickness`/`OverrideLineThickness`(default 3).
  - `bOverrideFontSize`(false)/`OverrideFontSize`(default 12, ClampMin 1) — schema only.
  - `MeshAssetSetOverride` (`TSoftObjectPtr<UNexusHighwayMeshAssetSet>`) — MOST SPECIFIC level: Highway → City → State → subsystem global default.
  - `SpeedLimit` (`float`, default -1) — -1 = global default, 0 = no limit, >0 = custom.
  - `Features` (`int32`, default 0, Bitmask `ENexusHighwayFeature`) — rules-of-the-road, carried verbatim into `FNexusFinalHighwayData::Features`.
  - `LaneConfiguration` (`ENexusLaneConfiguration`, default `TwoLanes`).
  - `LaneWidth`, `LaneGap` (gap between adjacent lanes same side), `CenterMedianGap` (space between left/right lane groups for median), `SidewalkGap` (offset from highway edge to sidewalk start), `LeftSidewalkWidth` (0 = no left sidewalk), `RightSidewalkWidth` (0 = no right sidewalk) — all `float`, default -1: -1 = global default (`UNexusGenerationSettings`), 0 = explicitly disabled, >0 = custom.
  - `AutoAdjustLandscape` (`int32`, default -1, Clamp -1/1) — inherit City→State→`UNexusGenerationSettings::bAutoAdjustLandscapeByDefault`. 0 = force off (e.g. bridge/flyover/tunnel), regardless of `bRaiseTerrain`/`bLowerTerrain` below.
  - `bRaiseTerrain` (`bool`, default true) — only consulted when `AutoAdjustLandscape` resolves true.
  - `bLowerTerrain` (`bool`, default true) — same gate.
  - `TerrainLayerName` (`FName`, default NAME_None) — Landscape paint layer; NAME_None = no layer painted.
  - `CornerSharpDetectionAngle` (`float`, default -1, ClampMin -1, UIMax 180) — inherit City→State→`UNexusGenerationSettings::CornerSharpDetectionAngle`.

---

## MODULE: Editor Subsystem/Module (root `Source/NexusFrameworkEditor/Public/`)

### `NexusFrameworkEditorModule.h`
- **`FNexusFrameworkEditorModule : public IModuleInterface`** — standard module entry.
  - `StartupModule()`, `ShutdownModule()` (overrides).
  - `LandscapeModeExtension` (`FNexusFrameworkLandscapeModeExtension`, private member) — owns the tab lifecycle extension.

### `NexusFrameworkEditorSubsystem.h` (1472 lines — read in full)
This is the central editor subsystem. Depends on `NexusWorldData.h`, `NexusLayoutAsset.h`, `NexusDebugDrawSettings.h`.

**Free enums (declared at file scope, before the class):**
- **`ENexusFrameworkSelectionKind`** (`uint8`, BlueprintType) — `None, State, City, Highway, Point`. Which entity is the active/selected Hierarchy node; drives details panel and viewport highlighting.
- **`ENexusSyncDiffStatus`** (`uint8`, plain enum, NOT UENUM) — `Synchronized, MissingInUE, UntrackedInNexus, Mismatch`. Result classification for one `FNexusSyncDiffEntry`.
- **`ENexusLayoutSaveResult`** (`uint8`, plain enum) — `Succeeded, Failed, Cancelled`. Outcome of Save/SaveAs; distinguishes real write failure from user cancelling the native Save Asset dialog.
- **`ENexusSyncMismatchFlags`** (plain `enum` — NOT enum class — `uint8`) — bitflags into `FNexusSyncDiffEntry::MismatchFlags`: `NexusSyncMismatch_None=0, _Location=1<<0, _Rotation=1<<1, _Tangent=1<<2` (Outgoing tangent), `_IncomingTangent=1<<3` (independent from `_Tangent`, added for `IncomingTangentLen`). Only meaningful when `Status==Mismatch`.

**`FNexusSyncDiffEntry`** (plain struct, not reflected, built fresh per `ComputeSyncDiff()` call, never stored) — one row of the sync-diff output:
- `Status` (`ENexusSyncDiffStatus`)
- `StateId`, `CityId`, `HighwayId`, `PointId` (`FGuid`) — ancestry, only meaningful for Synchronized/MissingInUE/Mismatch (invalid for UntrackedInNexus).
- `DisplayLabel` (`FString`) — `BuildPointDisplayLabel` for tracked points, or synthesized "Landscape Point <guid>" for untracked (control points have no Name/Code).
- `ControlPoint` (`TWeakObjectPtr<ULandscapeSplineControlPoint>`) — resolves for every Status except MissingInUE.
- `ChainIndex` (`int32`, default `INDEX_NONE`) — which untracked chain this entry belongs to (see `BuildChainsFromUntrackedPoints`); unused for other statuses.
- `MismatchFlags` (`uint8`, default `NexusSyncMismatch_None`) — non-zero only when Mismatch.
- `NexusLocation`/`UELocation` (`FVector`), `NexusRotation`/`UERotation` (`FRotator`), `NexusTangent`/`UETangent` (`float`, default -1, outgoing), `NexusIncomingTangent`/`UEIncomingTangent` (`float`, default -1) — valid whenever Status is Synchronized or Mismatch, kept even when matching so a Synchronized row can still be inspected.

**`UNexusFrameworkEditorSubsystem : public UEditorSubsystem, public FTickableEditorObject`** — owns the live, editable Nexus world data while the authoring panel is in use, not tied to any placed actor/level. `WorldData` is always the live authoring graph; New/Save/SaveAs/Load/Delete persist it to/from a `UNexusLayoutAsset`.

**Lifecycle / Tick:**
- `Initialize(FSubsystemCollectionBase&)`, `Deinitialize()` — overrides.
- `Tick(float DeltaTime)` override (FTickableEditorObject) — **Key architectural fact**: this is what makes `DrawDebugOverlays` (and world-space labels) update every editor frame regardless of which dockable tab/mode has focus. Previously only called from `SNexusFrameworkPanel::Tick()`, which silently stopped updating when switching tabs/modes. Subsystem lives for the whole editor session; ticking here fixed the real lifecycle bug. `DrawDebugOverlays()` internally no-ops when off, so unconditional calling is safe.
- `GetStatId() const` override.
- `PostEditUndo()` override — **Critical gotcha**: every mutating entry point wraps changes in `FScopedTransaction` + `Modify()`, so Ctrl+Z restores WorldData's raw property data, but that's a wholesale UStruct property-serialize that tears down/rebuilds every TMap from scratch — silently invalidating every raw `FNexusState/City/Highway*` pointer the Details panel's `FStructOnScope` was holding (none of `OnLayoutChanged`/`OnActiveSelectionChanged` fire during undo/redo — it bypasses all setters/mutators). Without this override the Details panel crashed (EXCEPTION_ACCESS_VIOLATION) on repaint after Ctrl+Z. Re-broadcasts both delegates to force listeners to rebuild against post-undo WorldData.

**World data access:**
- `const FNexusWorldData& GetWorldData() const`
- `FNexusWorldData& GetMutableWorldData()`

**Active selection:**
- `GetActiveSelectionKind() const` → `ENexusFrameworkSelectionKind`; `GetActiveSelectionId() const` → `FGuid`.
- `SetActiveState(FGuid)`, `SetActiveCity(FGuid)`, `SetActiveHighway(FGuid)`, `SetActivePoint(FGuid)`, `ClearActiveSelection()`.
- `GetActiveHighwayId() const` → `FGuid` — most recently active Highway selection independent of current selection (e.g. still valid after selecting a Point on it) — what Apply Configuration re-pushes onto. Invalid if no highway ever activated this session.
- `OnActiveSelectionChanged` (`FSimpleMulticastDelegate`) — broadcast on selection change.
- `OnEntityLabelChanged` (`DECLARE_MULTICAST_DELEGATE_TwoParams(FOnEntityLabelChanged, ENexusFrameworkSelectionKind, FGuid)`) — broadcast when an entity's Name/Code (and Hierarchy label) may have changed, from either Details panel or Hierarchy tree rename. Narrower than `OnLayoutChanged` (which means "rebuild everything") — a rename never adds/removes rows. This decoupling is what lets Details panel and Hierarchy tree live in independently-dockable tabs with no direct reference to each other.

**Layout Tools:**
- `NewLayout()` — gated by `ResolveUnsavedChangesBeforeProceeding`; resets to default State1>City1>Highway1.
- `SaveLayout()` → `ENexusLayoutSaveResult` — writes WorldData into `CurrentLayoutAsset` in place; falls through to `SaveLayoutAs()` if none loaded. **No longer reachable via dedicated UI button** — now called by `HandlePostSaveWorld` after every successful UE map save (auto-save architecture), and by `ResolveUnsavedChangesBeforeProceeding`'s "Yes, save first" branch. Only clears `bIsDirty`/returns Succeeded if the underlying write actually succeeded. Calls `SyncFromLandscape()` first, silently.
- `SaveLayoutAs()` → `ENexusLayoutSaveResult` — always prompts native Save Asset dialog, creates/overwrites, makes it `CurrentLayoutAsset`. Also calls `SyncFromLandscape()` first, silently.
- `LoadLayout()` — prompts native Open Asset dialog, loads chosen `UNexusLayoutAsset` into WorldData.
- `IsLayoutDirty() const` → `bool`; `GetCurrentLayoutAsset() const` → `UNexusLayoutAsset*`.
- `MarkLayoutDirty()` — inline, calls `MarkWorldDataDirty()`. Public entry for UI editing WorldData directly (e.g. `IStructureDetailsView`).
- `LayoutFolder` (`FString`, EditAnywhere, default "/Game/NexusLayouts") — default folder for Save/Load dialogs.
- `DefaultMeshAssetSet` (`TSoftObjectPtr<UNexusHighwayMeshAssetSet>`, EditAnywhere) — editor-level default, last stop of `ResolveHighwayMeshSet` chain. Mirrored to/from `CurrentLayoutAsset::DefaultMeshAssetSet` on Save/Load — **NOT a global editor preference**, deliberately, since that would leak between Layouts.
- `GenerationSettings` (`TSoftObjectPtr<UNexusGenerationSettings>`, EditAnywhere) — editor-level default City Generate Configuration, last stop of `ResolveGenerationSettings` chain. Also gates whether "New City" auto-arms Generate Random City. Mirrored to/from `CurrentLayoutAsset::GenerationSettings`.
- `DebugDrawSettingsAsset` (`TSoftObjectPtr<UNexusDebugDrawSettings>`, EditAnywhere) — mirrored to/from `CurrentLayoutAsset::DebugDrawSettingsAsset`.
- `DebugDrawState` (`FNexusDebugDrawState`, EditAnywhere) — panel checkboxes read/write directly; mirrored to/from `CurrentLayoutAsset::DebugDrawState`.
- `ResolveUnsavedChangesBeforeProceeding(const FText& ContextMessage)` → `bool` — Yes/No/Cancel prompt if `bIsDirty`; Yes must actually succeed to return true. Gates New/Load Layout.
- `HasRealUnsyncedChanges() const` → `bool` — true if `ComputeSyncDiff()` finds ANY real difference (topology or Location/Rotation/Tangent mismatch). More precise than `bIsDirty` (a coarse "something might have changed" flag).
- `ResolveUnsavedChangesOnExit()` — called from contexts that can't be cancelled (leaving Landscape Mode, editor shutdown). Only Yes/No, never Cancel. If `bIsDirty` but `HasRealUnsyncedChanges()` finds nothing, silently clears `bIsDirty` instead of prompting.
- `OnLayoutChanged` (`FSimpleMulticastDelegate`).

**Landscape (Phase 3) — Nexus owns config, Landscape owns geometry:**
- `ResolveTargetLandscape() const` → `ALandscape*` — first `ALandscape` in editor world, or nullptr; never creates one.
- `IsControlPointOnTargetLandscape(const ULandscapeSplineControlPoint*) const` → `bool` — true only if ControlPoint's immediate Outer is the CURRENT map's own SplinesComponent, not merely "resolves to a live UObject somewhere." **Closes a specific cross-map bug**: `TSoftObjectPtr::LoadSynchronous()` resolves by package path independent of which level is open, so a Layout saved while a different map was active could resolve "successfully" to a still-resident control point belonging to a DIFFERENT map's package — a plain null check can't tell the cases apart.
- `GetOrCreateLandscapeSplinesComponent(ALandscape*) const` → `ULandscapeSplinesComponent*` — creates if missing; nullptr only if Landscape itself null.
- `IsLandscapeSplinesToolActive() const` → `bool` — best-available signal for "is Landscape Mode's own Splines tool selected" — **no public API exists** for this (private engine module); reads `ULandscapeSplinesComponent::bShowSplineEditorMesh`, a public flag the Splines tool flips on Enter/ExitTool. Requires Landscape Mode active AND a target Landscape with existing splines component; false (not "unknown") otherwise.
- `ResolveHighwayMeshSet(const FNexusHighway&, UNexusHighwayMeshAssetSet** OutResolvedAsset=nullptr) const` → `const FNexusHighwayMeshSet*` — chain: Highway's own override → City's → State's → subsystem `DefaultMeshAssetSet` → nullptr. `OutResolvedAsset` (optional) set to which asset the returned set came from (needed for shared street-furniture slots living on the asset itself).
- `ResolveAutoAdjustLandscape(const FNexusHighway&, const FNexusRoadPoint* Point=nullptr) const` → `bool` — resolves Point(optional)→Highway→City→State→`UNexusGenerationSettings::bAutoAdjustLandscapeByDefault`→true. First explicit 0/1 wins, most-specific first. `Point=nullptr` for resolving in the abstract; a segment's effective value = AND of both endpoints (caller's responsibility).
- `ResolveCornerSharpDetectionAngle(const FNexusHighway&, FString* OutSourceLabel=nullptr) const` → `float` — Highway→City→State→`UNexusGenerationSettings::CornerSharpDetectionAngle`→100.f. **TEMPORARY DIAGNOSTIC param** noted in header (dated 2026-08-09, investigation into Save→Load corner/mesh classification mismatch): `OutSourceLabel` set to which level supplied the value ("Highway"/"City"/"State"/"GlobalGenerationSettings"/"GlobalDefault100"), purely observational.
- `TryGetPointWorldLocation(const FNexusRoadPoint&, FVector& OutLocation) const` → `bool` — pulls live geometry off SourcePoint; false if unset/unresolved.
- `TryGetPointWorldRotation(const FNexusRoadPoint&, FRotator& OutRotation) const` → `bool` — same, reading landscape-space Rotation transformed to world.
- `static BuildPointDisplayLabel(const FNexusRoadPoint&) const` → `FString` — "Name (Code)"; falls back to "Point" when Name empty; omits "(Code)" suffix when Code is NAME_None.
- `RecomputePointClassification(FNexusRoadPoint&, const FNexusHighwayMeshSet*, bool bRestoreSavedRotation=false)` — re-classifies `ENexusNodeType` from live `ConnectedSegments` (count+angle), recomputes tangent direction via `ComputeDeterministicJunctionForward` (ported from V4's `UNexusJunctionAnalysis::AnalyzeJunction`: bisector for Corner, through-direction for Straight/SmoothCorner, largest-angular-gap for TJunction, lowest-angle-sorted branch for CrossJunction/MultiJunction/DeadEnd), assigns resolved junction mesh via `ResolvePointMeshSlot` for junction NodeTypes, or clears `ControlPoint->Mesh` for Straight/SmoothCorner (those use the segment's own SplineMeshes instead). No-op if not materialized. **Does NOT call caller's `RebuildAllSplines`/`MarkPackageDirty`** — caller batches. **Deliberately does NOT call the engine's `AutoCalcRotation()`** even for the 2-connection closed-form-slerp case — reasons: engine's 1-or-3+ branch is single-step iterative delta not a from-scratch solve (confirmed via engine source ~LandscapeSplines.cpp 2147-2179), and even the 2-connection Slerp differs numerically from V4's formula; V5 needed V4's exact baseline to reuse V4's tuned per-mesh OffsetRotation values. `bRestoreSavedRotation` (default false, used only by `MaterializeMissingPointGeometry`'s Load-time pass) — restores the exact converged rotation as saved rather than recomputing, so T/Cross/MultiJunction tangent direction matches what was saved (references `ai-change-audits/bug-fixed/2026-08-09/tangent-lost-on-save-load-roundtrip.md`).
- `static ResolvePointMeshSlot(ENexusNodeType, const FNexusHighwayMeshSet*)` → `const FNexusHighwayRoadMeshConfig*` — Straight/SmoothCorner→MainHighwayMesh, Corner→CornerHighwayMesh, TJunction→TJunctionMesh, CrossJunction/MultiJunction→CrossJunctionMesh. nullptr for DeadEnd/Unknown or null MeshSet.
- `ApplyPointFurniture(FNexusRoadPoint&, const FNexusHighwayMeshSet*, const UNexusHighwayMeshAssetSet* AssetSet)` — first real consumer of `PointFeatures` TrafficLight/Crosswalk bits. Idempotent: destroys existing furniture (tagged by PointId) first, then spawns fresh `UStaticMeshComponent`s per flag if `AssetSet` non-null: TrafficLight→AssetSet's TrafficLightMesh or MeshSet's override; Crosswalk→both CrosswalkMesh (ground) and CrossWalkSignMesh (pole), each independently offsettable. No-op-but-still-clears-furniture if not materialized or AssetSet null. Does not call RebuildAllSplines/MarkPackageDirty (caller batches).

**Generate Random City (populates ONE city's internal street grid directly on Landscape, terrain-height-sampled):**
- `IsGenerateCityOriginArmed() const` → `bool`; `SetGenerateCityOriginArmed(bool bArmed, FGuid CityId=FGuid())` — arms origin-picker; next viewport click becomes origin. `CityId` captured into `PendingGenerateCityId` at ARM time (not re-derived from active selection at click time — selection can legitimately move between arming and clicking). Auto-disarms after one click. No-op if `PendingGenerateCityId` doesn't resolve by click time.
- `GenerateCityInternalGrid(FGuid CityId, const FVector& OriginWorldLocation)` → `int32` (points created) — builds `NumRows x NumColumns` grid centered on origin, spaced by `BlockSpacing` (interior points jittered by `InternalPositionJitterFraction`, perimeter not), wires adjacent pairs (never diagonally), classifies every point afterward. **Terrain-aware**: each grid point's height sampled from real Landscape DURING placement, not decided flat-then-patched (the gap V4's own generator left, per its own comment). Uses `Settings->RandomSeed`/`bDeterministic`. Settings resolves via `ResolveGenerationSettings(CityId)`. No-op if no target Landscape or bad CityId.
- `ResolveGenerationSettings(FGuid CityId) const` → `const UNexusGenerationSettings*` — City's `LayoutSettingsOverride` → `CurrentLayoutAsset`'s `GenerationSettings` → nullptr (caller falls back to a plain default-constructed instance).

**Apply / Sync — pushing Nexus config onto Landscape, and reconciling both ways (position never flows either direction — Landscape is always position's only source of truth):**
- `ApplyHighwayConfiguration(FGuid HighwayId)` — re-resolves/re-applies mesh/width onto every already-placed control point/segment on Highway. Does not move points or change topology. No-op if <1 materialized point.
- `ApplyAllConfiguration()` — `ApplyHighwayConfiguration` for every highway.
- `SyncFromLandscape(int32& OutRemovedCount, int32& OutImportedCount)` — reconciles both directions: 1) removal of `FNexusRoadPoint`s whose `SourcePoint` no longer resolves; 2) import of untracked control points grouped into chains by walking `ConnectedSegments` (chain ends at any point with != 2 connections), each chain becomes one new highway owned by active highway's city (else arbitrary existing city, else skipped); 3) connector detection — a native segment directly joining two ALREADY-tracked points with no adjacency representation gets registered as a standalone 2-point highway (mirrors V4's "not cleanly-extendable → branch, new highway" fallback). Idempotent (`IsAdjacencyRepresentedInWorldData` guard). Never touches position. Also called silently from `SaveLayout()`/`SaveLayoutAs()` before every disk write.
- `RemoveOrphanedPointsFromLandscape()` → `TArray<FGuid>` — just SyncFromLandscape's removal direction, cheap (O(n) over WorldData.Points, no Landscape scan) — runs every tick while Splines tool active. Does NOT import untracked points (that stays manual-only, since silently materializing new points/highways every tick would be surprising). Returns removed ids for surgical tree row removal.

**Sync Diff — read-only diagnostic layer, never mutates:**
- `ComputeSyncDiff() const` → `TArray<FNexusSyncDiffEntry>` — every tracked Point (walked top-down State→City→Highway→OrderedPointIds, carrying ancestry) classified MissingInUE/Mismatch (tolerances: 0.5/0.1/0.5 for Location/Rotation/Tangent, matching `OnLandscapeSplineObjectTransacted`'s own tolerances, including the "-1 stays -1 if live tangent still matches auto-distance formula" rule)/Synchronized. Untracked control points become UntrackedInNexus, grouped by `BuildChainsFromUntrackedPoints`. A junction point shared by multiple highways is visited once per highway (matches Hierarchy tree precedent, not a bug). Const, no Modify()/transaction/mutation — safe to call as often as needed.

**Materialize / Clear:**
- `MaterializeMissingPointGeometry()` — creates real Landscape geometry for every Point whose `SourcePoint` doesn't resolve, using each Point's stored `Location` (not a live click) plus highway's `bRaiseTerrain`/`bLowerTerrain`/`TerrainLayerName` and per-point `OutgoingTangentLen` overrides. Already-materialized points are left alone, used only as connection anchors. Makes Load Layout's "Load Fresh" and "Import and Merge" both work through the same path. No-op if no target Landscape or nothing missing.
- `ClearAllLandscapeGeometry()` — destroys every control point/segment on the target Landscape's splines component and every referencing `FNexusRoadPoint`. Highways/Cities/States themselves untouched (just left with empty `OrderedPointIds`). Irreversible outside Ctrl+Z; panel must confirm first. No-op if no target Landscape/splines component.

**Delete (always leaves at least one State/City/Highway):**
- `DeleteActiveSelection()` → `bool` — deletes whatever's active-selected, dispatching on `ActiveSelectionKind`. No-op if None. Returns true if the delete triggered `EnsureMinimumWorldDataOrReset` (full reset) — callers use this to decide full rebuild vs surgical removal.
- `DeletePoint(FGuid)` → `bool` — deletes materialized control point + connecting segments (other endpoints stay materialized, just lose their connection) + tagged furniture, then the `FNexusRoadPoint`. No-op if doesn't resolve. Selects next/previous point in highway, or the highway itself if it was the only point.
- `DeleteHighway(FGuid)` → `bool` — deletes every segment connecting its OrderedPointIds, then every point EXCLUSIVELY on this highway (a junction point shared with another highway survives, loses only this highway's segments), then the highway. Selects sibling highway or the city.
- `DeleteCity(FGuid)` → `bool` — `DeleteHighway` for every owned highway, then the city. Selects sibling city or state.
- `DeleteState(FGuid)` → `bool` — `DeleteCity` for every owned city, then the state. Selects any other existing state (no ordered sibling concept for states).

**Create / Duplicate (deliberately does NOT broadcast `OnLayoutChanged` — callers add rows surgically instead, avoiding tree collapse):**
- `AddNewState()` → `FGuid` — new State + auto-created City + auto-created Highway (matches default layout shape). Selects new Highway. Always succeeds.
- `AddNewCity(FGuid ParentStateId)` → `FGuid` — new City + auto-created Highway. Selects new Highway. No-op if bad parent.
- `AddNewHighway(FGuid OwnerCityId)` → `FGuid` — new empty Highway. Selects it. No-op if bad parent.
- `DuplicateState(FGuid)` → `FGuid`; `DuplicateCity(FGuid)` → `FGuid`; `DuplicateHighway(FGuid)` → `FGuid` — deep-duplicate config + cascade into children (State/City) or empty duplicate (Highway, no points). Selects the new entity. No-op (invalid Guid) if bad source id.

**Computed centers (State/City/Highway are pure logical containers, no stored location — "Hierarchy Objects Have Computed Locations"):**
- `GetHighwayCenter(FGuid, FVector& OutCenter) const` → `bool` — average of every materialized control point on the highway's points. False if none materialized.
- `GetCityCenter(FGuid, FVector& OutCenter) const` → `bool` — average of every highway center among city's `ConnectedHighwayIds`.
- `GetStateCenter(FGuid, FVector& OutCenter) const` → `bool` — average of every city center among state's `CityIds`.
- `GetActiveSelectionCenter(FVector& OutCenter) const` → `bool` — computed center for current active selection (average, or Point's own SourcePoint location). What the panel focuses the camera on.
- `GetActiveSelectionBounds(FBox& OutBounds) const` → `bool` — actual bounding box (not just average) of every materialized point under active selection; a single Point gets a small `MinPointBoxExtent`-sized box. Used for camera-focus framing instead of one fixed-size box for every selection kind.

**Debug Draw (viewport overlays):**
- `DrawDebugOverlays() const` — re-issues every enabled category's `DrawDebugLine/Sphere/Box` calls, queues text labels into `LabelOverlay`, using `DebugDrawState`'s toggles and `DebugDrawSettingsAsset`'s (or default-constructed fallback's) appearance. `bPersistentLines=false` + short `LifeTime` — must be called every frame or lines expire. No-op if master switch off or no editor world.

**Viewport highlighting (purely visual — does not change Landscape Mode's actual tool-side selection):**
- `RefreshLandscapeSelectionHighlight()` — clears prior highlight, re-highlights every materialized point/segment under current active selection. Called automatically on `OnActiveSelectionChanged`. No-op (but still clears) if nothing materialized.
- `DetectAndClearHighlightIfOverriddenByViewport()` → `bool` — polls (no public delegate exists for "spline selection changed" — confirmed via engine research) whether the native Landscape selection differs from `LastAppliedHighlightPoints`; if so, clears our own bookkeeping (not the Landscape's native selection) and returns true so panel Tick can refresh UI. False if unchanged.
- `SyncActiveSelectionFromNativeViewportSelection()` — read-only poll (called once/tick, gated on `IsLandscapeSplinesToolActive`) detecting the user selecting a different control point natively; calls `SetActivePoint` if it resolves to a tracked Point. **Deliberately ONLY reads `IsSplineSelected()`, never calls `SetSplineSelected`** (unlike `RefreshLandscapeSelectionHighlight`, which the header elsewhere calls out as disabled due to a confirmed engine crash risk) — a pure read carries no risk of desyncing Landscape Mode's private selection bookkeeping.

**Private section highlights (selected, since these encode architecture/gotchas useful for a reference doc even though private):**
- `ComputeCityBounds`/`ComputeStateBounds` (private) — bounding box helpers shared by DrawDebugOverlays and each other.
- `WorldData` (`UPROPERTY() FNexusWorldData`).
- `ActiveSelectionKind`/`ActiveSelectionId`/`ActiveHighwayId` are `UPROPERTY()` (not plain members) specifically so Delete/DrawPoint/etc undo restores exactly what was selected, not just WorldData.
- `bIsDirty` (`bool`, plain member).
- `MarkWorldDataDirty()` (private) — the ONE place `bIsDirty` is ever set true internally; also marks `CurrentLayoutAsset`'s package dirty so the engine's native "Unsaved Assets" tracker picks it up for free (confirmed via engine source: listens to `UPackage::PackageMarkedDirtyEvent` for ANY package).
- `ClearStalePackageDirtyFlag(UNexusLayoutAsset*)` (private) — counterpart for discard paths (NewLayout, LoadFresh, forced map-open reset) so a discarded change doesn't leave a phantom "unsaved" entry.
- `CurrentLayoutAsset` (`TWeakObjectPtr<UNexusLayoutAsset>`).
- `LastAppliedHighlightPoints` (`TSet<TWeakObjectPtr<ULandscapeSplineControlPoint>>`).
- `LastPolledNativeSelectionPoint` (`TWeakObjectPtr<ULandscapeSplineControlPoint>`).
- `DrawPointInputProcessor` (`TSharedPtr<FNexusDrawPointInputProcessor>`) — shared next-click capture, historically shared with the now-removed Draw Point tool; Generate Random City's origin-picker is its only remaining user.
- `LandscapeSplineTransactedHandle`, `MapOpenedHandle`, `PostSaveWorldHandle`, `EditorPreExitHandle` (`FDelegateHandle`s) — bound in Initialize, removed in Deinitialize.
- **`OnLandscapeSplineObjectTransacted(UObject*, const FTransactionObjectEvent&)`** (private) — Landscape→Nexus live sync, the largest and most architecturally significant private method (its doc comment spans ~130 lines in the header). Key facts:
  - Bound to `FCoreUObjectDelegates::OnObjectTransacted`, fires for EVERY transacted UObject — chosen because it's confirmed (via engine source) to be the only delegate that fires for a viewport gizmo drag on a control point (`PostEditChangeProperty`-based delegates only fire for Details-panel edits, not direct viewport manipulation). Also fires on Undo/Redo.
  - Scope: Location + Rotation (control point branch), `OutgoingTangentLen` (segment branch, since `TangentLen` lives on `FLandscapeSplineSegmentConnection` not the control point). Tolerance checks before marking anything changed.
  - **Undo/Redo architecture (hard requirement, stated explicitly)**: UE owns Undo/Redo for Landscape-originated changes — this handler must NEVER open its own `FScopedTransaction` for them. It calls plain `Modify()` (never Begin/EndTransaction) which JOINS the already-open transaction rather than creating one (verified against engine source that `SaveObject()` doesn't touch `ActiveCount`/`ActiveRecordCounts` bookkeeping that a nested `FScopedTransaction` would crash against). Requires this class's `RF_Transactional` flag (set once in Initialize()) — without it, `Modify()` silently no-ops.
  - Deletion: a deleted control point is never destroyed (Rename()'d into transient package, kept alive by Undo buffer) — detected via `GetOuterSafe()==nullptr`, routes to `DeletePointNoTransaction` (NOT public `DeletePoint()`, which would crash by opening a nested transaction).
  - First-point / new-segment registration: `TryAdoptFirstLandscapePoint` for a genuinely new isolated point (0 connected segments this transaction); `TryRegisterNewLandscapeSegment` / `TryAdoptNewLandscapePoint` for new-segment cases.
- `FindFreeHighwayEnd(FGuid PointId, FGuid& OutHighwayId, bool& bOutIsLast) const` (private) → `bool` — true only if PointId belongs to EXACTLY ONE highway AND sits at its first/last slot (unambiguous free end).
- `TryAdoptFirstLandscapePoint(ULandscapeSplineControlPoint*)` (private) — imports an isolated new point as the FIRST point of `ActiveHighwayId`'s highway; falls back to first existing highway, or builds missing State/City/Highway levels if WorldData is fully empty.
- `TryRegisterNewLandscapeSegment(ULandscapeSplineSegment*)` (private) — resolves both endpoints, and if eligible (both tracked, both genuine free ends via `FindFreeHighwayEnd`, different same-city `InternalCityRoad` highways) calls `MergeHighwaysForNewSegment`. Ineligible cases (already-junction endpoint, same-highway loop-close, cross-city/InterCityHighway pairing) all no-op (logged) rather than guess.
- `TryAdoptNewLandscapePoint(ULandscapeSplineSegment*, FGuid TrackedPointId, ULandscapeSplineControlPoint* NewControlPoint)` (private) — imports a new point onto an already-owned highway when exactly one endpoint is tracked and a free end. No ownership-kind/city check needed (never merges two highways).
- `MergeHighwaysForNewSegment(FGuid HighwayAId, bool bAIsLast, FGuid HighwayBId, bool bBIsLast)` (private) — concatenates HighwayB's `OrderedPointIds` onto HighwayA's (reversing as needed), repoints moved points' `ConnectedHighwayIds`, deletes HighwayB via `WorldData.RemoveHighway`. Also repoints `ActiveSelectionId`/`ActiveHighwayId` off the about-to-be-deleted HighwayBId.
- `DeletePointNoTransaction(FGuid)` (private) → `bool` — the exact WorldData cleanup `DeletePoint()` performs, WITHOUT the transaction wrapper. **Gotcha explicitly documented**: calling `DeletePoint()` synchronously from inside `OnLandscapeSplineObjectTransacted` previously crashed with `"ActiveRecordCounts.Num() == ActiveCount"` because that callback fires from inside `UTransBuffer::End()/Finalize()` for the Landscape delete's OWN transaction (still mid-close) — beginning a second transaction right then corrupts bookkeeping.
- `LabelOverlay` (`TSharedPtr<FNexusDebugLabelOverlay>`) — created in Initialize, destroyed (and detached) in Deinitialize.
- `PendingGenerateCityId` (`FGuid`) — captured at arm time.
- `HandleGenerateCityOriginClick(const FVector&)` (private) — the `OnValidClick` target while Generate Random City's origin-picker owns the processor.
- `HandleMapOpened(const FString& Filename, bool bAsTemplate)` (private) — bound to `FEditorDelegates::OnMapOpened`, fires after ANY level change (Open Level AND New Level). **Critical**: since this is a `UEditorSubsystem`, it survives level switches, so without this WorldData would silently keep referencing the previous level's Landscape. Root cause of a confirmed `"Connection.ControlPoint->GetOuterULandscapeSplinesComponent() == this"` ensure and "Illegal reference to private object... belongs to an external map" save failures and package leaks. Resets to fresh default layout — deliberately NOT wrapped in Modify()/transaction (no meaningful undo for a level switch).
- `HandlePostSaveWorld(UWorld*, FObjectPostSaveContext)` (private) — bound to `FEditorDelegates::PostSaveWorldWithContext`. **The entire auto-save architecture's trigger**: "UE map save is authoritative, Nexus follows." Fires unconditionally after EVERY world-save attempt. Three required guards: 1) `ObjectSaveContext.SaveSucceeded()`, 2) `!ObjectSaveContext.IsFromAutoSave()` (confirmed via engine source the autosave branch deliberately doesn't clear the real dirty flag), 3) `World == GEditor->GetEditorWorldContext().World()`. Then no-op if `!bIsDirty`; else calls `SaveLayout()`. On `Failed` (genuine write failure, not user-cancel), prompts Yes/No retry dialog, loops on Yes.
- `HandleEditorPreExit()` (private) — bound to `FEditorDelegates::OnEditorPreExit`; the actual-shutdown half of `ResolveUnsavedChangesOnExit`'s two trigger points (the other being leaving Landscape Mode).
- `ResetToDefaultLayout()` (private) — resets WorldData to default State1>City1>Highway1, makes Highway1 active. Shared by NewLayout and first-run Initialize.
- `DeletePointCore/DeleteHighwayCore/DeleteCityCore/DeleteStateCore` (private) — pure WorldData+Landscape mutation, no dirty-flag/selection/broadcast side effects, so cascading deletes (City→its Highways, State→its Cities) don't trigger per-child broadcasts.
- `FinishDeleteOperation(ENexusFrameworkSelectionKind FallbackKind=None, FGuid FallbackId=FGuid())` (private) → `bool` — common tail for every public Delete*: resets if below minimum, else selects fallback if it resolves, else clears selection; marks dirty; broadcasts `OnLayoutChanged`. Returns true if it reset (caller's cue for full tree rebuild vs surgical removal).
- `EnsureMinimumWorldDataOrReset()` (private) → `bool` — if WorldData now has zero States/Cities/Highways, resets to default baseline (standing invariant: at least one of each). No Landscape cleanup needed even on reset (reaching zero Highways globally means everything was already torn down by the cascade).
- `WriteWorldDataToAsset(UNexusLayoutAsset* Asset)` (private) — copies WorldData + `DebugDrawSettingsAsset`/`DebugDrawState` into Asset. Shared by SaveLayout/SaveLayoutAs.
- `SyncPointGeometrySnapshots()` (private) — refreshes every materialized Point's `Location`/`OutgoingTangentLen` snapshot from live SourcePoint, called once at the top of `WriteWorldDataToAsset` (not every tick), so saved data reflects current geometry even if the user forgot to click Apply Configuration.
- `PerformLoadFreshFromAsset(UNexusLayoutAsset* Asset)` (private) — shared by LoadLayout's LoadFresh choice AND the cross-map ownership dialog's Copy/Override choices. Replaces WorldData/DefaultMeshAssetSet/GenerationSettings/DebugDrawSettingsAsset/DebugDrawState wholesale, resets active selection. **Deliberately does NOT wipe the Landscape first** — the caller's later `MaterializeMissingPointGeometry` reuses whatever already resolves on this Landscape and only creates fresh geometry for the rest.
- `WarnAndMarkDirtyIfSyncDiffHasIssues()` (private) — called right after `MaterializeMissingPointGeometry()` on paths that don't wipe the Landscape first; surfaces `ComputeSyncDiff`'s UntrackedInNexus/Mismatch statuses via a blocking notice pointing at the Sync Inspector tab, plus `MarkWorldDataDirty()`. No-op if only Synchronized entries.

**Cross-file naming note/gotcha to flag**: Multiple Editor Schema headers' comments reference a class called `FNexusRoadGraph` (e.g. `NexusRoadTypes.h`'s `ENexusAnchorKind` comment references `FNexusRoadGraph::ResolveAnchorToPoint`; `NexusHighway.h` references `FNexusRoadGraph::ConnectPoints`; `NexusState.h`/`NexusCity.h` reference `FNexusRoadGraph`'s mutators and `FNexusRoadGraph::MoveCityToState`). However, the actual mutator struct documented and defined in `NexusWorldData.h` is named `FNexusWorldData`, and no `NexusRoadGraph.h` file was in the requested file list or appears to exist among these headers. This is either: (a) an old/internal name that these comments haven't been updated to match `FNexusWorldData` (post-rename comment drift), or (b) `FNexusRoadGraph` is a real, separate internal class living in a header outside the requested list. **This is worth flagging explicitly in the V6 reference doc** since a future agent reading only `NexusWorldData.h` would reasonably conclude `FNexusWorldData` is the sole graph-mutation entry point, per that header's own comment ("All graph mutation goes through the methods below"), yet several other headers refer to a differently-named class for the same/related operations.

---

## MODULE: Editor UI (`Source/NexusFrameworkEditor/Public/UI/`)

### `NexusDebugLabelOverlay.h`
- **`FNexusDebugLabelRequest`** (plain struct) — one frame's text label request: `WorldLocation` (`FVector`, zero), `Text` (`FString`), `Color` (`FLinearColor`, White), `FontSize` (`float`, 12).
- **`FNexusDebugLabelOverlay`** (plain class) — world-space text-label overlay, the text-label counterpart to subsystem's DrawDebugLine/Sphere/Box calls.
  - **Mechanism (confirmed via engine research)**: adds a single `SConstraintCanvas` to the first perspective level viewport's Slate overlay via `SEditorViewport::AddOverlayWidget` — same mechanism Epic's own `ViewportWidgetOverlay` plugin uses, confirmed NOT PIE-gated (unlike `DrawDebugString`, which needs a PlayerController/HUD unavailable in plain editor world).
  - `UpdateLabels()` repositions a POOLED set of `STextBlock`s via `UUnrealEditorSubsystem::WorldToScreen` (public forward counterpart of `ScreenToWorld`, used by the project's Draw Point tool for the reverse operation).
  - **Deliberately NOT a `UEdMode::DrawHUD()` override** — V5 cannot register a custom `UEdMode` (crash history) — called explicitly every frame by `DrawDebugOverlays` instead.
  - **Limitation**: only targets the first PERSPECTIVE level viewport if several are open (4-pane layout) — labels won't appear in other panes.
  - `~FNexusDebugLabelOverlay()` (destructor).
  - `EnsureRegistered()` — idempotent; finds first perspective viewport, adds overlay canvas if not already done or if the previous widget is gone (tab closed/reopened destroys/recreates `SLevelViewport`).
  - `UpdateLabels(const TArray<FNexusDebugLabelRequest>&)` — repositions/shows exactly `Requests.Num()` pooled labels, grows pool as needed, hides (not destroys) extras. A request whose location doesn't project on-screen is simply hidden, not an error. No-op if not registered.
  - `Unregister()` (private).
  - `RegisteredViewport` (`TWeakPtr<SEditorViewport>`), `Canvas` (`TSharedPtr<SConstraintCanvas>`), `FPooledLabel{TextBlock, Slot}` pool (`TArray<FPooledLabel> Pool`).

### `SNexusLoadLayoutChoiceDialog.h`
- **`ENexusLoadLayoutChoice`** (`uint8`) — `LoadFresh, ImportAndMerge, ShowMeFirst, Cancel`. LoadLayout's answer when the current session already has content that might conflict.
- **`SNexusLoadLayoutChoiceDialog : public SModalEditorDialog<ENexusLoadLayoutChoice>`** — modal shown ONLY when the CURRENT session already has authored points (nothing to reconcile otherwise). Custom subclass since none of `FMessageDialog`'s fixed combos express 4 distinct choices.
  - `SLATE_ARGUMENT(FText, LayoutName)` — the Layout about to load, named in the prompt.
  - `Construct(const FArguments&)`.
  - `OnChoiceClicked(ENexusLoadLayoutChoice)` (private) → `FReply` — every button routes here, forwards into `ProvideResult`.

### `SNexusFrameworkDetailsPanel.h`
- **`SNexusFrameworkDetailsPanel : public SCompoundWidget`** — standalone dockable tab showing active selection's property grid via native `IStructureDetailsView`. Split out from `SNexusFrameworkPanel` for independent docking. **Deliberately has no direct reference to `SNexusFrameworkPanel`/Hierarchy tree, and vice versa** — both react to subsystem delegates instead, since they may not both be open simultaneously.
  - `Construct(const FArguments&)`, `~SNexusFrameworkDetailsPanel()` override.
  - `DetailsView` (`TSharedPtr<IStructureDetailsView>`, private) — points directly at the live struct in subsystem's WorldData maps; edits write straight back, no copy/apply step. Auto-generates UI from UPROPERTY metadata.
  - `RefreshDetailsPanel()` (private) — repoints DetailsView at whatever's active-selected, or clears for None. Called on every selection change AND layout mutation — **never caches a raw struct pointer across a WorldData mutation** since TMap Add/Remove can reallocate/invalidate it.
  - `HandleDetailsPropertyChanged(const FPropertyChangedEvent&)` (private).
  - `HandleEntityLabelChanged(ENexusFrameworkSelectionKind, FGuid)` (private).
  - `LayoutChangedHandle`, `SelectionChangedHandle`, `EntityLabelChangedHandle` (`FDelegateHandle`, private).
  - `RestoreViewportFocus()` (private) — **Gotcha carried from V4**: every button/edit handler must call this before returning, or Slate panel widgets steal keyboard focus from the viewport. Duplicated here (not shared) since it's 4 lines with no state.
  - `GetSubsystem() const` (private) → `UNexusFrameworkEditorSubsystem*`.

### `NexusFrameworkLandscapeModeExtension.h`
- **`FNexusFrameworkLandscapeModeExtension`** (plain class) — shows/hides the Nexus dockable tab(s) in lockstep with built-in Landscape Mode. **Deliberately NOT a custom `UEdMode`** — tried first, reverted after a real crash (`Assertion failed: !Toolkits.Contains(NewToolkit)` in ToolkitManager.cpp — a second UEdMode alongside Landscape Mode conflicts with its toolkit registration, no supported extension point exists). A dockable Nomad tab has no such conflict.
  - Registration deliberately deferred until a level editor exists (`GLevelEditorModeTools()`/`FEditorModeManager` access from `StartupModule()` directly crashes — doesn't exist that early). Mirrors `FLevelInstanceEditorModule::StartupModule()`.
  - `Register()`, `Unregister()`.
  - `RegisterToFirstLevelEditor()`, `OnLevelEditorCreated(TSharedPtr<ILevelEditor>)`, `OnEditorModeIDChanged(const FName&, bool)` (private).
  - `SpawnNexusFrameworkTab(const FSpawnTabArgs&)` → `TSharedRef<SDockTab>` (private).
  - `SpawnNexusFrameworkDetailsTab(const FSpawnTabArgs&)` → `TSharedRef<SDockTab>` (private) — Details panel's own tab, opened/closed in lockstep with main tab.
  - `SpawnNexusSyncInspectorTab(const FSpawnTabArgs&)` → `TSharedRef<SDockTab>` (private) — Sync Inspector tab, same lifecycle.
  - `EditorModeChangedHandle` (`FDelegateHandle`, private).

### `SNexusSyncInspectorPanel.h`
Includes `NexusFrameworkEditorSubsystem.h` directly.

- **`ENexusSyncDiffRowKind`** (`uint8`) — `Branch` (top-level Synchronized/MissingInUE/UntrackedInNexus/Mismatch), `State/City/Highway` (ancestry grouping, never a leaf), `Point` (leaf or Mismatch parent), `MismatchField` ("Location/Rotation/Tangent mismatch" child of a Mismatch Point), `MismatchDetailLine` (plain "Nexus: ..."/"UE: ..." leaf), `UntrackedChain` ("Chain N (K points)" grouping), `UntrackedPoint` (leaf under a chain).
- **`FNexusSyncDiffTreeItem`** (plain struct) — one row of the diagnostic tree, rebuilt from scratch on every Refresh (mirrors `FNexusOutlinerItem`'s convention).
  - `Kind` (`ENexusSyncDiffRowKind`), `Status` (`ENexusSyncDiffStatus`), `DisplayName` (`FString`)
  - `StateId, CityId, HighwayId, PointId` (`FGuid`) — only meaningful on State/City/Highway/Point rows.
  - `ControlPoint` (`TWeakObjectPtr<ULandscapeSplineControlPoint>`) — set on UntrackedPoint rows (and unioned onto parent UntrackedChain) — what clicking focuses when there's no Nexus identity.
  - `bHasFocusLocation` (`bool`, false), `FocusLocation` (`FVector`, zero) — best-effort focus target, propagated bottom-up onto ancestors as an average.
  - `Children` (`TArray<TSharedPtr<FNexusSyncDiffTreeItem>>`).
- **`SNexusSyncInspectorPanel : public SCompoundWidget`** — read-only diagnostic tab comparing authored Nexus hierarchy against live Landscape geometry. **Never modifies either side, never opens a transaction** — lets the user click to focus/select via the same mechanisms the Hierarchy tree uses (`SetActiveXxx` + `GEditor::MoveViewportCamerasToBox`), **deliberately never `SetSplineSelected`** (documented crash-prone, disabled precedent).
  - `Construct(const FArguments&)`.
  - `TreeView` (`TSharedPtr<STreeView<...>>`), `RootItems` (private).
  - `LastDiffEntries` (`TArray<FNexusSyncDiffEntry>`, private) — raw `ComputeSyncDiff()` output kept verbatim so `BuildJsonReport`/auto-log always report exactly what's on screen, never a potentially-stale re-compute.
  - `SynchronizedCount, MissingInUECount, UntrackedInNexusCount, MismatchCount` (`int32`, private) — summary counts for the header line.
  - `OnRefreshClicked()` (private) → `FReply`; `RefreshSyncDiff()` (private) — manual/explicit rebuild (not per-tick poll — `ComputeSyncDiff` is not free and a rebuild would collapse tree expansion state).
  - `OnCopyJsonClicked()` (private) → `FReply` — builds full JSON report of `LastDiffEntries`, copies to OS clipboard, also logs (see below).
  - `BuildJsonReport(const TArray<FNexusSyncDiffEntry>&) const` (private) → `FString` — hand-serialized JSON array (no Json module dependency) covering every non-Synchronized entry (Synchronized entries omitted as noise), each object carrying EVERY field (full Nexus-vs-UE values), not just flagged ones — a complete standalone snapshot.
  - `LogDiffReport(const FString& Json, int32 MismatchCount, int32 MissingInUECount, int32 UntrackedInNexusCount)` (private, static) — chunks Json into log-friendly pieces via UE_LOG (avoids huge single-line log entries some console backends truncate). Called automatically at the end of every RefreshSyncDiff, not just on-demand.
  - `EscapeJsonString(const FString&)` (private, static) → `FString` — minimal manual JSON escaping, hand-rolled deliberately (values are simple enough, avoids Json module dependency).
  - `BuildTreeFromDiff(const TArray<FNexusSyncDiffEntry>&)` (private) — groups flat entries into the four branch rows.
  - `FindOrAddChildRow(Parent, Kind, Id, MakeLabel, BranchStatus)` (private) → `TSharedPtr<FNexusSyncDiffTreeItem>` — finds or creates a child, shared by State/City/Highway/Chain grouping so each ancestor row is created once regardless of how many Point entries fall under it.
  - `AddMismatchDetailRows(PointItem, const FNexusSyncDiffEntry&)` (private) — appends Location/Rotation/Tangent mismatch child rows.
  - `PropagateFocusLocations(const TArray<TSharedPtr<FNexusSyncDiffTreeItem>>&)` (private) — bottom-up average propagation.
  - `OnGenerateSyncDiffTreeRow`, `OnGetSyncDiffTreeChildren` (private) — STreeView callbacks.
  - `OnSyncDiffSelectionChanged(Item, ESelectInfo::Type)` (private) — focuses/selects clicked row via `SetActiveXxx` + `MoveViewportCamerasToBox` fallback. Branch/MismatchField/MismatchDetailLine rows inert.
  - `GetSummaryText() const` (private) → `FText`.
  - `GetStatusColor(ENexusSyncDiffStatus)` (private, static) → `FLinearColor`; `GetStatusBranchLabel(ENexusSyncDiffStatus)` (private, static) → `FString`.
  - `GetSubsystem() const` (private) → `UNexusFrameworkEditorSubsystem*`.

### `NexusDrawPointInputProcessor.h`
- **`FNexusDrawPointInputProcessor : public IInputProcessor, public TSharedFromThis<...>`** — mode-free next-viewport-click capture, currently used ONLY by Generate Random City's origin-picker. Originally built for a since-removed "Draw Point" tool (UE's native Landscape Splines tool covers that workflow now); kept as-is rather than renamed since it's an internal implementation detail with one caller. **Deliberately NOT a `UEdMode`/`FEdMode`** — same ToolkitManager crash history as `NexusFrameworkLandscapeModeExtension`. An `IInputProcessor` fires at the `FSlateApplication` level, entirely outside `FEditorModeTools`/`FToolkitManager`.
  - Only acts while `bArmed` true; never swallows input (always returns false) even while armed — a left-click still reaches the viewport normally.
  - **Three required safety checks (all documented)**: 1) click's screen position must fall inside an actual level viewport's on-screen rect (else clicking any Slate widget elsewhere would incorrectly fire, using stale `GEditor->GetActiveViewport()` mouse pos); 2) if the click's hit proxy resolved to an EXISTING spline element (control point/segment/tangent handle/gizmo axis), `OnValidClick` does NOT fire — falls through to Landscape Mode's native handling, letting armed-tool and normal spline editing coexist; 3) a drag (moved more than a small threshold between down/up) never fires `OnValidClick` regardless of release-time hit-proxy (prevents releasing a dragged gizmo/tangent handle away from itself from misfiring).
  - `Tick(...)` override (empty), `HandleMouseButtonDownEvent(...)` override → `bool`, `HandleMouseButtonUpEvent(...)` override → `bool`, `GetDebugName() const` override → `TEXT("NexusDrawPoint")`.
  - `Register()`, `Unregister()`.
  - `bArmed` (`bool`, public, default false).
  - `OnValidClick` (`DECLARE_DELEGATE_OneParam(FOnValidClick, const FVector&)`, public) — called with resolved world hit location once valid. Unbound by default; `Register()` does not bind anything.
  - `bIsRegistered` (private, false).
  - `LastLeftMouseDownScreenPosition` (`FVector2D`, private, zero), `bHasPendingLeftMouseDown` (`bool`, private, false) — for drag detection.
  - `FindViewportClientUnderScreenPosition(const FVector2D&)` (private, static) → `FLevelEditorViewportClient*`.

### `SNexusFrameworkPanel.h`
Includes `NexusRoadTypes.h`; forward-declares several editor structs.

- **`ENexusButtonType`** (`uint8`) — `Default, Primary, Warning`. Drives `BuildToolButton`'s color/hover tint; not reflected, Slate-only concept.
- **`FNexusOutlinerItem`** (plain struct) — one row in the State/City/Highway/Point hierarchy tree. Rebuilt from scratch on every `RefreshHierarchy()`, never mutated in place. Fields: `Type` (`ENexusOutlinerItemType`), `Id` (`FGuid`), `DisplayName` (`FString`), `Children` (`TArray<TSharedPtr<FNexusOutlinerItem>>`).
- **`FNexusDebugDrawTreeItem`** (plain struct) — one row in the Debug Draw checkbox tree, a STATIC structure built once in `Construct()` (unlike `FNexusOutlinerItem`, never rebuilt per-frame), mirroring `FNexusDebugDrawState`'s field groupings. Fields: `Label` (`FText`), `BoolField` (`bool FNexusDebugDrawState::*`, pointer-to-member) — every row (including branch headers like Highway/Segment) has its own BoolField since toggling e.g. "Should Draw Highway" both draws it AND gates children; `IsRowEnabled` (`TAttribute<bool>`, default true); `Children`.

- **`SNexusFrameworkPanel : public SCompoundWidget`** — the Nexus Framework authoring panel (Phase 1 scope: Hierarchy tree + Layout Tools). Pure UI glue — all state lives on `UNexusFrameworkEditorSubsystem`, this widget only reads/forwards.
  - `Construct(const FArguments&)`, `~SNexusFrameworkPanel()` override, `Tick(...)` override.
  - `bWasSplinesToolActiveLastTick` (`bool`, private, default true) — Splines-tool-active gate: Landscape spline control points/segments are only selectable/editable while Landscape Mode's own Splines tool is active. **No public API to switch/read that tool directly** (confirmed via engine research) — polls `IsLandscapeSplinesToolActive()` once per tick (cheap: two pointer derefs + bool check) rather than reacting to a nonexistent delegate.
  - `IsSplinesToolActive() const` (private) → `bool`; `GetSplinesToolWarningVisibility() const` (private) → `EVisibility`.
  - Hierarchy tree: `TreeView`, `RootItems`, `bIsSyncingTreeSelection` (guards against re-triggering selection-changed while syncing).
  - `BuildHierarchyTree()` → `TSharedRef<SWidget>`; `OnGenerateTreeRow`, `OnGetTreeChildren`, `OnTreeSelectionChanged` (private, STreeView callbacks).
  - `OnTreeContextMenuOpening()` (private) → `TSharedPtr<SWidget>` — right-click context menu: Name/Code edit fields pre-filled, level-gated Create/Duplicate row, Save/Cancel/Delete buttons. Safe to key off TreeView's own selection since Slate always signals selection before opening the context menu (confirmed via engine source). The "States" root Category row gets its own smaller New-State-only menu.
  - `ContextMenuItemType` (`ENexusOutlinerItemType`, private), `ContextMenuItemId` (`FGuid`, private), `ContextMenuNameTextBox`/`ContextMenuCodeTextBox` (`TSharedPtr<SEditableTextBox>`, private) — which entity the context menu currently targets; captured when the menu is built since the menu is a transient popup with no other way to recall "which row" later.
  - `ContextMenuAutoAdjustLandscapeValue` (`int32`, private, -1) — pending value for the 3-button (Inherit/Off/On) row, same "edit locally, write back on Save" pattern.
  - `OnContextMenuSaveClicked()` (private) → `FReply` — writes Name/Code back, validating Code uniqueness (warn+discard on collision, per-type `Is*CodeUnique`), plus writes `ContextMenuAutoAdjustLandscapeValue` back.
  - `OnContextMenuCancelClicked()` (private) → `FReply`.
  - `OnContextMenuSetAutoAdjustLandscapeInheritClicked/OffClicked/OnClicked` (private) → `FReply` — sets the pending value to -1/0/1 respectively; written on Save only.
  - `GetAutoAdjustLandscapeInheritButtonType/OffButtonType/OnButtonType() const` (private) → `ENexusButtonType` — drives highlight via live TAttribute.
  - `OnContextMenuNewStateClicked/NewCityClicked/NewHighwayClicked/DuplicateStateClicked/DuplicateCityClicked/DuplicateHighwayClicked` (private) → `FReply` — level-gated create/duplicate buttons; each calls the matching subsystem method (which never broadcasts `OnLayoutChanged`), then `AddOutlinerItem` to insert the row surgically, then `SyncTreeSelectionFromSubsystem` again (the first sync ran before the row existed).
  - `FocusViewportOnActiveSelection()` (private) — moves camera to frame active selection's computed center. Only reached from `OnTreeSelectionChanged` when `SelectInfo` is a GENUINE user interaction (not `ESelectInfo::Direct`, which every programmatic selection including Slate's own deferred post-rebuild reconciliation reports) — filters out programmatic re-selection so a new point doesn't silently jump the camera.
  - `RefreshHierarchy()` (private) — full rebuild from `GetSubsystem()->GetWorldData()`, bound to `OnLayoutChanged`. **Loses tree expansion state** (STreeView tracks by item identity) — use only for genuine wholesale topology changes (New/Load Layout, minimum-1 reset delete, Draw Point/Generate City). A single rename/delete should use `CollectOutlinerItems`/`RemoveOutlinerItems` instead.
  - `MakeHighwayOutlinerItem/MakeCityOutlinerItem/MakeStateOutlinerItem` (private, const) → `TSharedPtr<FNexusOutlinerItem>` — factored-out row builders shared by `RefreshHierarchy` and `AddOutlinerItem`.
  - `AddOutlinerItem(ENexusOutlinerItemType, FGuid)` (private) → `bool` — surgically appends the row for a just-created/duplicated entity without full refresh; children come along free via recursion. No-op (false) if Id doesn't resolve or parent row isn't in the tree.
  - `SyncTreeSelectionFromSubsystem()` (private) — finds the row matching current active selection, expands its FULL ancestor chain, selects/scrolls to it; bound to `OnActiveSelectionChanged`. Guarded by `bIsSyncingTreeSelection`.
  - `FindOutlinerItemPath(...)` (private, const) → `bool` — DFS for the ancestor path to a Type+Id match.
  - `CollectOutlinerItems(...)` (private, const) — collects EVERY match anywhere (a shared-junction Point can legitimately appear twice, once per highway — a rename must update every occurrence).
  - `RemoveOutlinerItems(...)` (private) → `bool` — removes every match in place, recursing only into non-matching children (a match already drops its whole subtree, matching a cascading delete).
  - `UpdateOutlinerItemLabel(ENexusOutlinerItemType, FGuid)` (private) — recomputes/writes DisplayName for every matching item; no-op if nothing resolves/matches.
  - `HandleEntityLabelChanged(ENexusFrameworkSelectionKind, FGuid)` (private), `EntityLabelChangedHandle` (private).
  - `LayoutChangedHandle`, `SelectionChangedHandle` (private).
  - `GetActiveSelectionLabel() const` (private) → `FText`.
  - `GetDeleteSelectionLabel() const` (private) → `FText` — "Delete State/City/Highway/Point" matching kind, or disabled-looking "Delete".
  - `IsDeleteSelectionEnabled() const` (private) → `bool` — enabled when something selected AND Splines tool active (deleting touches Landscape geometry, same gate as Apply/Sync/Clear).
  - `OnDeleteSelectionClicked()` (private) → `FReply` — Point deletion unconfirmed (lightweight/frequent, matches Draw Point having no confirmation); State/City/Highway deletion gets a Yes/No confirm (same as Clear All) since it cascades.
  - `OnApplyConfigurationClicked()` (private) → `FReply`; `IsApplyConfigurationEnabled() const` (private) → `bool` — re-pushes active highway's resolved mesh/width config onto already-placed geometry. Disabled unless active selection is a Highway.
  - `OnSyncFromLandscapeClicked()` (private) → `FReply` — reconciles both ways, reports both counts via message dialog.
  - `OnClearAllLandscapeGeometryClicked()` (private) → `FReply` — confirmed via Yes/No first (full, largely irreversible wipe).
  - Debug Draw tree: `DebugDrawTreeView`, `DebugDrawRootItems` (private). `BuildDebugDrawSection()` → `TSharedRef<SWidget>`; `OnGenerateDebugDrawTreeRow`, `OnGetDebugDrawTreeChildren` (private, STreeView callbacks).
  - `GetDebugBoolState(bool FNexusDebugDrawState::* Field) const` (private) → `ECheckBoxState`; `OnDebugBoolChanged(ECheckBoxState, bool FNexusDebugDrawState::* Field)` (private) — **one generic Get/Set pair backs every plain on/off toggle via pointer-to-member**, instead of a hand-written method pair per field (V4 wrote ~13 near-identical pairs; doesn't scale to V5's larger nested category list).
  - `IsDebugDrawMasterEnabled() const` (private) → `bool` — true only once `bShouldDrawDebug` is on; every top-level row disabled (greyed, not hidden) otherwise.
  - `IsDebugDrawHighwaySubRowEnabled() const`/`IsDebugDrawSegmentSubRowEnabled() const` (private) → `bool` — children require their own parent toggle too, not just master.
  - `BuildCheckboxRow(...)` (private) → `TSharedRef<SWidget>` — plain SCheckBox+label row, reused for tree rows AND the asset-picker section.
  - `GetSelectedDebugDrawSettingsAssetPath() const`/`OnSelectedDebugDrawSettingsAssetChanged(const FAssetData&)` (private).
  - `GetSelectedDefaultMeshAssetSetPath() const`/`OnSelectedDefaultMeshAssetSetChanged(const FAssetData&)` (private) — editor-level `DefaultMeshAssetSet` picker, last stop of `ResolveHighwayMeshSet`.
  - `GetSelectedGenerationSettingsPath() const`/`OnSelectedGenerationSettingsChanged(const FAssetData&)` (private) — also what `OnContextMenuNewCityClicked` checks before auto-arming Generate Random City.
  - `OnNewLayoutClicked()`/`OnLoadLayoutClicked()` (private) → `FReply` — **note**: Save/Save As have NO dedicated buttons anymore — `HandlePostSaveWorld` auto-saves after every successful UE map save now.
  - `BuildToolButton(Label, OnClicked, Type=Default, IsEnabled=true, Icon=nullptr)` (private) → `TSharedRef<SWidget>` — one button, styled by Type (TAttribute so it can change color when armed, e.g. Draw Point), fixed tall height, icon drawn above label (matches Landscape Mode's own toolbar look).
  - `BuildButtonRows(const TArray<TSharedRef<SWidget>>&)` (private) → `TSharedRef<SWidget>` — 3-per-row layout; trailing row of 2 splits 50/50, trailing row of 1 goes full-width.
  - `BuildAssetPicker(Label, AllowedClass, ObjectPath, OnChanged)` (private) → `TSharedRef<SWidget>` — labeled object picker.
  - `RestoreViewportFocus()` (private) — same V4-carried gotcha as `SNexusFrameworkDetailsPanel`'s.
  - `GetSubsystem() const` (private) → `UNexusFrameworkEditorSubsystem*`.

### `SNexusLoadLayoutOwnershipDialog.h`
- **`ENexusLoadLayoutOwnershipChoice`** (`uint8`) — `Copy, Override, Cancel`. LoadLayout's answer when the picked Layout's `SavedMapPackage` doesn't match the current map. **Fires INSTEAD OF (not before/after)** the usual `SNexusLoadLayoutChoiceDialog` for a cross-map load — ownership is a different question than "how should this be reconciled."
- **`SNexusLoadLayoutOwnershipDialog : public SModalEditorDialog<ENexusLoadLayoutOwnershipChoice>`** — same shape as `SNexusLoadLayoutChoiceDialog`.
  - `SLATE_ARGUMENT(FText, LayoutName)`, `SLATE_ARGUMENT(FText, SavedMapName)`, `SLATE_ARGUMENT(FText, CurrentMapName)`.
  - `Construct(const FArguments&)`.
  - `OnChoiceClicked(ENexusLoadLayoutOwnershipChoice)` (private) → `FReply`.

---

## MODULE: Runtime Schema (`Source/NexusFramework/Public/Schema/Runtime/`)

### `NexusStationTypes.h`
Enums used ONLY by station-type dynamic runtime data (`NexusStationInfo.h`) — not authored in Schema/Editor, hence living in Runtime rather than Shared.

- **`ENexusAllowedVehicles`** (`uint8`, BlueprintType, Bitflags) — `Bike=0, SmallVehicle=1, MediumVehicle=2, HeavyVehicle=3`. `ENUM_CLASS_FLAGS` applied.
- **`ENexusLaneSide`** (`uint8`, BlueprintType) — `Left, Right`.
- **`ENexusAllowedLanes`** (`uint8`, BlueprintType, Bitflags) — `LeftLane=0, RightLane=1`. `ENUM_CLASS_FLAGS` applied.

### `NexusInteractableTypes.h`
Enums used only by dynamic interactable runtime data.

- **`ENexusActiveTimes`** (`uint8`, BlueprintType, Bitflags) — `Day=0, Night=1, Afternoon=2, Midnight=3, MidnightAutoDisabled=4` (active at midnight but auto-disabled, e.g. a shop light that switches off overnight). `ENUM_CLASS_FLAGS` applied.
- **`ENexusDynamicInteractableType`** (`uint8`, BlueprintType) — `TrafficLight, HighwayLight, NewsTv, AdsBoard`. What kind of fake-activity logic to spawn near a static-mesh city prop.

### `NexusFrameworkResult.h`
Depends on `NexusFinalPoint.h`, `NexusStationInfo.h`, `NexusDynamicInteractable.h`.

- **`FNexusFrameworkResult`** (USTRUCT, BlueprintType) — the framework's final flattened result: everything AI/traffic/gameplay systems need to stand up a city at runtime, in one place. A separate FLAT view alongside the State→City→Highway hierarchy (`NexusFinalState.h`/`NexusFinalCity.h`/`NexusFinalHighway.h`, organized by ownership for streaming) — this struct exists for systems that just want every point of a given kind without walking the tree. **Explicitly stated as extensible**: "If this still isn't enough data for a AAA-quality game, extend this struct and/or generate more of it at runtime — it is not meant to be the final word."
  - `HighwayPoints` (`TArray<FNexusFinalPointData>`)
  - `ParkingPoints` (`TArray<FNexusParkingInfo>`)
  - `BusStopPoints` (`TArray<FNexusBusStopInfo>`)
  - `InteractablePoints` (`TArray<FNexusDynamicInteractable>`)

### `NexusFinalCity.h`
Depends on `NexusFinalHighway.h`. Part of "Tier 4 (Optimized Clean Data)" — **locked schema**. `Id` (`FName`) is the cross-reference key here, never a GUID — GUIDs are an editor-authoring concern; a shipped game never sees one.

- **`FNexusFinalCityData`** (USTRUCT, BlueprintType)
  - `Id` (`FName`, default NAME_None, VisibleAnywhere/ReadOnly) — real key, stable, never shown to player, never reused.
  - `Code` (`FName`, default NAME_None) — editable, human-meaningful short label (gameplay/audio trigger key), NOT the cross-reference key, may be renamed without breaking links.
  - `Name` (`FString`)
  - `Highways` (`TArray<FNexusFinalHighwayData>`)

### `NexusStationInfo.h`
Depends on `NexusStationTypes.h`.

- **`FNexusStationInfoBase`** (USTRUCT, BlueprintType) — live/dynamic runtime state for a station-type point (parking, bus stop). **NOT part of authored Tier 4 export data** — world-simulation state generated/maintained at runtime from the static `FNexusFinalPointData`.
  - `HighwaySplinePointId` (`FName`, default NAME_None) — the `FNexusFinalPointData::Id` this station sits at.
  - `StationId` (`FName`, default NAME_None, VisibleAnywhere/ReadOnly) — the real key, stable, never reused.
  - `HighwayId` (`FName`, default NAME_None) — the `FNexusFinalHighwayData::Id` this station belongs to.
  - `StationName` (`FString`)
  - `AllowVehicles` (`int32`, default 0, Bitmask `ENexusAllowedVehicles`)
  - `OffsetLocation` (`FVector`, zero), `OffsetRotation` (`FRotator`, zero)
  - `SegmentWidth`, `SegmentLength` (`float`, default -1) — -1 = global default.
  - `SegmentRow`, `SegmentColumn` (`int32`, default -1) — -1 = global default.
  - `AllowLanes` (`int32`, default 0, Bitmask `ENexusAllowedLanes`)
  - `OccupiedIndex` (`TArray<int32>`, Transient, VisibleAnywhere/ReadOnly, "Runtime" category) — which segment indices currently occupied; runtime state, not authored.
  - **`GetTotalSegmentCount() const`** (inline) → `int32` = `SegmentRow * SegmentColumn`.
  - **`HasFreeSegment() const`** (inline) → `bool` = `(GetTotalSegmentCount() - OccupiedIndex.Num()) > 0`.
- **`FNexusParkingInfo : public FNexusStationInfoBase`** (USTRUCT, BlueprintType) — no extra fields. **Gotcha**: if `HasFreeSegment()` is false, AI must not path here.
- **`FNexusBusStopInfo : public FNexusStationInfoBase`** (USTRUCT, BlueprintType) — no extra fields. **Gotcha**: if `HasFreeSegment()` is false, arriving buses/passengers must queue rather than occupy the stop directly.

### `NexusFinalHighway.h`
Depends on `NexusSharedRoadTypes.h`, `NexusHighwayFeatureTypes.h`. Tier 4 locked schema, same `Id`-not-GUID rule.

- **`FNexusFinalHighwayData`** (USTRUCT, BlueprintType)
  - `Id` (`FName`, default NAME_None, VisibleAnywhere/ReadOnly) — real key.
  - `Code` (`FName`, default NAME_None) — editable short label, not the cross-ref key.
  - `Name` (`FString`)
  - `PointIds` (`TArray<FName>`) — ordered references into `UGeneratedWorldDataAsset::Points`, by Id. **Note**: `UGeneratedWorldDataAsset` is referenced here but was not among the requested header files — flag for V6 doc as an asset type whose header wasn't read in this pass.
  - `OtherStateCityId` (`FName`, default NAME_None) — set ONLY when this highway bridges two states; the Id of the OTHER owning city for cross-references without walking the full tree. NAME_None for single-state.
  - `SpeedLimit` (`float`, default -1) — -1 = global default, 0 = no limit, >0 = custom.
  - `Features` (`int32`, default 0, Bitmask `ENexusHighwayFeature`)
  - `LaneConfiguration` (`ENexusLaneConfiguration`, default `TwoLanes`)
  - `LaneWidth`, `LaneGap`, `CenterMedianGap`, `SidewalkGap`, `LeftSidewalkWidth` (0=no left sidewalk), `RightSidewalkWidth` (0=no right sidewalk) — all `float`, default -1, mirroring `FNexusHighway` (Schema/Editor)'s Lanes & Sidewalks fields, carried through verbatim at export.

### `NexusDynamicInteractable.h`
Depends on `NexusInteractableTypes.h`.

- **`FNexusTrafficLightState`** (USTRUCT, BlueprintType) — marker/placeholder for a traffic light's fake-activity logic instance. **Deliberately empty for now** — the mesh is a static mesh with no logic; exists to be extended once near-player fake-light-cycle behavior is implemented.
- **`FNexusDynamicInteractable`** (USTRUCT, BlueprintType) — city props (traffic lights, street lights, news TVs, ad boards...) are baked into static meshes for performance (no gameplay logic of their own). When player is near, a lightweight "fake activity" actor/component is spawned to make it look alive; despawned/reused when player moves away (pooled cost stays flat).
  - `ActivationDistance` (`float`, default -1) — -1 = global default, >0 = custom.
  - `ActiveTimes` (`int32`, default 0, Bitmask `ENexusActiveTimes`)
  - `InteractableType` (`ENexusDynamicInteractableType`, default `TrafficLight`)
  - `HighwaySplinePointId` (`FName`, default NAME_None) — the `FNexusFinalPointData::Id` this interactable is anchored to.
  - `OffsetLocation` (`FVector`, zero), `OffsetRotation` (`FRotator`, zero)

### `NexusFinalPoint.h`
Depends on `NexusPointTargetTypes.h`, `NexusHighwayFeatureTypes.h`. Tier 4 locked schema.

- **`FNexusFinalPointData`** (USTRUCT, BlueprintType)
  - `Id` (`FName`, default NAME_None, VisibleAnywhere/ReadOnly) — real key, stable, never reused. Every cross-reference to a point (`FNexusFinalHighwayData::PointIds`, station/interactable anchors, etc.) uses THIS, not `Code`.
  - `Code` (`FName`, default NAME_None) — editable short label, NOT the cross-reference key.
  - `Location` (`FVector`, zero), `Rotation` (`FRotator`, zero)
  - `PointFeatures` (`int32`, default 0, Bitmask `ENexusHighwayPointFeature`) — point-level decoration flags.
  - `PointTargets` (`int32`, default 0, Bitmask `ENexusPointTarget`) — what kind(s) of thing this point represents.
  - `Description` (`ENexusPointDescription`, default `None`)

### `NexusFinalState.h`
Depends on `NexusFinalCity.h`. Tier 4 locked schema.

- **`FNexusFinalStateData`** (USTRUCT, BlueprintType) — shape: `FNexusFinalState → Cities → Highways → PointIds[]`. **Important invariant**: a cross-state highway (`ENexusHighwayStateSpan`) is DUPLICATED BY VALUE into both owning states' city entries at export time — same as V4 already duplicated an inter-city highway's data under both owning cities in the editor outliner. **There is no separate top-level "shared highways" list.** Runtime code needing a single canonical copy of such a highway must dedupe by `Id`, must NOT assume one live copy per state.
  - `Id` (`FName`, default NAME_None, VisibleAnywhere/ReadOnly) — real key.
  - `Code` (`FName`, default NAME_None) — editable short label, not cross-ref key.
  - `Name` (`FString`)
  - `DataLayerAssetName` (`FName`, default NAME_None) — streaming unit this state's data ships in; see `FNexusState::DataLayerAssetName` (Schema/Editor).
  - `Cities` (`TArray<FNexusFinalCityData>`)

---

## MODULE: Runtime Shared (`Source/NexusFramework/Public/Schema/Shared/`)

### `NexusSharedRoadTypes.h`
Enums referenced by BOTH Schema/Editor (live authoring) AND Schema/Runtime (locked Tier 4 export) — e.g. `FNexusHighway` and `FNexusFinalHighwayData` both carry `ENexusLaneConfiguration`. Anything used by only one side lives in that side's own header instead.

- **`ENexusLaneConfiguration`** (`uint8`, BlueprintType) — `TwoLanes, FourLanes, SixLanes, EightLanes, TenLanes, OneWayLeftLane (traffic keeps left only), OneWayRightLane (traffic keeps right only), HumanWalk (no vehicle lanes, pedestrian-only)`. **Supersedes** an earlier "EHighwayLanes" concept (HumanWalk/OneLane_LeftEntry/OneLane_RightEntry/TwoLane/FourLane/SixLane from early design notes) — those map onto HumanWalk/OneWayLeftLane/OneWayRightLane/TwoLanes/FourLanes/SixLanes here; EightLanes/TenLanes are new headroom for large-world highways.

### `NexusHighwayFeatureTypes.h`
- **`ENexusHighwayFeature`** (`uint8`, BlueprintType, Bitflags) — per-highway rules-of-the-road flags, authored on `FNexusHighway` (Editor), carried verbatim into `FNexusFinalHighwayData` (Runtime) at export. Values: `AllowOvertake=0, AllowUturn=1, AllowSideParking=2, AllowLaneChange=3, AllowHeavyVehicles=4, AllowPublicTransport=5`. `ENUM_CLASS_FLAGS` applied.
- **`ENexusHighwayPointFeature`** (`uint8`, BlueprintType, Bitflags) — per-point decoration flags, authored on `FNexusRoadPoint`, carried verbatim into `FNexusFinalPointData`. Values: `TrafficLight=0, Crosswalk=1`. **Supersedes** standalone `bHasTrafficLight`/`bHasCrosswalk` bools — explicit instruction: "add new point decorations here instead of adding more bools." `ENUM_CLASS_FLAGS` applied.

### `NexusPointTargetTypes.h`
- **`ENexusPointTarget`** (`uint8`, BlueprintType, Bitflags) — what kind(s) of thing a road point represents beyond plain geometry, authored on `FNexusRoadPoint`, carried verbatim into `FNexusFinalPointData`. A point can be more than one at once (e.g. a Shop that's also a ServiceStation). Values: `Highway=0, StationSport=1` (Bus/Parking/Helipad), `ServiceStation=2` (gas/repair/petrol/charging), `Shop=3`, `Playground=4` (Football/Basketball/Tennis), `Building=5` (House/Apartment/Office), `Institution=6` (School/College/Hospital/Research/Library), `Area=7` (Construction/Park/Gang Territory/Industrial/Military Restricted). `ENUM_CLASS_FLAGS` applied.
- **`ENexusPointDescription`** (`uint8`, BlueprintType, plain UENUM not bitflags) — fine-grained classification of a road/POI point, BANDED by `ENexusPointTarget` category. **Numeric ranges are part of the locked schema — explicit instruction: do NOT renumber existing entries when adding new ones; add at the end of a band instead.** Values fix a documented "duplicate-4 bug" from the source design doc (Highway_6_4/6_2/4_2_T_Junction and Highway_Cross_Junction previously all shared value 4) by giving each a distinct sequential value.
  - `None = 0`
  - Highway geometry (1-19): `Highway_Straight=1, Highway_Curve=2, Highway_T_Junction=3` (same-lane T), `Highway_6_4_T_Junction=4` (6-lane meets 4-lane connected highway, T), `Highway_6_2_T_Junction=5`, `Highway_4_2_T_Junction=6`, `Highway_Cross_Junction=7` (same-lane cross, e.g. 4x4 or 6x6).
  - Service Station (20-39): `SS_GasStation=20, SS_RepairShop=21, SS_Petrol=22, SS_Charging=23`.
  - Station (40-59): `Station_Bus=40, Station_Parking=41, Station_Helipad=42, Station_Sport=43, Station_Train=44`.
  - Shop (60-79): `Shop_Convenience=60, Shop_Clothing=61, Shop_Weapon=62, Shop_Vehicle=63`.
  - Playground (80-99): `Playground_Football=80, Playground_Basketball=81, Playground_Tennis=82`.
  - Building (100-119): `Building_House=100, Building_Apartment=101, Building_Office=102, Building_Hotel=103, Building_Bar=104`.
  - Institution (120-139): `Institution_School=120, Institution_College=121, Institution_Hospital=122, Institution_ResearchCenter=123, Institution_Library=124, Institution_PoliceStation=125, Institution_ArmyCamp=126, Institution_FireStation=127, Institution_Prison=128, Institution_CityHall=129`.
  - Area (140-159): `Area_GangTerritory=140, Area_Industrial=141, Area_MilitaryRestricted=142, Area_Park=143, Area_Construction=144`.

### `NexusSitableTypes.h`
- **`ENexusSitableTarget`** (`uint8`, BlueprintType) — what kind of place a `FNexusSitableStructure` is physically found in/attached to; determines how its `OwnerId` should be interpreted:
  - `BusStation` — `OwnerId` is a `FNexusRoadPoint::Id` with `ENexusPointDescription::Station_Bus`.
  - `CityParks` — `FNexusRoadPoint::Id` with `Area_Park`.
  - `SideHighway` — `OwnerId` is a `FNexusHighway::Id` instead (the one case where OwnerId is a Highway, not a Point).
  - `HotelResort` — `FNexusRoadPoint::Id` with `Building_Hotel`.
  - `Vehicle` — external runtime-only reference (a spawned vehicle actor, NOT WorldData) — no Nexus authoring counterpart at all.

---

## Cross-Cutting Architectural Notes (for the V6 doc's overview section)

1. **World hierarchy**: `FNexusState → FNexusCity → FNexusHighway → FNexusRoadPoint` (editor/authoring, GUID-keyed), all stored flat in `TMap`s inside `FNexusWorldData` (the single source of truth), owned by `UNexusFrameworkEditorSubsystem::WorldData`, persisted to/from `UNexusLayoutAsset::World`. States/Cities/Highways are pure logical containers with NO stored transform — their position is always computed live ("Hierarchy Objects Have Computed Locations"). Only `FNexusRoadPoint` has real geometry, and even that geometry (`Location`/`Rotation`/tangents) is authoritatively sourced from the referenced `ULandscapeSplineControlPoint` (via `SourcePoint`) whenever it resolves — the "Nexus owns configuration, Landscape owns geometry" split. `Location`/`Rotation`/tangent fields on `FNexusRoadPoint` are just SNAPSHOTS refreshed before Save, becoming authoritative only when `SourcePoint` no longer resolves.

2. **Runtime/export ("Tier 4 — Optimized Clean Data") types** are a SEPARATE, LOCKED schema (`NexusFinalState/City/Highway/Point`) using `FName Id` as the cross-reference key — never a GUID (GUIDs are editor-only). `Code` is always a separate, renamable, non-unique-required, non-cross-reference display label distinct from `Id`/`Code`(editor)/`PointId` — this Id-vs-Code distinction is repeated verbatim across nearly every struct in the codebase (State/City/Highway/Point, both Editor and Runtime tiers) and is one of the most load-bearing conventions to capture in the V6 doc.

3. **The `-1`-means-inherit / most-specific-wins resolution chain pattern** recurs pervasively: `AutoAdjustLandscape` (-1/0/1, Point→Highway→City→State→`UNexusGenerationSettings::bAutoAdjustLandscapeByDefault`→true), `CornerSharpDetectionAngle` (-1 inherit, 0-180 explicit, Highway→City→State→`UNexusGenerationSettings`→100), `MeshAssetSetOverride` (Highway→City→State→subsystem `DefaultMeshAssetSet`→nullptr), `LayoutSettingsOverride`/`GenerationSettings` (City→Layout→nullptr fallback to default-constructed), and every `*Width`/`*Gap` field on `FNexusHighway`/`FNexusHighwayDimensions` (-1 = global default, 0 = explicitly disabled, >0 = custom). `FNexusHighwayRoadMeshConfig::Width`/`Length` additionally has a 3rd tier: auto-measure the mesh's own bounding box.

4. **Bitmask enums** (`ENexusHighwayPointFeature`, `ENexusPointTarget`, `ENexusHighwayFeature`, `ENexusAllowedVehicles`, `ENexusAllowedLanes`, `ENexusActiveTimes`) are all stored as plain `int32` UPROPERTYs with `meta = (Bitmask, BitmaskEnum = "/Script/Module.EnumName")`, not as the enum type directly — this is the standard way this codebase exposes Blueprint-editable bitmasks.

5. **Save/Sync architecture**: "UE map save is authoritative, Nexus follows" — there are no manual Save/Save As buttons in the panel anymore; `HandlePostSaveWorld` auto-saves the Nexus Layout after every successful, non-autosave UE map save of the correct world. `SyncFromLandscape` reconciles Nexus↔Landscape topology (never position) both ways and runs silently before every disk write. `ComputeSyncDiff`/Sync Inspector is a separate, read-only diagnostic layer that never mutates. Position/geometry NEVER flows Landscape→WorldData except as a refreshed snapshot (`SyncPointGeometrySnapshots`), and WorldData config NEVER flows into Landscape positions (only mesh/width config via Apply Configuration).

6. **Known engine-API landmines** (documented defensively in the headers, worth preserving verbatim as "gotchas" in the V6 doc): registering a custom `UEdMode` alongside Landscape Mode crashes (`ToolkitManager.cpp` assertion) — hence the Nomad-tab + `IInputProcessor` architecture instead of a mode; calling `ULandscapeSplineControlPoint::SetSplineSelected` outside the one already-vetted call site is documented as crash-prone; calling the public `DeletePoint()` (which opens its own transaction) from inside `OnLandscapeSplineObjectTransacted` crashes because that callback fires mid-`Finalize()` of the Landscape's own transaction — must use `DeletePointNoTransaction` instead; there is no public API to read/set Landscape Mode's active tool or to observe "spline selection changed" — both are worked around via best-effort public-but-undocumented signals (`bShowSplineEditorMesh`, polling `IsSplineSelected()`).

7. **One naming inconsistency worth flagging explicitly to the user**: several Editor Schema header comments (`NexusRoadTypes.h`, `NexusHighway.h`, `NexusState.h`, `NexusCity.h`) reference a class `FNexusRoadGraph` and its methods (`ResolveAnchorToPoint`, `ConnectPoints`, `MoveCityToState`, and generically "FNexusRoadGraph's mutators") for operations that, per `NexusWorldData.h`'s own header comment ("All graph mutation goes through the methods below — never touch States/Cities/Highways/Points directly from UI or tool code"), are actually owned by `FNexusWorldData`. No `FNexusRoadGraph` header was among the files provided, and it doesn't appear in the file listing gathered for this pass. This is either stale comment terminology (an old class name from before a rename to `FNexusWorldData`) or a real class living outside `Schema/Editor` and `NexusFrameworkEditorSubsystem.h`/`NexusFrameworkEditorModule.h`. Recommend the user confirm which is true before the V6 doc asserts `FNexusWorldData` as the sole mutation entry point.