# 01 — V5 Analysis

Architectural facts about `NexusFramework_V5` as it actually exists, for V6 to react to.
Source: direct engineering work on the V5 codebase (`NexusFrameworkEditor` module) and
its own persistent history at `NexusFramework_V5/ai-change-audits/`.

## Core architectural rule

**Nexus owns configuration. The Landscape owns geometry.** `FNexusRoadPoint` never
treats its own cached `Location`/`Rotation`/`Tangent` fields as authoritative once its
`SourcePoint` (`TSoftObjectPtr<ULandscapeSplineControlPoint>`) resolves to a live
object — those fields are a snapshot/cache, only used to rebuild geometry when the live
control point doesn't exist yet or no longer resolves. Every other architectural
decision in V5 traces back to this split.

## Data model

`FNexusWorldData` (single source of truth for the authored graph):

```
FNexusState → FNexusCity → FNexusHighway → FNexusRoadPoint
```

- A **City** has no stored location — always computed live from its highways' points.
- A **Highway** has `OrderedPointIds` (the real path), `bIsClosedLoop`, `bLockEdit`, a
  mesh-set override, and terrain fields. An `InterCityHighway` bridges two cities (which
  may belong to two different states) — the only form a cross-state highway takes.
- A **Point** has `PointId` (real key), optional `Code` (display alias, not a key),
  `SourcePoint`, a geometry snapshot, derived `ConnectedHighwayIds`/`NodeType`, and
  decoration bitmasks.
- **Id vs Code**: `FGuid` is always the real structural key; `FName Code` is an
  optional, per-type-unique, user-editable alias — never used as an engine-facing
  lookup key.
- **`-1` convention**: inheritable numeric fields (width/gap/length/tangent/etc.)
  default to `-1` = inherit from the parent level, `0` = explicitly disabled, `>0` =
  explicit override. Most-specific-wins resolution (Point → Highway → City → State →
  global settings).

## Sync architecture

The one large subsystem (`UNexusFrameworkEditorSubsystem`) routes nearly everything.
As of V5's later development, Save and "Build Landscape" are **deliberately
asymmetric**:

- **Save / "Sync From Landscape"** is pull-only: WorldData ← Landscape. Never pushes a
  computed mesh/rotation back onto the live Landscape.
- **"Build Landscape"** is the only place Nexus pushes its own config onto the
  Landscape — mesh, scale, half-width, junction rotation/tangent recompute, furniture.
- **Load** (`MaterializeMissingPointGeometry`) is the opposite direction — WorldData →
  Landscape — but only for geometry that doesn't exist yet; it does not push over
  already-resolved, already-correct live geometry (this specific behavior was a
  late-V5 fix, not true from the start — see problems doc).
- **Live incremental edits** (native Landscape Spline edits, via engine transaction
  callbacks) classify/mesh immediately for real-time feedback while drawing.

## Known-unsafe engine APIs (UE 5.8, load-bearing for V6 if it also builds on Landscape Splines)

- `ULandscapeSplineSelection::SetSplineSelected` — private-to-LandscapeEditor, proven to
  crash. Only `IsSplineSelected()` (read-only) is safe.
- A `ULandscapeSplineControlPoint` subclass cannot cross a module boundary —
  `MinimalAPI` blocks it (confirmed unfixable via linker errors, not a build-config
  issue). V5 works around this by renaming the plain control point to a deterministic
  `"NexusPoint_<guid>"` name for a stable `FSoftObjectPath` instead of subclassing.
- Engine's `DeleteSplinePoints()` doesn't destroy objects — it renames them into the
  transient package. A cached `TSoftObjectPtr` weak pointer can resolve to a stale,
  orphaned-but-still-alive object from a different, still-resident map.
- `AutoCalcRotation` (engine) was never used by V5's own junction rotation — V5 used its
  own closed-form solver instead, because the two disagree at junctions.
- Tangent sign is meaningful (can be legitimately negative) — must `FMath::Abs()` before
  comparing against a plain auto-distance value.
- An **unresolved, engine-level** `Q.IsNormalized()` crash exists in UE 5.8's Landscape
  Spline tessellation on certain rotation edits at junctions (strong evidence points to
  an unguarded `FQuat(Axis, Angle)` constructor fed a zero-length Hermite-curve
  derivative) — not a V5 data-correctness bug, but a real, reproducible editor crash
  risk V5 had to design around (see problems doc).

## Module structure

`Public/Schema/{Editor,Runtime,Shared}` — a 3-way header split (editor-only authoring
structs vs. runtime-consumed data vs. shared-by-both), adopted after V5 initially tried
a flatter layout.
