# 06 — V6 Debug System

## Status

**Drafted — 2026-08-09.** Debug Mode is a primary V6 product, designed before most
generation systems (per the master architecture prompt, section 17) — this doc is
intentionally one of the earliest-filled specs.

## Why data-driven, not `if TrafficLight... if BusStop...`

V5's debug drawing (`NexusDebugLabelOverlay`, `NexusDebugDrawSettings`) grew one
category at a time with no shared registration model. That was fine at V5's category
count; it does not scale to V6's target of 30–50+ categories that must keep growing
without a redesign. V6 uses a **registry + renderer + config** model instead:

```
FNexusDebugCategory
{
    CategoryId          (stable name, e.g. "TrafficLight.LED")
    DisplayName
    ParentCategoryId     (drives the tree — see below)
    DefaultConfig         (FNexusDebugRenderConfig)
    RendererFn             (delegate: given live data + config, draw)
}
```

Every category registers once. Nothing else in the codebase branches on category
identity — the tree UI, the config panel, and the render loop all walk the registry
generically.

## Debug Tree structure

Six top-level groups (per the master prompt's example, adjusted to match V6's actual
data model):

```
DEBUG
├── Landscape        (Segments, Tangents, Start/End, Connections)
├── Roads             (Highways, Lanes, Lane direction, Sidewalks, Junctions)
├── Infrastructure    (Traffic Lights, Traffic-Light LED, Crosswalks, City Lights,
│                      City-Light Source, Hospitals, Police Stations, Parking,
│                      Petrol/Charging/Service stations)
├── Runtime           (Activation Points, Bus Stops, Bus Stopping/Entry/Exit Points,
│                      Passenger Points, Seat Points, Ads, TVs)
├── Mapping           (HighwayPointId labels, City/State membership, Source-point
│                      resolution status)
└── Diagnostics       (Validation errors, broken references, duplicate IDs, bounds)
```

New categories are always leaves under one of these six groups — the group set itself
is expected to stay stable; only leaves grow past 50.

## Per-category configuration (`FNexusDebugRenderConfig`)

One shared struct, not per-renderer bespoke fields:

```
bool bVisible
bool bWireframe
FLinearColor Color
float LineThickness
bool bShowLabel
FString LabelOverrideText   (empty = use a category-defined default label builder)
float LabelFontSize
int32 DepthPriority          (only where draw-order actually matters)
bool bSelectable
bool bSupportsGizmo
```

Stored per-category, per-Layout (matching V5's DataAsset-persisted debug settings
precedent, which worked and is worth keeping), editable from the tree UI's config panel
— never hard-coded inside a renderer function.

## Rendering approach

Lightweight wireframe primitives only (lines, boxes, spheres, arrows, capsules, tangent
handles, direction arrows, text labels) — never a production mesh. Matches V5's existing
approach (real-time debug-line drawing, not native selection highlighting, which V5
found to be an engine crash risk — see [01-v5-analysis.md](01-v5-analysis.md)) and the
master prompt's explicit wireframe rule.

**Mechanism, confirmed from V5's actual source** (2026-08-09, alongside the Editor
surface correction in [04-v6-architecture.md](04-v6-architecture.md) — V6 has no
custom `UEdMode` to hang a `Render()`/`DrawHUD()` override on): global
`DrawDebugLine`/`DrawDebugBox` calls (short `LifeTime`, redrawn every tick, not
persistent) for lines/boxes, plus a Slate overlay canvas
(`SEditorViewport::AddOverlayWidget`) for text labels — both driven every frame from an
`FTickableEditorObject` override on the persistent `UEditorSubsystem`, not from any
Editor Mode. Fully mode-independent, matching this doc's own "no category renderer
spawns Actors, all drawing goes through the engine's persistent debug-line API"
performance rule below — which was already correct, just needed the specific mechanism
name attached to it.

## Performance rule for 30–50+ categories at GTA-V scale

- Category visibility is checked once per category per frame, not per object — an
  invisible category costs nothing beyond a bool check.
- Renderers read cached Representation-stage data, never recompute Landscape geometry
  per frame (Landscape reads happen at Mapping-stage refresh points, not inside the draw
  loop).
- Spatial/viewport filtering (only render what's within camera range or a configurable
  debug radius) is mandatory once a category's live object count can exceed roughly a
  few hundred instances (crosswalks, activation points, lane markers).
- No category renderer spawns Actors; all drawing goes through the engine's persistent
  debug-line API (or an editor-only draw-interface), matching V5's precedent — this is
  the mechanism that keeps a large debug session cheap.

## Gizmo integration

See [13-v6-gizmo-system.md](13-v6-gizmo-system.md) — `bSupportsGizmo` on a category's
config is what makes its instances selectable/movable in the viewport; the gizmo always
edits an offset the category owns, never Landscape geometry.

## Inspector/diagnostic tooling

V6 keeps an equivalent of V5's Sync Inspector tab, generalized: any Mapping/Validation
stage discrepancy (unresolved HighwayPoint, duplicate ID, orphaned ActivationPoint,
broken Highway reference) surfaces here, not just geometry sync mismatches. Logging
categories and the crash-artifact triage convention (`Saved/Crashes/UECC-Windows-<hash>_NNNN/`)
carry over unchanged from V5 — no reason to redesign a working convention.

## References

- [01-v5-analysis.md](01-v5-analysis.md)
- [04-v6-architecture.md](04-v6-architecture.md)
- [12-v6-activation-point-system.md](12-v6-activation-point-system.md)
- [13-v6-gizmo-system.md](13-v6-gizmo-system.md)
