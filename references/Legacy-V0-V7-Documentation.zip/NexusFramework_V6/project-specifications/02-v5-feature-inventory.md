# 02 — V5 Feature Inventory

What V5 actually has, built and (mostly) working, as a checklist for V6 to decide
"keep / rebuild / drop" against. Grouped roughly by when it landed in V5's own history.

## Authoring / data model

- State → City → Highway → Point hierarchy, full CRUD through `FNexusWorldData`'s own
  mutator methods (never hand-edited maps).
- Duplicate State/City/Highway (deep-copy with fresh Ids, identity fields reset).
- Sitable-structure system (`FNexusSitableStructure`, owned by a Point or a Highway,
  stored top-level keyed by owner).
- Point Code/Name, per-type-unique Code uniqueness validation.
- `-1`-inherit config chain for width/gap/tangent/terrain fields, State-level global
  defaults (`UNexusGenerationSettings`).
- Mesh asset sets (`UNexusHighwayMeshAssetSet`) with per-level override chain
  (Highway → City → State → editor-level default) and per-point mesh/font-size
  overrides.

## Editor UI

- Dockable authoring panel: Hierarchy tree (State/City/Highway/Point) + Layout Tools.
- Native `IStructureDetailsView` details panel for the selected entity.
- Draw Point tool (click-to-place on Landscape, auto-assigns to active highway).
- Delete (Point/Highway/City/State) with cascading teardown of both WorldData and live
  Landscape geometry, shared-junction-safe.
- Right-click context menu on Hierarchy tree rows (Name/Code edit, Delete) mirroring the
  toolbar actions.
- Debug Draw system: curve-accurate overlay lines, per-category color/thickness/font via
  a reusable `UNexusDebugDrawSettings` asset, on/off state persisted per-Layout, world-
  space text labels.
- Segment/hierarchy highlighting via per-tick `DrawDebugLine` over real tessellation
  (NOT native `SetSplineSelected` — that path is permanently disabled, see analysis doc).
- Sync Inspector dockable tab — diagnostic view comparing Nexus WorldData against live
  Landscape state (`Synchronized`/`MissingInUE`/`UntrackedInNexus`/`Mismatch` per point,
  with mismatch-flag detail for Location/Rotation/Tangent).
- Sync Inspector JSON export.
- Global configuration section + "Generate City" gating.
- Street furniture: point furniture (traffic light/crosswalk meshes) spawns at flagged
  junctions, tag-based cleanup.

## Landscape integration (V5's later pivot — landscape-native, not V4's own graph)

- Highway geometry owned by real `ULandscapeSplineControlPoint`/`ULandscapeSplineSegment`
  objects, not a Nexus-private GUID graph.
- Click-to-place directly creates Landscape Spline geometry.
- Deterministic junction rotation solver (`ComputeDeterministicJunctionForward`, ported
  from V4), not the engine's own `AutoCalcRotation`.
- Terrain auto-adjust (raise/lower terrain layer) per Highway, with a most-specific-wins
  master/slave resolution between shared endpoints.
- Two-way Landscape↔Nexus sync: native edits (move/rotate/tangent/delete, segment
  create) picked up live via engine transaction callbacks and reconciled into WorldData.
- `SyncFromLandscape` reconciliation (4 "directions": drop dead points, import
  untracked native points as new highways or splice into existing ones, register
  "Imported Connector" highways for untracked adjacencies, prune dead connectors).
- Cross-map `SourcePoint` resolution guard (a stale weak pointer resolving to a
  different, still-resident map's orphaned object) — real bug, fixed and verified.

## Save / Load

- Layout asset (`UNexusLayoutAsset`) as the single persisted authoring file.
- Save (pull-only reconciliation first) vs. "Build Landscape" (push) as deliberately
  separate, asymmetric actions.
- Load Layout choice dialog (Load Fresh / Import and Merge / Show Me First / Cancel),
  triggered whenever either the current session or the target Landscape already has
  content, to prevent silent data loss.
- Load Fresh: wholesale WorldData replace, geometry reused/mapped from the Landscape
  where it already resolves (not a destructive wipe-and-rebuild).
- Import and Merge: duplicate-aware — an incoming point already physically on the
  Landscape collapses onto the existing tracked point (geometry pulled live, identity
  fields untouched) instead of being re-added.
- Cross-map ownership tracking (`SavedMapPackage`) with a Copy/Override/Cancel dialog
  when a Layout's saved map doesn't match the currently open one.
- Auto-save-on-map-save (`PostSaveWorldWithContext` triggers a Nexus Layout save, with
  failure notify+retry), replacing manual Save/Save As buttons for the common case.
- Layout asset shows up in Unreal's own native "Unsaved Assets" status bar tracker (no
  custom UI).

## Known gaps / never finished in V5

- Segment DELETE is not fully handled by the two-way live sync (create/move/rotate are).
- Highway-level duplicate detection (only point-level dedup exists in Import and Merge).
- No always-visible viewport overlay panel (only the dockable Sync Inspector tab).
- No AI/gameplay data extraction layer (walk AI, character, vehicle nav data) — noted as
  a future direction, never built in V5.
