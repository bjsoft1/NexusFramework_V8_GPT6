# 07 — V6 UI Design

## Status

**Drafted — 2026-08-09.**

## Hosted in a Nexus Nomad tab, synced to Landscape Mode — not a custom Editor Mode

**Corrected 2026-08-09** — this section originally said the UI lives inside
`FNexusEdModeToolkit : FModeToolkit`, hosted by a custom Editor Mode. That's reverted;
see [04-v6-architecture.md](04-v6-architecture.md)'s "Editor surface" section for why
(a custom `UEdMode` alongside built-in Landscape Mode is a confirmed engine crash,
per `NexusFramework_V5`'s own hard-won fix).

The UI now lives inside `SNexusFrameworkPanel` — a plain `SCompoundWidget`, not a
Toolkit — hosted in a single Nomad `SDockTab` that opens automatically when the user
enters built-in Landscape Mode and closes when they leave it
(`FNexusLandscapeModeExtension`). It's reached by Landscape Mode being active, not the
Modes toolbar (there is no separate Nexus entry there), and isn't an
independently-floating tab disconnected from Landscape state either — it only ever
appears alongside Landscape Mode, which is what "hosted inside a custom Editor Mode"
was actually trying to achieve in the first place. This is still a deliberate upgrade
over V5's own three-separately-dockable-tabs shape (see Panel/tab layout below), just
not over V5's tab-vs-competing-mode decision, which V5 already had right.

## Panel/tab layout

Three sections within the one panel, deliberately fewer than V5 accumulated (V5's
Hierarchy+Tools, Details, and Sync Inspector grew as three separate Nomad tabs
organically; V6 designs the set up front as one combined panel instead):

- **Nexus Panel** — Debug Tree (see [06](06-v6-debug-system.md)) + a Hierarchy view
  (State/City/Highway/HighwayPoint) as two sections of one panel, not two tabs — they're
  both "what exists and is it visible," and V5 users had to context-switch between a
  Hierarchy tab and a Debug Draw tab for related questions.
- **Details Panel** — native `IStructureDetailsView` reuse for whatever's selected in
  either the Hierarchy or the Debug Tree (proven pattern from V5, kept as-is).
- **Diagnostics Panel** — the generalized Sync Inspector (see
  [06-v6-debug-system.md](06-v6-debug-system.md)'s inspector section) — validation
  errors, unresolved references, duplicate IDs.

Phase 03 of the roadmap builds this panel UI-only, with no business logic wired in yet
(per the master prompt's explicit phase-03 rule) — entering Landscape Mode opens the
tab, the panel appears with its three sections and selection/tree interactions work,
nothing yet reads real Mapping/Representation data.

## Dialogs/modals inventory (designed up front, not accumulated)

V6's automatic config lifecycle ([05](05-v6-data-flow.md)) eliminates the entire
Load-Layout dialog family V5 needed (LoadFresh/Import-and-Merge/Show-Me-First/Cancel,
plus the later cross-map ownership Copy/Override/Cancel dialog) — there is no manual
load step to gate. The dialogs V6 actually needs:

- **Validation warning** — modal, appears when Mapping/Generation finds a blocking issue
  (unresolved HighwayPoint, broken reference) that would make Generation/Compilation
  produce invalid output. Ok-only, points at the Diagnostics Panel.
- **Destructive-action confirm** — a single reusable confirm dialog (title + body text
  parameters) for anything that deletes State/City/Highway/HighwayPoint/ActivationPoint
  data, reused rather than one bespoke dialog per delete action (V5 precedent, kept).
- **Generation/Compilation progress** — non-modal progress notification for
  potentially-long Static Generation / Runtime Compilation passes on a large world.

## Interaction model

- Click-to-place for new HighwayPoint-anchored objects (Activation Points) — same
  interaction shape V5 proved out for street furniture, generalized.
  Drag-to-move a debug gizmo edits an offset, never Landscape geometry directly (see
  [13-v6-gizmo-system.md](13-v6-gizmo-system.md)).
- Right-click context menu on Hierarchy/Debug Tree rows for common actions (Delete,
  Rename/Code edit, Focus in viewport) — V5's tree-row context menu pattern, kept.
- Keyboard shortcuts deferred past the first working version — not a phase-00..30
  requirement.

## Details/properties editing

Native details-panel (`IStructureDetailsView`) reuse throughout, not custom widgets —
V5's mesh/font-size override fields and State/City/Highway/HighwayPoint editing already
proved this scales to V6's larger field count without custom widget maintenance.

## Visual identity

- Debug draw category colors are per-category config (see
  [06-v6-debug-system.md](06-v6-debug-system.md)), not hard-coded — but ship with
  sensible group-level defaults (e.g. all `Infrastructure` categories default to warm
  colors, all `Runtime` categories default to cool colors) so a fresh 30+ category tree
  isn't visually undifferentiated out of the box.
- Icons: reuse Slate's built-in editor icon set where a suitable icon exists (matches
  V5's approach); no custom icon asset pipeline planned for the first version.

## References

- [02-v5-feature-inventory.md](02-v5-feature-inventory.md) — V5's actual UI surface.
- [04-v6-architecture.md](04-v6-architecture.md)
- [06-v6-debug-system.md](06-v6-debug-system.md)
- [13-v6-gizmo-system.md](13-v6-gizmo-system.md)

## Revision — 2026-08-10 — reverted to three independently dockable tabs

The "Panel/tab layout" section above (one combined panel, deliberately fewer tabs than
V5) is **superseded** by an explicit ad-hoc user request the same day: "Details Panel
and Diagnostics Panel must be separate independently dockable tabs... support normal
Unreal Editor docking behavior: Dock/Undock/Move/Resize/Close/reopen... Do not force
both panels into the main Nexus panel layout." `SNexusFrameworkPanel` (the single
combined `SCompoundWidget` this doc originally described) is now split into three
separate widgets, each its own Nomad tab, still all opened/closed together in lockstep
with Landscape Mode (`FNexusLandscapeModeExtension`, unchanged in that respect):

- **Nexus Hierarchy** (`SNexusHierarchyPanel`, tab id `NexusFrameworkPanel`) - the
  Hierarchy tree + Debug Tree, unchanged from the original design's own Nexus Panel
  section (these two stayed together - only Details/Diagnostics were split out).
- **Nexus Details** (`SNexusDetailsPanel`, tab id `NexusDetailsPanel`).
- **Nexus Diagnostics** (`SNexusDiagnosticsPanel`, tab id `NexusDiagnosticsPanel`).

Since Details/Diagnostics can each now be closed/reopened independently, cross-tab
communication (Details showing whatever's selected in the Hierarchy/Debug Tree tab,
including when Details wasn't even open at selection time) is mediated through
`UNexusFrameworkSubsystem` (`GetDetailsTarget()`/`SetDetailsTarget()`/
`OnDetailsTargetChanged`, `OnActiveConfigDataChanged`) rather than the direct
same-object method calls the original single-widget design used - see
`ai-change-audits/2026-08-10/feature-add/v6-ui-hierarchy-schema-improvements.md` for
the full implementation record.
