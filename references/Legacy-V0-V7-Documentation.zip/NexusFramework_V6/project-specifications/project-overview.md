# 00 — Project Overview

## What this is

NexusFramework_V6 is an **Unreal Engine 5.8 Editor-Only Plugin**. Its job is not "city
generation" in isolation — it reads a hand-authored (or procedurally authored) Landscape
Spline network, maps it into a clean Nexus representation, generates an optimized static
world from it, and compiles a runtime-safe dataset the shipped game uses to activate
gameplay objects (traffic lights, bus stops, seats, ads, and future systems) only where
and when needed.

```
Landscape → Nexus Mapping → World Generation → Static Optimization → Runtime Activation Data
```

## Status

**Drafted — 2026-08-09.**

## Why V6, not V5 iterated further

V5 proved the core idea (Landscape-as-geometry-source, Nexus-as-config-layer) works, but
grew several structural debts documented in
[03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md):

- A manual Load Layout workflow (asset picker, 4-way choice dialog, cross-map ownership
  dialog) that exists only because V5 let a Nexus config asset get disconnected from
  "which Landscape it actually belongs to." V6 removes the whole category by deriving
  the config asset from the Landscape's own stable identity automatically.
- Runtime Schema is further along than it first appears — V5 already prototyped a
  generic activation-point shape (`FNexusDynamicInteractable`: HighwayPoint anchor +
  offset location/rotation + type) and station occupancy structs
  (`FNexusParkingInfo`/`FNexusBusStopInfo`), aggregated into one `FNexusFrameworkResult`
  — but it stops short of what V6 needs: no tangent/start-end on the point schema, no
  pole-vs-LED / pole-vs-light-source offset split, no crosswalk struct, no
  seat/passenger-point type, no Static/Dynamic classification tag anywhere (confirmed
  directly against V5's actual `Source/NexusFramework/Public/Schema/Runtime/*.h` — full
  audit in [10-v6-runtime-schema.md](10-v6-runtime-schema.md)).
- A debug system that grew one hard-coded category at a time, fine at V5's scale, not
  viable at V6's target of 30–50+ categories.
- Everything V5 spawns stays a permanent Actor. That doesn't scale to a GTA-V-scale
  world with thousands of traffic lights, bus stops, and seats.

## Goals

- Landscape remains the single geometry source of truth — V6 never re-implements a
  second authoritative geometry system.
- Every gameplay-relevant object is representable as a HighwayPoint + offset
  (Activation Point), not a bespoke per-feature architecture.
- Static world is optimized (merge/instance); dynamic world is activation data only,
  resolved to actors near the player.
- Runtime Schema is a first-class, audited output — not an afterthought.
- Debug Mode scales to 30–50+ categories without per-category special-casing.
- No manual Load Layout step — plugin enable is fully automatic per Landscape.

## Non-goals

- V6 does not implement actual runtime gameplay logic (traffic AI, bus routes, seat
  animation) — it produces the *data* (Activation Points, offsets, relationships) that a
  separate gameplay system consumes. Where that boundary sits is defined in
  [12-v6-activation-point-system.md](12-v6-activation-point-system.md).
- V6 does not attempt automatic migration of existing V5 Layout assets in its first
  version — see [08-v5-vs-v6.md](08-v5-vs-v6.md) for the explicit decision and rationale.
- V6 does not redesign Unreal's Landscape Spline tooling itself — it consumes it as-is,
  including its known limitations (see [01-v5-analysis.md](01-v5-analysis.md)'s
  known-unsafe-API list, which still applies).

## Target scope

Detailed in [04-v6-architecture.md](04-v6-architecture.md) and the `phases/` roadmap.
High-level: a working Landscape reader + Mapping layer, a data-driven Debug system, a
Static Generator, a Runtime Compiler producing a validated Runtime Schema asset, and an
Activation Point system covering at minimum traffic lights, city lights, crosswalks, and
bus stops end-to-end (data → debug visualization → gizmo editing → runtime export),
proving the general Activation Point pattern before every future object type is added.

## Relationship to V5

Clean-slate framework, not a migration target for V6's first version. V5 keeps running
independently; V6 is architected from scratch using V5's lessons, not V5's code. See
[08-v5-vs-v6.md](08-v5-vs-v6.md).

## References

- [01-v5-analysis.md](01-v5-analysis.md) — what V5 actually is, architecturally.
- [02-v5-feature-inventory.md](02-v5-feature-inventory.md) — what V5 actually has.
- [03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md) — what V5 got wrong or
  learned the hard way.
- [10-v6-runtime-schema.md](10-v6-runtime-schema.md) — the concrete Runtime Schema gap
  audit referenced above.
