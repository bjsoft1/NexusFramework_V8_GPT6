# V6 Production Editor + Debugging Architecture — Audit Source Document

Status: **Reference — 2026-08-10.** Saved verbatim from the user's own audit prompt, per
`CLAUDE.md`'s "documentation is part of the V6 development system" rule — this is the
source text the gap analysis in `ai-change-audits/2026-08-10/others/
v6-editor-production-audit.md` was run against. Scope is Editor/authoring/procedural
generation/debug/validation/gizmo/preview/compiled-data-prep ONLY — explicitly excludes
runtime gameplay, actor pooling, runtime AI, runtime traffic simulation, runtime
missions, runtime query systems (those remain out of scope for this doc and for the
audit it produced).

See `v6-master-architecture.md` for the prior (2026-08-10, earlier same day) full
architecture pass this document extends/refines, not replaces — where the two overlap
(Debug LOD, gizmo sub-point addressing, Parking/Bus Stop/Seat field specs), the earlier
doc's requirements were already implemented before this one arrived; this doc's real new
contribution is the Editor Demo/Test Systems section, the Generated-vs-Manual offset
split, the Transform-Parity test concept, and the per-object-type generation-strategy
model (Sequential/Rule-Based/Decorative).

---

## Core Editor Pipeline

```text
Landscape
    ↓
Read spline/control-point data
    ↓
Build State / City / Highway / Point hierarchy
    ↓
Generate 30–40+ object types
    ↓
Debug visualize
    ↓
Gizmo/manual adjustment
    ↓
Validation
    ↓
Demo/test verification
    ↓
Final mesh/data preview
    ↓
Compile final optimized dataset
```

## Object Generation

Support different authoring strategies:

### Sequential

Examples: City Light, Electricity Pole, Roadside infrastructure.

### Rule-Based / Semi-Random

Examples: Bus Stop, Parking, Hospital, School, Petrol Station, Charging Station,
Playground, Seats, Ads/TV.

### Highly Random / Decorative

Examples: Trash Can, Trash, Dust, Debris, Small roadside props.

Generation settings should support where appropriate:

```text
MinGap
MaxGap
MinDistance
MaxDistance
Probability
Priority
RandomSeed
GeneratedLocationOffset
GeneratedRotationOffset
```

Do not assume every object type needs the same generation model.

## Generated vs Manual Adjustment

Keep these separate:

```text
FinalTransform =
    Landscape/HighwayAnchor
    × GeneratedOffset
    × ManualOffset
```

`GeneratedOffset` = procedural variation. `ManualOffset` = user gizmo correction. Manual
corrections must not be accidentally destroyed by procedural regeneration.

## Advanced Debugging

Debug visualization is a core production authoring feature. We may have 30–40+ object
types, 100+ debug leaves/options. Use a scalable registry/tree/config system, not
hundreds of unrelated hard-coded checkboxes.

Debug configuration should support where appropriate:

```text
IsVisible
Color
Thickness
PointSize
TextColor
FontSize
IsAlwaysDraw
FullDetailDistance
LabelDistance
LOD
```

Keep: Distance-based LOD, Closest-point-to-AABB distance, AABB/impostor fallback,
Full-detail object cap, Distance ranking, Frustum/radius filtering, Always Draw.

## Accurate Preview

Debug rendering must show the **real authored result**, not only symbolic markers.
Example Parking: bounds, every Row × Column spot, SpotWidth, SpotLength, RowGap,
ColumnGap, Free/occupied state, Indicator position, Anchor, GeneratedOffset,
ManualOffset, FinalTransform. If the debug view says Parking Spot #12 is at Transform A,
the final generated preview/compiled data must resolve to Transform A. Apply the same
principle to Bus Stops, Seats, Traffic Lights, Facilities, Crosswalks, etc.

## Generic Gizmo

The editor must support: single point, multiple fixed sub-points, dynamic N-element
arrays, nested object-specific points. Examples: TrafficLight (Pole/VehicleLED/
PedestrianLED), BusStop (StoppingPoint/EntryPoint/ExitPoint/PassengerWaitingPoints[]/
SeatInteractionPoints[]), Crosswalk (Start/End/WaitingPoints[]). Do not build separate
gizmo architecture for every object type.

## Advanced Validation

Validate more than simple data existence. Check: invalid/duplicate IDs, broken
hierarchy, missing Highway/Point references, invalid transforms, invalid tangent/
direction, NaN/zero vectors, invalid dimensions, invalid occupancy index, missing
sub-points, bad spacing, overlapping/invalid generated placement, relationship/
connectivity errors. Support severities: Info, Warning, Error, Blocking. Where possible:
click validation issue → select/focus object in viewport.

## Editor Demo/Test Systems

Create lightweight **Editor-only validation helpers**, not production gameplay.

**Demo Vehicle** - use generated data to verify: follow highway, follow tangent, follow
lane, switch highway, navigate junction, lane switch, overtake test, traffic-light
stop/wait/go, select parking spot, reach exact parking transform.

**Demo Character** - verify: walk using generated points, reach bus-stop waiting point,
find seat, move to exact seat interaction transform, verify facing rotation, reach
facility entrance.

The goal is NOT production AI. The goal is: **prove that the Editor-generated data is
spatially correct and usable.**

## Critical Transform-Parity Test

There must be one deterministic transform-resolution rule. Verify equality between:
Debug representation, Gizmo result, Preview mesh, Final generated mesh, Compiled data,
Demo vehicle target, Demo character target. Any mismatch is a production-blocking bug.

## Dedicated Test Fixtures

Plan separate fixtures for important systems: Parking, Bus Stop, Seat, Traffic Light,
Crosswalk, Facility, Sequential City Lights, Random decorative objects. Do not validate
Parking using only Bus Stop test data.

## Production Quality Requirement

Do not accept "works for this object" / "temporary solution" / "hard-code it for now" /
"we can redesign later" if the same architecture must support 30–40+ object types.
Prefer reusable/extensible systems.

## Architecture Gap Rule

If required information is missing, do NOT silently invent it. Report: Missing / Why it
matters / Affected object/system / Recommended options / Question for user. Ask only
when a genuine product/design decision is missing.
