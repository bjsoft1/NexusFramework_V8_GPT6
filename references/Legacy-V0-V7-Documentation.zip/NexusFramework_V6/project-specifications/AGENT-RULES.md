# Agent Rules — NexusFramework_V6

Persistent, project-wide rules for every AI agent working on V6 — Claude Code, new
sessions, sub-agents, future agents, regardless of which phase or task is active. Every
agent must read this file before starting work and follow these rules unless the user
explicitly overrides them for a specific task. Distinct from
[09-development-rules.md](09-development-rules.md) (process/workflow rules) — this file
is specifically the standing policy boundaries an agent must not cross without explicit
user instruction.

## Agent Testing Policy

Added 2026-08-09, user-requested, after a session spent significant time chasing a false
test failure (an automated test's own tab-detection logic was wrong; the real feature
already worked, confirmed by the user manually in the editor — see
`ai-change-audits/2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md`'s
2026-08-09 Correction section for the full story). That cost was avoidable: the user
verifies UI/editor behavior manually in Unreal Editor, so agent-written automated tests
for that purpose are, by default, unwanted overhead, not a safety net.

**AI agents must NOT create or execute automated tests unless the user explicitly
requests testing.**

Rules:

- Do NOT write new test cases.
- Do NOT create test files, automation tests, unit tests, functional tests, or
  test-only code.
- Do NOT spend time debugging or fixing automated test failures.
- Do NOT launch Unreal Editor specifically for automated testing.
- Do NOT run `Automation RunTests`.
- Do NOT add test infrastructure or test dependencies.
- Focus only on the actual implementation task requested by the user.
- Build/compile only when necessary to verify that the implementation compiles, unless
  the user explicitly says to skip compilation too.
- **The user will manually test and verify the implementation in Unreal Editor.**
- If testing would normally be useful, document what the user should manually verify
  instead of implementing an automated test.
- Never modify production code merely to satisfy an automated test.
- Never claim that a feature is verified unless the user has manually verified it or
  explicitly provides verification results.

### Priority

This is a **project-wide persistent rule**, not a rule scoped to only the current phase
or task. Every future AI agent must read this file
(`project-specifications/AGENT-RULES.md`) before starting work and follow these rules
unless the user explicitly overrides them.

## C++ Coding Standard

Added 2026-08-10, user-requested. **Every agent must read
[v6-coding-standard.md](v6-coding-standard.md) before writing or modifying any C++ in
this project** — same standing weight as the Agent Testing Policy above. Summary: types/
members/functions are PascalCase (boolean members/functions use an `Is/Has/Can/Should/
Was/Were` semantic prefix, replacing Epic's own `b`-prefix convention project-wide);
parameters/locals (including `const`/`static`/`constexpr` locals) are camelCase; read
that file's own "Serialization risk" section before renaming any `UPROPERTY` boolean —
this project already has saved `.uasset` content on disk that a bare rename would
silently corrupt.

### Priority

Same as the Agent Testing Policy above — project-wide, persistent, applies regardless of
which phase or task is active.
