# 11 — V6 Static/Dynamic Architecture

## Status

**Drafted — 2026-08-09.**

## The classification

Every object the Static Generator or Runtime Compiler produces gets exactly one
explicit tag — never implicit, never inferred later from context:

```
ENexusGenerationClassification : uint8
{
    Static,              // merged into a static mesh batch, never moves, no runtime cost
    Instanced,            // ISM/HISM instance, cheap to render in bulk, no gameplay logic
    MergedStatic,          // explicitly merged via mesh-merge tooling (distinguished from
                            // Static for cases needing a separate merge pass/material atlas)
    RuntimeActivated,       // Activation Point — spawns/despawns near the player (12)
    RuntimePersistent,       // always-live gameplay actor (rare — e.g. a mission-critical
                              // NPC spawn point), used sparingly, never the default
    EditorOnly,               // debug/authoring helper, stripped from cooked builds
    DebugOnly,                 // visible only when Debug Mode is on, stripped otherwise
}
```

Assigned at the point an object is generated (Static Generator or Runtime Compiler
decides, per object type — a traffic-light pole is always `Static`, a traffic-light LED
is always `RuntimeActivated`, regardless of Debug Mode state). The tag then drives every
downstream decision: whether an object is meshed, whether it's exported to the Runtime
Schema at all, and whether Debug rendering shows it by default.

## Object → classification mapping (starting set)

| Object | Classification |
|---|---|
| Highway/road surface mesh | Static (merged per Highway or per streaming cell) |
| Sidewalk mesh | Static |
| Traffic-light pole | Static (or Instanced if identical across many junctions) |
| Traffic-light LED (vehicle/pedestrian) | RuntimeActivated |
| City-light pole | Instanced |
| City-light source (the actual light component) | RuntimeActivated |
| Bus-stop shelter/bench/sign | Static or Instanced |
| Bus stopping/entry/exit point | RuntimeActivated (no mesh — pure activation data) |
| Seat (physical mesh) | Static/Instanced |
| Seat interaction point | RuntimeActivated |
| Crosswalk mesh/decal | Static |
| Crosswalk pedestrian-waiting point | RuntimeActivated |
| Static advertisement board mesh | Static |
| Interactive advertisement content | RuntimeActivated |
| Debug wireframe/label (any category) | DebugOnly |
| Gizmo helper actor | EditorOnly |

## Why this must be explicit, not implicit

V5 never had this tag — everything V5 spawned was either baked into a static mesh with
no further metadata, or left as a full permanent Actor. The master prompt's core
motivation for V6 (a potentially GTA-V-scale world can't sustain millions of independent
Actors) requires the Static Generator and Runtime Compiler to make this decision
deliberately and record it, not leave it to whatever a given feature's implementer
happened to do. This is the single mechanism that lets Debug Mode, the Static Generator,
and the Runtime Compiler all agree on what a given generated object actually is, without
three separate ad-hoc classification schemes drifting apart.

## Generation-stage responsibilities by classification

- **Static / MergedStatic** — Static Generator batches these per streaming cell
  (matching V5's `DataLayerAssetName` precedent, see
  [10-v6-runtime-schema.md](10-v6-runtime-schema.md)), never appears in the Runtime
  Schema's gameplay-facing structs (`FNexusRuntimeResult`) at all — it's baked geometry,
  not activation data.
- **Instanced** — Static Generator groups into ISM/HISM components per mesh+material
  combination, same streaming-cell grouping as Static.
- **RuntimeActivated** — Runtime Compiler emits an Activation Point entry (see
  [12](12-v6-activation-point-system.md)); no mesh baked for the interactive part itself
  (though a *paired* static mesh, e.g. the seat itself, is a separate `Static`-classified
  object referencing the same HighwayPoint).
- **RuntimePersistent** — Runtime Compiler emits it, flagged never-deactivate; used
  sparingly and requires explicit justification per use (not a default fallback when
  unsure — unsure defaults to `RuntimeActivated`).
- **EditorOnly / DebugOnly** — never reach Generation or Compilation output; exist only
  in the editor-side Debug/gizmo systems.

## References

- [04-v6-architecture.md](04-v6-architecture.md)
- [10-v6-runtime-schema.md](10-v6-runtime-schema.md)
- [12-v6-activation-point-system.md](12-v6-activation-point-system.md)
