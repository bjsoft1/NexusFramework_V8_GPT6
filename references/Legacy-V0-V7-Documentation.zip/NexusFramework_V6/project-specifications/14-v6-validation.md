# 14 — V6 Validation Architecture

## Status

**Drafted — 2026-08-09.**

## Rule

Every pipeline stage validates its own output before the next stage is allowed to
consume it — never a single validation pass bolted on at the very end.

```
Landscape Read       → Validate: every referenced control point actually resolves
      ↓
Mapping                → Validate: every Landscape entity maps to exactly one
                          HighwayPointId; no orphaned/duplicate mappings
      ↓
Representation           → Validate: every Highway's OrderedPointIds reference points
                            that exist; every City/State membership is consistent;
                            no dangling ActivationPoint→HighwayPointId reference
      ↓
Generation                  → Validate: every object has a Classification tag (11); no
                               object silently defaults to unclassified
      ↓
Runtime Compilation            → Validate: schema-level invariants (no duplicate
                                  Runtime Ids, no missing required fields)
      ↓
Final Validation                  → whole-dataset pass before the Runtime Schema asset
                                     is allowed to save
```

A stage that fails validation blocks the next stage from running against its output —
it does not silently pass through invalid data hoping a later stage catches it (this is
the direct fix for V5's occasional "clean success log, but the Landscape edit didn't
actually take effect" class of issue — see the analogous lesson in
[03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md)).

## Validation checks by category

- **Missing references** — any `HighwayPointId`/`HighwayId`/`CityId`/`StateId`/
  `ActivationPointId` referenced somewhere that doesn't resolve to a live entity.
- **Invalid segments** — a Highway segment whose two endpoints don't correspond to
  adjacent entries in `OrderedPointIds`, or whose Landscape connection is broken.
- **Invalid tangent** — near-zero-length tangent at a point that isn't a genuine
  dead-end (the underlying cause of V5's known engine `Q.IsNormalized()` crash risk —
  see [01-v5-analysis.md](01-v5-analysis.md) — validation here is a mitigation, not a
  fix for the engine bug itself, since it lets Compilation catch and report the
  condition instead of an editor crash discovering it).
- **Invalid mapping** — a Landscape control point tracked by more than one
  HighwayPointId, or a HighwayPointId whose `SourcePoint` resolves to a control point
  not on the current Landscape (the cross-map class of bug, see
  [03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md)).
- **Duplicate IDs** — any `FGuid`/Runtime `FName Id` collision within its own scope.
- **Missing activation point** — an object type whose Classification is
  `RuntimeActivated` but has no compiled `FNexusActivationPoint` entry.
- **Invalid offset** — a NaN/degenerate offset transform.
- **Invalid City/Highway relationship** — a Highway's `StartCityId`/`EndCityId` (or V6
  equivalent) referencing a City not present in the same Representation snapshot.
- **Broken junction** — a HighwayPoint reported as a junction (multiple
  `ConnectedHighwayIds`) where the Landscape segments don't actually meet there.
- **Invalid runtime data** — anything that would fail to deserialize/round-trip in the
  final compiled asset.

## Severity and reporting

Two severities, not a single pass/fail:

- **Blocking** — Compilation/Generation must not proceed past this stage (e.g. missing
  reference, duplicate ID, invalid tangent). Surfaces as the modal warning dialog
  described in [07-v6-ui-design.md](07-v6-ui-design.md).
- **Warning** — proceeds, but is recorded and surfaced in the Diagnostics Panel (see
  [06-v6-debug-system.md](06-v6-debug-system.md)) — e.g. a HighwayPoint with no
  ActivationPoints at all where one might be expected, or a Highway with an unusually
  short segment.

Validation results themselves are never written into the shipped Runtime Schema asset
(per [10-v6-runtime-schema.md](10-v6-runtime-schema.md)'s note) — they're an
editor/Compilation-time gate, not gameplay data.

## References

- [01-v5-analysis.md](01-v5-analysis.md)
- [03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md)
- [04-v6-architecture.md](04-v6-architecture.md)
- [06-v6-debug-system.md](06-v6-debug-system.md)
- [10-v6-runtime-schema.md](10-v6-runtime-schema.md)
