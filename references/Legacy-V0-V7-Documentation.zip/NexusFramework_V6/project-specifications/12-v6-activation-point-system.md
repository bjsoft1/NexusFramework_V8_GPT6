# 12 — V6 Activation Point System

## Status

**Drafted — 2026-08-09.** The single most important new V6 concept per the master
architecture prompt. Generalizes V5's real but limited prototype,
`FNexusDynamicInteractable` (see [10-v6-runtime-schema.md](10-v6-runtime-schema.md)).

## The base concept

```
FNexusActivationPoint
{
    ActivationPointId      (FGuid, stable)
    HighwayPointId          (anchor — always resolved live, never cached, per 04/05)
    OffsetLocation
    OffsetRotation
    Type                     (open enum/registry, not V5's fixed 4-value enum — see below)
    RuntimeClass              (what to spawn/activate)
    ActivationDistance         (-1 = global default, matches V5's convention)
    ActiveTimes                  (bitmask — day/night/afternoon/midnight, kept from V5)
    DeactivationTimes             (bitmask, same shape as ActiveTimes — 2026-08-10
                                    addition. A bucket set here forces this instance off
                                    even if the same bucket is also set in ActiveTimes.
                                    Replaces V5's removed MidnightAutoDisabled enum value
                                    — that only covered one bucket; this covers any.
                                    Evaluation order is Phase 89's job.)
    Classification                (see 11 — almost always RuntimeActivated)
    Metadata                       (TMap<FName,FString> or a small variant-typed payload
                                     for type-specific extra data that doesn't warrant a
                                     whole specialized struct)
    bAlwaysDraw                     (per-instance debug-visibility override, default
                                      false — v6-master-architecture.md Section 23; see
                                      phase-46.md's 2026-08-10 revision. Distinct from
                                      Phase 25's per-CATEGORY visibility toggle: this
                                      instance still renders even when its owning
                                      category is toggled off/the panel is closed.)
}
```

`FinalTransform = HighwayPointTransform * OffsetTransform` (Unreal transform
composition — offset is local to the HighwayPoint's transform, not world-space; this
is what makes the offset stay correct if the HighwayPoint's Landscape anchor is ever
edited).

## Why a shared base instead of one struct per feature

V5's `FNexusDynamicInteractable` proved the anchor+offset+type idea but hit its ceiling
immediately: one offset pair can't describe a traffic light (needs three distinct
positions) or a bus stop (needs five-plus). The fix isn't to keep adding fields to one
struct — it's a shared base plus specialized payloads, so a new object type never
requires touching the base:

```
FNexusActivationPoint                    (base — always present)
  ├─ FNexusTrafficLightActivation         : Pole sub-offset, VehicleLED sub-offset,
  │                                          PedestrianLED sub-offset, ControlledLaneIds[],
  │                                          ControlledRoadIds[], SignalGroup
  ├─ FNexusCityLightActivation             : LightSource sub-offset (Pole itself is a
  │                                           separate Static-classified object, not part
  │                                           of this struct — see 11)
  ├─ FNexusBusStopActivation                : StoppingPoint/EntryPoint/ExitPoint
  │                                            sub-offsets, PassengerWaitingPoints[],
  │                                            SeatInteractionPoints[] (each a
  │                                            FNexusSeatActivation payload, not just a
  │                                            bare point), ShelterConfig, BaseMesh,
  │                                            IndicatorMesh (v6-master-architecture.md
  │                                            Section 7 — see phase-64.md's 2026-08-10
  │                                            revision for the fields this line
  │                                            originally omitted)
  ├─ FNexusCrosswalkActivation               : StartPoint/EndPoint, PedestrianWaitingPoints[],
  │                                             Width, LinkedTrafficLightId
  ├─ FNexusSeatActivation                     : SeatType, SeatCapacity (one physical
  │                                              object may represent N logical seats —
  │                                              v6-master-architecture.md Section 8),
  │                                              Occupancy (V5's FNexusOccupancyGrid
  │                                              shape: NumRows/NumColumns/OccupiedIndex),
  │                                              Spacing, SeatMesh (optionally
  │                                              capacity-keyed, porting V5's
  │                                              FNexusSittingSite::
  │                                              OverrideMeshOptionsByCapacity), optional
  │                                              GroupId — see phase-69.md's 2026-08-10
  │                                              revision (the original "base fields
  │                                              sufficient" scoping here was a
  │                                              regression from V5's own FNexusSittingSite
  │                                              precedent, corrected)
  ├─ FNexusAdvertisementActivation              : ContentId/PlaylistId
  └─ FNexusParkingActivation                     : Row/Column, RowGap/ColumnGap,
                                                     SpotWidth/SpotLength, BaseMesh,
                                                     ParkingIndicatorMesh, OccupiedIndex[]
                                                     (v6-master-architecture.md Section 6 —
                                                     extends V5's FNexusStationInfoBase
                                                     SegmentRow/Column/AllowVehicles/
                                                     OccupiedIndex shape with the
                                                     spacing/dimension/mesh fields V5
                                                     never had; see phase-70.md's
                                                     2026-08-10 revision)
```

Each specialized struct **contains** an `FNexusActivationPoint` (or inherits from it,
matching V5's own `FNexusStationInfoBase`→`FNexusParkingInfo`/`FNexusBusStopInfo`
inheritance precedent — reuse that pattern, it already works) rather than duplicating
the anchor/offset/classification fields. A brand-new object type (a future charging
station, a future petrol station) adds one new specialized struct plus one new `Type`
enum value or registry entry — it never touches `FNexusActivationPoint` itself, the
Debug Tree registration model (see [06](06-v6-debug-system.md)), or the Gizmo system
(see [13](13-v6-gizmo-system.md)).

## Type registry, not a closed enum

V5's `ENexusDynamicInteractableType` is a fixed enum — adding a 5th type means editing
that enum and every switch statement over it. V6 uses the same registry pattern as the
Debug system ([06](06-v6-debug-system.md)): each Activation Point type registers its
specialized struct type, default classification, default Debug category, and default
gizmo behavior once, at startup. Generation/Compilation/Debug code iterates the registry
generically — never a hard-coded `switch (Type) { case TrafficLight: ... }` chain.

## Runtime activation flow

```
Player/Actor moves
        ↓
Nearby ActivationPoint query (spatial index over ActivationPointId + world position,
                               computed as HighwayPointTransform * OffsetTransform at
                               Compilation time and baked into the query structure —
                               not recomputed per query)
        ↓
Resolve specialized payload (traffic light? bus stop? ...)
        ↓
Apply OffsetTransform (already baked; this step is a cache read, not live composition)
        ↓
Spawn/activate the RuntimeClass actor/component
        ↓
Actor performs its gameplay behavior
        ↓
Player leaves ActivationDistance → deactivate/despawn (or pool for reuse, matching
                                                          V5's `FNexusDynamicInteractable`
                                                          doc comment's pooling intent)
```

The Editor plugin only ever produces this data (Compilation stage). The runtime
Activation subsystem (in the `NexusFramework` runtime module, per
[04-v6-architecture.md](04-v6-architecture.md)'s module split) is the only consumer —
kept strictly separate so the editor plugin never needs to link against gameplay code.

## Traffic Light Signal Group runtime coordination contract (Phase 52, 2026-08-12)

`FNexusTrafficLightActivation::SignalGroup` (plain `FName`, blank = standalone/ungrouped)
is a DATA-ONLY coordination tag, added by Phase 52 ("Traffic Light - Signal Group Data").
This section documents the contract it establishes for the runtime module to consume -
per that phase's own explicit scoping, the actual synchronization state machine is NOT
implemented here, or by the Editor plugin at all.

**The contract:**

```
Two or more FNexusTrafficLightActivation instances share the same non-blank SignalGroup
        -> they are DECLARED to be one coordinated intersection signal group
        -> the runtime Activation Subsystem (Phase 86-89's module, or a future
           dedicated Traffic Light runtime controller built on top of it) is
           responsible for driving them through a shared phase/state-machine
           (e.g. all switch Vehicle-red + Pedestrian-walk simultaneously, then
           Vehicle-green + Pedestrian-stop, in lockstep across every member)
        -> a light with a blank SignalGroup is standalone - it runs its own
           independent timing, coordinated with nothing
```

**What the Editor plugin's own pipeline is responsible for** (all that exists as of
Phase 52):

- Authoring: `SignalGroup` is Details-panel-editable like any other payload field (Phase
  51's `TestActivationPointPayload` Details-panel binding - no Traffic-Light-specific UI
  code, see that phase's own record).
- Query: `FNexusTrafficLightActivation::FindActivationPointsInSignalGroup` - given a
  group name and a set of candidate instances, returns every member. Used today by
  `Nexus.Representation.FindTrafficLightsInSignalGroup` for manual verification; the same
  function is the intended building block for a future Compilation-stage export step
  (Phase 55) that would group `FNexusRuntimeResult`'s exported Traffic Light entries by
  `SignalGroup` before handing them to the runtime module.
- Validation (Phase 55's own stated scope - "Compilation-stage validation covers
  Traffic-Light-specific fields, e.g. dangling SignalGroup"): NOT implemented by Phase 52 -
  candidate checks for that future pass include flagging a SignalGroup with exactly one
  member (a "group" that coordinates nothing) or one whose `ControlledLaneIds`/
  `ControlledRoadIds` conflict across members at the same junction. Left as an open
  question for whoever picks up Phase 55, not decided here.

**What the runtime module is responsible for** (none of this exists yet - Phase 86-89 is
still `Not started` as of this writing):

- Grouping active Traffic Light instances by `SignalGroup` at activation time (or reading
  a pre-grouped Compilation-stage export, if Phase 55 adds one - undecided).
- Owning the actual phase/state timing logic and applying it in lockstep to every group
  member.
- Nothing in `12-v6-activation-point-system.md`'s "Runtime activation flow" section above
  changes - `SignalGroup` is exported as plain data through the same
  Compile -> Resolve payload -> Spawn/activate pipeline, same as every other field.

## Crosswalk LinkedTrafficLightId runtime pedestrian-signal contract (Phase 61, 2026-08-12)

`FNexusCrosswalkActivation::LinkedTrafficLightId` (plain `FGuid`, invalid/unset =
unlinked) is a DATA-ONLY reference, added by Phase 61 ("Crosswalk - Traffic-Light
Linkage"). Same "data now, behavior later" split as SignalGroup above - this section
documents the contract for the runtime module to consume; the Editor plugin does not
implement pedestrian-signal coordination itself.

**The contract:**

```
FNexusCrosswalkActivation::LinkedTrafficLightId == some Traffic Light's own ActivationPointId
        -> that Crosswalk is DECLARED to be controlled by that Traffic Light
        -> the runtime Activation Subsystem (Phase 86-89's module) is responsible for
           driving this Crosswalk's pedestrian "walk/don't walk" state directly off
           that Traffic Light's own FNexusTrafficLightActivation::PedestrianLED phase
           (never off VehicleLED - PedestrianLED is the correct source of truth for a
           pedestrian crossing's own signal state)
        -> LinkedTrafficLightId unset (invalid Guid) means this Crosswalk is
           uncontrolled - it runs with no signal-driven pedestrian state at all
```

**What the Editor plugin's own pipeline is responsible for** (all that exists as of
Phase 61):

- Authoring: `LinkedTrafficLightId` is Details-panel-editable like any other payload
  field (same generic `TestActivationPointPayload` binding Phase 51 already established
  - no Crosswalk-specific UI code).
- Console-scriptable linking for manual QA:
  `Nexus.Representation.LinkCrosswalkToTrafficLight`.
- Validation: `FNexusCrosswalkActivation::ValidateLinkedTrafficLight` - given a
  Crosswalk's own `LinkedTrafficLightId` and a caller-resolved set of known Traffic
  Light `ActivationPointId`s, flags a dangling link as `Blocking`. Exercised via
  `Nexus.Representation.ValidateCrosswalkLinkedTrafficLight`. Not yet wired into
  `FNexusRepresentationGraph::ValidateRepresentationStage`'s own aggregate pass (that
  function's own header comment explains why shared Representation-stage validation
  never branches on a specific `Type` - a future Compilation-stage validation pass,
  same open question Phase 52's SignalGroup section above already flagged for its own
  fields, is the likely place this gets aggregated).

**What the runtime module is responsible for** (none of this exists yet - Phase 86-89 is
still `Not started` as of this writing):

- Resolving `LinkedTrafficLightId` to the live Traffic Light instance at activation
  time and reading its current `PedestrianLED` phase.
- Owning the actual pedestrian "walk/don't walk" state transition logic and applying it
  to the Crosswalk's own runtime representation.
- Nothing in this doc's "Runtime activation flow" section above changes -
  `LinkedTrafficLightId` is exported as plain data through the same
  Compile -> Resolve payload -> Spawn/activate pipeline, same as every other field.

## Payload persistence — RESOLVED 2026-08-22

How a specialized payload actually gets **saved** was left open from Phase 46 all the way
through Phase 75 (which re-reported it as its own GAP 1). `UNexusConfigAsset::ActivationPoints`
held base-only values, so every type declaring sub-point fields — Traffic Light, Crosswalk,
Bus Stop, Seat, Parking, and the five Services/Facilities — existed only in the session-only
`FNexusActivationPointTestStore`. Nothing a designer authored survived an editor restart.

**Decision: `FInstancedStruct`, stored on `FNexusActivationPoint` itself.**

```
FNexusActivationPoint
 |- ActivationPointId / HighwayPointId / Code / Name / Offset* / Type / ...   (shared base)
 \- Payload : FInstancedStruct        <- the specialized struct for this point's own Type
```

### Why not the alternatives

- **Per-type arrays on the config asset** (`TArray<FNexusTrafficLightActivation> …`) —
  rejected. Every new object type would have to edit the config asset, which is exactly the
  zero-edit-extensibility failure this document's own "Type registry, not a closed enum"
  section exists to prevent, and exactly the cost Phase 75 measured on the Generation side
  (its GAP 2) and refused to pay.
- **A hand-rolled byte blob** (`TArray<uint8>` + `UScriptStruct*`, which is what the test
  store used internally) — rejected. It re-implements, worse, what the engine already does:
  tagged and versioned serialization, reflection, Details-panel editing, undo integration.
- **`FInstancedStruct`** — chosen. It lives in `CoreUObject` as of UE 5.5
  (`StructUtils/InstancedStruct.h`), so it costs no new module or plugin dependency, and the
  built-in `StructUtilsEditor` module registers `FInstancedStructDetails`, which means the
  Details panel renders a type picker plus the payload's own inline properties for free.

### Why on the base struct rather than a side table

A `TMap<FGuid, FInstancedStruct>` on the config asset would leave `FNexusActivationPoint`
untouched, but it has to be kept in sync by hand — delete a point and you orphan a payload —
and it splits one logical object across two places, so create, delete, and undo would each
have to remember to touch both. On the point, all three are atomic for free.

This is **not** a violation of the standing "do not add feature-specific fields to
`FNexusActivationPoint`" rule (Phase 21's Not Allowed list, repeated by every object-type
phase since). That rule targets *feature-specific* fields — a traffic light's LED offset, a
parking lot's row count. `Payload` is the generic slot the rule itself points at
("specialize via a payload struct instead"), finally made persistable. Nothing on the base
struct knows or branches on any specific type; the struct type is resolved through
`FNexusActivationTypeRegistry`, exactly as every other Activation-Point-generic code path
already does.

### Keeping Type and Payload in agreement

`Type` is a user-editable `FName` on a plain struct, so retyping it in the Details panel
knows nothing about swapping the payload. `FNexusActivationPayloadReconciler` closes that:
`UNexusConfigAsset::PostEditChangeProperty` runs a reconcile pass over the array after any
edit. It is idempotent (a payload already of the right struct type is left alone), so it
never destroys authored values and needs no property filtering.

One deliberate exception: an **unregistered** `Type` leaves the payload untouched rather
than clearing it. A Type naming a module that is not currently loaded must not cost the user
their data — the Representation validation gate reports it as a Warning instead, which is
recoverable; discarding would not be.

### What this unblocked, and what it did not

Unblocked: real, persisted points now carry payloads and sub-points, so the gizmo's
real-point sub-point editing was reinstated (see
[13-v6-gizmo-system.md](13-v6-gizmo-system.md)'s "Scope narrowed to specialized sub-points"
section — the base offset of a real point still belongs to the Editor Proxy Actor pool;
only its specialized sub-points are this tool's).

**Not** unblocked: the Runtime Compiler. Phases 55/59 are `Blocked`, and the export leg of
Phases 73/74/75 is incomplete, because no Compilation stage or `FNexusRuntimeResult` exists
yet — that is Phases 80–85's own scope, and always was a separate wall from this one.
Persistence was the prerequisite; the compiler is still the work.

## References

- [04-v6-architecture.md](04-v6-architecture.md)
- [10-v6-runtime-schema.md](10-v6-runtime-schema.md)
- [11-v6-static-dynamic-architecture.md](11-v6-static-dynamic-architecture.md)
- [13-v6-gizmo-system.md](13-v6-gizmo-system.md)
