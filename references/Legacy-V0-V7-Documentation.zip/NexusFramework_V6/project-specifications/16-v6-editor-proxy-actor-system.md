# 16 — V6 Editor Proxy Actor System

## Status

**Implemented — 2026-08-11.** Direct user request, following real usability friction
found during Phase 49 manual testing with the custom gizmo (see
[13-v6-gizmo-system.md](13-v6-gizmo-system.md)'s own "too large at distance, doesn't feel
like a normal Actor" complaint). See `ai-change-audits/2026-08-11/feature-add/
editor-proxy-actor-pool-near-camera-interaction.md` for the full implementation record.

## The one rule

```
99,999+ Nexus authored objects
        -> PDI wireframe/debug rendering, globally, at any distance (unchanged)

camera-nearby editable objects (<= MaxActiveEditorProxies, default 100)
        -> reusable, pooled, transient ANexusEditorProxyActor instances
        -> native UE Actor selection + native UE transform widget
        -> edits write back into Nexus authored data (UNexusConfigAsset)
```

PDI (Layer A, "global visualization") is untouched by this document - see
[06-v6-debug-system.md](06-v6-debug-system.md). This document describes Layer B ("near-
camera interaction") only: a small pool of native Editor Actors that make the handful of
objects currently near the camera feel like normal Unreal Actors to select and drag,
without ever turning all 99,999+ authored objects into real Actors.

**Never make 99,999 Nexus objects into Unreal Actors.** Reuse a maximum small pool of
Editor-only transient Actors as temporary interaction handles for nearby Nexus objects.

## Why not the custom gizmo for this

[13-v6-gizmo-system.md](13-v6-gizmo-system.md)'s `UNexusActivationGizmoTool` remains -
unchanged in mechanism - as the tool for specialized SUB-POINT editing (Traffic Light's
VehicleLED/PedestrianLED, Crosswalk's `WaitingPoints[]`, Phase 50+). It briefly also
handled real ActivationPoints' base offset (Phase 49) but that is reverted: a custom ITF
gizmo can grow visually huge at distance and never quite feels like manipulating a normal
UE Actor (direct user complaint). Where the native Unreal transform widget can do the
job, it does the job - the custom gizmo is reserved for cases the native widget
structurally can't express (multiple independently-editable sub-points on one object,
never one Actor per sub-point).

## Two layers

### Layer A — PDI visualization (unchanged)

Continues rendering Landscape debug, highways, lanes, sidewalks, junctions, Activation
Points, mapping information, and every future object type (Traffic Light, City Light,
Crosswalk, Bus Stop, Parking, ...) at 99,999+ scale via existing LOD/culling
([06-v6-debug-system.md](06-v6-debug-system.md)). Nothing in this document changes PDI
rendering, gates it on gizmo/proxy state, or removes any debug line/box/wireframe.

### Layer B — reusable Editor Proxy Actor pool

`ANexusEditorProxyActor` (`Public/Proxy/NexusEditorProxyActor.h`) - one native, editor-
only, transient `AActor` per pool slot:

- `bIsEditorOnlyActor = true` (never cooked) + spawned with `RF_Transient` (never saved
  into the level) - never becomes persisted content, confirmed by grep (the only
  `SpawnActor`/`Destroy()` call sites in the whole feature are pool growth and full
  teardown - see "Safety properties" below).
- Deliberately **not** `RF_Transactional` - the proxy's own raw transform is never
  itself an undo step; only the semantic `UNexusConfigAsset::Modify()` write-back is (see
  "Write-back and undo" below).
- `PrimaryActorTick.bCanEverTick = false` - no per-proxy Tick; all periodic work happens
  once, at the pool level (`FNexusEditorProxyPool::TickUpdateNearbyProxies`, called from
  `UNexusFrameworkSubsystem::Tick`).
- A `UBillboardComponent` icon (`bIsScreenSizeScaled = true`, constant apparent size
  regardless of camera distance, the same mechanism built-in point-type icon Actors like
  `ATargetPoint` already use) - a real `UPrimitiveComponent`, so it generates normal
  editor hit proxies and is clickable like any mesh. Uses a built-in engine sprite
  (`/Engine/EditorResources/S_TargetPoint`) as a safe temporary generic icon; a per-Type
  icon (Phase 45's type registry) is the intended real future source, not yet wired.
- `BoundActivationPointId` (invalid = free/unbound), `AnchorWorldTransform` (the resolved
  HighwayPoint anchor this proxy's point was last composed against), and
  `IsProgrammaticTransformUpdate` (see "Avoiding feedback loops" below).

`FNexusEditorProxyPool` (`Public/Proxy/NexusEditorProxyPool.h`) - owned by
`UNexusFrameworkSubsystem` (the same "long-lived, mode-independent, editor-session-wide
state" home `ActiveConfig`/`RenderSnapshot` already use - see
[04-v6-architecture.md](04-v6-architecture.md)'s "Editor surface" section), reusing that
class's existing `Tick`/`RefreshRepresentationIfDue`/`UNexusConfigAsset::OnPostEditUndo`
hooks rather than inventing a second, parallel lifecycle.

## Reuse, never spawn/destroy per frame

`Slots` grows lazily (spawn only when no free slot exists and the pool is below
`MaxActiveEditorProxies`) and never shrinks except on full world teardown. An object
leaving interaction range unbinds/hides its slot's Actor and returns it to the free
list - it is never `Destroy()`'d just because the bound object changed:

```
Proxy #7 currently represents Activation Point A
A leaves interaction range -> Proxy #7: unbind A, hide, disable interaction, return to free pool
Activation Point B becomes nearby -> Proxy #7: bind B, update transform/label, show, selectable
```

When the pool is full and a new nearby candidate needs a slot: prefer an existing free
slot, then lazy-grow (if under `MaxActiveEditorProxies`), then evict the farthest-from-
camera currently-bound **unpinned** slot - a pinned/selected proxy is never a candidate
for eviction (see "Pinning" below). A one-slot-beyond-max reservation exists only as a
defensive last resort for pinning a brand-new target before the next nearby-ranking pass
accounts for it; normal nearby-ranking already reserves room for an active pin ahead of
time.

## Spatial query (Phase 47 reuse)

`FNexusEditorProxyPool::RebuildSpatialIndex` feeds `FNexusSpatialGridIndex` (Phase 47,
unchanged) real, resolved world positions - every `UNexusConfigAsset::ActivationPoint`
whose owning Debug category has `IsSelectable`, that `IsEnabled`, and that's currently
drawn (`IsVisible` or `DebugOverride.IsAlwaysDraw`) - through the exact base sub-point key
(`FieldName=NAME_None`) `FNexusActivationSubPointResolver::EnumerateResolvedSubPoints`
already resolves for the renderer. **Never synthetic/benchmark data** - this is the same
gating `UNexusActivationGizmoTool`'s own click-test already established, applied to real,
persisted data only.

Rebuilt on the exact same dirty/throttle cadence `UNexusFrameworkSubsystem::
RefreshRepresentationIfDue` already refreshes `RenderSnapshot` on - never a second,
independent poll, never per-frame.

`TickUpdateNearbyProxies` (called every `Tick`, internally throttled to a movement-delta/
time gate - not a full spatial query every frame) resolves the active Level Editor
viewport camera (`GCurrentLevelEditingViewportClient`, guarded against PIE via
`GEditor->PlayWorld`), queries `ProxyReleaseDistance`, ranks candidates closest-first, and
reconciles bindings against the current `MaxActiveEditorProxies` cap.

## Pinning

The currently UE-selected (or Hierarchy-double-click-activated) Nexus object's id is
tracked as `PinnedActivationPointId`. It is:

- always included in the "desired" binding set regardless of camera distance,
- excluded from every eviction pass, and
- excluded from the normal camera-distance release check (an out-of-range but still-
  selected proxy stays bound until the user deselects it, selects something else, or the
  map changes).

This is what lets a user select an object, walk the camera away to inspect something
else, and still find their selection intact and editable on return.

## Native UE selection is authoritative

`FNexusEditorProxyPool` binds to `USelection::SelectionChangedEvent` (the standard "actor
selection set changed" delegate). Selecting a proxy Actor sets `PinnedActivationPointId`
and publishes a `HierarchyEntity`/`ActivationPoint` target to `UNexusFrameworkSubsystem::
SetDetailsTarget` (the existing, mode-independent Hierarchy/Details selection bridge -
[07-v6-ui-design.md](07-v6-ui-design.md)/`NexusPanelSharedTypes.h`), so Hierarchy/Details
update exactly as if the user had clicked the tree row. Selecting anything else (a
different Actor, or nothing) clears `PinnedActivationPointId` and, **only if** the
Details tab is currently showing that same proxy-driven ActivationPoint selection, clears
it - a State/City/Highway/HighwayPoint/DebugCategory selection made from the Hierarchy
tree (none of which have a proxy) is never touched by viewport Actor selection.

A single reentrancy bool (`bIsSyncingSelection`, `TGuardValue`-scoped around every call
this class itself makes into `GEditor`'s selection API) prevents the resulting
`SelectionChangedEvent` broadcast from being mistaken for a second, independent user
action.

## Hierarchy TreeView double-click

Single-click keeps its existing lightweight behavior (select the tree row, populate
Details, optional viewport focus - unchanged). Double-clicking an `ActivationPoint` row
(`SNexusHierarchyPanel::OnTreeItemDoubleClicked`) performs full native activation even if
the target is currently outside normal interaction range:

```
Tree double-click -> HandleFocusItem (camera jump, unchanged)
                   -> FNexusEditorProxyPool::EnsureProxyAndSelect(id)
                        -> resolve/acquire/bind a proxy (pinning it)
                        -> GEditor->SelectActor(proxy, true, true)
                   -> native UE transform widget appears
```

## Write-back and undo

`ANexusEditorProxyActor::PostEditMove(bool isFinished)` - the standard viewport-gizmo-
drag hook - calls `FNexusEditorProxyPool::NotifyProxyMoved`, which inverts the proxy's
current world transform against its cached `AnchorWorldTransform` (`NewOffset =
NewWorldTransform * Inverse(Anchor)`, the same formula `UNexusActivationGizmoTool`
already used) and writes it back via `FNexusActivationSubPointResolver::
SetSubPointOffset` on the base sub-point key.

**One undo transaction per drag, never one per callback.** The native Level Editor's own
"Move/Rotate Actor" transaction is already open for the whole drag by the time
`PostEditMove` fires (`TrackingStarted`/`TrackingStopped` bracket it; `PostEditMove(false)`
fires many times mid-drag, once more with `isFinished=true` before the transaction
closes) - `NotifyProxyMoved` therefore calls `UNexusConfigAsset::Modify()` and relies on
that ambient transaction, deliberately opening **no** `FScopedTransaction` of its own.
`Modify()` is idempotent per object per transaction (this codebase's established
precedent, `SNexusDetailsPanel.cpp`), so the repeated calls across one drag collapse into
exactly one undo step. Ctrl+Z/Ctrl+Y bypasses `PostEditMove` entirely (the transaction
system rewrites the struct directly) - `FNexusEditorProxyPool::HandlePostEditUndo`, bound
to the existing `UNexusConfigAsset::OnPostEditUndo` delegate (the same one
`SNexusHierarchyPanel`/`SNexusDetailsPanel` already use), re-pushes every currently-bound
proxy's transform from its (possibly just-reverted) offset.

Deliberately does **not** call `MarkRepresentationDirty()` - an ActivationPoint offset
edit never affects Landscape/Highway/HighwayPoint geometry (the same exclusion
`SNexusDetailsPanel.cpp`'s own ActivationPoint edit path already applies), and the Debug
renderer already re-reads the live offset every frame, so the wireframe follows the drag
without any cache invalidation.

## Avoiding feedback loops

`IsProgrammaticTransformUpdate` is set true for the duration of every pool-driven
`SetActorTransform` call (initial bind, periodic anchor-follow refresh, post-undo
resync). `PostEditMove` checks it and returns immediately when set, so a programmatic
transform push can never be mistaken for a user drag and looped back into another
`Modify()`/write-back call.

## Mode gating (Select Mode only)

Reuses [13-v6-gizmo-system.md](13-v6-gizmo-system.md)'s existing mode-gate call site
(`FNexusLandscapeModeExtension::RefreshNexusInteractionState`, renamed from
`RefreshGizmoActiveState` - same `IsDefaultModeActive()` check, same "recomputed on every
`OnEditorModeIDChanged`" pattern, not a second mechanism) to also drive
`FNexusEditorProxyPool::SetInteractionEnabled`. Leaving Select Mode hides/deselects every
non-pinned bound proxy without destroying the pool; a pinned selection is left alone
(consistent with the custom gizmo's own "selection survives the mode switch" precedent).
Returning to Select Mode immediately re-ensures/re-selects whatever is still pinned.

## World/map/PIE lifecycle

- `FEditorDelegates::MapChange` and `FWorldDelegates::OnWorldCleanup` (filtered to the
  world the pool is currently bound to) both trigger a full teardown
  (`ReleaseAllForWorldTeardown` - every spawned Actor `Destroy()`'d, every slot cleared,
  `PinnedActivationPointId` invalidated) - the next `TickUpdateNearbyProxies`/
  `EnsureProxyAndSelect` call transparently rebuilds against whichever editor world turns
  out to be current.
- `TickUpdateNearbyProxies` refuses to run while `GEditor->PlayWorld` is set (PIE active)
  or while the focused viewport isn't a perspective Level Editor viewport - editor-world
  proxies are never referenced by (or updated from) a PIE world.
- `FEditorDelegates::BeginPIE` additionally, proactively releases non-pinned bound
  proxies as a visual tidy-up (belt-and-suspenders, not load-bearing correctness given
  the guard above).

## Configurable settings

`UNexusEditorInteractionSettings` (`Public/Settings/NexusEditorInteractionSettings.h`, a
`UDeveloperSettings`, Project Settings > Plugins > Nexus Framework (Editor Interaction)) -
the one place these numbers live:

| Setting | Default | Meaning |
|---|---|---|
| `ProxyActivationDistance` | 2000 cm | Documented reference distance ("near the camera") |
| `ProxyReleaseDistance` | 3000 cm | Actual query/release radius - deliberately larger than activation distance (hysteresis, prevents flicker) |
| `MaxActiveEditorProxies` | 100 | Hard cap on simultaneously bound proxies |
| `ProxyIconScreenSize` | 0.025 | `UBillboardComponent::ScreenSize` |

## Safety properties (verified by grep, 2026-08-11)

- The only `SpawnActor<ANexusEditorProxyActor>` call site is `FNexusEditorProxyPool::
  SpawnProxyActor`, reached only from lazy pool growth (`AcquireSlotFor`) - never once
  per frame, never once per camera movement.
- The only `Destroy()` call site is `ReleaseAllForWorldTeardown` (world switch/plugin
  shutdown) - an object leaving interaction range unbinds/hides, it is never destroyed.
- Every currently-selected/pinned proxy is excluded from both the "candidates competing
  for a slot" ranking and the "farthest evictable" pass, confirmed at every call site
  that checks `PinnedActivationPointId`.
- `RunAutomaticEnableFlow`/`MarkRepresentationDirty` are never called from this feature's
  write-back path - an offset edit stays outside the sync-policy rework's scope exactly
  as the existing ActivationPoint-editing precedent already established (see
  [04-v6-architecture.md](04-v6-architecture.md)'s Revision section on the 2026-08-11
  sync-policy change).
- No `DrawDebug*`/`ULineBatchComponent` calls anywhere in this feature - PDI rendering is
  completely untouched.

## References

- [04-v6-architecture.md](04-v6-architecture.md)
- [06-v6-debug-system.md](06-v6-debug-system.md)
- [12-v6-activation-point-system.md](12-v6-activation-point-system.md)
- [13-v6-gizmo-system.md](13-v6-gizmo-system.md)
- `ai-change-audits/2026-08-11/feature-add/editor-proxy-actor-pool-near-camera-interaction.md`
