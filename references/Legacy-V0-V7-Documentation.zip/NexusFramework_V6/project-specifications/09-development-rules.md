# 09 — Development Rules

Process rules for how V6 is planned, documented, and implemented. Distinct from
`04-v6-architecture.md` (what V6 *is*) — this is how work on it proceeds. Also distinct
from [AGENT-RULES.md](AGENT-RULES.md) — that file holds standing behavioral policy
boundaries (e.g. the Agent Testing Policy) every agent reads before starting work; this
file covers the process *within* those boundaries.

## Documentation location & phase file rules

All V6 project specification and development planning documents live in
`NexusFramework_V6/project-specifications/` — the single source of truth for V6
architecture and development specifications. See [README.md](README.md) for the index.

**Phase file rules:**

1. Every development phase has its own `.md` file under `phases/`.
2. Never combine multiple phases into one file.
3. Roughly 100 phase files, `phase-00.md` through `phase-99.md` — plus rare, deliberate
   3-digit exceptions (e.g. `phase-100-verification-and-publish-gate.md`, added
   2026-08-09) for a system that only makes sense once everything else in the 00–99 arc
   exists to apply to. Not a pattern to reach for casually — the roadmap's own
   completeness review (`v6-phase-verification.md`) should already catch anything that
   belongs *inside* 00–99 instead. Tooling (`html-docs/build.js`/`server.js`) parses
   `\d{2,3}` specifically to support this, not unlimited digits — keep exceptions to
   double-then-triple digits, don't jump straight to 4.
4. Each phase file has a maximum of 10-15 actionable points.
5. Keep phase files short, clear, and implementation-oriented — no long explanations.
6. Detailed architecture explanations belong in the numbered spec documents (`04`–`14`),
   not in phase files.
7. Each phase defines its own objective and completion criteria.
8. Each phase states what is allowed and what is NOT allowed in that phase.
9. Each phase references relevant V6 systems/files without duplicating their
   documentation.
10. A completed phase records its completion status/date/time.
11. If a phase changes later, update that phase's file — never create a duplicate
    version of it.
12. **Status vocabulary**: every phase's `## Status` section is a **fixed-line block**
    (2026-08-10 refactor — replaced the original single free-form-sentence format so a
    phase's stage-transition dates stop being overwritten as it advances, and so
    `build.js`/`server.js` can read it by fixed line/pattern instead of each keeping its
    own paragraph-scraping regex; see `html-docs/build.js`'s `parseStatusBlock`/
    `serializeStatusBlock`, the one shared reader/writer both scripts now use), not a
    free-form sentence:

    ```
    ## Status

    <Stage>
    Ready for Review: <date+time, or blank>
    In Review: <date+time, or blank>
    Ready for QA: <date+time, or blank>
    Complete: <date+time, or blank>

    <optional free-form notes paragraph(s) — untouched by any status change>
    ```

    `<Stage>` (line 1 of the block) is exactly one of the seven values below, in this
    order (no skipping backward except an explicit unblock/reopen). The four lines below
    it are fixed fields, always present in that exact order even when blank — one gets
    stamped with `YYYY-MM-DD HH:MM TZID (+HHMM)` (include the time and timezone, not just
    the date, so same-day transitions stay distinguishable) the moment a phase **first**
    reaches that stage, and is never overwritten or cleared by a later transition — a
    phase's full stage history accumulates permanently instead of each transition erasing
    the previous one's date. `Not started`/`In progress`/`Blocked` have no dedicated
    field of their own (not part of the four dated stages) — only `<Stage>` itself
    records which of those three a phase is currently in.

    | Status | Meaning | Who may set it |
    |---|---|---|
    | `Not started` | Default; no work begun. | agent (direct file edit only — see below) |
    | `Blocked` | Work started but stuck on an external dependency/decision — note why. | agent or user |
    | `In progress` | An agent is actively implementing this phase. | agent (direct file edit only — see below) |
    | `Ready for Review` | Agent's implementation + build verification is done; awaiting **human** code review. | agent |
    | `In Review` | The user is actively code-reviewing this phase right now (2026-08-10 addition — distinguishes "someone is looking at this" from "still queued"). | **user only** |
    | `Ready for QA` | Code review passed; awaiting **human** QA/testing pass. | **user only** |
    | `Complete` | QA passed; phase closed. | **user only** |

    An agent (via `/TODO` or otherwise) may move a phase as far as `Ready for Review`
    and no further — mirrors `agent-todos/AGENT-TODO-RULES.md`'s rule that only the user
    moves a task into `ready-for-qa/`/`closed/`. This applies whether the status is
    edited by hand or via `html-docs/server.js`'s API (see `html-docs/README.md`) — an
    agent must not call that API to advance a phase past `Ready for Review` on its own
    initiative, same restriction either way — this includes `In Review`, which sits past
    that boundary same as `Ready for QA`/`Complete`. This half of the rule (agent stops
    at `Ready for Review`) is a **documented convention, not technically enforced** by
    the server — same trust boundary `AGENT-TODO-RULES.md` already relies on.

    The other half **is** technically enforced: `Not started` and `In progress` can only
    be set by editing a phase file directly (or letting `/TODO` do so) — both the
    phase-tracker's dropdown (rendered disabled) and `server.js`'s API (rejects the
    request) refuse to set either one, since neither means anything as a browser click.
    `server.js` watches `project-specifications/phases/` for direct edits and
    auto-rebuilds on any change, so a status set this way still shows up in the tracker
    (which polls every few seconds) without anyone needing to run `node build.js`
    by hand. This also covers the reverse direction: a phase **currently** `Not started`
    or `In progress` is itself agent-owned state, so the whole dropdown/API is refused
    for it too, not just those two values as a target — otherwise a human could jump a
    phase straight from `Not started` to `Ready for QA`/`Complete` from the browser,
    skipping the agent's own `Ready for Review` step entirely (a real regression,
    fixed 2026-08-09 — see `ai-change-audits/2026-08-09/bug-fixed/phase-tracker-status-ui-broken.md`).

    Also technically enforced: once a phase has been `Complete` for **more than an
    hour** (measured from the timestamp already in its own `Complete:` field), it is
    locked from further status changes — both `server.js`'s API and the tracker's
    dropdown refuse to touch it, protecting a finalized record from being casually
    changed long after the fact. Within that first hour it's still changeable, e.g. to
    undo a mis-click.

    **Every status write triggers a real docs-site rebuild** (`server.js` runs
    `build.js` synchronously after each one). When verifying the status system itself
    (its API, its lock rules, its UI), prefer reading the code over live round-trip
    testing against real phase files — an agent should not toggle a phase's status back
    and forth as a way of "testing," costing a rebuild each time. Where a live check is
    genuinely the only way to confirm something, keep it to the minimum number of
    round trips and don't repeat one that already passed.

    **An agent working a phase writes `## Status` exactly once, at the end — never
    `In progress` as a routine start-of-work marker** (2026-08-09, user-requested; see
    `.claude/commands/TODO.md` Step B for the actual workflow this governs). The user
    tracks what's actively being worked on themselves; a write that will just be
    overwritten minutes later by the completion write is a wasted rebuild for no
    reader's benefit. `Blocked` is the one exception — genuinely getting stuck on an
    external dependency/decision is a real state change worth recording immediately,
    not a routine marker.

    This vocabulary is machine-parseable — `PHASE-STATUS.md` and
    `html-docs/js/phase-data.js` are both regenerated from these lines (see
    `PHASE-STATUS.md`'s own header for the regeneration procedure). The phase's own
    `## Status` field is always the authoritative source; both generated files (and the
    phase-tracker's dropdown) are read-only reflections of it — if they ever disagree,
    the phase file is right and the generated file is stale, re-run
    `node html-docs/build.js` (or use `html-docs/server.js`, which does this
    automatically on every status change).

**Documentation separation** — keep these responsibilities separate:

- `project-specifications/` → architecture, design, requirements, roadmap, phases,
  technical specifications.
- `.claude/` (this repo's own, git-tracked copy) → Claude rules, skills, commands, TODO
  workflow config, agent operational instructions — **tooling configuration only, never
  memory or project history** (see `CLAUDE.md` rule 1). Durable memory belongs in
  `ai-change-audits/` instead, or here in `project-specifications/` for process rules
  like this one. Never mix `.claude` operational files with V6 architecture spec files.
- **Never** a Claude Code agent's own global/external memory
  (`C:/Users/<user>/.claude/...` or equivalent on another OS) — that directory is
  per-machine, per-user, and outside this git repo entirely, so on a multi-developer,
  multi-PC project like this one it is invisible to every other developer and every
  other machine, and gone forever if that one PC's data is lost. An agent that saves a
  durable finding there instead of in `ai-change-audits/` has silently made it
  unrecoverable for everyone else — this happened once already (2026-08-09, see
  `ai-change-audits/2026-08-09/others/agent-memory-must-stay-in-repo.md`) and must not
  happen again.
- Source code → the actual V6 implementation.

**Critical rule**: before creating any V6 implementation code, the specification
structure must exist. The documentation is part of the V6 development system, not
temporary notes. Every important architectural decision has a clear home inside
`project-specifications/`.

## Source file organization (.cpp splitting by responsibility)

Added 2026-08-09, user-requested, applies proactively to all future phases:

If a `.cpp` file becomes large or is expected to grow significantly, split its
implementation across multiple `.cpp` files by responsibility while keeping a single `.h`
defining the class/interface. Example — `NexusFrameworkPanel.h` implemented across:

- `NexusFrameworkPanel.Widget.cpp`
- `NexusFrameworkPanel.Landscape.cpp`
- `NexusFrameworkPanel.Actor.cpp`
- `NexusFrameworkPanel.Debug.cpp`

Rules:

1. One `.h` defines the class/interface — never split the declaration itself.
2. Multiple `.cpp` files may implement the same class (member functions defined
   out-of-line in whichever file matches their responsibility).
3. Group related functionality together in the same `.cpp` — split by responsibility
   boundary, not by arbitrary size/line-count alone.
4. Do not split arbitrarily or pre-emptively — a small, focused `.cpp` stays as one
   file; this rule triggers once a file is genuinely large or clearly growing toward
   covering multiple distinct responsibilities.
5. Avoid duplicate function definitions across the split files (each member function
   defined in exactly one of them).
6. This is an implementation-organization rule only — it does not change class
   architecture, public interfaces, or runtime behavior of existing code.

## Adapted from V5 (see 03-v5-problems-and-lessons.md for why)

- **Durable project memory lives in the repo, not in agent-local/global memory.**
  V5 kept an append-only `ai-change-audits/` history precisely so any fresh session
  could self-orient without re-deriving or contradicting past decisions. V6 should
  decide its own equivalent (this `project-specifications/` tree plus a decision-log
  convention, e.g. dated entries in `04-v6-architecture.md` or a dedicated log) rather
  than relying on chat history.
- **Explicit task-workflow state, separate from architecture docs.** V5's
  `agent-todos/` (queued → active → review → QA → closed) is a different concern from
  "what is true about the system" — worth a V6 equivalent once implementation starts,
  kept out of `project-specifications/` per the separation rule above.
- **Investigate before implementing; never assume a reported cause is correct.** Read
  the actual current code/state before changing it, especially for anything touching a
  previously-identified crash-sensitive area.
- **Ambiguous requirements get a clarifying question, not a guess**, especially before
  large or hard-to-reverse implementation work — cheaper than redoing it.
- **Build and verify before calling work done.** Compile with 0 errors at minimum;
  note explicitly when a change hasn't been manually tested in-editor yet rather than
  implying it has.
- **Crash-sensitive subsystems get a standing "don't change without explicit approval"
  note directly in the code/docs**, once identified — not just remembered informally.

## Open questions

Both resolved 2026-08-09, mirroring V5's proven systems exactly (see
`03-v5-problems-and-lessons.md` for why V5 built them this way):

- **Persistent-memory/decision-log convention** → `NexusFramework_V6/ai-change-audits/`,
  rules in `NexusFramework_V6/CLAUDE.md` (append-only, dated-folder-then-category
  structure, same as V5's). Nothing has been logged there yet — no implementation has
  happened yet to have findings about.
- **Task-workflow system** → `NexusFramework_V6/agent-todos/` for work that isn't a
  whole roadmap phase (a bug found mid-phase, a small ad-hoc ask) — rules in
  `agent-todos/AGENT-TODO-RULES.md`. **Roadmap phases themselves do NOT use this
  folder-move system** — a phase's identity is its fixed, numbered, cross-referenced
  file path (`phases/phase-NN*.md`), so its state lives in that same file's `## Status`
  line (rule 12 above) instead of being moved between folders. `agent-todos/` and
  `phases/` are complementary, not duplicate systems — check both when picking up work.
