# 15 — V6 Verification System

## Status

**Drafted — 2026-08-09.** Added after Phase 01 shipped, in response to a direct request:
before a dynamically generated map ships, someone needs to be able to see *everything*
V6 generated — every State/City/Highway and every Static/Activation object placed under
them (Parking, Bus Stop, Traffic Light, ...) — as one browsable tree, visually confirm
each one in the viewport, and record that confirmation, before the map is allowed to be
called "ready to publish." Implemented starting at [Phase 100](phases/phase-100-verification-and-publish-gate.md).

## Why this is a separate system, not more Debug Architecture

[06-v6-debug-system.md](06-v6-debug-system.md) (Phases 23–35) already gives V6 a
category **registry + renderer + config** tree — but that tree is organized by
*rendering concern* (Landscape / Roads / Infrastructure / Runtime / Mapping /
Diagnostics), and its per-leaf state (`FNexusDebugRenderConfig`) is about how a category
draws, not whether a human has looked at and approved a specific instance. This system
needs a tree organized by the **content hierarchy** instead (State → City → Highway →
the objects placed on/under it), with **new, per-instance** state that has never existed
before: has a human looked at *this specific* Parking lot / Bus Stop / Traffic Light and
confirmed it's actually correct.

This is deliberately a thin layer on top of what Phases 23–35 and 27 already build, not
a parallel reimplementation:

- **Tree widget mechanics** (expand/collapse, filtering, Slate list construction) reuse
  the same patterns [Phase 24](phases/phase-24.md) establishes for the Debug Tree — a
  different data source, the same widget approach.
- **Click-to-focus** (select the entity, frame the viewport camera on it) is not
  reimplemented here — it's the same mechanism [Phase 27](phases/phase-27.md) already
  builds for the Diagnostics panel's "click-to-focus the offending entity." This system
  is a second consumer of that mechanism, not a second implementation of it.
- **What's genuinely new**: the content-hierarchy tree source itself, and a persisted,
  per-instance verification-state record (below).

## Data model: `FNexusVerificationStatus`

One record per verifiable instance (every `FNexusState`/`FNexusCity`/`FNexusHighway`, and
every Static/Activation object placed under a Highway/HighwayPoint — see
[11](11-v6-static-dynamic-architecture.md)/[12](12-v6-activation-point-system.md)),
keyed by that instance's own `FGuid` (never by array position or tree row index, same
rule as every other Nexus identity — see [05](05-v6-data-flow.md)):

```
FNexusVerificationStatus
{
    TargetId              (FGuid — the State/City/Highway/.../ActivationPoint this
                            record belongs to; the record does not exist until the
                            first time someone opens that item in the tree)
    Checks                (TArray<FNexusVerificationCheckItem> — see below)
    bAllChecked            (derived: true only when every Checks entry is true)
    LastReviewedUtc        (FDateTime, set whenever any Checks entry is toggled)
    LastReviewedBy         (FString — OS username via FPlatformProcess, best-effort
                            "who" for a multi-developer project; not an auth system)
}

FNexusVerificationCheckItem
{
    CheckId       (FName — stable key, e.g. "UIPlacement", "SmokeTest", "Overall")
    Label          (FString — display text)
    bChecked        (bool)
}
```

**The starting checklist is intentionally provisional** — explicitly requested as a demo
of the general idea, not a locked spec:

```
[ ] UI Placement Correct
[ ] Smoke Test Complete
[ ] Overall Test Complete
```

`Checks` is a plain array, not hardcoded fields, specifically so this list can grow or
change per object type later without a struct-shape migration — adding a fourth check
(or a type-specific one, e.g. a Bus Stop getting a "Passenger waypoints reachable"
check) is a data change, not a code change, once Phase 100 lands the array-based shape.

## Persistence

Lives in the same `[LandscapeId]_nexusconfig` Data Asset every other per-Landscape Nexus
state already lives in (see [04](04-v6-architecture.md)'s "No Load Layout" section) —
keyed by `TargetId`, so it survives editor restarts and travels with the map the same way
Mapping/Representation data does. Not a separate asset, not per-user local state: on a
multi-developer project, whoever last verified an instance is what everyone else sees.

## The publish gate

A dynamically generated map's Runtime Compiler export (Phases 80–85,
[10-v6-runtime-schema.md](10-v6-runtime-schema.md)) checks `bAllChecked` across every
`FNexusVerificationStatus` record for every instance currently in the Representation
graph before producing a final Runtime Schema asset intended to ship — same
"stage validates its own output before the next stage may consume it" rule
[04-v6-architecture.md](04-v6-architecture.md) already establishes, with a human
sign-off as this stage's validation instead of an automated rule. An instance with no
record at all (never opened in the tree) counts as unverified, same as one with an
unchecked box — silence is not approval.

This is a **separate concern from [14-v6-validation.md](14-v6-validation.md)'s automated
gates and [Phase 99](phases/phase-99-final-validation.md)'s pipeline sign-off** — 14/99
catch structural problems (broken references, invalid geometry); this system catches
"technically valid but actually wrong" problems only a human looking at the viewport can
catch (a Bus Stop facing into a wall, a Parking space overlapping a building). Both
gates apply; neither substitutes for the other.

## References

- [06-v6-debug-system.md](06-v6-debug-system.md)
- [phases/phase-24.md](phases/phase-24.md) (tree widget mechanics reused)
- [phases/phase-27.md](phases/phase-27.md) (click-to-focus mechanism reused)
- [10-v6-runtime-schema.md](10-v6-runtime-schema.md)
- [14-v6-validation.md](14-v6-validation.md)
- [phases/phase-100-verification-and-publish-gate.md](phases/phase-100-verification-and-publish-gate.md)
