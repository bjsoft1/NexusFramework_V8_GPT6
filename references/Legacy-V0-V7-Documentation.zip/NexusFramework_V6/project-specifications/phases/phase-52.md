# Phase 52 — Traffic Light — Signal Group Data

## Status

Ready for Review
Ready for Review: 2026-08-12 02:15 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Add SignalGroup to the Traffic Light struct so multiple Traffic Lights at one junction can be coordinated at runtime.

## Allowed

- Implement SignalGroup field and grouping query (all Traffic Lights sharing a group).
- Build a UI affordance for assigning/viewing a group at a junction.
- Verify a multi-light test junction groups correctly.
- Document the runtime coordination contract this data enables (actual coordination logic is a runtime-module concern, out of scope here).

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

- [ ] Multi-light junction test proves correct grouping. Per
      `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
      the agent this session (build-only verification) - left unchecked. **To check**: see
      "Manual verification required" below.
- [x] Runtime coordination contract documented, not implemented (explicitly out of scope
      this phase). See `12-v6-activation-point-system.md`'s new "Traffic Light Signal
      Group runtime coordination contract" section - a documentation deliverable directly
      confirmable by reading it, not an in-editor behavior needing manual QA.

## Implementation (2026-08-12)

- `FNexusTrafficLightActivation::SignalGroup` (new, `Public/Representation/
  NexusTrafficLightActivation.h`) - plain `FName`, blank (`NAME_None`) = standalone/
  ungrouped, same blank-sentinel convention as `FNexusActivationPoint::Type`/`Code`. An
  `FName` rather than an `FGuid` deliberately - unlike `ControlledLaneIds`/
  `ControlledRoadIds` (Phase 51), a signal group has no single owning entity/registry;
  it only ever exists implicitly as two or more lights sharing the same hand-typed label.
- `FNexusTrafficLightActivation::FindActivationPointsInSignalGroup` (new, static) - the
  grouping query, taking a caller-resolved `TArrayView<const FNexusTrafficLightInstanceRef>`
  (a new small `{ActivationPointId, Payload}` struct, storage-agnostic - today's only real
  source is the session-only test store, matching Phase 51's own `ValidateControlledReferences`
  "caller resolves the data" split).
- Two new console commands (`NexusTrafficLightActivationRegistration.cpp`):
  `Nexus.Representation.SetTrafficLightSignalGroup <ActivationPointId> <SignalGroupName>`
  (console-scriptable equivalent of the Details-panel edit, for scripting a multi-light
  test setup end-to-end) and
  `Nexus.Representation.FindTrafficLightsInSignalGroup <SignalGroupName>` (runs the
  grouping query against every known test Traffic Light and logs matches - the "viewing a
  group at a junction" half of this phase's own UI-affordance ask).
- **"Assigning" a group needed zero new UI code** - `SignalGroup` is a plain `UPROPERTY`
  on the payload struct, so it is already Details-panel-editable the moment a sub-point
  is selected, via Phase 51's `ENexusDetailsTargetMode::TestActivationPointPayload`
  binding (registry-driven, not Traffic-Light-specific) - exactly the "zero-edit
  extensibility" payoff that mechanism's own audit record predicted for a future type's
  own payload fields, now realized one phase later for this same type.
- `12-v6-activation-point-system.md` - new "Traffic Light Signal Group runtime
  coordination contract" section: documents the DATA-ONLY contract (two-plus instances
  sharing a non-blank `SignalGroup` are declared one coordinated intersection, the actual
  phase/state-machine timing belongs to the Phase 86-89 runtime module or a future
  dedicated Traffic Light runtime controller, not the Editor plugin) and flags candidate
  Phase 55 validation checks (a single-member group, cross-member `ControlledLaneIds`
  conflicts) as an open question for that future phase, not decided here.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. `Nexus.Representation.AddTestTrafficLight <HighwayPointId1> 1` and
   `Nexus.Representation.AddTestTrafficLight <HighwayPointId2> 1` (two different
   HighwayPointIds at or near the same junction) - note both `ActivationPointId`s.
2. `Nexus.Representation.SetTrafficLightSignalGroup <ActivationPointId1> Junction_A` and
   the same for `<ActivationPointId2>`.
3. `Nexus.Representation.FindTrafficLightsInSignalGroup Junction_A` - confirm the log
   lists BOTH `ActivationPointId`s.
4. Select 'Select Mode', click one of the two Traffic Lights' sub-points - confirm the
   Details panel shows `SignalGroup = Junction_A` (editable there directly, e.g. rename
   it and re-run step 3 to confirm the query reflects the live edit).
5. `Nexus.Representation.FindTrafficLightsInSignalGroup SomeOtherGroup` - confirm zero
   matches (proves the query doesn't over-match).

## References

- `project-specifications/12-v6-activation-point-system.md`
