# Phase 79 — Gizmo — Full Category Rollout Verification

## Status

Ready for Review
Ready for Review: 2026-08-22 17:36 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Verify every gizmo-enabled Debug category (per Phase 25's bSupportsGizmo config) across the full object-type set (50-75) works end-to-end, closing this stage before Runtime Schema work begins.

## Allowed

- Enumerate every category with bSupportsGizmo = true.
- Run a select/edit/undo/redo/re-render cycle for each.
- **(2026-08-10)** For every category whose type has a dynamic-array sub-point
  (Crosswalk's `WaitingPoints[]`, Bus Stop's `PassengerWaitingPoints[]`/
  `SeatInteractionPoints[]`), test on an instance with N>=3 array elements
  specifically, and verify editing element `i` never moves element `i-1`, `i+1`, or the
  shared anchor - this is a distinct test from "the category works," per
  13-v6-gizmo-system.md's "Sub-point addressing" section, and must not be satisfied by
  a single-element test case.
- Record pass/fail per category (and per sub-point-key shape: fixed vs. array).
- Fix any failure found before proceeding to Phase 80.

## Not Allowed

- Do not let a gizmo edit write to Landscape/`ULandscapeSplineControlPoint` transforms.
- Do not bypass FScopedTransaction/Modify() for gizmo-driven edits (undo/redo must work).
- Do not implement scale handling - offsets are not scaled objects (see 13).

## Completion Criteria

- [ ] 100% pass rate across every gizmo-enabled category, or documented, escalated exceptions.

## References

- `project-specifications/13-v6-gizmo-system.md`

## Enumeration result (agent, 2026-08-22)

**Gizmo-enabled categories: exactly ONE.** `CanSupportGizmo = true` is set in a single
place in the whole codebase — `Runtime.ActivationPoints`
(`NexusDebugRuntimeGroupRenderers.cpp`). Every one of the 14 registered Activation Point
types gates its selection/gizmo on that one category, so "full category rollout" is in
practice **one category × 14 types × 3 sub-point shapes**, not N independent gizmo
implementations. That is by design — 13-v6-gizmo-system.md requires one generic
mechanism, and `Nexus.Gizmo.AuditTypeConsistency` (Phase 76) reports it live.

| Type | Sub-point shape | Array fields (the N>=3 cases) |
|---|---|---|
| Advertisement | base offset only (1 synthetic key) | — |
| Tv | base offset only | — |
| Seat | base offset only | — |
| Parking | base offset only | — |
| CityLight | 1 fixed | — |
| TrafficLight | 3 fixed | — |
| Crosswalk | 2 fixed + 1 array | `PedestrianWaitingPoints` |
| BusStop | 3 fixed + 2 arrays | `PassengerWaitingPoints`, `SeatInteractionPoints` |
| Hospital | 2 fixed + 1 array | `AmbulanceBayPoints` |
| PoliceStation | 1 fixed + 1 array | `PatrolVehicleBayPoints` |
| PetrolStation | 2 fixed + 1 array | `FuelPumpPoints` |
| ChargingStation | 2 fixed + 1 array | `ChargingBayPoints` |
| ServiceGarage | 2 fixed + 1 array | `ServiceBayPoints` |
| Dummy.BaseOnly / Dummy.Array | base-only / 1 fixed + 1 array | `ArrayPoints` |

Note: 13-v6-gizmo-system.md calls Crosswalk's array `WaitingPoints[]`; the implemented
field is `PedestrianWaitingPoints`. Doc/code drift only — **not** renamed, because
renaming a `UPROPERTY` risks silently corrupting saved `.uasset` content
(v6-coding-standard.md's "Serialization risk" section).

## Defects found and fixed (agent, 2026-08-22)

Three real defects, all found by static audit of the sub-point addressing path. Build
verified after each.

1. **Real, persisted Activation Points rendered base-only** — every authored sub-point
   invisible. `RenderActivationPoints` passed `nullptr` as the payload for the real-config
   loop while passing the point's own payload for the test-store loop, so
   `EnumerateResolvedSubPoints` fell back to the single base key for real data. The
   `nullptr` was correct when written, but the 2026-08-22 payload-persistence work moved
   the payload onto the point and updated the **gizmo's** hit-test without updating this
   **renderer** — leaving real points hit-testable but invisible, the exact inverse of the
   "clickable must never diverge from visible" invariant `IsGizmoSelectable` states.
   Fixed by removing the payload parameter entirely and resolving through the same
   point-only overload the gizmo uses, so the two cannot drift apart again.
   *This one would have made a manual Phase 79 pass on real data fail outright.*

2. **Both dummy types were silently non-selectable.** Their `DefaultDebugCategory` was
   `"Runtime.Dummy"` — a category that is never registered anywhere, so
   `GetRuntimeConfig()` returned null and `IsGizmoSelectable` rejected them. This disabled
   `Dummy.Array`, whose stated purpose is "proving Gizmo array sub-point selection/drag."
   They were still drawn (under `Runtime.ActivationPoints`, which ignores type), so they
   were visible-but-unclickable — same invariant broken, opposite direction. Repointed to
   the category that actually governs their visibility.

3. **Array element type was never validated before `reinterpret_cast`.** The resolver's
   fixed-field branch checks `structProperty->Struct`, but the array branch cast a raw
   element pointer to `FNexusSubPointOffset*` unchecked. A key naming a `TArray` of any
   other element type would stride by the wrong size and, on write, corrupt neighbouring
   elements — precisely the "editing element i must never disturb i±1" invariant this
   phase exists to hold. Not reachable from the normal path (the key enumerator already
   filters by inner type), so this is defence-in-depth against a key arriving from
   anywhere else — a selection remembered across a payload Type change, a console command,
   a future caller. `NexusBusStopActivation.h`'s Phase 66 comment had already flagged this
   as a known sharp edge; it is now enforced rather than documented.

## Verified by static audit (agent, 2026-08-22)

- **Element independence holds by construction.** One sub-point key resolves to exactly
  one `FNexusSubPointOffset`; `SetSubPointOffset` writes through that single pointer and
  touches nothing else. Sibling elements are unreachable from a write to element `i`.
- **The shared anchor is never written by a gizmo drag.**
  `HandleGizmoTransformChanged` only *reads* the anchor transform (to invert the
  composition) — satisfying this phase's "do not let a gizmo edit write to Landscape /
  `ULandscapeSplineControlPoint` transforms" Not-Allowed rule at the code level.
- **Array-element pointers are never held across frames.**
  `FNexusGizmoSubPointSelection` carries the *key*, never a resolved pointer, so an array
  resize cannot dangle it.

## Manual verification still required from the user

Per AGENT-RULES.md's Agent Testing Policy, **no automated test was written or run and the
editor was not launched**. Everything below needs a human in Unreal Editor, and this
phase's single Completion Criterion is deliberately left **unchecked** until then.

Start here — this is the fastest check that fix (1) worked, and it was impossible before:

1. Create a **real, persisted** Crosswalk Activation Point, save, and confirm the viewport
   now draws `StartPoint`, `EndPoint` **and** each `PedestrianWaitingPoints` element —
   not a single base marker. Before this fix only one marker appeared.
2. `Nexus.Gizmo.AuditTypeConsistency` — expect 14 types, **one** gating category, and
   "CONSISTENT" on both lines (it would have reported DIVERGED before fix 2).
3. `Nexus.Representation.AddTestActivationPointArray <HighwayPointId> 4` — confirm the
   `Dummy.Array` point is now **selectable and draggable** (it was silently inert before).
4. **The N>=3 array test, which must not be satisfied by a single-element case:** on a
   Crosswalk with >=3 waiting points, drag element `i` and confirm elements `i-1`/`i+1`
   and the shared anchor do not move. Repeat on Bus Stop with **both** of its arrays.
5. Per-category select / edit / undo / redo / re-render cycle across the 14 types, and
   record pass/fail per sub-point shape (base-only, fixed, array).
6. Confirm the gizmo stays inactive in Landscape Mode and active in Select Mode.

Record the pass/fail matrix here when done. If everything passes, the Completion
Criterion below can be checked and the phase advanced — **status advancement past
`Ready for Review` is the user's call, not an agent's.**
