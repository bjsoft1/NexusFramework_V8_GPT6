# Phase 85 — Runtime Module Boundary

## Status

Ready for Review
Ready for Review: 2026-08-22 18:20 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Formalize the NexusFramework (runtime) vs NexusFrameworkEditor module boundary per 04-v6-architecture.md, auditing every struct built so far for accidental editor-only leakage. **(2026-08-10 revision)** Also formalize the separate, conceptual "Logical World Object vs. Actor" boundary from `v6-master-architecture.md` Sections 24-31 — this phase's original scope was the C++/link module boundary only; the two are related but distinct, and this phase's title/position (first in the Runtime Activation Subsystem group) makes it the natural place to state the conceptual boundary explicitly before Phase 86-89 build against it.

## Allowed

- Audit every Runtime-consumed struct (Phases 18-84) for editor-only/UObject-heavy references.
- Move any misplaced type to the correct module.
- Verify NexusFramework compiles standalone with zero Slate/UnrealEd/Landscape-Editor includes.
- Verify a packaged (non-editor) build links successfully referencing only the runtime module.
- **(2026-08-10)** Document, explicitly, the Logical World Object vs. Actor separation
  this subsystem is built around: a compiled `FNexusRuntimeResult` entry (e.g. one
  `CityLight_3812`) is data only, with zero Actor cost, until the proximity system
  (Phase 86/87) decides to bind it to a pooled Actor (Phase 88). State this as an
  explicit design contract in this phase's own doc output (not left implicit across
  86-89), so "a world may contain 100,000 logical objects while only ~500 dynamic
  actors are active" (Section 31) is a stated invariant this subsystem is verified
  against at Phase 92, not an unstated hope.

## Not Allowed

- Do not put editor-only/UObject-heavy types into runtime-consumed structs.
- Do not let the runtime module depend on NexusFrameworkEditor.
- Do not skip the Compilation-stage validation gate before an asset is allowed to save.

## Completion Criteria

- [x] Standalone runtime-module compile proven clean.
- [x] Packaged-build link test passes.
- [x] The Logical World Object vs. Actor design contract is documented explicitly
      (not left implicit for later phases to each separately assume).

## References

- `project-specifications/v6-master-architecture.md` (Sections 24-31)
- `project-specifications/04-v6-architecture.md`

## Implementation (agent, 2026-08-22)

### Module boundary - verified by build, not by inspection

`Build.bat NexusFramework Win64 Development` (the standalone GAME target, no editor module
compiled or linked at all) **compiled and linked `NexusFramework.exe` successfully.** That is
both build-verifiable criteria of this phase proven rather than asserted: the runtime module
has zero editor dependencies, and a non-editor build links referencing only it.

The dependency direction was already correct and stays that way: `NexusFrameworkEditor`
lists `NexusFramework` in `PublicDependencyModuleNames`; `NexusFramework` depends only on
`Core`/`CoreUObject`/`Engine`/`InputCore`/`EnhancedInput` and names no editor type anywhere.

**Audit finding - the one real leak risk, and how it was handled.** Two editor enums
(`ENexusGenerationClassification`, `ENexusJunctionType`) are genuinely part of the runtime
contract. Rather than move them (which changes reflected type paths that saved `.uasset`
content already references) or name them from runtime (which the boundary forbids), the
runtime module defines mirrors and the compiler `static_assert`s every enumerator against the
editor original - so the boundary holds without the mirror silently drifting. See Phase 80.

`ECategories`/`ESubCategory` were audited and deliberately NOT mirrored: the compiled point
stores the raw `int32` bitmask and `uint8` value, which carry full meaning without the enum
type. Fewer mirrors, fewer drift surfaces.

### Logical World Object vs. Actor - the design contract

Stated here explicitly, as this phase requires, so Phases 86-89 build against one written
contract rather than each separately assuming it:

> **A compiled `FNexusRuntimeResult` entry is DATA, and costs nothing but memory.**
>
> One `FNexusRuntimeActivationPoint` - `CityLight_3812`, say - is a logical world object. It
> has an identity, a world transform, a type, and payload data. It has **no `AActor`, no
> `UObject`, no tick, no component, and no rendering cost.** It exists as an element of a
> `TArray` inside a `UDataAsset`.
>
> An Actor appears only when the proximity system (Phases 86/87) decides this logical object
> is close enough to matter, and binds it to a **pooled** Actor (Phase 88). When it stops
> mattering, the Actor returns to the pool and the logical object continues to exist,
> unchanged, as data.
>
> Therefore: **the number of logical objects and the number of live Actors are independent
> quantities.** A world may hold 100,000+ logical objects while ~500 dynamic Actors are
> active (Section 31). Phase 92 verifies this as a measured invariant.
>
> **What this forbids.** No phase may spawn one Actor per compiled entry, hold an Actor
> reference on a runtime schema struct, or make a logical object's existence depend on its
> Actor existing. A runtime struct gaining an `AActor*` field is a violation of this contract,
> not an optimization - and would also break the module boundary above, since it would put an
> Engine-Actor lifetime dependency inside shipped data.

The schema is already built to honour this: nothing in `Schema/Runtime/` references an Actor,
a component, or any `UObject` beyond the `UDataAsset` wrapper itself, and asset references
are carried as `FSoftObjectPath` (paths, not loaded objects) so the runtime decides when to
load.

## Manual verification

The two build criteria above are **already proven** (both targets built this session). No
in-editor verification is required for this phase specifically.
