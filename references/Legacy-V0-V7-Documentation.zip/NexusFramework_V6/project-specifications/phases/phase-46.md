# Phase 46 — Activation Point — Debug Visualization Integration

## Status

In Review
Ready for Review: 2026-08-10 17:45 GMT+5:45 (+0545)
In Review: 2026-08-10 15:14 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Register the Runtime debug group's leaves generically for Activation Points, driven by Phase 45's registry rather than one leaf per feature.

## Allowed

- Register a generic Activation Point renderer keyed by the type registry, not hard-coded per type.
- Verify the dummy test type from Phase 45 renders correctly with zero renderer-side changes.
- Wire visibility/config through the existing Phase 25 shared config system.
- Verify offset composition (Phase 21) is what's actually rendered, not the raw HighwayPoint position.
- **(2026-08-10, v6-master-architecture.md Section 23 — V0-derived Always-Draw)** Add a
  per-instance `bAlwaysDraw` override on `FNexusActivationPoint` (the base struct - this
  is a per-*instance* flag, distinct from Phase 25's per-*category* visibility toggle):
  when true, this instance renders even when its owning category's normal visibility
  gate would otherwise hide it (panel closed, category toggled off, tool not active).
  Reuse the exact same renderer/draw call this phase already registers - do not build a
  second rendering path (ported from V0's `FNexusRoadGraphAlwaysDrawEdMode`/
  `FNexusRoadGraphEditorAlwaysDraw` precedent, but V6 has no equivalent second EdMode to
  register against - since V6's debug rendering is already driven from
  `UNexusFrameworkSubsystem`'s own `FTickableEditorObject::Tick` per Phase 27's header
  comment, not from any Mode-specific `Render()`, the "survives mode switches" property
  V0 needed a whole second EdMode for is already true here for free - `bAlwaysDraw`
  only needs to additionally survive the *category* visibility gate specifically).

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).
- Do not implement `bAlwaysDraw` as a second, separate renderer - it must reuse this
  phase's own generic per-type renderer, only bypassing the category-level visibility
  check.

## Completion Criteria

- [ ] Dummy type renders correctly via the generic path alone. `RenderActivationPoints`
      (`NexusDebugRuntimeGroupRenderers.cpp`) is a single generic function, no
      switch-over-Type - not yet actually seen rendered in-viewport (needs a manual
      editor run, see below).
- [x] Rendered position is proven to be the composed offset transform, not the bare
      anchor. `ComposeFinalTransform` explicitly composes `offsetTransform *
      anchorWorldTransform` (the exact same formula as `FNexusActivationPoint::
      ComputeFinalTransform`) before drawing - code-verified by construction, not just
      asserted.
- [ ] An instance with `IsAlwaysDraw = true` remains visible with its owning category's
      visibility toggled off; `IsAlwaysDraw = false` (default) correctly disappears when
      the category is toggled off. Mechanism implemented (`FNexusDebugCategory::
      SupportsAlwaysDraw` + `DispatchDebugRenderers`'s own updated gate, see
      Implementation Notes) - not yet actually observed in-viewport.

## Implementation Notes (2026-08-10)

- `IsAlwaysDraw` added to `FNexusActivationPoint` (the shared base, not a per-type
  field - correct per this system's own "per-instance, category-independent" framing).
- `FNexusDebugCategory::SupportsAlwaysDraw` (new field, default false, zero behavior
  change for every other existing category) + a targeted change to
  `UNexusFrameworkSubsystem::DispatchDebugRenderers`: a `SupportsAlwaysDraw` category's
  renderer is now called even while `IsVisible=false`, with that same false value passed
  through - `RenderActivationPoints` reads `config.IsVisible` itself to decide "draw
  everything" vs. "draw only `IsAlwaysDraw` instances," so there is exactly one render
  function/draw-call path for both cases (this phase's own explicit Not Allowed rule).
- **Known, accepted deviation from Phase 33's "invisible category costs nothing" rule**:
  a `SupportsAlwaysDraw` category's renderer now does a small amount of work (iterate
  its own instance list, checking `IsAlwaysDraw` per instance) even while fully hidden
  with zero Always-Draw instances - unavoidable, since something has to check. Scoped
  to only opted-in categories (currently just `Runtime.ActivationPoints`), proportional
  to that category's own instance count, not a blanket cost increase.
- **Instance data source is a deliberate, flagged placeholder** - no real Activation
  Point persistence exists anywhere yet (`UNexusConfigAsset` has no `ActivationPoints`
  array; Phase 22's own validation signature already defaults to empty with a comment
  saying nothing produces them yet). Rather than invent that storage architecture under
  time pressure, this phase uses a session-only, never-persisted `TArray<
  FNexusActivationPoint>` seeded via `Nexus.Representation.AddTestActivationPoint`
  against a REAL, already-mapped HighwayPoint - so the render/composition/Always-Draw
  proof is against live geometry, not fabricated anchors, without deciding the real
  storage model. **The real storage architecture (flat array? per-type arrays?
  FInstancedStruct-based heterogeneous storage for varying payload types?) remains an
  open question for whichever phase first needs to persist a real object type (Phase
  50+, Traffic Light) - flagged here rather than silently decided.**
- Console commands: `Nexus.Representation.AddTestActivationPoint [HighwayPointId]
  [OffsetX] [OffsetY] [OffsetZ] [AlwaysDraw]`, `Nexus.Representation.
  ClearTestActivationPoints`.

## Manual Verification Needed

In the Unreal Editor, with a Landscape/ActiveConfig loaded and at least one mapped
HighwayPoint:
1. Get a real `HighwayPointId` from `Nexus.Representation.DumpJunctionClassification`'s
   log output.
2. `Nexus.Representation.AddTestActivationPoint <HighwayPointId> 0 0 150 0` - enable
   `Runtime.ActivationPoints` in the Debug Tree - confirm an orange sphere appears
   150cm above the HighwayPoint's own live location (not AT the anchor itself - proves
   offset composition).
3. `Nexus.Representation.AddTestActivationPoint <HighwayPointId> 200 0 150 1` (last arg
   1 = `IsAlwaysDraw`) - turn `Runtime.ActivationPoints`'s own category visibility OFF
   in the Debug Tree - confirm this second sphere STILL renders while the first
   (non-always-draw) one disappears.
4. `Nexus.Representation.ClearTestActivationPoints` when done - these are session-only
   and never persist, but clearing avoids confusion in a later test.

## Revision (2026-08-10, Phase 48)

Phase 48 ("Activation Point - Gizmo Integration") needed to both READ and WRITE this
phase's own session-only test data - a gizmo drag has to land somewhere real, and this
was the only real "somewhere" that existed. Two changes to this phase's own code, not a
rewrite of its logic:

- The local `GTestActivationPoints` `TArray<FNexusActivationPoint>` (this file's own
  anonymous-namespace variable) moved to a new shared class,
  `FNexusActivationPointTestStore` (`Public/Private/Representation/
  NexusActivationPointTestStore.*`) - same session-only/never-persisted contract, same
  two console command names/behavior (`Nexus.Representation.AddTestActivationPoint`/
  `ClearTestActivationPoints`), now also holding each point's (optional) allocated
  payload struct instance so Phase 48 could exercise the `Dummy.Array` case for real.
- `RenderActivationPoints` now draws one marker per resolved SUB-point (via new
  `FNexusActivationSubPointResolver::EnumerateResolvedSubPoints`), not only ever the base
  offset - previously this renderer never actually exercised a payload struct's own
  `FixedPoint`/`ArrayPoints` fields at all (only `FNexusActivationPoint::OffsetLocation/
  OffsetRotation` directly), so there was nothing for a gizmo to select on a
  `Dummy.Array`-typed point. Base-offset-only types (no payload, or a payload declaring
  zero sub-point fields) render identically to before - one marker at the base offset.
- New `Nexus.Representation.AddTestActivationPointArray` console command (same file)
  seeds a real multi-element `Dummy.Array` payload for Phase 48's own array-case testing.

See `ai-change-audits/2026-08-10/feature-add/phase-48-gizmo-integration.md` for the full
reasoning and `phase-48.md` itself for that phase's own record. This phase's own
Completion Criteria/Allowed/Not Allowed above are unchanged and still accurately
describe this phase's original scope.

## References

- `project-specifications/06-v6-debug-system.md`
- `project-specifications/12-v6-activation-point-system.md`

## Update — 2026-08-22 (payload persistence — the open question this phase flagged is closed)

This phase flagged that no real Activation Point persistence model existed, and left the
harder half open: how a SPECIALIZED payload gets persisted (flat array? per-type arrays?
`FInstancedStruct`?). Phase 75 re-reported it as its own GAP 1 after five more types hit it.

**Resolved**: `FNexusActivationPoint::Payload`, an `FInstancedStruct`, stored on the point
itself. The session-only `FNexusActivationPointTestStore` was collapsed onto the same field,
so the test data this phase's own renderer verification uses and real, persisted config data
now travel through one identical mechanism.

Full reasoning, rejected alternatives, and the manual verification steps:
`project-specifications/12-v6-activation-point-system.md` → "Payload persistence — RESOLVED
2026-08-22", and `ai-change-audits/2026-08-22/others/activation-point-payload-persistence.md`.
