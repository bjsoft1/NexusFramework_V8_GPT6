# Phase 96 — Testing — End-to-End Pipeline Test

## Status

Ready for Review
Ready for Review: 2026-08-22 20:40 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Build one comprehensive, repeatable end-to-end test: a hand-authored test Landscape exercising every stage (Source through Compilation through Runtime activation) and every object type in one pass.

## Allowed

- Build/curate a single test Landscape covering every object type built through Phase 75.
- Run the full pipeline against it and verify output at every stage boundary.
- Make this test repeatable (documented steps or automated) for future regression use.
- Record this as the canonical reference test going forward.

## Not Allowed

- No phase-specific restrictions beyond the general roadmap rules in `09-development-rules.md`.

## Completion Criteria

- [ ] Full pipeline run against the canonical test Landscape produces correct output at every stage with zero manual workarounds.

## References

- `project-specifications/04-v6-architecture.md`

## Implementation (agent, 2026-08-22)

**Written and RUN under the user's explicit, Phase-96/97-scoped override of AGENT-RULES.md's
Agent Testing Policy (2026-08-22).** That policy remains in force for every other phase.

`Source/NexusFrameworkEditor/Private/Tests/NexusPipelineEndToEndTests.cpp` - five automation
tests, one per stage boundary reachable headless. **All 5 pass** (run via
`Automation RunTests Nexus.Pipeline`, re-run and still green after the Phase 90/92
optimizations).

| Test | Boundary it holds |
|---|---|
| `CompilerRefusesUnresolvedSourcePoint` | Representation -> Compilation, failure path |
| `ValidationGateBlocksAndPasses` | Compilation -> shipped asset, both directions |
| `StationQueryableFromExportedDataAlone` | Shipped asset -> runtime consumption |
| `TimeOfDayRulesEvaluateCorrectly` | Runtime activation rules, all four buckets |
| `DistanceOverridesResolveTogether` | Per-instance override resolution |

**What this suite deliberately cannot cover, stated so a green run is not mistaken for full
coverage.** The **Source stage** reads a real `ULandscapeSplineControlPoint` off a real
Landscape actor. That cannot be fabricated headless - a synthetic control point has no
owning splines component and no world transform. Rather than skip the boundary, the first
test asserts the pipeline's **refusal** behaviour there, which is the part that must never
regress: an unresolved SourcePoint must fail loudly rather than bake a guessed location into
a shipped asset.

## Manual verification still required from the user

The criterion asks for a full run against a **canonical test Landscape**, which does not
exist yet and which an agent cannot author. Left unchecked.

1. Build/curate one test Landscape covering every object type through Phase 75.
2. Run `Nexus.Mapping.RunAutomaticEnableFlow` -> `Nexus.Compilation.CompileAndSave` against
   it and verify output at every stage boundary.
3. Record it as the canonical reference test. Phase 99 depends on this existing.
