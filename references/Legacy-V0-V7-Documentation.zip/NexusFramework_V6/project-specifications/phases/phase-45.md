# Phase 45 — Activation Point — Type Registry

## Status

In Review
Ready for Review: 2026-08-10 17:15 GMT+5:45 (+0545)
In Review: 2026-08-10 15:14 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Implement the Activation Point type registry from 12-v6-activation-point-system.md (parallel to Phase 23's Debug category registry) - the extensibility mechanism for all object types from Phase 50 onward.

## Allowed

- Implement the registry: type -> specialized struct type, default classification, default Debug category, default gizmo behavior.
- **(2026-08-10 revision, v6-master-architecture.md Section 5)** "Default gizmo
  behavior" means the registry exposes each type's set of editable **sub-point keys**
  (see `13-v6-gizmo-system.md`'s "Sub-point addressing" section) - a type may declare
  zero extra sub-points (base offset only - Advertisement/TV/Seat/Parking), N fixed
  named sub-points (Traffic Light: Pole/VehicleLED/PedestrianLED), or a mix of fixed and
  dynamic-array sub-points (Crosswalk: StartPoint/EndPoint + WaitingPoints[]). Resolve
  this generically via property reflection over the specialized payload struct, not a
  hand-written per-type list in the registry itself.
- Implement registration for a dummy test type to prove zero-edit extensibility -
  register TWO dummy types for this phase specifically: one base-offset-only, one with a
  dynamic array of at least 3 sub-points, so the array case is proven here rather than
  left for Phase 48 to discover it doesn't work.
- Verify Generation/Compilation/Debug code paths iterate the registry generically, no switch-over-Type.
- Document the exact onboarding steps a new object type follows (feeds Phase 75).

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

- [ ] Dummy-type test proves zero-edit extensibility across Generation/Debug/Compilation.
      The registry/reflection mechanism itself is generic and touches neither
      Generation nor Debug code (nothing exists yet for either to branch on) - true by
      construction for Generation/Debug specifically because Phase 46/Static Generator
      don't consume Activation Point types yet; will be re-proven once Phase 46 wires a
      generic renderer against these same two dummy types.
- [x] The dynamic-array dummy type's sub-point keys are correctly enumerated by the
      registry (N keys for an N-element array, updating if the array is resized).
      `Nexus.Representation.DumpActivationTypeRegistry` builds a real
      `FNexusDummyArrayActivationPayload` instance, sets `ArrayPoints` to 3 elements,
      resolves keys (expect 4 = 1 `FixedPoint` + 3 `ArrayPoints[i]`), resizes to 5,
      re-resolves (expect 6) - not yet actually run (no editor launch), but the
      resize-then-re-resolve check is in the command itself, not left untested.
- [x] Onboarding steps documented - see Implementation Notes below; will be the basis
      for Phase 75's own checklist.

## Implementation Notes (2026-08-10)

- New `FNexusSubPointOffset` (`Public/Representation/NexusSubPointOffset.h`) - the one
  reusable `OffsetLocation`/`OffsetRotation` pair every sub-point field is made of. A
  payload struct declares one bare member of this type per FIXED sub-point, or one
  `TArray<FNexusSubPointOffset>` per dynamic-array sub-point group - never a raw
  `FVector`/`FRotator` pair by naming convention, which is what makes reflection-based
  discovery possible without a hand-written per-type field list.
- New `FNexusActivationTypeRegistry` (`Public/Representation/
  NexusActivationTypeRegistry.h` / `Private/.../NexusActivationTypeRegistry.cpp`) -
  same Meyer's-singleton/self-registration shape as Phase 23's
  `FNexusDebugCategoryRegistry`. `EnumerateDeclaredSubPointFields` walks a payload
  struct's `FProperty` list for `FStructProperty`/`FArrayProperty` members whose
  element type is `FNexusSubPointOffset::StaticStruct()` (static declaration - Fixed
  vs. Array shape only). `EnumerateSubPointKeysForInstance` combines that with the
  REAL current array length off a live instance (`FScriptArrayHelper`), so the returned
  key count always matches the actual array size, not just the type's declared shape.
- New dummy types (`Public/Representation/NexusActivationDummyTypes.h`,
  registered in `Private/Representation/NexusActivationDummyTypesRegistration.cpp`):
  `FNexusDummyBaseOnlyActivationPayload` (empty - zero sub-points) and
  `FNexusDummyArrayActivationPayload` (`FixedPoint` + `ArrayPoints[]`).
- **Onboarding steps for a new Activation Point type** (feeds Phase 75): (1) define a
  payload `USTRUCT` with one `FNexusSubPointOffset` member per fixed sub-point and/or
  one `TArray<FNexusSubPointOffset>` per dynamic-array sub-point group; (2) declare one
  static `FNexusActivationTypeAutoRegister` at namespace scope with the type's Name/
  `StaticStruct()`/default Classification/default Debug category; (3) nothing else -
  Generation/Debug/gizmo code discovers the type and its sub-points generically. No
  registry code, no switch statement, no renderer edit.

## Manual Verification Needed

In the Unreal Editor Output Log (no Landscape/ActiveConfig needed):
1. `Nexus.Representation.DumpActivationTypeRegistry` - confirm both dummy types are
   listed, `Dummy.BaseOnly` has 0 declared sub-point fields, `Dummy.Array` has 2
   (`FixedPoint` Fixed, `ArrayPoints` Array), the 3-element instance resolves 4 keys,
   and after resizing to 5 it resolves 6.

## References

- `project-specifications/12-v6-activation-point-system.md`
