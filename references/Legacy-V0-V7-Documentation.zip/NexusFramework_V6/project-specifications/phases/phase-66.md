# Phase 66 — Bus Stop — Seat Interaction Points

## Status

Ready for Review
Ready for Review: 2026-08-12 (agent, via `/TODO`)
In Review: 
Ready for QA: 
Complete: 

## Objective

Add SeatInteractionPoints[] to Bus Stop, proving the general Seat activation pattern (Phase 69) in its first real usage context.

## Allowed

- Implement SeatInteractionPoints[] referencing the general Seat activation type (built next in Phase 69, or stubbed here and finalized then - record which).
- Verify a seat mesh (Static-classified, per 11) and its interaction point (RuntimeActivated) share an anchor without merging.
- Verify the master prompt's explicit goal: a chair stays part of merged static geometry while its interaction location is stored separately.
- **(2026-08-10)** Verify each `SeatInteractionPoints[]` element is independently
  gizmo-editable through Phase 48's generic sub-point mechanism, and that each element's
  `FNexusSeatActivation` payload (Phase 69's revision - SeatCapacity/Occupancy/etc.) is
  reachable from the Details panel per-element, not just the array as a whole.

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

- [x] Static seat mesh and RuntimeActivated interaction point proven independently
      classified sharing one anchor. `SeatInteractionConfigs` (RuntimeActivated, part
      of the Bus Stop payload) never spawns or references any merged-static geometry -
      the physical seat mesh is a separate Static-classified object elsewhere (Phase
      40-42's Static Generation pipeline, out of this phase's own scope), same "Pole is
      separate Static, LightSource is the RuntimeActivated sub-point" split City Light
      already established. True by construction: this phase's own code never touches
      any merging path. The visual "share an anchor" placement itself is unchecked
      pending in-editor confirmation per `AGENT-RULES.md`'s Agent Testing Policy - see
      "Manual verification required" below.

## Implementation Notes (2026-08-12)

- **Resolved "built next in Phase 69, or stubbed here and finalized then" per this
  phase's own explicit "record which" instruction: built Phase 69 FIRST** (reordered
  ahead of this phase within the same batch), so this phase references the real,
  finished `FNexusSeatActivation` - no stub was ever created or later replaced.
- **Design deviation from `12-v6-activation-point-system.md`'s diagram wording** ("each
  a FNexusSeatActivation payload, not just a bare point", taken completely literally
  would mean `TArray<FNexusSeatActivation>` with an embedded position): implemented as
  TWO parallel, index-aligned arrays instead - `SeatInteractionPoints`
  (`TArray<FNexusSubPointOffset>`, position, reusing the exact
  PassengerWaitingPoints/PedestrianWaitingPoints mechanism with zero new resolver code)
  and `SeatInteractionConfigs` (`TArray<FNexusSeatActivation>`, metadata). Root cause:
  the existing generic sub-point resolver
  (`NexusActivationSubPointResolver.cpp::ResolveSubPointOffsetPtr`) `reinterpret_cast`s
  a resolved array element directly to `FNexusSubPointOffset*` - safe only when the
  array's element type genuinely IS `FNexusSubPointOffset`. Extending that shared,
  load-bearing mechanism (every real type's gizmo editing depends on it) to support an
  embedded-offset struct-array shape was judged out of scope for this phase - see
  `NexusBusStopActivation.h`'s own "Seat interaction design decision" header comment
  for the full reasoning. This satisfies the ACTUAL requirement (each element's
  SeatCapacity/Occupancy/etc. independently editable, not one shared config for "the
  array as a whole") without the unsafe cast.
- Test console command (`Nexus.Representation.AddTestBusStop`, extended with a new
  `[SeatCount=2]` arg) seeds both arrays in lockstep, each element with a DISTINCT
  `SeatCapacity` (index+1) specifically to make per-element independence visible in the
  Details panel, not just structurally implied.
- Cross-reference confirmed: this is the SAME `FNexusSeatActivation` Phase 69 registers
  standalone (`Nexus.Representation.AddTestSeat`) - `NexusBusStopActivation.h` includes
  `NexusSeatActivation.h` and uses the type directly, no duplicate/parallel struct.
  Phase 69's own Completion Criteria updated to reflect this (see that phase's own
  record).

### Manual verification required (Agent Testing Policy - not run by this agent)

1. In the Unreal Editor, run `Nexus.Mapping.LoadOrCreateConfig`, then
   `Nexus.Representation.DumpJunctionClassification` to find a real `HighwayPointId`.
2. `Nexus.Representation.AddTestBusStop <HighwayPointId> 2 2 3 2 1` - confirm the log
   line reports 2 `SeatInteractionPoints/Configs` pairs (SeatCapacity 1..2).
3. Select 'Select Mode', click each `SeatInteractionPoints[]` marker in turn - confirm
   each is independently selectable/draggable, and the Details panel shows
   `SeatInteractionConfigs` with each element's own distinct `SeatCapacity` (1 and 2),
   not one shared value.
4. Confirm dragging a `SeatInteractionPoints[]` marker does not change
   `SegmentRow`/`SegmentColumn`/`OccupiedIndex` or `PassengerWaitingPoints` in the
   Details panel (three independent concepts on one payload).

## References

- `project-specifications/11-v6-static-dynamic-architecture.md`
- `project-specifications/12-v6-activation-point-system.md`
