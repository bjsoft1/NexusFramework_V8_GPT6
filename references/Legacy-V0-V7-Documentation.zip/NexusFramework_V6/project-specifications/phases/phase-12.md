# Phase 12 — Nexus Mapping — City/State Membership

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Map Highways into City and State membership, including the InterCityHighway (cross-city, possibly cross-state) case carried forward from V5.

## Allowed

- Implement City assignment for a Highway (existing City or new).
- Implement State assignment for a City.
- Implement InterCityHighway detection and dual-city bridging, matching V5's precedent.
- Verify City center computation is fully derived (live from member Highways' points), never stored.

## Not Allowed

- Do not generate meshes or write Landscape geometry.
- Do not treat a mapped ID as permanent before this phase's validation passes.
- Do not duplicate a Landscape control point under two different HighwayPointIds.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — left unchecked for the user's own
manual pass. **Note (2026-08-10)**: the user's first pass at these commands called
`Nexus.Mapping.AssignHighwayToCity`/`.AssignHighwayInterCity`/`.SetCityState`/
`.ComputeCityCenter` with no arguments, which only exercises each command's usage-text
path (confirmed in the log, and `Nexus.Mapping.DumpGraph` afterward showed every
Highway/City still fully unassigned, `StateId`/`CityId`/`EndCityId` all zero) - none of
this phase's actual assignment/computation logic has been exercised yet, both criteria
below remain fully open, not partially confirmed.

- [ ] A cross-city test Highway correctly bridges two City entries. **To check**: after
      Phase 10/11 have run, create two cities (`Nexus.Mapping.CreateCity CityA`,
      `Nexus.Mapping.CreateCity CityB`), pick a Highway spanning both (via
      `Nexus.Mapping.DumpGraph` for indices), run `Nexus.Mapping.AssignHighwayInterCity
      <HighwayIndex> <CityAIndex> <CityBIndex>`, then `Nexus.Mapping.DumpGraph` again
      and confirm that Highway logs `InterCity=true` with both `CityId`/`EndCityId` set
      to the two chosen cities.
- [ ] City center is proven to update live when a member point moves, not cached stale.
      **To check**: assign at least one Highway to a City (`Nexus.Mapping.
      AssignHighwayToCity`), run `Nexus.Mapping.ComputeCityCenter <CityIndex>` and note
      the logged center, move one of that Highway's control points in the Landscape
      Splines tool, then run `Nexus.Mapping.ComputeCityCenter` again and confirm the
      logged center changed to reflect the new position (it re-resolves `SourcePoint`
      live every call, never caches - see `FNexusMapping::ComputeCityCenter`).

## References

- `project-specifications/01-v5-analysis.md`
- `project-specifications/AGENT-RULES.md`
