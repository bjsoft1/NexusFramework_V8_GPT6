# Phase 41a — Static Generator — Junction Mesh Selection (Lane-Aware) [improve/update requirement]

## Status

In Review
Ready for Review: 2026-08-10 15:30 GMT+5:45 (+0545)
In Review: 2026-08-10 15:13 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Select the correct junction mesh piece per HighwayPoint from BOTH its topological classification (Phase 36's `ENexusJunctionType`) AND the resolved lane count of every connecting Highway (Phase 37's per-Highway `LaneCount`) - not topology alone. A mismatched-lane-count junction (e.g. a 4-lane Highway meeting a 2-lane Highway) must resolve to an asymmetric mesh piece where the higher-lane-count Highway continues straight and the lower-lane-count Highway merges in as the T's base - never a symmetric same-size piece (2x2 or 4x4) that would visually and physically mismatch the two roads' actual widths.

## Context (why this phase exists)

Inserted 2026-08-10, immediately after Phase 41 shipped, once user review of the
just-expanded Phase 36 (junction classification) asked whether V6's roadmap already
accounts for lane-count-aware junction mesh selection, not just topology. It does not -
confirmed by search before adding this file (see
`ai-change-audits/2026-08-10/others/phase-41a-inserted-lane-aware-junction-mesh-selection.md`).

V5 already solved half of this: `ENexusPointDescription`'s Highway-geometry band
(`project-specifications/v5-complete-reference.md`) is already lane-combination-specific,
not just topology-specific - `Highway_Straight=1, Highway_Curve=2,
Highway_T_Junction=3` (same-lane T), `Highway_6_4_T_Junction=4` (6-lane meets 4-lane,
T), `Highway_6_2_T_Junction=5`, `Highway_4_2_T_Junction=6`, `Highway_Cross_Junction=7`
(same-lane cross). That same doc also records V5's superseded early lane concept
(`EHighwayLanes`: HumanWalk/OneLane_LeftEntry/OneLane_RightEntry/TwoLane/FourLane/
SixLane) and what replaced it (`ENexusLaneConfiguration`: TwoLanes/FourLanes/SixLanes/
EightLanes/TenLanes/OneWayLeftLane/OneWayRightLane/HumanWalk).

Neither Phase 40 ("Static Generator - Classification Tagging", a DIFFERENT axis -
Static/Instanced/etc, not junction geometry) nor Phase 41 ("Static Generator - Mesh
Merge Pipeline", scoped to Highway road-surface and Sidewalk mesh generation only) nor
their shared reference doc (`11-v6-static-dynamic-architecture.md`) mention
junction-piece selection at all. This phase closes that gap rather than letting it
surface later as a silent bad-design default (every junction rendered with a
mismatched, same-size mesh piece regardless of the real lane counts on each side).

Concrete failure this phase exists to prevent - a 4-lane Highway meeting a 2-lane
Highway must NOT place two mismatched full-width junction pieces; the correct shape is
the 4-lane road continuing straight with the 2-lane road's T-base merging into it:

```
--------
--------
    |
    |
```

## Allowed

- Implement a mesh-selection key that combines Phase 36's `ComputeJunctionType` result
  with the resolved `LaneCount` (Phase 37's Highway -> City -> State inheritance chain)
  of every Highway connected at that HighwayPoint - not topology alone.
- Follow V5's own `ENexusPointDescription` Highway-geometry band as the precedent for
  which distinct lane/topology combinations need distinct mesh pieces (same-lane T/Cross
  vs. asymmetric 6-4/6-2/4-2 T combinations) - extend it for V6's own lane model
  (`FNexusLane`/per-Highway `LaneCount`, Phase 37), don't redesign from scratch.
- Determine the "priority" (through) Highway at an asymmetric junction as the one with
  the strictly higher resolved lane count; document the tie-break rule for equal-lane-
  count multi-Highway junctions explicitly - do not leave it implicit/undefined.
- Consume Phase 36/37 output only (Representation-stage data) - this phase's own
  selection logic lives in the Generation/Static Generator arc (Phase 40+) and must not
  read Landscape directly, matching every other Generation-stage phase's Not Allowed
  rule.
- Verify against a synthetic test map containing at least: a same-lane T, a same-lane
  cross, a 4-lane/2-lane T, and a 6-lane/4-lane T.

## Not Allowed

- Do not place a symmetric junction mesh piece at an asymmetric (mismatched lane count)
  junction - this is the specific defect this phase exists to prevent.
- Do not perform this selection at the Representation stage - Phase 36/37's own Not
  Allowed list (no generation, no Landscape reads) still applies to those phases; this
  is Generation-stage work layered on top of their output.
- Do not hardcode specific mesh asset references beyond what's needed to prove the
  selection KEY is correct - actual mesh asset wiring follows this project's existing
  mesh-asset-set precedent (see Phase 41's own mesh pipeline).

## Completion Criteria

- [ ] A same-lane T-junction and a same-lane cross-junction each resolve to a distinct,
      correct selection key. Structurally guaranteed by design (`FNexusJunctionMeshSelectionKey`
      combines `JunctionType` - TJunction vs CrossJunction always differ - with the lane
      combination) and hand-traced against the `SameLaneT`/`SameLaneCross` synthetic
      cases in `Nexus.Generation.TestJunctionMeshSelection` - not yet actually executed
      by anyone (an agent cannot launch the editor - AGENT-RULES.md), see Manual
      Verification below for the one command that closes this out.
- [ ] A 4-lane/2-lane T-junction resolves to an asymmetric selection key (not the
      same-lane T key), with the 4-lane Highway correctly identified as the
      through/priority road. Hand-traced via the `4v2_T` case
      (expect `IsAsymmetric=true`, `PriorityLaneCount=4`) - not yet actually run.
- [ ] A 6-lane/4-lane and a 6-lane/2-lane T-junction are each distinguishable from the
      4-lane/2-lane case and from each other - `ConnectedLaneCountsDescending` is a
      structured array ([6,4] vs [6,2] vs [4,2]), not a flat enum value, so V5's
      recorded "duplicate-4 bug" (several distinct combinations collapsing to one enum
      value) cannot recur by construction. Hand-traced via the `6v4_T`/`6v2_T` cases -
      not yet actually run.
- [ ] Equal-lane-count multi-Highway (3+) junctions have an explicit, documented
      tie-break rule for which Highway (if any) is treated as "through." Rule: the
      FIRST connected Highway (in the HighwayPoint's own `ConnectedHighwayIds` order) at
      the highest resolved LaneCount wins - see `FNexusJunctionMeshSelectionKey::
      HasAmbiguousPriority`'s own doc comment. Hand-traced via the `TiedPriority_6_6_2`
      case (lane counts [6,6,2], expect `PriorityLaneCount=6`,
      `HasAmbiguousPriority=true`, `PriorityHighwayId` still a valid Guid) - not yet
      actually run.

## Implementation Notes (2026-08-10)

- New `FNexusJunctionMeshSelectionKey`/`FNexusJunctionMeshSelector`
  (`Public/Generation/NexusJunctionMeshSelector.h`,
  `Private/Generation/NexusJunctionMeshSelector.cpp`). Deliberately split into two
  pieces: `ComputeLaneAsymmetryKey` (lane-count/asymmetry logic only, reads
  `ConnectedHighwayIds` + each Highway's resolved `LaneCount`, NO live geometry) and
  `ComputeSelectionKey` (adds `JunctionType` via Phase 36's already-verified
  `FNexusRepresentationGraph::ComputeJunctionType`). This split exists because
  `ComputeJunctionType` requires a resolvable live `SourcePoint` for every point
  involved (real Landscape Spline data) - untestable without a real mapped Landscape -
  while the lane-combination logic this phase actually introduces needs no geometry at
  all and is fully unit-testable with a synthetic, Landscape-free
  `FNexusRepresentationGraph` built directly via `AddHighway`/`AddPointToHighway`.
- `Nexus.Generation.TestJunctionMeshSelection` (new console command,
  `NexusJunctionMeshSelectorCommands.cpp`) runs all 6 completion-criteria cases against
  real (not mocked) `FNexusJunctionMeshSelector` code and logs PASS/FAIL per case - see
  Verification below for this session's own run.

## Verification

- Build only: `NexusFrameworkEditor` compiled clean (0 errors) with this phase's new
  files. The 6 completion-criteria cases above were hand-traced against the algorithm,
  not actually executed - no automated test run/added, per `AGENT-RULES.md`'s Agent
  Testing Policy (an agent cannot launch the editor). Unlike Phase 41's mesh generation,
  this phase's test harness needs NO Landscape/mapped data at all, so it's the one
  Generation-phase this session where the real PASS/FAIL numbers can be produced by
  running a single console command with no map setup first - see Manual Verification.

## Manual Verification Needed

In the Unreal Editor Output Log (no Landscape/ActiveConfig needed for this command):
1. `Nexus.Generation.TestJunctionMeshSelection` - confirm all 6 cases log PASS and the
   final line reads `6/6 cases passed`.

## References

- `project-specifications/v5-complete-reference.md` (`ENexusPointDescription` Highway
  geometry band; `ENexusLaneConfiguration`; the superseded `EHighwayLanes` note; the
  "duplicate-4 bug" fix precedent)
- `project-specifications/phases/phase-36.md` (`ENexusJunctionType` - see its
  2026-08-10 revision, which is a direct prerequisite for this phase)
- `project-specifications/phases/phase-37.md` (per-Highway `LaneCount`/`Lanes`)
- `project-specifications/phases/phase-41.md` (the mesh-merge pipeline this phase's
  selection output feeds into)
- `project-specifications/11-v6-static-dynamic-architecture.md`
