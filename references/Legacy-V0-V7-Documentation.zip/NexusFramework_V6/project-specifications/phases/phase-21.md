# Phase 21 — Representation — ActivationPoint Base Struct

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement FNexusActivationPoint itself per 12-v6-activation-point-system.md: the shared base every specialized activation type will build on, plus offset-transform composition.

## Allowed

- Implement the base struct fields exactly as specified in 12-v6-activation-point-system.md.
- Implement FinalTransform = HighwayPointTransform * OffsetTransform composition.
- Verify composition stays correct when the underlying HighwayPoint's Landscape anchor moves.
- Do not yet implement any specialized subtype - base only, this phase.

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — both left unchecked for the user's
own manual pass, even though the composition math was hand-derived during
implementation (see the audit record's Findings) — per AGENT-RULES.md: "Never claim
that a feature is verified unless the user has manually verified it."

- [ ] Composition math verified against a hand-computed test case. **To check**: run
      `Nexus.Mapping.LoadOrCreateConfig` then `Nexus.Representation.
      DumpActivationPointTransform`; confirm the logged `FinalTransform.Location`
      matches the logged "Hand-check: expected..." value on the same line (both are
      computed independently — one via `FNexusActivationPoint::ComputeFinalTransform`,
      the other via a plain `AnchorLocation + AnchorRotation.RotateVector(OffsetLocation)`
      expression written directly in the console command, not reused from the struct's
      own method).
- [ ] Moving the anchor point live updates the composed transform with no manual
      recompute step. **To check**: move the first HighwayPoint's control point in the
      Landscape Splines tool, then re-run `Nexus.Representation.
      DumpActivationPointTransform` and confirm `FinalTransform.Location` changed to
      match the new position (`ComputeFinalTransform` re-resolves the anchor's live
      geometry via `GetLiveLocation`/`GetLiveRotation` on every call - no cached
      transform exists to go stale).

## References

- `project-specifications/12-v6-activation-point-system.md`

## Revision — 2026-08-10 — base struct extended (prerequisite work for Phase 49)

Direct ad-hoc user request, made before starting Phase 49: audit V6 for "the shared
Activation Point / city-object data structure" the future 20-50 object types (Phase
50+) will build on, and extend it with fields the original 12-v6-activation-point-
system.md spec (and this phase's own original Allowed list: "implement the base struct
fields exactly as specified") did not include - `Code`/`Name`/`Description` (the same
identity convention already used by every other Nexus authoring struct - State/City/
Highway/HighwayPoint), `IsEnabled` (per-instance active/inactive toggle, distinct from
`IsAlwaysDraw`), and `DebugOverride` (new `FNexusDebugInstanceOverride` struct -
per-instance Color/TextColor/TextSize/LineThickness, distinct from a Debug category's
own per-CATEGORY `FNexusDebugRenderConfig`).

This is a genuine extension of this phase's own base struct, not a new phase - treated
the same way Phase 46 already extended this same struct with `IsAlwaysDraw` (see that
phase's own Implementation Notes). Not a violation of the "no feature-specific fields"
Not Allowed rule: these are universal identity/authoring/debug-visual fields that apply
to every future specialized type uniformly, the same category as `ActivationPointId`/
`HighwayPointId`/`Classification`/`Metadata`/`IsAlwaysDraw` already on the base - not
something like `SignalGroup` that only makes sense for one specialized type.

Deliberately structure-only - no renderer/Generation/Compilation/persistence/Details
Panel/Gizmo/validation wiring for the new fields in this pass (`IsEnabled`/
`DebugOverride` are inert - they exist and default safely, nothing reads them yet). See
`ai-change-audits/2026-08-10/feature-add/activation-point-shared-base-struct-extension.md`
for full detail. This phase's own Status is unchanged (already `In Review`) - this is an
amendment to already-implemented work, not a new completion.

## Revision — 2026-08-10 — real persistence, Details Panel editing, undo/redo

Immediate same-day follow-up: `UNexusConfigAsset.ActivationPoints` (real, persisted,
undo/redo-capable array) + Hierarchy tree/Details Panel/Debug renderer wiring, so the
base struct extended above is actually editable, not just defined. See
`ai-change-audits/2026-08-10/feature-add/activation-point-persistence-and-details-editing.md`.
Gizmo-editing of real (non-test-store) points remains unwired - see that record's own
Important Notes.

## Update — 2026-08-22 (payload persistence)

`FNexusActivationPoint` gained one new field: `Payload` (`FInstancedStruct`), the persisted
home for a type's specialized payload. This resolves the storage question Phase 46 flagged
and Phase 75 re-reported as its GAP 1.

**This does not weaken this phase's own "do not add feature-specific fields to
FNexusActivationPoint" Not-Allowed rule, and the rule still stands.** That rule targets
*feature-specific* fields — a traffic light's LED offset, a parking lot's row count.
`Payload` is the generic slot the rule itself points at ("specialize via a payload struct
instead"), finally made persistable. Nothing on the base struct knows or branches on any
specific type; the struct type is resolved through `FNexusActivationTypeRegistry` exactly as
every other Activation-Point-generic code path already does.

Full reasoning and the rejected alternatives:
`project-specifications/12-v6-activation-point-system.md` → "Payload persistence — RESOLVED
2026-08-22", and `ai-change-audits/2026-08-22/others/activation-point-payload-persistence.md`.
