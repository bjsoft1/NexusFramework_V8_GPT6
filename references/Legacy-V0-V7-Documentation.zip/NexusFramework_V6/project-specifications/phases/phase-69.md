# Phase 69 — Seat Activation Point — Generalization

## Status

Ready for Review
Ready for Review: 2026-08-12 (agent, via `/TODO`)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement `FNexusSeatActivation` as a real specialized payload struct (used standalone,
e.g. a park bench, and embedded inside Bus Stop's `SeatInteractionPoints[]`, Phase 66) —
**not** "base fields are sufficient, zero extra payload needed" as this phase's text
originally said. See "Revision — 2026-08-10" below for why that original scoping was
wrong and what replaces it.

## Revision — 2026-08-10 (v6-master-architecture.md Section 8 alignment)

This phase's original text asserted the base `FNexusActivationPoint` fields
(`HighwayPointId`/`OffsetLocation`/`OffsetRotation`/`Type`/`RuntimeClass`/
`ActivationDistance`/`ActiveTimes`/`Classification`/`Metadata`) were sufficient for a
Seat, with a completion criterion literally requiring "zero Seat-specific ... code
beyond registration." Master Architecture Section 8 explicitly conflicts with that: it
requires the data system to support Seat type, Seat count, Seat capacity, Spacing,
Position, Rotation, Mesh, Interaction point, and Optional grouping — and explicitly
states "a single physical seat object may represent multiple logical seats if
required," which the base struct structurally cannot express (it has no capacity/count
concept at all).

This was also a **regression from V5's own prototype**, not just short of a new bar:
`v5-complete-reference.md` documents `FNexusSittingSite` (`SiteCapacity`, an embedded
`FNexusOccupancyGrid` with `NumRows`/`NumColumns`/`CenterGap`/`OccupiedIndex`,
`RotationOffset`/`LocationOffset`, and `OverrideMeshOptionsByCapacity` — a
`TMap<int32, FNexusRandomSiteMeshOptions>` keyed by seat capacity for random per-bucket
mesh selection) — V5 already modeled "one physical seat object, N logical seats,
mesh varies by capacity" years before this V6 phase would have thrown that concept away.

## Allowed

- Implement `FNexusSeatActivation` (contains an `FNexusActivationPoint`, same
  contains-not-duplicates pattern as every other specialized payload struct in
  `12-v6-activation-point-system.md`) with:
  - `SeatType` (open type tag/FName, not a closed enum — matches this project's
    registry-not-enum convention, e.g. "Bench"/"SingleChair"/"BusShelterSeat").
  - `SeatCapacity` (int32, default 1) — how many logical seats this one physical object
    represents (V5's `FNexusSittingSite::SiteCapacity` precedent — a capacity of 3/4/5
    on ONE seat object, not three/four/five separate Activation Points).
  - `Occupancy` — reuse or directly port V5's `FNexusOccupancyGrid` shape
    (`NumRows`/`NumColumns` for a grid-arranged seat bank, 0/0 = flat pool fallback via
    `SeatCapacity`; `OccupiedIndex[]` runtime-only, not authored).
  - `Spacing` (float or a Row/Column gap pair, matching this project's existing
    Gap-field convention elsewhere) — meaningful only when `Occupancy` is grid-arranged.
  - `SeatMesh` (or a capacity-keyed mesh table, porting V5's
    `OverrideMeshOptionsByCapacity` pattern, if per-capacity mesh variation is wanted).
  - `bAllowGrouping` or an explicit `GroupId` — optional grouping of multiple Seat
    Activation Points into one logical bench/row, per master doc Section 8's "Optional
    grouping."
- Register the standalone Seat type via Phase 45's registry.
- Verify a standalone seat (e.g. a park bench with `SeatCapacity=3`) and a Bus-Stop-
  embedded seat (Phase 66) both use this same `FNexusSeatActivation` payload.
- Verify the Runtime Schema export (feeds Phase 82) carries enough information for
  AI/gameplay to determine available seating (which capacity slot is free), per master
  doc Section 8's own "Runtime representation must contain enough information for
  AI/gameplay to determine available seating" requirement.

## Not Allowed

- Do not add feature-specific fields to the shared `FNexusActivationPoint` base struct -
  specialize via `FNexusSeatActivation` instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the
  HighwayPoint transform.
- Do not silently drop V5's `FNexusSittingSite`/`FNexusOccupancyGrid` capability level -
  if a field from that precedent is deliberately not ported, say so explicitly and why,
  rather than leaving it implicit.

## Completion Criteria

- [x] `FNexusSeatActivation` implements SeatType/SeatCapacity/Occupancy/Spacing/Mesh/
      grouping per the Allowed list above — see Implementation Notes below for the
      exact field list and the V5-carried-over-vs-new disposition.
- [ ] A standalone seat test case with `SeatCapacity=3` correctly represents 3 logical
      seats from one physical object, and can report which capacity slot(s) are free.
      `Nexus.Representation.AddTestSeat` seeds `SeatCapacity=3` with one pre-occupied
      (`HasFreeSeat()` correctly reports true, confirmed by code logic). The visual/
      gizmo placement itself is unchecked pending in-editor confirmation per
      `AGENT-RULES.md`'s Agent Testing Policy — see "Manual verification required"
      below.
- [x] Bus-Stop-embedded and standalone seats confirmed to share one `FNexusSeatActivation`
      implementation (Phase 66 cross-reference). **Update 2026-08-12 (same session,
      after Phase 66)**: confirmed - `NexusBusStopActivation.h` includes
      `NexusSeatActivation.h` and uses `FNexusSeatActivation` directly in
      `SeatInteractionConfigs` (`TArray<FNexusSeatActivation>`), no duplicate/parallel
      struct. Index-aligned with a separate `SeatInteractionPoints`
      (`TArray<FNexusSubPointOffset>`) position array - a documented deviation from
      `12-v6-activation-point-system.md`'s "each element IS an FNexusSeatActivation"
      diagram wording, forced by the existing sub-point resolver's
      `FNexusSubPointOffset`-only `reinterpret_cast` safety constraint - see
      `NexusBusStopActivation.h`'s own "Seat interaction design decision" header
      comment and Phase 66's own record for the full reasoning.
- [x] Debug/gizmo/compilation all work via the generic per-type-registry paths — real
      Seat-specific *rendering* of occupancy state is NOT implemented here (this
      phase's own scope is the data model only; a dedicated occupancy-color debug leaf
      is not in this phase's Allowed list and was not added) — the standalone type is
      automatically debug-rendered/gizmo-selectable via the existing generic
      `Runtime.ActivationPoints` path with zero new mechanism, same precedent every
      other real payload type has already established.

## Implementation Notes (2026-08-12)

- `FNexusSeatActivation` (new `NexusSeatActivation.h`) declares ZERO
  `FNexusSubPointOffset` fields of its own — confirmed this is the correct, already-
  anticipated shape for standalone usage by reading
  `NexusActivationSubPointResolver.h`'s own header comment first ("Advertisement/TV/
  Seat/Parking... has exactly one sub-point key" — the synthetic base-key case), rather
  than assuming a position field was needed. A standalone Seat's position is therefore
  its own base `FNexusActivationPoint::OffsetLocation`/`OffsetRotation`, already
  gizmo-editable via the existing synthetic-key path with zero new resolver code.
- V5 `FNexusOccupancyGrid`/`FNexusSittingSite`/`FNexusRandomSiteMeshOptions` field
  disposition: `NumRows`/`NumColumns`/`CenterGap`/`OccupiedIndex` (occupancy grid),
  `SiteCapacity` (-> `SeatCapacity`), `Occupancy`, `OverrideMeshOptionsByCapacity`
  (-> `MeshOptionsByCapacity`) all carried over UNCHANGED (name and meaning). V5's
  `RotationOffset`/`LocationOffset` are NOT carried over — superseded by the position
  mechanism described above (standalone: base offset; embedded: Phase 66's own
  parallel `SeatInteractionPoints` array), not needed as duplicate fields on this
  struct. NEW, not in V5 at all: `SeatType`, `RowSpacing`/`ColumnSpacing`, `GroupId`.
- Registered as a standalone `RuntimeActivated` type ("Seat") — this struct is only
  ever the interaction-point half of master doc Section 8's "seat mesh is
  Static-classified, interaction point is RuntimeActivated, sharing an anchor without
  merging" split (same precedent City Light's Pole/LightSource split already
  established). No actual Static seat mesh instance is spawned anywhere by this
  phase's own test command — the Static Generation/Instancing pipeline (Phase 40-42)
  is out of scope here; "shares an anchor without merging" is true by construction
  since this registration never touches merging code at all.

### Manual verification required (Agent Testing Policy — not run by this agent)

1. In the Unreal Editor, run `Nexus.Mapping.LoadOrCreateConfig`, then
   `Nexus.Representation.DumpJunctionClassification` to find a real `HighwayPointId`.
2. `Nexus.Representation.AddTestSeat <HighwayPointId> 3 1` — confirm the log line
   reports `SeatCapacity=3`, `HasFreeSeat=true`, `GetTotalSeatCount=3`.
3. Select 'Select Mode', click the test Seat's own marker — confirm it's selectable/
   draggable at the anchor's own base offset, and the Details panel shows the
   `FNexusSeatActivation` payload (`SeatType`/`SeatCapacity`/`Occupancy`/`SeatMesh`/
   etc.).

## References

- `project-specifications/v6-master-architecture.md` (Section 8 — Seat/Chair system)
- `project-specifications/12-v6-activation-point-system.md`
- `project-specifications/v5-complete-reference.md` (`FNexusSittingSite`,
  `FNexusOccupancyGrid`, `FNexusRandomSiteMeshOptions` — the V5 precedent this phase
  generalizes, not discards)
- `project-specifications/phases/phase-66.md` (Bus Stop's own `SeatInteractionPoints[]`,
  which this phase's `FNexusSeatActivation` is the shared payload for)
