# Phase 58 — City Light — Gizmo Offset Editing

## Status

Ready for Review
Ready for Review: 2026-08-12 02:34 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Enable gizmo editing for the LightSource offset, following Phase 54's pattern.

## Allowed

- Enable bSupportsGizmo for the City Light Source leaf.
- Implement offset editing following the Traffic Light pattern.
- Verify editing the light-source offset never affects the separately-classified pole object.

## Not Allowed

- Do not let a gizmo edit write to Landscape/`ULandscapeSplineControlPoint` transforms.
- Do not bypass FScopedTransaction/Modify() for gizmo-driven edits (undo/redo must work).
- Do not implement scale handling - offsets are not scaled objects (see 13).

## Completion Criteria

- [ ] Light-source offset is gizmo-editable with the pole proven unaffected. Per
      `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, the gizmo-editable
      half is not run/verified by the agent this session - left unchecked for the
      in-editor drag check. **The "pole proven unaffected" half is checked by
      construction** (see Implementation below) - `FNexusCityLightActivation` has no
      pole field of any kind to affect.

## Implementation (2026-08-12) — zero new code, verification-only phase (same shape as Phase 54)

Same finding as Phase 54 (Traffic Light's own gizmo phase), re-confirmed for City Light
specifically rather than assumed to carry over silently:

- **"Enable bSupportsGizmo for the City Light Source leaf"** — already true.
  `FNexusCityLightActivation`'s `DefaultDebugCategory` is `Runtime.ActivationPoints`
  (`NexusCityLightActivationRegistration.cpp`, Phase 56), whose
  `IsSelectable`/`CanSupportGizmo` were already set `true` at Phase 48's own
  registration. Phase 57's `Infrastructure.CityLightPole`/`CityLightSource` leaves are
  visualization-only and never consulted by the gizmo's click-test (same reasoning as
  Traffic Light's own leaves, Phase 53/54).
- **"Offset editing following the Traffic Light pattern"** — already true, fully
  generically. `LightSource` is declared as a single `FNexusSubPointOffset` field on
  `FNexusCityLightActivation`, found by
  `FNexusActivationTypeRegistry::EnumerateDeclaredSubPointFields`'s own type-blind
  `FProperty` reflection (zero knowledge of "City Light" as a concept), and edited via
  the exact same generic `UNexusActivationGizmoTool` path Traffic Light already proved
  out.
- **"Editing the light-source offset never affects the separately-classified pole
  object"** — true by construction, even more directly than Traffic Light's analogous
  criterion: `FNexusCityLightActivation` has no pole-related field of ANY kind (see
  Phase 56/57's own records) — there is nothing for a `LightSource` gizmo edit to
  possibly reach. A future real pole Generation object (Phase 57's own flagged follow-up)
  would be an entirely separate object with its own separate transform, produced by an
  entirely separate Static Generator pipeline this gizmo tool never touches.
- **Undo/redo, scale, Landscape-write-back Not-Allowed items** — same generic mechanism
  Phase 54 already verified in full, type-agnostic.

No code changed.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. `Nexus.Representation.AddTestCityLight <HighwayPointId> 1`.
2. In Select Mode, click the LightSource marker - confirm a gizmo appears and drags
   correctly, with live wireframe feedback.
3. Ctrl+Z - confirm the drag reverts in one undo step.

## References

- `project-specifications/13-v6-gizmo-system.md`
