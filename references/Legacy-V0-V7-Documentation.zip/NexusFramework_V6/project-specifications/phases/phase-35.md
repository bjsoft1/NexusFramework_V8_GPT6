# Phase 35 — Debug Performance — Massive-World Stress Validation

## Status

In Review
Ready for Review: 2026-08-10 14:05 GMT+5:45 (+0545)
In Review: 2026-08-10 15:13 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Stress-test the full Debug system (registry + tree + rendering + config) against a synthetic GTA-V-scale test Landscape (thousands of points, 50+ registered categories).

## Allowed

- Build or import a synthetic large-scale test Landscape.
- Register enough dummy categories to reach 50+.
- Profile full editor responsiveness (tree UI, viewport, config panel) under this load.
- Document any bottleneck found and file it as a scoped fix, don't fix silently mid-phase if it's large.

## Not Allowed

- Do not optimize a subsystem that hasn't been correctness-verified first.
- Do not introduce caching that can silently go stale (see the V5 lessons doc for why this matters).

## Completion Criteria

- [ ] 50+ category, thousands-of-instance stress test completes without editor freeze or
      crash. Tooling built (`Nexus.Debug.RegisterStressCategories`,
      `Nexus.Debug.SimulateLaneMarkerLOD`) - actually running it and confirming no
      freeze/crash needs a manual editor session (agents cannot launch/drive the editor
      themselves, AGENT-RULES.md).
- [ ] Any found bottleneck is documented with a clear owner phase for the fix. None found
      by static/code-level review (see Findings) - nothing here is a substitute for the
      actual manual run above; if the manual run finds a real bottleneck, log it as a new
      dated section in this file (append, not overwrite) with an owner phase.

## Findings (2026-08-10 code-level review, not a substitute for the manual run above)

No unbounded-per-frame-cost pattern found by inspection: category iteration
(`DispatchDebugRenderers`) is a flat loop over however many categories are registered,
each gated by one `IsVisible` bool before any work; the Debug Tree UI
(`BuildDebugTreeFromRegistry`/`BuildDebugTreeChildrenRecursive`) walks the registry with
`GetChildCategories`, an `O(categories)` `TMap`-backed lookup, not anything
quadratic. The actual scale risk this phase is meant to catch - Slate tree-widget
rebuild cost, `SConstraintCanvas` label-overlay rebuild cost
(`FNexusDebugLabelOverlay::UpdateLabels`'s own doc comment already flags "rebuilds fully
on every call... pooling/allocation-efficiency at scale is explicitly Phase 33-35's
job") at real thousands-of-instance counts - is not something code review can prove
either way; it needs the manual run.

## Tooling added this session (2026-08-10)

- `Nexus.Debug.RegisterStressCategories [Count=50]` (`NexusDebugPerformanceCommands.cpp`)
  - registers `Count` synthetic leaf categories under a session-only `StressTest` group
  (unbound `RendererFn`, matching the six real top-level groups' own convention - these
  stress the Tree/Config UI, not the render loop) so the Debug Tree/config panel can be
  manually checked at 50+ categories without hand-writing 50 fake production categories.
  Never persisted to any config asset.
- `Nexus.Debug.SimulateLaneMarkerLOD [Count=500]` (same file, shared with Phase 34) -
  synthesizes `Count` candidates and exercises the real LOD selection path, giving a
  repeatable instance-count stress number for the render side specifically.

## Manual Verification Needed

In the Unreal Editor:
1. `Nexus.Debug.RegisterStressCategories 60` (Output Log) - confirms the registry holds
   60+ categories.
2. Open/refresh the Nexus panel's Debug Tree - confirm it renders and stays responsive
   (expand/collapse, scroll) with the `StressTest` group's 60 dummy leaves present.
3. `Nexus.Debug.SimulateLaneMarkerLOD 3000` - confirms the LOD math itself stays fast at
   a "thousands" instance count; note the logged microseconds.
4. If a real large/imported Landscape is available, load it, map it, and observe overall
   editor responsiveness (viewport framerate, panel responsiveness) with several
   categories enabled - this is the one part of this phase's own scope no console command
   can substitute for.

## References

- `project-specifications/06-v6-debug-system.md`
