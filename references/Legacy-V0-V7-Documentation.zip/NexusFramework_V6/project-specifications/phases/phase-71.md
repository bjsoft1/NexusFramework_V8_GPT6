# Phase 71 — Parking — Debug Visualization

## Status

Ready for Review
Ready for Review: 2026-08-12 (agent, via `/TODO`)
In Review: 
Ready for QA: 
Complete: 

## Objective

Register the Parking debug leaf under Infrastructure, rendering bay grid and occupancy state.

## Allowed

- Register following Phase 53's pattern.
- Render the bay grid and per-bay occupied/free state distinctly, using Phase 70's
  actual `RowGap`/`ColumnGap`/`SpotWidth`/`SpotLength` fields to draw individually-
  dimensioned, correctly-spaced spot outlines - not a generic uniform grid. This is
  what lets the debug view answer "if I generate the final mesh now, exactly where will
  it appear" (v6-master-architecture.md Section 9) for Parking specifically, since
  Parking's whole design intent is accurate row/column spacing.
- Verify on the Phase 70 multi-bay test case.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Completion Criteria

- [ ] Bay grid and occupancy state render correctly and update live as occupancy
      changes. "Update live" is true by construction - `RenderParkingBays` reads
      `OccupiedIndex` fresh off the live test-store payload every render call, no
      cached copy (confirmed by reading the code, not assumed). The visual "render
      correctly" half is unchecked pending in-editor confirmation per
      `AGENT-RULES.md`'s Agent Testing Policy - see "Manual verification required"
      below.

## Implementation Notes (2026-08-12)

- New `Infrastructure.Parking` leaf added to the existing
  `NexusDebugInfrastructureGroupRenderers.cpp` (Phase 53's "one file per GROUP, not per
  TYPE" precedent, already extended by Phase 57/62's own leaves).
- Each of `Capacity` spots is drawn as an individually-dimensioned, correctly-spaced
  rectangle OUTLINE (4 lines, not a solid box - reads as a flat ground marking rather
  than a cube at this scale) sized `SpotLength x SpotWidth`, positioned via Phase 70's
  own `ComputeSpotWorldTransform` (`RowGap`/`ColumnGap` already baked into that
  function's own math) - this phase's own explicit "not a generic uniform grid"
  Allowed-list item, and what lets this debug view answer `v6-master-architecture.md`
  Section 9's "if I generate the final mesh now, exactly where will it appear" for
  Parking specifically. Colored green (free) or red (occupied) per a fresh
  `OccupiedIndex.Contains` check every call.
- Does not touch `NexusParkingActivationRegistration.cpp`'s own `DefaultDebugCategory`
  (stays `Runtime.ActivationPoints`, unchanged) or `RenderActivationPoints` (still
  renders Parking generically) - same "additional, richer, type-aware view, not a
  replacement" precedent every other Infrastructure leaf in this file already follows.
  Not gated on `IsSelectable`/`CanSupportGizmo` - the grid's own overall anchor offset
  is already gizmo-editable via the existing `Runtime.ActivationPoints` category
  (Phase 70's own registration, unchanged); individual spots are COMPUTED, not
  authored (Phase 70's own design), so they were never meant to be individually
  gizmo-draggable in the first place - this is not a gap.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. In the Unreal Editor, run `Nexus.Mapping.LoadOrCreateConfig`, then
   `Nexus.Representation.DumpJunctionClassification` to find a real `HighwayPointId`.
2. `Nexus.Representation.AddTestParking <HighwayPointId> 4 10 1` (the Phase 70 Section-6
   example test case).
3. In the Debug Tree, enable `Infrastructure > Parking`. Confirm: a 4x10 grid of
   correctly-spaced, individually-sized rectangle outlines (not a uniform default
   grid), with 4 spots red (occupied) and 36 green (free), matching indices
   `[0, 3, 7, 21]`.
4. Select the test Parking lot's own marker in the viewport (via
   `Runtime.ActivationPoints`) and drag it - confirm the entire bay grid moves/rotates
   together as one rigid body (every spot recomputed off the new anchor offset), not
   left behind.
5. Edit `OccupiedIndex` directly in the Details panel (add/remove an index) - confirm
   the corresponding spot's color flips green/red on the very next frame, with no
   toggle/refresh needed (proves "updates live").

## References

- `project-specifications/06-v6-debug-system.md`
