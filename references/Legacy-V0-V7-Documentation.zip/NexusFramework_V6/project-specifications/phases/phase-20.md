# Phase 20 — Representation — Relationship Queries

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 15:09 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Implement the higher-level query API the Debug/UI/Generation stages will all depend on: junction detection, City center, Highway length, point neighbor lookups.

## Allowed

- Implement junction detection (point with 2+ ConnectedHighwayIds).
- Implement live City-center computation (derived from member Highways' points, never stored).
- Implement Highway total length (sum of segment lengths via live tangent-aware curve length, not straight-line distance).
- Implement point neighbor lookup (previous/next point along a given Highway).

## Not Allowed

- Do not perform generation (static mesh, instancing) from this stage.
- Do not read Landscape directly from Representation code - only via Mapping's output.
- Do not let a cached field become authoritative - live reads only per 04/05.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — both left unchecked for the user's
own manual pass.

- [ ] City center is proven to update immediately when a member point moves. **To
      check**: run `Nexus.Mapping.LoadOrCreateConfig`, assign a Highway to a City
      (`Nexus.Mapping.AssignHighwayToCity`), run `Nexus.Representation.DumpQueries` and
      note the logged `ComputeCityCenter` value for that City, move one of that
      Highway's control points in the Landscape Splines tool, then run
      `Nexus.Representation.DumpQueries` again and confirm the center changed (it
      re-resolves every member point's live location on every call via
      `FNexusRepresentationGraph::ComputeCityCenter` — no cached field exists to go
      stale, same precedent as `FNexusMapping::ComputeCityCenter`, already confirmed
      live at the Mapping stage per Phase 12's own Verification section).
- [ ] Highway length is verified within a reasonable tolerance against a known-curve
      test case. **To check**: run `Nexus.Representation.DumpQueries` and compare the
      logged `ComputeHighwayLength` for a Highway you can independently measure (e.g. a
      near-straight two-point test Highway, where the expected length is close to the
      straight-line distance between its endpoints). Note: tangent MAGNITUDE is
      approximated as chord distance between each point pair (Representation code may
      only read `FNexusHighwayPoint::GetLiveTangentDirection`, a unit vector — the
      actual per-segment `TangentLen` lives on the Landscape segment connection, a
      Source-stage-only read this phase's Not Allowed list excludes), so expect closer
      agreement on gently-curved highways than on sharp direction changes.

## References

- `project-specifications/05-v6-data-flow.md`
