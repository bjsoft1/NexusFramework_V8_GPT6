# Phase 33 — Debug Performance — Visibility Cost Model

## Status

In Review
Ready for Review: 2026-08-10 14:05 GMT+5:45 (+0545)
In Review: 2026-08-10 15:13 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Verify and, if needed, fix the cost model from 06-v6-debug-system.md: an invisible category must cost effectively zero per frame.

## Allowed

- Profile per-frame cost with all categories visible vs. all hidden on a mid-size test Landscape.
- Fix any renderer found doing work before its own visibility check.
- Verify the per-category check happens once per category per frame, not per object.
- Record before/after profiling numbers.

## Not Allowed

- Do not optimize a subsystem that hasn't been correctness-verified first.
- Do not introduce caching that can silently go stale (see the V5 lessons doc for why this matters).

## Completion Criteria

- [ ] Profiling proves near-zero cost delta between all-hidden and baseline-empty-scene.
      Structurally verified by code audit (see Findings) - actual wall-clock numbers
      still need a manual run; `Nexus.Debug.ProfileRenderers` (2026-08-10 addition,
      `NexusFrameworkSubsystem.cpp`) is the tool for that, see Manual Verification below.
- [x] Any renderer found violating the visibility-first rule is fixed and re-profiled -
      none found. Every one of the four Debug-group renderer files (Landscape/Roads/
      Mapping, plus the Diagnostics overlay) is only ever invoked through
      `UNexusFrameworkSubsystem::DispatchDebugRenderers`'s single dispatch loop, which
      checks `runtimeConfig->IsVisible` once per category, before `RendererFn.Execute` is
      called at all - nothing to fix.

## Findings (2026-08-10 code audit)

`DispatchDebugRenderers` (`Private/Subsystem/NexusFrameworkSubsystem.cpp`) already
implements this phase's cost model correctly, evidently written with Phase 33 in mind up
front (its own inline comment cites this phase by number). Confirmed by reading all four
renderer .cpp files (`NexusDebugLandscapeGroupRenderers.cpp`,
`NexusDebugRoadsGroupRenderers.cpp`, `NexusDebugMappingGroupRenderers.cpp`,
`RenderDiagnosticsOverlay`): none does Landscape/Mapping recomputation inside the draw
loop (all read from the already-throttled `RenderSnapshot`), and none is reachable except
through the single per-category `IsVisible` gate. No fix was needed - this phase's actual
remaining work was building the tool to produce real numbers (`Nexus.Debug.
ProfileRenderers`) and Phase 34's LOD chain, which shares this phase's "checked once, not
per object" principle by construction (`FNexusDebugLOD::SelectLOD` is one call per
category per frame, not per candidate).

## Manual Verification Needed

Run in the Unreal Editor (Output Log), with a Landscape/ActiveConfig loaded:
1. `Nexus.Debug.ProfileRenderers` with the Debug Tree's normal/default visibility state
   - note the TOTAL microseconds line.
2. Toggle every category off in the Debug Tree (or run with `Nexus.Debug.
   RegisterStressCategories 0` first if you want a larger baseline - see Phase 35).
3. `Nexus.Debug.ProfileRenderers` again - the new TOTAL should be near-zero (a handful of
   `IsVisible` bool checks) regardless of the first run's number.

## References

- `project-specifications/06-v6-debug-system.md`
