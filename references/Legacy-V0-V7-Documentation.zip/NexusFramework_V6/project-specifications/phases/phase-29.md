# Phase 29 — Debug Rendering — Labels & Text

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement world-space text label rendering (font size, content, visibility all per-category-configurable), matching V5's proven label-overlay precedent.

## Allowed

- Implement world-space text draw using FNexusDebugRenderConfig's label fields.
- Implement a default label-content builder per category (e.g. "HighwayPointId: <guid>"), overridable.
- Verify labels remain readable (billboard toward camera) at varying distances.
- Verify label toggling is independent of the parent category's wireframe visibility toggle.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — both left unchecked for the user's
own manual pass.

- [ ] Labels stay camera-facing and readable at near and far test distances. **To
      check**: with a config loaded and at least one Diagnostics entry that has a world
      location (see Phase 27's own steps), fly the viewport camera near and far and
      confirm the label text stays legible. Note: labels are 2D screen-space
      `STextBlock`s positioned via `WorldToScreen`, not 3D world-space billboards, so
      they are camera-facing and constant-size by construction — this check is about
      confirming that behavior looks right in practice, not that a billboard rotation
      was implemented correctly.
- [ ] Label visibility and wireframe visibility are proven independently toggleable.
      **To check**: select a `Diagnostics.*` leaf in the Debug Tree; toggle its
      `bShowLabel` in the Details panel and confirm the label appears/disappears while
      the wireframe marker stays; then untick the row's own visibility checkbox
      (`bVisible`) and confirm both marker and label disappear together (bVisible is
      the category master switch, bShowLabel only gates the text — that asymmetry is
      intended).

## Note on scope

The `LabelOverrideText`/"default label-content builder per category" half of this
phase's Allowed list is deliberately deferred: no category has a renderer yet (Phase 30+
registers the first real leaves), so there is no category-specific label content to
build a default for. `FNexusDebugRenderConfig::LabelOverrideText` exists as a field
(Phase 23/25) and Phase 27's Diagnostics rendering composes its own label text directly.
The per-category default-builder hook belongs with the first phase that registers a
renderer needing one.

## References

- `project-specifications/06-v6-debug-system.md`
