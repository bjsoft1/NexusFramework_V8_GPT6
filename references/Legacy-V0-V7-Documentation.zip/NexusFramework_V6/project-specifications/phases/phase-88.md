# Phase 88 — Runtime Activation Subsystem — Deactivate/Pooling

## Status

Ready for Review
Ready for Review: 2026-08-22 19:05 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement deactivation and pooling/reuse when the player leaves ActivationDistance, per V5's FNexusDynamicInteractable doc-comment pooling intent.

## Allowed

- Implement deactivate-on-distance-exceeded logic.
- **(2026-08-10, v6-master-architecture.md Section 26)** Use a separate
  `DeactivationRadius` distinct from Phase 89's `ActivationDistance`
  (`DeactivationRadius > ActivationDistance`, a hysteresis gap) - a single shared
  threshold causes boundary-flicker thrashing (rapid activate/deactivate as a player
  oscillates exactly at the edge).
- Implement pooling/reuse of a despawned instance for the next nearby Activation Point of the same type.
- **(2026-08-10)** Make pooling itself configurable via `PoolingEnabled` (per type or
  global default) - do not build it as unconditionally-on with no opt-out.
- **(2026-08-10)** Implement a configurable `MaximumActiveActors` ceiling (per type or
  global) - once reached, the next nearby Activation Point simply doesn't get a pooled
  Actor until one frees up (distance-prioritized, closest-wins), rather than growing
  the pool unbounded.
- **(2026-08-10)** Implement a configurable `UpdateDistance` (how far the player must
  move before re-evaluating nearby/pooled bindings) - do not re-run the full nearby
  query every tick regardless of player movement.
- Verify no memory/instance-count growth over a long simulated player-movement test (enter/exit range repeatedly).
- Verify `MaximumActiveActors` is actually enforced under a test density that exceeds
  it (more nearby candidates than the configured ceiling).
- Benchmark activate/deactivate cycle cost.

## Not Allowed

- Do not put editor-only/UObject-heavy types into runtime-consumed structs.
- Do not let the runtime module depend on NexusFrameworkEditor.
- Do not skip the Compilation-stage validation gate before an asset is allowed to save.
- Do not hard-code `DeactivationRadius`/`MaximumActiveActors`/`UpdateDistance` -
  each must be a configurable value, matching v6-master-architecture.md Section 26's
  explicit "do not hard-code 15-20 as an architectural requirement" rule.

## Completion Criteria

- [ ] Long-running enter/exit test shows flat, non-growing instance/memory count.
- [ ] `DeactivationRadius` hysteresis proven to prevent boundary-flicker thrashing at the
      activation threshold.
- [ ] `MaximumActiveActors` proven enforced under over-density test.
- [ ] Cycle-cost benchmark recorded.

## References

- `project-specifications/v6-master-architecture.md` (Sections 26-27)
- `project-specifications/10-v6-runtime-schema.md` (pooling precedent)

## Implementation (agent, 2026-08-22)

Deactivation, pooling, and both budget ceilings — every threshold configurable via
`UNexusRuntimeSettings`, none hard-coded, per this phase's own Not-Allowed rule and
`v6-master-architecture.md` Section 26.

**Hysteresis.** Each point resolves its own `DeactivationRadius`, strictly larger than its
`ActivationDistance`. `ResolveDeactivationRadius` clamps to
`activationDistance * MinimumHysteresisMultiplier` if a configuration ever resolves the two
equal or inverted — rather than honouring a setting that silently destroys the gap it exists
to create. Deactivation runs **before** activation each update, so Actors freed this frame
are immediately reusable.

**Pooling is opt-out-able** (`IsPoolingEnabled`, global and per-type; global off wins).
Pooled Actors are hidden, collision-disabled and tick-disabled rather than destroyed.
`MaximumPooledActorsPerType` caps the pool — a pool that swelled during one dense moment
would otherwise hold that memory for the whole session. A pooled Actor destroyed by
something else is skipped rather than handed out.

**`MaximumActiveActors`** is enforced globally and per type. Because candidates arrive
nearest-first from Phase 86, hitting a ceiling means the objects that missed out are strictly
farther than those that got an Actor — "closest wins" with no second sort.

**`UpdateDistance`** gates `Tick`: a stationary player costs nothing. A time-of-day change
force-clears that gate, since eligibility can change while the player stands still.

### Build verification

`Build.bat NexusFramework Win64 Development` — the standalone GAME target, no editor
module compiled or linked — **Succeeded**. Every line of this subsystem lives in the
runtime module, so that is a real compile+link proof for this phase's code and re-proves
Phase 85's module boundary at the same time.

**No automated test was written or run, and the editor was not launched** (AGENT-RULES.md).
Every Completion Criterion below is a *runtime behaviour* test needing a running game, so
all are deliberately left **unchecked**.

## Manual verification still required from the user

1. Long-running enter/exit test — `GetActiveActorCount()` and `GetPooledActorCount()` must
   stay flat across many cycles, with no growth.
2. **Hysteresis:** stand exactly at the activation boundary and strafe slightly. Nothing
   should thrash. Then set `DefaultDeactivationRadius` equal to `DefaultActivationDistance`
   and confirm the clamp still prevents thrashing.
3. **Over-density:** put more candidates in range than `MaximumActiveActors` and confirm the
   ceiling holds and the *nearest* candidates are the ones bound.
4. Record an activate/deactivate cycle-cost benchmark.
