# Phase 57 — City Light — Debug Visualization

## Status

Ready for Review
Ready for Review: 2026-08-12 02:33 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Register the City-Light-Pole and City-Light-Source debug leaves, visually distinguishing the static pole from the dynamic light-source offset per the master prompt's explicit requirement.

## Allowed

- Register both leaves under Infrastructure, following Phase 53's pattern.
- Render pole and light-source markers with visually distinct styling.
- Verify both remain correctly positioned as the shared anchor point moves.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Completion Criteria

- [ ] Pole and light-source markers are visually distinguishable, matching the master
      prompt's explicit City Light debug requirement. Per
      `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
      the agent this session (build-only verification) - left unchecked. **To check**:
      see "Manual verification required" below.

## Implementation (2026-08-12)

Added to the same `Private/Debug/NexusDebugInfrastructureGroupRenderers.cpp` Phase 53
created (this file's own established "one file per GROUP" home for Infrastructure leaves):

- **`Infrastructure.CityLightPole`** - a PLACEHOLDER static-structure marker (a vertical
  line + box "cap"), drawn at a fixed height directly above the shared anchor. No real
  Static-classified City-Light-Pole Generation object exists anywhere yet (confirmed by
  Phase 56's own Findings, re-confirmed here) - `FNexusCityLightActivation` deliberately
  has no pole-offset field to read (see that struct's own header comment), so this leaf
  draws at the LIVE anchor position itself, not a cached/stored offset - "remain
  correctly positioned as the shared anchor point moves" is trivially true by
  construction (it re-reads the anchor's own snapshot location every call).
- **`Infrastructure.CityLightSource`** - the real, registered `LightSource` sub-point, a
  warm yellow-white "lit" color, deliberately distinct from the Pole leaf's neutral grey
  - satisfies "visually distinguishing the static pole from the dynamic light-source
  offset."
- Neither leaf opts into `IsSelectable`/`CanSupportGizmo` - selection/gizmo-editing stays
  `Runtime.ActivationPoints`' own job (Phase 48), same precedent as Phase 53's Traffic
  Light leaves.
- Once a future phase actually produces a real City-Light-Pole Generation object, the
  Pole leaf here should be updated to read its real position instead of the placeholder
  height - flagged in-file, not silently left as a permanent stand-in.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. `Nexus.Representation.AddTestCityLight <HighwayPointId> 1` at a real, already-mapped
   HighwayPoint.
2. Enable `Infrastructure > City-Light Pole` and `Infrastructure > City-Light Source` in
   the Debug Tree. Confirm: a grey placeholder pole marker directly above the anchor, and
   a separate warm-yellow LightSource sphere at its own configured offset - visually
   distinguishable from each other at a glance.
3. Move the underlying Landscape control point (native Landscape Splines tool) - confirm
   both markers follow the new anchor position live, without a manual refresh step.

## References

- `project-specifications/06-v6-debug-system.md`
