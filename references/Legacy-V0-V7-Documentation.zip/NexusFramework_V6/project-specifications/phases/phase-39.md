# Phase 39 — Validation — Representation Gate Hardening

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 11:08 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Harden Phase 22's Representation gate with the remaining checks from 14-v6-validation.md not yet covered (invalid City/Highway relationship, broken junction consistency).

## Allowed

- Add invalid City/Highway relationship checks (cross-references a City/State not in the snapshot).
- Add broken-junction checks (Representation says junction, Landscape segments don't actually meet there).
- Re-run all prior Representation test cases plus new ones for these checks.
- Confirm severity classification (Blocking vs Warning) matches 14-v6-validation.md's table.

## Not Allowed

- Do not perform generation (static mesh, instancing) from this stage.
- Do not read Landscape directly from Representation code - only via Mapping's output.
- Do not let a cached field become authoritative - live reads only per 04/05.

## Implementation note

**(a) Invalid City/Highway relationship checks were already implemented** - re-verified
by reading `ValidateRepresentationStage` (Phase 22) in full before adding anything:
`Highway.CityId`/`EndCityId` resolving in `Cities`, and `City.StateId` resolving in
`States`, are both already Blocking checks (predates this phase). Nothing new added for
this part - re-implementing an existing check would be duplicated logic, not hardening.

**(b) Broken junction consistency (the genuinely missing check) is now implemented.**
Representation may not read Landscape directly (this phase's own Not Allowed list), so
`ValidateRepresentationStage` gained a new parameter, `HighwaysNotMatchingLiveLandscape`
(a `TSet<FGuid>`, default empty), rather than reading Landscape itself. The CALLER
computes this set via the new `FNexusMapping::ComputeHighwaysNotMatchingLiveLandscape`
(Mapping-stage, built on the same-day `DoesHighwayChainMatchLiveLandscape` check from
`ai-change-audits/2026-08-10/bug-fixed/stale-highway-not-detected-on-landscape-removal.md`)
and hands over only the resulting Guid set - Representation never touches an
`ALandscape*` even indirectly. A junction point (`IsJunction()`'s own definition, 2+
`ConnectedHighwayIds`) with any contributing Highway in that set is flagged Blocking.
Both existing callers (`Nexus.Representation.ValidateStage`'s console command and
`FNexusDiagnostics::GatherDiagnostics`) were updated to compute and pass this set.

## Completion Criteria

- [ ] New deliberate-break test cases for both new checks are caught correctly. Part (a)
      needs no new test (already covered by Phase 22's own existing test cases - see
      that phase's own criteria). Part (b) is new. **To check**: reproduce today's
      earlier closed-loop-diagonal scenario - map a closed loop, draw a highway
      connecting two of its existing points (creating a real junction), run
      `Nexus.Mapping.ReconcileMappingStage` so it's registered, then delete just that
      connecting segment natively (leaving both endpoints individually resolvable).
      Run `Nexus.Representation.ValidateStage` - confirm a `[BLOCKING]` entry now names
      the affected HighwayPoint and the stale Highway ("this junction may be broken").
      Before this fix, this scenario produced zero validation entries at the
      Representation stage despite the junction being provably stale one stage up.
- [x] No regression in Phase 22's original test cases. Structural fact: the new check is
      entirely gated behind `if (HighwaysNotMatchingLiveLandscape.Num() > 0)`, and the
      parameter defaults to an empty set - any existing caller that doesn't pass it
      (there are none left uncalled-through after this change, but the default exists
      for compile-compatibility) gets byte-for-byte the same entries as before this
      phase; the new logic cannot fire without a non-empty set being explicitly passed
      in.

## References

- `project-specifications/14-v6-validation.md`
