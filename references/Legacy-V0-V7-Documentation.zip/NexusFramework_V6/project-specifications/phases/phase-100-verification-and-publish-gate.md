# Phase 100 — Verification Tree & Publish Gate

## Status

Ready for Review
Ready for Review: 2026-08-22 20:40 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Give a human a single tree view of everything V6 generated for a map (State → City →
Highway → the Static/Activation objects placed under it), let them click any item to
focus it in the viewport, record a per-item manual sign-off, and block Runtime Compiler
export until every item is signed off. Full design: `15-v6-verification-system.md`.

## Allowed

- Define `FNexusVerificationStatus`/`FNexusVerificationCheckItem` per
  `15-v6-verification-system.md`'s data model, persisted on the
  `[LandscapeId]_nexusconfig` Data Asset, keyed by the target instance's own `FGuid`.
- Build the content-hierarchy tree (State/City/Highway/placed objects) as a new Slate
  tree view, reusing Phase 24's tree-widget patterns (expand/collapse, per-row
  filtering) against this new data source — not a modification of the Phase 24 Debug
  Tree itself.
- Wire row-click to Phase 27's existing click-to-focus mechanism (select + frame the
  viewport camera on the corresponding entity) — reuse it as-is, do not reimplement
  entity selection/camera framing here.
- Render each row's checklist (starting content: `UI Placement Correct`,
  `Smoke Test Complete`, `Overall Test Complete` — explicitly a starting example per
  `15-v6-verification-system.md`, not a locked list) as checkboxes that write directly
  to that row's `FNexusVerificationStatus`.
- Roll up per-row completion into a tree-wide summary (e.g. "42/57 verified") and an
  explicit `bAllChecked`-across-everything flag.
- Add the publish-gate check to the Runtime Compiler export path (Phases 80–85): refuse
  (or block with a clear, listed reason per unverified instance) to produce a Runtime
  Schema asset while any instance is unverified, including instances that have no
  `FNexusVerificationStatus` record at all yet.

## Not Allowed

- Do not modify Phase 24's Debug Tree or its category registry — this is a second,
  separate tree over different data, not an extension of that one.
- Do not reimplement viewport selection/camera-framing — call into Phase 27's existing
  mechanism.
- Do not hardcode the checklist as fixed struct fields — `Checks` must stay a
  data-driven array so the list can change per object type later without a struct
  migration.
- Do not let the publish gate silently pass an instance that has never been opened in
  the tree — no record is treated the same as an unchecked box.

## Completion Criteria

- [ ] Opening the tree shows every State/City/Highway and every placed object currently
      in the Representation graph, correctly nested.
- [ ] Clicking any row focuses the correct entity in the viewport (same behavior as
      Phase 27's diagnostics click-to-focus, confirmed against the same entity).
- [ ] Toggling a checklist item persists to `FNexusVerificationStatus` and survives an
      editor restart (reads back from the `_nexusconfig` asset correctly).
- [ ] A deliberately-unverified instance (fresh object, never opened in the tree) blocks
      Runtime Compiler export with a clear message naming it.
- [ ] Marking every instance's every checklist item complete allows export to proceed.

## References

- `project-specifications/15-v6-verification-system.md`
- `project-specifications/06-v6-debug-system.md`
- `project-specifications/phases/phase-24.md`
- `project-specifications/phases/phase-27.md`
- `project-specifications/10-v6-runtime-schema.md`
- `project-specifications/14-v6-validation.md`

## Implementation (agent, 2026-08-22)

Fully implemented and build-verified.

**Data model** — `FNexusVerificationCheckItem` / `FNexusVerificationStatus`, persisted on
`UNexusConfigAsset::VerificationStatuses`, keyed by the target's own `FGuid` (never array
position). `Checks` is a data-driven array, not fixed struct fields, exactly as this phase's
Not-Allowed list requires - so the checklist can vary per object type later with no struct
migration.

**Tree** — `SNexusVerificationPanel`, a fifth dockable Nomad tab ("Nexus Verification"),
registered in lockstep with the existing four. A **separate** tree over generated content
(State > City > Highway > HighwayPoint > Activation Point), *not* a modification of Phase
24's Debug Tree, which this phase forbids. Rows render their checklist from the record's own
array. Row-click focuses the viewport by calling Phase 27's existing
`MoveViewportCamerasToBox` mechanism rather than reimplementing selection or camera framing.
Header shows the "N/M verified" roll-up and live gate state.

**Publish gate** — `FNexusVerification::IsEverythingVerified`, wired into
`FNexusRuntimeCompilerIO::CompileAndSaveAll` **before** the compile runs.

### Three decisions worth review

1. **The gate does NOT live in the tree widget.** It lives in the compiler's save path, so a
   headless or scripted export cannot skip a human sign-off just because no panel happens to
   be open. The widget is how a sign-off is *recorded*; it is not what enforces it.

2. **The gate runs before compiling, not after.** Compiling reads live Landscape geometry
   across the whole map and is the expensive part; an author who has not finished signing off
   should be told immediately, not after a long wait.

3. **No record is treated exactly like an unchecked box.** An instance nobody has ever opened
   in the tree is the *least* verified thing in the map, not the most - this phase's
   Not-Allowed list is explicit that silence is not approval. `IsFullyChecked()` also
   returns false for an empty checklist rather than vacuously true, for the same reason.

Console access for scripting and inspection: `Nexus.Verification.DumpTree`,
`.SetCheck`, `.CheckPublishGate`.

## Manual verification still required from the user

All five criteria need in-editor confirmation and are left unchecked:

1. Open the **Nexus Verification** tab; confirm every State/City/Highway/point/object appears,
   correctly nested.
2. Click a HighwayPoint and an Activation Point row - the viewport should frame that entity.
   (State/City/Highway rows are groupings with no single location and deliberately do not
   move the camera.)
3. Tick a box, save, restart the editor, and confirm it persisted with the right
   reviewer/timestamp.
4. **The gate test:** create a fresh object, do NOT open it in the tree, and run
   `Nexus.Compilation.CompileAndSave`. It must refuse and name that object.
5. Tick everything, re-run, and confirm export proceeds.
