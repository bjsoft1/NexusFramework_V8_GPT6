# Phase 67 — Bus Stop — Debug Visualization

## Status

Ready for Review
Ready for Review: 2026-08-12 (agent, via `/TODO`)
In Review: 
Ready for QA: 
Complete: 

## Objective

Register Bus-Stop-related debug leaves under Runtime: Bus Stop, Bus Stopping/Entry/Exit Points, Passenger Points, Seat Points.

## Allowed

- Register all leaves following Phase 53's pattern.
- Render stopping/entry/exit distinctly.
- Render passenger waiting points and seat points distinctly from vehicle bays.
- Verify on the Phase 64 multi-bay test stop.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Completion Criteria

- [ ] All Bus Stop sub-concepts are visually distinguishable on the test stop.
      Implementation + build done - four independently-toggleable leaves, each its own
      color/shape, cover every sub-concept (bay occupancy, Stopping/Entry/Exit, Passenger
      Points, Seat Points). The visual confirmation itself is unchecked pending
      in-editor confirmation per `AGENT-RULES.md`'s Agent Testing Policy - see "Manual
      verification required" below.

## Implementation Notes (2026-08-12)

- This phase's own Objective explicitly says leaves go **"under Runtime"** - unlike
  Traffic Light/City Light/Crosswalk's own debug-viz phases, which all say
  "under Infrastructure". Read this literally rather than assuming it was a copy-paste
  inconsistency: confirmed "Runtime" is a real, separate top-level parent category
  (`NexusDebugRuntimeGroupRenderers.cpp`'s own `Runtime.ActivationPoints` registration,
  `ParentCategoryId = FName(TEXT("Runtime"))`), so the four new leaves were added to
  THAT file (the Runtime group's own renderer file), not
  `NexusDebugInfrastructureGroupRenderers.cpp` - same "one file per GROUP, not per TYPE"
  precedent Phase 53 established, applied to the group this phase's own text actually
  named.
- Four leaves, matching the Objective's own named list ("Bus Stop, Bus Stopping/Entry/
  Exit Points, Passenger Points, Seat Points"):
  - **`Runtime.BusStop`** ("Bus Stop") - the vehicle-bay occupancy grid (SegmentRow x
    SegmentColumn boxes, green=free/red=occupied per OccupiedIndex) plus a shelter
    indicator marker if `ShelterConfig.HasShelter`. None of this data is a
    `FNexusSubPointOffset` field, so it's drawn at fixed debug-only offsets from the
    anchor, not resolved/gizmo-draggable sub-points - correctly matches its own
    "plain config, not a position" shape.
  - **`Runtime.BusStopPoints`** ("Bus Stop Points") - StoppingPoint (blue)/EntryPoint
    (green)/ExitPoint (orange), each its own fixed color (this phase's own "render
    stopping/entry/exit distinctly" item).
  - **`Runtime.BusStopPassengerPoints`** ("Bus Stop Passenger Points") - each
    `PassengerWaitingPoints[]` element, its own toggleable category, never mixed into
    the bay-occupancy or Stopping/Entry/Exit leaves' own draw calls.
  - **`Runtime.BusStopSeatPoints`** ("Bus Stop Seat Points") - each
    `SeatInteractionPoints[]` element, labeled with its own index-aligned
    `SeatInteractionConfigs[]` `SeatCapacity` (proves the parallel-array pairing
    visually, not just structurally).
- Deliberately does not touch `NexusBusStopActivationRegistration.cpp`'s own
  `DefaultDebugCategory` (stays `Runtime.ActivationPoints`, unchanged) or the generic
  `RenderActivationPoints` (still renders Bus Stop, undifferentiated) - same
  "additional, richer, type-aware view, not a replacement" precedent every prior
  debug-viz phase already established. None of the four new leaves opt into
  `IsSelectable`/`CanSupportGizmo` - selection/gizmo-editing remains
  `Runtime.ActivationPoints`' own job, unchanged.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. In the Unreal Editor, run `Nexus.Mapping.LoadOrCreateConfig`, then
   `Nexus.Representation.DumpJunctionClassification` to find a real `HighwayPointId`.
2. `Nexus.Representation.AddTestBusStop <HighwayPointId> 2 2 3 2 1` - the Phase 64/65/66
   multi-bay test stop (4 bays/1 occupied, 3 passenger points, 2 seat points).
3. In the Debug Tree, enable all four `Runtime > Bus Stop*` leaves. Confirm: a 2x2 grid
   of boxes (3 green/1 red) with a lavender shelter marker; blue/green/orange spheres
   at Stopping/Entry/Exit; 3 cyan Passenger Point spheres; 2 magenta Seat Point spheres
   labeled "Seat[0] Cap=1"/"Seat[1] Cap=2".
4. Toggle `Runtime.ActivationPoints` on too - confirm it draws its own undifferentiated
   markers at the same sub-point positions, additively, not in conflict.
5. Toggle each of the four new leaves off/on independently - confirm each is genuinely
   independent (e.g. turning off Seat Points doesn't hide Passenger Points).

## References

- `project-specifications/06-v6-debug-system.md`
