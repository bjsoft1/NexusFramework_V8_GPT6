# Phase 60 — Crosswalk — Data Model

## Status

Ready for Review
Ready for Review: 2026-08-12 02:37 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement FNexusCrosswalkActivation per 12-v6-activation-point-system.md: start/end points, width, pedestrian waiting points - a struct V5 had no equivalent of at all.

## Allowed

- Implement the specialized struct (StartPoint/EndPoint, PedestrianWaitingPoints[], Width).
- Register the type via Phase 45's registry.
- Verify a crosswalk correctly spans two Highway sides (e.g. across a road, not just along it).
- Confirm explicitly this closes the "no crosswalk representation at all" gap identified in 10-v6-runtime-schema.md.

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

- [ ] A cross-road test crosswalk correctly represents start/end on opposite sides. Per
      `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
      the agent this session (build-only verification) - left unchecked. **To check**:
      see "Manual verification required" below.
- [x] Gap-closure explicitly confirmed against 10-v6-runtime-schema.md's audit.
      `10-v6-runtime-schema.md`'s own "Confirmed gaps" section, item 3: "No crosswalk
      representation at all. No struct anywhere in Runtime covers crosswalk start/end,
      width, pedestrian waiting points, or its relationship to a controlling traffic
      light." `FNexusCrosswalkActivation` now covers start/end (`StartPoint`/`EndPoint`),
      width (`Width`), and pedestrian waiting points (`PedestrianWaitingPoints[]`) -
      three of that gap's four named items. The fourth ("relationship to a controlling
      traffic light") is explicitly Phase 61's own scope
      (`LinkedTrafficLightId`), not silently dropped - see this struct's own header
      comment.

## Implementation (2026-08-12)

- `Public/Representation/NexusCrosswalkActivation.h` (new) - `FNexusCrosswalkActivation`:
  `StartPoint`/`EndPoint` (fixed `FNexusSubPointOffset`), `PedestrianWaitingPoints`
  (`TArray<FNexusSubPointOffset>` - the first REAL, non-dummy type to exercise the array
  sub-point shape), `Width` (plain `float`, not a sub-point - a single scalar dimension,
  nothing to individually gizmo-drag).
- `Private/Representation/NexusCrosswalkActivationRegistration.cpp` (new) - registers
  `FName("Crosswalk")` (`RuntimeActivated`/`Runtime.ActivationPoints`, same
  reuse-the-shared-category-for-now pattern as Traffic Light/City Light). Adds
  `Nexus.Representation.AddTestCrosswalk <HighwayPointId> [WaitingPointCount=2]
  [AlwaysDraw]` - places `StartPoint`/`EndPoint` at opposite lateral offsets (local
  +-400cm, perpendicular to the anchor's own forward axis) so the test object visibly
  spans "across the road" rather than clustering near one point, and seeds N
  `PedestrianWaitingPoints` spread along that span (offset slightly forward so they don't
  visually overlap Start/End) - reuses `AddTestActivationPointArrayConsoleCommand`'s own
  `FArrayProperty`-resize-then-`SetSubPointOffset`-per-element pattern (Phase 48), the
  first time that pattern has been exercised for a real type rather than the Phase 45
  dummy array type.
- As with Traffic Light/City Light, this type is automatically debug-rendered and
  gizmo-selectable/draggable (including each `PedestrianWaitingPoints` element
  independently) the moment it's registered - zero new renderer/gizmo code, now proven
  for the array-sub-point case with real data too, not just the Phase 45 dummy type.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. `Nexus.Representation.AddTestCrosswalk <HighwayPointId> 3 1` at a real, already-mapped
   HighwayPoint.
2. Enable `Runtime.ActivationPoints` in the Debug Tree - confirm 5 markers: StartPoint
   and EndPoint on visibly opposite sides of the anchor (spanning across it, not
   clustered together), and 3 PedestrianWaitingPoints spread between them.
3. In Select Mode, click each `PedestrianWaitingPoints` element individually - confirm
   each drags independently without disturbing the others or StartPoint/EndPoint (same
   "editing one array element must never disturb sibling elements" requirement
   `13-v6-gizmo-system.md` already states).

## References

- `project-specifications/10-v6-runtime-schema.md`
- `project-specifications/12-v6-activation-point-system.md`
