# Phase 34 — Debug Performance — Spatial/Viewport Filtering

## Status

In Review
Ready for Review: 2026-08-10 14:05 GMT+5:45 (+0545)
In Review: 2026-08-10 15:13 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Implement distance-based LOD for high-instance-count categories (crosswalks, activation
points, lane markers) per `06-v6-debug-system.md`'s performance rule and
`v6-master-architecture.md` Sections 10/22 — not just a binary radius/frustum cutoff.

## Revision — 2026-08-10 (v6-master-architecture.md Section 22 — V0-derived LOD)

The original text scoped this phase to a single configurable debug-radius/frustum
filter (in/out of range, binary). Master Architecture Section 22 explicitly requires
porting V0's more advanced concepts (`NexusFramework_V0`'s `RoadGraphEditorLOD`
namespace, `NexusRoadGraphEditorVisualizer.cpp`): closest-point-to-AABB camera distance
(not origin distance), two INDEPENDENT distance thresholds (full-detail geometry vs.
label text), an AABB/impostor fallback for objects beyond full-detail range, and a
maximum-full-detail-objects-per-frame cap with distance-ranked selection. A binary
cutoff alone cannot express "draw this object's bounding box with one summary label
instead of its full lane/sidewalk/sub-point geometry" — that needs a THIRD state
(full detail / impostor / culled), not just (visible / culled).

## Allowed

- Implement closest-point-to-camera distance using each object's own AABB (bounds), not
  origin-to-origin distance - matches V0's own precedent, meaningfully more accurate for
  large objects (a long Highway's bounds vs. its centroid).
- Implement two independent, separately-configurable distance thresholds per category:
  `FullDetailDistance` (below this, draw full geometry) and `LabelMaxDistance` (below
  this, still draw the text label - independent of whether full geometry is drawn).
- Beyond `FullDetailDistance`, draw a cheap AABB/bounding-box "impostor" plus at most one
  summary label, instead of the category's normal wireframe primitives (lane lines,
  sub-point markers, etc.) - never nothing, matching V0's own "never draws nothing"
  precedent.
- Implement a configurable `MaxFullDetailObjects` cap per category per frame -
  distance-rank every candidate object and only the closest N get full detail; the rest
  (even if within `FullDetailDistance`) get the impostor treatment once the cap is hit.
  This is the specific mechanism V0 built to stop the editor hanging on large maps
  ("large maps would redraw every tile every tick and hang the editor").
- Retain the original binary debug-radius/viewport-frustum filter as the outermost
  cull (objects beyond it draw nothing at all) - LOD operates only on what survives
  that cull.
- Apply the full LOD chain (cull -> rank -> full-detail/impostor split) to at least one
  high-count test category (simulate several hundred instances).
- Verify visual correctness is unaffected for objects that stay within
  `FullDetailDistance` and under the `MaxFullDetailObjects` cap.
- Record before/after profiling numbers at the simulated instance count, specifically
  comparing "every object full detail" vs. "LOD chain active."

## Not Allowed

- Do not optimize a subsystem that hasn't been correctness-verified first.
- Do not introduce caching that can silently go stale (see the V5 lessons doc for why this matters).
- Do not hard-code `MaxFullDetailObjects`/`FullDetailDistance`/`LabelMaxDistance` - each
  must be a configurable value (per-category or global default), matching this
  project's existing "-1 = inherit, explicit override" convention where applicable.
- Do not silently drop an object entirely once it exceeds `MaxFullDetailObjects` - it
  must still get the impostor+label treatment, not disappear.

## Completion Criteria

- [ ] Simulated few-hundred-instance category stays within an acceptable frame-time
      budget with the full LOD chain (cull/rank/impostor) active. Implemented and
      algorithmically O(N log N) (one distance pass + one sort of the over-cap subset,
      `FNexusDebugLOD::SelectLOD`) - trivial at a few hundred candidates by inspection,
      but the actual wall-clock number needs a manual run (see Manual Verification).
- [x] `MaxFullDetailObjects` is proven to cap full-detail rendering regardless of how
      many objects are within `FullDetailDistance`. Code-verified: `SelectLOD`'s pass 3
      always truncates the distance-ranked FullDetail set to `config.
      MaxFullDetailObjects` before returning, unconditionally - there is no path that
      returns more FullDetail results than the cap. `Nexus.Debug.SimulateLaneMarkerLOD`
      (2026-08-10, `NexusDebugPerformanceCommands.cpp`) also actively re-checks this at
      runtime and logs a Warning if it ever doesn't hold, so a regression here can't go
      silent.
- [ ] Impostor rendering (AABB + one summary label) is visually confirmed for an object
      beyond `FullDetailDistance`, not just "culled" vs. "not culled." Implemented
      (`RenderLaneDirection` in `NexusDebugRoadsGroupRenderers.cpp` draws
      `FNexusDebugPrimitives::DrawBox` for `Impostor` state, `DrawDirectionArrow` for
      `FullDetail`) - needs an actual in-viewport look to confirm visually, see Manual
      Verification.
- [x] Filtering/LOD thresholds are proven configurable, not hard-coded to one category.
      `DebugRadius`/`FullDetailDistance`/`LabelMaxDistance`/`MaxFullDetailObjects` are
      plain `UPROPERTY(EditAnywhere)` fields on the shared `FNexusDebugRenderConfig`
      (`NexusDebugRenderConfig.h`), editable per-category from the Details panel exactly
      like every other field on that struct; `FNexusDebugLOD::SelectLOD` itself never
      branches on `CategoryId` or any specific category - it only reads `config`'s
      fields, so any future category can opt in by setting `FullDetailDistance >= 0` on
      its own `DefaultConfig`, no changes to `NexusDebugLOD.cpp` required.

## Implementation Notes (2026-08-10)

- `FNexusDebugLOD` (`Public/Debug/NexusDebugLOD.h` /
  `Private/Debug/NexusDebugLOD.cpp`) is the generic port of V0's `RoadGraphEditorLOD`
  namespace: closest-point-to-AABB squared distance
  (`GetClosestDistanceSquared`), independent `FullDetailDistance`/`LabelMaxDistance`
  thresholds, and a distance-ranked `MaxFullDetailObjects` cap
  (`ClampFullDetailHighwaysByDistance`'s V6 equivalent). Camera location comes from
  `GCurrentLevelEditingViewportClient->GetViewLocation()` (`LevelEditorViewport.h`) - the
  first active level viewport, same "only the first pane" limitation
  `FNexusDebugLabelOverlay` already documents for the same reason.
- Pilot category: `Roads.LaneDirection` ("lane markers", this phase's own Objective
  wording) - `RenderLaneDirection` now builds one `FNexusDebugLODCandidate` per resolved
  `HighwayPoint`, calls `SelectLOD` once, then branches FullDetail (arrow) / Impostor
  (box, matching label rules) / Culled (nothing) per candidate, instead of always
  drawing every arrow. Registered with real (if generous/demo-scale) defaults -
  `FullDetailDistance=1500cm`, `LabelMaxDistance=800cm`, `MaxFullDetailObjects=150` - not
  left at the inherited -1/off default, so the mechanism is visibly active out of the
  box, not just present but dormant. No other existing category (28-32) was touched -
  their `FullDetailDistance` stays at -1 (LOD disabled), matching this phase's own "at
  least one high-count test category" scope, not a blanket retrofit.
- New fields added to `FNexusDebugRenderConfig` (all default -1/unlimited, matching this
  project's own inherit/override convention, so no existing category's behavior
  changed): `DebugRadius`, `FullDetailDistance`, `LabelMaxDistance`,
  `MaxFullDetailObjects`.

## Manual Verification Needed

In the Unreal Editor, with a Landscape/ActiveConfig loaded and at least one Highway
mapped (so `Roads.LaneDirection` has real points to draw):
1. Enable `Roads.LaneDirection` in the Debug Tree. Stand close to a HighwayPoint (within
   ~15m) and confirm you see the normal direction arrow; back away past 15m and confirm
   it switches to a small box instead of disappearing - that's the Impostor state.
2. `Nexus.Debug.SimulateLaneMarkerLOD 500` (Output Log) - confirm `FullDetail` in the
   logged split never exceeds `MaxFullDetailObjects` (150 by default), and note the
   logged microseconds as this phase's "before/after" number.
3. Optionally rerun with a larger count (e.g. `Nexus.Debug.SimulateLaneMarkerLOD 2000`)
   to see the timing scale.

## References

- `project-specifications/v6-master-architecture.md` (Sections 10, 22)
- `project-specifications/06-v6-debug-system.md`
- `NexusFramework_V0`'s `RoadGraphEditorLOD` namespace (`Source/NexusFrameworkEditor/
  Private/NexusRoadGraphEditorVisualizer.cpp`) — the ported precedent for this phase's
  closest-point-to-AABB distance, dual distance thresholds, impostor fallback, and
  per-frame full-detail cap.
