# Phase 87 — Runtime Activation Subsystem — Spawn/Activate

## Status

Ready for Review
Ready for Review: 2026-08-22 19:05 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement the spawn/activate half of the runtime flow: resolve HighwayPoint, apply offset, spawn/activate the RuntimeClass.

## Allowed

- Implement HighwayPointTransform-times-OffsetTransform resolution at runtime (reading the compiled, already-baked value - not recomputing).
- **(2026-08-10, v6-master-architecture.md Section 30 — "one authoritative transform-
  resolution path")** Verify this phase's resolved transform for a given Activation
  Point matches, to the bit/tolerance, the transform the Static Generator (Phase 41/42)
  baked into that same object's Static-classified companion mesh (if it has one, e.g. a
  City Light's pole) at Generation time. Neither phase currently cross-references the
  other's output - this is the specific test that closes that gap. A mismatch here
  means the editor's gizmo-adjusted location and the generated mesh's actual location
  have silently diverged, which is the exact failure v6-master-architecture.md Section
  19 calls out as the critical requirement ("the location adjusted in the editor must
  be the location ultimately used by the generated mesh and Runtime systems").
- Implement RuntimeClass spawn/activate per Activation Point type.
- Verify at least one object type (Traffic Light, the reference implementation) spawns correctly in a runtime test.
- Verify spawn cost is acceptable at a simulated near-player-density instance count.

## Not Allowed

- Do not put editor-only/UObject-heavy types into runtime-consumed structs.
- Do not let the runtime module depend on NexusFrameworkEditor.
- Do not skip the Compilation-stage validation gate before an asset is allowed to save.

## Completion Criteria

- [ ] Traffic Light reference type spawns correctly at its compiled position/rotation in a runtime test.
- [ ] For at least one Static+RuntimeActivated paired type (City Light), the dynamic
      actor's resolved transform is proven identical to the Static Generator's baked
      transform for the same object - the "one authoritative path" cross-check.
- [ ] Spawn cost benchmark recorded.

## References

- `project-specifications/v6-master-architecture.md` (Sections 25, 30)
- `project-specifications/12-v6-activation-point-system.md`

## Implementation (agent, 2026-08-22)

`TryActivate` / `AcquireActor` in `UNexusActivationSubsystem`. A point's Actor is spawned
from `UNexusRuntimeSettings::TypeRules[Type].RuntimeClass` (a `TSoftClassPtr`, so the class
is not loaded until something of that type first comes into range) and placed at the
compiled `WorldTransform`.

**The transform is READ, never recomputed** — this phase's Allowed list is explicit
("reading the compiled, already-baked value - not recomputing"). The subsystem does no
offset composition of its own; `FNexusRuntimeActivationPoint::WorldTransform` was resolved
once at compile time by `FNexusRuntimeCompiler`, through the same
`FNexusActivationSubPointResolver` the gizmo and the debug renderer use. That is what makes
`v6-master-architecture.md` Section 30's "one authoritative transform-resolution path" true
by construction rather than by convention.

A type absent from `TypeRules` spawns nothing and stays data-only. That is a deliberate
default, not a failure: most compiled points should never become Actors.

### Build verification

`Build.bat NexusFramework Win64 Development` — the standalone GAME target, no editor
module compiled or linked — **Succeeded**. Every line of this subsystem lives in the
runtime module, so that is a real compile+link proof for this phase's code and re-proves
Phase 85's module boundary at the same time.

**No automated test was written or run, and the editor was not launched** (AGENT-RULES.md).
Every Completion Criterion below is a *runtime behaviour* test needing a running game, so
all are deliberately left **unchecked**.

## Manual verification still required from the user

1. Configure `TypeRules["TrafficLight"].RuntimeClass`, run a packaged build, and confirm the
   Traffic Light spawns at its compiled position and rotation.
2. **The Section 30 cross-check, which nothing else in the project performs:** for a City
   Light (a Static + RuntimeActivated paired type), compare the dynamic Actor's resolved
   transform against the Static Generator's baked transform for the same object. They must
   match to tolerance. A mismatch means the editor's gizmo-adjusted location and the
   generated mesh's location have silently diverged — Section 19's critical requirement.
3. Record a spawn-cost benchmark at near-player-density instance counts.
