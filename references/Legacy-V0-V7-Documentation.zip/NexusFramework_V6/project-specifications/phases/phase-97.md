# Phase 97 — Testing — V5-Derived Regression Suite

## Status

Ready for Review
Ready for Review: 2026-08-22 20:40 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Build a regression suite specifically covering every V5-derived lesson referenced throughout this roadmap (cross-map identity, tangent sign, batch-mutation scoping, junction rotation risk).

## Allowed

- Enumerate every V5 lesson referenced across Phases 01-96 (search this roadmap for `03-v5-problems-and-lessons.md` references).
- Build one regression test case per lesson.
- Run the full suite and confirm all pass.
- Wire the suite for easy re-run before any future V6 release.

## Not Allowed

- No phase-specific restrictions beyond the general roadmap rules in `09-development-rules.md`.

## Completion Criteria

- [ ] Every enumerated V5 lesson has a corresponding, passing regression test.

## References

- `project-specifications/03-v5-problems-and-lessons.md`
- `project-specifications/v5-complete-reference.md`

## Implementation (agent, 2026-08-22)

Same explicit, Phase-96/97-scoped testing override as Phase 96.

`Source/NexusFrameworkEditor/Private/Tests/NexusV5LessonRegressionTests.cpp` - six tests,
each naming the lesson it guards, because a regression failure is only useful if the reader
immediately knows *which* historical bug just came back. **All 6 pass.**

| Test | V5 lesson / invariant guarded |
|---|---|
| `HighwayPointCachesNoGeometry` | Cross-map stale soft-reference - guards the *structural* fix (no cached geometry) rather than the symptom |
| `EnumMirrorsHaveNotDrifted` | Runtime/editor enum mirrors (Phases 80/89) |
| `ArraySubPointElementIndependence` | Editing element i never disturbs i+/-1 or the anchor, at N=4 |
| `PayloadSurvivesAndIsNeverSilentlyWiped` | Payload round-trip + unregistered Type must not destroy authored data |
| `DeactivationHysteresisAlwaysHolds` | Boundary-flicker thrashing, tested across pathological configs |
| `CompilationGateCatchesDuplicateIds` | Duplicate/dangling/untyped ids caught as Blocking, with no false positives |

All headless by design: pure data and reflection, no Landscape, no world, no UI. That keeps
the suite from failing for environmental reasons - the exact false-failure trap that
motivated the testing policy in the first place.

### Why the criterion is left UNCHECKED despite 6 passing tests

The criterion says "**every** enumerated V5 lesson has a corresponding, passing regression
test". Three enumerated lessons are **not** unit-testable headless, and claiming otherwise
would be the kind of false green this project has been burned by:

- **`Q.IsNormalized()` crash risk** - an engine-level bug inside Landscape Spline
  tessellation. Not reachable from our code; mitigated by documentation, not by a test.
- **No safe native selection API** (`SetSplineSelected` crashes) - guarded by never calling
  it. A test would have to call it to prove anything, which is the crash.
- **`DeleteSplinePoints()` reparents to transient** - needs a real Landscape and a real
  delete to exercise.

These are guarded structurally and by documentation. Checking the box would imply coverage
that does not exist.

## Manual verification still required from the user

Decide whether the three engine-limitation lessons above need editor-driven tests, or
whether structural mitigation is sufficient. If sufficient, the criterion can be reworded to
"every unit-testable lesson" and checked.
