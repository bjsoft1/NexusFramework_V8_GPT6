# Phase 75 — Future Object Types — Onboarding Checklist Proof

## Status

Ready for Review
Ready for Review: 2026-08-22 15:59 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Prove Phase 45's onboarding checklist by adding EVERY remaining named-but-unbuilt object type from the master prompt (Hospital, Police Station, Petrol Station, Charging Station, Service Garage) using only the documented steps - no framework changes allowed. Per v6-phase-verification.md, a pattern proven once is not the same as these being built - all five are in scope for this phase, not just one.

## Allowed

- Enumerate the five remaining not-yet-built object types (Hospital, Police Station, Petrol Station, Charging Station, Service Garage).
- Implement each following Phase 45's documented checklist exactly, timing how long each takes.
- Explicitly forbid any edit to registry/Debug/Gizmo/Compilation framework code during this phase.
- Record timing/step count per type as the onboarding-cost benchmark.
- If any single type turns out to need a framework change, stop, report it as a framework gap, and do not route around it silently - that finding is more valuable than forcing all five through.

## Not Allowed

- Do not modify any framework-level file (registry, generic renderers, generic gizmo/compilation code) during this phase - if that's required, the framework has a gap and this phase should fail and report it, not route around it.
- Do not skip any of the five without an explicit, recorded reason - silently doing only one and calling the phase complete re-creates the gap this phase exists to close.

## Completion Criteria

- [~] All five types register/visualize/edit with **zero framework-file edits** - the
      zero-edit half is fully met. **Export: NOT done for any of them** - see GAP 1
      below (no payload persistence, no Compilation stage). Recorded, not counted.
- [x] Step-count recorded per type as the onboarding-cost benchmark, and made
      re-runnable rather than only written down:
      `Nexus.Representation.DumpOnboardingBenchmark`. Result: 2 authored steps per type,
      0 framework files edited, **flat from the first type to the fifth**. Two results
      beat the checklist - the test-placement command and the debug renderer both turned
      out to need no per-type code at all (pure registry + property reflection), so the
      fifth facility's entire debug cost was one registration line.
- [x] Three framework gaps found and reported, none routed around (no framework file was
      edited to make any of them go away):
      **GAP 1** - specialized-payload PERSISTENCE unresolved (pre-existing, flagged since
      Phase 46): `UNexusConfigAsset::ActivationPoints` stores base-only values, so every
      sub-pointed type - these five, plus Traffic Light/Crosswalk/Bus Stop - is
      session-only. This is what blocks the export leg above.
      **GAP 2** (new) - the Generation-side classification is a CLOSED enum + hand-written
      switch (`ENexusStaticObjectType` + `ResolveClassification`), so classifying a new
      type's paired Static half costs edits to two framework files - the exact closed-enum
      pattern the Activation Point layer rejected, still present one layer down. Suggested
      fix: a registry-backed classification lookup mirroring `FNexusActivationTypeRegistry`.
      **GAP 3** (new, minor) - `MakeInfrastructureLeaf` is file-local, so a new renderer
      file must duplicate a small leaf factory.
      Full detail: `ai-change-audits/2026-08-22/feature-add/phase-75-onboarding-checklist-proof-five-types.md`.

## References

- `project-specifications/12-v6-activation-point-system.md`
- `project-specifications/v6-phase-verification.md`
