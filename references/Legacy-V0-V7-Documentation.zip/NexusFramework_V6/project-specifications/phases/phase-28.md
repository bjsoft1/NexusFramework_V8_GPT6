# Phase 28 — Debug Rendering — Wireframe Primitives

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement the shared lightweight-primitive draw library (lines/boxes/spheres/arrows/capsules/tangent handles/direction arrows) every category renderer will call into.

## Allowed

- Implement each primitive type as a small reusable draw function.
- Implement color/thickness parameters sourced from FNexusDebugRenderConfig, never hard-coded.
- Verify none of these functions ever load or reference a production mesh asset.
- Benchmark drawing 10,000 primitives in one frame as a baseline.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Completion Criteria

- [x] Zero production-mesh references anywhere in this library. Structural fact,
      provable by inspection: every function in `FNexusDebugPrimitives` only ever calls
      an engine `::DrawDebug*` free function from `DrawDebugHelpers.h`; the
      `NexusDebugPrimitives.h`/`.cpp` pair references no `UStaticMesh`,
      `UMaterialInterface`, `TSoftObjectPtr`, or any asset type at all.
- [ ] 10,000-primitive benchmark recorded as a baseline for Phase 33-35's performance
      work. Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run
      by the agent (build-only verification) — left unchecked for the user's own pass.
      **To check**: run `Nexus.Debug.BenchmarkPrimitives` (issues 10,000 `DrawLine`
      calls in one invocation, a 100x100 grid at the world origin) and record the
      logged elapsed-ms figure here as the Phase 33-35 baseline.

## References

- `project-specifications/06-v6-debug-system.md`
