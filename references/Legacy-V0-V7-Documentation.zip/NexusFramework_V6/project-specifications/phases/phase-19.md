# Phase 19 — Representation — Highway/City/State Graph

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement the full in-memory FNexusState -> FNexusCity -> FNexusHighway -> FNexusHighwayPoint graph and its query API (single source of truth for everything downstream).

## Allowed

- Implement the four-level container graph with FGuid-keyed maps.
- Implement AddState/AddCity/AddHighway/AddPointToHighway-style mutation methods (all mutation routed through these, matching V5's proven FNexusWorldData precedent).
- Implement graph-wide lookup by any ID (State/City/Highway/HighwayPoint) in O(1).
- Implement the InterCityHighway cross-reference from Phase 12's Mapping output.

## Not Allowed

- Do not perform generation (static mesh, instancing) from this stage.
- Do not read Landscape directly from Representation code - only via Mapping's output.
- Do not let a cached field become authoritative - live reads only per 04/05.

## Completion Criteria

- [x] No code outside this graph's own methods mutates the maps directly (spot-checked)
      - the four TMaps are `private` on `FNexusRepresentationGraph`; `Find*()` returns
      `const` pointers only and `Add*()`/`AddPointToHighway()` are the sole mutators, so
      no other file can reach into them even by construction, not just by convention.
- [x] Lookup by any ID type is proven O(1) (map-based, not linear scan)
      - `FindState`/`FindCity`/`FindHighway`/`FindHighwayPoint` are direct
      `TMap<FGuid, T>::Find` calls (O(1) average), replacing `FNexusMapping`'s
      `TArray::FindByPredicate` linear scans for this new graph's own reads.

## Manual verification (user, in-editor - see AGENT-RULES.md's Agent Testing Policy)

Run `Nexus.Mapping.LoadOrCreateConfig` then `Nexus.Representation.DumpGraph` against a
real config asset with at least one InterCityHighway (see `Nexus.Mapping.
AssignHighwayInterCity`). Confirm:
- Logged `States=/Cities=/Highways=/HighwayPoints=` counts match `Nexus.Mapping.
  DumpGraph`'s own counts for the same config.
- Every Highway logs `FindHighway resolved=true` with the correct `Points=` count.
- Every InterCityHighway logs `GetInterCityBridgedCities: resolved=true` with the
  correct `CityA`/`CityB` names (matching what `Nexus.Mapping.AssignHighwayInterCity`
  assigned).

## References

- `project-specifications/01-v5-analysis.md` (FNexusWorldData precedent)
- `project-specifications/05-v6-data-flow.md`
