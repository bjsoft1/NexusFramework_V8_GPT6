# Phase 01 — Core Structures

## Status

Complete
Ready for Review: 
In Review: 
Ready for QA: 
Complete: 2026-08-09 23:29 GMT+5:45 (+0545)

## Objective

Define the V6 core data types (State/City/Highway/HighwayPoint identity, the `-1`/`0`/
`>0` inheritance convention, `FGuid`/`Code`/`Name` split) per `05-v6-data-flow.md` —
structs and headers only, no Landscape reading, mapping, or generation logic yet.

## Design constraint carried forward from V5 (do not lose this — see below)

V5 hit a real, confirmed bug from caching/holding a soft-reference to an external engine
object across a map/level switch: a `TSoftObjectPtr` resolves by package path, independent of
which level is currently open, so right after switching maps it could resolve "successfully"
to a real, live object that actually belonged to a DIFFERENT, still-resident map — a plain
null-check couldn't tell the two cases apart. Full detail:
`project-specifications/03-v5-problems-and-lessons.md`'s "Critical bugs V5 hit and fixed"
section, and `project-specifications/v5-complete-reference.md`'s `IsControlPointOnTargetLandscape`
entry (the actual fix: validate the resolved object's `Outer`/owning-context against the
CURRENT context, not just whether it resolves at all).

**Whatever V6's core data model design turns out to be, if it holds any cached/soft reference
to an external engine object that can outlive a map/level switch (or any other context
switch), the identity/ownership validation this bug required must be designed in from this
phase's first pass — not bolted on after a similar bug is independently rediscovered.**

## Allowed

- Defining the `NexusFramework`/`NexusFrameworkEditor` header/struct skeletons for
  State/City/Highway/HighwayPoint identity fields (IDs, Code, Name) per
  `05-v6-data-flow.md`.
- Implementing the `-1` = inherit / `0` = disabled / `>0` = override resolution helper
  (most-specific-wins), carried forward from V5 unchanged.
- Writing unit-level tests for ID uniqueness and inheritance resolution in isolation
  (no Landscape/engine dependency needed for this phase's own tests).

## Not Allowed

- Reading Landscape geometry (that starts at Phase 05).
- Implementing Mapping, Representation-graph mutation methods, or any generation logic.
- Adding cached Location/Rotation/Tangent fields as authoritative data on
  `FNexusHighwayPoint` (explicitly disallowed by `04-v6-architecture.md`/
  `05-v6-data-flow.md` — geometry is always read live once Phase 18 wires the accessor).

## Completion Criteria

- [x] Core identity structs compile with zero Landscape/Slate/UnrealEd dependencies.
- [x] Inheritance-resolution helper unit-tested against Point→Highway→City→State→global
      chains, including the `0` = explicitly-disabled case.
- [x] This phase's carried-forward design constraint (above) is reflected in how any
      soft/cached external reference is designed — re-verified, not just noted, before
      Phase 08 implements the actual identity trick against it.

## Phase 01 completion note — 2026-08-09 22:22 NST (+0545)

Implemented. Full detail in `ai-change-audits/2026-08-09/feature-add/phase-01-core-structures.md`.
Summary: `FNexusState`/`FNexusCity`/`FNexusHighway`/`FNexusHighwayPoint` (identity only —
`Id`/`Code`/`Name`, no relationship or geometry fields) plus a generic
`NexusInheritance::ResolveInheritedValue` helper live in the new `NexusFrameworkEditor`
module. Criterion 3 is satisfied by construction: none of this phase's structs hold any
soft/cached external reference, so there is nothing that could go stale across a map
switch yet — the actual identity trick lands in Phase 08. Build verified with a real UBT
compile (`Result: Succeeded`) and both unit tests actually executed headlessly
(`NexusFramework.Editor.Identity.IdUniqueness` and
`NexusFramework.Editor.Inheritance.ResolveInheritedValue`, both `Result: Success`), not
just written.

## References

- `project-specifications/04-v6-architecture.md`
- `project-specifications/05-v6-data-flow.md`
- `project-specifications/03-v5-problems-and-lessons.md`
