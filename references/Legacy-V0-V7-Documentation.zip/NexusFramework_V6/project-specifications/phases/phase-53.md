# Phase 53 — Traffic Light — Debug Visualization

## Status

Ready for Review
Ready for Review: 2026-08-12 02:22 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Register Traffic Light-specific debug leaves (Traffic Light, Traffic-Light LED) under the Infrastructure group, rendering all three sub-offsets distinctly.

## Allowed

- Register both leaves via Phase 45/46's generic Activation Point debug path.
- Render Pole/VehicleLED/PedestrianLED as visually distinct markers (per master prompt's debug distinction requirement).
- Render ControlledLaneIds as connecting lines to the referenced lanes.
- Verify on the Phase 51 multi-lane test junction.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Completion Criteria

- [ ] All three sub-offsets are visually distinguishable in the viewport on the test
      junction. Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not
      run/verified by the agent this session (build-only verification) - left unchecked.
      **To check**: see "Manual verification required" below.
- [ ] Controlled-lane connections render correctly. Same manual-verification note as
      above.

## Implementation (2026-08-12)

- New file `Private/Debug/NexusDebugInfrastructureGroupRenderers.cpp` registers the
  Infrastructure group's first two leaves:
  - **`Infrastructure.TrafficLight`** - draws the Pole sub-point (a sphere + a grounding
    line back to the anchor), plus one connecting line per `ControlledLaneIds` entry out
    to that lane's resolved world position (see `ResolveControlledLaneLocation` below).
  - **`Infrastructure.TrafficLightLED`** - draws VehicleLED (fixed red) and
    PedestrianLED (fixed amber), each its own hard-coded color so the two remain
    distinguishable from EACH OTHER, not just from Pole - satisfies "all three sub-
    offsets are visually distinguishable" (Pole/VehicleLED/PedestrianLED are now three
    different colors across the two leaves, not one shared category color).
- `ResolveControlledLaneLocation` (same file) - resolves one `ControlledLaneIds` entry to
  a world position by searching the active config's `Highways` (a plain, already-in-
  memory `TArray` read - NOT a live Landscape/spline query, same precedent
  `RenderActivationPoints`'s own real-`ActivationPoints` loop already established) for the
  `FNexusLane` with that `LaneId`, then combining that Highway's SNAPSHOT-cached
  `ResolvedLaneWidth` (never re-resolves inheritance itself) with the lane's own
  `Side`/`IndexFromCenter` and the Traffic Light's anchor's own cached
  `Location`/`TangentDirection` - the identical lateral-offset formula
  `NexusDebugRoadsGroupRenderers.cpp`'s `ComputeRightVector`/`DrawOffsetPolyline` already
  use for a Highway's own centerline, applied at one specific point instead of along the
  whole Highway. Returns false (draws nothing for that entry) for a dangling/unresolvable
  reference - this renderer's job is to draw what resolves, not to flag what doesn't
  (Phase 51's `ValidateControlledReferences` already owns that).
- Deliberately does **not** touch `NexusTrafficLightActivationRegistration.cpp`'s own
  `GRegisterTrafficLight` (`DefaultDebugCategory` stays `Runtime.ActivationPoints`,
  unchanged) or `NexusDebugRuntimeGroupRenderers.cpp`'s generic `RenderActivationPoints`
  (still renders every registered type, including Traffic Light, exactly as before) - the
  two new leaves are an ADDITIONAL, richer, type-aware view, not a replacement. Toggling
  both `Runtime.ActivationPoints` and the two new Infrastructure leaves on simultaneously
  will show overlapping markers at the same 3 positions - the same accepted
  "two independently toggleable categories may draw related/overlapping content" shape
  `NexusDebugRoadsGroupRenderers.cpp`'s own `RenderJunctions` already established
  relative to `Landscape.Connections`, not a bug introduced by this phase.
- Neither new leaf opts into `IsSelectable`/`CanSupportGizmo` - selection/gizmo-editing
  remains `Runtime.ActivationPoints`' own job (Phase 48), unchanged.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. `Nexus.Representation.AddTestTrafficLight <HighwayPointId> 1` at a real multi-lane
   junction, then `Nexus.Representation.AssignTrafficLightControlledLanes
   <ActivationPointId>` (Phase 51's command) to populate `ControlledLaneIds` from real
   lane data.
2. In the Debug Tree, enable `Infrastructure > Traffic Light` and
   `Infrastructure > Traffic-Light LED`. Confirm: a Pole marker with a line grounding it
   to the anchor; separate lines from the Pole out to each controlled lane's own
   position; a red VehicleLED sphere and an amber PedestrianLED sphere at their own
   distinct offsets.
3. Confirm the label over the Pole marker shows the Traffic Light's Name (and
   `[SignalGroup]` if one was set via Phase 52's affordance).
4. Toggle `Runtime.ActivationPoints` on too - confirm it draws its own (undifferentiated,
   single-color) markers at the same 3 positions, additively, not in conflict with the
   two new leaves.
5. `Nexus.Representation.AssignTrafficLightControlledLanes <ActivationPointId>
   InjectDanglingLaneId=1` - confirm the dangling entry draws NO extra connecting line
   (silently skipped, not a crash/garbage line).

## References

- `project-specifications/06-v6-debug-system.md`
