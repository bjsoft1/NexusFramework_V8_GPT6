# Phase 22 — Representation — Validation Gate

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement 14-v6-validation.md's Representation-stage checks: dangling Highway point references, inconsistent City/State membership, dangling ActivationPoint anchors.

## Allowed

- Implement dangling-reference checks across all four graph levels.
- Implement dangling ActivationPoint -> HighwayPointId checks.
- Implement City/State membership consistency checks.
- Wire Blocking severity to prevent Generation stage from running on invalid Representation.

## Not Allowed

- Do not perform generation (static mesh, instancing) from this stage.
- Do not read Landscape directly from Representation code - only via Mapping's output.
- Do not let a cached field become authoritative - live reads only per 04/05.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — both left unchecked for the user's
own manual pass.

- [ ] A clean Representation snapshot passes with zero validation entries. **To check**:
      after Phases 10-17 have produced a fully-mapped, fully-assigned config (every
      Highway has a CityId, every City has a StateId), run `Nexus.Representation.
      ValidateStage` and confirm it logs "clean - zero validation entries."
- [ ] Each deliberate-break test case is caught as Blocking. **Not yet exercisable with
      real data**: every field this check reads (`OrderedPointIds`/`CityId`/`EndCityId`/
      `StateId`/`ConnectedHighwayIds`) is `VisibleAnywhere` (read-only in the Details
      panel, by this codebase's own identity-field convention), and no phase through 22
      implements deletion/un-mapping, so nothing in the current system can organically
      produce a dangling Representation-level reference to break against yet — the
      graph is always internally consistent when built from a config that Phases 10-17's
      own idempotent functions produced. This gate is real and will start catching
      genuine breaks once a later phase adds deletion (or hand-edits a config asset
      directly) - deliberately not building a synthetic corrupt-the-graph-for-testing
      console command to exercise it artificially now, since that would be test-only
      code (`project-specifications/AGENT-RULES.md`'s Agent Testing Policy).

## References

- `project-specifications/14-v6-validation.md`
