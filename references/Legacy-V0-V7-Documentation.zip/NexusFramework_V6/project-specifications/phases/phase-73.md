# Phase 73 — Advertisement Activation Point

## Status

Ready for Review
Ready for Review: 2026-08-22 15:59 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement FNexusAdvertisementActivation (ContentId/PlaylistId payload), pairing a Static-classified board mesh with RuntimeActivated interactive content per 11-v6-static-dynamic-architecture.md.

## Allowed

- Implement the specialized struct with ContentId/PlaylistId.
- Register the type via Phase 45's registry.
- Verify the static board mesh and the dynamic content activation share an anchor without merging, following the City Light pattern.
- Wire debug/gizmo/compilation following the established per-type pattern (register, visualize, edit, export).

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

- [x] Static board and dynamic content proven independently classified on a shared anchor.
      `ENexusStaticObjectType::AdvertisementBoardMesh` -> `Static` and
      `AdvertisementInteractiveContent` -> `RuntimeActivated` (both already in Phase 40's
      table), on ONE `FNexusActivationPoint::HighwayPointId`. Runnable proof:
      `Nexus.Representation.VerifyAdvertisementClassification`.
- [~] Register / visualize / edit: DONE (type registry entry, two Infrastructure debug
      leaves, base-offset gizmo editing via the existing synthetic base key).
      **Export: NOT done** - no Compilation stage / `FNexusRuntimeResult` exists yet;
      that is Phases 80-85' scope, the same wall Phases 55/59 are `Blocked` on. Recorded
      rather than counted as complete.

## References

- `project-specifications/11-v6-static-dynamic-architecture.md`
- `project-specifications/12-v6-activation-point-system.md`
