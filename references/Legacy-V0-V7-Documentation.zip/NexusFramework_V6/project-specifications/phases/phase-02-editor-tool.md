# Phase 02 — Editor Plugin Foundation — Landscape Mode Integration

## Status

Complete
Ready for Review: 
In Review: 
Ready for QA: 
Complete: 2026-08-10 00:45 GMT+5:45 (+0545)

## Objective

Stand up NexusFrameworkEditor as a real Editor-Only Unreal plugin whose UI appears
alongside built-in Landscape Mode — **not** a custom Editor Mode. **Architecture
correction, 2026-08-09**: this phase originally built `UNexusEdMode : UEdMode`, the
same family as Landscape Mode/Modeling Mode. That crashes for real
(`NexusFramework_V5` hit `Assertion failed: !Toolkits.Contains(NewToolkit)` in
`ToolkitManager.cpp` trying exactly this, and reverted — see
`ai-change-audits/2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md`).
This phase now builds `FNexusLandscapeModeExtension`, ported from V5's own proven fix:
detect built-in Landscape Mode via `FEditorModeTools::OnEditorModeIDChanged`, open/close
a Nomad `SDockTab` in lockstep with it. See `04-v6-architecture.md`'s "Editor surface"
section.

## Allowed

- Module split with correct Build.cs dependencies (`NexusFrameworkEditor`/
  `NexusFramework`, already registered from Phase 01 — this project is a standalone
  `.uproject`, not a `.uplugin`).
- Implement `FNexusLandscapeModeExtension`: register a Nomad tab spawner; listen for
  `FEditorModeTools::OnEditorModeIDChanged`, filtered to
  `FBuiltinEditorModes::EM_Landscape`; open the tab on entering Landscape Mode, close it
  on leaving; defer mode-manager registration until a level editor actually exists
  (mirrors the engine's own `FLevelInstanceEditorModule::StartupModule()` pattern).
- Implement the tab's content this phase (the real `SNexusFrameworkPanel` from Phase 03
  is what actually ends up hosted, since both phases were implemented together in this
  correction — see the completion note).
- Add the `UEditorSubsystem` for mode-independent persistent state
  (Initialize/Deinitialize only, no logic yet) — unaffected by this correction.
- Confirm the plugin loads cleanly and the tab opens/closes correctly when entering/
  leaving Landscape Mode in a real editor session, with zero Output Log errors.

## Not Allowed

- **Do not implement a custom `UEdMode`, `FModeToolkit`, or any competing Editor Mode**
  — this is the specific pattern this correction removes; reintroducing it reintroduces
  the crash.
- Do not implement business/generation/mapping logic behind the UI.
- Do not read real Landscape or Representation data yet.
- Do not skip ahead to wiring real data sources.

## Completion Criteria

- [x] Entering built-in Landscape Mode opens the Nexus tab; leaving it closes the tab —
      confirmed in a real, running editor, not just by log/compile evidence. Manually
      verified by the user directly in Unreal Editor, 2026-08-09/10 (see
      `ai-change-audits/2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md`'s
      2026-08-09 Correction section).
- [x] Both modules compile independently; `NexusFramework` has zero Slate/UnrealEd
      includes. Confirmed via `Build.bat` for both targets and a grep of
      `NexusFramework.Build.cs` (`Core`/`CoreUObject`/`Engine`/`InputCore`/
      `EnhancedInput` only).
- [x] Tab content (`SNexusFrameworkPanel`, see Phase 03) is confirmed hosted when the
      tab is open — same manual verification as above.

## References

- `project-specifications/04-v6-architecture.md`
- `ai-change-audits/2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md`
