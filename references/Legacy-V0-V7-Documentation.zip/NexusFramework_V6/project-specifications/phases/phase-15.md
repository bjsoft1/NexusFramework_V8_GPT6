# Phase 15 — Automatic Config Lifecycle — Plugin Enable

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Wire Phase 02's subsystem to run the full enable-time flow from 05-v6-data-flow.md: resolve LandscapeId, load/create config, run Mapping - fully automatic, zero user action.

## Allowed

- Trigger the flow on map-opened / plugin-enabled.
- Sequence: LandscapeId resolve -> config load/create -> Mapping re-run/reconcile.
- Handle the zero-Landscape-in-map case cleanly (no crash, clear log).
- Time the flow on a mid-size test Landscape and record a baseline.

## Not Allowed

- Do not generate meshes or write Landscape geometry.
- Do not treat a mapped ID as permanent before this phase's validation passes.
- Do not duplicate a Landscape control point under two different HighwayPointIds.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — left unchecked for the user's own
manual pass:

- [ ] Opening a test map with an existing config asset loads with no dialogs. **To
      check**: with a test Landscape's config already created (any prior
      `Nexus.Mapping.LoadOrCreateConfig` run), enter Landscape Mode in the editor
      (Landscape → Nexus tab should open as before - Phase 02/03, unaffected) and
      confirm the Output Log shows `FNexusMapping::RunAutomaticEnableFlow: ...` firing
      automatically with no modal dialog of any kind appearing.
- [ ] Opening a test map with no config asset creates one with defaults, no dialogs.
      **To check**: same as above but on a Landscape that has never been mapped before
      (delete its `NexusConfig` asset first if one exists - saved at
      `<LevelFolder>/<LevelName>/NexusConfig`, see 04-v6-architecture.md) - confirm entering
      Landscape Mode creates a fresh config (log shows `NewlyMappedPoints`/
      `NewlyMappedHighways` matching the Landscape's actual content) with no dialog.
- [ ] Baseline timing recorded for later Phase 90+ optimization comparison. **To
      check**: the same automatic-flow log line includes `ElapsedMs=<value>` - note
      this value somewhere for later Phase 90+ comparison (or re-run
      `Nexus.Mapping.RunAutomaticEnableFlow` manually to re-time without re-toggling
      Landscape Mode). No baseline has been recorded yet.

## References

- `project-specifications/05-v6-data-flow.md`
- `project-specifications/AGENT-RULES.md`
