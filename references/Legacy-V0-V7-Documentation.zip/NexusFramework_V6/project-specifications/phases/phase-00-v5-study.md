# Phase 00 — V5 Study

## Status

Complete
Ready for Review: 
In Review: 
Ready for QA: 
Complete: 2026-08-09

`v5-complete-reference.md` (a full, direct extraction of every public header across both V5 modules — 34 files, every type/field/method/gotcha) now exists, alongside the narrative `01-v5-analysis.md` / `02-v5-feature-inventory.md` / `03-v5-problems-and-lessons.md`. **A future agent should NOT need to open the V5 codebase to complete this phase — read the docs below instead.** Re-open this phase only if a later phase finds the reference doc is missing or wrong about something specific.

## Objective

Understand V5 well enough that V6's design decisions in later phases are informed choices,
not guesses — without needing to re-read the V5 source directly each time.

## Allowed

- Reading `v5-complete-reference.md` (the deep reference) and `01-03` (the narrative
  distillation) — this is the primary path now.
- Falling back to V5 source (`NexusFramework_V5/Source/`) or its own history
  (`NexusFramework_V5/ai-change-audits/`) ONLY if the reference doc is missing something
  needed, or a fact in it looks wrong/outdated — then correct the reference doc itself so the
  next agent doesn't hit the same gap.
- Running V5 in-editor to observe behavior firsthand, if a design question genuinely needs
  hands-on confirmation the docs can't answer.

## Not Allowed

- Writing any V6 implementation code.
- Making V6 architecture decisions (that's Phase 01+, after this phase's findings are in).
- Modifying V5's own source/behavior.
- Treating a gap in the reference doc as "go re-read all of V5" by default — check whether
  the specific fact needed is genuinely missing first; the doc is meant to be complete enough
  that this is rare.

## Completion Criteria

- [x] `v5-complete-reference.md` created — full header-level extraction (Editor Schema,
      Editor Subsystem, Editor UI, Runtime Schema, Runtime Shared), plus cross-cutting
      architectural notes.
- [x] `01-v5-analysis.md` / `02-v5-feature-inventory.md` reviewed against it.
- [x] `03-v5-problems-and-lessons.md` reviewed/corrected — includes the cross-map
      stale-`SourcePoint` bug (confirmed real, fixed in V5) and a corrected note that a
      separately-reported "still points at first landscape after map switch" claim does not
      reproduce in current V5 source.
- [x] The one naming inconsistency found (`FNexusRoadGraph` referenced only in comments,
      `FNexusWorldData` is the actual class) flagged in `v5-complete-reference.md` for the
      user to confirm rather than silently resolved.
- [ ] User has reviewed `v5-complete-reference.md` for accuracy (pending — this was authored
      by an agent reading V5 headers directly, not yet human-confirmed).

## References

- `project-specifications/v5-complete-reference.md` — **start here**
- `project-specifications/01-v5-analysis.md`
- `project-specifications/02-v5-feature-inventory.md`
- `project-specifications/03-v5-problems-and-lessons.md`
- `NexusFramework_V5/ai-change-audits/README.md` (only if the above is insufficient)
