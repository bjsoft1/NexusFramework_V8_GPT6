# Phase 80 — Runtime Compiler — HighwayPoint Export

## Status

Ready for Review
Ready for Review: 2026-08-22 18:20 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement the Compilation-stage export of HighwayPoint data itself (not just Activation Points), adding the tangent/start-end fields V5's FNexusFinalPointData was missing.

## Allowed

- Implement FNexusRuntimeHighwayPoint export with tangent in/out and start/end flag fields added, per 10-v6-runtime-schema.md's gap list.
- **(2026-08-10, v6-master-architecture.md Section 12)** Also export
  `ConnectedHighwayIds` (already a derived field on `FNexusHighwayPoint` since Phase
  18) as part of `FNexusRuntimeHighwayPoint` - the master architecture doc explicitly
  requires the Runtime Schema answer "What highways connect? What objects are
  connected?", which tangent/start-end alone cannot do. This was not part of
  10-v6-runtime-schema.md's original gap list (that audit predates the master
  architecture doc) - treat it as an additional, newly-identified export requirement
  for this phase, not optional.
- Verify exported tangent data matches Phase 06's extraction within tolerance.
- Verify exported `ConnectedHighwayIds` correctly reflects a multi-Highway junction test
  case (3+ connections at one point).
- Verify round-trip correctness (save/reload/re-read).
- Explicitly confirm this closes gap #1 from 10-v6-runtime-schema.md ("no tangent data anywhere").

## Not Allowed

- Do not put editor-only/UObject-heavy types into runtime-consumed structs.
- Do not let the runtime module depend on NexusFrameworkEditor.
- Do not skip the Compilation-stage validation gate before an asset is allowed to save.

## Completion Criteria

- [ ] Round-trip test passes with tangent data intact.
- [ ] Round-trip test passes with `ConnectedHighwayIds` intact for a 3+-way junction.
- [x] Gap-closure explicitly confirmed against 10-v6-runtime-schema.md AND against
      v6-master-architecture.md Section 12's connectivity requirement.

## References

- `project-specifications/10-v6-runtime-schema.md`

## Note — 2026-08-10 — new Editor-schema fields awaiting export

An ad-hoc user request added real editable fields to `FNexusHighwayPoint` (Editor
schema, `Source/NexusFrameworkEditor/Public/Representation/NexusHighwayPoint.h`) ahead
of this phase actually starting: `Description` (FString), `bHasCrossWalk`/
`bHasTrafficLight` (bool), `CategoryMask` (int32, bitmask of the new `ECategories`
enum - `Source/NexusFrameworkEditor/Public/Representation/NexusPointCategoryTypes.h`),
and `SubCategory` (the new `ESubCategory` enum, same header). These are Editor-schema
only today - no `FNexusRuntimeHighwayPoint`/export pipeline exists yet (this phase is
still Not Started), so nothing propagates them to a Runtime-consumed struct. When this
phase's own `FNexusRuntimeHighwayPoint` gets implemented, it must also carry these five
fields (not just the tangent/start-end/ConnectedHighwayIds fields already listed under
Allowed above) - see
`ai-change-audits/2026-08-10/feature-add/v6-ui-hierarchy-schema-improvements.md` for
the full context/reasoning (including why `ECategories` deliberately replaces V5's own
buggy `ENexusPointTarget` precedent).

## Implementation (agent, 2026-08-22)

The Compilation stage now exists. This is the phase that unblocked Phases 55/59/63/68/72,
which had been `Blocked` since 2026-08-12 on its absence.

**New runtime schema** - `Source/NexusFramework/Public/Schema/Runtime/`, in the RUNTIME
module so a cooked build can load it with no editor present:
`NexusRuntimeTypes.h`, `NexusRuntimeHighwayPoint.h`, `NexusRuntimeActivationPoint.h`,
`NexusRuntimeStationPoint.h`, `NexusRuntimeResult.h` (+ `UNexusRuntimeDataAsset`).

**New compiler** - `Source/NexusFrameworkEditor/{Public,Private}/Compilation/`.

`FNexusRuntimeHighwayPoint` carries, per this phase's Allowed list and its own 2026-08-10
note: `TangentIn`/`TangentOut`, `IsChainStart`/`IsChainEnd`, `ConnectedHighwayIds`,
`JunctionType`, and all five later-added editor fields (`Description`, `HasCrossWalk`,
`HasTrafficLight`, `CategoryMask`, `SubCategory`), plus `CellName`.

### Two decisions worth review

**1. `ConnectedHighwayIds` is RECOMPUTED at export, never copied.** The editor field of the
same name is documented as never actually maintained for real Mapping-stage output
(`2026-08-10/bug-fixed/highwaypoint-connectedhighwayids-never-populated.md`). Copying it
would have shipped empty connectivity for every real point while passing any test built on
hand-constructed fixtures - a silent failure that looks like success. The compiler rebuilds
it from live `OrderedPointIds` membership, the same live-scan `FNexusStreamingCellResolver`
uses for the same reason. `IsChainStart`/`IsChainEnd` are derived in the same pass.

**2. Runtime enums MIRROR the editor enums rather than moving or naming them.** A runtime
struct may not name an editor type. Moving `ENexusGenerationClassification`/
`ENexusJunctionType` down would change their reflected type paths, and
`FNexusHighwayPoint::CategoryMask` names one such path as a literal string in its
`UPROPERTY` meta with saved `.uasset` content already on disk - the serialization risk
`v6-coding-standard.md` says to stop at. Mirroring's one failure mode is drift, closed
structurally: `NexusRuntimeCompiler.cpp` `static_assert`s all 14 enumerators, so drift is a
compile error rather than a wrong exported byte. `ECategories`/`ESubCategory` are
deliberately NOT mirrored - the compiled point stores the raw `int32` mask and `uint8`
value, which need no enum type to be useful.

**Compilation freezes live geometry, which the editor deliberately never caches.** That is
not a re-introduction of the V5 staleness bug: V5 cached geometry in the AUTHORING
representation where it drifted from the Landscape during authoring. Here the freeze happens
at the end of the pipeline, and re-compiling is what re-reads.

**Unresolved `SourcePoint` fails the compile** rather than substituting a fallback location -
`05-v6-data-flow.md`'s "unresolved reference is a validation error, not a fallback value".

## Manual verification still required from the user

Build-verified only; the editor was not launched (AGENT-RULES.md). Needs a level with a real
mapped Landscape:

1. `Nexus.Compilation.Compile` - reports counts plus two lines written specifically for this
   phase's criteria: how many points carry a non-zero tangent / are a chain boundary, and how
   many carry `ConnectedHighwayIds` / are 3+-way junctions.
2. **Criterion 1 (tangent round-trip):** `Nexus.Compilation.CompileAndSave`, then reopen the
   saved `NexusRuntime` asset and confirm tangent values survived the save/reload.
3. **Criterion 2 (3+-way junction):** on a map with a junction of 3+ Highways, confirm that
   point's `ConnectedHighwayIds` has 3+ entries after reload. The command's
   "3+-way junctions" count tells you whether your map even has such a case - if it reports
   0, the criterion is untested regardless of what else passes.
