# Phase 30a — Debug Rendering — Curve-Accurate Segment/Offset Lines [improve/update requirement]

## Status

In Review
Ready for Review: 2026-08-10 11:10 GMT+5:45 (+0545)
In Review: 2026-08-10 15:13 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Make every debug renderer that draws a line ALONG a Highway/Landscape segment (Landscape.Segments, and Roads.Highways/Lanes/Sidewalks' shared offset-polyline helper) sample the segment's real Hermite curve — using each endpoint's actual tangent vector (direction AND length) — instead of a single straight line between the two control points' locations. Today's straight-line approximation visibly diverges from the real Landscape spline curve on any non-trivial (curved) segment, making visual QA against the actual Landscape geometry unreliable, per direct user report.

## Context (why this phase exists)

Raised 2026-08-10 during the user's own QA pass, in the same report that surfaced the
landscape-space-vs-world-space location bug (see
`ai-change-audits/2026-08-10/bug-fixed/debug-render-landscape-space-not-world-space.md`,
fixed same day). After that fix, the user could see the debug points/spheres align with
the real Landscape control points, but noted the CONNECTING line between two points
"not flow with the landscape segment tengent arc" — i.e. still a straight line where the
real Landscape spline segment curves. User confirmed this is a solved problem in V5
("we draw from landscape segment center and this is main parent and valid location
points").

Searched before adding this file: both existing renderers that draw a line along a
segment already document the straight-line behavior as a **deliberate, explicit** scope
decision, not an oversight —
`NexusDebugLandscapeGroupRenderers.cpp`'s `RenderSegments` (Phase 30, `## Completion
Criteria` literally says "Segments traces the polyline") and
`NexusDebugRoadsGroupRenderers.cpp`'s shared `DrawOffsetPolyline` helper (Phase 31, own
comment: "A straight-per-segment approximation (not curve-following), matching this
phase's own 'debug wireframe, not final mesh generation' scope"). Neither phase's own
Completion Criteria nor `06-v6-debug-system.md` ever asked for curve accuracy — this is
new scope, not a regression, hence a new phase rather than a same-day bug-fix revision
to Phase 30/31.

The reason neither renderer can already do this: `FNexusDebugSnapshotPoint` only carries
a tangent **direction** (`FNexusHighwayPoint::GetLiveTangentDirection`) — deliberately,
per that struct's own header comment ("there is no single meaningful tangent length for
a point in isolation, only a direction... a per-segment-connection value"). The real
per-segment tangent **length** (needed for a correct Hermite curve) already exists at the
Source stage (`FNexusSegmentEndpointRead::TangentVector`, Phase 06's
`FNexusLandscapeReader::EnumerateSegments`) but has never been threaded through Mapping/
Representation into the Debug snapshot — this phase's real work is building that bridge,
not just adding curve math.

## Allowed

- Add per-segment (not per-point) tangent data to `FNexusDebugRenderSnapshot` — e.g. a
  new `FNexusDebugSnapshotSegment { FVector StartLocation, EndLocation; FVector
  StartTangentVector, EndTangentVector; }`, populated in `Refresh()` by cross-referencing
  `FNexusLandscapeReader::EnumerateSegments(Landscape)` against the already-built
  `Points` snapshot (same live-resolve-once-per-Refresh() boundary every existing
  snapshot field already uses — not a new per-frame live read; Phase 30's own "no live
  Landscape reads per frame" rule is about renderers, not `Refresh()` itself, which
  already resolves `SourcePoint.LoadSynchronous()` for every point).
- Transform each segment's world-space tangent the same way Phase (2026-08-10 revision)
  fixed `FNexusHighwayPoint::GetLiveLocation`/`GetLiveRotation` — landscape-space raw
  engine values must be transformed into world space via
  `FNexusLandscapeReader::TryResolveControlPointWorldTransform` (or a segment-specific
  sibling) before use, not copied raw.
- Implement one shared cubic-Hermite sampling helper (`FNexusDebugPrimitives` or a new
  small function beside it), used by BOTH `NexusDebugLandscapeGroupRenderers.cpp`'s
  `RenderSegments` and `NexusDebugRoadsGroupRenderers.cpp`'s `DrawOffsetPolyline` — one
  curve math implementation, not two.
- Pick a fixed, reasonable sample count per segment (e.g. 8-16 subdivisions) — good
  enough to visually track a real Landscape spline curve at debug-line thickness; this is
  a debug aid, not production geometry (Phase 41's own mesh pipeline is where
  production-accurate curve geometry belongs, per Phase 31's own Not Allowed list, which
  still applies here).
- Verify against a real curved (non-straight) test Highway that the debug line visually
  tracks the actual Landscape spline curve, not just its two endpoints.

## Not Allowed

- Do not perform real mesh generation or production-accurate offset geometry here — this
  is still the Debug group (Phase 28-32's own "wireframe, not final mesh" scope), just a
  more accurate wireframe.
- Do not let any renderer function itself call live Landscape/engine APIs per frame —
  all resolution stays inside `FNexusDebugRenderSnapshot::Refresh()`, same boundary as
  every other snapshot field.
- Do not change `FNexusHighwayPoint`'s own per-point tangent contract (still direction-
  only, still correctly documented as such) — the new per-segment tangent data is
  snapshot-only, not promoted onto the Representation-stage struct.

## Implementation note

Confirmed the exact engine Hermite convention from UE 5.8 source
(`Engine/Source/Runtime/Landscape/Private/LandscapeSplines.cpp`,
`ULandscapeSplineSegment::UpdateSplinePoints`) rather than guessing: a segment's curve is
a standard cubic Hermite between its two `ULandscapeSplineControlPoint`s, where the
START connection's tangent (`Rotation.Vector() * TangentLen`) is used as-is
(`FMath::CubicInterp`'s `T0`/LeaveTangent), but the END connection's tangent is
**negated** before use (`T1`/ArriveTangent) — `FNexusSegmentEndpointRead::TangentVector`
(Phase 06) already computes the un-negated raw value for both ends uniformly, so this
phase applies the engine's own sign flip explicitly rather than baking it into Phase 06's
existing, already-shipped struct.

New `FNexusDebugPrimitives::SampleHermiteCurve` (pure math, `FMath::CubicInterp` per
sample) is the one shared curve implementation. New
`FNexusDebugSnapshotSegment`/`FNexusDebugRenderSnapshot::FindSegmentTangents` resolve and
cache real per-segment world-space tangent data once per `Refresh()` (via
`FNexusLandscapeReader::EnumerateSegments` + new
`TryResolveSegmentEndpointWorldTangent` — same landscape-space-vs-world-space fix as the
same-day location bug fix, applied to a tangent *vector* via `TransformVector`, not a
position). Both `NexusDebugLandscapeGroupRenderers.cpp`'s `RenderSegments` and
`NexusDebugRoadsGroupRenderers.cpp`'s `DrawOffsetPolyline` now sample this curve (12
subdivisions) instead of drawing one straight line; `DrawOffsetPolyline` additionally
computes a per-sample right-vector via finite-difference direction along the curve so the
lateral offset stays curve-following too. Both fall back to the original straight-line
behavior if no matching native engine segment is found for a given point pair (e.g. a
virtually-mapped pair not yet synced) — never draws nothing.

## Completion Criteria

- [ ] `Landscape.Segments` visually tracks the real Landscape spline curve (not just its
      two endpoints) on a non-trivial curved test Highway. Per
      `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
      the agent (build-only verification) — left unchecked. **To check**: tick Debug Tree
      -> Landscape -> Segments on a Highway with a real curve and confirm the debug line
      now bends WITH the visible Landscape spline curve, not a straight chord across it.
- [ ] `Roads.Highways`/`Roads.Lanes`/`Roads.Sidewalks`' offset lines also curve-follow on
      the same test Highway, staying a consistent lateral offset from the (now curved)
      centerline along its whole length, not just at the two endpoints. **To check**:
      same Highway, tick Roads -> Highways/Lanes, confirm both edges/lane lines bend with
      the curve and stay a consistent width apart along the whole curve.
- [x] One shared curve-sampling implementation is used by both the Landscape and Roads
      renderers — no duplicated Hermite-math. Structural fact:
      `FNexusDebugPrimitives::SampleHermiteCurve` is the only place `FMath::CubicInterp`
      is called anywhere in the Debug module; both renderer files call it, neither
      reimplements curve math itself.
- [x] No regression to the 2026-08-10 world-space location fix — sampled curve points
      must still land in world space, not landscape-space. Structural fact: every input
      to `SampleHermiteCurve` is already world-space by construction —
      `PointA->Location`/`PointB->Location` come from the already-fixed
      `FNexusHighwayPoint::GetLiveLocation`, and the tangent vectors come from the new
      `TryResolveSegmentEndpointWorldTangent`, which applies the same
      `ULandscapeSplinesComponent::GetComponentTransform()` used by the location fix
      (via `TransformVector` instead of `TransformPosition`, correct for a
      direction/length vector).

## References

- `project-specifications/phases/phase-30.md` (Landscape group — this phase's Segments
  leaf gains curve accuracy)
- `project-specifications/phases/phase-31.md` (Roads group — shares the same
  `DrawOffsetPolyline` straight-line limitation)
- `project-specifications/phases/phase-06.md` (Source-stage tangent extraction — the
  per-segment tangent length data this phase threads through)
- `ai-change-audits/2026-08-10/bug-fixed/debug-render-landscape-space-not-world-space.md`
  (the same-day, same-report world-space location fix this phase builds on)
- `project-specifications/06-v6-debug-system.md`
