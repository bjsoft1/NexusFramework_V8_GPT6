# Phase 44 — Static Generator — Validation Gate

## Status

In Review
Ready for Review: 2026-08-10 22:40 GMT+5:45 (+0545)
In Review: 2026-08-11 12:12 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Implement 14-v6-validation.md's Generation-stage gate: every object classified, no object silently dropped, streaming assignment consistent.

## Allowed

- Implement the unclassified-object check as a hard gate (building on Phase 40's assertion).
- Implement dropped-object detection (Representation had it, Generation produced nothing, with no explicit skip reason).
- Implement streaming-assignment consistency checks.
- Wire Blocking severity to prevent Compilation stage from running on invalid Generation output.

## Not Allowed

- Do not skip Classification tagging for any generated object.
- Do not let Generation write back to Landscape or Mapping data.
- Do not proceed to Compilation on data that failed this stage's validation gate.

## Completion Criteria

- [x] A deliberately-unclassified test object is caught as Blocking. Proven by
      `Nexus.Generation.TestValidationGateCatchesUnclassified` (calls
      `ValidateObjectTypeIsClassified(255, ...)` and confirms Blocking) - deterministic,
      no active config asset needed, can be run the moment the editor is open.
- [ ] A clean Generation pass on the standing test Landscape produces zero validation
      entries. Implemented (`Nexus.Generation.ValidateStage`) but not yet run against a
      real active config asset - manual QA, see below.

## Implementation note (2026-08-10)

Implemented `FNexusGenerationValidationGate` (`NexusGenerationValidation.h`/`.cpp` - the
header already existed from an earlier session but had no `.cpp` - dead code until now).
`ValidateGenerationStage(config)` runs two checks, same "one function per stage" shape as
`FNexusMapping::ValidateMappingStage`/`FNexusRepresentationGraph::
ValidateRepresentationStage`:

1. Unclassified-object check - every real `ENexusStaticObjectType` value passes
   `ValidateObjectTypeIsClassified` (via `UEnum::IsValidEnumValue`), re-asserting Phase
   40's own completion criterion as this stage's own gate.
2. Streaming-assignment consistency (Phase 43, landed in the same batch as this phase,
   unblocking this check - an earlier revision of the header had scoped it out as N/A) -
   every junction HighwayPoint's connected Highways must resolve to the same streaming
   cell; a mismatch is logged as a Warning (an inter-City/inter-State bridge point,
   doesn't corrupt data - `FNexusStreamingCellResolver`'s own documented tie-break still
   produces one valid answer), not Blocking.

Dropped-object detection stays deliberately deferred, same reasoning the header already
recorded before this pass: it needs a real end-to-end Generation run over live data to
mean anything, not something provable in the abstract.

"Wire Blocking severity to prevent Compilation stage from running on invalid Generation
output" - no Compilation stage exists yet to literally gate. Folded
`ValidateGenerationStage` into `FNexusDiagnostics::GatherDiagnostics` as a fourth stage
(Source/Mapping/Representation/Generation) instead - the same aggregator every other
stage's Blocking severity already flows through, and the most truthful available form of
"wired" until a real Compilation stage exists.

## Manual QA still required (cannot be performed by an agent - AGENT-RULES.md's Agent
Testing Policy)

1. With a real active config asset loaded (`Nexus.Status` confirms one), run
   `Nexus.Generation.ValidateStage` - confirm it reports 0 entries on a clean map.
2. Open the Diagnostics panel - confirm a Generation-stage entry appears there if one is
   deliberately introduced (e.g. two Highways sharing a junction point across two
   different States' Data Layers, per Phase 43's own multi-cell test map).

## References

- `project-specifications/14-v6-validation.md`
