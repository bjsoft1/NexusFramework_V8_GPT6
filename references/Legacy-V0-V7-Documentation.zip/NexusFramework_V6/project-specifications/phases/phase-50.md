# Phase 50 — Traffic Light — Data Model

## Status

In Review
Ready for Review: 2026-08-11 06:18 GMT+5:45 (+0545)
In Review: 2026-08-11 12:12 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Implement FNexusTrafficLightActivation per 12-v6-activation-point-system.md: Pole/VehicleLED/PedestrianLED sub-offsets, replacing V5's single-offset FNexusDynamicInteractable shape.

## Allowed

- Implement the specialized struct with three distinct sub-offsets (Pole/VehicleLED/PedestrianLED).
- Register the type via Phase 45's registry.
- Verify each sub-offset composes independently against the shared HighwayPoint anchor.
- Compare explicitly against V5's FNexusDynamicInteractable to confirm this is a strict superset, not a rewrite from nothing.

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

- [ ] Three sub-offsets are proven independently editable and independently rendered.
      **Not yet manually verified in-editor** - see Implementation section below for the
      exact console command + what to check (this agent cannot launch the editor,
      `AGENT-RULES.md`'s Agent Testing Policy).
- [x] Explicit written comparison against V5's shape confirms superset relationship -
      see Implementation section below.

## References

- `project-specifications/10-v6-runtime-schema.md`
- `project-specifications/12-v6-activation-point-system.md`

## Implementation (2026-08-11)

**Changes** (all new files, nothing existing modified):

- `Public/Representation/NexusTrafficLightActivation.h` - `FNexusTrafficLightActivation`,
  a `USTRUCT` with exactly three `FNexusSubPointOffset` members (`Pole`/`VehicleLED`/
  `PedestrianLED`), no other fields - `ControlledLaneIds`/`ControlledRoadIds`/
  `SignalGroup` (also listed for this struct in `12-v6-activation-point-system.md`'s own
  diagram) are deliberately NOT added here; they belong to `phase-51.md`/`phase-52.md`.
- `Private/Representation/NexusTrafficLightActivationRegistration.cpp` - registers the
  type (`FName("TrafficLight")`, `ENexusGenerationClassification::RuntimeActivated`,
  `DefaultDebugCategory=FName("Runtime.ActivationPoints")` - the SAME existing,
  already-registered, already gizmo-enabled category real ActivationPoints use, not a
  new dedicated one; `UNexusActivationGizmoTool`'s test-store click-test reads this
  field to gate `IsSelectable`/`CanSupportGizmo`, so pointing it at a not-yet-registered
  category would have made this type gizmo-unselectable until `phase-53.md` eventually
  registers one - reusing the existing category keeps THIS phase's own "independently
  editable" criterion provable today; a dedicated category is a one-line change for
  Phase 53 to make later if warranted) via Phase 45's `FNexusActivationTypeAutoRegister`,
  same lazy-`PayloadStructTypeGetter`-lambda pattern
  `NexusActivationDummyTypesRegistration.cpp` already established (required - a bare
  `::StaticStruct()` call here would repeat the exact module-load crash documented in
  `ai-change-audits/2026-08-10/research/
  editor-shutdown-crash-live-coding-new-reflected-types.md`). Also adds
  `Nexus.Representation.AddTestTrafficLight <HighwayPointId> [AlwaysDraw]` - a
  session-only test-store command (never persisted), mirroring
  `AddTestActivationPointArrayConsoleCommand`'s own precedent exactly.

**Why no renderer/gizmo/persistence code was needed** - `FNexusTrafficLightActivation`
follows the exact same "payload struct declares sub-point fields, base struct stays on
`FNexusActivationPoint`" shape the Phase 45 dummy types already proved. Both
`NexusDebugRuntimeGroupRenderers.cpp`'s `RenderActivationPoints` (Phase 46) and
`UNexusActivationGizmoTool::FindClosestSubPointHit`'s test-store loop (Phase 48) are
fully generic over `FNexusActivationTypeRegistry` - neither contains any per-type
branching. Registering `FNexusTrafficLightActivation` therefore makes it automatically
debug-renderable and gizmo-draggable via `Nexus.Representation.AddTestTrafficLight`
alone, with zero new rendering/gizmo/persistence code - proving the registry's own
"zero-edit extensibility" design goal for its first REAL (non-dummy) type, not just the
two synthetic dummy types Phase 45 originally used to prove it. Real persistence on
`UNexusConfigAsset` remains explicitly open (per that array's own header comment,
"remains open for Phase 50+ when a real specialized type first needs it") - this phase
provides the struct/registration a later phase's persistence design can target, it does
not decide that design itself (matching this phase's own Allowed list, which does not
ask for persistence work).

**Explicit written comparison against V5's `FNexusDynamicInteractable`** (Completion
Criterion 2, `project-specifications/10-v6-runtime-schema.md`'s own field table):

| V5 `FNexusDynamicInteractable` field | V6 equivalent | Notes |
|---|---|---|
| `HighwaySplinePointId` | `FNexusActivationPoint::HighwayPointId` (base) | Same anchor role, unchanged. |
| `OffsetLocation`/`OffsetRotation` (exactly one pair) | `FNexusActivationPoint::OffsetLocation`/`OffsetRotation` (base) | Same "main" offset - preserved, not dropped. |
| *(none - V5 had no second/third position)* | `FNexusTrafficLightActivation::Pole`/`VehicleLED`/`PedestrianLED` (3 new independent `FNexusSubPointOffset` pairs) | **The actual gap this phase closes** - V5 could describe exactly one position per interactable; a real traffic light needs three (pole + vehicle-facing head + pedestrian-facing head), confirmed impossible in V5's shape (`10-v6-runtime-schema.md`'s own "Confirmed gaps" list, item 2). |
| `InteractableType` (closed 4-value enum: TrafficLight/HighwayLight/NewsTv/AdsBoard) | `FNexusActivationPoint::Type` (open `FName` registry key) | `"TrafficLight"` is now one registered entry in an open-ended registry, not a hardcoded enum branch - adding a 5th type never requires editing this type or any switch statement. |
| `ActivationDistance` | `FNexusActivationPoint::ActivationDistance` (base) | Unchanged, `-1`=default convention preserved. |
| `ActiveTimes` (bitmask) | `FNexusActivationPoint::ActiveTimes` (base) | Unchanged (V6 additionally has `DeactivationTimes`, a 2026-08-10 addition unrelated to this phase). |

**Conclusion**: every field V5's `FNexusDynamicInteractable` had maps directly onto an
existing V6 base field - nothing is lost or reduced. V6 additionally provides three
independently-editable named positions (Pole/VehicleLED/PedestrianLED) V5 could not
express at all (limited to exactly one position). This is a strict superset, confirmed
field-by-field, not assumed.

**Build**: `Build.bat NexusFrameworkEditor Win64 Development` succeeded, zero
warnings/errors.

### Manual verification required (this agent cannot launch the editor - `AGENT-RULES.md`)

1. In a level with a mapped Landscape, get a real `HighwayPointId` (e.g. from
   `Nexus.Representation.DumpJunctionClassification`'s log output).
2. Run `Nexus.Representation.AddTestTrafficLight <HighwayPointId>`.
3. Enable `Runtime.ActivationPoints` in the Debug Tree. Confirm **three** separate
   wireframe spheres render near the anchor (Pole straight up, VehicleLED
   forward/lower, PedestrianLED backward/lower) - proves independent rendering.
4. Click each sphere in turn. Confirm the gizmo selects and drags exactly that one
   sub-point (its own label shows `Test Traffic Light.Pole` /
   `Test Traffic Light.VehicleLED` / `Test Traffic Light.PedestrianLED`) without moving
   the other two or the shared anchor - proves independent editability.
5. Run `Nexus.Representation.DumpActivationTypeRegistry` and confirm `TrafficLight`
   appears with `DeclaredSubPointFields=3` (`Pole`, `VehicleLED`, `PedestrianLED`, all
   `Fixed`).
