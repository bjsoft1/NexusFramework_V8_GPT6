# Phase 43 — Static Generator — Streaming/Data Layer Grouping

## Status

In Review
Ready for Review: 2026-08-10 22:40 GMT+5:45 (+0545)
In Review: 2026-08-11 12:12 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Implement per-streaming-cell grouping for generated Static/Instanced output, reusing V5's DataLayerAssetName precedent for World Partition integration.

## Allowed

- Implement streaming-cell assignment per generated object (by State's DataLayerAssetName equivalent).
- Verify generated meshes/instances are correctly assigned to their owning streaming unit.
- Test with a multi-cell synthetic test map.
- Verify a cell can be unloaded/reloaded without affecting other cells' generated content.

## Not Allowed

- Do not skip Classification tagging for any generated object.
- Do not let Generation write back to Landscape or Mapping data.
- Do not proceed to Compilation on data that failed this stage's validation gate.

## Completion Criteria

- [ ] Multi-cell test proves correct per-cell assignment. **Implemented, not yet run
      against a real multi-cell map** - see Implementation note below.
- [ ] Unload/reload of one cell leaves others provably unaffected. **Mechanism
      implemented (separate host actor per cell, real Data Layer assignment where
      available), not yet manually verified in-editor** - see Manual QA below.

## Implementation note (2026-08-10)

Added `FNexusState::DataLayerAssetName` (V5's own field, carried over unchanged - see
`10-v6-runtime-schema.md`) and a new `FNexusStreamingCellResolver`
(`Public/Generation/NexusStreamingCellResolver.h`) - the single place that resolves
"which streaming cell does this Highway/HighwayPoint belong to" by walking Highway ->
City -> State (only State carries the field, no per-Highway/City override chain). Wired
into both pipelines:

- **Static** (`NexusStaticGeneratorCommands.cpp`) - generated `UStaticMesh` package paths
  now nest under `/Game/NF/Generated/<Cell>/Highways/...` instead of one flat folder
  ("Default" for an unset cell). Asset-only output (Phase 41's own scope) has no level
  actor to assign a real Data Layer to - real per-object World Partition streaming for
  baked static geometry is Phase 83's own job ("reusing Phase 43's grouping"), not this
  phase's.
- **Instanced** (`NexusInstancingGenerator`/`NexusInstancingGeneratorCommands.cpp`) -
  `ANexusGeneratedInstancedMeshHost` now spawns ONE actor PER resolved streaming cell
  (new `StreamingCellName` field) instead of one shared actor for the whole world - this
  is the actual mechanism behind "a cell can be unloaded/reloaded without affecting
  others" (Data Layers stream whole actors). Each new host is best-effort assigned to a
  real `UDataLayerInstance` matching its cell name via `UDataLayerEditorSubsystem`
  (new `DataLayerEditor` module dependency) if the world is World-Partition-enabled and a
  Data Layer with that name already exists - a non-WP test map, or no matching Data
  Layer yet, is a logged no-op, not an error; name-based grouping (separate host actors)
  still holds either way.
- New read-only `Nexus.Generation.DumpStreamingCellAssignment` console command logs every
  Highway/HighwayPoint's own resolved cell - the tool for the "multi-cell test" criterion
  above, not yet run against a real multi-State test map.
- Phase 44's `ValidateGenerationStage` (implemented in the same batch) flags a junction
  HighwayPoint whose connected Highways resolve to different cells as a Warning (an
  inter-City/inter-State bridge point) rather than hiding the tie-break silently.

## Manual QA still required (cannot be performed by an agent - AGENT-RULES.md's Agent
Testing Policy)

1. Build a synthetic test map with >= 2 States, each with a distinct
   `DataLayerAssetName` set to a real Data Layer instance created in that map's World
   Partition (Data Layer Outliner).
2. Run `Nexus.Generation.DumpStreamingCellAssignment` - confirm each Highway/HighwayPoint
   reports the expected cell.
3. Run `Nexus.Generation.GenerateHighwayMeshes` - confirm assets land under
   `/Game/NF/Generated/<Cell>/Highways/` per State, in the Content Browser.
4. Run `Nexus.Generation.GeneratePoleInstances` - confirm one
   `ANexusGeneratedInstancedMeshHost_<Cell>` actor exists per State in the World
   Outliner, each assigned to that State's own Data Layer (Data Layer Outliner should
   show the host actor under the right Data Layer).
5. Unload one Data Layer (Data Layer Outliner) - confirm only that cell's host actor
   (and its instances) disappear from the viewport/World Outliner, others unaffected.
   Reload it - confirm it comes back correctly.

## References

- `project-specifications/10-v6-runtime-schema.md` (DataLayerAssetName precedent)
