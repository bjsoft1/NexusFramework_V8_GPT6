# Phase 81 — Runtime Compiler — Activation Point Export

## Status

Ready for Review
Ready for Review: 2026-08-22 18:20 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement the generic Compilation-stage export path for ActivationPoints, replacing the per-type manual wiring done in Phases 55/59/63/68/72/73/74 with one generic exporter driven by the type registry.

## Allowed

- Implement a generic export function iterating the Phase 45 registry, replacing per-type export code where possible.
- Verify every object type built through Phase 75 still exports correctly through this generic path.
- Measure and record any export-time performance difference vs. the original per-type code.
- Remove now-redundant per-type export code once the generic path is verified equivalent.

## Not Allowed

- Do not put editor-only/UObject-heavy types into runtime-consumed structs.
- Do not let the runtime module depend on NexusFrameworkEditor.
- Do not skip the Compilation-stage validation gate before an asset is allowed to save.

## Completion Criteria

- [ ] Every implemented object type round-trips correctly through the generic exporter.
- [x] Redundant per-type export code removed with no regression.

## References

- `project-specifications/10-v6-runtime-schema.md`
- `project-specifications/12-v6-activation-point-system.md`

## Implementation (agent, 2026-08-22)

`FNexusRuntimeActivationPoint` + one generic, registry-driven exporter. No per-type export
code exists anywhere.

**How a specialized payload exports without per-type code.** `ExportPayloadFieldsGenerically`
reflects over the payload `USTRUCT` and lands each property in a name-keyed container:
`FGuid`/`TArray<FGuid>` -> `References` (Traffic Light's `ControlledLaneIds`/
`ControlledRoadIds`, Crosswalk's light linkage); numerics/bools -> `NumericFields`;
`FName`/`FString` -> `NameFields`; soft object refs -> `AssetFields`. Offsets are skipped
here and exported through the existing sub-point resolver instead, so the same data never
ships in two shapes.

Sub-points carry their `(FieldName, ArrayIndex)` key, satisfying Phase 80a's requirement that
this round-trip be checkable **by NAME** - a consumer asks for `Pole` or
`PedestrianWaitingPoints[2]`, so a compile that silently dropped or reordered a field fails
the lookup instead of returning the wrong offset.

Gaps closed: **#2** (one offset pair per interactable - now N named sub-points), **#4**
(fixed 4-value type enum - `Type` is an `FName` from the registry, so a new type ships with
zero edits here), **#6** (no classification tag - `Classification` is exported).

### On "remove now-redundant per-type export code"

Checked and marked done, but the honest reason is that **there was none to remove**. The
per-type export wiring this phase was written to replace (Phases 55/59/63/68/72) was never
implemented - all five were `Blocked` on the Compilation stage not existing. So the generic
path is the first and only export path, not a replacement for one. Recorded plainly rather
than checked off as though a migration happened.

## Manual verification still required from the user

`Nexus.Compilation.Compile` on a level containing a Traffic Light, a Crosswalk and a Bus
Stop; confirm each type's payload fields appear by name in the compiled output, then
`CompileAndSave` and confirm they survive reload.
