# Phase 38 — Validation — Landscape/Mapping Combined Gate

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 11:08 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Combine and harden Phases 09 and 14's individual gates into the single Landscape-Read + Mapping validation checkpoint 14-v6-validation.md describes as one pipeline stage.

## Allowed

- Merge the two prior gates' checks into one callable validation pass.
- Verify Blocking severity from either sub-check correctly halts progression to Representation.
- Add any check identified as missing from the individual phases' test coverage.
- Re-run all prior deliberate-break test cases against the combined gate.

## Not Allowed

- Do not generate meshes or write Landscape geometry.
- Do not treat a mapped ID as permanent before this phase's validation passes.
- Do not duplicate a Landscape control point under two different HighwayPointIds.

## Implementation note

`FNexusMapping::ValidateLandscapeMappingCombinedGate(Landscape, Config)`
(`NexusMapping.CombinedGate.cpp`, console command `Nexus.Mapping.ValidateCombinedGate`)
calls `FNexusLandscapeReader::ValidateSourceStage` and `ValidateMappingStage` and
returns both stages' entries as one `TArray<FNexusMappingValidationEntry>` - Source
entries are converted field-by-field (the two per-stage structs are already identical
in shape) rather than introducing a fourth near-duplicate type, keeping this project's
existing "each pipeline stage gets its own validation-entry type" precedent intact.

`FNexusDiagnostics::GatherDiagnostics` deliberately still calls the two stage gates
separately, not through this combined function - it needs each entry's own originating
stage (Source vs Mapping) for its per-entry `StageName` field in the Diagnostics Panel,
which the merged result intentionally discards. This is retaining finer-grained
information the Panel already relies on, not a bypass of the new gate.

## Completion Criteria

- [x] All prior test cases (Phases 09 and 14) still correctly caught by the combined
      gate. Structural fact: the combined gate is a straight concatenation of both
      original functions' own results (Source entries copied field-by-field into the
      Mapping-shaped struct, Mapping entries appended verbatim) - no filtering,
      deduplication, or mutation happens in between, so anything either original gate
      would produce, the combined gate still produces, unchanged.
- [ ] The combined gate is the single entry point Representation-stage code calls - no
      bypass path exists. **Partially true by construction, needs a wording caveat**:
      this is now the one function anything wanting "the full Landscape+Mapping
      picture" should call (and the new `Nexus.Mapping.ValidateCombinedGate` command
      does). But — same as Phase 09/14/22's own gates before it — nothing technically
      *blocks* Representation's `PopulateFromConfigAsset` from running regardless of
      validation results; every validation gate in this project so far is advisory
      (surfaced via console commands/Diagnostics), not a hard-wired pipeline block. **To
      check**: run `Nexus.Mapping.ValidateCombinedGate` against a config with at least
      one known Source-stage issue and one known Mapping-stage issue (see Phase 09/14's
      own break-test recipes) and confirm both appear together in one call's output.

## References

- `project-specifications/14-v6-validation.md`
