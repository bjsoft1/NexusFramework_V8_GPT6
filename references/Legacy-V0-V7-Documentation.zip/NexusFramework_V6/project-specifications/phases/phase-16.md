# Phase 16 — Automatic Config Lifecycle — Reconciliation

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Handle the case where the config asset's stored mappings and the Landscape's current live state have diverged since last session (edits made while the plugin was off, or via native tools only).

## Allowed

- Detect config-asset entries whose control point no longer resolves.
- Detect live control points with no matching config-asset entry (new since last session).
- Reconcile: flag broken entries (never silently drop - per validation doc), map new points automatically.
- Surface reconciliation results in a log/list for the Diagnostics Panel to pick up later.

## Not Allowed

- Do not generate meshes or write Landscape geometry.
- Do not treat a mapped ID as permanent before this phase's validation passes.
- Do not duplicate a Landscape control point under two different HighwayPointIds.

## Revision — 2026-08-10 (same day, after this phase was already Ready for QA)

This phase's original scope was point-level only ("control point no longer resolves" /
"new since last session") - it never checked whether a previously-known Highway's own
point-chain still corresponds to a live, connected sequence of Landscape spline
segments. User testing surfaced exactly this gap: a highway/divider connecting two
points already shared with an unrelated closed loop, once its segment is deleted
natively, leaves both endpoints still resolvable (they're still loop members) - so this
function's existing broken-entry detection (point-SourcePoint-resolution only) never
caught it, and `MapHighways` (Phase 11) has no removal path at all (it only ever
appends). `ReconcileMappingStage` now also calls the same
`FNexusMapping::DoesHighwayChainMatchLiveLandscape` check Phase 14's
`ValidateMappingStage` uses (see that phase's own 2026-08-10 Revision), appending to
`BrokenEntries` for any previously-known Highway that no longer matches - same "flag it,
never silently drop it" contract this phase already used for points, just extended to
Highways. Full writeup:
`ai-change-audits/2026-08-10/bug-fixed/stale-highway-not-detected-on-landscape-removal.md`.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — left unchecked for the user's own
manual pass:

- [ ] **(New, 2026-08-10)** A previously-known Highway whose segment was deleted/
      rerouted natively, while its own points remain individually resolvable, is
      reported as a `[BROKEN]` entry on the next `Nexus.Mapping.ReconcileMappingStage`
      run - not silently absent from the report, and not removed from
      `Config.Highways`. **To check**: map a closed loop, draw a highway connecting two
      of the loop's existing points, run `Nexus.Mapping.ReconcileMappingStage` once so
      it's registered (appears as `[NEW]`), delete just that connecting segment
      natively, then re-run `Nexus.Mapping.ReconcileMappingStage` again - confirm it now
      logs a `[BROKEN]` entry naming that Highway, and that the Highway still exists in
      `Config.Highways`/`Nexus.Mapping.DumpGraph` afterwards (reported, not dropped).
- [ ] A deliberately-diverged test config (one entry manually broken, one new point
      added natively) reconciles correctly: broken entry flagged, new point mapped.
      **To check**: with a config already mapped, delete a control point that a
      `HighwayPoint.SourcePoint` still references (or move it to a different,
      still-resident map) AND add a brand-new spline control point via the native
      Landscape Splines tool, then run `Nexus.Mapping.ReconcileMappingStage` (Output
      Log console) - confirm it logs exactly one `[BROKEN]` entry for the deleted
      point's `HighwayPoint` and one `[NEW]` entry for the newly-added point (which is
      now mapped with a real `HighwayPointId`, confirmable via `Nexus.Mapping.
      DumpGraph`).
- [ ] No data is silently dropped. **To check**: after the broken-entry test above,
      confirm the broken `HighwayPoint` entry still exists in `Nexus.Mapping.DumpGraph`/
      the config asset's own array (it's reported, not removed) - `Nexus.Mapping.
      ValidateMappingStage` (Phase 14) is what should be relied on to keep flagging it
      Blocking on every subsequent run, not this phase silently cleaning it up.

## References

- `project-specifications/05-v6-data-flow.md`
- `project-specifications/14-v6-validation.md`
- `project-specifications/AGENT-RULES.md`
