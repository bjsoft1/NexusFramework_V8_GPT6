# Phase 91 — Optimization — Debug System at Scale

## Status

Ready for Review
Ready for Review: 2026-08-22 20:40 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Re-run Phase 35's 50+-category stress test now that all real object types (Phases 50-75) are registered, not just dummy categories - confirm real-world numbers hold.

## Allowed

- Run the full Debug tree/rendering/config system with every real registered category from Phases 30-74.
- Profile against the Phase 33/34 performance baselines.
- Fix any regression found.
- Record final real-category-count timing as the release baseline.

## Not Allowed

- Do not optimize a subsystem that hasn't been correctness-verified first.
- Do not introduce caching that can silently go stale (see the V5 lessons doc for why this matters).

## Completion Criteria

- [ ] Full real-category stress test meets or beats the dummy-category baselines from Phase 35.

## References

- `project-specifications/06-v6-debug-system.md`

## Static at-scale audit (agent, 2026-08-22)

The premise this phase was written against has changed in a way worth recording: it asks to
re-run Phase 35's stress test "now that all real object types are registered, not just dummy
categories". There are now **14 registered Activation Point types**, but they very
deliberately share a **single** Debug category (`Runtime.ActivationPoints`) - confirmed by
`Nexus.Gizmo.AuditTypeConsistency` and by the Phase 79 audit, which found
`CanSupportGizmo = true` set in exactly one place in the codebase.

So the real-category count did **not** grow the way this phase anticipated. Category count
is driven by the Debug tree's own registrations (Landscape/Roads/Mapping/Infrastructure/
Runtime/Diagnostics groups and their leaves), not by object-type count. That makes the
"50+ real categories vs 50 dummy categories" comparison this phase assumes less direct than
its text implies - worth knowing before interpreting the numbers as a regression.

No renderer changes were made. `Nexus.Debug.ProfileRenderers` and
`Nexus.Debug.BenchmarkPrimitives` already exist as the measurement surface.

**No profiling run was performed.** An agent cannot run the editor for automation
(AGENT-RULES.md), and "at scale" is a *measured* property - so this phase's criteria are
left **unchecked**. What was done instead is a static at-scale audit: reading the code for
algorithmic hazards that only bite at large N, and fixing what that found. That is real work
and it is build-verified, but it is not the measurement this phase asks for.

## Manual verification still required from the user

1. `Nexus.Debug.DumpCategoryRegistry` - record the actual real-category count.
2. `Nexus.Debug.ProfileRenderers` with every category visible; compare against Phase 33/34
   baselines.
3. If the count is materially lower than Phase 35's dummy-category test used, re-run
   `Nexus.Debug.RegisterStressTestCategories` alongside the real ones so the comparison is
   like-for-like rather than flattering.
