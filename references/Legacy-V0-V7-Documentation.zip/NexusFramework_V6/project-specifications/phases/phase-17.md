# Phase 17 — Automatic Config Lifecycle — Multi-Landscape Support

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Verify and harden the lifecycle for a map containing more than one Landscape actor (each gets its own LandscapeId and config asset, fully independent).

## Allowed

- Verify LandscapeId derivation is unique per Landscape actor in a multi-Landscape test map.
- Verify each Landscape's Mapping/Representation stays fully isolated from the others.
- Verify the UI (Phase 03/04 shell) can distinguish/select between Landscapes if more than one exists.
- Document the single-Landscape-per-map assumption if V6's first version deliberately narrows scope here.

## Not Allowed

- Do not generate meshes or write Landscape geometry.
- Do not treat a mapped ID as permanent before this phase's validation passes.
- Do not duplicate a Landscape control point under two different HighwayPointIds.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — left unchecked for the user's own
manual pass, except where noted:

- [ ] A two-Landscape test map produces two independent config assets with zero
      cross-contamination. **To check**: build/open a test map with two `ALandscape`
      actors, run `Nexus.Mapping.LoadOrCreateConfig` (Output Log console) - confirm it
      logs a Warning naming both Landscapes and picking the first one, then run
      `Nexus.Mapping.MapControlPoints`/`.MapHighways` and confirm only the first
      Landscape's points/Highways appear in `Nexus.Mapping.DumpGraph`. There is
      currently no way to point the flow at the SECOND Landscape instead (no picker UI
      exists yet - see this phase's own scope decision below), so "zero
      cross-contamination" for now means confirming the ignored Landscape's data never
      appears mixed into the first one's config, not that both are independently
      mappable in the same session.
- [x] Explicit scope decision recorded (support N Landscapes, or document as a known
      first-version limitation). Done this session: V6 maps exactly one `ALandscape`
      per open map (the first found); a second+ Landscape is logged as a Warning, not
      silently ignored, and `LandscapeId`/config-asset resolution is already
      per-Landscape-actor by construction so lifting this later needs only a picker UI,
      not a data-model change. Recorded in
      `project-specifications/04-v6-architecture.md`'s new "Multi-Landscape scope"
      section and `FNexusLandscapeReader::ResolveActiveLandscape`'s own comment.

## References

- `project-specifications/04-v6-architecture.md`
- `project-specifications/AGENT-RULES.md`
