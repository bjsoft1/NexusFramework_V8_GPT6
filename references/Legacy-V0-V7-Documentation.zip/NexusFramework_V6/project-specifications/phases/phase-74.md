# Phase 74 — TV / Interactive Screen Activation Point

## Status

Ready for Review
Ready for Review: 2026-08-22 15:59 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement the TV/NewsTv activation type, reusing V5's ENexusDynamicInteractableType::NewsTv precedent but through the generalized registry instead of a closed enum.

## Allowed

- Implement the specialized struct (content reference, activation distance override).
- Register the type via Phase 45's registry.
- Wire debug/gizmo/compilation following the established pattern.
- Confirm this proves the registry replaces V5's fixed 4-value enum without losing any of its original coverage (TrafficLight/HighwayLight/NewsTv/AdsBoard all now representable).

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

- [~] Register / visualize / edit: DONE. **Export: NOT done** - no Compilation stage
      exists yet (Phases 80-85' scope, same wall as Phases 55/59).
- [x] Written confirmation that all four of V5's original ENexusDynamicInteractableType
      values are now representable through the registry: TrafficLight -> `TrafficLight`,
      HighwayLight -> `CityLight`, NewsTv -> `Tv` (this phase), AdsBoard ->
      `Advertisement` (Phase 73). Checked against the LIVE registry, not asserted in
      prose: `Nexus.Representation.VerifyV5InteractableCoverage`.

## References

- `project-specifications/10-v6-runtime-schema.md`
- `project-specifications/12-v6-activation-point-system.md`
