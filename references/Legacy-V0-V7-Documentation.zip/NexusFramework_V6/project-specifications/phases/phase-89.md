# Phase 89 — Runtime Activation Subsystem — ActiveTimes/Distance Rules

## Status

Ready for Review
Ready for Review: 2026-08-22 19:05 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Wire ActiveTimes (day/night/afternoon/midnight, carried from V5) and per-instance ActivationDistance overrides into the runtime activation decision.

## Allowed

- Implement ActiveTimes bitmask evaluation against the current world-clock state.
- Implement -1-inherits-global / >0-override ActivationDistance resolution at runtime -
  this field is what `v6-master-architecture.md` Section 26 calls `ActivationRadius`;
  same concept, keep V5's existing `ActivationDistance` name (already shipped as a base
  `FNexusActivationPoint` field, per 12-v6-activation-point-system.md) rather than
  introducing a second, differently-named field for the same value.
- **(2026-08-10)** Confirm this phase's `ActivationDistance` and Phase 88's new
  `DeactivationRadius` are resolved through the same per-instance-override mechanism (a
  per-instance override on one must not silently leave the other at a global default) -
  document the relationship explicitly.
- Verify a test object correctly activates/deactivates as simulated time-of-day changes.
- Verify a per-instance distance override is respected over the global default.

## Not Allowed

- Do not put editor-only/UObject-heavy types into runtime-consumed structs.
- Do not let the runtime module depend on NexusFrameworkEditor.
- Do not skip the Compilation-stage validation gate before an asset is allowed to save.

## Completion Criteria

- [ ] Time-of-day test case activates/deactivates correctly across all four ENexusActiveTimes values.
- [ ] Distance-override test case proven respected.

## References

- `project-specifications/10-v6-runtime-schema.md` (ENexusActiveTimes precedent)

## Implementation (agent, 2026-08-22)

`IsActiveAtCurrentTime` + `SetTimeOfDay`, and the shared distance-resolution mechanism.

**ActiveTimes/DeactivationTimes ship as raw `int32` bitmasks**, so no enum crosses the
module boundary. `ENexusRuntimeTimeOfDay` mirrors the editor's `ENexusActiveTimes`
value-for-value, guarded by four `static_assert`s in `NexusRuntimeCompiler.cpp`. Worth the
guard: a drift here would not crash, it would light objects at the wrong time of day —
far harder to notice than a crash.

Evaluation order: `DeactivationTimes` is checked **first** and wins over `ActiveTimes` for
the same bucket. That is what expresses V5's removed `MidnightAutoDisabled` case generally —
a light on at night but forced off at midnight is
`ActiveTimes = Night|Midnight, DeactivationTimes = Midnight`. `ActiveTimes == 0` means "no
time restriction authored", not "never active".

**The relationship this phase asks to be documented explicitly:** `ActivationDistance` and
Phase 88's `DeactivationRadius` resolve through the *same* most-specific-wins chain — the
point's own value, then the type rule, then the global — and
`ResolveDeactivationRadius` calls `ResolveActivationDistance` internally to derive its
clamp. So a per-instance override on one can never silently leave the other at a global
default; the second is always computed relative to the first.

The subsystem does not invent its own clock. `SetTimeOfDay` is called by whatever owns the
day/night cycle, and forces a re-evaluation rather than waiting on the `UpdateDistance` gate.

### Build verification

`Build.bat NexusFramework Win64 Development` — the standalone GAME target, no editor
module compiled or linked — **Succeeded**. Every line of this subsystem lives in the
runtime module, so that is a real compile+link proof for this phase's code and re-proves
Phase 85's module boundary at the same time.

**No automated test was written or run, and the editor was not launched** (AGENT-RULES.md).
Every Completion Criterion below is a *runtime behaviour* test needing a running game, so
all are deliberately left **unchecked**.

## Manual verification still required from the user

1. Cycle a test object through all four `ENexusActiveTimes` buckets via `SetTimeOfDay` and
   confirm it activates/deactivates correctly at each.
2. Confirm the `DeactivationTimes`-overrides-`ActiveTimes` case behaves as described (the
   old MidnightAutoDisabled scenario).
3. Set a per-instance `ActivationDistance` and confirm it is respected over the global —
   and that the point's `DeactivationRadius` moved with it rather than staying at the
   global default.
