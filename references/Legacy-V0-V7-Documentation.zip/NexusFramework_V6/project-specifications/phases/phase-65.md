# Phase 65 — Bus Stop — Passenger Waiting Points

## Status

Ready for Review
Ready for Review: 2026-08-12 (agent, via `/TODO`)
In Review: 
Ready for QA: 
Complete: 

## Objective

Add PassengerWaitingPoints[] to Bus Stop - a concept V5's vehicle-occupancy-shaped station data had no equivalent of.

## Allowed

- Implement PassengerWaitingPoints[] as a list of offset points distinct from vehicle bays.
- Implement a UI affordance for placing multiple waiting points per stop.
- Verify waiting points don't interfere with vehicle bay occupancy tracking.
- Confirm this closes the passenger-point gap identified in 10-v6-runtime-schema.md.
- **(2026-08-10)** Verify each `PassengerWaitingPoints[]` element is independently
  gizmo-editable through Phase 48's generic sub-point mechanism - Bus Stop has no
  dedicated gizmo phase of its own (unlike Traffic Light/City Light), so this is where
  that coverage must be proven for this array specifically.

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

- [ ] Multiple waiting points placed and queryable independently of vehicle bays. By
      construction the two are already independent (`PassengerWaitingPoints[]` and
      `SegmentRow`/`SegmentColumn`/`OccupiedIndex` are unrelated fields, seeded from
      unrelated console-command args, never cross-read - see Implementation Notes
      below); the visual/gizmo placement itself is unchecked pending in-editor
      confirmation per `AGENT-RULES.md`'s Agent Testing Policy - see "Manual
      verification required" below.
- [x] Gap-closure explicitly confirmed against 10-v6-runtime-schema.md.
      `10-v6-runtime-schema.md`'s own "Confirmed gaps" section, item 5:
      "`FNexusStationInfoBase`'s segment-grid model is vehicle-occupancy-shaped, not
      passenger-shaped... no concept of 'passenger waiting point'... as a first-class
      entity distinct from the vehicle bay itself." `FNexusBusStopActivation::
      PassengerWaitingPoints` now covers the passenger-waiting-point half of that gap
      for Bus Stop specifically; the sibling "seat interaction point" half is Phase 66/
      69's own scope, not silently folded in here.

## Implementation Notes (2026-08-12)

- `PassengerWaitingPoints` (`TArray<FNexusSubPointOffset>`) added to
  `FNexusBusStopActivation` - same dynamic-array sub-point shape
  `FNexusCrosswalkActivation::PedestrianWaitingPoints` (Phase 60) already proved for a
  real type, reusing the identical generic reflection/resolver/gizmo path (no new
  mechanism).
- "Implement a UI affordance for placing multiple waiting points per stop" (this
  phase's own Allowed-list item) is already satisfied by the SAME generic
  `IStructureDetailsView`-over-the-whole-payload-struct binding every other
  `TArray<FNexusSubPointOffset>` field already gets (`SNexusDetailsPanel.cpp`'s
  `TestActivationPointPayload` case - standard UE array add/remove/reorder UI, no
  Bus-Stop-specific code needed) - same precedent Phase 60 already established for
  Crosswalk's own array field.
- `Nexus.Representation.AddTestBusStop` (Phase 64) extended with a fourth
  `[WaitingPointCount=3]` arg - seeds that many `PassengerWaitingPoints[]` entries
  spread near `StoppingPoint`, using the same `FArrayProperty`-resize-then-
  `SetSubPointOffset`-per-element pattern `AddTestCrosswalkConsoleCommand` already
  established. Independence from the vehicle-bay grid is proven by construction: the
  two are seeded from unrelated command args (`WaitingPointCount` vs.
  `SegmentRow`/`SegmentColumn`) and neither field's own code path reads the other.
- "(2026-08-10) Verify each PassengerWaitingPoints[] element is independently
  gizmo-editable" - same situation Phase 62 already documented for Crosswalk: Bus
  Stop's `DefaultDebugCategory` is `Runtime.ActivationPoints` (Phase 64's own
  registration, unchanged), which already has `IsSelectable`/`CanSupportGizmo` both
  `true` since Phase 48 - zero new code required, this is a manual-verification item
  only.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. In the Unreal Editor, run `Nexus.Mapping.LoadOrCreateConfig`, then
   `Nexus.Representation.DumpJunctionClassification` to find a real `HighwayPointId`.
2. `Nexus.Representation.AddTestBusStop <HighwayPointId> 2 2 4 1` - confirm the log
   line reports 4 `PassengerWaitingPoints` alongside 4 total bays (1 pre-occupied).
3. Select 'Select Mode', click each `PassengerWaitingPoints[]` marker in turn - confirm
   each is independently selectable/draggable via the viewport gizmo, and dragging one
   does not change `SegmentRow`/`SegmentColumn`/`OccupiedIndex` in the Details panel
   (proves the two are unrelated in the live editing UI too, not just in the seed
   command).
4. In the Details panel, use the array add/remove affordance on
   `PassengerWaitingPoints` directly (not via console command) - confirm a new element
   can be added/removed and immediately becomes its own gizmo-selectable marker.

## References

- `project-specifications/10-v6-runtime-schema.md`
