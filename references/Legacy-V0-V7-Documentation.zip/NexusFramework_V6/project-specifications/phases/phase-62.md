# Phase 62 — Crosswalk — Debug Visualization

## Status

Ready for Review
Ready for Review: 2026-08-12 (agent, via `/TODO`)
In Review: 
Ready for QA: 
Complete: 

## Objective

Register the Crosswalk debug leaf under Infrastructure, rendering the span, width, and pedestrian waiting points.

## Allowed

- Register the leaf following Phase 53's pattern.
- Render start/end span, width extents, and waiting-point markers.
- Render the LinkedTrafficLightId connection as a line, if set.
- **(2026-08-10)** Enable bSupportsGizmo and verify StartPoint/EndPoint plus each
  `WaitingPoints[]` element are independently gizmo-editable through Phase 48's generic
  sub-point mechanism (13-v6-gizmo-system.md) - Crosswalk has no dedicated gizmo phase
  of its own (unlike Traffic Light/City Light), so this is where that coverage must be
  proven for this type specifically.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Completion Criteria

- [ ] Test crosswalk renders span/width/waiting-points/link correctly.
      (Implementation + build done; not yet manually verified in-editor - see "Manual
      verification required" below.)

## Implementation Notes (2026-08-12)

- New `Infrastructure.Crosswalk` leaf added to the existing
  `NexusDebugInfrastructureGroupRenderers.cpp` (Phase 53's "one file per GROUP, not per
  TYPE" precedent, already extended once by Phase 57's City Light leaves). A single leaf,
  not a Pole/LED-style pair - this phase's own Objective wording is "the Crosswalk debug
  leaf", singular.
- Renders: StartPoint/EndPoint markers + the span line between them; a Width-extent
  rectangle straddling that span (`ComputeRightVectorFromTangent` applied to the span
  direction, same lateral-offset primitive `ResolveControlledLaneLocation` already uses
  for a Highway's own centerline); each `PedestrianWaitingPoints[]` element in its own
  cyan color; and, if Phase 61's `LinkedTrafficLightId` is set and resolves against a
  currently-known test Traffic Light, an amber connecting line from the span's midpoint
  out to that light's own `Pole` sub-point (falls back to the light's anchor location if
  its Pole sub-point isn't found). A dangling `LinkedTrafficLightId` draws nothing
  extra - same "draw what resolves, flagging what doesn't is validation's job" split
  `ResolveControlledLaneLocation` already established; `ValidateLinkedTrafficLight`
  (Phase 61) owns flagging it.
- Reuses this file's own `GatherTestTrafficLights` (Phase 53) to resolve the link target,
  rather than a second parallel Traffic-Light-gathering helper - only actually gathered
  if at least one crosswalk in the current frame has a set `LinkedTrafficLightId`.
- Does not touch `NexusCrosswalkActivationRegistration.cpp`'s own `GRegisterCrosswalk`
  (`DefaultDebugCategory` stays `Runtime.ActivationPoints`, unchanged) or
  `RenderActivationPoints` (still renders Crosswalk generically) - same "additional,
  richer, type-aware view, not a replacement" precedent every other Infrastructure leaf
  in this file already follows. Not gated on `IsSelectable`/`CanSupportGizmo` - this
  phase's own "Enable bSupportsGizmo" Allowed-list item is already satisfied by the
  EXISTING `Runtime.ActivationPoints` category (`IsSelectable`/`CanSupportGizmo` both
  already `true` since Phase 48; Phase 60's own registration never pointed
  `DefaultDebugCategory` anywhere else) - `StartPoint`/`EndPoint`/
  `PedestrianWaitingPoints[]` elements are therefore already independently
  gizmo-draggable today, with zero new code required for that coverage. This is a
  manual-verification item, not an implementation gap.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. In the Unreal Editor, run `Nexus.Mapping.LoadOrCreateConfig`, then
   `Nexus.Representation.DumpJunctionClassification` to find a real `HighwayPointId`.
2. `Nexus.Representation.AddTestTrafficLight <HighwayPointId> 1` - note the logged
   `ActivationPointId`.
3. `Nexus.Representation.AddTestCrosswalk <HighwayPointId> 3 1` - note the logged
   `ActivationPointId`.
4. `Nexus.Representation.LinkCrosswalkToTrafficLight <CrosswalkActivationPointId>
   <TrafficLightActivationPointId>` (Phase 61's command).
5. In the Debug Tree, enable `Infrastructure > Crosswalk`. Confirm: two endpoint spheres
   joined by a span line; a width-extent rectangle straddling that span at the
   Crosswalk's own `Width`; 3 cyan waiting-point markers; one amber line from the span's
   midpoint out to the linked Traffic Light's Pole marker (enable
   `Infrastructure > Traffic Light` too to see the Pole marker itself).
6. Re-run step 4 with a third arg of `1` (`InjectDangling=1`) - confirm the amber link
   line disappears (no crash/garbage line for the now-dangling reference).
7. Select 'Select Mode', click the Crosswalk's StartPoint/EndPoint markers and each
   waiting-point marker in turn - confirm each is independently selectable/draggable via
   the viewport gizmo (Phase 48's generic mechanism), and the Details panel shows the
   `FNexusCrosswalkActivation` payload for each.

## References

- `project-specifications/06-v6-debug-system.md`
