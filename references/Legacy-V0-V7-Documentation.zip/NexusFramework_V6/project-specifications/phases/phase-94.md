# Phase 94 — Claude Workflow — Rules, Commands, Skills

## Status

Ready for Review
Ready for Review: 2026-08-22 20:40 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Recreate V5's proven .claude workflow for V6 per the master prompt's section 32: rules, commands, skills, adapted to V6's actual structure (not copied blindly).

## Allowed

- Create a V6 onboarding skill (parallel to V5's nexus-editor-onboarding) covering V6's actual data model and pipeline stages.
- Create/adapt a /TODO command matching V6's agent-todos workflow if the user wants the same task-queue convention as V5.
- Document V6-specific do-not-touch-without-approval guardrails (the engine-level Q.IsNormalized() risk, if V6 also drives Landscape Splines).
- For each convention this phase touches (rules/commands/skills/TODO/memory/logging/completion records) explicitly state whether V6 reuses V5's exact pattern verbatim or redesigns it - do not leave this implicit, per v6-phase-verification.md.
- Verify a fresh agent session can self-orient using only these files, matching V5's proven pattern.

## Not Allowed

- Do not copy V5's skill content verbatim where V6's architecture has actually changed (Load Layout references, old struct names, etc.) - adapt, don't clone.

## Completion Criteria

- [ ] A fresh-session test (no prior context) successfully self-orients using only the new skill/rules files.

## References

- `project-specifications/09-development-rules.md`

## Implementation (agent, 2026-08-22)

Created `.claude/skills/nexus-v6-onboarding/SKILL.md` - V6's own onboarding skill, written
from V6's actual structure rather than adapted from V5's (which references Load Layout and
struct names that do not exist here, exactly what this phase's Not-Allowed list forbids
cloning).

It covers: the five pipeline stages and the Landscape-as-source-of-truth rule; the module
boundary and how it is enforced; the three state systems (`ai-change-audits/`,
`agent-todos/`, `phases/`) and which question each answers; the two-edits extensibility
contract; five traps this project has actually hit; and how to build/verify.

**The reuse-vs-redesign table this phase explicitly requires** is in the skill itself rather
than left implicit — per `v6-phase-verification.md`. Summary: `agent-todos/` and completion
records are reused from V5 verbatim; `/TODO` is reused in shape but rewritten for V6's two
work sources; memory location, the onboarding skill, and the activation type system are all
deliberate redesigns.

`.claude/commands/TODO.md` already exists and matches V6's workflow - not rewritten.

**On the `Q.IsNormalized()` guardrail this phase asks about:** V6 *does* build on Landscape
Splines, so the risk carries over. It is documented in the skill's "Traps" section with the
correct instruction (it is an engine bug, do not attempt to fix it in engine code).

## Manual verification still required from the user

The single criterion is a **fresh-session test** - start a new agent session with no prior
context and confirm it can self-orient using only these files. That cannot be self-assessed:
this session wrote the skill and therefore already knows everything in it, so any judgement
it makes about sufficiency is worthless. Left unchecked.
