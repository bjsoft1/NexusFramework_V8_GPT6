# Phase 64 — Bus Stop — Data Model

## Status

Ready for Review
Ready for Review: 2026-08-12 (agent, via `/TODO`)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement `FNexusBusStopActivation` per `12-v6-activation-point-system.md` and
`v6-master-architecture.md` Section 7 (Bus Stop must be fully authorable) —
StoppingPoint/EntryPoint/ExitPoint sub-offsets, generalizing V5's `FNexusBusStopInfo`
occupancy-grid shape, PLUS the mesh/shelter fields the original phase text omitted. See
"Revision — 2026-08-10" below.

## Revision — 2026-08-10 (v6-master-architecture.md Section 7 alignment)

This phase's original text covered only StoppingPoint/EntryPoint/ExitPoint plus a
vehicle-bay occupancy grid. Master Architecture Section 7's field list additionally
requires `Shelter configuration`, `BaseMesh`, `IndicatorMesh`, and `Seat/Chair
configuration` — none of which appeared anywhere across the original Phase 64-68 group
(confirmed absent by a project-wide search). `PassengerWaitingPoints[]` (Phase 65) and
`SeatInteractionPoints[]` (Phase 66, now backed by `FNexusSeatActivation` per Phase 69's
own revision) already cover the point-position half of Section 7; this revision adds the
remaining mesh/shelter half to this phase specifically, since it's the base data-model
phase the other four in the group build on.

## Allowed

- Implement `FNexusBusStopActivation`'s stopping/entry/exit sub-offsets.
- Add `ShelterConfig` (a small struct: has-shelter bool, shelter mesh ref, or reuse a
  Static-classified companion object pattern like City Light's separate pole — decide
  and document which, don't leave it implicit).
- Add `BaseMesh` (platform/stop-marker mesh) and `IndicatorMesh` (e.g. a stop-sign/
  route-number board mesh) as soft object references.
- Reuse V5's `SegmentRow`/`SegmentColumn`/`OccupiedIndex` occupancy shape where it still
  applies (vehicle bay occupancy) - note this is the same shape Phase 70 (Parking) now
  extends with spacing/dimension fields; Bus Stop's own vehicle-bay grid does not need
  Parking's `SpotWidth`/`SpotLength`/`RowGap`/`ColumnGap` level of detail unless a real
  requirement for it surfaces - don't add it speculatively.
- Register the type via Phase 45's registry.
- Verify against a multi-bay test bus stop that also has a shelter and a stopping-point
  mesh configured, not just bare points.

## Not Allowed

- Do not add feature-specific fields to the shared `FNexusActivationPoint` base struct -
  specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the
  HighwayPoint transform.
- Do not speculatively add Parking-level spacing/dimension fields to the vehicle-bay
  grid here - that belongs to Phase 70's own scope, not this one, unless a real Bus
  Stop requirement demonstrates it's needed.

## Completion Criteria

- [ ] Multi-bay test stop correctly represents all three point types plus bay
      occupancy. `Nexus.Representation.AddTestBusStop` seeds StoppingPoint/EntryPoint/
      ExitPoint at three distinct offsets and a SegmentRow x SegmentColumn grid (default
      2x2 = 4 bays) with one bay pre-occupied (`OccupiedIndex = {0}`,
      `HasFreeSegment()` correctly reports true with 3 of 4 free, confirmed by code
      logic, not an editor run). Per `AGENT-RULES.md`'s Agent Testing Policy, the visual/
      gizmo round trip itself is not run/verified by the agent this session - left
      unchecked. **To check**: see "Manual verification required" below.
- [x] `ShelterConfig`/`BaseMesh`/`IndicatorMesh` are implemented and exercised by the
      test case (not left as unused fields) - the test command sets `HasShelter=true` +
      a `ShelterMesh` soft reference, plus `BaseMesh`/`IndicatorMesh`, all pointed at
      Engine basic-shape meshes (always present in any UE project) so the
      `TSoftObjectPtr` fields round-trip without depending on project-specific content.
- [x] Explicit note recorded on which V5 `FNexusBusStopInfo` fields carried over
      unchanged vs. were extended - see "Implementation Notes" below.

## Implementation Notes (2026-08-12)

- **V5 `FNexusStationInfoBase`/`FNexusBusStopInfo` field disposition** (this phase's own
  explicit completion criterion):
  - Carried over UNCHANGED (name and meaning both): `SegmentRow`, `SegmentColumn`,
    `OccupiedIndex`, `GetTotalSegmentCount()`, `HasFreeSegment()`.
  - NOT carried over - already superseded by the shared `FNexusActivationPoint` base:
    `HighwaySplinePointId`/`HighwayId` (-> base `HighwayPointId`), `StationId` (-> base
    `ActivationPointId`), `StationName` (-> base `Name`), `OffsetLocation`/
    `OffsetRotation` (-> base fields, and this type's own three named sub-offsets for
    the actual point positions).
  - NOT carried over - deliberately dropped, no longer applicable: `AllowVehicles`/
    `AllowLanes` (bitmask fields with no analogue named anywhere in Section 7's own
    field list; not reintroduced speculatively), `SegmentWidth`/`SegmentLength` (V5's
    -1-means-global-default dimension fields - Section 7 doesn't call for per-bay
    dimensions on Bus Stop the way Phase 70/Parking's own `SpotWidth`/`SpotLength` will;
    not added here per this phase's own Not-Allowed list against speculative Parking-
    level detail).
  - NEW, not in V5 at all: `ShelterConfig` (`HasShelter` + `ShelterMesh`), `BaseMesh`,
    `IndicatorMesh` - Section 7's own field list additions this phase's 2026-08-10
    revision exists to close.
- **Shelter design decision** (this phase's own explicit "decide and document which"
  requirement): `ShelterConfig` is a small embedded struct (`FNexusBusStopShelterConfig`
  - `HasShelter` bool + `ShelterMesh` soft ref) on `FNexusBusStopActivation` itself, NOT
  a separate Static-classified companion object the way City Light's own Pole is.
  Reason: Section 7's own diagram nests "Shelter configuration" as a sibling FIELD of
  Bus Stop alongside BaseMesh/IndicatorMesh, not as a separate top-level entity - see
  `NexusBusStopActivation.h`'s own header comment for the full reasoning.
- `SeatInteractionPoints[]`, `PassengerWaitingPoints[]` deliberately NOT added here -
  Phase 66 and Phase 65's own scope respectively (`12-v6-activation-point-system.md`'s
  diagram). Section 8's "Seat/Chair configuration" field is satisfied by
  `SeatInteractionPoints[]` itself once Phase 66/69 land, not a separate field on this
  struct.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. In the Unreal Editor, run `Nexus.Mapping.LoadOrCreateConfig`, then
   `Nexus.Representation.DumpJunctionClassification` to find a real `HighwayPointId`.
2. `Nexus.Representation.AddTestBusStop <HighwayPointId> 2 2 1` - confirm the log line
   reports 4 total bays, 1 pre-occupied, `HasFreeSegment=true`.
3. Select 'Select Mode' in the viewport, click each of the three sub-point markers
   (StoppingPoint/EntryPoint/ExitPoint) in turn - confirm each is independently
   selectable/draggable, and the Details panel shows the `FNexusBusStopActivation`
   payload including `SegmentRow`/`SegmentColumn`/`OccupiedIndex`, `ShelterConfig`
   (`HasShelter=true` + `ShelterMesh` pointing at the Engine Cylinder), and `BaseMesh`/
   `IndicatorMesh` (Engine Plane/Cube).

## References

- `project-specifications/v6-master-architecture.md` (Section 7 — Bus Stop must be
  fully authorable)
- `project-specifications/10-v6-runtime-schema.md`
- `project-specifications/12-v6-activation-point-system.md`
