# Phase 49 — Activation Point — End-to-End Smoke Test

## Status

In Review
Ready for Review: 2026-08-11 GMT+5:45 (+0545)
In Review: 2026-08-11 12:12 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Prove the full Source-to-Gizmo pipeline works end-to-end for the dummy test Activation Point type before any real object type (Traffic Light, etc.) is built on top of it.

## Allowed

- Run the full pipeline: Landscape read -> Mapping -> Representation -> Generation classification -> Debug render -> Gizmo edit -> re-render.
- Document any friction/gap found at a stage boundary.
- Fix only what's required for the dummy type to round-trip correctly - do not scope-creep into real object types yet.
- Sign off this phase as the proof point that Phases 50+ build on a validated foundation.

## Not Allowed

- Do not begin real object-type-specific work (Traffic Light, etc.) in this phase - that starts at Phase 50.

## Completion Criteria

- [ ] Full round-trip (Source through Gizmo edit through re-render) completes with no manual workarounds.
- [ ] Any friction found is documented and, if it requires a design change, escalated rather than silently patched.

## References

- `project-specifications/12-v6-activation-point-system.md`
- `project-specifications/13-v6-gizmo-system.md`

## Note — 2026-08-10 — prerequisite base-struct extension done first

Before starting this phase, direct user request: audit V6 for the shared Activation
Point / city-object base struct and extend it with fields the smoke test's dummy type
round-trip will eventually need to exercise (Code/Name/Description, IsEnabled,
DebugOverride) - see `phase-21.md`'s own appended Revision section and
`ai-change-audits/2026-08-10/feature-add/activation-point-shared-base-struct-extension.md`.
Structure-only - the new fields are not yet wired into the renderer/Generation/
persistence/Gizmo/Details Panel, so this phase's own round-trip smoke test still only
exercises the pre-existing base fields (offset/type/anchor) until a later pass wires
the rest.

## Note — 2026-08-10 (continued) — persistence/Details Panel/undo-redo now wired

Immediate same-day follow-up: `UNexusConfigAsset.ActivationPoints` is now a real,
persisted array, editable from the Hierarchy tree (nested under its anchor
HighwayPoint) and Details Panel, with full undo/redo, and rendered in the viewport
(including `DebugOverride`/`IsEnabled`) - see
`ai-change-audits/2026-08-10/feature-add/activation-point-persistence-and-details-editing.md`.
Still NOT wired: Gizmo-dragging a real (non-test-store) point, Generation/Compilation
consumption, and specialized payload persistence - this phase's smoke test should scope
its "full round-trip" claim accordingly (Details-Panel-driven offset edits are real and
persisted; gizmo-driven edits of a real point are not yet possible, only of
`FNexusActivationPointTestStore` test points as originally planned).

## Note — 2026-08-11 — mandatory scalability requirement, verified already satisfied

Direct user request: the gizmo mechanism this phase smoke-tests must be strictly
selection-driven at 99,999+-object scale (never one gizmo per object, O(1) gizmo
creation, no per-frame full-object scan) - see `13-v6-gizmo-system.md`'s new
"Scalability requirement" section for the full rule set, now a mandatory, standing
requirement for this phase and every future object-type gizmo phase (Traffic Light,
City Light, Crosswalk, etc.), not just a one-off note here.

Audited (read-only, no code changed) against the actual already-built Phase 48 tool:
`ai-change-audits/2026-08-11/research/gizmo-scalability-audit-selection-driven-architecture.md`.
Every rule is already satisfied - single gizmo instance, created only on selection,
destroyed on deselect/reselect, no per-frame scan, drag write-back touches exactly one
point's data with no blanket cache invalidation. This phase's own smoke test should
still explicitly re-confirm this in-editor (only one gizmo ever visible regardless of
how many test points are seeded) as part of its round-trip proof, not assume the audit
alone is sufficient sign-off.

One friction point IS flagged by that audit, per this phase's own "document any
friction/gap found... escalate rather than silently patch" completion criterion:
click-time selection (`FindClosestSubPointHit`) is an O(N) linear scan over every
selectable/drawn Activation Point, not O(1) - a real cost at 99,999+ scale, though paid
once per click, not per frame, and not currently a blocker (current/near-term object
counts are far below where this would be measurable). Recommended fix (not implemented):
wire Phase 47's already-built `FNexusSpatialGridIndex` in as a broad-phase filter before
the narrow-phase ray-vs-sphere test, once object counts actually warrant it - a future
phase's concern, not this one's, but recorded here so it isn't silently forgotten.

## Implementation (2026-08-11) — real ActivationPoints now gizmo-editable, round trip closed

Direct user request: proceed with this phase, closing the one remaining gap the
2026-08-10 notes above flagged - "gizmo-driven edits of a real point are not yet
possible, only of `FNexusActivationPointTestStore` test points." Gizmo scalability
architecture (Phase 48, re-verified 2026-08-11 above) was explicitly required to stay
unchanged - this pass only widens WHICH data the existing single-gizmo mechanism can
target, never how many gizmo instances exist.

**Changes** (`Public/Private/Gizmo/NexusActivationGizmoTool.{h,cpp}` only):

- `FHitSubPoint` gained `bool bIsRealConfigPoint` (and the tool's selection state gained
  the matching `SelectedIsRealConfigPoint`) - tags which of the two data sources a hit/
  selection came from.
- `FindClosestSubPointHit`'s per-point ray-test body was extracted into a shared local
  lambda (`testActivationPoint`, no logic change, pure refactor) so a SECOND loop over
  `UNexusFrameworkSubsystem::GetActiveConfig()->ActivationPoints` could be added without
  duplicating the ray-vs-sphere math - both loops feed the SAME closest-hit-wins
  comparison, so whichever source is actually closer to the click wins, same as any
  other "which of several candidates did I click" test. The real-config loop mirrors
  `NexusDebugRuntimeGroupRenderers.cpp`'s own `DrawOneActivationPoint` gating exactly
  (`IsEnabled`, category `IsVisible`/`DebugOverride.IsAlwaysDraw`) so "gizmo-selectable"
  never diverges from "visible," for real points same as test points - but gated on the
  fixed `Runtime.ActivationPoints` category directly rather than a per-Type registry
  lookup, since a real config point's `Type` may be blank (`FNexusActivationPoint::
  MakeNew()`'s own default) and never has a payload/sub-points regardless of `Type`
  (specialized payload persistence remains explicitly open for Phase 50+ - unchanged,
  not decided by this pass).
- `HandleGizmoTransformChanged` now branches on `SelectedIsRealConfigPoint`: a real
  point calls `UNexusConfigAsset::Modify()` then `FNexusActivationSubPointResolver::
  SetSubPointOffset` (payload always null, base offset key only); a test-store point is
  completely unchanged (existing `FTransformProxyChangeSource`-based undo path). See
  `NexusActivationGizmoTool.h`'s own updated class comment for why a real point's
  `Modify()` correctly participates in the SAME real `FScopedTransaction` the ITF gizmo
  drag already opens (confirmed from engine source,
  `EdModeInteractiveToolsContext.cpp`'s `BeginUndoTransaction`/`EndUndoTransaction`) -
  no second, hand-rolled transaction needed. Deliberately does NOT call
  `MarkRepresentationDirty()`, matching `SNexusDetailsPanel.cpp`'s own established
  exclusion for ActivationPoint edits (no Landscape/Highway/HighwayPoint geometry is
  affected).

**What did NOT need to change** (confirming the round trip was already mostly wired,
this pass closed exactly one gap): the PDI wireframe renderer already drew real config
points (2026-08-10 prerequisite work); the Details Panel/Hierarchy already provided
real, undo/redo-capable, persisted create/edit; `HandlePostSaveWorld`'s existing
package-dirty check already auto-saves the config asset on map save - a gizmo-driven
`Modify()` call marks the SAME dirty flag, so Save/Load now works for gizmo edits too,
with zero new persistence code. Gizmo instance count/lifecycle
(`ActiveGizmo`/`ActiveTransformProxy`, created only on selection, destroyed on
deselect/reselect) is untouched - confirmed by inspection, this pass only added a second
candidate-scan loop and a write-back branch, no new gizmo/tool/proxy creation path.

**Explicitly out of scope, unchanged** (per this phase's own "do not begin real
object-type-specific work" rule and the ConfigAsset's own flagged persistence gap):
specialized payload persistence (the `Dummy.Array` sub-point case) remains
session-only/test-store-only, exactly as before - `UNexusConfigAsset::ActivationPoints`
still only ever holds base-only instances. Generation/Compilation consumption of
ActivationPoints remains unwired (not part of the objective this pass was asked to
close).

**Build**: `Build.bat NexusFrameworkEditor Win64 Development` succeeded with zero
warnings/errors (editor was not running).

### Manual verification still required (this agent cannot launch the editor - AGENT-RULES.md)

Full round-trip proof:

1. Enter Landscape Mode. In the Hierarchy tab, create a real Activation Point under a
   mapped HighwayPoint (existing, unmodified creation flow).
2. Enable `Runtime.ActivationPoints` in the Debug Tree - confirm the new point's
   wireframe sphere renders (pre-existing behavior, unchanged).
3. Click the sphere in the viewport. Confirm the translate/rotate gizmo appears at its
   location - this is the NEW behavior this pass adds (previously nothing would happen,
   since only test-store points were gizmo-selectable).
4. Drag the gizmo. Confirm the sphere moves live and the Details Panel (if open on the
   same point) shows the updated OffsetLocation/OffsetRotation live.
5. Ctrl+Z. Confirm the sphere/Details Panel revert. Ctrl+Y redoes it. This proves the
   `Modify()`-participates-in-the-ITF-transaction mechanism actually works live, not
   just by engine-source reading.
6. Save the level (or trigger the existing config auto-save). Close and reopen the
   editor/level. Confirm the dragged offset is still there - the actual Save/Load proof.
7. Confirm the underlying HighwayPoint/Landscape control point position is unchanged
   throughout (re-run `Nexus.Representation.EnumerateControlPoints` or equivalent
   before/after) - the "no Landscape geometry modification" criterion.
8. Re-confirm Phase 48's own scalability property still holds with a REAL point
   selected: only one gizmo ever visible; selecting a different point (real or
   test-store) destroys the old gizmo and creates exactly one new one; deselecting
   (click empty space) removes it entirely.

Selection-responsiveness observation (per direct user request, conditional follow-up):

9. With whatever number of test/real Activation Points you have on hand, click to
   select several in a row and subjectively judge selection responsiveness (time from
   click to gizmo appearing). Current/near-term object counts are far below where the
   known `FindClosestSubPointHit` O(N) scan (see the 2026-08-11 note above) would be
   expected to matter.
   - **If selection feels smooth**: no further action needed this phase - the
     O(N)-scan gap stays documented above as a standing, future scalability task (wire
     Phase 47's `FNexusSpatialGridIndex` as a broad-phase filter) rather than being
     built now. Do not expand this phase's scope pre-emptively.
   - **If selection is noticeably slow**: escalate back before Phase 50+ proceeds -
     that is the trigger point (per direct user instruction) to integrate
     `FNexusSpatialGridIndex` as a broad-phase candidate filter ahead of the existing
     precise ray-vs-sphere test (`click ray -> spatial query -> small candidates ->
     existing precise hit test -> selected object -> existing single gizmo`), preserving
     the precise selection logic and gizmo behavior exactly as they are - not a gizmo
     redesign.

## Correction — 2026-08-11 — real-point gizmo editing superseded by Editor Proxy Actor pool

Same-day follow-up editor-usability pass (project-specifications/
16-v6-editor-proxy-actor-system.md, `ai-change-audits/2026-08-11/feature-add/
editor-proxy-actor-pool-near-camera-interaction.md`), direct user request: the "Implementation
(2026-08-11)" section above - gizmo-dragging a REAL, persisted ActivationPoint via
`UNexusActivationGizmoTool` - is **reverted**, not merely superseded in practice. The
custom ITF gizmo goes back to test-store-only data; a real ActivationPoint's base offset
is now edited through a native `ANexusEditorProxyActor` (standard UE Actor selection +
transform widget), per this same-day pass's own explicit direction to stop routing
generic object-authoring through a custom gizmo where the native widget does the job
better. Steps 3-5 of the manual verification list above (click the sphere -> custom
gizmo appears -> drag -> Ctrl+Z/Y) no longer apply as written for a REAL point - the
equivalent proof is now: move the camera within `ProxyActivationDistance` of the point
(or double-click it in the Hierarchy tree) -> a proxy Actor appears/is selected with the
native transform widget -> drag -> Ctrl+Z/Y, per the new spec's own acceptance test list.
Steps 1, 2, 6, 7 (create, enable wireframe, save/reload, no-Landscape-mutation) are
unaffected. `FNexusActivationPointTestStore` test points are unaffected either way -
still gizmo-draggable exactly as originally built, now documented as this tool's
primary ongoing purpose (specialized future sub-point editing, Phase 50+).
