# Phase 48 — Activation Point — Gizmo Integration (Base)

## Status

In Review
Ready for Review: 2026-08-10 18:30 GMT+5:45 (+0545)
In Review: 2026-08-11 12:12 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Wire Phase 21's base ActivationPoint into the gizmo model from 13-v6-gizmo-system.md,
using the dummy test type(s) from Phase 45 - proves the pattern before real object types
plug in. **This "base" must be the GENERIC sub-point mechanism**
(`v6-master-architecture.md` Section 5 / `13-v6-gizmo-system.md`'s "Sub-point
addressing"), not a single-offset-only implementation that Traffic Light/City Light
later have to work around — Crosswalk and Bus Stop's own dynamic-array sub-points
(`WaitingPoints[]`, `PassengerWaitingPoints[]`, `SeatInteractionPoints[]`) depend on this
phase building the array case now, not deferring it.
**First task in this phase: resolve 13-v6-gizmo-system.md's open mechanism question**
(no `UNexusEdMode`/`UInteractiveToolManager` exists as of the 2026-08-09 architecture
correction - see `ai-change-audits/2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md`;
whether the Interactive Tools Framework is reachable without a custom Mode is unverified)
before implementing the rest of this phase against an assumption that may not hold.

## Progress note (2026-08-10)

This phase's own required first task (mechanism investigation) is DONE - see
`ai-change-audits/2026-08-10/research/phase-48-itf-reachable-without-custom-mode.md`.
Finding: ITF is reachable without a custom Mode, via
`ILevelEditor::GetEditorModeManager().GetInteractiveToolsContext()`; `13-v6-gizmo-
system.md`'s "Editing flow" section is updated accordingly. The rest of this phase
(tool registration, selection -> gizmo activation, drag -> offset write-back with
undo/redo, the fixed-field vs. array-element cases) was NOT attempted this session -
real interactive viewport behavior cannot be verified without launching the editor
(this agent cannot do that), and this is real, substantial, first-of-its-kind
interactive code in this project that deserves a dedicated pass with actual in-editor
testing available, not a blind implementation at the tail of a long session. Status
left at `Not started` (the phase's actual deliverable - a working gizmo - doesn't
exist yet) rather than `Ready for Review`, even though real, durable progress was made
and is fully recorded.

## Progress note (2026-08-10, continued)

The rest of this phase is now implemented and build-verified (see
`ai-change-audits/2026-08-10/feature-add/phase-48-gizmo-integration.md` for full detail).
Summary: `UNexusActivationGizmoTool`/`UNexusActivationGizmoToolBuilder`
(`Public/Private/Gizmo/NexusActivationGizmoTool.*`) - an always-active ITF tool,
registered/started/ended by new `FNexusActivationGizmoManager`
(`Public/Private/Gizmo/NexusActivationGizmoManager.*`) alongside built-in Landscape
Mode (same hook `FNexusLandscapeModeExtension::OnEditorModeIDChanged` already uses for
config load/Debug-config restore). Selection is a manual ray-vs-sphere hit test against
`FNexusActivationSubPointResolver::EnumerateResolvedSubPoints` (new,
`Public/Private/Representation/NexusActivationSubPointResolver.*`) - there is no
`HHitProxy`/scene component per sub-point to hook into (Phase 46's renderer only ever
called `DrawSphere`), so this had to be built from scratch, not reused. The gizmo itself
is standard `UCombinedTransformGizmo`/`UTransformProxy` (`UE::TransformGizmoUtil`) -
translate+rotate only (`ETransformGizmoSubElements::StandardTranslateRotate`, no scale,
per this phase's own Not Allowed rule).

Two supporting changes needed to make the array case (this phase's own explicit
completion criterion) exercisable at all, since nothing before this phase ever stored or
drew a real payload-struct instance: Phase 46's session-only test list moved from a local
`GTestActivationPoints` TArray into a new shared `FNexusActivationPointTestStore`
(`Public/Private/Representation/NexusActivationPointTestStore.*`, same session-only/
never-persisted contract, same command names) so the Gizmo tool can read/write the exact
same instances the renderer draws; the renderer itself now draws one marker per resolved
sub-point (via the same resolver) instead of only ever the base offset, and a new
`Nexus.Representation.AddTestActivationPointArray` console command seeds a real
multi-element `Dummy.Array` payload to click/drag. See phase-46.md's own appended
Revision section.

Undo/redo relies on `UTransformProxy`'s own built-in `FTransformProxyChangeSource`
integration (through `GetToolManager()`'s `IToolContextTransactionProvider`, the same
real `GEditor` transaction system `FScopedTransaction` wraps) rather than a hand-written
`FToolCommandChange` - the edited data (`FNexusActivationPointTestStore`'s plain structs)
isn't a `UObject`, so there is no `Modify()` to call directly; see
`NexusActivationGizmoTool.h`'s own class comment for the full reasoning. **This specific
mechanism is unverified in a live editor** (see Completion Criteria below) - it is a
correct reading of the engine's own `TransformProxy.cpp`/`CombinedTransformGizmo.cpp`
source, not something this agent could click-test.

## Allowed

- Investigate and decide the actual gizmo-interaction mechanism (ITF reachable without a
  custom Mode, vs. a hand-rolled `FEditorViewportClient`/`IInputProcessor` fallback) -
  record the finding in `ai-change-audits/` before proceeding with the rest of this phase.
- Implement `CanSupportGizmo` opt-in wiring from category config to gizmo selectability
  (implemented name for what this list originally called `bSupportsGizmo` - see
  13-v6-gizmo-system.md's own 2026-08-10 clarification: requires `IsSelectable &&
  CanSupportGizmo` together, not `CanSupportGizmo` alone).
- Implement the base gizmo-driving tool (shape depends on the mechanism decision above), that activates on selection.
- **Implement sub-point-key resolution** (Phase 45's registry output): selecting a
  debug-drawn sub-point (fixed field OR one array element) resolves to exactly one
  `(FieldName, OptionalArrayIndex)` key.
- Implement selection -> UCombinedTransformGizmo positioning at the selected sub-point
  key's own composed transform (not always the base offset).
- Implement drag -> write-back to exactly that sub-point key's OffsetLocation/
  OffsetRotation through FScopedTransaction/Modify() - a fixed field for a named
  sub-point, or `Array[Index]`'s own offset for an array element.
- Verify against BOTH of Phase 45's dummy types: the base-offset-only case AND the
  dynamic-array case (at least 3 elements) - editing array element `i` must not move
  element `i-1`, `i+1`, or the shared anchor.
- Verify the underlying HighwayPoint/Landscape control point is never touched by this flow.

## Not Allowed

- Do not let a gizmo edit write to Landscape/`ULandscapeSplineControlPoint` transforms.
- Do not bypass FScopedTransaction/Modify() for gizmo-driven edits (undo/redo must work).
- Do not implement scale handling - offsets are not scaled objects (see 13).
- Do not implement only the single-fixed-offset case and defer the array case to a
  later phase - Crosswalk (60-63) and Bus Stop (64-68) have no dedicated gizmo phase of
  their own and depend on this phase's array support being real, not stubbed.

## Completion Criteria

- [ ] Dummy-type (base-offset-only) gizmo drag correctly updates only the offset,
      proven by inspecting the Landscape control point's transform unchanged.
- [ ] Dummy-type (dynamic-array) gizmo drag on element `i` updates only that element's
      offset - proven by inspecting elements `i-1`/`i+1` and the shared anchor are
      unchanged.
- [ ] Undo/redo correctly reverts a gizmo edit, for both the fixed-field and
      array-element case.

## Manual QA still required

None of the three Completion Criteria above are checked off - this agent cannot launch
Unreal Editor (`project-specifications/AGENT-RULES.md`'s Agent Testing Policy), and this
is real, first-of-its-kind interactive viewport code. Steps to verify in-editor:

1. Enter Landscape Mode on a map with a real, already-mapped HighwayPoint (get its Id
   from `Nexus.Representation.DumpJunctionClassification`'s log output).
2. `Nexus.Representation.AddTestActivationPoint <HighwayPointId>` - enable
   `Runtime.ActivationPoints` in the Debug Tree - confirm a wireframe sphere is drawn.
3. Click the sphere in the viewport. Confirm a translate/rotate gizmo appears exactly at
   the sphere's location (not the anchor HighwayPoint's own location).
4. Drag the gizmo. Confirm the sphere moves live (no separate "apply" step) and that the
   underlying Landscape control point / `FNexusHighwayPoint` position is unchanged
   (e.g. re-run `Nexus.Reader.EnumerateControlPoints` or equivalent before/after).
5. Ctrl+Z after a drag. Confirm the sphere/gizmo revert to the pre-drag position; Ctrl+Y
   redoes it. This is the specific mechanism flagged unverified in this phase's own
   Progress note above.
6. `Nexus.Representation.ClearTestActivationPoints`, then
   `Nexus.Representation.AddTestActivationPointArray <HighwayPointId> 3` - confirm 4
   markers are drawn (1 `FixedPoint` + 3 `ArrayPoints`) at 4 distinct locations. Click
   and drag the *middle* `ArrayPoints` element specifically - confirm the other two
   array elements, `FixedPoint`, and the shared anchor do NOT move.
7. Click empty space (no sub-point under the cursor). Confirm the gizmo disappears
   (deselect).
8. **Specifically verify dragging the gizmo's own translate/rotate arrow handles still
   works** - this tool adds its own always-on viewport click behavior
   (`USingleClickInputBehavior`, default priority) alongside the gizmo's own built-in
   sub-gizmo click-drag behaviors; whether the gizmo's handles correctly take priority
   over this tool's own selection click (so dragging an arrow doesn't get swallowed as a
   new selection click instead) could not be confirmed without a live editor session.
9. Enter/leave Landscape Mode a few times in one session. Confirm no warnings/errors in
   the Output Log about duplicate tool registration.

## References

- `project-specifications/13-v6-gizmo-system.md`
