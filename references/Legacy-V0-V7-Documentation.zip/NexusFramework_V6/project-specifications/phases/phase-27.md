# Phase 27 — Debug Architecture — Diagnostics Panel & Viewport Rendering

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Wire the Phase 03 Diagnostics tab to live validation results from every stage gate built so far (Phases 09/14/22), generalizing V5's Sync Inspector - and render flagged entities in the viewport, not just in the panel list.

## Allowed

- Bind the Diagnostics tab to the accumulated validation-result list across all stages run so far.
- Implement Blocking vs Warning visual distinction (07-v6-ui-design.md).
- Implement click-to-focus (select the offending entity in the Hierarchy/viewport).
- Register the Diagnostics debug-tree group's leaves (validation errors, broken references, duplicate IDs, bounds) with the Phase 23 registry, rendering via Phase 28/29's shared primitives at each flagged entity's world location - not panel-list-only.
- Verify results update live as Mapping/Representation are re-run.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Revision — 2026-08-10 (same day, after this phase was already Ready for QA)

User reported the Diagnostics list (as tested with a large real entry list) had no way
to get its text out of the editor - `OnGenerateDiagnosticsRow`'s rows are plain
`STextBlock`s, which don't support mouse text-selection/copy in Slate at all, and the
row click is already claimed by this phase's own click-to-focus behavior, so making a
row itself copyable wasn't a clean option. Added a "Copy All" button above the list
(`SNexusFrameworkPanel::OnCopyAllDiagnosticsClicked`) that formats every currently-
listed entry as plain text (same `[Severity] [Stage] Message` shape as the row text,
one line each) and puts it on the OS clipboard via `FPlatformApplicationMisc::
ClipboardCopy` - needed adding the `ApplicationCore` module dependency (that symbol
doesn't live in Slate/SlateCore/Core; missing it produced a linker error, not a compile
error, same class of gap as this module's existing `InputCore` comment). Purely
additive UI - the three original criteria below (and their own manual-check steps) are
unaffected.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — all three left unchecked for the
user's own manual pass.

- [ ] **(New, 2026-08-10)** The "Copy All" button copies every currently-listed
      Diagnostics entry to the clipboard as plain text. **To check**: with at least one
      entry listed, click "Copy All", then paste (Ctrl+V) into any text field - confirm
      every listed entry appears, one per line, in the same `[Severity] [Stage] Message`
      shape shown in the panel. Confirm the button is disabled when the list is empty.

**Producing a deliberate failure to test all three against**: the most reachable one
with today's code is a broken `SourcePoint` — after `Nexus.Mapping.MapControlPoints`
has mapped some points, delete a Landscape Spline control point in the Splines tool.
Mapping's own gate then reports "HighwayPoint ... has an unresolved SourcePoint"
(Blocking). Note that this specific entry has **no** world location (the control point
it would point at is exactly what no longer exists) so it exercises criterion 1 only.
For criteria 2/3, a **cross-map** or **near-zero-tangent-at-a-junction** entry does
carry a location — see `FNexusLandscapeReader::ValidateSourceStage`.

- [ ] A deliberate validation failure from any prior phase's test case appears
      correctly in this panel. **To check**: enter Landscape Mode with the Nexus Panel
      open, produce a failure as above, and confirm it appears in the Diagnostics
      section prefixed `[BLOCKING]`/`[Warning]` and `[Source]`/`[Mapping]`/
      `[Representation]`, in red (Blocking) or amber (Warning). Confirm it disappears
      live once the underlying problem is fixed, without reopening the panel.
- [ ] The same deliberate failure is also visible as a rendered marker in the viewport
      at the correct world location, not just listed in the panel. **To check**: using
      a failure that carries a location (see above), confirm a red wireframe sphere
      appears at the offending entity's position with a text label beside it. Confirm
      unticking that `Diagnostics.*` leaf's checkbox in the Debug Tree makes the marker
      disappear.
- [ ] Click-to-focus correctly selects the offending entity. **To check**: click the
      diagnostics row and confirm the viewport camera moves to frame that location.
      **Known deviation from this criterion's wording** — this focuses the camera but
      does not *select* the entity: V5 documents `ULandscapeSplineSelection::
      SetSplineSelected` as a confirmed engine crash
      (`project-specifications/01-v5-analysis.md`), so programmatically selecting a
      control point is off-limits; and the Hierarchy tree is still Phase 04 placeholder
      content with no real entities to select. Revisit once the Hierarchy is wired to
      real Representation data.

## References

- `project-specifications/06-v6-debug-system.md`
- `project-specifications/14-v6-validation.md`
- `project-specifications/v6-phase-verification.md`
