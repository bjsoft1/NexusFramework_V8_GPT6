# Phase 24 — Debug Architecture — Tree View

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Build the actual Slate tree view driven generically by the Phase 23 registry, replacing Phase 03's placeholder Debug Tree section.

## Allowed

- Bind the Nexus Panel's Debug Tree section to the live registry.
- Implement expand/collapse per group, matching Phase 04's interaction patterns.
- Implement per-leaf visibility checkbox wired to FNexusDebugRenderConfig.bVisible.
- Verify the tree renders correctly at both 6 categories (today) and a stress-test 60 categories.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — both left unchecked for the user's
own manual pass.

- [ ] 60-category stress test renders without layout breakage or noticeable lag. **To
      check**: run `Nexus.Debug.RegisterStressTestCategories` (adds 54 dummy leaves, 9
      per top-level group), close and reopen the Nexus Panel tab (leave/re-enter
      Landscape Mode), expand the Debug Tree, confirm all 60 categories render without
      layout breakage or noticeable lag scrolling/expanding.
- [ ] Toggling a leaf's visibility checkbox is reflected in its stored config
      immediately. **To check**: in the Debug Tree, toggle any row's checkbox (every
      row has one, not just leaves — see this phase's own Findings in the batch audit
      record for why), then run `Nexus.Debug.DumpCategoryRuntimeConfigs` and confirm
      that category's `bVisible` matches the checkbox state.

## References

- `project-specifications/06-v6-debug-system.md`
- `project-specifications/07-v6-ui-design.md`
