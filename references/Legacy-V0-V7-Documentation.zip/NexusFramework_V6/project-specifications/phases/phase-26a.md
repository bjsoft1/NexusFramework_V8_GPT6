# Phase 26a — Config Asset — Undo/Redo for User-Driven Edits [improve/update requirement]

## Status

In Review
Ready for Review: 2026-08-10 11:23 GMT+5:45 (+0545)
In Review: 2026-08-10 15:13 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Give genuinely user-driven edits to the NexusConfig asset (starting with Phase 25/26's
Debug category Details-panel editing — the only real Details-panel-driven editing
surface that exists as of this phase) native Ctrl+Z/Ctrl+Y support, while guaranteeing
system-driven writes (Landscape sync/reconciliation, automatic enable-flow) NEVER create
an undo/redo entry — only mark the asset dirty. Direct user report, 2026-08-10: "ctrl+z,
ctrl+y can support. but make sure UE > to our system any info comes then do not make
redu/undo. just show dirty only to save."

## Context (why this phase exists, and what's already done)

Raised in the same message as the curve-accurate debug line request (Phase 30a), plus
"colors, font-size, label and more this should all save inside NexusConfig... if has any
change in this file make dirty, and editor can show unsaved file list... and auto happens
when UE landscape got save." Searched before adding this file — no existing phase covers
config-asset dirty-tracking/undo-redo/auto-save (`Modify()`/`FScopedTransaction`/`dirty`/
`undo`/`redo` only appear in the much later, narrower Phase 48/54/58/76-79 "gizmo offset
editing" phases — those are specifically about `ActivationPoint` drag-gizmo undo once the
Gizmo system exists, Phase 48+, a different and much narrower slice than this general
config-asset-wide concern).

**Already implemented same-day, ahead of this phase file** (see
`ai-change-audits/2026-08-10/others/config-asset-dirty-undo-autosave-scoping.md` for the
full record) — these parts needed no architecture decision, so they were done directly
rather than only tracked:

1. **Dirty-marking for every Mapping-stage mutation** — `Config.Modify()` added at each
   of `FNexusMapping`'s real mutation points (`MapControlPoint`, `BuildHighwayFromChain`
   inside `MapHighways`, `FindOrCreateCityByName`, `FindOrCreateStateByName`,
   `AssignHighwayToCity`, `AssignHighwayAsInterCity`, `AssignCityToState`) — guarded by
   each function's own existing idempotency check so a no-op re-run (e.g. re-running
   `Nexus.Mapping.MapControlPoints` against an unchanged Landscape) does NOT spuriously
   mark the asset dirty. `UObject::Modify()` unconditionally calls `MarkPackageDirty()`
   (confirmed via engine source) regardless of `RF_Transactional` or whether a
   transaction is currently open — so this single call correctly satisfies "make dirty"
   for these paths immediately, with ZERO risk of creating an unwanted undo entry, since
   none of these functions open their own `FScopedTransaction` (and never should — this
   is exactly V5's own proven rule below).
2. **`UNexusConfigAsset` now gets `RF_Transactional`** (`FNexusConfigAssetIO::
   LoadOrCreateConfigAsset`, both the `NewObject` and `LoadObject`-reuse paths — the flag
   is NOT part of serialized object data, confirmed via V5's own prior finding, so it
   must be (re-)set explicitly on load too, not just on first creation). This alone
   doesn't create any undo entries yet (nothing wraps an edit in `FScopedTransaction`
   yet) — it's the prerequisite foundation this phase's own remaining work needs.
3. **Auto-save-on-Landscape/level-save** — new `UNexusFrameworkSubsystem::
   HandlePostSaveWorld`, bound to `FEditorDelegates::PostSaveWorldWithContext`. Directly
   ports V5's own proven 3-guard pattern (`project-specifications/
   v5-complete-reference.md`'s `HandlePostSaveWorld` entry, engine-source-verified by V5
   already): 1) `SaveContext.SaveSucceeded()`, 2) `!SaveContext.IsFromAutoSave()`
   (autosave deliberately doesn't clear the real dirty flag — using it as the trigger
   would create a save-loop), 3) `World == GEditor->GetEditorWorldContext().World()`.
   No-ops if `ActiveConfig` unset or its package isn't actually dirty
   (`Package->IsDirty()` — the same native flag `Modify()`/`MarkPackageDirty()` above
   set, and the same one UE's own Content Browser/"Save All" dialog already reads for
   free) — never a write for its own sake.
4. **"Editor can show unsaved file list" is deliberately NOT a bespoke widget** — once
   `MarkPackageDirty()` fires reliably (item 1 above), UE's own native dirty-package UI
   (Content Browser asterisk, File > Save All's list, the exit-time "save changes?"
   prompt) already surfaces the NexusConfig asset the moment it's genuinely dirty, with
   zero custom UI needed. A custom "unsaved changes" list inside the Nexus panel itself
   would be a second, divergent source of truth for the same one bit of state — revisit
   only if the user finds the native UE indicators insufficient once they've tried them.

**What THIS phase still covers** (not yet implemented — the genuinely open, architecture-
loaded piece): real Ctrl+Z/Ctrl+Y for Debug category edits made through the Details panel
(`SNexusFrameworkPanel`'s shared `IStructureDetailsView`, Phase 25/26). As of this phase,
this is the ONLY real user-editable-via-Details-panel surface that exists —
`FNexusPlaceholderDetails` (bound when a Hierarchy tree row is selected) is explicitly a
non-editable stub (`VisibleAnywhere`, not `EditAnywhere`; its own header comment: "UI
plumbing only, not a data model... whichever later phase wires real selection replaces
this struct"), so real Highway/City/State/HighwayPoint field editing doesn't exist yet to
even need undo/redo — this phase's own Completion Criteria should be re-checked once that
lands, but this phase itself is scoped to what's real today.

**The exact reason this is nontrivial, not busywork** — V5 already hit and solved this
exact problem, with a real crash along the way, fully documented in
`project-specifications/v5-complete-reference.md`:
- `IStructureDetailsView` bound to a raw `FStructOnScope` (Phase 25/26's own mechanism,
  reused from V5) does NOT automatically wrap edits in `FScopedTransaction`/`Modify()` —
  V5's own subsystem API notes: **"every mutating entry point wraps changes in
  `FScopedTransaction` + `Modify()`"** — i.e. V5 did this explicitly, by hand, at each
  mutator, not by relying on the Details panel to do it automatically.
- **The crash V5 hit**: `PostEditUndo()` must be overridden on whichever UObject owns the
  transactional data. Without it, Ctrl+Z restores the UObject's raw property data via a
  wholesale UStruct property-serialize that tears down/rebuilds every TMap/TArray from
  scratch — silently invalidating any raw pointer a `FStructOnScope` (i.e. the Details
  panel's own current binding) was holding into the old memory. V5's own documented
  result before the fix: **`EXCEPTION_ACCESS_VIOLATION` on repaint after Ctrl+Z**. Also:
  undo/redo bypasses every normal setter/mutator, so no `OnLayoutChanged`-equivalent
  delegate fires on its own — `PostEditUndo()` must re-broadcast whatever delegate the UI
  layer listens to, so it rebuilds its `FStructOnScope` binding against the fresh
  post-undo memory instead of the stale, now-freed pointer.
- **The "UE owns Landscape-side undo, don't fight it" rule** (directly answers this
  session's own "UE > our system... do not make undo" ask): V5's
  `OnLandscapeSplineObjectTransacted` (bound to `FCoreUObjectDelegates::
  OnObjectTransacted`, the delegate proven to fire for BOTH Details-panel edits AND
  direct viewport gizmo manipulation, confirmed via engine source) calls plain
  `Modify()` — **never** `BeginTransaction`/`FScopedTransaction` — when reacting to a
  Landscape-originated change, so it JOINS whichever transaction UE already has open for
  that Landscape edit rather than opening a second, nested one (V5's own engine-source-
  verified finding: a nested `FScopedTransaction` here corrupts `UTransBuffer`'s
  `ActiveRecordCounts`/`ActiveCount` bookkeeping and crashes). V6 doesn't yet have an
  equivalent continuous push-based Landscape-change listener (V6's Mapping stage is
  currently pull-based: `ReconcileMappingStage`, run manually or at Landscape-Mode-enable
  time, not on every live edit) — so V6 doesn't face this exact nested-transaction risk
  yet, but the RULE still applies the moment any future phase adds a live
  `OnObjectTransacted`-style V6 listener: it must call bare `Modify()`, never open its own
  transaction.

## Allowed

- Wrap Debug category Details-panel edits (the `IStructureDetailsView` bound to
  `FNexusDebugRenderConfig` in `SNexusFrameworkPanel.cpp`) in `FScopedTransaction` +
  `Modify()` at the actual edit site — e.g. via the details view's own
  `OnFinishedChangingProperties`/`NotifyHook` mechanism — so Ctrl+Z/Ctrl+Y works for
  these edits specifically.
- Decide and document where the "live, currently-in-effect" Debug category data should
  live for this to be undo-safe: EITHER (a) keep `FNexusDebugCategoryRegistry::
  RuntimeConfigs` as the live copy and manually wrap+sync it into
  `ConfigAsset->DebugCategoryConfigs` on every edit (matches V5's own "wrap every
  mutating entry point by hand" precedent, smaller diff, keeps Phase 23-26's already-
  shipped registry architecture intact), OR (b) make `ConfigAsset->DebugCategoryConfigs`
  itself the single live source of truth and have `GetRuntimeConfig`/
  `GetMutableRuntimeConfig` read/write through to it directly (larger, more invasive
  change to Phase 23-26's already-"In Review" architecture — do not choose this silently,
  confirm with the user first if it becomes the preferred direction, per this project's
  own "ambiguous descriptions cost real rework, ask first" lesson,
  `03-v5-problems-and-lessons.md`).
- Implement a `PostEditUndo()`-equivalent (or `FEditPropertyChain`/`FCoreUObjectDelegates::
  OnObjectTransacted` reaction, whichever fits the chosen storage model above) that
  re-resolves/rebuilds the Details panel's `FStructOnScope` binding after an undo/redo,
  instead of leaving it pointing at possibly-invalidated memory — this is what V5's own
  crash history exists to warn against skipping.
- Verify a Debug category color/thickness/font-size edit is both real-Ctrl+Z-undoable AND
  that repainting the Details panel immediately after an undo does not crash.

## Not Allowed

- Do not open a `FScopedTransaction` anywhere in `FNexusMapping`'s own
  Landscape-sync/reconciliation functions (`MapControlPoint`, `MapHighways`,
  `ReconcileMappingStage`, `RunAutomaticEnableFlow`) — these must keep marking dirty via
  bare `Modify()` only (already true today, see this phase's own "already implemented"
  section above) - this is the literal "UE > our system, don't undo" requirement.
- Do not build a bespoke "unsaved changes" list widget — rely on UE's own native
  dirty-package UI (see this phase's own "already implemented" section, item 4) unless a
  concrete gap in it is found first.
- Do not silently pick storage-model option (a) vs (b) above without flagging the
  trade-off to the user first if choosing (b) — it revisits an already-"In Review"
  architecture decision from Phase 23-26.

## Completion Criteria

- [x] Every Landscape-sync/reconciliation mutation marks the config asset dirty without
      creating an undo/redo entry. Structural fact, already implemented (see Context):
      `Config.Modify()` is called at every real `FNexusMapping` mutation point, and none
      of those functions (nor anything upstream of them — `ReconcileMappingStage`,
      `RunAutomaticEnableFlow`) ever opens an `FScopedTransaction`, so `Modify()` there
      can only ever dirty-mark, never record an undo step, by construction.
- [x] UE's own map/Landscape save auto-triggers a NexusConfig save when dirty. Structural
      fact: `HandlePostSaveWorld` is bound and implements V5's own proven 3-guard
      pattern; `Package->IsDirty()` is read (the very code path (1) above marks) before
      deciding to save.
- [ ] A Debug category color/thickness/font-size/label edit made through the Details
      panel is undoable via Ctrl+Z and redoable via Ctrl+Y. **Implemented and
      build-verified 2026-08-10, not yet manually verified in-editor** (Agent Testing
      Policy — no editor automation). Storage-model choice: option (a) from this file's
      own Allowed list — kept `FNexusDebugCategoryRegistry::RuntimeConfigs` as the live
      copy, manually wrapped+synced into `ConfigAsset->DebugCategoryConfigs`.
      `SNexusFrameworkPanel` now implements `FNotifyHook`; `NotifyPreChange` (bound via
      `DetailsViewArgs.NotifyHook`) opens an `FScopedTransaction` and calls
      `Config->Modify()` before the struct write lands, and
      `OnDebugCategoryDetailsFinishedChangingProperties` (already-bound
      `OnFinishedChangingProperties`) syncs the new value into `DebugCategoryConfigs` and
      then closes the transaction. **To check**: select a Debug category, change its
      Color in the Details panel, Ctrl+Z — confirm the Details panel's own displayed
      value reverts; Ctrl+Y — confirm it re-applies. Repeat for LineThickness/
      LabelFontSize/LabelOverrideText/bShowLabel. Also confirm the NexusConfig asset still
      shows dirty in the Content Browser after the edit (pre-existing behavior, should be
      unaffected).
- [ ] Undoing a Debug category edit does not crash the Details panel on next repaint —
      this is the exact failure V5 hit before its `PostEditUndo()` fix. **Implemented and
      build-verified 2026-08-10, not yet manually verified in-editor.**
      `UNexusConfigAsset::PostEditUndo()` calls
      `FNexusDebugCategoryRegistry::RestoreRuntimeConfigsFromConfigAsset` (assigns through
      the existing owned `FNexusDebugRenderConfig` in place rather than replacing the
      `TUniquePtr` — see that class's own header comment — so the raw pointer the Details
      panel's `FStructOnScope` holds never dangles, unlike V5's crash), then broadcasts
      the new `OnPostEditUndo` delegate, which `SNexusFrameworkPanel::
      HandleConfigAssetPostEditUndo` subscribes to and uses to re-`SetStructureData` the
      currently-selected category, forcing a full repaint of the reverted/reapplied
      values. **To check**: same steps as above — confirm no crash/hitch on the repaint
      immediately following Ctrl+Z, and that the Details panel's displayed values
      genuinely match what's in the asset afterward (not just "didn't crash").

## References

- `project-specifications/v5-complete-reference.md` (`OnLandscapeSplineObjectTransacted`,
  `PostEditUndo()`, `HandlePostSaveWorld` entries — the full proven precedent this phase
  is built on)
- `project-specifications/03-v5-problems-and-lessons.md` ("ambiguous natural-language
  task descriptions cost real rework... cheaper to spend one round of clarifying
  questions" — why option (b) above needs confirmation, not a silent pick)
- `project-specifications/phases/phase-13.md` (general Config Asset persistence — the
  auto-save-on-level-save half of this phase's already-done work sits conceptually here
  too, not just under Phase 26)
- `project-specifications/phases/phase-25.md` / `phase-26.md` (the Debug category
  Details-panel editing and persistence this phase adds undo/redo to)
- `project-specifications/phases/phase-04-ui-interaction.md` (`FNexusPlaceholderDetails`
  — the still-a-stub Hierarchy-tree details binding; real Highway/City/State field
  editing, once it exists, will need this same treatment)
- `ai-change-audits/2026-08-10/others/config-asset-dirty-undo-autosave-scoping.md`
