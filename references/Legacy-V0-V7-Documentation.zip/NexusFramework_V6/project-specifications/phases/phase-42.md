# Phase 42 — Static Generator — Instancing Pipeline

## Status

In Review
Ready for Review: 2026-08-10 16:00 GMT+5:45 (+0545)
In Review: 2026-08-10 15:14 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Implement the Instanced classification's ISM/HISM grouping pipeline for repeated objects (poles, identical furniture).

## Allowed

- Implement ISM/HISM component creation grouped by mesh+material combination.
- Wire at least one Instanced-classified test object type (e.g. city-light poles) end-to-end.
- Verify instance count matches the source HighwayPoint count for that object type.
- Verify re-running the pipeline doesn't duplicate instances.

## Not Allowed

- Do not skip Classification tagging for any generated object.
- Do not let Generation write back to Landscape or Mapping data.
- Do not proceed to Compilation on data that failed this stage's validation gate.

## Completion Criteria

- [ ] Instance count is proven exact-match against source data on a test case.
      `Nexus.Generation.GeneratePoleInstances` logs added-vs-source counts (an
      unresolved HighwayPoint is correctly excluded, logged explicitly, not a silent
      mismatch) - not yet actually run (needs a mapped Landscape, manual step).
- [ ] Idempotency proven on re-run. `Nexus.Generation.TestInstancingIdempotency` runs
      the generator twice and compares both the return value and the live component's
      own `GetInstanceCount()` - not yet actually run.

## Implementation Notes (2026-08-10)

- New `ANexusGeneratedInstancedMeshHost` (`Public/Generation/
  NexusGeneratedInstancedMeshHost.h`) - a minimal actor holding one
  `UHierarchicalInstancedStaticMeshComponent` per mesh+material combination.
- New `FNexusInstancingGenerator` (`Public/Generation/NexusInstancingGenerator.h` /
  `Private/.../NexusInstancingGenerator.cpp`): `FindOrCreateInstanceComponent` (groups
  by mesh+material, never creates a duplicate component for the same pair) and
  `GenerateHighwayPointPoleInstances` (the "at least one Instanced-classified test
  object type" proof this phase's Allowed list asks for - one instance per resolved
  HighwayPoint, `ClearInstances()` before re-adding for idempotency).
- **Uses HighwayPoints as a stand-in source, not a real City-Light-pole placement
  list** - Phase 56 ("City Light - Data Model") hasn't defined actual pole placement
  data yet. This phase's own scope is proving the ISM/HISM grouping mechanism works
  (mesh+material grouping, exact instance count, idempotent re-run), not shipping real
  city lights - flagged explicitly rather than silently presented as a finished
  feature. Swapping in real placement data later does not change
  `GenerateHighwayPointPoleInstances`'s own contract.
- Console commands: `Nexus.Generation.GeneratePoleInstances`,
  `Nexus.Generation.TestInstancingIdempotency`.

## Manual Verification Needed

In the Unreal Editor, with a Landscape/ActiveConfig loaded and at least one mapped
HighwayPoint:
1. `Nexus.Generation.GeneratePoleInstances` - confirm the logged added-count matches
   `HighwayPoints.Num()` minus any unresolved points.
2. `Nexus.Generation.TestInstancingIdempotency` - confirm it logs PASS.
3. In the World Outliner, find `NexusGeneratedInstancedMeshHost` - confirm exactly one
   actor exists (not duplicated across repeated command runs) and it has exactly one
   `HierarchicalInstancedStaticMeshComponent` child.

## References

- `project-specifications/11-v6-static-dynamic-architecture.md`
