# Phase 10 — Nexus Mapping — Landscape Entity to HighwayPointId

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement the core Mapping-stage function: assign/lookup a stable HighwayPointId (FGuid) per identified control point, using Phase 08's stable identity as the key.

## Allowed

- Implement HighwayPointId assignment for a newly-seen control point.
- Implement HighwayPointId lookup/reuse for an already-mapped control point.
- Persist the ControlPoint-identity -> HighwayPointId table.
- Guard against assigning two different HighwayPointIds to the same physical point.

## Not Allowed

- Do not generate meshes or write Landscape geometry.
- Do not treat a mapped ID as permanent before this phase's validation passes.
- Do not duplicate a Landscape control point under two different HighwayPointIds.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — left unchecked for the user's own
manual pass:

- [x] Re-running Mapping on an unchanged Landscape produces zero new IDs (idempotent).
      **Verified 2026-08-10** by user: `Nexus.Mapping.MapControlPoints` run against the
      already-mapped 10-point test Landscape logged `TotalHighwayPoints=10
      NewThisRun=0`.
- [ ] The double-assignment guard is proven with a deliberate test case. **Not yet
      verified**: the same run only logged "double-assignment guard held" (the
      zero-conflict path) — no deliberate StableId conflict was injected, so the guard
      actually catching something hasn't been observed yet. **To check**:
      after mapping, `Nexus.Mapping.MapControlPoints` itself logs "double-assignment
      guard held" when it finds zero StableId conflicts; to see the guard actually
      catch something, open the saved config asset's Details panel (see Phase 13),
      hand-edit a second `HighwayPoints` entry to copy an existing entry's `StableId`,
      save, then re-run `Nexus.Mapping.MapControlPoints` and confirm it logs a
      `[BLOCKING]` conflict message identifying that StableId rather than staying
      silent.

## References

- `project-specifications/04-v6-architecture.md`
- `project-specifications/05-v6-data-flow.md`
- `project-specifications/AGENT-RULES.md`
