# Phase 25 — Debug Architecture — Per-Category Config

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement the full FNexusDebugRenderConfig struct and its editing UI (color/thickness/label/wireframe/gizmo-support toggles), shared across every category.

## Allowed

- Implement FNexusDebugRenderConfig exactly per 06-v6-debug-system.md's field list.
- Build the config-editing panel (opens on category selection in the tree).
- Verify no renderer has its own bespoke, non-shared config fields.
- Set sensible group-level default colors (warm Infrastructure, cool Runtime, per 07-v6-ui-design.md).

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Completion Criteria

- [x] Every registered category (six groups, any leaves so far) edits through the same
      panel with no per-category special-casing. Structural fact, provable by
      inspection rather than a runtime claim (same category as Phase 19's O(1)-lookup
      criterion): `SNexusFrameworkPanel::OnDebugTreeSelectionChanged` binds
      `DetailsView` to `FNexusDebugCategoryRegistry::GetMutableRuntimeConfig(Item->
      CategoryId)` unconditionally — there is exactly one `FNexusDebugRenderConfig`
      type in the codebase and zero `if (CategoryId == ...)` branches anywhere in the
      selection/editing path, so every category (including any leaf a future phase
      registers) goes through the identical code, not by convention but because no
      per-category branch exists to diverge.
- [ ] Default colors are visibly distinct group-to-group without manual per-category
      tuning. Per `AGENT-RULES.md`'s Agent Testing Policy, not run/verified by the agent
      this session (build-only verification) — left unchecked for the user's own visual
      pass. **To check**: open the Debug Tree and visually confirm the six top-level
      groups read as distinct colors. Assigned at registration
      (`NexusDebugCategoryRegistry.cpp`'s `MakeTopLevelGroup` calls), no per-category
      manual tuning involved: Landscape=green (0.10,0.60,0.20), Roads=neutral gray
      (0.65,0.65,0.68), Infrastructure=warm orange (0.90,0.45,0.05, per this doc's own
      "warm Infrastructure" example), Runtime=cool blue (0.15,0.50,0.90, per this doc's
      own "cool Runtime" example), Mapping=violet (0.55,0.25,0.85), Diagnostics=red
      (0.90,0.15,0.15).

## References

- `project-specifications/06-v6-debug-system.md`
- `project-specifications/07-v6-ui-design.md`
