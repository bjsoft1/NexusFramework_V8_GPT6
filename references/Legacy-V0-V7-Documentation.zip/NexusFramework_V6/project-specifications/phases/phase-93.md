# Phase 93 — Optimization — Memory/Duplicate-Data Audit

## Status

Ready for Review
Ready for Review: 2026-08-22 20:40 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Audit the full pipeline (Source through Compilation) for duplicate geometry/transform data or unnecessary UObject references, per the master prompt's massive-world performance rule. **(2026-08-10 revision)** This phase's title also invites a SECOND, different kind of "duplication" check — v6-master-architecture.md Section 28's visible-representation duplication (a static mesh and its dynamic-actor counterpart both rendering at the same location simultaneously) — which the original scope (data-storage duplication only) did not cover. Both are now in scope, explicitly distinguished below.

## Allowed

- Audit for any place geometry/transform data is stored twice (should be zero, per the 04/05 no-caching rule). This is DATA-storage duplication (the same Location/Rotation value cached in two structs).
- Audit for unnecessary UObject references in hot paths.
- **(2026-08-10, v6-master-architecture.md Section 28)** Separately audit for
  VISIBLE-REPRESENTATION duplication: for every object type that has both a
  Static-classified companion (per 11-v6-static-dynamic-architecture.md) and a
  RuntimeActivated dynamic-actor representation (e.g. a City Light's pole vs. its
  light-source actor), verify that when the dynamic actor is active, the corresponding
  static representation is handled per its own documented rendering strategy - not
  simply left rendering unconditionally alongside the dynamic actor with no
  coordination. This is a different failure mode from data-storage duplication (a
  correctness/visual-quality issue, not a memory issue) and must not be
  conflated with or assumed covered by the data-storage audit above.
- Fix any violation found (either kind).
- Document the audit result as a checked box for the release, explicitly noting which
  kind of duplication (data-storage vs. visible-representation) each finding is.

## Not Allowed

- Do not optimize a subsystem that hasn't been correctness-verified first.
- Do not introduce caching that can silently go stale (see the V5 lessons doc for why this matters).

## Completion Criteria

- [x] Audit completes with zero unresolved duplicate-data findings, or each finding explicitly justified and recorded.
- [x] Visible-representation duplication audit completed for every Static+RuntimeActivated
      paired object type (City Light at minimum), with zero unresolved findings or each
      finding explicitly justified and recorded.

## References

- `project-specifications/v6-master-architecture.md` (Section 28)
- `project-specifications/04-v6-architecture.md`
- `project-specifications/05-v6-data-flow.md`
- `project-specifications/11-v6-static-dynamic-architecture.md`

## Audit result (agent, 2026-08-22)

Both kinds of duplication audited separately, as this phase requires - they are different
failure modes and must not be conflated.

### 1. Data-storage duplication — 3 findings, all justified, none unresolved

- **Editor/Representation schema: ZERO duplication.** `FNexusHighwayPoint` caches no
  geometry at all; it is read live on every access. Enforced by a passing regression test
  (`Nexus.Regression.V5Lessons.HighwayPointCachesNoGeometry`) rather than by convention.
- **`FNexusRuntimeHighwayPoint` stores `Location`/`Rotation`** — *justified and necessary.*
  This is the deliberate compile-time freeze; a cooked build has no Landscape to read and no
  editor module to read it with. It is not a cache that can drift, because nothing writes to
  it after compilation and re-compiling is what re-reads.
- **`FNexusRuntimeSubPoint` stores both the local offset AND the resolved
  `WorldTransform`** — *justified.* The world transform is derivable (`Offset x Anchor`), so
  this is genuine redundancy. Kept because a consumer that only had the world transform
  could not re-resolve against a moved anchor, and one that only had the offset would have to
  recompose every frame. Recorded here as a real finding rather than defended as "not
  duplication".
- **Station sub-points also appear in `FNexusRuntimeActivationPoint::SubPoints`** —
  *justified.* A deliberate second query-shaped VIEW, matching V5's hierarchical + flat
  duality that `10-v6-runtime-schema.md` calls a sound design choice. Critically, the
  Compilation gate **enforces** that the two views agree (a Station with no matching
  Activation Point is Blocking), so they cannot silently diverge.

No unnecessary `UObject` references were found in hot paths. Asset references ship as
`FSoftObjectPath`, so nothing is loaded until the runtime chooses to.

### 2. Visible-representation duplication — prevented by construction

The concerning case is a static mesh and a dynamic actor both rendering the same thing at
the same place. Checked `FNexusGenerationClassificationTable`, which is where each object
type's classification is decided:

```
TrafficLightPole  -> Static           TrafficLightLED  -> RuntimeActivated
CityLightPole     -> Instanced        CityLightSource  -> RuntimeActivated
BusStopShelter    -> Instanced        BusStopPoint     -> RuntimeActivated
SeatMesh          -> Instanced        SeatPoint        -> RuntimeActivated
```

Every object type resolves to **exactly one** classification, and the paired members are
*different objects at different positions* (a pole is not a light source). So a single
visual element can never be both statically generated and dynamically spawned - the
duplication this audit looks for is structurally impossible, not merely absent today.

### The one real risk, which is a content constraint rather than a code defect

`UNexusActivationSubsystem` spawns `TypeRules[Type].RuntimeClass`, a Blueprint the project
configures. **If that Blueprint's mesh includes the static companion** - a whole traffic-light
model rather than just the LED - the pole renders twice: once from the Static Generator and
once inside the spawned Actor. No code can prevent this; it is an authoring rule.

**Recorded as an accepted, documented constraint:** a `RuntimeClass` must contain only the
dynamic half of its object. Worth re-stating in whatever art/BP guide the project grows.

## Manual verification still required from the user

Visually confirm, for a City Light and a Traffic Light in a running build, that the pole
appears exactly once when the dynamic actor is active - i.e. that the configured
`RuntimeClass` Blueprints honour the constraint above.
