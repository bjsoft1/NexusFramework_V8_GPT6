# Phase 70 — Parking — Data Model

## Status

Ready for Review
Ready for Review: 2026-08-12 (agent, via `/TODO`)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement Parking as a complete authoring system per `v6-master-architecture.md`
Section 6 — not merely "a point with a mesh," and not merely V5's narrower
`FNexusStationInfoBase` shape reused verbatim. See "Revision — 2026-08-10" below.

## Revision — 2026-08-10 (v6-master-architecture.md Section 6 alignment)

This phase's original text scoped Parking to reusing V5's
`SegmentRow`/`SegmentColumn`/`AllowVehicles`/`OccupiedIndex` fields "almost verbatim."
That shape is missing six of Section 6's twelve required fields (`RowGap`/`ColumnGap`/
`SpotWidth`/`SpotLength`/`BaseMesh`/`ParkingIndicatorMesh`) — without spacing and
dimension fields, no individual spot's exact world-space position/rotation can be
computed, which breaks Section 6's own required runtime queries ("Where is that spot
located? What is its final rotation?"). `12-v6-activation-point-system.md` has been
updated to match this revision — see that doc's own `FNexusParkingActivation` line.

## Allowed

- Implement `FNexusParkingActivation` (contains an `FNexusActivationPoint` for the
  anchor/offset, same contains-not-duplicates pattern as every other specialized
  payload struct) with:
  - `Row`, `Column` (int32) — grid dimensions. `Capacity = Row × Column`, computed, never
    stored as an independently-editable field (Section 6's explicit rule).
  - `RowGap`, `ColumnGap` (float) — spacing between spots, same `-1`-inherit/`0`-disabled/
    `>0`-custom convention used elsewhere in this project.
  - `SpotWidth`, `SpotLength` (float) — per-spot dimensions.
  - `BaseMesh` (soft object ref) — the parking-surface/marking mesh.
  - `ParkingIndicatorMesh` (soft object ref) — the occupied/free indicator (V5 had no
    equivalent — new).
  - `OccupiedIndex` (`TArray<int32>`, runtime-only/not authored) — reuse V5's
    `FNexusStationInfoBase::OccupiedIndex` shape/semantics (flattened Row×Column index).
  - Keep `AllowVehicles` (V5's bitmask) if still meaningful, or fold into `Metadata`.
- Implement the query surface Section 6 requires: is parking available, which spot is
  free, the next available spot, its resolved world-space location, its resolved
  rotation (derived from `Row`/`Column`/`RowGap`/`ColumnGap`/`SpotWidth`/`SpotLength`
  against the anchor + offset transform).
- Register the type via Phase 45's registry.
- Verify against a multi-bay test parking area with real `RowGap`/`ColumnGap`/
  `SpotWidth`/`SpotLength` values, not just a bare grid count.
- Document explicitly what changed from V5's `FNexusParkingInfo` (this revision's own
  answer: spacing/dimension/mesh fields added, `Capacity` made derived not stored).

## Not Allowed

- Do not add feature-specific fields to the shared `FNexusActivationPoint` base struct -
  specialize via `FNexusParkingActivation` instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the
  HighwayPoint transform.
- Do not store `Capacity` as an independently-editable field - it is always
  `Row × Column`, computed.

## Completion Criteria

- [x] `FNexusParkingActivation` implements Row/Column/RowGap/ColumnGap/SpotWidth/
      SpotLength/BaseMesh/ParkingIndicatorMesh/OccupiedIndex per the Allowed list above
      - see Implementation Notes below for the `AllowVehicles`/spacing-default design
      decisions this phase's own text left open.
- [ ] Multi-bay parking test case correctly tracks occupancy AND correctly resolves an
      individual spot's exact world-space location/rotation from the grid+spacing+
      dimension fields (not just an abstract index). `Nexus.Representation.
      AddTestParking`/`QueryTestParking` seed and query this correctly by code logic
      (confirmed by reading `ComputeSpotLocalTransform`/`ComputeSpotWorldTransform`'s
      own math); the visual/in-editor confirmation itself is unchecked pending manual
      verification per `AGENT-RULES.md`'s Agent Testing Policy - see "Manual
      verification required" below.
- [x] The query surface (is available / which spot / next available / its location / its
      rotation) is proven against the test case - `Nexus.Representation.
      QueryTestParking` exercises `HasAvailableSpot`/`GetFreeSpotIndices`/
      `FindNextAvailableSpotIndex`/`ComputeSpotWorldTransform` together in one command,
      logging every result.
- [x] Explicit V5-diff note recorded (per this revision's own summary above) - see
      Implementation Notes below.

## Implementation Notes (2026-08-12)

- **Zero declared `FNexusSubPointOffset` fields, deliberately** - `FNexusParkingActivation`
  is a base-only-shaped type (same "Advertisement/TV/Seat/Parking... exactly one
  sub-point key" case `NexusActivationSubPointResolver.h` already anticipated at Phase
  45/48, same reasoning Phase 69 already used for standalone Seat). The grid's own
  overall position/rotation is the base `FNexusActivationPoint::OffsetLocation`/
  `OffsetRotation`, already gizmo-editable with zero new resolver code - satisfies
  Section 6's "allow gizmo adjustment... convert gizmo changes into local authoring
  offsets" requirement. Individual spot positions are NOT separately authored
  sub-points - they're computed (`ComputeSpotLocalTransform`/`ComputeSpotWorldTransform`),
  matching Section 6's own "generated parking positions" framing and this phase's own
  "don't store Capacity as an independently-editable field" rule extended to spots
  themselves.
- **`AllowVehicles` design decision** (this phase's own "keep... or fold into Metadata"
  choice): folded into the base `FNexusActivationPoint::Metadata` rather than added as
  a dedicated field - V5's `ENexusAllowedVehicles` bitmask enum does not exist anywhere
  in this V6 codebase yet, and nothing currently queries it. See
  `NexusParkingActivation.h`'s own header comment for the full reasoning.
- **Spacing default-resolution scoping note**: `RowGap`/`ColumnGap`'s `-1` value
  resolves to a fixed `DefaultSpacingCm` constant (50cm, `NexusParkingActivation.cpp`)
  for query-math purposes, NOT a real State/City/Highway-style inheritance chain (no
  such target exists for per-instance Parking spacing) - flagged explicitly rather than
  silently implying full parity with e.g. `FNexusHighway::LaneWidth`'s own real
  inheritance resolution.
- **V5 `FNexusStationInfoBase`/`FNexusParkingInfo` diff** (this phase's own explicit
  completion criterion): carried over UNCHANGED - `OccupiedIndex` (shape/semantics).
  NOT carried over - superseded by the shared base: `HighwaySplinePointId`/`HighwayId`
  (-> base `HighwayPointId`), `StationId` (-> base `ActivationPointId`), `StationName`
  (-> base `Name`), `OffsetLocation`/`OffsetRotation` (-> base fields, this type's grid
  origin). NOT carried over - dropped: `SegmentWidth`/`SegmentLength` (superseded by
  the NEW `SpotWidth`/`SpotLength`, which V5 never had), `AllowLanes` (no analogue in
  Section 6's own field list), `AllowVehicles` (folded into `Metadata`, see above),
  `SegmentRow`/`SegmentColumn` (renamed `Row`/`Column` per Section 6's own naming).
  NEW, not in V5 at all: `RowGap`/`ColumnGap`, `SpotWidth`/`SpotLength`, `BaseMesh`,
  `ParkingIndicatorMesh`, and the full query surface (`GetFreeSpotIndices`/
  `FindNextAvailableSpotIndex`/`ComputeSpotWorldTransform`) - V5's
  `FNexusParkingInfo` had zero query methods of its own beyond the inherited
  `GetTotalSegmentCount`/`HasFreeSegment`.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. In the Unreal Editor, run `Nexus.Mapping.LoadOrCreateConfig`, then
   `Nexus.Representation.DumpJunctionClassification` to find a real `HighwayPointId`.
2. `Nexus.Representation.AddTestParking <HighwayPointId> 4 10 1` - confirm the log line
   reports a 4x10 grid, Capacity=40, 4 pre-occupied (matching Section 6's own example).
3. `Nexus.Representation.QueryTestParking <ActivationPointId>` (from step 2's log) -
   confirm `HasAvailableSpot=true`, `FreeSpotCount=36`, `NextAvailableSpotIndex=1` (index
   0 is occupied per the seeded set), and a resolved `WorldLocation`/`WorldRotation` for
   that spot.
4. Select 'Select Mode', click the test Parking lot's own marker - confirm it's
   selectable/draggable at the anchor's own base offset (the grid's overall
   position), and the Details panel shows the `FNexusParkingActivation` payload
   (`Row`/`Column`/`RowGap`/`ColumnGap`/`SpotWidth`/`SpotLength`/`BaseMesh`/
   `ParkingIndicatorMesh`/`OccupiedIndex`).

## References

- `project-specifications/v6-master-architecture.md` (Section 6 — Parking must be a
  complete authoring system)
- `project-specifications/12-v6-activation-point-system.md`
- `project-specifications/10-v6-runtime-schema.md`
