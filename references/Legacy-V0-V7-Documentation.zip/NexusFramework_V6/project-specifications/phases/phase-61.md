# Phase 61 — Crosswalk — Traffic-Light Linkage

## Status

Ready for Review
Ready for Review: 2026-08-12 (agent, via `/TODO`)
In Review: 
Ready for QA: 
Complete: 

## Objective

Add LinkedTrafficLightId to Crosswalk, connecting it to a Phase 50 Traffic Light's PedestrianLED for future runtime coordination.

## Allowed

- Implement LinkedTrafficLightId field and resolution.
- Implement validation for a dangling link.
- Verify against a test junction with both a Traffic Light and a linked Crosswalk.
- Document (not implement) the runtime pedestrian-signal contract this enables.

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

- [ ] Linked test case resolves correctly; dangling case caught by validation.
      (Implementation + build done; not yet manually verified in-editor - see
      "Manual verification required" below.)

## Implementation Notes (2026-08-12)

- `FNexusCrosswalkActivation::LinkedTrafficLightId` (`FGuid`, invalid = unlinked) added
  to `NexusCrosswalkActivation.h`, referencing a Traffic Light's own
  `ActivationPointId` - never a sub-field of it directly (see this struct's own header
  comment and `12-v6-activation-point-system.md`'s new "Crosswalk LinkedTrafficLightId
  runtime pedestrian-signal contract" section).
- `FNexusCrosswalkActivation::ValidateLinkedTrafficLight` (new
  `NexusCrosswalkActivation.cpp`) flags a dangling link as `Blocking`. Takes a
  caller-resolved `TArrayView<const FGuid>` of known Traffic Light
  `ActivationPointId`s rather than an `FNexusRepresentationGraph` - Activation Points
  are not stored in that graph (still an open architecture question, see
  `ai-change-audits/README.md`'s "Current open threads"), same "storage-agnostic,
  caller resolves candidates" split `FindActivationPointsInSignalGroup` (Phase 52)
  already established.
- Two new console commands in `NexusCrosswalkActivationRegistration.cpp`:
  `Nexus.Representation.LinkCrosswalkToTrafficLight` (sets the link; `InjectDangling=1`
  assigns a fresh unresolvable Guid) and
  `Nexus.Representation.ValidateCrosswalkLinkedTrafficLight` (runs the validation and
  logs entries).
- No sub-point/gizmo/renderer changes - `LinkedTrafficLightId` is a plain reference
  field, same "Details-panel-editable only, never gizmo-enumerated" precedent as
  `FNexusTrafficLightActivation::ControlledLaneIds`/`ControlledRoadIds`.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. In the Unreal Editor, run `Nexus.Mapping.LoadOrCreateConfig`, then
   `Nexus.Representation.DumpJunctionClassification` to find a real junction's
   `HighwayPointId`.
2. `Nexus.Representation.AddTestTrafficLight <HighwayPointId> 1` - note the logged
   `ActivationPointId` (the Traffic Light).
3. `Nexus.Representation.AddTestCrosswalk <HighwayPointId> 2 1` - note the logged
   `ActivationPointId` (the Crosswalk).
4. `Nexus.Representation.LinkCrosswalkToTrafficLight <CrosswalkActivationPointId> <TrafficLightActivationPointId>`.
5. `Nexus.Representation.ValidateCrosswalkLinkedTrafficLight <CrosswalkActivationPointId>` -
   confirm it logs "clean - zero validation entries."
6. Re-run step 4 with a third arg of `1` (`InjectDangling=1`), then re-run step 5 -
   confirm exactly one `BLOCKING` entry is logged for the injected dangling
   `LinkedTrafficLightId`.
7. Select 'Select Mode' in the viewport, click the test Crosswalk's `StartPoint` marker -
   confirm the Details panel shows the `FNexusCrosswalkActivation` payload struct,
   including the `LinkedTrafficLightId` field editable directly (no Crosswalk-specific
   UI code needed for this - generic `TestActivationPointPayload` binding).

## References

- `project-specifications/12-v6-activation-point-system.md`
