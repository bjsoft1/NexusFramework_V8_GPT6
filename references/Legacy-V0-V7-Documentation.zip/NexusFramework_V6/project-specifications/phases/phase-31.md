# Phase 31 — Debug Rendering — Roads Group

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:29 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Register and implement renderers for the Roads group's leaves: Highways, Lanes, Lane direction, Sidewalks, Junctions.

## Allowed

- Register all five leaves under the Roads group.
- Implement Highway/Lane/Sidewalk outline renderers from Representation-stage width/gap fields.
- Implement lane-direction arrow renderers.
- Implement Junction highlighting using Phase 20's junction-detection query.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Note: added the width/lane inheritable fields this phase needed

`FNexusHighway`/`FNexusCity`/`FNexusState` had no width/lane-count fields at all before
this phase (checked - none existed) even though `05-v6-data-flow.md`'s Identity rules
already documented the "-1/0/>0... width, gap, length..." convention as a general rule.
This phase's own Allowed list requires rendering "from Representation-stage width/gap
fields", so `HalfWidth`/`LaneWidth`/`SidewalkWidth`/`LaneCount` (V5's own field-naming
precedent, `v5-complete-reference.md`) were added to all three structs as part of this
phase, not assumed to already exist. See the batch audit record for the full reasoning.

## Revision — 2026-08-10 (same day, after this phase was already Ready for QA)

User feedback: manual QA via console-command output alone is hard to follow; asked for
the Highways/Lanes leaves specifically to be large and high-contrast in the viewport so
they're identifiable at a glance, without needing the Debug Tree's own per-category
color picker as a prerequisite step first. `MakeRoadsLeaf` (`NexusDebugRoadsGroupRenderers.cpp`)
now takes optional `Color`/`LineThickness` overrides (default unchanged - the Roads
group's own grey, `LineThickness=2`, for the three leaves not touched here):
`Roads.Highways` -> hot pink `(1.0, 0.05, 0.55)`, thickness 10; `Roads.Lanes` -> bright
gold `(1.0, 0.85, 0.05)`, thickness 8 (a distinct color from Highways, on purpose - real-
world yellow/white lane-marking convention, and keeps the two separable when both are
visible at once, not just individually loud). Only `DefaultConfig` changed - the user's
own already-saved runtime config (Phase 26 persistence) for these categories, if any,
is untouched; this only affects what a category starts at before the user overrides it.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — both left unchecked for the user's
own manual pass.

- [ ] **(New, 2026-08-10)** `Roads.Highways` renders hot pink and noticeably thicker
      than the other Roads leaves; `Roads.Lanes` renders bright gold, also thicker than
      default, and visually distinct from Highways. **To check**: tick Debug Tree ->
      Roads -> Highways and Lanes on a mapped test Highway with LaneCount >= 2 and
      confirm both are easy to pick out against the Landscape and against each other at
      normal viewport zoom.
- [ ] Lane and sidewalk outlines correctly reflect the -1/0/>0 inheritance resolution
      (04/05) on a test Highway with an override set. **To check**: leave a Highway's
      `LaneWidth`/`SidewalkWidth` at -1 (inherit) while setting an explicit override on
      its owning City (or State), confirm the rendered outline uses the inherited
      value; then set an explicit override directly on the Highway and confirm it wins
      (most-specific-wins); then set a field to exactly 0 on the Highway and confirm
      that outline disappears entirely (0 = explicitly disabled, not zero-width).
- [ ] Junction highlighting correctly identifies the Phase 07 3-way-junction test case.
      **To check**: tick Debug Tree -> Roads -> Junctions and confirm a marker appears
      only at the known 3-way-junction point from Phase 07's own test data, not at
      ordinary 2-connection mid-chain points.

## References

- `project-specifications/06-v6-debug-system.md`
- `project-specifications/05-v6-data-flow.md`
- `project-specifications/phases/phase-30a.md` (2026-08-10 — curve-accurate segment/
  offset lines; this phase's own `DrawOffsetPolyline` helper was always a "straight-per-
  segment approximation" by design, see that phase's own Context for why that's now
  being revisited)
