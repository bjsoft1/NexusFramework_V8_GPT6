# Phase 77 — Gizmo — Undo/Redo Hardening

## Status

Ready for Review
Ready for Review: 2026-08-22 16:22 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Stress-test undo/redo across multi-step gizmo edit sequences and across editor sessions, closing any gap found.

## Allowed

- Test long undo chains (10+ sequential gizmo edits) for correctness.
- Test undo/redo interaction with the Phase 27 Diagnostics panel (does an undone edit correctly clear a validation warning it caused?).
- Test transaction naming/grouping is sensible in the Editor's Undo History panel.
- Fix any gap found.

## Not Allowed

- Do not let a gizmo edit write to Landscape/`ULandscapeSplineControlPoint` transforms.
- Do not bypass FScopedTransaction/Modify() for gizmo-driven edits (undo/redo must work).
- Do not implement scale handling - offsets are not scaled objects (see 13).

## Completion Criteria

- [~] IMPLEMENTED, user-verified step. Per `AGENT-RULES.md` no automated test was written;
      the phase ran as a code audit + fixes, and the 12-edit chain exercise is listed as
      manual steps in `ai-change-audits/2026-08-22/feature-add/phase-77-gizmo-undo-redo-hardening.md`.
      `Nexus.Gizmo.DumpUndoHistory` was added so the chain can be counted and named without
      losing track. Four gaps found and fixed - most seriously, undo records were addressed
      by transform PROXY rather than by data, so undoing after a selection change could write
      an old sub-point's transform into a DIFFERENT sub-point (silent corruption). Records are
      now data-addressed, one per gesture, named per sub-point, and no-op edits are suppressed.
- [~] Found the reason this was untestable: `NexusDiagnostics.cpp` passed an EMPTY
      ActivationPoint array to `ValidateRepresentationStage`, so NO Activation Point was
      validated at all and nothing could raise a warning to undo. FIXED - it now passes the
      real, persisted set. Still NOT fully exercisable by a gizmo edit, because the gizmo
      edits session-only test-store data that is outside the config asset: that is Phase 75's
      GAP 1 (payload persistence unresolved), not a separate issue, and it resolves for free
      once sub-pointed types can be persisted.

## References

- `project-specifications/13-v6-gizmo-system.md`
