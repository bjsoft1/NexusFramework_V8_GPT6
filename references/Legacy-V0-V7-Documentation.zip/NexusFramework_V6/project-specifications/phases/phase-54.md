# Phase 54 — Traffic Light — Gizmo Offset Editing

## Status

Ready for Review
Ready for Review: 2026-08-12 02:26 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Enable gizmo editing for all three Traffic Light sub-offsets independently, building on Phase 48's proven base gizmo flow.

## Allowed

- Enable bSupportsGizmo for the Traffic Light leaves.
- Implement independent selection/editing of Pole vs VehicleLED vs PedestrianLED sub-offsets.
- Verify editing one sub-offset never affects the others or the shared anchor.
- Verify undo/redo per sub-offset edit.

## Not Allowed

- Do not let a gizmo edit write to Landscape/`ULandscapeSplineControlPoint` transforms.
- Do not bypass FScopedTransaction/Modify() for gizmo-driven edits (undo/redo must work).
- Do not implement scale handling - offsets are not scaled objects (see 13).

## Completion Criteria

- [ ] Each of the three sub-offsets is independently gizmo-editable, proven by a test
      editing all three in sequence. Per `project-specifications/AGENT-RULES.md`'s Agent
      Testing Policy, not run/verified by the agent this session - left unchecked. **To
      check**: see "Manual verification required" below.
- [ ] Undo/redo correctly isolated per edit. Same manual-verification note as above.

## Implementation (2026-08-12) — zero new code, verification-only phase

Confirmed by re-reading `13-v6-gizmo-system.md`'s own "Sub-point addressing" section
(direct quote: *"Traffic Light (Phase 54) and City Light (Phase 58) are call sites that
configure which sub-point keys exist for their type, not separate gizmo
implementations"*) plus the actual code, that this phase's entire Allowed/Completion
Criteria list is **already fully satisfied by existing, prior work** — the "call site"
this doc refers to was Phase 50 itself (declaring `Pole`/`VehicleLED`/`PedestrianLED` as
three `FNexusSubPointOffset` fields on `FNexusTrafficLightActivation`), not this phase.
No source file was touched.

- **"Enable bSupportsGizmo (CanSupportGizmo) for the Traffic Light leaves"** — already
  true. `FNexusTrafficLightActivation`'s `DefaultDebugCategory` is
  `Runtime.ActivationPoints` (`NexusTrafficLightActivationRegistration.cpp`, unchanged
  since Phase 50), and that category's `DefaultConfig.IsSelectable`/`CanSupportGizmo` were
  both already set `true` at Phase 48's own registration
  (`NexusDebugRuntimeGroupRenderers.cpp`'s `GRegisterActivationPoints`). Phase 53's two
  new `Infrastructure.TrafficLight`/`TrafficLightLED` leaves are visualization-only
  (`IsSelectable`/`CanSupportGizmo` left at their default `false`, deliberately - see that
  phase's own record) and are never consulted by the gizmo's click-test, which reads a
  TYPE's single `DefaultDebugCategory`, not every category that type happens to render
  under - so nothing about them needed to change for THIS completion criterion; "the
  Traffic Light leaves" in this phase's own Objective/Allowed wording is satisfied via
  `Runtime.ActivationPoints`, the operative category the gizmo mechanism actually reads.
- **"Independent selection/editing of Pole vs VehicleLED vs PedestrianLED"** — already
  true, fully generically. `FNexusActivationTypeRegistry::EnumerateDeclaredSubPointFields`
  reflects over `FNexusTrafficLightActivation`'s own `FProperty` list for
  `FNexusSubPointOffset`-typed fields (fixed or array), with zero knowledge of "Traffic
  Light" as a concept - it finds Pole/VehicleLED/PedestrianLED as three independent
  sub-point keys purely by their C++ type, the exact same reflection path every other
  registered type (including the Phase 45 dummy types) already goes through.
  `UNexusActivationGizmoTool::FindClosestSubPointHit`/`SelectSubPoint`/
  `HandleGizmoTransformChanged` are all already fully generic over sub-point keys (no
  Traffic-Light-specific branch anywhere in that file) - confirmed by re-reading the file
  in full, not assumed.
- **"Editing one sub-offset never affects the others or the shared anchor"** — true by
  construction: `FNexusActivationSubPointResolver::SetSubPointOffset` writes to exactly
  one `FNexusSubPointOffset` field (identified by its own `FNexusActivationPointSubPointKey`),
  and the anchor (`FNexusActivationPoint::HighwayPointId`) is never touched by any gizmo
  write-back path - `HandleGizmoTransformChanged`'s own formula
  (`NewOffset = NewWorldTransform * Inverse(AnchorWorldTransform)`) only ever produces a
  new LOCAL offset for the one selected key.
- **"Undo/redo per sub-offset edit"** — already true via the mechanism Phase 48/49's own
  audit records already verified in full: `UTransformProxy`'s built-in
  `BeginTransformEditSequence`/`EndTransformEditSequence` participate in the Interactive
  Tools Framework's own real `FScopedTransaction` (opened once per drag gesture by
  `UModeManagerInteractiveToolsContext`), collapsing one drag into one undo step -
  type-agnostic, no Traffic-Light-specific undo code exists or is needed.
- **"Do not implement scale handling"** — true; `HandleGizmoTransformChanged` only ever
  reads `GetLocation()`/`Rotator()` off the resulting transform, never scale, for every
  type including Traffic Light.

No code changed. This phase exists to formally verify the above against a real
multi-sub-point object in the editor (something Phase 50's own manual-verification steps
already partially covered but never explicitly confirmed for "editing one never
disturbs the others" and "undo/redo isolation" specifically) - not to build anything new.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. `Nexus.Representation.AddTestTrafficLight <HighwayPointId> 1` (a real junction, from
   `Nexus.Representation.DumpJunctionClassification`'s own log output).
2. In Select Mode, click the Pole sub-point marker - confirm a gizmo appears at Pole's
   own position (not at VehicleLED/PedestrianLED or the anchor). Drag it a short
   distance - confirm VehicleLED/PedestrianLED markers and the anchor do NOT move.
3. Click the VehicleLED marker - confirm the gizmo re-targets there (Pole stays at its
   new dragged position, untouched). Drag it. Repeat for PedestrianLED.
4. Ctrl+Z three times - confirm each undo reverts exactly one of the three drags, in
   reverse order, leaving the other two edits intact each time (not a single combined
   undo, not reverting more than one edit per Ctrl+Z).
5. Ctrl+Y three times - confirm all three edits are correctly reapplied in original
   order.

## References

- `project-specifications/13-v6-gizmo-system.md`
