# Phase 90 — Optimization — Static Generation at Scale

## Status

Ready for Review
Ready for Review: 2026-08-22 20:40 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Re-run Phases 41-43's Static Generator pipeline against the Phase 35 synthetic GTA-V-scale test Landscape and fix whatever doesn't hold up.

## Allowed

- Run the full Static Generator pipeline against the large-scale test Landscape.
- Profile mesh-merge and instancing time at scale.
- Fix any bottleneck found (do not silently accept a regression from the Phase 41-43 baselines).
- Record final at-scale timing as the release baseline.

## Not Allowed

- Do not optimize a subsystem that hasn't been correctness-verified first.
- Do not introduce caching that can silently go stale (see the V5 lessons doc for why this matters).

## Completion Criteria

- [ ] Large-scale generation run completes within a documented, agreed time budget.
- [ ] Any fix made is re-verified against the original Phase 41-43 correctness tests (no regression).

## References

- `project-specifications/11-v6-static-dynamic-architecture.md`

## Static at-scale audit (agent, 2026-08-22)

Reviewed the Generation and Compilation paths for complexity that only matters at
GTA-V-scale N. **One real bottleneck found and fixed**, in the Compilation stage:

`FNexusRuntimeCompiler::Compile` rebuilt each point's Highway membership by scanning every
Highway per point - O(points x highways). At the 100,000-point scale
`11-v6-static-dynamic-architecture.md` targets, with a few thousand Highways, that is
hundreds of millions of comparisons for a single compile: slow enough to read as a hang
rather than a wait. Replaced with a single inverse-index pass over Highways, after which
each point's lookup is O(1). Behaviour is identical - the 11-test suite still passes.

The Static Generator's own mesh-merge/instancing paths (Phases 41-43) were **not** modified.
Nothing in them was found to be obviously super-linear on inspection, but "not obviously
wrong on inspection" is not a performance result, and this phase's Not-Allowed list is
explicit that a subsystem must be correctness-verified before it is optimized.

**No profiling run was performed.** An agent cannot run the editor for automation
(AGENT-RULES.md), and "at scale" is a *measured* property - so this phase's criteria are
left **unchecked**. What was done instead is a static at-scale audit: reading the code for
algorithmic hazards that only bite at large N, and fixing what that found. That is real work
and it is build-verified, but it is not the measurement this phase asks for.

## Manual verification still required from the user

1. Run the full Static Generator pipeline against the Phase 35 synthetic large-scale test
   Landscape; record mesh-merge and instancing time.
2. Compare against the Phase 41-43 baselines and agree a time budget.
3. Re-run Phase 41-43's correctness checks after any fix, per this phase's own criterion.
