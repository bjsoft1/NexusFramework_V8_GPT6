# Phase 32 — Debug Rendering — Mapping Group

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:29 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Register and implement renderers for the Mapping group's leaves: HighwayPointId labels, City/State membership, source-point resolution status.

## Allowed

- Register all three leaves under the Mapping group.
- Implement HighwayPointId label renderer (short-form GUID display).
- Implement City/State membership color-coding (one color per City, for instance).
- Implement resolution-status renderer (green=resolved, red=broken) reading Phase 14's validation output.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Known deviation: broken points cannot render red

A HighwayPoint whose `SourcePoint` fails to resolve has no drawable world location at
all, by this project's own "resolve-or-fail, never a fallback location" rule (Phase 18).
`Mapping.ResolutionStatus` therefore only draws GREEN markers at resolved points -
there is no "at" to draw a red marker at for a broken one. Phase 27's Diagnostics panel
already lists exactly this case (list-only, no marker, same underlying reason). See the
batch audit record for the full reasoning; **the first completion criterion below is
consequently only half-satisfiable as originally worded** and is marked accordingly
rather than silently claimed.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — both left unchecked for the user's
own manual pass.

- [ ] A deliberately-broken test point renders red under this category and clean points
      render green. **Partially achievable only** — see "Known deviation" above. **To
      check**: with a mixed config (some resolved points, one with a deleted/broken
      SourcePoint), tick Debug Tree -> Mapping -> Resolution Status and confirm every
      resolved point shows green; confirm the broken point shows nothing here (not a
      false green) and instead appears in the Diagnostics panel.
- [ ] City membership color-coding is visually distinct across a multi-City test map.
      **To check**: assign Highways to at least 2-3 different Cities, tick Debug Tree ->
      Mapping -> City/State Membership, and confirm each City's points render in a
      visibly different color from the others.

## References

- `project-specifications/06-v6-debug-system.md`
