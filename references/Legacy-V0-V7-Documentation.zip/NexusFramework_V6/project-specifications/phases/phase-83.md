# Phase 83 — Runtime Compiler — Streaming Integration

## Status

Ready for Review
Ready for Review: 2026-08-22 18:20 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Wire Compilation output to respect the Phase 43 streaming-cell grouping, so the shipped Runtime Schema asset can be split/loaded per World Partition Data Layer.

## Allowed

- Implement per-cell Compilation output partitioning, reusing Phase 43's grouping.
- Verify a multi-cell test map compiles into correctly-separated runtime data.
- Verify loading one cell's compiled data doesn't require loading all cells.
- Cross-check against V5's DataLayerAssetName precedent for consistency.

## Not Allowed

- Do not put editor-only/UObject-heavy types into runtime-consumed structs.
- Do not let the runtime module depend on NexusFrameworkEditor.
- Do not skip the Compilation-stage validation gate before an asset is allowed to save.

## Completion Criteria

- [ ] Multi-cell test proves independent per-cell compiled output and loading.

## References

- `project-specifications/10-v6-runtime-schema.md`

## Implementation (agent, 2026-08-22)

`FNexusRuntimeCompiler::CompilePerCell` partitions compiled output by streaming cell, reusing
Phase 43's `FNexusStreamingCellResolver` rather than inventing a second notion of "cell" -
so a cell is still V5's `FNexusState::DataLayerAssetName`, unchanged.

**Compile once, then partition** - rather than running the whole compile once per cell.
Compilation reads live Landscape geometry, the expensive part; doing that N times to produce
N disjoint slices would scale with cell count for no benefit, and risks slices disagreeing if
anything moved between passes.

One `UNexusRuntimeDataAsset` is written per cell, so loading one cell's data never pulls in
another's. `NAME_None` is a real key meaning "the ungrouped/default cell" - an explicit
bucket for objects whose owning State has no Data Layer yet, never silently merged into a
neighbouring cell.

## Manual verification still required from the user

Needs a multi-State map with distinct `DataLayerAssetName` values - this cannot be verified
on a single-State test map, and `Nexus.Compilation.CompilePerCell` reporting one cell means
the test is inconclusive, not passing.

1. `Nexus.Compilation.CompilePerCell` - confirm one row per Data Layer, with entry counts
   summing to the whole-world totals from `Nexus.Compilation.Compile`.
2. `Nexus.Compilation.CompileAndSave` - confirm one `NexusRuntime_<CellName>` asset per cell.
3. Load a single cell's asset and confirm it resolves without the others present.
