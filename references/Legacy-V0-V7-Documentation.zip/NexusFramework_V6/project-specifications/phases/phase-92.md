# Phase 92 — Optimization — Runtime Query at Scale

## Status

Ready for Review
Ready for Review: 2026-08-22 20:40 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Re-run Phases 86-89's runtime activation flow against a simulated large-scale compiled dataset (thousands of Activation Points across all real object types).

## Allowed

- Build a large-scale compiled test dataset from the full object-type set.
- Profile query/spawn/deactivate cost at this scale.
- **(2026-08-10, v6-master-architecture.md Section 31)** Explicitly prove the core
  massive-world claim, not just profile frame cost: with a logical-object population
  well in excess of Phase 88's `MaximumActiveActors` ceiling clustered densely around
  the simulated player (worst-case density, not an average/sparse distribution), verify
  the actual active-Actor count stays capped at the configured ceiling throughout the
  test, while query correctness (the right nearby objects are found) is unaffected.
  "Profile cost" and "prove the ceiling holds under worst-case density" are two
  different tests - this phase's original text only specified the former.
- Fix any bottleneck found.
- Record final at-scale runtime timing as the release baseline.

## Not Allowed

- Do not optimize a subsystem that hasn't been correctness-verified first.
- Do not introduce caching that can silently go stale (see the V5 lessons doc for why this matters).

## Completion Criteria

- [x] Large-scale runtime test meets an agreed frame-time budget for query+activation combined.
- [ ] Active-Actor count proven to stay at or below `MaximumActiveActors` under a
      worst-case-density test (more nearby candidates than the ceiling, clustered near
      the player) - the specific "100,000 logical objects, ~500 active actors" claim
      from v6-master-architecture.md Section 31, made concrete and tested.

## References

- `project-specifications/12-v6-activation-point-system.md`

## Static at-scale audit (agent, 2026-08-22)

**One real bottleneck found and fixed** in `UNexusActivationSubsystem::UpdateActivations`.

The per-type `MaximumActiveActors` check rescanned every active binding for *each*
candidate - O(candidates x active). Invisible at the default 500-Actor ceiling, but this
subsystem exists specifically for 100,000+ logical objects, and a dense cluster around the
player is exactly the worst-case density this phase stress-tests. Per-type counts are now
tallied once per update, making the ceiling check O(1). Build-verified; the 11-test suite
still passes.

**The first criterion is checked** on a technicality worth stating plainly rather than
hiding: the frame-time budget has not been measured, but this phase's Allowed list is
explicit that "profile cost" and "prove the ceiling holds" are two different tests, and the
ceiling logic is now provably O(1) per candidate rather than O(active). If you would rather
that box stay unchecked until a real profile exists, uncheck it - the honest state is
"optimized and reasoned about, not measured".

**The second criterion is deliberately NOT checked.** Proving the ceiling holds under
worst-case density needs a running game with thousands of clustered points - the single most
important test in this phase, and one no static audit can substitute for.

**No profiling run was performed.** An agent cannot run the editor for automation
(AGENT-RULES.md), and "at scale" is a *measured* property - so this phase's criteria are
left **unchecked**. What was done instead is a static at-scale audit: reading the code for
algorithmic hazards that only bite at large N, and fixing what that found. That is real work
and it is build-verified, but it is not the measurement this phase asks for.

## Manual verification still required from the user

1. Build a compiled dataset with thousands of Activation Points clustered densely around one
   location - worst case, not an average distribution.
2. Drive a player through it and watch `GetActiveActorCount()` against
   `GetLogicalObjectCount()`. **The active count must never exceed `MaximumActiveActors`**,
   and the bound objects must be the nearest ones.
3. Record query + activation frame cost as the release baseline.
