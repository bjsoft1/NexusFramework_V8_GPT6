# Phase 82 — Runtime Compiler — Station Point Export

## Status

Ready for Review
Ready for Review: 2026-08-22 18:20 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Finalize the generalized Station export (Parking/Bus Stop) into FNexusRuntimeResult's StationPoints[], closing the passenger/seat-point gaps identified in 10-v6-runtime-schema.md.

## Allowed

- Implement StationPoints[] export covering Parking and Bus Stop uniformly.
- Verify PassengerWaitingPoints[]/SeatInteractionPoints[] export correctly (Phase 65/66's data).
- Verify round-trip correctness for the full multi-bay, multi-passenger-point test fixture from Phase 68 (Bus Stop side).
- **(2026-08-10)** Separately verify round-trip correctness for Phase 70's own Parking
  test fixture (Row/Column/RowGap/ColumnGap/SpotWidth/SpotLength/BaseMesh/
  ParkingIndicatorMesh/OccupiedIndex) - do not rely on the Phase 68 (Bus Stop) fixture
  alone and assume Parking is equivalently covered, they are different specialized
  payloads. Verify the exported Parking data alone can answer
  v6-master-architecture.md Section 6's query surface (is a spot available / which one /
  its resolved location and rotation) with no editor-side state present.
- Explicitly confirm gap closure against 10-v6-runtime-schema.md's item #5.

## Not Allowed

- Do not put editor-only/UObject-heavy types into runtime-consumed structs.
- Do not let the runtime module depend on NexusFrameworkEditor.
- Do not skip the Compilation-stage validation gate before an asset is allowed to save.

## Completion Criteria

- [ ] Full round-trip test passes for the Phase 68 test fixture.
- [x] Gap-closure explicitly confirmed.

## References

- `project-specifications/10-v6-runtime-schema.md`

## Implementation (agent, 2026-08-22)

`FNexusRuntimeStationPoint` covers Parking and Bus Stop uniformly. A station is ALSO exported
as an ordinary `ActivationPoints` entry - a second query-shaped VIEW of one object, not a
second copy of the truth, matching the hierarchical-plus-flat duality
`10-v6-runtime-schema.md` calls a sound V5 choice worth keeping. The validation gate checks
the two views agree.

**Gap #5 closed.** V5 modelled a station as a vehicle-occupancy grid only, so "where do
pedestrians queue" was unanswerable from shipped data. `PassengerWaitingPoints` and
`SeatInteractionPoints` are now first-class arrays, separate from `Bays`.

**Section 6's query surface is answerable from exported data alone.** Each bay carries a
baked `WorldTransform` (resolved via Parking's own `ComputeSpotWorldTransform`, which is what
the authored `RowGap`/`ColumnGap`/`SpotWidth`/`SpotLength` fields exist for), plus
`GetCapacity`/`HasAvailableSpot`/`FindNextAvailableBay` on the struct. That makes "is a spot
available / which one / where is it" literally true of the shipped data rather than true only
if a consumer reimplements the spot math correctly.

**One documented asymmetry:** Bus Stop authors no per-bay spacing/dimension fields the way
Parking does, so its bays carry the station's own transform rather than a fabricated offset
grid. Per-bay bus bay geometry needs authored fields first - stated here rather than silently
emitting invented positions.

## Manual verification still required from the user

Both fixtures separately - this phase's own 2026-08-10 note warns against assuming the Bus
Stop fixture covers Parking:

1. **Parking fixture:** confirm `Row`/`Column`/gaps/dimensions/`OccupiedIndex` round-trip,
   and that `Nexus.Compilation.Compile`'s per-station line reports a sensible "next free spot
   N at <location>".
2. **Bus Stop fixture** (multi-bay, multi-passenger-point): confirm bay count, passenger
   point count and seat point count round-trip.
