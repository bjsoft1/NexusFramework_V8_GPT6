# Phase 08 — Landscape Reader — Stable Identity

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement V5's proven control-point-rename identity trick (deterministic "NexusPoint_<guid>" naming for a stable FSoftObjectPath) since subclassing ULandscapeSplineControlPoint remains engine-blocked in UE 5.8.

## Allowed

- Implement the rename-to-stable-name routine for a newly-encountered control point.
- Implement the on-target-Landscape guard (V5's IsControlPointOnTargetLandscape fix) before trusting any resolved TSoftObjectPtr.
- Verify identity survives an editor restart and a map close/reopen.
- Verify identity does NOT falsely resolve to a same-named point on a DIFFERENT, still-resident map (the cross-map bug class).

## Not Allowed

- Do not write to the Landscape (Source stage is read-only, always).
- Do not assign Nexus IDs yet (that is Mapping's job, next stage).
- Do not cache Location/Rotation/Tangent as authoritative anywhere.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — left unchecked for the user's own
manual pass:

- [ ] A tagged point's identity survives editor restart. **Baseline captured
      2026-08-10**: user ran `Nexus.Reader.TagControlPointIdentities` against the test
      Landscape and got real `NexusPoint_<guid>` names/`StableId` values for all 10
      points (logged). Restart-and-recompare has not been done yet, so this criterion
      stays open. **To check**: fully restart the editor (not just close/reopen the
      level), then run the same command again and confirm the same points log the
      *same* `StableId` values as the baseline above (not new ones — the command is
      idempotent, it only renames untagged points).
- [ ] The cross-map false-resolve case is proven NOT to occur, with a test reproducing
      V5's original bug scenario. **To check**: reproduce V5's cross-map scenario —
      have two maps open/resident (e.g. via level streaming or opening a second map
      without fully unloading the first, so both packages are still in memory), each
      with their own Landscape and control points; confirm
      `FNexusLandscapeReader::IsControlPointOnTargetLandscape` (exercised indirectly via
      `Nexus.Reader.ValidateSourceStage`, Phase 09) correctly rejects a control point
      that resolves but belongs to the OTHER map's splines component, rather than
      treating it as valid just because the pointer is non-null.

## References

- `project-specifications/01-v5-analysis.md`
- `project-specifications/03-v5-problems-and-lessons.md`
- `project-specifications/AGENT-RULES.md`
