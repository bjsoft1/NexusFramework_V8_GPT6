# Phase 26 — Debug Architecture — Config Persistence

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 14:53 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Persist per-category debug config to the config asset (per-Layout, matching V5's proven precedent) so settings survive editor restarts.

## Allowed

- Implement save of all registered categories' FNexusDebugRenderConfig to the config asset.
- Implement load/restore on plugin enable, before the tree view first renders.
- Handle a category present in saved data but no longer registered (stale entry) without crashing.
- Verify settings survive a full editor restart on a test project.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Revision — 2026-08-10 (root cause found and fixed: settings lost on editor restart)

User report: "I have setup the Debug tree view value (color, thickness) restart engine
the config disaparing." Root cause: a Debug Tree edit only ever wrote into
`FNexusDebugCategoryRegistry::RuntimeConfigs` (a process-lifetime, non-persisted
singleton) - nothing synced that into `ConfigAsset->DebugCategoryConfigs` or marked the
asset dirty until the user manually ran `Nexus.Mapping.SaveConfig`, which this phase's
own original completion criterion always required but nothing in the UI prompted for or
did automatically. Combined with the same-day `Config.Modify()`/auto-save work
(`phases/phase-26a.md`), this meant a real edit was silently lost on restart unless the
user remembered the console command first - exactly what was reported.

**Fix**: `SNexusFrameworkPanel` now binds `DetailsView->GetOnFinishedChangingPropertiesDelegate()`
(new `OnDebugCategoryDetailsFinishedChangingProperties`) - whenever an edit finishes AND
the Details panel is currently showing a Debug category (not a Hierarchy/Placeholder
selection, tracked via new `bDetailsViewShowsDebugCategory`), it calls
`ActiveConfig->Modify()` then `FNexusDebugCategoryRegistry::SaveRuntimeConfigsToConfigAsset`
immediately - the edit is written into the config asset and the asset marked dirty the
moment the edit completes, not only at an explicit Save. Combined with Phase 26a's
`HandlePostSaveWorld` auto-save hook, saving the level now also saves the Debug category
change - `Nexus.Mapping.SaveConfig` becomes a manual option, not a requirement, to avoid
losing a change. Real Ctrl+Z/Ctrl+Y for this same edit is still Phase 26a's own separate,
not-yet-implemented scope (this fix is data-loss prevention only, not undo).

## Correction — 2026-08-10 (the above revision itself introduced a real editor crash)

The dirty-marking fix above (`OnDebugCategoryDetailsFinishedChangingProperties` calling
`SaveRuntimeConfigsToConfigAsset` on every edit) caused a real, reproducible
`EXCEPTION_ACCESS_VIOLATION` crash, reported directly by the user with a full callstack
(`FString::AssignRange` inside a Details-panel Slate repaint). Root cause:
`SaveRuntimeConfigsToConfigAsset` walks EVERY registered category (dozens), and for any
category never touched yet this session, `GetMutableRuntimeConfig` inserts a new entry
into `FNexusDebugCategoryRegistry::RuntimeConfigs` (previously a plain `TMap<FName,
FNexusDebugRenderConfig>`). `TMap::Add` can reallocate the map's backing storage on
growth, which invalidates every raw pointer previously returned into it - including the
one the Details panel was still bound to for the category just edited. The very next
repaint dereferenced that now-dangling pointer. Exactly the class of bug V5's own
`PostEditUndo()` crash history already warned about (a raw struct pointer surviving a
container mutation it shouldn't have) - see `phases/phase-26a.md`'s own Context section,
which quoted that precedent before this exact failure mode actually reproduced.

**Fix**: `RuntimeConfigs` is now `TMap<FName, TUniquePtr<FNexusDebugRenderConfig>>` -
growing/rehashing the map only moves the small TUniquePtr handles, never the
`FNexusDebugRenderConfig` each one owns, so a raw pointer any caller already holds (the
Details panel included) stays valid regardless of what else gets inserted into the map
afterward. `RestoreRuntimeConfigsFromConfigAsset` updates an already-present entry's
VALUE in place (`**Existing = Pair.Value`) rather than replacing its `TUniquePtr`
wholesale, for the same reason. `FNexusDebugCategoryRegistry`'s copy
constructor/assignment are now explicitly deleted (required for this DLL-exported class
to compile with a non-copyable `TUniquePtr` member - also just correct for a singleton).
See `ai-change-audits/2026-08-10/bug-fixed/debug-details-panel-dangling-pointer-crash.md`.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — both left unchecked for the user's
own manual pass.

- [ ] A changed color/thickness on any category survives an editor restart, AND does not
      crash the Details panel on repaint immediately after the edit (2026-08-10
      Correction). **To check
      (2026-08-10 revision - no longer requires the manual SaveConfig step)**: select a
      category in the Debug Tree, change its Color/LineThickness in the Details panel
      (confirm the config asset shows dirty in the Content Browser immediately after),
      save the level (triggers the Phase 26a auto-save hook) OR run
      `Nexus.Mapping.SaveConfig` directly, fully restart the editor, re-enter Landscape
      Mode (triggers `RestoreRuntimeConfigsFromConfigAsset`), run
      `Nexus.Debug.DumpCategoryRuntimeConfigs` and confirm the changed value persisted.
- [ ] A deliberately-stale saved category entry is ignored cleanly, not a crash. The
      guard itself is code-visible and crash-free by inspection —
      `FNexusDebugCategoryRegistry::RestoreRuntimeConfigsFromConfigAsset` checks
      `FindCategory(Pair.Key)` before touching anything and `continue`s (with a log
      warning) on a miss, never dereferencing an unresolved category — but a genuinely
      stale `DebugCategoryConfigs` entry can't be produced with real data yet (no phase
      through 26 removes/renames a registered category). Left unchecked pending either
      a real scenario once such a phase exists, or the user manually editing a saved
      config asset's `DebugCategoryConfigs` to inject one - deliberately not building a
      synthetic corrupt-the-asset-for-testing console command for this, same reasoning
      as Phase 22's equivalent gap (`AGENT-RULES.md`'s Agent Testing Policy: no
      test-only code).

## References

- `project-specifications/06-v6-debug-system.md`
- `project-specifications/phases/phase-26a.md` (2026-08-10 — Undo/Redo for Debug
  category edits made through this phase's own Details-panel binding; also where this
  phase's own persistence gained automatic dirty-marking and auto-save-on-level-save)
