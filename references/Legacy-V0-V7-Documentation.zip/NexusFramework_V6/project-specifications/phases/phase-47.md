# Phase 47 — Activation Point — Spatial Query Index

## Status

In Review
Ready for Review: 2026-08-10 18:05 GMT+5:45 (+0545)
In Review: 2026-08-10 15:14 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Implement the Compilation-time baked spatial index for nearby-Activation-Point queries, per 12-v6-activation-point-system.md's runtime flow.

## Allowed

- Implement a spatial index structure (grid or similar) built once at Compilation time.
- Implement the nearby-query API against this baked index (not live recomputation).
- Benchmark query cost at a simulated few-thousand-Activation-Point scale.
- Verify the index correctly reflects offset-composed world positions, not raw anchors.

## Not Allowed

- Do not put editor-only/UObject-heavy types into runtime-consumed structs.
- Do not let the runtime module depend on NexusFrameworkEditor.
- Do not skip the Compilation-stage validation gate before an asset is allowed to save.

## Completion Criteria

- [ ] Few-thousand-point benchmark stays within an acceptable query-cost budget.
      `Nexus.Representation.BenchmarkSpatialGridIndex [PointCount=5000] [QueryCount=1000]`
      logs build time + total/average query time - not yet actually run (needs a
      manual editor session, no editor launch available to this agent).
- [x] Index rebuild is proven required only after Compilation re-runs, not per query -
      true by construction: `FNexusSpatialGridIndex::QueryNearby` is `const` and never
      calls `Build`/mutates `Buckets`/`Positions` in any way; the benchmark command
      itself calls `Build()` exactly once before its whole query loop, not per-query.

## Implementation Notes (2026-08-10)

- New `FNexusSpatialGridIndex` (`Public/Representation/NexusSpatialGridIndex.h` /
  `Private/.../NexusSpatialGridIndex.cpp`) - plain C++ class, no `UObject`/editor-only
  types (this phase's own Not Allowed rule), so it can move into the Runtime module
  unchanged whenever a real runtime consumer exists (Phase 85+). Uniform grid
  (`TMap<FIntVector, TArray<int32>>`), `Build()` O(N) bucket assignment, `QueryNearby()`
  narrows to the candidate cells within `radius` then does a real per-candidate distance
  check (not an approximation).
- `Nexus.Representation.BenchmarkSpatialGridIndex` synthesizes `PointCount` random
  points across a 5km square (deterministic seed - repeatable numbers, not different
  every run), builds one index, runs `QueryCount` 50m-radius queries against it, logs
  build time and per-query average.
- **Not yet wired to any real data source** - same "no real Activation Point storage
  exists yet" gap Phase 46 flagged; this phase's own benchmark deliberately uses
  synthetic positions rather than inventing a connection to real data, matching this
  phase's own "benchmark query cost at a simulated scale" Allowed action (it doesn't
  ask for real data, just a scale proof).

## Manual Verification Needed

In the Unreal Editor Output Log (no Landscape/ActiveConfig needed):
1. `Nexus.Representation.BenchmarkSpatialGridIndex` - confirm it completes quickly and
   note the logged build/query timings as this phase's own benchmark record.
2. Optionally rerun with a larger count, e.g.
   `Nexus.Representation.BenchmarkSpatialGridIndex 20000 5000`, to see the timing scale.

## References

- `project-specifications/12-v6-activation-point-system.md`
