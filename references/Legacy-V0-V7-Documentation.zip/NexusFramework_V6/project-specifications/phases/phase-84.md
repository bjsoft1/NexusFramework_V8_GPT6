# Phase 84 — Runtime Compiler — Validation Gate

## Status

Ready for Review
Ready for Review: 2026-08-22 18:20 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement 14-v6-validation.md's Compilation-stage gate: schema-level invariants (no duplicate Runtime Ids, no missing required fields) before an asset is allowed to save.

## Allowed

- Implement duplicate-Id detection across the full compiled dataset.
- Implement missing-required-field detection.
- Wire this as the final Blocking gate before FNexusRuntimeResult is allowed to save.
- Re-run every object type's round-trip test against this gate to confirm no false positives.

## Not Allowed

- Do not put editor-only/UObject-heavy types into runtime-consumed structs.
- Do not let the runtime module depend on NexusFrameworkEditor.
- Do not skip the Compilation-stage validation gate before an asset is allowed to save.

## Completion Criteria

- [ ] A deliberate duplicate-Id test case is caught as Blocking.
- [ ] All prior object types' round-trip tests still pass with zero false-positive blocks.

## References

- `project-specifications/14-v6-validation.md`

## Implementation (agent, 2026-08-22)

`FNexusRuntimeCompilationValidationGate` + `FNexusRuntimeCompilerIO::CompileAndSaveAll`.

**The gate is enforced by API shape, not by documentation.** There is deliberately no public
"save this result" entry point that skips validation - `CompileAndSaveAll` runs
compile -> validate -> save as one indivisible operation. Every one of Phases 80-85 carries the
"do not skip the Compilation-stage validation gate before an asset is allowed to save" rule;
making it structurally impossible to bypass is what makes that rule survive future callers.

**Blocking:** duplicate `HighwayPointId`/`ActivationPointId`, invalid (zero) primary keys,
an Activation Point with no `Type`, an Activation Point anchored to a HighwayPoint absent
from the same dataset, and a Station entry with no matching Activation Point entry.
**Warning:** a point in no Highway, a zero-length tangent, and no streaming cell - the last
is a Warning because `NAME_None` is a legitimate state for a non-World-Partition test map.

Duplicate ids are Blocking rather than Warning because every lookup helper resolves by FIRST
match: a duplicate never announces itself at runtime, it silently shadows the other entry
forever, which is worse than a failed compile.

**Validation results deliberately do not ship** inside `FNexusRuntimeResult` - gap #7's
stated resolution is that compilation-time validation gates whether compilation succeeds,
rather than becoming runtime payload.

**All-or-nothing across cells:** every cell is validated before any is written, so a Blocking
finding in a later cell cannot leave earlier cells freshly written and later ones stale.

## Manual verification still required from the user

1. **Deliberate duplicate-Id test:** duplicate an Activation Point's `ActivationPointId` in
   the config, run `Nexus.Compilation.CompileAndSave`, and confirm it logs BLOCKING and
   reports "NOTHING SAVED" - then confirm no asset on disk was modified.
2. **Zero false positives:** with valid data, confirm `CompileAndSave` reports 0 Blocking for
   every object type built through Phase 75.
