# Phase 40 — Static Generator — Classification Tagging

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 11:08 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement ENexusGenerationClassification and the per-object-type mapping table from 11-v6-static-dynamic-architecture.md - the foundation every later generation phase depends on.

## Allowed

- Implement the classification enum exactly per 11-v6-static-dynamic-architecture.md.
- Implement the starting object-type -> classification mapping table.
- Verify every object type planned through Phase 75 has an entry (even if the object type itself isn't implemented yet).
- Add a hard assertion/validation check: no generated object may leave Generation unclassified.

## Not Allowed

- Do not skip Classification tagging for any generated object.
- Do not let Generation write back to Landscape or Mapping data.
- Do not proceed to Compilation on data that failed this stage's validation gate.

## Implementation note

`ENexusGenerationClassification` itself already existed (added in Phase 21 for
`FNexusActivationPoint::Classification`) - this phase's real net-new work was the
object-type enum and the mapping table. New `ENexusStaticObjectType`
(`Public/Generation/NexusGenerationObjectType.h`) - exactly the 16 rows
`11-v6-static-dynamic-architecture.md`'s own "Object -> classification mapping
(starting set)" table names, not the larger ~30-40 figure referenced earlier in this
project's own history (that larger catalog isn't written down anywhere yet - growing
this enum toward it is later Generation phases' own job). New
`FNexusGenerationClassificationTable::ResolveClassification`
(`Public/Generation/NexusGenerationClassificationTable.h`,
`Private/Generation/NexusGenerationClassificationTable.cpp`) - a real switch covering
every value, `ensureAlwaysMsgf`-and-fallback-to-`EditorOnly` on anything unhandled.
Where the doc left a row ambiguous ("Static or Instanced", etc.), the concrete choice
made is commented in-code at that `case`, not silently picked - see
`Nexus.Generation.DumpClassificationTable`.

## Completion Criteria

- [ ] The unclassified-object assertion is proven to fire on a deliberately-broken test
      case. **To check**: run `Nexus.Generation.TestUnclassifiedAssertion` (Output Log
      console) - confirm an `ensure` failure is logged (an out-of-range `ObjectType`
      value, 255, is passed deliberately), and that the command's own follow-up log line
      reports the fallback classification as `EditorOnly`.
- [x] Mapping table covers every object type named in 11-v6-static-dynamic-architecture.md.
      Structural fact: `ResolveClassification`'s switch has one `case` per
      `ENexusStaticObjectType` value, and that enum has exactly one value per row of the
      architecture doc's own 16-row starting table (verified by direct row-by-row
      comparison while writing both) - no doc row was left without a corresponding enum
      value/switch case. `Nexus.Generation.DumpClassificationTable` makes this directly
      inspectable rather than only provable by reading the switch by eye.

## References

- `project-specifications/11-v6-static-dynamic-architecture.md`
