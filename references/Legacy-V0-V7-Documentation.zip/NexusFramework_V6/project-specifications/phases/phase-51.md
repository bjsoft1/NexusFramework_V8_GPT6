# Phase 51 — Traffic Light — Controlled Lane/Road References

## Status

Ready for Review
Ready for Review: 2026-08-12 02:08 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Add ControlledLaneIds/ControlledRoadIds to the Traffic Light struct, referencing Phase 37's lane relationship data.

## Allowed

- Implement ControlledLaneIds/ControlledRoadIds fields referencing Phase 37 lane data.
- Implement a validation check: every referenced lane/road ID must resolve.
- Build a UI affordance (Details panel) for assigning controlled lanes to a placed Traffic Light.
- Verify against a test junction with multiple controlled lanes.

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

- [ ] A multi-lane test junction's Traffic Light correctly references all intended lanes.
- [ ] A dangling lane reference is caught by validation.

## Implementation (2026-08-12)

- `FNexusTrafficLightActivation` (`Public/Representation/NexusTrafficLightActivation.h`)
  gains `ControlledLaneIds`/`ControlledRoadIds` (`TArray<FGuid>`), referencing Phase 37's
  `FNexusLane::LaneId` and `FNexusHighway::HighwayId` ("Road" = this project's Highway
  concept - there is no separate Road entity). Plain `FGuid` arrays, not
  `FNexusSubPointOffset`s - never enumerated as gizmo sub-points, matching the "these are
  references, not positions" distinction the Not-Allowed list implies.
- `FNexusTrafficLightActivation::ValidateControlledReferences` (new,
  `NexusTrafficLightActivation.cpp`) - self-contained to this type's own file rather than
  folded into `FNexusRepresentationGraph::ValidateRepresentationStage`, per that
  function's own "never branches on a specific Type" contract. Flags a `Blocking` entry
  per `ControlledLaneIds` entry that doesn't resolve via `GetLanesAtPoint` at the Traffic
  Light's own anchor, and per `ControlledRoadIds` entry that doesn't resolve via
  `FindHighway` anywhere in the graph.
- Two new console commands (`NexusTrafficLightActivationRegistration.cpp`), same
  session-only-test-store precedent as Phase 50's `AddTestTrafficLight`:
  - `Nexus.Representation.AssignTrafficLightControlledLanes <ActivationPointId>
    [InjectDanglingLaneId 0/1]` - assigns a test Traffic Light's ControlledLaneIds/
    ControlledRoadIds from its own anchor HighwayPoint's real, live lane/Highway data
    (proving Criterion 1 against a real multi-lane junction); the optional flag appends
    one deliberately-unresolvable Guid (Criterion 2).
  - `Nexus.Representation.ValidateTrafficLightControlledReferences <ActivationPointId>` -
    runs `ValidateControlledReferences` and logs every entry (or confirms zero), same log
    shape as `Nexus.Representation.ValidateStage`.
- Details panel UI affordance: `ControlledLaneIds`/`ControlledRoadIds` are the first
  payload fields on any Activation Point type that are neither gizmo-editable
  sub-offsets nor part of the shared base struct - before this phase, nothing bound a
  payload struct into the Details panel at all (Pole/VehicleLED/PedestrianLED are
  gizmo-only). Added a new `ENexusDetailsTargetMode::TestActivationPointPayload`
  (`NexusPanelSharedTypes.h`) + a matching bind branch in
  `SNexusDetailsPanel::RebindToCurrentTarget` that shows a session-only test-store
  point's payload struct via the same generic `IStructureDetailsView`/`FStructOnScope`
  mechanism the base struct already uses - resolved through
  `FNexusActivationTypeRegistry` (registry lookup, no Traffic-Light-specific UI code), so
  any future type's own non-sub-point payload fields get the same affordance for free.
  `UNexusActivationGizmoTool::SelectSubPoint` sets this target on selection;
  `OnClickedInViewport`'s explicit-deselect path clears it (guarded on Mode still being
  ours, and NOT cleared on a mode-driven `Shutdown()`, matching the existing
  `bHasRememberedSelection` "survives the mode switch" precedent). `NotifyPreChange`/
  `OnDetailsViewFinishedChangingProperties` both early-return for this mode - session-only
  test-store data is not a `UObject`, so there is nothing to `Modify()`/transact through
  `UNexusConfigAsset`'s own undo system for it.
- Real, persisted `UNexusConfigAsset::ActivationPoints` are untouched by this phase -
  specialized payload persistence for a REAL placed Traffic Light remains the same open,
  not-yet-decided architecture question flagged since Phase 46/49/50 (see those phases'
  own audit records). "A placed Traffic Light" in this phase's own Allowed-list wording is
  necessarily the session-only test-store kind, same as every other specialized-payload
  phase so far.

### Manual verification required (Agent Testing Policy - not run by this agent)

1. In the Unreal Editor, run `Nexus.Mapping.LoadOrCreateConfig`, then
   `Nexus.Representation.DumpJunctionClassification` to find a real multi-lane junction's
   `HighwayPointId`.
2. `Nexus.Representation.AddTestTrafficLight <HighwayPointId> 1` - adds a test Traffic
   Light at that junction (get its `ActivationPointId` from the log line).
3. `Nexus.Representation.AssignTrafficLightControlledLanes <ActivationPointId>` - confirm
   the log reports a nonzero `ControlledLaneIds`/`ControlledRoadIds` count matching that
   junction's real lane/Highway count.
4. `Nexus.Representation.ValidateTrafficLightControlledReferences <ActivationPointId>` -
   confirm it logs "clean - zero validation entries."
5. Select 'Select Mode' in the viewport, click one of the test Traffic Light's three
   sub-point markers (Pole/VehicleLED/PedestrianLED) - confirm the Details panel tab now
   shows the `FNexusTrafficLightActivation` payload struct, including the
   `ControlledLaneIds`/`ControlledRoadIds` arrays populated from step 3.
6. Re-run step 3 with `InjectDanglingLaneId=1`, then re-run step 4 - confirm exactly one
   `BLOCKING` entry is logged for the injected dangling `ControlledLaneIds` entry.
7. Click empty viewport space to deselect - confirm the Details panel clears. Switch to
   Landscape Mode and back to Select Mode - confirm the same Traffic Light sub-point
   re-selects and the Details panel shows its payload again (selection-survives-mode-
   switch precedent, unchanged by this phase).

## References

- `project-specifications/12-v6-activation-point-system.md`
