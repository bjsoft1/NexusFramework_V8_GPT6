# Phase 36 — HighwayPoint — Junction Classification

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 11:08 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Formalize junction classification (2-way passthrough vs. 3+-way junction vs. dead-end) as a queryable HighwayPoint property, building on Phase 20's raw detection.

## Allowed

- Implement the classification enum and computation from ConnectedHighwayIds count/arrangement.
- Verify classification updates live as Highways are added/removed at a point.
- Expose classification to the Mapping group debug renderer (Phase 32) as an additional label.
- Implement V6's own closed-form junction rotation resolution, following V5's precedent of never calling the engine's AutoCalcRotation (the two are known to disagree at junctions).
- Validate the rotation resolution against the known Q.IsNormalized() crash scenario documented in 01-v5-analysis.md (near-zero-length tangent at a junction) - this is the highest-severity carried-forward engine crash risk in the whole roadmap, per v6-phase-verification.md.

## Not Allowed

- Do not perform generation (static mesh, instancing) from this stage.
- Do not read Landscape directly from Representation code - only via Mapping's output.
- Do not let a cached field become authoritative - live reads only per 04/05.

## Revision — 2026-08-10 (same day)

User review of the console output flagged that V5 already has a proven, richer
classification system (`ENexusNodeType`: Straight/SmoothCorner/Corner/TJunction/
CrossJunction/MultiJunction/DeadEnd) and asked for it to be ported rather than left at
the original 3-value DeadEnd/Passthrough/Junction cut. Re-derived V5's classification
(`project-specifications/v5-complete-reference.md`'s `RecomputePointClassification`)
without violating this phase's "no direct Landscape read" rule: V5 counts raw
`ULandscapeSplineControlPoint::ConnectedSegments`; V6 reconstructs the same count from
each connected Highway's own `OrderedPointIds` membership (`GetPointNeighbors` already
answers "is this point a MIDDLE or END of that Highway's chain") plus live neighbor
positions - same sanctioned live-read path this phase always used, just applied to every
bucket instead of only the DeadEnd/Passthrough split. `ENexusJunctionType` now has 7
values; a new inheritable `CornerSharpDetectionAngleDegrees` field (Highway -> City ->
State, terminal default 100 degrees - V5's own literal default, deliberately NOT routed
through the project's usual 0-means-disabled resolver since 0 degrees would make Corner
unreachable) drives the Straight/Corner/SmoothCorner split for 2-connection points. See
`ai-change-audits/2026-08-10/feature-add/phase-36-37-highwaypoint-junction-and-lanes.md`'s
appended `## Revision` section for the full writeup. `ComputeJunctionForwardDirection`'s
own dispatch (0/1/2/3+) is unchanged - only the classification labels got richer, not
the rotation solver's bucket boundaries, so the two stay consistent by construction. The
completion criteria below are unaffected by this revision (still open, same manual-check
steps - the DeadEnd/Junction distinction they describe is a subset of what the richer
enum now reports).

## Note on the solver's crash-avoidance strategy

`FNexusRepresentationGraph::ComputeJunctionForwardDirection` (`NexusRepresentationGraph.
JunctionResolver.cpp`) never constructs an `FQuat` via an axis-angle pair — the specific
construction pattern `01-v5-analysis.md`'s crash trace implicates (an unguarded
`FQuat(Axis, Angle)` fed a zero-length Hermite-curve derivative). The solver works
entirely in plain `FVector`/`float` (bisector subtraction, `atan2`/`cos`/`sin` for the
largest-angular-gap case) and only ever calls `FVector::Rotation()` (atan2-based, no
quaternion axis-angle construction at all) if a caller needs an `FRotator`. Every
direction computation is guarded with `IsNearlyZero()`/`GetSafeNormal()` before use. This
is prevention (the risky code path is never reached, structurally), not a fix verified
by reproducing the crash — the third criterion below still needs the user's own
reproduction, which is a stronger form of evidence than the reasoning above.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — all three left unchecked for the
user's own manual pass.

- [ ] Classification is proven correct on 2-way, 3-way, and dead-end test points. **To
      check** (updated 2026-08-10 for the 7-value revision above): run
      `Nexus.Representation.DumpJunctionClassification` against a config with a known
      straight-through point, a known bent 2-way point (confirm it reads `Corner` or
      `SmoothCorner` depending on how sharp the bend is relative to the resolved
      `CornerSharpDetectionAngleDegrees`), a known 3-way branch, and a known chain
      boundary; confirm `Type=Straight`/`Corner`/`SmoothCorner`/`TJunction`/`DeadEnd`
      matches expectation for each. A real 4-way crossing or 5+-way point (if the test
      config has one) should read `CrossJunction`/`MultiJunction` respectively.
- [ ] Classification updates live with no manual recompute step. **To check**: re-run
      the same command after mapping a new Highway through an existing point (changing
      its `ConnectedHighwayIds` count) and confirm its logged `Type` changed without
      any explicit recompute call — true by construction (`ComputeJunctionType` is a
      live query with no cached field, same category as Phase 20's `ComputeCityCenter`
      precedent), but left for the user's own confirmation per this session's
      established policy for this class of claim.
- [ ] The Q.IsNormalized() crash scenario is reproduced against V6's own solver and
      confirmed NOT to crash. **To check**: create a junction with a near-zero-length
      tangent on one connection (matching Phase 09's own Source-stage validation check
      for this exact pattern), run `Nexus.Representation.DumpJunctionClassification`,
      and confirm the editor does not crash and a `Forward` value is still logged (even
      if not visually meaningful for a degenerate case) — see the note above for why
      this is expected to hold.

## References

- `project-specifications/01-v5-analysis.md` (junction rotation lesson)
- `project-specifications/v6-phase-verification.md`
