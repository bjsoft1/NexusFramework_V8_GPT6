# Phase 23 — Debug Architecture — Category Registry

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement FNexusDebugCategory and the registration model from 06-v6-debug-system.md - the mechanism every future category (up to 50+) plugs into without touching shared code.

## Allowed

- Implement FNexusDebugCategory struct (CategoryId/DisplayName/ParentCategoryId/DefaultConfig/RendererFn).
- Implement the registry itself (register-once, iterate-generically).
- Register the six top-level groups (Landscape/Roads/Infrastructure/Runtime/Mapping/Diagnostics) as parent categories with no renderers yet.
- Verify adding a dummy 51st test category requires zero edits to the registry code itself.

## Not Allowed

- Do not hard-code `if CategoryName == X` branches - registry-driven only.
- Do not use production meshes for debug rendering - wireframe primitives only.
- Do not let a renderer read live Landscape geometry per frame (cached Representation reads only).

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — both left unchecked for the user's
own manual pass.

- [ ] The dummy-category test proves zero-edit extensibility. **To check**: run
      `Nexus.Debug.DumpCategoryRegistry`, then `Nexus.Debug.RegisterTestCategory`, then
      `Nexus.Debug.DumpCategoryRegistry` again — confirm `Diagnostics.Test.Dummy51`
      appears, and confirm (by inspecting the diff for this batch) that
      `RegisterTestCategoryConsoleCommand` never touches
      `FNexusDebugCategoryRegistry.h`/`.cpp`'s own class code — it only ever calls the
      already-public `RegisterCategory()`.
- [ ] Six top-level groups render as empty tree parents with no leaves yet. **To
      check**: enter Landscape Mode, open the Nexus Panel tab, expand the Debug Tree
      section, confirm Landscape/Roads/Infrastructure/Runtime/Mapping/Diagnostics all
      appear with no children (Phase 24 wires the tree UI itself; this criterion is
      about the registry's own content being correct once that UI exists to show it).

## References

- `project-specifications/06-v6-debug-system.md`
