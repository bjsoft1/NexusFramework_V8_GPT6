# Phase 13 — Nexus Mapping — Config Asset Persistence

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement the NexusConfig Data Asset - what Mapping persists between sessions, replacing V5's manually-selected Layout asset entirely.

## Allowed

- Derive LandscapeId from the Landscape's own stable identity, not the map package name.
- Implement the config asset naming/path convention.
- Implement create-if-missing and load-if-present.
- Verify a Landscape moved to a differently-named map still resolves the same config asset.

**Note (2026-08-10 refactor)**: the naming/path convention was changed after this phase's
original implementation, per direct user request - see `project-specifications/
04-v6-architecture.md`'s "Config asset path" section and `ai-change-audits/2026-08-10/
feature-add/phase-13-config-path-refactor.md`. The asset now saves at
`<LevelFolder>/<LevelName>/NexusConfig` (alongside the level, matching the built-in
Landscape material layer system's own convention) instead of the original flat
`/Game/NexusConfigs/[LandscapeId]_nexusconfig`. `LandscapeId` is still stored inside the
asset for identity, it just no longer derives the save path - see the superseded
criterion below.

## Not Allowed

- Do not generate meshes or write Landscape geometry.
- Do not treat a mapped ID as permanent before this phase's validation passes.
- Do not duplicate a Landscape control point under two different HighwayPointIds.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — left unchecked for the user's own
manual pass:

- [ ] A test Landscape's config asset is found correctly after the containing map is
      renamed. **Partially verified 2026-08-10** (against the ORIGINAL LandscapeId-keyed
      path, since superseded): user's `Nexus.Mapping.LoadOrCreateConfig` run logged
      `LandscapeId=06AD7994490783B500BC81A27A951F63` and resolved
      `/Game/NexusConfigs/06AD7994...490783B500BC81A27A951F63_nexusconfig` already
      populated (`States=1 Cities=1 Highways=1 HighwayPoints=10`) — proving the asset
      genuinely persisted and re-loaded correctly across sessions (load-if-present half
      confirmed) under that design.
      **Superseded 2026-08-10**: this criterion is no longer expected to pass. The
      config asset path is now `<LevelFolder>/<LevelName>/NexusConfig`, derived from the
      level itself (a deliberate, user-requested trade-off - see this phase's own Note
      above and `ai-change-audits/2026-08-10/feature-add/
      phase-13-config-path-refactor.md`). Renaming/moving the containing map now DOES
      change which config asset a Landscape resolves to (the old asset is left behind at
      the old path, orphaned) - this is expected behavior under the new convention, not
      a regression to chase. `LandscapeId` is still stored inside the asset for
      identity/lookup, just no longer used to derive the save path.
- [x] No user-facing asset picker exists anywhere in this phase's flow. Self-verified
      by review: `FNexusConfigAssetIO::LoadOrCreateConfigAsset` resolves/creates the
      asset purely from `LandscapeId` (`LoadObject`/`CreatePackage`/`NewObject`, no
      `IContentBrowserSingleton`/asset-picker dialog anywhere in this phase's code);
      the only way this phase's logic runs right now is the `Nexus.Mapping.
      LoadOrCreateConfig` console command - automatic enable-time wiring (still no
      picker) is Phase 15's job.

## References

- `project-specifications/04-v6-architecture.md`
- `project-specifications/05-v6-data-flow.md`
- `project-specifications/AGENT-RULES.md`
- `project-specifications/phases/phase-26a.md` (2026-08-10 — dirty-tracking, auto-save-
  on-Landscape-save, and Undo/Redo for this asset; the auto-save half directly extends
  `FNexusConfigAssetIO::SaveConfigAsset`, this phase's own function)
