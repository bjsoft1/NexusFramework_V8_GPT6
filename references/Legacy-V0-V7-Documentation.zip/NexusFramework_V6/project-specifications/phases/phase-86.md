# Phase 86 — Runtime Activation Subsystem — Nearby Query

## Status

Ready for Review
Ready for Review: 2026-08-22 19:05 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement the runtime-side nearby-ActivationPoint query consuming Phase 47's baked spatial index, in the NexusFramework runtime module.

## Allowed

- Implement the runtime subsystem's query API against the compiled/loaded spatial index.
- Verify query correctness against the Phase 47 benchmark dataset.
- Verify the query works from a packaged (non-editor) build.
- Benchmark query cost in a runtime (not editor) context.

## Not Allowed

- Do not put editor-only/UObject-heavy types into runtime-consumed structs.
- Do not let the runtime module depend on NexusFrameworkEditor.
- Do not skip the Compilation-stage validation gate before an asset is allowed to save.

## Completion Criteria

- [ ] Packaged-build query test passes with correct results.
- [ ] Runtime query benchmark recorded.

## References

- `project-specifications/12-v6-activation-point-system.md`

## Implementation (agent, 2026-08-22)

`UNexusActivationSubsystem` (a `UTickableWorldSubsystem` in `Source/NexusFramework/`),
`RegisterRuntimeData` / `UnregisterRuntimeData` / `QueryNearby` / `QueryNearbyIndices`.

**The Phase 47 spatial index was MOVED, not reimplemented.**
`FNexusSpatialGridIndex` now lives at `Source/NexusFramework/Public/Spatial/` instead of
the editor module. It is pure math with zero reflection (no `UPROPERTY`/`USTRUCT`), so the
move carries none of the serialization risk that ruled out moving the enums in Phase 80, and
Phase 85's Allowed list explicitly sanctions relocating a misplaced type. Three includes
updated. The alternative — a runtime copy — would have let editor and runtime silently
disagree about what "nearby" means, and would have been exactly the duplicate-data smell
Phase 93 exists to find.

**Query results are sorted nearest-first.** Not cosmetic: Phase 88's `MaximumActiveActors`
ceiling only means "closest wins" if candidates arrive closest-first, so the ordering is
load-bearing for that phase rather than a convenience here.

**The index rebuilds lazily, on first query after a registration.** Streaming several World
Partition cells in at once would otherwise rebuild the whole index once per cell.

**Re-registering the same asset replaces its slice rather than appending.** A cell can
stream out and back in repeatedly; appending would double its points every cycle, which
would read as a memory leak and would break Phase 88's "flat instance count" test for
reasons having nothing to do with pooling.

### Build verification

`Build.bat NexusFramework Win64 Development` — the standalone GAME target, no editor
module compiled or linked — **Succeeded**. Every line of this subsystem lives in the
runtime module, so that is a real compile+link proof for this phase's code and re-proves
Phase 85's module boundary at the same time.

**No automated test was written or run, and the editor was not launched** (AGENT-RULES.md).
Every Completion Criterion below is a *runtime behaviour* test needing a running game, so
all are deliberately left **unchecked**.

## Manual verification still required from the user

1. Build a packaged (non-editor) build, load a compiled `NexusRuntimeDataAsset`, call
   `RegisterRuntimeData`, and confirm `QueryNearby` returns the expected points.
2. Record a query benchmark in the packaged build and compare against Phase 47's editor-side
   numbers for the same dataset.
