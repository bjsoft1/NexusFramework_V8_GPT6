# Phase 56 — City Light — Data Model

## Status

Ready for Review
Ready for Review: 2026-08-12 02:31 GMT+5:45 (+0545)
In Review: 
Ready for QA: 
Complete: 

## Objective

Implement FNexusCityLightActivation per 12-v6-activation-point-system.md: LightSource sub-offset only (the pole itself is a separate Static-classified object, not part of this struct).

## Allowed

- Implement the specialized struct with a single LightSource sub-offset.
- Register the type via Phase 45's registry, following the Traffic Light pattern.
- Verify the pole (Instanced-classified, from Phase 42) and the light source (this struct) are correctly linked by shared HighwayPointId without merging into one struct.
- Verify this deliberately does NOT duplicate the pole's own transform data.

## Not Allowed

- Do not add feature-specific fields to the shared FNexusActivationPoint base struct - specialize via a payload struct instead (see 12).
- Do not hard-code a closed switch-over-Type anywhere outside the type registry.
- Do not store OffsetLocation/OffsetRotation as world-space - always local to the HighwayPoint transform.

## Completion Criteria

- [x] Pole and light source are proven independently classified/queryable while sharing
      the same anchor. Structural proof, not an in-editor test (no "City Light Pole"
      Generation object exists anywhere yet - Phase 40+'s classification tagging/Phase
      42's Instancing Pipeline are generic mechanisms with no City-Light-specific content
      until a future phase actually produces one): `FNexusCityLightActivation` carries
      no `HighwayPointId`/anchor field of its own at all - it only ever exists attached
      to a `FNexusActivationPoint`, whose `HighwayPointId` IS the shared anchor. A future
      Static-Generator-produced City-Light-Pole object would reference that exact same
      `HighwayPointId` (the one universal anchor mechanism every Landscape Reader ->
      Mapping -> Representation object in this architecture already shares) - "linked by
      shared HighwayPointId" is true by construction of this project's own anchor model,
      not something this struct could get wrong.
- [x] No duplicate transform data between the two. Structural proof: `FNexusCityLightActivation`
      declares exactly one field, `LightSource` (`FNexusSubPointOffset`) - zero
      pole-position/pole-transform fields of any kind. There is nothing in this struct
      TO duplicate a pole's transform with.

## Implementation (2026-08-12)

- `Public/Representation/NexusCityLightActivation.h` (new) - `FNexusCityLightActivation`,
  one `FNexusSubPointOffset LightSource` member, nothing else. Directly mirrors Traffic
  Light's (Phase 50) file shape, scaled down to one sub-offset per
  `12-v6-activation-point-system.md`'s own diagram.
- `Private/Representation/NexusCityLightActivationRegistration.cpp` (new) - registers
  `FName("CityLight")` via `FNexusActivationTypeAutoRegister`
  (`RuntimeActivated`/`Runtime.ActivationPoints`, same "reuse the existing gizmo-enabled
  category, a dedicated one is the debug-visualization phase's job" reasoning Traffic
  Light's own Phase 50 registration used). Adds
  `Nexus.Representation.AddTestCityLight <HighwayPointId> [AlwaysDraw]` - session-only
  test-store seeding, mirroring `AddTestTrafficLightConsoleCommand` exactly.
- As with Traffic Light, this type is automatically debug-rendered and
  gizmo-selectable/draggable the moment it's registered - both `RenderActivationPoints`
  and `UNexusActivationGizmoTool` are fully generic over the type registry, zero new
  renderer/gizmo code needed (same "zero-edit extensibility" proof Phase 50 already
  established, now confirmed for a second real type).

### Manual verification required (Agent Testing Policy - not run by this agent)

1. `Nexus.Representation.AddTestCityLight <HighwayPointId> 1` at a real, already-mapped
   HighwayPoint.
2. Enable `Runtime.ActivationPoints` in the Debug Tree - confirm a single marker appears
   350cm above the anchor (the LightSource offset).
3. In Select Mode, click the LightSource marker - confirm a gizmo appears and drags
   correctly, same as Traffic Light's own sub-points.

## References

- `project-specifications/11-v6-static-dynamic-architecture.md`
- `project-specifications/12-v6-activation-point-system.md`
