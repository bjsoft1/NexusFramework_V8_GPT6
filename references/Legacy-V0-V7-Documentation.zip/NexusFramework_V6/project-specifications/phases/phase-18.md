# Phase 18 — Representation — HighwayPoint Struct

## Status

In Review
Ready for Review: 
In Review: 2026-08-10 09:28 GMT+5:45 (+0545)
Ready for QA: 
Complete: 

## Objective

Implement FNexusHighwayPoint per 05-v6-data-flow.md: HighwayPointId + live-resolved geometry accessors (never cached fields) + membership + ConnectedHighwayIds.

## Allowed

- Implement the struct with ID/membership fields only - no cached geometry fields.
- Implement live Location/Rotation/Tangent accessor functions that read through Mapping to the Landscape control point.
- Implement the unresolved-reference case as an explicit validation error, not a fallback value.
- Implement ConnectedHighwayIds as a derived, recomputed (never hand-edited) field.

## Not Allowed

- Do not perform generation (static mesh, instancing) from this stage.
- Do not read Landscape directly from Representation code - only via Mapping's output.
- Do not let a cached field become authoritative - live reads only per 04/05.

## Completion Criteria

Per `project-specifications/AGENT-RULES.md`'s Agent Testing Policy, not run/verified by
the agent this session (build-only verification) — left unchecked for the user's own
manual pass:

- [ ] Moving a control point natively is reflected immediately by the accessor with no
      stale read, proven by a live test. **To check**: with a mapped config active
      (`Nexus.Mapping.LoadOrCreateConfig` + `.MapControlPoints`), run `Nexus.
      Representation.DumpHighwayPointGeometry` (Output Log console), note one point's
      logged `Location`, drag that same control point natively in the Landscape Splines
      tool, then re-run the command - confirm the logged `Location` changed to match
      the new position with no stale/cached value (`GetLiveLocation` re-reads
      `SourcePoint->Location` on every call, no caching, but this is the real in-editor
      proof).
- [ ] An intentionally-broken SourcePoint reference produces a validation error, not a
      silent zero-vector. **To check**: delete a mapped control point natively (leaving
      its `HighwayPoint` entry's `SourcePoint` unresolved), run `Nexus.Representation.
      DumpHighwayPointGeometry` - confirm that point logs `Location=UNRESOLVED
      Rotation=UNRESOLVED TangentDirection=UNRESOLVED` (never `X=0.00 Y=0.00 Z=0.00`),
      then run `Nexus.Mapping.ValidateMappingStage` (Phase 14) and confirm it reports a
      `[BLOCKING]` entry naming that HighwayPoint's unresolved SourcePoint.

## References

- `project-specifications/05-v6-data-flow.md`
