# Phase 41 — Static Generator — Mesh Merge Pipeline

## Status

In Review
Ready for Review: 2026-08-10 15:10 GMT+5:45 (+0545)
In Review: 2026-08-10 15:13 GMT+5:45 (+0545)
Ready for QA: 
Complete: 
## Objective

Implement the Static/MergedStatic mesh-merge pipeline for road/sidewalk surfaces, consuming Representation only (never Landscape directly, per 04-v6-architecture.md).

## Allowed

- Implement mesh generation for Highway road surfaces from Representation data.
- Implement mesh generation for Sidewalks using Highway width/gap fields.
- Implement the actual merge step (UE's static mesh merge utility or equivalent).
- Verify the pipeline is idempotent - re-running produces the same output, no accumulation.

## Not Allowed

- Do not skip Classification tagging for any generated object.
- Do not let Generation write back to Landscape or Mapping data.
- Do not proceed to Compilation on data that failed this stage's validation gate.

## Completion Criteria

- [ ] Idempotency proven by running the pipeline twice on an unchanged test Highway.
      Tooling built and self-consistent (`Nexus.Generation.TestIdempotency` compares
      `FNexusGeneratedRibbonMesh::ComputeContentHash` across two runs) - actually running
      it against a real mapped Highway needs a manual editor session.
- [ ] Generated mesh visually matches the source Highway's curve within tolerance.
      `Nexus.Generation.TestCurveTolerance` programmatically proves the CENTERLINE data
      is exact (every source HighwayPoint is itself one of the sampled curve points, ~0
      deviation, see `FNexusStaticGenerator::VerifyCenterlineMatchesSourcePoints`'s own
      comment) - an actual in-viewport visual look at the generated ribbon mesh (not
      just its centerline data) is still a manual step.

## Implementation Notes (2026-08-10)

- New `FNexusStaticGenerator` (`Public/Generation/NexusStaticGenerator.h` /
  `Private/Generation/NexusStaticGenerator.cpp`): `GenerateHighwayRoadSurfaceMesh`/
  `GenerateHighwaySidewalkMesh` sample each Highway's centerline as a per-segment cubic
  Hermite curve (`FMath::CubicInterp`, tangent DIRECTION from
  `FNexusHighwayPoint::GetLiveTangentDirection`, tangent LENGTH auto-derived from
  inter-point distance - see the class's own header comment on why this doesn't reuse
  Debug's Phase 30a native-segment-length curve data), then builds a quad-strip ribbon
  mesh (`AppendRibbon`) offset laterally by the resolved width fields. Road surface is
  one ribbon (`-ResolvedHalfWidth` to `+ResolvedHalfWidth`); sidewalks are two ribbons
  (road edge to `ResolvedHalfWidth + ResolvedSidewalkWidth`, both sides).
- The "actual merge step": `BuildStaticMeshAsset` commits the generated geometry into a
  real `UStaticMesh` asset via `CreateMeshDescription`/`FStaticMeshAttributes`/
  `CommitMeshDescription(bUseHashAsGuid=true)`/`Build` - the same editor-time
  asset-authoring path `UInterchangeStaticMeshFactory` uses (engine-source-verified
  before writing this, `InterchangeStaticMeshFactory.cpp`). `bUseHashAsGuid=true` is the
  load-bearing idempotency mechanism: the built asset's Mesh GUID is content-derived, so
  committing identical geometry twice reuses the same GUID rather than minting a new
  random one - re-running finds the existing `UStaticMesh` object (`FindObject`) and
  overwrites it in place, never accumulating a duplicate asset.
- Triangle winding was hand-verified (not just assumed) to produce a +Z-facing normal
  for a strip advancing in +X, matching the explicit `UpVector` vertex normal this
  generator assigns - worked out via the cross-product test in
  `ai-change-audits/2026-08-10/feature-add/static-generator-mesh-merge-pipeline.md`.
  Flagged as something to actually look at in-viewport regardless (see Manual
  Verification) since hand-verified math on paper is not the same as a rendered check.
- Console commands: `Nexus.Generation.GenerateHighwayMeshes` (generates+commits every
  mapped Highway's road-surface/sidewalk assets under `/Game/NF/Generated/Highways/`),
  `Nexus.Generation.TestIdempotency`, `Nexus.Generation.TestCurveTolerance`.

## Manual Verification Needed

In the Unreal Editor, with a Landscape/ActiveConfig loaded and at least one Highway
mapped with `HalfWidth`/`SidewalkWidth` resolving to a real (> 0) value:
1. `Nexus.Generation.GenerateHighwayMeshes` (Output Log) - confirm it logs at least one
   generated asset path.
2. Open `/Game/NF/Generated/Highways/` in the Content Browser, double-click the
   generated `<Code>_RoadSurface` asset - confirm it opens as a real, valid StaticMesh
   (not empty/degenerate) and its shape visually follows the Highway's actual curve.
3. Drag the generated mesh into the level near the source Highway (or just eyeball the
   Static Mesh Editor preview) - confirm the top face is visible (not backface-culled -
   see this phase's own "triangle winding hand-verified, not rendered-verified" note
   above) and roughly matches the mapped road's width/curve.
4. `Nexus.Generation.TestIdempotency` and `Nexus.Generation.TestCurveTolerance` - both
   should log PASS.
5. Run `Nexus.Generation.GenerateHighwayMeshes` a second time - confirm the Content
   Browser still shows exactly one `_RoadSurface` asset per Highway, not a `_RoadSurface1`
   duplicate.

## References

- `project-specifications/11-v6-static-dynamic-architecture.md`
- `project-specifications/phases/phase-41a.md` — inserted 2026-08-10, "Junction Mesh
  Selection (Lane-Aware)": this pipeline's road-surface/sidewalk mesh generation does
  NOT itself decide which junction mesh piece to place at a HighwayPoint (topology +
  connecting-Highway lane counts) - that selection logic is that phase's own scope.
