# 04 — V6 Architecture

## Status

**Drafted — 2026-08-09.** Core architectural decisions for V6, made from V5's lessons
([01](01-v5-analysis.md)/[03](03-v5-problems-and-lessons.md)) plus the V6 master
architecture prompt. Subject to correction, not TBD.

## Core ownership model

V6 sharpens V5's split rather than replacing it:

- **Landscape owns geometry** — segment location, start/end, tangents, rotation,
  connections. V6 does not maintain a second authoritative geometry system. This is
  stricter than V5: V5's `FNexusRoadPoint` cached geometry as a *fallback* for
  materializing missing points; V6 treats the Landscape as the only place geometry is
  ever written by generation logic, full stop (see [05](05-v6-data-flow.md)).
- **Nexus owns mapping and configuration** — IDs, State/City/Highway/HighwayPoint
  relationships, generation config, debug config, export config, activation-point
  definitions.
- **Runtime Schema owns the final, game-consumed dataset** — a compiled, read-only
  output, not a live-editable structure (see [10](10-v6-runtime-schema.md)).

These three own disjoint concerns. No subsystem is allowed to write to a layer it
doesn't own (e.g. Debug rendering never writes geometry; Generation never invents IDs
outside the Mapping layer).

## The five-stage pipeline

```
Landscape (Source)
      ↓ read
Nexus Reader
      ↓ map
Nexus Mapping            — Landscape entity → Nexus ID + relationships
      ↓
Nexus Internal Representation   — HighwayPoint graph, State/City/Highway
      ↓
   ┌───────────────┬──────────────────┐
   ↓               ↓                  ↓
Debug System   Static Generator   Runtime Compiler
   ↓               ↓                  ↓
Editor UI      Merge/Instance     Runtime Dataset (Activation Points)
```

Five distinct stages, five distinct subsystems — never collapsed into one "Builder"
class (this is the explicit anti-pattern called out in the master prompt, section 35):

1. **Source** — read Landscape/editor data. No interpretation.
2. **Mapping** — Landscape entity ↔ Nexus ID. No generation, no meshing.
3. **Representation** — the clean in-memory Nexus graph (State→City→Highway→
   HighwayPoint→ActivationPoint). No IO.
4. **Generation** — static world (merge/instance) and dynamic Activation Point data,
   consuming Representation only, never touching Landscape directly.
5. **Compilation** — Representation + Generation output → validated Runtime Schema
   asset. The one artifact the shipped game reads.

Each stage validates its own output before the next stage may consume it (see
[14-v6-validation.md](14-v6-validation.md)) — a stage never silently passes through
invalid data.

## Module boundaries

V6 is an **Editor-Only plugin**. Two top-level modules, matching V5's precedent but
drawn at a stricter line:

- **NexusFrameworkEditor** (editor-only) — Landscape reader, Mapping layer,
  Representation, Debug system + gizmos, UI, Static Generator, Runtime Compiler. Every
  UObject/Slate/Landscape-Spline reference lives here.
- **NexusFramework** (runtime-safe) — Runtime Schema structs only (see
  [10](10-v6-runtime-schema.md)) and the runtime Activation subsystem that reads the
  compiled dataset and spawns/deactivates actors. No editor-only types, no
  `WITH_EDITOR` branching inside runtime-consumed structs.

No third "Shared" module this time — V5's `Shared` folder mostly held enum/flag types
used by both sides; V6 keeps those inside `NexusFramework` (runtime module) and has the
editor module depend on it, since a runtime-safe type set is automatically editor-safe
too, but not vice versa.

## Editor surface: a Nomad tab synced to Landscape Mode, not a competing custom Editor Mode

**Corrected 2026-08-09** (see
[ai-change-audits/2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md](../ai-change-audits/2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md)
for the full history) — V6's first draft of this section specified a custom Editor Mode
(`UEdMode` + `FModeToolkit`), the same architectural family Landscape Mode and Modeling
Mode are built on. **This was wrong and has been reverted.**
`NexusFramework_V5` tried exactly this and hit a real, reproducible engine crash
(`Assertion failed: !Toolkits.Contains(NewToolkit)` in `ToolkitManager.cpp`, UE 5.8):
activating a second `UEdMode` alongside built-in Landscape Mode conflicts with Landscape
Mode's own toolkit registration, and there is no supported extension point into
Landscape Mode's own panel. V6's Phase 02/03 rebuilt this exact crashing pattern before
the mistake was caught (neither phase's own build verification exercised it — the crash
only triggers on actually *activating* the competing mode, not at editor startup) and
were reworked once it was.

**A custom `UEdMode` must never be reintroduced for this plugin's editor surface.**

V6's actual, working interaction surface — ported directly from V5's own proven fix:

- **`FNexusLandscapeModeExtension`** (plain C++ class, not a `UEdMode`) — the plugin's
  entry point, owned by `FNexusFrameworkEditorModule`. Listens for
  `FEditorModeTools::OnEditorModeIDChanged()` on the level editor's own mode manager,
  filtered strictly to built-in `FBuiltinEditorModes::EM_Landscape`: entering Landscape
  Mode opens the Nexus tab, leaving it closes the tab. This is *also* the natural place
  the "plugin enabled for a Landscape" flow from [05-v6-data-flow.md](05-v6-data-flow.md)
  hooks in — entering Landscape Mode is what triggers LandscapeId resolution and config
  load, the same role "entering the mode" played in the old (reverted) design.
- **A Nomad `SDockTab`**, registered via `FGlobalTabmanager::RegisterNomadTabSpawner`,
  hosts `SNexusFrameworkPanel` — an ordinary `SCompoundWidget` with the Slate UI from
  [07-v6-ui-design.md](07-v6-ui-design.md) (Nexus Panel/Details/Diagnostics), appearing
  alongside Landscape Mode's own UI (opened/closed in lockstep with it) rather than
  living inside a Mode's own toolkit panel or floating disconnected from any workflow.
  Unlike V5 (three separately-dockable tabs), V6 uses a single tab hosting all three
  sections, per this doc's own "fewer tabs than V5 accumulated" design goal.
- **Viewport interaction does NOT go through a custom Mode** (there isn't one). Debug
  wireframe drawing (see [06-v6-debug-system.md](06-v6-debug-system.md)) uses V5's own
  proven mechanism — global `DrawDebugLine`/`DrawDebugBox` calls plus a Slate overlay
  canvas (`SEditorViewport::AddOverlayWidget`) for labels, both driven every frame from
  an `FTickableEditorObject` on the persistent subsystem, not an `UEdMode::Render()`/
  `DrawHUD()` override. Click interaction (where V5 needed it) used a raw
  `IInputProcessor` registered via `FSlateApplication::RegisterInputPreProcessor`, not
  the Interactive Tools Framework via a Mode's `UInteractiveToolManager`. **Gizmo-drag
  editing of an Activation Point's offset (see
  [13-v6-gizmo-system.md](13-v6-gizmo-system.md)) has no proven V5 precedent** — V5's
  own gizmo needs were satisfied by deferring to Landscape Mode's native spline gizmo,
  which has no equivalent for a Nexus-only offset value. This is an open question,
  explicitly deferred to whichever phase (Phase 48) actually implements it — do not
  assume a `UInteractiveToolManager` is available without a custom Mode; it needs its
  own research pass when that phase is picked up.
- **The `UEditorSubsystem` still exists, unaffected by this correction** — its role was
  already persistent, hosting-mechanism-independent state (the loaded config asset, the
  Representation graph) that must survive the tab closing and reopening — the tab/panel
  own UI, the subsystem owns data lifetime, same split as before, just without a Mode in
  between.

**Revision, 2026-08-11 (editor-usability pass, direct user request)** — two corrections
to the "opened/closed in lockstep with Landscape Mode" framing above, both driven by real
interaction conflicts found during Phase 49 manual testing:

1. **Tabs no longer close on leaving Landscape Mode**, and are independently openable
   from the Window menu without ever entering Landscape Mode at all — Nexus's Hierarchy/
   Details/Diagnostics/Profiler tabs must remain usable in standard Select Mode, per the
   `Landscape = source geometry` vs. `Nexus = independent editor authoring/debug system`
   separation this pass introduced. Landscape Mode entry still auto-*opens* them as a
   discoverability convenience (unchanged). See `FNexusLandscapeModeExtension`'s own
   updated header comment.
2. **The PDI debug-draw EdMode (added 2026-08-11, see `ai-change-audits/2026-08-11/
   bug-fixed/pdi-debug-rendering-backend-implemented.md` — a later addition than this
   doc's own "no custom Mode" framing above, but NOT a reintroduction of the crashing
   toolkit-based pattern; it is toolkit-less and always active regardless of Landscape
   Mode) already made wireframe rendering Landscape-Mode-independent. What THIS revision
   adds is the separate, still-open question this doc flagged above ("Gizmo-drag editing
   ... has no proven V5 precedent ... explicitly deferred") — now resolved (Phase 48) and
   further refined: gizmo INTERACTIVITY (not rendering) is gated on standard Select Mode
   (`FEditorModeTools::IsDefaultModeActive()`) specifically, not Landscape Mode, and not
   "always on" either — see `13-v6-gizmo-system.md`'s own "Mode gating" section for the
   full rule and reasoning (Nexus gizmo dragging must never compete with Landscape
   Mode's own sculpt/spline handles for mouse input).

Also revised the same day: the "entering Landscape Mode is what triggers LandscapeId
resolution and config load" sentence above is still accurate for LOAD, but no longer
implies a full Mapping reconciliation happens automatically at the same time - see
`ai-change-audits/2026-08-11/feature-add/editor-usability-select-mode-gizmo-sync-policy.md`
for the full sync-policy change (implicit full re-sync removed from every load/mode-
change/panel-open path; a full reconciliation is now always an explicit user action via
the Hierarchy tab's "Re-sync from Landscape" button, plus a new narrow, event-driven
dirty-marking path for live Landscape Spline edits).

Core/Data/Schema (Mapping, Representation, Runtime Schema) stay strictly separate from
this editor-surface layer — the tab/extension are a consumer of those systems via the
subsystem, not
where their logic lives. This keeps the "professional custom Landscape-like Nexus editor
tool" goal without collapsing Core/Data/Schema into UI code.

**Revision, 2026-08-11 (Editor Proxy Actor pass, direct user request)** — a further
correction to point 2's own "gizmo INTERACTIVITY" framing above: the custom ITF gizmo no
longer handles generic, main-object editing of real, persisted objects at all. See
[16-v6-editor-proxy-actor-system.md](16-v6-editor-proxy-actor-system.md) — a small,
reusable pool of native, transient `ANexusEditorProxyActor` instances (standard UE Actor
selection + transform widget, spatially queried near the camera via Phase 47's
`FNexusSpatialGridIndex`) now owns that job instead, still gated on the exact same
Select-Mode check as before (`FNexusLandscapeModeExtension::RefreshNexusInteractionState`,
renamed from `RefreshGizmoActiveState`, same call site). The custom gizmo is retained for
specialized SUB-POINT editing only (Traffic Light's VehicleLED/PedestrianLED, etc.,
Phase 50+) — `13-v6-gizmo-system.md`'s own "Mode gating" section and its newly appended
scope-narrowing note describe the current split. PDI rendering itself remains completely
unaffected by either the gizmo or the proxy pool, exactly as this doc's own "Editor
surface" framing already establishes.

## Landscape → Nexus mapping architecture

```
Landscape Segment / ControlPoint
        ↓ (Nexus Reader)
HighwayPointId (stable Nexus ID, keyed via the same renamed-control-point
                identity trick V5 proved works — see 01-v5-analysis.md)
        ↓ (Nexus Mapping)
HighwayId, CityId, StateId membership
        ↓ (Nexus Representation)
FNexusHighwayPoint { location/rotation/tangents READ from Landscape each
                     query, never cached as authoritative — see 05 }
```

V5's control-point-rename trick (`"NexusPoint_<guid>"` for a stable `FSoftObjectPath`,
since subclassing `ULandscapeSplineControlPoint` across a module boundary is
engine-blocked) is reused as-is — proven, not a V5 mistake. What changes is that V6
never snapshots Location/Rotation/Tangent onto the Nexus-side struct as a fallback;
every read goes through the live control point. If it doesn't resolve, that HighwayPoint
is invalid and flagged by Mapping-stage validation — not silently rebuilt from a stale
cache (this is the direct fix for the cross-map stale-`SourcePoint` class of bug in
[03](03-v5-problems-and-lessons.md)).

## No Load Layout — automatic config lifecycle

See [05-v6-data-flow.md](05-v6-data-flow.md) for the full flow. Summary:

```
Plugin enabled for a map
        ↓
Determine LandscapeId (stable per-Landscape identity, not the map package name —
                        a Landscape can be renamed/moved between maps in UE without
                        losing its own GUID identity; stored on the config asset for
                        identity/lookup — see "Config asset path" below for what
                        actually derives the save location)
        ↓
<LevelFolder>/<LevelName>/NexusConfig  (Data Asset name/path convention)
        ↓
Exists? Load it.  Missing? Create it with defaults.
        ↓
Internal load — no user action, no asset picker, no Load/Import/Merge dialog.
```

This removes an entire category of V5 complexity (Load Fresh / Import-and-Merge /
cross-map ownership dialogs — all now-obsolete under this model since a config asset is
never manually pointed at the wrong Landscape).

### Config asset path (refactored 2026-08-10)

The config asset saves at `<LevelFolder>/<LevelName>/NexusConfig` — alongside the level
itself, in a subfolder named for it, e.g. a map at `/Game/Maps/TestMap.umap` gets
`/Game/Maps/TestMap/NexusConfig`. This mirrors the same save-next-to-the-level pattern
the built-in Landscape material layer system already uses, and replaces the original
Phase 13 design (a flat `/Game/NexusConfigs/[LandscapeId]_nexusconfig` folder, one entry
per Landscape GUID). `LandscapeId` is still stored *inside* the asset
(`UNexusConfigAsset::LandscapeId`) for identity/lookup, it just no longer derives the
save path. **Trade-off accepted deliberately**: unlike the GUID-keyed path, this one is
no longer immune to level renames/moves — renaming or moving a map's `.umap` orphans its
old config asset at the old path (the same way any other level-relative asset behaves in
UE). See `ai-change-audits/2026-08-10/feature-add/phase-13-config-path-refactor.md`.

## Multi-Landscape scope (Phase 17 decision, 2026-08-10; path convention updated 2026-08-10)

V6's first version maps exactly one `ALandscape` per open map. `FNexusLandscapeReader::
ResolveActiveLandscape()` returns the first `ALandscape` actor found
(`TActorIterator`); if a map contains more than one, the rest are fully ignored - a
Warning is logged naming which one was picked and how many were skipped, so this reads
as a known limitation rather than a silent bug (see
[phases/phase-17.md](phases/phase-17.md)).

This was originally a pure scope narrowing, not an architectural constraint — under the
old `[LandscapeId]_nexusconfig` path, two Landscapes in the same map would already
produce two fully independent config assets by construction, so lifting the restriction
would only have needed a picker UI. **That is no longer true after the same-day config
asset path refactor above**: the path is now `<LevelFolder>/<LevelName>/NexusConfig`,
which is per-*level*, not per-Landscape-actor — two Landscape actors in the same map
would now resolve to the same config asset path and collide. Lifting this restriction in
the future needs both a picker UI *and* a path-disambiguation change (e.g. naming the
asset after the Landscape actor's label when more than one exists), not just the UI half
described here previously.

## Subsystems requiring a standing "don't touch without approval" guardrail

Carried forward from V5, still true in V6 since the underlying engine hasn't changed:

- Any rotation/tangent recompute math at junctions — V5's `Q.IsNormalized()` crash risk
  is an **engine**-level bug in UE 5.8 Landscape Spline tessellation, not a V5 code
  defect; it reproduces in V6 too if V6 also drives native Landscape Splines. Treat any
  change here as requiring explicit sign-off, and keep the guard pattern (`FMath::Abs()`
  before tangent comparisons, never call the engine's own `AutoCalcRotation`).
- Anything touching `ULandscapeSplineSelection` beyond `IsSplineSelected()` (read-only).

## References

- [01-v5-analysis.md](01-v5-analysis.md)
- [03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md)
- [05-v6-data-flow.md](05-v6-data-flow.md)
- [10-v6-runtime-schema.md](10-v6-runtime-schema.md)
- [11-v6-static-dynamic-architecture.md](11-v6-static-dynamic-architecture.md)
- [12-v6-activation-point-system.md](12-v6-activation-point-system.md)
