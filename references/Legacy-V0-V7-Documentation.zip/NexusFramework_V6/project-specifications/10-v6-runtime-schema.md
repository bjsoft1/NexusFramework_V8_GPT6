# 10 — V6 Runtime Schema

## Status

**IMPLEMENTED — 2026-08-22 (Phases 80-85).** The shape proposed below is no longer a
proposal: `FNexusRuntimeResult`, `FNexusRuntimeHighwayPoint`, `FNexusRuntimeActivationPoint`,
`FNexusRuntimeStationPoint` and `UNexusRuntimeDataAsset` all exist under
`Source/NexusFramework/Public/Schema/Runtime/`, and `FNexusRuntimeCompiler` produces them.
Gap status against the confirmed-gaps list below: **#1 tangent/start-end — CLOSED**;
**#2 pole-vs-light offset split — CLOSED** (N named sub-points per point, not one pair);
**#3 crosswalk representation — CLOSED** (a registered type with its own payload);
**#4 fixed type enum — CLOSED** (`Type` is an `FName` from the registry);
**#5 passenger/seat points — CLOSED** (first-class arrays on `FNexusRuntimeStationPoint`);
**#6 classification tag — CLOSED** (`ENexusRuntimeClassification` is exported);
**#7 validation metadata — RESOLVED BY DESIGN** (compilation-time validation gates whether
compilation succeeds and deliberately does NOT ship inside the asset).
See `ai-change-audits/2026-08-22/feature-add/phases-80-85-runtime-compiler-built.md`.

Originally **Drafted — 2026-08-09.** Audited directly against V5's actual headers under
`NexusFramework_V5/Source/NexusFramework/Public/Schema/Runtime/` (all 9 files read in
full, not assumed) — this is the master architecture prompt's explicitly required
Runtime Schema audit.

## What V5's Runtime Schema actually has (verified, not assumed)

V5's runtime output is more developed than a first glance at the editor tooling
suggests. It is **not** a dead end — V6 extends this shape rather than discarding it.

| File | Struct | What it holds |
|---|---|---|
| `NexusFinalPoint.h` | `FNexusFinalPointData` | `Id`(FName)/`Code`, `Location`, `Rotation`, `PointFeatures`/`PointTargets` bitmasks, `Description` enum |
| `NexusFinalHighway.h` | `FNexusFinalHighwayData` | `Id`/`Code`/`Name`, ordered `PointIds`, `OtherStateCityId` (cross-state bridge), `SpeedLimit`, `Features` bitmask, lane/sidewalk width fields (`-1`-inherit convention) |
| `NexusFinalCity.h` | `FNexusFinalCityData` | `Id`/`Code`/`Name`, `TArray<FNexusFinalHighwayData> Highways` |
| `NexusFinalState.h` | `FNexusFinalStateData` | `Id`/`Code`/`Name`, `DataLayerAssetName` (World Partition streaming unit), `TArray<FNexusFinalCityData> Cities` |
| `NexusDynamicInteractable.h` | `FNexusDynamicInteractable` | `HighwaySplinePointId`, `OffsetLocation`, `OffsetRotation`, `InteractableType` (TrafficLight/HighwayLight/NewsTv/AdsBoard), `ActivationDistance` (-1=default), `ActiveTimes` bitmask |
| `NexusStationInfo.h` | `FNexusStationInfoBase` + `FNexusParkingInfo`/`FNexusBusStopInfo` | Point anchor, `HighwayId`, offset, segment grid (`SegmentRow`×`SegmentColumn`), `AllowVehicles`/`AllowLanes` bitmasks, `OccupiedIndex` (runtime-only) |
| `NexusFrameworkResult.h` | `FNexusFrameworkResult` | Flat aggregate: `HighwayPoints` + `ParkingPoints` + `BusStopPoints` + `InteractablePoints` — "everything AI/traffic/gameplay needs in one place," explicitly documented as extensible, not final |

`FNexusDynamicInteractable` is functionally a first draft of the Activation Point
pattern the V6 master prompt asks for: HighwayPoint anchor + offset + type. It's real
prior art, not a blank slate — see [12-v6-activation-point-system.md](12-v6-activation-point-system.md)
for how V6 generalizes it.

## Confirmed gaps (V6 must add — not assumed, checked against the actual structs above)

1. **No tangent data anywhere.** `FNexusFinalPointData` has `Location`/`Rotation` only —
   no incoming/outgoing tangent, no start/end distinction. Any runtime system that needs
   to know a road's curve direction at a point (lane-following AI, procedural traffic)
   cannot get it from the current export.
2. **No pole-vs-light offset split.** `FNexusDynamicInteractable` has exactly one
   `OffsetLocation`/`OffsetRotation` pair per interactable — insufficient for a traffic
   light (needs pole + vehicle-LED + pedestrian-LED, three distinct positions) or a city
   light (needs pole + actual light-source position, two positions). See
   [12](12-v6-activation-point-system.md) for the fix.
3. **No crosswalk representation at all.** No struct anywhere in Runtime covers
   crosswalk start/end, width, pedestrian waiting points, or its relationship to a
   controlling traffic light.
4. **No seat/passenger-point type.** `ENexusDynamicInteractableType` is a fixed 4-value
   enum (TrafficLight/HighwayLight/NewsTv/AdsBoard) with no Seat, Parking-interaction, or
   generic extensibility beyond editing that enum by hand.
5. **`FNexusStationInfoBase`'s segment-grid model is vehicle-occupancy-shaped, not
   passenger-shaped.** Good for "which parking/bus bay is free," has no concept of
   "passenger waiting point" or "seat interaction point" as first-class entities distinct
   from the vehicle bay itself.
6. **No Static/Dynamic/classification tag anywhere.** Nothing in any struct says whether
   the object it describes is merged-static, instanced, or runtime-spawned — see
   [11-v6-static-dynamic-architecture.md](11-v6-static-dynamic-architecture.md).
7. **No validation metadata.** No structs carry a "this reference failed to resolve" or
   "this data was flagged during compilation" marker — compilation-time validation
   results aren't part of the shipped schema today (see
   [14-v6-validation.md](14-v6-validation.md) for where V6 puts this instead — validation
   results themselves should NOT ship in the runtime asset; they gate whether
   compilation succeeds at all).

## V6 Runtime Schema shape (proposal)

Keeps V5's two-views-of-the-same-data pattern (hierarchical for streaming, flat for
gameplay lookup) — that split was a deliberate, sound V5 design choice, not a defect.

```
FNexusRuntimeState → FNexusRuntimeCity → FNexusRuntimeHighway → FNexusRuntimeHighwayPoint
                                                                        (adds tangent
                                                                         in/out, start/end
                                                                         flag)

FNexusRuntimeResult (flat aggregate, extends FNexusFrameworkResult's role)
{
    HighwayPoints[]
    ActivationPoints[]      — generalizes InteractablePoints; see 12
    StationPoints[]         — generalizes Parking/BusStop; adds PassengerWaitingPoints[],
                               SeatInteractionPoints[] per station
    CrosswalkPoints[]       — new
    ClassificationTags[]    — Static/Instanced/MergedStatic/RuntimeActivated/
                               RuntimePersistent/EditorOnly/DebugOnly per generated object,
                               see 11
}
```

`DataLayerAssetName`-style World Partition streaming stays — it's the one piece of V5's
schema explicitly built for the GTA-V-scale requirement V6 shares, and there's no reason
to redesign it.

## References

- [04-v6-architecture.md](04-v6-architecture.md)
- [11-v6-static-dynamic-architecture.md](11-v6-static-dynamic-architecture.md)
- [12-v6-activation-point-system.md](12-v6-activation-point-system.md)
- [14-v6-validation.md](14-v6-validation.md)
