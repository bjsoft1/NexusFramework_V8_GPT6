# 13 — V6 Gizmo System

## Status

**Drafted — 2026-08-09.**

## The one rule

```
Gizmo drag/rotate
        ↓
Modifies the selected object's OffsetLocation/OffsetRotation
        ↓
Never touches the Landscape control point's own transform
```

The gizmo is always editing an `FNexusActivationPoint`'s offset (or a HighwayPoint's
own debug-only display properties), never Landscape geometry — Landscape edits stay
exclusively a native-Landscape-Spline-tool action, per the ownership model in
[04-v6-architecture.md](04-v6-architecture.md). This is the direct implementation of the
master prompt's explicit warning against a gizmo "accidentally modifying Landscape
geometry."

## Selection model

- A debug-drawn object is selectable only if its category's `CanSupportGizmo` config flag
  (`FNexusDebugRenderConfig`, implemented name for what this doc originally called
  `bSupportsGizmo` before the coding-standard rename pass) is on (see
  [06-v6-debug-system.md](06-v6-debug-system.md)) — most Debug categories
  (Landscape/Roads/Mapping/Diagnostics groups) are inspect-only, no gizmo. Gizmo support
  is opt-in per category, concentrated in the `Infrastructure` and `Runtime` groups
  where an Activation Point's offset is actually meant to be hand-tuned (traffic-light
  LED position, city-light source position, seat position, etc). **Resolved 2026-08-10
  (Phase 48's own implementation)**: `FNexusDebugRenderConfig` also has a separate
  `IsSelectable` flag (added Phase 25, originally undecided how it related to gizmo
  support - see this doc's own prior ambiguity). Phase 48's tool requires BOTH
  `IsSelectable && CanSupportGizmo` before a category's instances are click-selectable at
  all - the conservative default (a category can still be gizmo-capable in the registry
  without yet being exposed to clicking, e.g. mid-rollout for a new object type), not
  `CanSupportGizmo` alone.
- Selecting a gizmo-enabled debug object shows: its live transform (HighwayPointTransform
  × OffsetTransform composed), its `HighwayPointId`, its owning City/Highway/State
  chain, and its `ActivationPointId` — all read-only inspection fields alongside the
  editable offset.
- V6 does **not** attempt V5's native Landscape-Spline-selection-highlight approach —
  V5 confirmed (see [01-v5-analysis.md](01-v5-analysis.md)) that
  `ULandscapeSplineSelection::SetSplineSelected` is private-to-LandscapeEditor and proven
  to crash; V6's gizmo targets are never Landscape Spline objects in the first place
  (they're Nexus-owned Activation Points), so this risk doesn't apply to gizmo
  selection — only to any code that might try to select/highlight the underlying
  Landscape control point itself, which the gizmo system should never do.

## Editing flow — mechanism RESOLVED 2026-08-10 (was an open question as of the 2026-08-09 architecture correction)

**Resolved**: the Interactive Tools Framework IS reachable without a custom `UEdMode` -
`ILevelEditor::GetEditorModeManager().GetInteractiveToolsContext()` returns the level
editor's own shared `UModeManagerInteractiveToolsContext` (the same one every built-in
Mode uses), whose `StartTool`/`CanStartTool` are public and callable by any code holding
the pointer - not gated behind Mode ownership. V6's `NexusLandscapeModeExtension.cpp`
already holds the exact `FEditorModeTools&` reference needed (used today for
`OnEditorModeIDChanged()`), so no new access pattern is required. See
`ai-change-audits/2026-08-10/research/phase-48-itf-reachable-without-custom-mode.md` for
the full finding. The hand-rolled `FEditorViewportClient`/`IInputProcessor` fallback
below is **not needed** - kept in this doc only as historical context for why the
question existed, not as the chosen mechanism.

**This section originally assumed gizmo editing would be an `UInteractiveTool`
registered with `UNexusEdMode`'s own `UInteractiveToolManager`.** That assumption no
longer holds — see [04-v6-architecture.md](04-v6-architecture.md)'s "Editor surface"
section: V6 has no custom `UEdMode` (a confirmed engine crash alongside built-in
Landscape Mode, per `NexusFramework_V5`'s own fix,
[ai-change-audits/2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md](../ai-change-audits/2026-08-09/research/v5-custom-edmode-crash-vs-landscape-mode.md)),
so there is no Mode to own a `UInteractiveToolManager`.

**`NexusFramework_V5` has no proven pattern for this specific need either** — confirmed
via source search, V5 uses the Interactive Tools Framework nowhere at all. V5's own
gizmo-like interaction is satisfied entirely by deferring to Landscape Mode's own
native Spline gizmo (V5's points *are* Landscape Spline control points, so Landscape's
gizmo already handles dragging them — V5's one custom input hook, a raw
`IInputProcessor`, explicitly detects and steps aside when the click is on Landscape's
own gizmo widget rather than intercepting it). That doesn't transfer to V6's actual
need: an `FNexusActivationPoint`'s offset is a Nexus-only value with no Landscape
object behind it, so there's no native Landscape gizmo to defer to.

**Open question, deferred to Phase 48** (do not implement this phase's scope early —
see `09-development-rules.md`'s "do not jump phases"): whether the Interactive Tools
Framework is reachable without a custom Mode (e.g. via the level editor's own
independent/default tool context, if one exists) still needs its own research pass
when Phase 48 is actually picked up. A hand-rolled `FEditorViewportClient`/raw
`IInputProcessor`-based override (V5's own proven fallback shape, even though V5 never
needed it for gizmo-dragging specifically) is the fallback if ITF genuinely isn't
reachable outside a Mode. Below is the *intended* editing flow/rule regardless of which
mechanism ends up implementing it — only the "how it's wired into the viewport" part is
now open:

```
User selects a gizmo-enabled debug object (traffic-light LED, city-light source,
seat, ...) — routed through whatever mechanism Phase 48 settles on (see above)
        ↓
That mechanism supplies a standard UE transform gizmo (translate/rotate), ideally via
UCombinedTransformGizmo if ITF turns out reachable, positioned at the object's current
composed world transform
        ↓
User drags
        ↓
On each delta: new OffsetTransform = Inverse(HighwayPointTransform) * NewWorldTransform
        ↓
Write to FNexusActivationPoint::OffsetLocation/OffsetRotation (via FScopedTransaction +
Modify(), same undo/redo pattern V5 used throughout)
        ↓
Debug renderer (the Tick-driven DrawDebugLine/overlay mechanism, see 06) redraws
immediately at the new composed transform (no separate "apply" step — live feedback,
matching the master prompt's "see the result immediately" requirement)
```

Standard Unreal Interactive Tools Framework gizmo machinery (`UCombinedTransformGizmo`
on a selected proxy), not a custom-drawn gizmo — reduces implementation risk and matches
how Modeling Mode's own tools already solve this exact problem.

## Scope boundary for the first working version

Gizmo editing ships for offset-only editing (translate + rotate an Activation Point's
local offset). Scaling an Activation Point's offset is not meaningful (offsets aren't
scaled objects) and is out of scope. Multi-select gizmo editing (dragging several
Activation Points' offsets at once) is deferred past the first working version — single
selection only initially.

## Sub-point addressing (2026-08-10, `v6-master-architecture.md` Section 5 alignment)

The base gizmo mechanism (Phase 48) must NOT be designed around a single
`OffsetLocation`/`OffsetRotation` pair per Activation Point — several real object types
have more than one independently-editable offset, and some have a *dynamic array* of
them:

```
Traffic Light         Pole, VehicleLED, PedestrianLED        (3 fixed named sub-points)
City Light             LightSource                            (1 fixed named sub-point)
Crosswalk               StartPoint, EndPoint, WaitingPoints[]  (2 fixed + 1 array)
Bus Stop                  StoppingPoint, EntryPoint, ExitPoint,
                           PassengerWaitingPoints[],
                           SeatInteractionPoints[]              (3 fixed + 2 arrays)
```

The fix is a single generic addressing concept, not per-type gizmo code: a
**sub-point key** — `(FieldName, OptionalArrayIndex)` — resolved via the Activation
Point's own type-registry entry (Phase 45), which each specialized payload struct
declares its editable offset fields against (fixed `FVector`/`FRotator` pair fields, or
`TArray` of an offset-bearing element type) using UE's own property-reflection system
(`FProperty` introspection over the `USTRUCT`), not a hand-written per-type list.
Selecting a debug-drawn sub-point resolves to one sub-point key; dragging writes back to
exactly that key's offset (fixed field, or `Array[Index]`'s offset) via
`FScopedTransaction`/`Modify()`, same as the single-offset case. Traffic Light's 3 named
points and Crosswalk's `WaitingPoints[]` array both route through this ONE mechanism —
Traffic Light (Phase 54) and City Light (Phase 58) are call sites that configure which
sub-point keys exist for their type, not separate gizmo implementations. A type with
only the base `OffsetLocation`/`OffsetRotation` (Advertisement, TV, Seat, Parking) has
exactly one sub-point key and needs no per-type gizmo phase at all — Phase 48's base
already covers it.

Editing one array element must never disturb sibling elements or the shared anchor —
this is an explicit, separately-tested requirement (see Phase 48/79's own completion
criteria), not assumed to follow automatically from "the single-offset case worked."

## Scalability requirement (2026-08-11, mandatory — governs Phase 49 and every future object-type gizmo phase)

V6 may eventually contain 99,999+ authored city/debug objects. Gizmos MUST be strictly
selection-driven, not one-instance-per-object:

- Never create or keep a gizmo per object — unselected objects have NO active
  gizmo/tool instance.
- Only the currently selected/active object may own a gizmo; if it has sub-points, only
  the currently selected sub-point gets the gizmo (never one gizmo per sub-point either).
- Changing selection must deactivate/reuse the previous gizmo and bind it to the new
  target; deselecting must remove/deactivate the gizmo completely.
- Wireframe/PDI rendering stays independent of gizmo state and may visualize many
  objects through existing LOD/culling — the gizmo system must never gate or duplicate
  that rendering path.
- Gizmo creation must be O(1) relative to total object count. Do not scan/rebuild all
  objects every gizmo frame.
- A gizmo drag must update only the selected object's authored data and mark only the
  necessary debug/cache state dirty — never a blanket Representation/cache invalidation
  for a per-instance offset edit (Activation Points already correctly stay outside
  `MarkRepresentationDirty`'s scope — see `NexusFrameworkSubsystem.h`'s own comment).

Target shape: `99,999+ objects → PDI wireframes via LOD/culling`, but
`1 selected object (or 1 selected sub-point) → 1 active gizmo`, always.

**Verified 2026-08-11** against the already-built Phase 48 tool
(`UNexusActivationGizmoTool`/`FNexusActivationGizmoManager`) — see
`ai-change-audits/2026-08-11/research/gizmo-scalability-audit-selection-driven-architecture.md`.
Every rule above is already satisfied by that implementation (single `ActiveGizmo`/
`ActiveTransformProxy` member pair, created only on selection, destroyed on
deselection/reselection, no per-frame scan, drag write-back touches exactly one point).
The one flagged gap is NOT gizmo-instance scalability but SELECTION acquisition: the
click-time ray-vs-sphere hit test (`FindClosestSubPointHit`) is currently a linear scan
over every currently-selectable, currently-drawn Activation Point — a real cost at
99,999+ scale, though paid once per click, not per frame. Phase 47's
`FNexusSpatialGridIndex` (already built, currently only wired to a synthetic benchmark)
is the intended fix — use it as a broad-phase filter before the narrow-phase ray test —
when object counts actually reach a scale where this is measured to matter, not a
blocker for Phase 49 itself. Every future object-type gizmo phase (Traffic Light Phase
54, City Light Phase 58, Crosswalk's array sub-points, etc.) reuses this SAME
`UNexusActivationGizmoTool` mechanism (per this doc's own "Sub-point addressing"
section above) — it does not get its own gizmo tool/instance per type, so this
compliance status carries forward automatically rather than needing re-verification per
object type.

## Mode gating (2026-08-11, mandatory — editor-usability pass, direct user request)

**Rendering and editing are separate concepts.** `PDI rendering visible` does NOT imply
`Nexus gizmo interactive`. Nexus wireframes render in Select Mode, Landscape Mode, and
other compatible modes alike (unchanged, PDI-backend-driven, mode-independent — see
`ai-change-audits/2026-08-11/bug-fixed/pdi-debug-rendering-backend-implemented.md`); the
gizmo's INTERACTIVITY is a separate, narrower gate:

```
Select Mode          -> Nexus gizmo interactive (translate/rotate works)
Landscape Mode        -> Nexus wireframes/UI still visible, gizmo INACTIVE
Foliage/MeshPaint/etc -> same as Landscape Mode - gizmo INACTIVE
```

**Why**: Landscape Mode's own sculpt/spline handles and a live Nexus gizmo competing for
the same viewport mouse input is a real, reported interaction conflict (found during
Phase 49 manual testing) that risked accidentally modifying Landscape geometry via the
wrong tool capturing a drag. The fix keeps the SAME "only active during one specific
mode" pattern Phase 48 already used (`FNexusActivationGizmoManager::Activate()`/
`Deactivate()` via `StartTool`/`EndTool` on the shared `UModeManagerInteractiveToolsContext`)
— only WHICH mode triggers it changed: Select Mode (`FEditorModeTools::
IsDefaultModeActive()`, UE 5.8's own reliable check for the engine's built-in
"camera movement, actor placement" mode), not Landscape Mode. Recomputed generically on
EVERY `OnEditorModeIDChanged` event (`FNexusLandscapeModeExtension::
RefreshGizmoActiveState`), not just a Landscape-Mode-specific transition, so leaving
Landscape Mode for ANY other non-Select mode also correctly keeps the gizmo inactive.

**Selection survives the mode switch even though the tool itself is torn down and
rebuilt.** `StartTool`/`EndTool` destroys/recreates the actual `UInteractiveTool`
instance each time, which would otherwise silently drop the current selection every
time the user left Select Mode. `UNexusActivationGizmoTool` keeps the "what's currently
selected" identity (`ActivationPointId`/sub-point key/source) in STATIC members that
survive individual tool instance Setup()/Shutdown() cycles (see that class's own header
comment) - a mode-driven `Shutdown()` deliberately leaves them alone, while an EXPLICIT
deselect (clicking empty space) clears them. `Setup()` re-resolves and silently rebinds
the gizmo to the remembered selection if it still exists/is still visible - `Select ->
Landscape -> Select` therefore preserves the user's selection without requiring a
re-click, while `Select -> Landscape` correctly leaves NO gizmo active during the
Landscape-Mode portion (never two gizmos, never a stale one left interactive in the
wrong mode).

**Gizmo visual/hit size** — separately increased the same day (direct user request: the
default ITF gizmo was too small to comfortably click, unlike Landscape's own larger
native spline handles). `GNexusGizmoVisualScale` (`NexusActivationGizmoTool.cpp`, one
centralized constant, currently `2.5`) is applied via `AActor::SetActorScale3D` on the
spawned `ACombinedTransformGizmoActor` once per selection - confirmed via engine source
(`GizmoLineHandleComponent.cpp`) to scale both the rendered mesh AND the hit-test
geometry together, purely as a rendering-transform multiplier completely independent of
the logical `UTransformProxy` transform that actually gets written back into authored
offsets - never scales any authored Nexus data. Debug marker sphere sizes
(`GActivationPointMarkerRadius`/`GSubPointMarkerRadius`) were deliberately left
unchanged (small visual point); only the click-test tolerance
(`GSubPointPickRadius`, `NexusActivationGizmoTool.cpp`, 40 → 100) grew, per the user's
own "small visual point can still have larger invisible/selection hit radius" framing.

## Scope narrowed to specialized sub-points (2026-08-11, Editor Proxy Actor pass)

Phase 49 briefly widened this tool to also drag REAL, persisted
`UNexusConfigAsset::ActivationPoints`' BASE offset (see `phase-49.md`'s own Implementation
section). That is **reverted** the same day: generic, main-object editing is no longer
this custom ITF gizmo's job. See
[16-v6-editor-proxy-actor-system.md](16-v6-editor-proxy-actor-system.md) - a small,
reusable pool of native `ANexusEditorProxyActor` instances (standard UE Actor selection
+ transform widget) now owns base-object editing for real, persisted objects near the
camera, while PDI continues visualizing all 99,999+ at any distance exactly as this
document already describes.

This document's own mechanism (`UNexusActivationGizmoTool`/`FNexusActivationGizmoManager`,
the "Sub-point addressing" section, the "Scalability requirement" section, the "Mode
gating" section) all remain exactly as written - nothing here was wrong, the tool simply
goes back to editing only `FNexusActivationPointTestStore` session-only test data (its
original Phase 48 scope) rather than real config data. Its real, ongoing future purpose
is specialized SUB-POINT editing once a real config point has a specialized payload with
actual sub-point fields (Traffic Light's VehicleLED/PedestrianLED, Crosswalk's
`WaitingPoints[]`, etc. - Phase 50+) - `FindClosestSubPointHit`'s own top-of-file comment
marks exactly where a real-point loop would be reinstated for that case, gated the same
way the test-store loop already is.

## References

- [01-v5-analysis.md](01-v5-analysis.md)
- [04-v6-architecture.md](04-v6-architecture.md)
- [06-v6-debug-system.md](06-v6-debug-system.md)
- [12-v6-activation-point-system.md](12-v6-activation-point-system.md)
- [16-v6-editor-proxy-actor-system.md](16-v6-editor-proxy-actor-system.md)
