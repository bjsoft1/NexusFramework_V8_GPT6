# 03 — V5 Problems and Lessons

Real friction points from building V5, for V6 to either fix architecturally or
consciously accept. Distinguish, per item, whether it's an **engine limitation** (V6
inherits it regardless of design) or a **V5 design choice** (V6 can do differently).

## Engine limitations (V6 inherits these if it also builds on Landscape Splines)

- **`Q.IsNormalized()` crash risk** — UE 5.8's own Landscape Spline tessellation can
  construct a non-normalized quaternion from a legitimate zero-length Hermite-curve
  derivative at certain junction rotation configurations. Unresolved as of V5; not a
  Nexus bug. If V6 still builds on native Landscape Splines, this risk carries over
  and needs its own mitigation strategy decided up front, not discovered via crash logs
  again.
- **No safe native selection API** — `SetSplineSelected` is private and crashes if
  called. Any V6 feature wanting to highlight/select native spline points must use an
  external overlay (debug lines), not the engine's own selection state.
- **Control point subclassing is blocked** (`MinimalAPI` module boundary). Any V6
  design that assumed "just subclass the control point to carry extra data" needs a
  different mechanism from day one (V5's answer: deterministic naming for a stable
  soft-object path).
- **`DeleteSplinePoints()` doesn't destroy, it reparents to transient.** Any code
  caching a `TSoftObjectPtr`/raw pointer across a delete must re-validate ownership
  (which map/component it currently belongs to), not just null-check.

## Critical bugs V5 hit and fixed — design V6 against the same class from day one

- **Cross-map stale soft-reference (real, confirmed, fixed).** `FNexusRoadPoint::SourcePoint`
  is a `TSoftObjectPtr<ULandscapeSplineControlPoint>`, which resolves by package path —
  independent of which level is currently open. Right after switching maps, the previous
  map's package can still be resident in memory (GC hasn't run yet), so `.LoadSynchronous()`
  would happily return a real, live object that actually belongs to a DIFFERENT map's
  `ULandscapeSplinesComponent`. A plain null-check can't tell the two cases apart — the pointer
  resolves "successfully" either way. This produced illegal cross-package references, engine
  ensures, save failures, and package leaks. **Fixed** via `IsControlPointOnTargetLandscape()`
  — checks the resolved object's actual `Outer` against the CURRENT map's own splines
  component, not just whether it resolves at all — applied at every call site that reads a
  `SourcePoint` (14 call sites in the final V5 implementation). Full detail:
  [v5-complete-reference.md](v5-complete-reference.md)'s `IsControlPointOnTargetLandscape` and
  `OnLandscapeSplineObjectTransacted` entries; original V5 audit:
  `NexusFramework_V5/ai-change-audits/bug-fixed/cross-map-sourcepoint-bug.md`.
  **V6 design implication**: any cached/soft reference to an external engine object that can
  outlive a map switch needs an explicit "does this actually belong to the CURRENT context"
  check at every read site — resolving to a non-null, live object is not sufficient proof of
  validity when soft references can span package/level boundaries. This is flagged concretely
  in [phases/phase-01-core-structures.md](phases/phase-01-core-structures.md) so it's designed
  in from V6's first data-model pass rather than discovered the same way twice.
- **NOT a bug, corrected premise**: a separately reported claim that "after switching map, the
  editor tool still points at the first landscape" was checked directly against current V5
  source while authoring this doc and does not reproduce —
  `UNexusFrameworkEditorSubsystem::ResolveTargetLandscape()` re-resolves fresh (no cached
  `ALandscape*`) on every call, and `HandleMapOpened` already does a full `WorldData` reset on
  every map open/switch. Recorded here so this specific claim isn't re-investigated from
  scratch again without cause.

## V5 design choices worth reconsidering for V6

- **The Save/Load reconciliation logic grew organically and reactively.** Nearly every
  Load/Save/Sync bug found in V5 was the same root shape: one direction (Load-time
  materialize, or Save-time pull) handled a topology case (mid-chain insert, closed
  loop wraparound, shared junction, cross-map stale reference) that the other direction
  hadn't been taught yet. If V6 keeps a similar pull/push split, design the topology
  edge cases (closed loops, shared junctions, partial merges) into the data model and
  reconciliation algorithm up front, rather than discovering them one Save/Load bug
  report at a time.
- **"Duplicate" identity had no real definition for a long time.** V5's merge/import
  logic didn't recognize "this incoming point is the same physical thing as one I
  already have" until very late — it relied on GUID collision-avoidance only, which is
  identity-blind. If V6 needs merge/import at all, decide the identity model (spatial?
  live-object-reference? explicit external key?) as part of the core data model, not
  bolted on later.
- **The wipe-vs-preserve question for "load a fresh layout" was never designed, only
  discovered.** V5's "Load Fresh" originally destroyed and rebuilt everything
  unconditionally; later changed to map onto/reuse already-correct live geometry and
  only flag (not silently delete) anything left over. Decide this policy explicitly for
  V6's own load/reset operations before building them, including what happens to
  Landscape (or other external) state that the loaded data doesn't reference.
- **Classification/mesh-assignment passes ran too broadly by default.** A recurring bug
  class in V5: a batch operation (Load, Merge) would reclassify/remesh every point it
  merely *touched* while doing something else, not just the points it actually
  *created* — silently overwriting live, correct, user-tuned state (rotation, mesh)
  that had nothing to do with the operation. If V6 has any similar "batch touches many
  entities, only some should actually be mutated" pattern, track the mutation set
  explicitly and narrowly from the start.
- **Ambiguous natural-language task descriptions cost real rework.** Several V5
  features (Load Layout's dialog options, in particular) were redefined 2-3 times
  across a single implementation because the initial description under-specified
  behavior for a real edge case. Cheaper to spend one round of explicit clarifying
  questions up front than to re-implement.
- **Crash-sensitive code needs its own explicit guardrail.** V5 ended up with a
  standing rule ("don't change rotation/tangent math without explicit approval") for
  the specific function implicated in the open engine crash — worth deciding for V6
  which subsystems (if any) warrant that same standing caution from day one, rather
  than after a crash dump forces the conversation.

## Process lessons (not architecture, but worth carrying forward)

- A durable, in-repo, append-only project memory (not agent-local/global memory)
  materially helped multi-session continuity — every fresh session could self-orient
  from the same source of truth instead of re-deriving context or contradicting past
  decisions.
- Explicit task-workflow folders (queued → active → review → QA → closed) prevented
  silent, un-reviewed changes to already-decided behavior.
