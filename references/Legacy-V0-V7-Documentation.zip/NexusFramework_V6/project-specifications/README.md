# NexusFramework_V6 — Project Specifications

Single source of truth for V6 architecture and development specifications. See
[09-development-rules.md](09-development-rules.md) for the full rules governing this
folder (location/phase-file rules, documentation separation from `.claude/` and source),
and **[AGENT-RULES.md](AGENT-RULES.md) for standing agent policy every agent must read
before starting work** (currently: no automated testing unless the user explicitly asks).

## Index

| Doc | Status | Covers |
|---|---|---|
| [AGENT-RULES.md](AGENT-RULES.md) | Drafted | **Read first** — persistent agent policy (e.g. Agent Testing Policy) |
| [v6-coding-standard.md](v6-coding-standard.md) | Authoritative | **Read before touching any C++** (cross-referenced from AGENT-RULES.md) — naming case/prefix rules, and a serialization-risk warning before renaming a `UPROPERTY` boolean |
| [v6-master-architecture.md](v6-master-architecture.md) | Authoritative | **Read second** — the top-level architecture authority (above this README's own `04`-`14` docs and above `v6-phase-verification.md`): Landscape-as-source-of-truth, the 3 object categories, universal authoring model, N-sub-point gizmo requirement, Parking/Bus Stop/Seat field-level specs, debug LOD/always-draw, junction safety, massive-world static+dynamic actor strategy, and the mandatory 20-phase architecture-review checkpoints |
| [project-overview.md](project-overview.md) | Drafted | What V6 is, goals, scope |
| [v5-complete-reference.md](v5-complete-reference.md) | Drafted | **Deep** reference — every V5 header, field, method, gotcha. Read this instead of opening V5's source. |
| [01-v5-analysis.md](01-v5-analysis.md) | Drafted | V5's architecture as-built (short version) |
| [02-v5-feature-inventory.md](02-v5-feature-inventory.md) | Drafted | What V5 actually has |
| [03-v5-problems-and-lessons.md](03-v5-problems-and-lessons.md) | Drafted | V5 pain points, fixed bugs, and lessons for V6 |
| [04-v6-architecture.md](04-v6-architecture.md) | Drafted | V6's core design — ownership model, 5-stage pipeline, Nexus tab synced to Landscape Mode |
| [05-v6-data-flow.md](05-v6-data-flow.md) | Drafted | V6's data model / flow |
| [06-v6-debug-system.md](06-v6-debug-system.md) | Drafted | V6's debug/diagnostic tooling (30–50+ category registry) |
| [07-v6-ui-design.md](07-v6-ui-design.md) | Drafted | V6's editor UI (Mode Toolkit panel) |
| [08-v5-vs-v6.md](08-v5-vs-v6.md) | Drafted | Direct V5/V6 comparison, migration |
| [09-development-rules.md](09-development-rules.md) | Drafted | Process rules for this project |
| [10-v6-runtime-schema.md](10-v6-runtime-schema.md) | Drafted | Runtime Schema audit against V5's actual headers + V6 proposal |
| [11-v6-static-dynamic-architecture.md](11-v6-static-dynamic-architecture.md) | Drafted | Static/Dynamic/Instanced classification system |
| [12-v6-activation-point-system.md](12-v6-activation-point-system.md) | Drafted | The generalized Activation Point pattern (traffic lights, bus stops, seats, ads, ...) |
| [13-v6-gizmo-system.md](13-v6-gizmo-system.md) | Drafted | Editor gizmo editing (UInteractiveTool-based) |
| [14-v6-validation.md](14-v6-validation.md) | Drafted | Per-stage validation gates |
| [15-v6-verification-system.md](15-v6-verification-system.md) | Drafted | Manual visual-QA tree + per-instance sign-off, gating a generated map's publish readiness |

"Drafted" = has real content written from V5 knowledge, ready for review/correction.
"Skeleton" = structure and section headers exist, content is TBD (none remain in the
core doc set as of 2026-08-09; `04-v6-architecture.md` through `08-v5-vs-v6.md` and
`10`–`14` were filled in together as one internally-consistent pass — see each doc's
own References section for how they cross-link).

## Phase roadmap (`phases/`)

`phase-00.md` through `phase-99.md`, one file per development phase (see
[09-development-rules.md](09-development-rules.md) for the phase-file rules), **plus
[phase-100-verification-and-publish-gate.md](phases/phase-100-verification-and-publish-gate.md)**
— a deliberate exception added 2026-08-09 (see `09-development-rules.md` rule 3) for a
system that only makes sense once everything else exists to verify.
[PHASE-STATUS.md](PHASE-STATUS.md) is a generated, single-glance status table for all of
them — read that instead of opening every file to check progress. All of `00`–`99` have
real Objective/Allowed/Not Allowed/Completion Criteria content (drafted 2026-08-09
against the `04`–`14` architecture docs above); none are still "TBD" skeletons. Status on
every one of them is still **Not started** except Phase 00 (**Complete**) and Phase 01
(**Ready for Review**) — having real planned content is not the same as having been
built yet. High-level shape:

- `phase-00-v5-study.md` — **Complete**. V5 study is done; produced `v5-complete-reference.md`.
- `phase-01` – `phase-04` — Core structures, Editor Plugin Foundation (`FNexusLandscapeModeExtension`
  syncing a Nexus Nomad tab to built-in Landscape Mode — **not** a custom `UEdMode`, see
  `04-v6-architecture.md`'s Editor surface section and the 2026-08-09 architecture
  correction), UI Shell, UI Interaction.
- `phase-05` – `phase-17` — Landscape Reader (Source stage), Nexus Mapping, automatic
  `[LandscapeId]_nexusconfig` lifecycle (replaces V5's Load Layout entirely).
- `phase-18` – `phase-22` — Representation (HighwayPoint graph, ActivationPoint base
  struct, validation gate).
- `phase-23` – `phase-39` — Debug Architecture (category registry, tree, rendering,
  performance), HighwayPoint/lane detail, validation-gate hardening.
- `phase-40` – `phase-49` — Static Generator foundation, Activation Point base system
  end-to-end smoke test.
- `phase-50` – `phase-75` — Real object types built on the Activation Point pattern:
  Traffic Light, City Light, Crosswalk, Bus Stop, Seat, Parking, Advertisement, TV, and
  a proof-of-onboarding-cost exercise for a brand-new type.
- `phase-76` – `phase-84` — Gizmo system polish, Runtime Compiler (closing the Runtime
  Schema gaps identified in `10-v6-runtime-schema.md`).
- `phase-85` – `phase-93` — Runtime activation subsystem, at-scale optimization passes.
- `phase-94` – `phase-99` — `.claude` workflow for V6, end-to-end/regression testing,
  final architecture coverage review, final validation sign-off.
- `phase-100` — manual verification tree (State/City/Highway/placed-object hierarchy,
  click-to-focus, per-instance sign-off checklist) gating Runtime Compiler export; see
  [15-v6-verification-system.md](15-v6-verification-system.md).

See [v6-phase-verification.md](v6-phase-verification.md) for the strict
requirement-by-requirement coverage audit of this roadmap against the master V6
architecture prompt.

## Human-facing HTML view

`../html-docs/` renders this whole folder as a browsable site (sidebar nav, light/dark theme,
an interactive phase-tracker page) for visual review — open `html-docs/index.html` directly in
a browser. The markdown files in THIS folder remain the authoritative, edited source; the HTML
is a regenerated view of it (see `html-docs/README.md` for the regeneration convention). Never
hand-edit the `.html` files expecting it to stick.

## Reading order for a fresh session/agent

1. This README.
2. **`AGENT-RULES.md` (standing agent policy — read before doing any work).**
3. **`v6-master-architecture.md` (the top-level architecture authority — read before
   `09-development-rules.md`; every phase must trace back to this doc's pipeline and
   Sections 3-12's requirements, per its own Section 35 "final instruction").**
4. `v6-phase-verification.md` (the requirement-coverage audit `v6-master-architecture.md`
   sits above and extends).
5. `09-development-rules.md` (how work here proceeds).
6. `PHASE-STATUS.md` (what's done, what's pending, current phase — fastest orientation).
7. `01-v5-analysis.md` → `02-v5-feature-inventory.md` → `03-v5-problems-and-lessons.md`
   (what V5 is and what V6 should react to); `v5-complete-reference.md` when field/method-level
   detail is needed.
8. `project-overview.md`, then `04-v6-architecture.md` onward once those are filled
   in.
9. `phases/` for the current implementation step.

Within a single session that has already loaded 1-4 above, do not reload them before
every subsequent command (`v6-master-architecture.md`'s own Section 17) — only the
current phase spec and any doc it directly references.
