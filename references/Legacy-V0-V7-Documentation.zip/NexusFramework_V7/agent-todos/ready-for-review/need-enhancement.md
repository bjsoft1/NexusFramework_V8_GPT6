we need imporovemnt the current phase update:
1. [X] The delete mesage should show popup,
2. [X] After delete the tree view not refresh
3. [X] The diagnostics, message, warning, error, success any the status mesage should be allow copy or select.
4. [X] When asking the delete then focus next tab so, it will maybe auto fixed if convert into dialog.
5. [X] `[Blocking] Nexus.Authoring.NoChange: The name is unchanged.` — create a new point and immediately try to rename.
6. [X] Autosave / dirty ownership → handed over as [save-and-dirty-ownership.md](../ready-for-review/save-and-dirty-ownership.md), and closed there 2026-08-27.

# Enhancements — delete confirmation, refresh, copyable messages

Reported from the editor against the Phase 07 CRUD build. All four fixed 2026-08-24;
123/123 automation tests pass, and `Scripts/VerifyPhase07Crud.ps1` passes on three
clean builds.

Items 1 and 4 turned out to be one defect with two symptoms, and the guess in item 4
was right: converting the confirmation to a dialog fixes both. Item 2 was not about
delete — **no** command run from the shell refreshed anything.

---

## 1 and 4. Delete confirmed inline, and asking moved the user to another tab — **fixed**

**Cause.** `SNexusConfirmationBar` was a collapsed region inside `BuildCommandBar`,
which every surface builds. Three surfaces open means three confirmation bars, and each
one subscribed to `OnPendingConfirmationChanged` and called `SetKeyboardFocus` on *its*
cancel button when a confirmation appeared. Whichever ran last won.

Separately, `RunCommand` did this on the destructive branch:

```cpp
if (RequestConfirmation(CommandId))
{
    FocusSurface(WorkspaceState.FocusedSurface);   // TryInvokeTab
    return false;
}
```

`FocusSurface` calls `TryInvokeTab`, which brings that tab forward. So pressing Delete
raised the *saved* focused surface whether or not it was the surface you were on — the
tab switch in item 4. It was there because the bar was invisible unless you were looking
at the surface that drew it; the tab switch existed to make the inline strip findable.

**Fix.** `SNexusConfirmationDialog`, a single popup the module owns, replacing
`SNexusConfirmationBar` (deleted). Pushed with `FSlateApplication::PushMenu` over the
surface that already has focus — the same mechanism the command palette uses, so it is
still not an operating-system modal and `Nexus.V7.Shell.NotificationsAreNonModal` still
passes with every forbidden API unreached. V7-UX-SPEC.md section 15 permits a dialog for
destructive confirmation, which is what this is.

The tab invocation is gone from `RunCommand`. `FocusSurface` is now reached only from
inside `OpenConfirmationDialog`, and only when no Nexus surface is open at all — the
question has to be asked somewhere, and there is nowhere yet. That is not the reported
bug, which fired even when a surface was already focused.

Consequences of it being one popup rather than three strips:

- One control takes focus, and it is the cancel control. Section 15's safe default.
- Escape cancels, and so does clicking away: `IMenu::GetOnMenuDismissed` routes every
  dismissal back through `CancelPendingConfirmation`, so a dismissed popup cannot leave
  a live approval behind that the next Accept would run.
- A second destructive request answers the first one "no" before asking, and does it
  *before* writing the new pending state — dismissing the old popup runs its cancel,
  which would otherwise clear the confirmation that replaced it.
- Opened from a context-menu entry, the popup survives: `SMenuEntryBlock::OnClicked`
  dismisses the menu stack before running the action, precisely so an action can start
  a new one.
- The affected list scrolls past 200px, so deleting two hundred rows can say so without
  growing a popup taller than the screen.
- If the popup cannot be shown at all, the confirmation is dropped rather than held
  invisibly; the command then runs, is refused with `Nexus.Command.ConfirmationRequired`,
  and the user is told why.

**Guards.** `Nexus.V7.Shell.ConfirmationIsAPopup`. No `NexusEditorUI` file may name
`SNexusConfirmationBar` — a reintroduced per-surface strip compiles and lays out fine, so
it has to be caught in the source. The same test reads `RunCommand`'s destructive branch
and fails if it focuses a surface, and builds a real dialog to assert that its initial
focus is not the confirm control and that the confirm control names the verb rather than
saying OK.

The branch scan caught its own explanatory comment on the first run, because the comment
said `FocusSurface`. Matching now includes the open paren, and the comment was reworded —
the same trap `Nexus.V7.Module.UiMutationBoundary` already warns about for prose about a
flag satisfying a rule about the flag.

## 2. The tree did not refresh after a delete — **fixed**

Not a delete bug. **No command run from the shell refreshed any view.**

**Cause.** Only `UNexusEditorSubsystem::ExecuteCommand` calls
`Repository.NotifyChanged(Result.RefreshHint, Result.ChangedIds)`, and that broadcast is
the single thing that tells `FNexusHierarchyView`, `FNexusDetailsView`, and the state
provider that the document moved. `FNexusEditorUIModule::RunCommand` and
`AcceptPendingConfirmation` both called `FNexusCommandService::Get().Execute` directly,
so nothing was ever told.

They had a reason to: the subsystem's `ExecuteCommand` built its own context, and the
shell's context carries the invoking surface and — for a destructive command — the
approval the user gave against a specific preview. Going through it would have discarded
both.

The mutation itself was correct throughout. `ExecuteDelete` returns
`ENexusRefreshHint::Hierarchy`, the entities were removed, the revision advanced. Every
assertion about the document passed, and the tree drew rows for records that no longer
existed. Delete is where it is most obvious, because a stale row is a row you can select
and then act on.

**Fix.** `UNexusEditorSubsystem::ExecuteCommand(FName, const FNexusCommandContext&)` — the
same refresh, for a caller that has already built its context. The one-argument overload
now delegates to it. The module routes both call sites through
`FNexusEditorUIModule::ExecuteAndRefresh`, which uses the subsystem when there is one and
falls back to the service only when there is not.

**Guards.**

- `Nexus.V7.Crud.DeleteRefreshesViews` binds a real `FNexusHierarchyView` to the
  subsystem's repository, deletes a City through the subsystem with a real approval, and
  asserts the repository broadcast exactly once with the hierarchy hint and that the
  bound view — never touched directly — has dropped the row.
- `Nexus.V7.Module.UiMutationBoundary` now also requires that a `NexusEditorUI` file
  reaching `FNexusCommandService::Get().Execute(` also names
  `Subsystem->ExecuteCommand(`, and reaches the service directly at most once. A second
  direct call would be a route that skips the refresh.

## 3. Status messages could be read but not copied — **fixed**

**Cause.** `STextBlock` cannot be selected. Every diagnostic, refusal reason, failure
message, and state sentence in the shell was drawn in one, so the only way to get an
error out of the editor was to retype it.

**Fix.** `NexusShellUI::MakeSelectableText` — a read-only `SMultiLineEditableText` styled
as a plain label. It accepts no typed character, commits nothing, and opens no
transaction, but it has a caret, drag-selection, Ctrl+C, and the right-click Copy /
Select All menu. Now used for:

| Where | What |
| --- | --- |
| `SNexusBanner` | message and detail, plus a **Copy** button that takes both |
| `SNexusStateView` | headline and detail |
| `SNexusShellSurface` | the footer status line |
| `SNexusDetailsPanel` | validation findings, the dirty/stale/read-only banner, the kept-draft notice, the empty-state message |
| `SNexusConfirmationDialog` | consequence and affected list |
| `NexusShellUI::MakeKeyValueRow` | the value half — asset paths, ids, revisions |

Two things it is deliberately **not** used for.

Colour that changes at runtime: the style is fixed at construction, so the Details banner
uses `MakeSelectableTextInheritingColor`, which sets `FSlateColor::UseForeground()` and
takes the live colour from the containing `SBorder`'s `ForegroundColor`.
`FSlateTextRun::OnPaint` resolves it against the inherited widget style each paint.

List rows: a selectable region swallows the click that selects the row. The Activity list
instead got the context menu it never had. `Nexus.History.CopyEntry`,
`Nexus.History.CopyTechnicalDetails`, and `Nexus.Debug.CopyDiagnostics` have been
registered, eligible, and listed in the palette since Phase 04 — with nothing on any
surface able to summon them. `NexusMenus::BuildActivityContextMenu` is that, generated
from the catalog, and Slate selects the right-clicked row before the menu opens, so the
copy commands act on the row the user aimed at. The row tooltip says so.

**Guards.**

- `Nexus.V7.Shell.MessagesAreCopyable` walks the real widget tree of every surface and
  counts selectable regions. Whether text can be selected is a property of the widget,
  not of the string, so no assertion about wording can see it.
- `Nexus.V7.Shell.ActivityCopyIsReachable` summons the menu from a real
  `SNexusActivityLog` rather than calling the builder — a builder-level test would have
  passed for the whole time the commands were unreachable. See
  [[declared-is-not-reachable]].
- `Nexus.V7.Command.SurfaceParity` now checks the Activity menu alongside the toolbar,
  row menu, and Window submenu.

## 5. Accepting a new item's offered name reported an error — **fixed**

Reported as `[Blocking] Nexus.Authoring.NoChange: The name is unchanged.` after
creating a point and immediately trying to rename it.

**Cause.** `ExecuteCreate` selects the new row and opens inline rename on it, per
section 7.5 — with the generated name already in the box. `SInlineEditableTextBlock`
commits on Enter *and* on focus loss, so accepting that name, or clicking anywhere
else, commits it unchanged. `SNexusHierarchyRow::HandleNameCommitted` ran the Rename
command with it regardless, and `FNexusEntityCommandService::Rename` refuses an
unchanged name as **Blocking** `Nexus.Authoring.NoChange`.

So the commonest thing to do with a new row — take the name it offers — produced a
red banner. The inline editor made it worse by agreeing first: `HandleVerifyName`
excludes the entity itself from the collision check, so the field reported the name as
valid and the command then called it an error.

**Fix.** In `ExecuteRename`, committing the name the item already has is treated as an
acceptance: the editor closes, nothing is written, and the result is success with
`bChanged = false` and an Information diagnostic (`'X' kept the name it already had.`).
No banner — `ReportCommandOutcome` only toasts on `bChanged` — and Activity still
records that the user did something.

The mutation service still refuses an unchanged rename. At that layer it is a request
to change a name to itself and there is no caller intent to read; the command layer is
the one that knows the difference, so it is the one that decides. Putting it there
rather than in the row widget also means the palette, `F2`, and automation all get it.

**Also fixed, because the fix would otherwise have introduced it.** `FName` compares
case-insensitively, so `Record.Identity.DisplayName == NewDisplayName` read
`point` → `Point` as no change. Before, that was a Blocking error; after, it would
have become a *silent* no-op, which is worse. Both layers now compare with
`ENameCase::CaseSensitive`, so a rename that only alters casing reaches the document.
Sibling collision stays case-insensitive — two siblings differing only in case is a
trap, not a feature.

**Guards.** `Nexus.V7.Crud.CreateFlow` now creates a row and commits the offered name
back unchanged: success, nothing blocking, `bChanged` false, revision unmoved, editor
closed, and a diagnostic recorded. `Nexus.V7.Crud.Rename` covers the casing case.

**Proven.** The fix was stripped and the suite re-run. `CreateFlow` failed with
*"Expected 'accepting the offered name is not a failure' to be true"*, plus the
blocking-diagnostic and editor-closed assertions. Restored and re-verified.

---

## Verification

```
PASS: clean build NexusFrameworkEditor-Win64-Development
PASS: clean build NexusFramework-Win64-Development
PASS: clean build NexusFramework-Win64-Shipping
PASS: Nexus.V7.Module - 12 results
PASS: Nexus.V7.Command - 17 results
PASS: Nexus.V7.Crud - 15 results
PASS: Nexus.V7.Hierarchy - 14 results
PASS: Nexus.V7.Shell - 17 results
PASS: Nexus.V7.Details - 23 results
PASS: Nexus.V7.Foundation - 21 results
PHASE 07 CRUD: PASS
FOUNDATION STRUCTURAL SCAN: PASS
Nexus.V7 (all): 123 tests, 0 failures
```

## Not covered

The popup's on-screen position and appearance need a person. Automation builds the dialog
and reads its focus and wording, but `PushMenu` needs a real window to place anything, so
nothing here proves the popup lands over the focused surface at 100% and 200% scale, or
that clicking away dismisses it. Same for the selectable text: the widget is the right
one and it is where it should be, but no headless test can drag a mouse across it. Both
belong on the E3 human checklist.
