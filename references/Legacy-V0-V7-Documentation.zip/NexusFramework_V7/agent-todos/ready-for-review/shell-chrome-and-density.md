# Handover — the shell repeats its chrome on every tab, and the chrome is too big

1. [X] Notification banners are drawn on all three surfaces at once. Scope them.
2. [X] The toolbar (Command Palette / Refresh / … overflow) is drawn on all three. Scope it.
3. [X] Toolbar and search-row controls read as oversized. Cut the row height ~40-50%.
4. [X] The `Ready · NexusWorldDefinition_0 · UNSAVED` strip is on all three. **Read item 4 before touching it — the spec requires it there.**

Raised by the user 2026-08-24, alongside a general note: *"Need more professional
design, user friendly, clean, small."* Not fixed in that session because it is a design
pass rather than a bug fix, and item 4 contradicts a written spec requirement, which is
the user's call and not an agent's.

---

# What was done — 2026-08-27

All four closed. `PASS: 122 tests, 0 failures` via `Scripts/VerifyPhase07Crud.ps1` on
three clean builds, `FOUNDATION STRUCTURAL SCAN: PASS`, 124/124 across all of
`Nexus.V7`. The order this file suggested was followed: 3, then 2, then 1, then the
user's answer on 4.

## The shape the fix took

`FNexusSurfaceChrome`, in
[SNexusShellSurface.h](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/Widgets/SNexusShellSurface.h),
exactly as this file proposed: three booleans resolved once from `Surface` at the top
of `Construct`, so the per-surface decision reads in one place instead of as `if
(Surface ==` branches down the function.

| Item | What changed |
|---|---|
| 3 | `Nexus.ToolBar`, a copy of the engine `SlimToolBar` with `Icon20x20 → Icon16x16`, button padding `8,4 → 4,2`, background `4,6 → 2,2`. ~40px → ~22px. Registered as a Nexus style, not a mutation of the engine's. Plus `Nexus.SearchBox`, padding `8,3,8,4 → 6,2,6,2`. |
| 2 | `BuildCommandBar` returns `SNullWidget::NullWidget` unless `Chrome.bShowToolbar`, which is Hierarchy only. **Command Palette dropped from `GetToolbarCommands`** — the context strip directly above it already has that button, which is the duplication the report was pointing at. `Nexus.V7.Command.SurfaceParity` unaffected, as predicted. |
| 1 | `FNexusShellNotification::Origin`, stamped by `FNexusNotificationOriginScope` around every command run. A surface draws `GetForSurface(Surface)` rather than `GetAll()`. |
| 4 | User chose the middle path this file recommended. `SNexusContextStrip` gained a `Compact` argument: badge + name + dirty marker, count and revision into the tooltip it already builds, workspace and palette controls dropped. Hierarchy keeps the full strip. **No spec amendment needed** — section 3.3 asks for "compact" and this is the first build where it is. |

Also done, from the "worth fixing while you are in there" note: **the surface header
is gone entirely.** It carried the second of three readiness badges on one panel, and
restated the surface name and description that the tab label and its tooltip already
carry — `SetTooltipText(GetSurfaceDescription(...))` at
[NexusEditorUIModule.cpp:185](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/NexusEditorUIModule.cpp#L185).
Nothing was lost and it was the tallest block in the column, worth about 60px per
surface — more than the toolbar cut.

## The origin, and why `InvokedFrom` could not supply it

This file said `FNexusCommandContext` already carries the invoking surface. It does
not: `InvokedFrom` is an `FName` naming the *control* — `"Surface"`, `"CommandPalette"`,
`"CommandList"`, `"StatusAction"`, `"Confirmation"` — and every surface passes the same
`"Surface"`. `WorkspaceState.FocusedSurface` was no better: it only moves when the
module raises a tab itself, never when the user clicks into one.

So the module now tracks `ActiveSurface`, set from three places: the tab-activation
callback (before its focus guard, since the user has moved there whether or not the
module touches focus), the surface's own `OnRunCommand` lambda, and `FocusSurface`.

A **scope** rather than a parameter on `Post`, because a command handler may post its
own message — `Nexus.About` does — and an argument would mean the handler that forgot
went back to appearing on all three tabs. Nesting restores the enclosing origin.

An origin-less notification is still drawn everywhere, deliberately: the only ones are
the two workspace-recovery messages posted at startup, before any surface exists to
have invoked anything, and a user with one tab open must still see them.

## The guard, proven by reverting

`Nexus.V7.Shell.ChromeIsNotRepeated` counts widgets by type across all three surfaces
via a new `NexusShell::CountSurfaceWidgetsOfType`, in the shape this file suggested.
Reverted both fixes and re-ran it before claiming it works:

```
Expected 'one message means one banner on screen, not three' to be 1, but it was 3.
Expected 'and one toolbar across the shell, not three' to be 1, but it was 3.
```

It also checks the context strip's document line per surface, built through
`FNexusSurfaceChrome::For` rather than through a second copy of the rule.

`Nexus.V7.Shell.StyleTokens` now asserts the toolbar and search-box dimensions, so an
edit that restores the engine defaults is visible rather than merely different.

## Not covered

Whether a panel reads as clean is a person's judgement, and no automation here reaches
it. Added as check 14 of
[the E3 checklist](../../project-specifications/evidence/phase-07-e3-manual-checklist-2026-08-24.md),
written to be run with all three tabs open at once — the only configuration in which
the original report is visible — including a 200% DPI pass.

---

## One cause behind items 1, 2 and 4

[SNexusShellSurface::Construct](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/Widgets/SNexusShellSurface.cpp#L134-L202)
builds the same seven-slot column for every surface, with no branch on which surface it
is:

```
context strip      <- item 4      SNexusShellSurface.cpp:142
surface header     <- see below   SNexusShellSurface.cpp:158
command bar        <- item 2      SNexusShellSurface.cpp:164
notification list  <- item 1      SNexusShellSurface.cpp:171
compact navigation
body (splitter)
status footer                     SNexusShellSurface.cpp:196
```

Open all three tabs and the user sees three of each. That is the whole report.

The class comment says the three surfaces share the frame "so they cannot drift apart
visually" — a good reason for shared *construction*, but it was read as a reason for
identical *content*. Keep the shared builder; give it per-surface content rules. The
cheapest shape is a small `FNexusSurfaceChrome` struct (`bShowNotifications`,
`bShowToolbar`, `bShowContextStrip`) resolved once from `Surface` at the top of
`Construct`, so the decision sits in one readable place rather than in four
`if (Surface ==` branches scattered down the function.

### Also worth fixing while you are in there

**The same readiness badge is drawn three times on a single surface** — context strip,
surface header ([SNexusShellSurface.cpp:311](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/Widgets/SNexusShellSurface.cpp#L311)),
and status footer ([SNexusShellSurface.cpp:591](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/Widgets/SNexusShellSurface.cpp#L591)),
all bound to `GetState()`. This is not cross-panel duplication, it is within one panel,
and it is the cheapest thing on this list that serves "clean, small". Two of the three
can go. Suggestion: keep the context strip's (it is the spec's, §3.3) and the footer's
(it sits next to the sentence that explains it), drop the header's. The header also
restates the surface name and description that the tab label already carries; it is the
most expendable slot in the column.

---

## 1. Notifications on every panel

One [`FNexusShellNotificationCenter`](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/NexusEditorUIModule.cpp#L49)
is created by the module and handed to every surface
([NexusEditorUIModule.cpp:748](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/NexusEditorUIModule.cpp#L748)).
Each surface subscribes to `OnChanged()` and rebuilds its own banner list from
`GetAll()` in [`RebuildNotifications`](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/Widgets/SNexusShellSurface.cpp#L648).
So one command outcome renders up to three identical banners, each with its own Copy and
Dismiss button, and dismissing one clears all three.

**The user is right and the spec agrees.** V7-UX-SPEC.md §9.2 places messages by kind:

> - Property-level messages appear beside or below the affected property…
> - Selection summary appears in the Details banner.
> - Row badges summarize unresolved messages in Hierarchy.
> - Full, filterable evidence appears in Activity.

And §15: *"Warnings persist in **the relevant panel** until resolved/dismissed"*,
*"Errors never vanish only because a toast timed out; they remain in Activity."*
"The relevant panel" is not "all of them".

The user offered a second option — *"or just show UE toaster message"*. §15's first line
allows it (`FSlateNotificationManager`) but only *"when the result is not already
obvious"*, and only for success. Errors must still land somewhere durable. So a toast
cannot be the whole answer; Activity is the floor.

**Suggested shape.** Banners render on the surface the command was invoked from, plus
Activity always. `FNexusShellNotification` would need an origin field —
[`ReportCommandOutcome`](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/NexusEditorUIModule.cpp#L667)
already knows it, because `FNexusCommandContext` carries the invoking surface. If that is
more than you want to take on, the much smaller version is: banners on Hierarchy and
Activity only, none on Details — Details already has its own dirty/validation banner per
§8.1, which is what §9.2 actually asks for there.

## 2. The toolbar on every panel

[`BuildCommandBar`](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/Widgets/SNexusShellSurface.cpp#L638)
returns `NexusMenus::BuildToolbar(CommandList)` unconditionally. The four commands are
fixed in [`GetToolbarCommands`](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/NexusMenus.cpp#L113):
Command Palette, Refresh, Validate Document, Show Diagnostics.

**The spec puts a toolbar on Hierarchy only.** §7.1 lists "authoring toolbar" in the
Hierarchy layout. §8.1's Details layout has no toolbar — it has a sticky footer with
Revert and Apply. §14.1's Activity is a filterable list. So scoping the toolbar to
Hierarchy moves the code *toward* the spec, not away from it.

Two things that look like blockers and are not:

- **§6.3 surface parity** requires the toolbar and the palette to map to the same
  command IDs. That is about IDs, not about where the widget is drawn.
  `Nexus.V7.Command.SurfaceParity` calls `GetToolbarCommandIds()`, which reads the
  catalog list and never builds a widget, so it passes unchanged.
- **The Command Palette button** is not only in the toolbar — the context strip has its
  own, in the slot Phase 03 reserved for it
  ([SNexusContextStrip.cpp](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/Widgets/SNexusContextStrip.cpp)).
  That is arguably the duplication the user is actually pointing at: *the same button
  twice on the same panel*. Drop it from one. §3.3 names the command-palette button as
  part of the strip, so drop the toolbar's.

## 3. The controls are too big

The user asked for 40-50% smaller. Worth knowing before you start: **the bulk is padding,
not glyphs.**

[`NexusMenus::BuildToolbar`](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/NexusMenus.cpp#L127)
uses `FSlimHorizontalToolBarBuilder` and never calls `SetStyle`, so it inherits
`FCoreStyle`'s `"SlimToolBar"`. From `StarshipCoreStyle.cpp`, that style is:

| | value |
|---|---|
| `IconSize` | `Icon20x20` |
| button `NormalPadding` | `8, 4, 8, 4` |
| `BackgroundPadding` | `4, 6` |
| `ButtonPadding` | `4, 0` |
| label | shown beside the icon |

That is a ~40px row for a 20px glyph. Halving the glyph to 10px would put it below any
reasonable hit target, would strain §18.1's "meaningful non-text controls target at least
3:1" at 100% DPI, and would barely move the row. Trimming padding gets the whole 40-50%
and keeps the icon legible:

```
Icon20x20 -> Icon16x16          (engine standard, same as the Content Browser)
NormalPadding 8,4 -> 4,2
BackgroundPadding 4,6 -> 2,2
```

≈ 40px → ≈ 22px, about 45%, with an accessible glyph. Register it as a Nexus-owned
`FToolBarStyle` copied from `SlimToolBar` in
[NexusEditorStyle.cpp](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/NexusEditorStyle.cpp)
and call `Builder.SetStyle(&FNexusEditorStyle::Get(), TEXT("Nexus.ToolBar"))`. Do not
mutate the engine style in place — it is shared with every other editor toolbar.

While you are there: `BuildToolbar`'s comment claims it uses "the editor's own slim
toolbar style". It resolves to `FCoreStyle`, not `FAppStyle`. Both land on the same
Starship slim toolbar today so nothing is visibly wrong, but the comment should say what
the code does.

**The "… more" button is not a defect.** It is the SlimToolBar overflow, and §18.3
requires it: *"Toolbars collapse lower-priority labels into an accessible overflow
menu."* What it is telling you is that four labelled buttons do not fit a docked panel
width — which items 2 and 3 both fix. Do not remove the overflow.

**The search row.** [`BuildSearchRow`](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/Widgets/SNexusHierarchyTree.cpp#L528)
uses a stock `SSearchBox`, whose glass icon is already overridden to 14px
(`SetImageSizeOverride(FVector2D(14.0f))`). The icon is not the problem; the text-box
height is. If it still reads heavy once the toolbar shrinks, style the box rather than
the icon — and check the result at 200% DPI, which `Nexus.V7.Shell.SurfaceLayout` already
lays out but only asserts non-degenerate sizes for.

## 4. The context strip — the user's request conflicts with the spec

*"The top Ready NexusWorldDefinition_0 Unsaved showing in all panel just show in one
panel."* That string is the context strip: badge + `GetDocumentText` + `GetDirtyText`.

**V7-UX-SPEC.md requires it on all three tabs, in three separate places.** §3.3: *"Each
tab begins with a compact context strip"*, listing document name, readiness, workspace,
dirty/recovery indicators, Home and palette buttons. §7.1 and §8.1 both open their layout
lists with "shared context strip". The widget's own header comment gives the reasoning: a
user who docks one tab away from the others must still be able to see which document they
are editing and whether it is saved.

That reasoning is sound, and it is why this was not simply done. **Do not remove the
strip on your own judgement — it needs the user's decision, and if they confirm, it needs
a spec amendment, not a silent divergence.**

There is a middle path worth offering them first, because it may be what they actually
want: the strip is not currently *compact*, which is the one adjective §3.3 uses for it.
On Details and Activity it renders the full document sentence
(`"{name} - {n} entities, revision {r}"`), a workspace combo button, and a Command
Palette button, none of which those tabs act on. Condensing non-Hierarchy tabs to
badge + document name, with the entity count and revision moved into the tooltip
`GetDocumentTooltip` already builds, removes most of the visual weight, keeps the
docked-away-tab guarantee, and stays inside §3.3. Show them that before proposing
removal.

---

## Suggested order

**3, then 2, then 1, then ask about 4.**

Item 3 is self-contained and changes how everything else looks, so doing it first tells
you how much of the complaint was density rather than duplication. Item 2 is a few lines
once the chrome struct exists. Item 1 is the largest, because doing it properly means
threading an origin through the notification centre. Item 4 is blocked on a decision.

Estimates: 3 is 30-45 min including the style registration and a DPI check. 2 is 15 min.
1 is 1-2 hours for the scoped version, 20 min for the "Hierarchy and Activity only"
version. 4 is a conversation.

## What will break

Run these before you start so you know which failures are yours:

- `Nexus.V7.Shell.MessagesAreCopyable`
  ([NexusShellTests.cpp:1321](../../Plugins/NexusFrameworkV7/Source/NexusTests/Private/NexusShellTests.cpp#L1321))
  asserts **every** surface offers at least one selectable text region. Today the footer
  guarantees that. If you drop the footer from a surface, check that surface still has a
  selectable region from its own content — and if it does not, the test is right and you
  are wrong.
- `Nexus.V7.Shell.SurfaceLayout`
  ([NexusShellTests.cpp:1172](../../Plugins/NexusFrameworkV7/Source/NexusTests/Private/NexusShellTests.cpp#L1172))
  builds all three surfaces in all nine states at 100% and 200% and asserts a
  non-degenerate desired size. Removing a slot can make a sparse surface degenerate.
- `Nexus.V7.Command.SurfaceParity`
  ([NexusCommandSystemTests.cpp:1504](../../Plugins/NexusFrameworkV7/Source/NexusTests/Private/NexusCommandSystemTests.cpp#L1504))
  should be unaffected — see item 2 — but confirm rather than assume.

**Add a guard for the thing being fixed**, or this comes back. No test today counts how
many times a given piece of chrome is built across the three surfaces, which is exactly
why three copies shipped. `NexusShell::CountSelectableTextWidgets`
([SNexusShellSurface.cpp:1018](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/Widgets/SNexusShellSurface.cpp#L1018))
is the pattern to copy: it walks a real surface's widget tree counting widgets by type. A
`CountWidgetsOfType(Surface, TEXT("SNexusBanner"))` in the same shape would have caught
all of this, and would catch it again.

## How to verify

Per [[verify-claims-by-re-running]]:

```
powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase07Crud.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyFoundation.ps1
```

Baseline before this work: `PASS: 119 tests, 0 failures`, `PHASE 07 CRUD: PASS`,
`FOUNDATION STRUCTURAL SCAN: PASS`, and 123/123 across all of `Nexus.V7`.

None of this is provable by automation alone — whether a panel reads as clean is a
person's judgement. Add what you change to
[the E3 checklist](../../project-specifications/evidence/phase-07-e3-manual-checklist-2026-08-24.md)
with all three tabs open at once, which is the only configuration in which the original
report is visible.
