# Bug — a new document could not be authored, and a fixture looked like lost work

1. [X] An empty tree offered no Create. From zero, nothing could be made.
2. [X] Editing a fixture showed no asset and no dirty state, with no explanation.
3. [X] Auto-generated per-map config asset, as V6 had.

Reported by the user 2026-08-27:

> *"in first time the tree has empty and not showing any options, to create, state,
> city or anythings, so, from 0 i am not able to create any things, I need to run
> console command for some demo then allow to create or add."*

> *"when i edit any from the tree i cannot see any data-assets and not showing dirty
> in editor … the old version we have: mapname/filename. this auto generate and
> editor showing … why missing in new version?"*

Items 1 and 2 were fixed on 2026-08-27. Item 3 was deferred to Phase 10 twice on the
same day, refused a third time, and is now implemented — section 3 has both what
was built and why the deferral was the wrong answer to give three times.

`PASS: 124 tests, 0 failures` via `Scripts/VerifyPhase07Crud.ps1 -SkipBuilds`, on a
`Result: Succeeded` editor build. The two new tests are
`Nexus.V7.Crud.WorldDocumentBinding` and `Nexus.V7.Crud.DefaultHierarchy`.

---

## 1. The list was collapsed, so the right-click had nothing to land on

[SNexusHierarchyTree.cpp](../../Plugins/NexusFrameworkV7/Source/NexusEditorUI/Private/Widgets/SNexusHierarchyTree.cpp)
drew the list and the state message as two stacked slots that took turns:

```cpp
EVisibility GetListVisibility() const { return Rows.IsEmpty() ? Collapsed : Visible; }
```

**A collapsed widget receives no mouse events.** `Create` lives in the list's
right-click menu (`SListView::OnContextMenuOpening` → `BuildRowContextMenu`), so with
no rows there was no surface to right-click and no way to make the first entity. The
only escape was `Nexus.Fixture.LoadSample`, and creating from zero is precisely what a
fixture cannot help with.

**The command layer was willing throughout**, which is why nothing caught it.
[`FNexusAuthoringView::GetLegalCreateKinds`](../../Plugins/NexusFrameworkV7/Source/NexusEditor/Private/NexusAuthoringView.cpp#L67)
already handles the empty case and says so in a comment: *"Nothing usable is selected,
so Create targets the document root. That is a real, legal context rather than a
refusal: an empty document has to be startable from somewhere."* World and State are
legal at the root. Every existing assertion about Create ran against a selection.

**Fix.** The list and the empty state are an `SOverlay` now. The list is always
`Visible` and hit-testable even with zero rows — which is how the Content Browser and
the World Outliner behave — and the empty panel sits over it as
`SelfHitTestInvisible`, so it does not swallow the right-click while its own buttons
stay clickable. `STextBlock`s inside it are explicitly `HitTestInvisible`;
`SelfHitTestInvisible` excuses only the container.

**And a route that does not require guessing.** The empty state was one sentence —
*"This document has no entities yet."* — and nothing else. It now follows the pattern
`SNexusActivityLog` already uses for its empty scopes (*"Title, explanation, and next
action for an empty scope. Never a blank panel."*): a headline, a detail that names
the next action, and **Create State** / **Create World** buttons built from the same
`GetLegalCreateKinds` the menu draws from, so the two cannot drift.

Both buttons and the menu entry go through one new `NexusMenus::RunCreate`, so the
empty state is not a second implementation of Create.

**A stale message went with it.** `StateNoDocument` read *"Phase 07 delivers the
authoring entry point that opens one"* — true when written, false the moment Phase 07
delivered it. **A message that names a future phase has an expiry date; one that names
the command does not.** It now names New Document, and the test asserts the string
`Phase 07` appears in neither the headline nor the detail.

**And one button that is worth more than the per-kind ones.** Create State on its
own leaves a document with one row, and every kind below City stays unreachable
until the rungs above it exist — which is the second half of what the user reported
on 2026-08-27: *"if tree is empty then show the create button as create default"*,
with `Default State > Default City > Default Highway` spelled out underneath. The
empty state's first and primary button is now **Create Default**, running a new
catalog command `Nexus.Authoring.CreateDefaultHierarchy` that seeds exactly that
chain.

It is one `CreateMany` call with the three identities generated up front, so the
child requests can name parents created earlier in the same batch: one transaction,
one undo step, and no half-seeded document if the third record is rejected. It does
not open inline rename — Create does that because the user asked for one thing and
is expected to name it, and this made three things that already carry the names the
command advertises.

`GuardCreateDefaultHierarchy` refuses a document that already holds entities, naming
the count and pointing at Create, so a second press cannot add a second "Default
State". The button is drawn only when that guard says yes, asked of the live command
rather than decided in the widget.

The seed is V6's `SeedDefaultHierarchyIfEmpty` with the automatic part removed. V6
ran it inside the flow that loaded a map's config, so a document seeded itself
without being asked; here it is a press, and the Create group in the row context
menu offers it too because that menu is generated from the catalog.

Covered by `Nexus.V7.Crud.DefaultHierarchy` at the command layer and by
`Nexus.V7.Hierarchy.EmptyIsAuthorable` at the widget, which now presses the real
button and reads the three rows back out of the live document rather than asserting
the command id the probe itself returned.

## 2. A fixture cannot be dirty, and the strip said nothing about it

`FNexusDocumentStore::IsDirty` returns false for a non-persistent document, and a
fixture lives in the transient package where `MarkPackageDirty()` does nothing. So on
a fixture the strip drew **empty space** where the dirty marker goes, no Save control,
and no reason — which reads exactly like the editor having lost the edits.

Item 1 caused item 2: the empty-tree bug forced the user onto a fixture, and the
fixture is the one document that can never go dirty.

`FNexusShellDocumentInfo::bPersistent` now carries it, and the strip says
**`IN MEMORY - NO ASSET`** in the palette's `Stale` purple — not the `Dirty` amber,
because amber means "you have work to save" and this is the one state where there is
nothing to save and never will be. The tooltip names `Nexus.Fixture.LoadSample` as the
source and New Document as the way to a real asset. Save stays hidden, via a new
`GetSaveVisibility` rather than the marker's own visibility.

## 3. The per-map config asset — delivered, after being deferred twice

V6 auto-created `Content/NF/Maps/<MapName>/NexusConfig.uasset` beside the level.
Confirmed on disk at `NexusFramework_V6/Content/NF/Maps/LV0_Development1/`.

**This was previously answered with "Phase 10, not started." That answer was wrong
to give three times.** The phase boundary was real, but a boundary is a reason to
say what it will cost, not a reason to keep handing back the same refusal to
someone who has asked three times. It is implemented now, inside Phase 07, and the
Phase 10 tracker records the pull-forward rather than pretending it did not happen.

**What was built.**
[`FNexusDocumentStore::GetDocumentPackageNameForWorldPackage`](../../Plugins/NexusFrameworkV7/Source/NexusEditor/Private/NexusDocumentStore.cpp)
derives `/Game/NF/Maps/LV0/NexusConfig` from the map `/Game/NF/Maps/LV0` — V6's own
save-beside-the-level convention, and the same one Unreal's Landscape layer assets
use. `ResolveForWorldPackage` opens that document if it exists, hands back the
in-memory one if this session already made it, and otherwise creates it.
`UNexusEditorSubsystem` calls it from `FEditorDelegates::OnMapOpened` and from a
deferred tick for the map already open at startup.

**One deliberate difference from V6: the asset is not written to disk.** V6 called
`SavePackage` inside its create path, so opening a map wrote a file. V7 leaves the
document dirty and unsaved — the Content Browser shows it with an asterisk, and
closing the editor raises Unreal's own "save these packages?" prompt. That is what
`V7-UX-SPEC.md` section 12.1 requires, it is what Unreal's own create-asset flow
does, and it is the behaviour the user described wanting: *"make it dirty and
showing unsaved in UE editor"*.

**Where it does nothing, on purpose.** An unsaved map lives under `/Temp` and the
folder derived from that name would move the moment it was saved; an engine
template map is not the user's to add an asset to; a PIE world is a decorated copy
that stops existing when play stops. All three resolve to no path and bind nothing.

**`FEditorDelegates::MapChange` is bound as well as `OnMapOpened`**, because V6
recorded — from reading the engine source, not from assuming — that File > New
Level routes through `UEditorEngine::NewMap()` and broadcasts only `MapChange` with
the `NewMap` flag. Without it, switching from a saved map to a blank one left the
saved map's document active and editable, which is a V6 bug worth not repeating.
Only a document the subsystem itself bound is dropped on that switch; one the user
opened deliberately is theirs to close.

`Nexus.AutoBindWorldDocument 0` turns the whole thing off. The bind is also skipped
under `-unattended` and in commandlets, so an automation run does not leave a dirty
package beside whatever map it was pointed at.

**Not the anchor.** `V7-ARCHITECTURE.md` says discovery "never chooses the first
asset or first Landscape it happens to find", and this does not: it is one exact
path derived from one world package, not a search. The `ANexusWorldAnchor` soft
reference is still what Phase 09 introduces and it will be authoritative over this
convention once it exists; this stays as the fallback for a map with no anchor.

Covered by `Nexus.V7.Crud.WorldDocumentBinding`.

## The guards, proven by reverting

`Nexus.V7.Hierarchy.EmptyIsAuthorable` binds an `Empty` fixture to both the view and
the subsystem — the menu asks the subsystem for the active document while the tree
draws from the repository, and binding only the view would have left Create with
nothing to target and the test measuring the harness. It then checks the real list's
visibility, reads the Create submenu, and **presses the empty state's first button**.

What it asserts about that press changed with this round. The probe used to return
`NexusCommands::Create` as a literal, which would have passed against a button wired
to nothing at all; it now reads the document back through the subsystem afterwards
and returns the rows as `Kind: Name`, and the test checks all three against the
fixture the tree is bound to.

Restored the collapse-when-empty rule and re-ran before claiming it works:

```
Expected 'an empty tree can still be right-clicked' to be true.
Expected 'and its Create menu offers the root kinds' to be true.
```

`Nexus.V7.Shell.SaveIsReachable` gained the fixture case: the marker must be non-empty
and must **not** say `UNSAVED`, and Save must stay hidden.

`Nexus.V7.Crud.DefaultHierarchy` checks the seed at the command layer: three records,
parented State > City > Highway, named as advertised, **one revision step** rather
than three, no rename box open afterwards, and a second call refused with
`Nexus.Authoring.DocumentNotEmpty` and the document unchanged.

`Nexus.V7.Crud.WorldDocumentBinding` checks the map-document derivation against the
exact V6 path (`/Game/NF/Maps/LV0_Development1` →
`/Game/NF/Maps/LV0_Development1/NexusConfig`), the three cases that must resolve to
nothing rather than to a plausible-looking path, and the resolve itself: created,
dirty, **not written to disk**, and the same object on the second resolve instead of
a duplicate or an already-exists refusal.

## Not covered

Whether the empty state reads as inviting rather than as an error is a person's
judgement, and no automation reaches it. E3 check 17.

**The map-open path itself has no automated coverage, and cannot have it here.** The
bind is deliberately skipped under `-unattended`, which is how the verification
script runs the editor, so `FEditorDelegates::OnMapOpened` firing for real is
unproven by `Nexus.V7.Crud.WorldDocumentBinding`; that test covers the derivation and
the resolve, which is everything the delegate calls but not the delegate. Opening
`Content/NF/Maps/LV0_Development1` in an interactive editor and seeing
`LV0_Development1/NexusConfig` appear dirty in the Content Browser is a manual check,
and it is the one the user asked for.
