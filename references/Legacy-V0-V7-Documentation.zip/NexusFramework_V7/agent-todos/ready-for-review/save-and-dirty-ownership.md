# Handover — who owns writing the asset to disk

1. [X] `Nexus.Document.New` silently writes the package. V7-UX-SPEC.md 12.1 forbids it.
2. [X] `Nexus.Document.Save` calls `UPackage::Save` directly, bypassing Unreal's save path.
3. [X] The Details footer says "Saved" when nothing has been written to disk.

**All three closed 2026-08-27.** Item 2 was the user's decision and they chose to route
it through Unreal's save path. What was learned doing it is at the bottom of this file.

Raised by the user 2026-08-24: *"the system auto saving … we just make it dirty and
UE save"*. Not in any upcoming phase — I checked 08 through 20; only phase-08 line 29
mentions a dirty state, and that is about testing the state, not about who owns the
write. Handed over rather than fixed because it is over the ten-minute bar the user
set and item 1 changes user-visible behaviour on a phase that is awaiting review.

**The user is describing the spec, not a preference.** V7-UX-SPEC.md section 12.1:

> - **Unreal source save** persists applied authoritative data through normal Unreal
>   package/map saving.
> - Draft autosave never marks authoritative content saved and **never silently
>   invokes a package save**.

---

## What is already correct — do not "fix" these

I audited every write path before writing this. Four of the five are right, and the
user's impression that autosave "missed to make dirty" does not match the code:

| Path | What it does |
|---|---|
| Entity mutations — `CommitCandidate`, [NexusEntityCommands.cpp:475](../../Plugins/NexusFrameworkV7/Source/NexusEditor/Private/NexusEntityCommands.cpp#L475) | `FScopedTransaction` + `Modify()` + `MarkPackageDirty()`. No write. |
| Details Apply — `ExecuteApply`, [NexusDetailsCommands.cpp:183](../../Plugins/NexusFrameworkV7/Source/NexusEditor/Private/NexusDetailsCommands.cpp#L183) | Same. No write. |
| Activation points — [NexusActivationPointCommands.cpp](../../Plugins/NexusFrameworkV7/Source/NexusEditor/Private/NexusActivationPointCommands.cpp) lines 660, 791, 931 | Same. No write. |
| Draft autosave — `AutosaveDrafts` → `FNexusDraftRecoveryStore::Write` | Writes JSON to `Saved/NexusV7/Recovery`, never Content, never touches the package. Correct per 12.2. |

`Nexus.V7.Crud.DocumentLifecycle` and `Nexus.V7.Command.*` already assert the dirty
flag on these paths, so the mechanism works and is guarded. The problem is elsewhere.

---

## 1. New Document silently writes the package

[NexusDocumentStore.cpp:239](../../Plugins/NexusFrameworkV7/Source/NexusEditor/Private/NexusDocumentStore.cpp#L239):

```cpp
FAssetRegistryModule::AssetCreated(Document);
Package->MarkPackageDirty();

FNexusDocumentResult Result = Save(Document);   // <-- silently invokes a package save
```

`Nexus.Document.New` therefore leaves a file on disk and a **clean** package. Unreal's
own "create asset" flow does the opposite: the asset exists in memory, dirty, visible
in the Content Browser with an asterisk, and is written when the user saves.

`Nexus.V7.Crud.DocumentLifecycle` currently pins the wrong behaviour in place, at
[NexusCrudTests.cpp:1474](../../Plugins/NexusFrameworkV7/Source/NexusTests/Private/NexusCrudTests.cpp#L1474):

```cpp
TestFalse(TEXT("and it is saved, not dirty"), FNexusDocumentStore::IsDirty(Document));
```

**Suggested change.** Drop the `Save` call, return the created document dirty, and
flip that assertion to `TestTrue(TEXT("and it is dirty, not yet on disk"), ...)`.

**Check before you commit to it:**

- The rest of `DocumentLifecycle` runs Save explicitly before Reload, so Reload still
  has a file to read. Verify that is still true after the flip.
- Anything that reopens by package path between New and the first Save. I did not find
  one; `Nexus.Document.Open` reads the Content Browser selection, and an unsaved new
  asset is selectable there.
- Closing the editor with an unsaved new document is now Unreal's standard
  "save these packages?" prompt rather than a silent loss. That is the point, but say
  so in the E3 checklist so a reviewer does not read the prompt as a regression.

**Also update:** [phase-07.md](../../project-specifications/phases/phase-07.md) step 3,
[phase-07-crud-2026-08-24.md](../../project-specifications/evidence/phase-07-crud-2026-08-24.md)
step 3, and check 1 of
[the E3 checklist](../../project-specifications/evidence/phase-07-e3-manual-checklist-2026-08-24.md).
All three say *"an asset appears under `/Game/Nexus`"*, which stays true — it appears
unsaved. Say that explicitly rather than leaving it ambiguous.

## 2. Save bypasses Unreal's save path

[NexusDocumentStore.cpp:329](../../Plugins/NexusFrameworkV7/Source/NexusEditor/Private/NexusDocumentStore.cpp#L329)
calls `UPackage::Save` directly. Not silent — it is the `Nexus.Document.Save` command,
which the user invokes — so it does not break 12.1's second bullet. But 12.1's first
bullet says persistence goes through *normal Unreal package/map saving*, and a direct
`UPackage::Save`:

- does not check out from source control, so on a Perforce or Git-LFS project it fails
  or silently writes a read-only file;
- does not run the editor's pre-save hooks;
- does not appear in the editor's own dirty-package accounting the way a normal save
  does.

`FEditorFileUtils::PromptForCheckoutAndSave` is the normal path. **This is a judgement
call, not a defect** — swapping it in adds a prompt to a command that currently has
none, and the shell's no-modal rule may have opinions about that. Get the user's answer
before changing it. Leaving it as-is and documenting the source-control limitation is a
legitimate outcome.

## 3. "Saved" means two different things

[NexusDetailsView.cpp:675](../../Plugins/NexusFrameworkV7/Source/NexusEditor/Private/NexusDetailsView.cpp#L675):

```cpp
case ENexusDetailsAutosaveState::Saved:
    return LOCTEXT("AutosaveSaved", "Saved");
```

The draft has been applied to the in-memory document and the package is dirty. Nothing
is on disk. A user reading "Saved" concludes otherwise, and I think this is most of why
the report says *"the system auto saving"* — the wording promises a write the code
correctly does not perform.

This is a one-string fix and the cheapest win here. Something like
`"Applied — Ctrl+S to save the asset"`. Check
`Nexus.V7.Details` first: I did not confirm whether any test asserts the literal
`"Saved"`. Related, `"Editing — saves when you finish"` has the same ambiguity.

---

## Suggested order

3, then 1, then ask about 2. Item 3 alone may be enough to close the user's actual
complaint; do it first and show them before spending time on item 1.

Estimate: item 3 is minutes. Item 1 is 20–30 including the doc updates, most of it the
`Scripts/VerifyPhase07Crud.ps1` clean-build cycle. Item 2 is open-ended and needs a
decision first.

## How to verify

Per [[verify-claims-by-re-running]]:

```
powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase07Crud.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyFoundation.ps1
```

Baseline before this work: `PASS: 119 tests, 0 failures`, `PHASE 07 CRUD: PASS`,
`FOUNDATION STRUCTURAL SCAN: PASS`, and 123/123 across all of `Nexus.V7`.

Revert your fix and re-run before you claim a guard works — the rename fix in
`need-enhancement.md` was proven that way, and the confirmation-popup guard caught its
own explanatory comment on the first run.

---

# What was done — 2026-08-27

`PASS: 122 tests, 0 failures` via `Scripts/VerifyPhase07Crud.ps1` on three clean
builds, `FOUNDATION STRUCTURAL SCAN: PASS`, 124/124 across all of `Nexus.V7`.

The suggested order was followed: 3, then 1, then the user's answer on 2.

## 3. "Saved" is now "Applied", including the enum

One string was the fix this file asked for. The enum behind it was called
`ENexusDetailsAutosaveState::Saved`, and leaving that name in place would have
regrown the same footer text the next time someone wrote a label from it — so it is
`Applied` now, across all 24 references, with the reason on the declaration.

- Footer: `"Saved"` → `"Applied — Ctrl+S saves the asset"`.
- Mid-edit: `"Editing — saves when you finish"` → `"Editing — applies when you finish"`.
- Held: `"Not saved"` → `"Not applied"`, and the two held reasons with it.

No test asserted the literal — all six read the enum — so nothing had to be loosened
to let the change through.

The other `"Saved"` strings in the shell were checked and left alone: the context
strip's tooltip, Home's save-state summary, and the `Unsaved` badge all describe the
**package** dirty flag, where "saved" is accurate.

## 1. New Document leaves the asset dirty

The `Save(Document)` call is gone from `FNexusDocumentStore::Create`, and
`Nexus.V7.Crud.DocumentLifecycle` flipped from `TestFalse("and it is saved, not
dirty")` to `TestTrue("and it is dirty, not yet on disk")`, plus a new assertion that
no `.uasset` exists before the explicit save.

**One thing this file did not anticipate.** The already-exists guard was two disk
checks — `DoesPackageExist` and `FileExists`. Both stopped covering the case the
moment Create stopped saving: a second New Document under the same name would find
nothing on disk, get the *existing in-memory package* back out of `CreatePackage`,
and construct a second asset over the first one's name. `FindPackage` is now the
third check. Worth remembering as a shape: **removing a write can invalidate a guard
that was reading the write's side effect rather than the state it stood for.**

The same assumption sat in a second place, and finding one was what found the other:
`ExecuteNewDocument`'s unique-name loop
([NexusAuthoringCommands.cpp:719](../../Plugins/NexusFrameworkV7/Source/NexusEditor/Private/NexusAuthoringCommands.cpp#L719))
skipped a candidate name only if `DoesPackageExist` found it on disk. A second **New
Document** in one session would therefore generate `NexusWorld` again and be refused by
the guard above — the fix for one defect producing another. It consults `FindPackage`
too now. `Nexus.V7.Crud.DocumentLifecycle` covers the store half (creating the same
name again before any save is refused); the command half is E3 check 1, which now says
to run New Document twice.

Everything else this file said to check held. `DocumentLifecycle` saves explicitly
before Reload, so Reload still has a file; nothing reopens by package path between
New and the first Save.

## 2. Save goes through Unreal's path — but not the obvious function

The user chose to route it. `FEditorFileUtils::PromptForCheckoutAndSave` is the
function this file named and it is the wrong one here, twice over:

1. It opens a dialog, and the shell may not.
2. **It returns `PR_Cancelled` without saving anything under `FApp::IsUnattended()`**
   — [FileHelpers.cpp:4664](file) — so every headless run reports a cancelled save.
   That is not a theory: the first build with it failed `DocumentLifecycle` with
   *"Saving '/Game/NexusV7Tests/CrudLifecycle' was cancelled."*

`UEditorLoadingAndSavingUtils::SavePackages` is what that function's own unattended
branch falls back to. It checks the package out when source control is enabled, marks
a newly created file for add afterwards, saves through the same internal path
(`InternalPromptForCheckoutAndSave` with `bUseDialog = false`), and never prompts —
which is what both 12.1 and the no-modal rule want.

`bOnlyDirty` is false: `Nexus.Document.Save` is explicit, and a user who asks to save
an already-clean document should get a written file rather than a silent no-op.

The success check is unchanged in spirit and still does not trust the return code
alone — a save can report a non-error outcome and write nothing, so the file's size
on disk is what the result claims.

## Not covered

Neither the source-control checkout nor Unreal's "save these packages?" prompt on
editor close can be exercised by automation on a workstation with no SCC provider
configured. Both are in the E3 checklist: check 1 for the unsaved-on-create
behaviour, check 15 for the footer wording.
