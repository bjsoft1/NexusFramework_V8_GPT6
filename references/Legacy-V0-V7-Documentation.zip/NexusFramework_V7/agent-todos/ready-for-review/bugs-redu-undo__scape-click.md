1. [X] Undo working but not refreshing the Treeview value, it just happens but not refresh tree view.
2. [X] During the editing time if click the escape button then textbox value auto reset: good
    But after switch focus then textbox value again comes same. And showing 
3. [X] The number inputs if chnages and click enter showing warning message: "The document changed after these edits were made. Refresh to see the currnet values, then apply again. Your edits are kept until you do."
4. [X] Regration bug: The undo redo not working not, The maybe complely broken

# Bugs — undo refresh / Escape / repeat edit / undo dead

Reported from the editor against the Phase 06 autosave build. Bugs 1–3 fixed
2026-08-23. Bug 4 was a regression caused by the fix for bug 2, fixed 2026-08-24;
101/101 automation tests pass on three clean builds.

---

## 1. Undo worked but the tree did not refresh — **fixed**

**Cause.** Nothing in the editor was an undo client. The transaction system restores
the document's arrays by writing the UObject directly, so no read path was told
anything had changed and every view kept drawing the pre-undo tree. The revision is
restored along with the contents, so even the repository's staleness check could not
notice — `RebuildIndexIfStale` compares revisions and they matched.

**Fix.** `UNexusEditorSubsystem` now derives from `FSelfRegisteringEditorUndoClient`.
`PostUndo`/`PostRedo` force `Repository.RebuildIndex()` — unconditional, not the
revision-compare path, for the reason above — then broadcast
`ENexusRefreshHint::Hierarchy` so the rows rebuild and the selection survives. Details
reloads from source, dropping any unsaved edit written against the state the undo just
removed.

The refresh is deferred by one tick. `PostUndo` runs while the transaction system is
still unwinding and the property editor is a client of the same broadcast, so rebinding
an `IDetailsView` from inside it re-enters a property editor that is midway through
reacting to the same undo. See `UNexusEditorSubsystem::RefreshAfterUndo`.

**Guard.** Partly, via bug 4's. `Nexus.V7.Details.UndoAfterAutosave` drives a real
`GEditor->UndoTransaction()` and asserts the repository's *read path* serves the
restored value after `RebuildIndex()` — the half that was actually broken here. The
widget rebuild still needs a live panel; E3 checklist item 5 covers it.

## 2. Escape reset the box, but the typed value came back on focus change — **fixed**

**Cause.** The live-text customization writes to the proxy on every keystroke.
`RevertTextOnEscape` restored the *widget's* text but nothing restored the draft, so
the abandoned value was still in the proxy — and the next rebind read it straight back
out and displayed it again.

**Fix.** Escape now calls `FNexusDetailsView::RevertField`, which restores that one
field from the baseline on every bound target and bumps the structure serial so the row
rebuilds from a value that is actually correct. Restoring text the widget happens to
hold was never going to be authoritative.

**Guard.** `Nexus.V7.Details.RevertField` — the field is restored in the draft itself,
neighbouring fields are untouched, the widget is asked to re-read, nothing is committed,
and reverting an already-clean field is a no-op rather than a spurious rebind.

**This fix caused bug 4.** The early return it added is the path that stopped closing
the property editor's transaction. See below.

## 3. Number input + Enter warned "the document changed after these edits" — **fixed**

**Cause, and the worst of the three.** After a successful autosave the commit moved the
revision and the baseline reloaded at the new one, but the reclaimed draft kept the
revision it was originally authored against. It was therefore permanently stale, so
**one successful save locked that entity for the rest of the session** — every
subsequent edit refused.

**Fix.** When a reclaimed draft matches its baseline exactly — which is precisely what a
successful autosave leaves behind — its revision is re-based to the baseline's. A draft
identical to the source has nothing stale about it. The staleness rule is otherwise
unchanged: a draft that genuinely differs from newer source is still refused.

**Guard.** `Nexus.V7.Details.RepeatEdit` edits the same entity four times in a row and
asserts each pass is not stale, reports Saved, and reaches the document.

**Proven.** The fix was reverted and the guard re-run: pass 1 committed and pass 2
failed with *"expected 20, but it was 10"* — the reported symptom exactly — while pass 3
and 4 failed the same way. Restored and re-verified.

## 4. Undo and redo stopped working entirely — **fixed**

**Symptom.** Not a stale view like bug 1. `Ctrl+Z` and `Ctrl+Y` did nothing at all, for
the rest of the session, once the Details panel had been typed into.

**Cause.** The live-text rows write through an `IPropertyHandle` on every keystroke.
`FPropertyValueImpl::ImportText` (`PropertyHandleImpl.cpp`) derives `bTransactable` from
`NotTransactable` and `bFinished` from `InteractiveChange`, then calls
`GEditor->BeginTransaction` on the first **interactive** write and
`GEditor->EndTransaction` only on a later **finishing** write. A keystroke is never a
finishing write, so the transaction deliberately stays open across the gesture and is
closed when the edit is committed.

The bug 2 fix returns from `OnTextCommitted` before that finishing write whenever the
commit type is `ETextCommit::OnCleared`, and `RevertField` then bumps the structure
serial, which rebuilds the panel and destroys the handle. The transaction was left open
with nothing left to close it. `UTransBuffer::CanUndo` refuses outright while
`ActiveCount != 0`, so **one press of Escape disabled undo and redo permanently.**

Changing selection mid-edit does the same thing for the same reason.

**Fix.** The rows now always write with `EPropertyValueSetFlags::NotTransactable`, so no
transaction is opened on that path and none can be left open. This is correct
independently of the leak: the target is a transient throwaway draft proxy, never the
document. The undoable step is the Apply commit, which transacts the document itself
under its own `FScopedTransaction`.

Nothing is lost by opting out. The proxy is created `RF_Transient` and is not
`RF_Transactional`, so `Modify()` on it records nothing, and `UTransBuffer::End` pops the
finished transaction as `IsTransient()` regardless. The old flags bought an empty
transaction that was discarded — and a dangling one that was not.

**Guards.** Two, because the defect spans two layers.

- `Nexus.V7.Module.UiMutationBoundary` now requires that any NexusEditorUI file calling
  `SetValueFromFormattedString` names `EPropertyValueSetFlags::NotTransactable`. The
  existing forbidden-string list catches a widget that opens a transaction itself; it
  could not see one the property editor opens on the widget's behalf.
- `Nexus.V7.Details.UndoAfterAutosave` asserts the user-visible behaviour: an autosaved
  edit is one undoable step that round-trips through `GEditor->UndoTransaction()` and
  `RedoTransaction()`, the repository's read path serves the restored value after
  `RebuildIndex()`, and `GEditor->IsTransactionActive()` is false either side of it.

**Proven.** The fix was reverted and the suite re-run. `Nexus.V7.Module.UiMutationBoundary`
failed with *"NexusDetailsCustomization.cpp writes the draft proxy with NotTransactable,
or undo dies the first time an edit is abandoned"*. Restored and re-verified.

**Not covered.** The customization sits behind Slate and cannot be typed into headlessly,
so no automated test presses Escape in a real text box. The source-level guard stands in
for that; E3 checklist item 5 still needs a human at the keyboard.

---

## Verification

```
PASS: clean build NexusFrameworkEditor-Win64-Development
PASS: clean build NexusFramework-Win64-Development
PASS: clean build NexusFramework-Win64-Shipping
PASS: Nexus.V7.Details - 23 results
PASS: Nexus.V7.Module - 12 results
PASS: 101 tests, 0 failures
PHASE 06 DETAILS: PASS
```

## Also fixed in passing

A unity-build collision: `SNexusDetailsPanel.cpp` and `SNexusHierarchyTree.cpp` both
declared `GetSubsystem()` in an anonymous namespace. Anonymous namespaces do not
separate translation units that a unity build has merged into one. Renamed to
`GetDetailsSubsystem`.

A queued post-undo refresh is now cancelled in `Deinitialize` rather than left to fire
against a torn-down subsystem.
