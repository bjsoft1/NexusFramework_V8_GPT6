# Bug — the document never looked like it needed saving, and could not be saved

1. [X] The dirty marker was 8pt muted grey — present, and not visible.
2. [X] `Nexus.Document.Save` was reachable from the command palette and nowhere else.
3. [X] The Details footer named `Ctrl+S`, which does not save the Nexus asset.

Reported by the user 2026-08-27 against the Phase 07 build: *"when i made any changes,
i cannot see the dirty in editor and editor not showing dirty or save, the editor not
tracking maybe it has some changes and need to save."*

All three fixed the same day. `PASS: 122 tests, 0 failures` via
`Scripts/VerifyPhase07Crud.ps1` on three clean builds, `FOUNDATION STRUCTURAL SCAN:
PASS`, 125/125 across all of `Nexus.V7`.

---

## The flag was never the problem

Worth stating first, because the report reads like a tracking bug and it is not.

| Path | What it does |
|---|---|
| Entity mutations — `CommitCandidate`, [NexusEntityCommands.cpp:483](../../Plugins/NexusFrameworkV7/Source/NexusEditor/Private/NexusEntityCommands.cpp#L483) | `FScopedTransaction` + `Modify()` + `MarkPackageDirty()` |
| Details Apply — `ExecuteApply` | Same |
| Activation points | Same |
| `FNexusDocumentStore::IsDirty` | Reads `UPackage::IsDirty()` |
| Shell state | `FNexusEditorShellStateProvider` reads the same flag every paint |

`Nexus.V7.Crud.DocumentLifecycle` asserts the flag goes true after a mutation and it
passed throughout. Unreal's Content Browser asterisk worked throughout. Everything
between the flag and the user was broken instead, in two independent ways.

## 1. The marker was the least visible thing in the shell

`GetDirtyText` returned `UNSAVED`, drawn in `Nexus.Text.Caption`:

```cpp
Style->Set(TEXT("Nexus.Text.Caption"), MakeText(8, TEXT("Regular"), Palette.TextMuted));
```

**8pt, `TextMuted` (#8593A4)** — the smallest size and the lowest-contrast colour the
palette defines, sitting on `SurfaceSunken`. It passes the contrast test, and it was
still the thing a reader's eye reaches last on a strip that until this week also
carried the full document sentence, a workspace combo button, and a palette button.

Now `Nexus.Text.BodyStrong` in `Palette.Dirty` amber, with a tooltip that says where
the changes are and what "unsaved" means here.

**Passing a contrast threshold is not the same as being noticed.** The palette test
holds body text to 4.5:1 and this cleared it. Prominence is a separate property and
nothing measures it.

## 2. Save Document existed, worked, and could not be found

Registered in the catalog with `.In(Authoring, File)`, eligible, listed in the
palette. Where it was not:

- **The toolbar** — `GetToolbarCommands` was Refresh, Validate Document, Show
  Diagnostics.
- **`Window > Nexus Framework V7`** — `GetWindowMenuOrder` is the ten entries
  V7-UX-SPEC.md §3.1 fixes, and Save is not one of them.
- **The row context menu** — `GetRowContextMenuCommands` draws the `Create`, `Edit`,
  and `Context` groups. Save is in `File`.
- **Any keyboard chord** — §16's chord table defines none, and the catalog gives it
  no `.Shortcut`.

So the only route was `Ctrl+Shift+P` and knowing the words "Save Document". Meanwhile
every edit marks the package dirty and writes nothing, by design — V7-UX-SPEC.md 12.1
— so the need to save is permanent and the route to it was invisible.

Third instance of [[declared-is-not-reachable]] in this project, and the worst,
because the unreachable command was the one that protects the user's work.

**Two routes now.** A **Save** button beside the dirty marker in the context strip,
on all three tabs because §3.3 puts the strip on all three, and visible only while
the document is dirty — which is exactly when `GuardSave` considers the command
eligible, so the control is never present-and-refusing. And **Save Document** leads
the Hierarchy toolbar. Both go through `OnRunCommand`.

This is not the chrome duplication closed in
[shell-chrome-and-density.md](shell-chrome-and-density.md). That was one transient
message rendered three times with three Dismiss buttons. This is a per-document,
persistent state the spec already requires on every tab, made actionable where it is
already shown.

## 3. The footer named a keystroke that does not do it

Mine, from earlier the same day. Fixing the old `"Saved"` wording, the replacement
read `"Applied — Ctrl+S saves the asset"`. The shell is a **nomad tab**, not an asset
editor: `Ctrl+S` there is Unreal's level save. The line was false the moment it was
written, and the same false instruction went into `phases/phase-07.md` step 3.

Now `"Applied — the asset is not saved yet"`, naming no chord. **A fix for a
misleading string can ship a second misleading string**; the replacement needs the
same check the original failed.

## The guard, proven by unwiring

`Nexus.V7.Shell.SaveIsReachable` asserts the toolbar list contains Save Document,
then builds a real context strip against a dirty document, walks its tree for the
button, and **clicks it** via `SButton::SimulateClick`, checking which command id
comes back. Reverted `HandleSaveDocument` to a bare `return FReply::Handled()` and
re-ran before claiming it works:

```
Expected 'the context strip's Save control runs a command' to be true.
Expected 'and the command it runs is Save Document' to be Nexus.Document.Save, but it was None.
```

A builder-level test would have passed against a button wired to nothing, which is
the exact failure mode this class of bug keeps taking here.

It also asserts the control is **not** offered against a clean document.

## Not covered

Whether the marker now reads as noticeable is a person's judgement. E3 check 16
covers it, together with the Content Browser asterisk and `File > Save All`, which
were never broken but are worth confirming beside the shell's own indicator.
