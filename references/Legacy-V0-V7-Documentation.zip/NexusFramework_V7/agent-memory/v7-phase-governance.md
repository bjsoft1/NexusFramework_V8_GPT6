---
name: v7-phase-governance
description: An AI may never mark a V7 phase Complete or Ready for Manual QA; only independent review and the user can advance those states.
metadata:
  type: project
---

Nexus Framework V7 runs a strict 20-phase gate model defined in
`project-specifications/V7-QUALITY-GATES.md`. The implementing AI may set only
Not Started, In Progress, Blocked, Reopened, or Ready for Review. An independent
review (E0) moves accepted work to Ready for Manual QA. Only the user moves a
phase to Complete, and only after the manual evidence for that phase passes.
`project-specifications/PHASE-STATUS.md` is the single authoritative ledger; the
Status heading in each phase file is a mirror of it.

**Why:** V0–V6 failed partly because implementation claims were accepted as
evidence. The gate model exists so that "it builds and the tests pass" can never
be mistaken for "this phase is done." Phase 09 and every later backend phase are
blocked by dependency until the Phase 08 UI gate is Complete.

**How to apply:** Never edit a status to Complete or Ready for Manual QA on your
own initiative, and never start a phase whose dependency phase is not Complete.
Advance work to Ready for Review, record evidence under
`project-specifications/evidence/` naming the exact command, result, and
artifact, then ask the user for the acceptance decision. Because Phase 01 was
implemented by ChatGPT, a Claude session is a legitimate independent E0 reviewer
for it — but not for its own work. See [[phase-01-e0-outcome]].

**Completion handoff:** Every finished phase or sub-phase must give the user five
or six short UI verification steps, each naming what to click or press and the
visible expected result. Include exact paste-ready fixture/setup console commands
when needed, mirror the checklist in the phase and evidence documents, and state
clearly when the latest source has not yet been built or tested. This is guidance
for re-running the work, not a substitute for E0-E4 evidence or status authority.
