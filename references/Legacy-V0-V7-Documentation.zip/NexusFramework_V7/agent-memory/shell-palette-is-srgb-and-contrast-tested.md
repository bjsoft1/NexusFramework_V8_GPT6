---
name: shell-palette-is-srgb-and-contrast-tested
description: Nexus shell colours are defined from sRGB hex via FromSRGBColor so WCAG contrast is computable, and automation holds the palette to it.
metadata:
  type: project
---

Every colour in `NexusStyle::FNexusPalette` is written as sRGB hex and converted
with `FLinearColor::FromSRGBColor`. New UI colours in Phases 04-08 must be added the
same way and added to `Nexus.V7.Shell.PaletteContrast`, which holds body text to
4.5:1 and every state or severity colour to 3:1 against all three surface tokens.

**Why:** `FLinearColor` stores linear values, and WCAG relative luminance is defined
over linear channels — so contrast is only computable when the stored value is
genuinely linear. Writing `FLinearColor(r / 255.0f, ...)` puts sRGB numbers into a
linear field: the colour renders roughly twice as dark as intended and every
measured ratio is wrong while still looking plausible. Defining the palette from hex
makes the rendered result match the intended design *and* makes the measurement
honest. This is what turns "readable contrast", otherwise a manual E3 judgement, into
an E2 assertion.

Hairline borders and separators are deliberately excluded from the contrast test.
WCAG 1.4.11 covers visual information needed to identify a component or its state,
and Nexus identifies state with a shaped glyph plus text, never with a border.

**How to apply:** Add the colour to the palette struct as `FromHex(...)`, then add
the pairing to the test's list. If a new colour cannot reach its ratio, change the
colour — do not lower the threshold or add an exception. Glyph shape must keep
carrying the same meaning the colour does, so the shell stays readable without
colour vision. See [[verify-claims-by-re-running]] and
[[command-service-is-the-only-mutation-path]].
