---
name: a-document-must-not-lose-unrelated-work-on-a-scoped-command
description: Revert Draft's preview named only the selected entity, but its implementation reset every parked draft in the document as a side effect — a command's blast radius must match what its own preview promised, not exceed it silently.
metadata:
  type: feedback
---

`FNexusDetailsView::Revert()` (F-08-16) reverted the currently selected target and
then unconditionally called `KeptDrafts.Reset()` — discarding every unrelated,
still-unapplied draft parked elsewhere in the document as an undocumented side
effect. `RevertDraft`'s own confirmation preview only ever named the currently
selected entity, so the destructive-confirmation gate this project built specifically
to make "the preview describes what will happen" a guarantee
([[destructive-previews-do-not-belong-in-eligibility]]) was quietly violated by the
handler behind it: what ran did strictly more than what was confirmed.

**Why:** A destructive command's preview is the contract. If a handler's actual
effect can exceed what its own preview enumerates, the preview stops being trustworthy
even when its wording is accurate about the part it does mention — the user approved
a smaller blast radius than the one that fired.

**How to apply:** When a command handler touches state beyond `Context.Selection` /
`Context.Primary` (a cache reset, a global reindex, a "while I'm here" cleanup),
either name that wider effect in the preview or don't do it in the handler for the
narrow command — give it its own explicitly-named operation instead
(`DiscardKeptDrafts()` is that operation here). Grep a handler for resets/clears on
shared containers as a matter of course when reviewing anything gated by
`CheckConfirmation`.
