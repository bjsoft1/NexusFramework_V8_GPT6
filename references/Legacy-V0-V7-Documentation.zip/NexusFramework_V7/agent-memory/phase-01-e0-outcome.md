---
name: phase-01-e0-outcome
description: Phase 01 passed independent E0 verification of its builds and tests but was not accepted; two Blocking findings against the frozen runtime schema remain open.
metadata:
  type: project
---

The independent E0 review of Phase 01 was completed on 2026-08-22 and recorded in
`project-specifications/evidence/phase-01-e0-independent-review-2026-08-22.md`.
Builds, the 21-test Foundation suite, the structural scan, and the Shipping-link
module boundary were all re-executed and reproduced. The phase was **not**
accepted. Two Blocking findings stand against the runtime schema Phase 01 freezes:

- **F-01** — validation requires every compiled record's bounds to be valid and to
  fit inside its assigned cell, so a `World`/`State`/`City`/`Highway` record whose
  extent spans cells has no legal `CellIndex`.
- **F-02** — canonical order is cell-major, yet `ParentIndex` must reference a
  preceding record; a parent whose cell sorts after its child's cell cannot be
  represented at all.

**Why:** These are not code bugs. They are gaps in a contract Phase 01 exists to
freeze, and multi-Landscape plus World Partition — both non-negotiable — make
cross-cell parents the ordinary case rather than an edge case. Discovering this at
Phase 16 would reopen Phase 01 and every phase built on the compiled contract.

**Resolved the same day** on the user's instruction. `V7-ARCHITECTURE.md` §10
"Cell assignment and hierarchy ownership" now decides all three rules: a record
belongs to the cell whose `Coordinate` equals `floor(origin / CellSize)`; a cell's
stored `Bounds` is loose, must cover its records, and may exceed its own partition
box; and ownership is validated as an acyclic graph, not by record position.
`NexusRuntimeDataset.cpp` enforces them, and the fixture now covers a cross-cell
`City` owner whose cell sorts after its child's.

**How to apply:** Do not treat Phase 01 as done and do not start Phase 02 yet.
Phase 01 stays at Ready for Review because the reviewer authored the remediation,
and an agent may not certify its own work — see [[v7-phase-governance]]. It
advances only on the user's acceptance or a second independent pass. Two forward
items survive: Phase 16 must fix one canonical formula for a cell's stored bounds
(validation enforces only containment), and broad-phase queries must treat cells
as overlapping volumes rather than a disjoint grid.
