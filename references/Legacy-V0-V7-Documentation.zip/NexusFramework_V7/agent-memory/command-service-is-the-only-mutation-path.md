---
name: command-service-is-the-only-mutation-path
description: All Nexus authoring mutations go through INexusCommandService; UI reads through INexusRepository and never touches assets directly — and only the subsystem's ExecuteCommand refreshes the views, so calling the service directly mutates correctly and updates nothing on screen.
metadata:
  type: project
---

Phase 02 established two seams in `NexusEditor`:

- `INexusCommandService` (`NexusCommandService.h`) is the only public mutation API.
  Commands are addressed by stable `FName`, registered at module startup, and
  implement `INexusCommandHandler` with a `CanExecute`/`Execute` pair.
- `INexusRepository` (`NexusRepository.h`) is the only read seam. It resolves
  entities by ID, returns copies, and broadcasts `OnChanged` with a refresh hint
  plus the changed IDs.

`UNexusEditorSubsystem` owns the repository, exposes both seams, and builds the
command context from the active document and selection via `MakeCommandContext()`.

**Executing a command does not refresh anything.** `INexusCommandService::Execute`
mutates and returns a `RefreshHint`; the only code that acts on that hint is
`UNexusEditorSubsystem::ExecuteCommand`, which calls
`Repository.NotifyChanged(Hint, ChangedIds)`. That broadcast is the single signal
`FNexusHierarchyView`, `FNexusDetailsView`, and the shell state provider have. Call
the service directly and the mutation is correct, the revision advances, every
assertion about the document passes, and no view on screen moves. Phases 04–07
shipped that way: the shell ran every command on the service, so a Delete emptied
the document while the tree kept drawing the rows it had removed. Fixed 2026-08-24
by adding `ExecuteCommand(FName, const FNexusCommandContext&)` — the shell needs its
own context, because that is where the invoking surface and a destructive command's
approval live — and routing `FNexusEditorUIModule` through it.

**Why:** V7-ARCHITECTURE.md section 7 makes this a product boundary, not a style
preference. Widgets that mutate assets directly were a recurring V0–V6 failure, and
because such code still compiles, the rule needs a test rather than a convention.
`Nexus.V7.Module.UiMutationBoundary` scans `NexusEditorUI` sources and fails if it
finds `FNexusActivationPointCommandService`, `FScopedTransaction`, or `->Modify()`.
The same test now also fails a `NexusEditorUI` file that reaches
`FNexusCommandService::Get().Execute(` more than once, or that reaches it at all
without also naming `Subsystem->ExecuteCommand(` — going around the subsystem
compiles and behaves correctly right up to the point where the screen should update.

**How to apply:** When adding a feature, write a command handler and register it in
the owning module's `OnNexusModuleStartup`, unregistering it in
`OnNexusModuleShutdown` — `UnregisterCommand` is ownership-checked, so a module
cannot remove a registration it does not own. Never call
`FNexusActivationPointCommandService` from UI code. `Execute` must re-check
`CanExecute` itself: UI eligibility is advisory, and a script or shortcut has to hit
the same guard. A handler that refuses without a blocking diagnostic still fails,
because the service supplies `Nexus.Command.NotEligible` rather than letting a
refusal read as success. See [[v7-phase-governance]] and
[[verify-claims-by-re-running]].
