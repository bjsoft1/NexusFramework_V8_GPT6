---
name: measure-at-the-reachable-size
description: A budget measured only at the size the spec names passes while the same code hangs the editor at the size a command can actually be handed.
metadata:
  type: feedback
---

Every V7 responsiveness budget names a size — "1,000 selected items", "10,000 loaded
rows", "100,000 indexed entities". Measuring at exactly that size is necessary and is
not sufficient. For each budget, ask separately: **what is the largest input a user
can produce through a command that ships?** Measure that too.

Phase 08 found this the expensive way. Section 19 budgets a 1,000-item multi-selection
at 300 ms; V7 answered in 13.7 ms, a 22x margin. Underneath, three paths on the
selection route deduplicated or tested membership with a linear scan. Select All
Visible is a Phase 05 command bound to a chord, and it hands the whole tree to all
three at once — about five billion comparisons each on the 100,000-row reference tree.
An editor that stops responding on a keystroke, shipped, behind a very green test.

The same pass found four sort tie-breakers formatting two GUIDs into strings per
comparison (~3.4 million allocations to sort the reference tree) and a row filter
building four strings per row before checking which the query needed. Both read as
ordinary code and are free at the sizes the other suites use.

**Why:** the size in a budget is the size the spec author chose to write down. It says
what is acceptable; it says nothing about what is reachable. A per-element allocation
or a linear `AddUnique` is not a smell until something multiplies it by the reference
scale, and no test does that for you unless one is written to.

**How to apply:** when a gate item claims a number, find the assertion that holds that
number — if none names it, it is unmeasured however many green tests surround it, and
a passing test that *disclaims* being the measurement is invisible from the test list.
Then add the reachable-size case alongside the spec-size one. `Nexus.V7.UiGate` is the
pattern: each test names the exact spec line, asserts against that number rather than
one chosen to pass, and appends its measurement to a dated, digested artifact. When a
budget is genuinely missed and the fix would change a frozen contract, leave the test
failing with a message that names the missing mechanism — see
[[v7-phase-governance]] and [[declared-is-not-reachable]].
