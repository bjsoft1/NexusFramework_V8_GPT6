---
name: a-cross-cutting-fix-built-on-a-per-path-artifact-inherits-that-path
description: F-08-16 fixed the "Completed" Activity bug by reusing the confirmed preview, which only destructive commands build, so it silently covered only them; F-08-19 rebuilt it on Result.ChangedIds, which every command carries.
metadata:
  type: reference
---

**The shape.** F-08-16 fixed "a successful command leaves Activity with just the
word *Completed*" by making `FNexusCommandService::Execute` reuse the *confirmed
preview* to write the message and target summary. Only a **destructive** command
ever builds a confirmed preview, so the fix silently covered destructive commands
only — while `phase-08.md` and `PHASE-STATUS.md` prose read as if the whole
problem were closed. The E0 review caught it as E0-02. A cross-cutting fix built
on a value that only some code paths produce inherits that condition; check what
produces the artifact you are reusing before claiming the fix is general.

**F-08-19's fix.** A new `SummariseSuccessfulCommand` (anon namespace,
`NexusCommandService.cpp`), called for the success branch that previously wrote
nothing, builds the record from what *every* result carries:

- `Result.ChangedIds` resolved against the live `Context.Document` to
  `"DisplayName (Kind)"` — named when 3 or fewer, `"N item(s)"` past that (the
  same threshold F-08-16's `DescribeConfirmedTarget` uses). Message is
  `"<Label>: <entities>."`, target summary is the entity list.
- else `RefreshHint::Document`, or the `DocumentId` sitting in `ChangedIds` →
  `"<Label>: the active document."` / `"the active document"`.
- else (a Phase 05 view-only command, a valid no-op) → `"<Label>."`, no target.

The document pointer is `::IsValid`-checked first: Close and Reload can leave
`Context.Document` aimed at an object the command just replaced.
`FNexusOperationHistory::Complete` still owns the bare-`"Completed"` fallback for a
direct caller, but the service success path no longer reaches it. No field was
added to `FNexusCommandResult`.

So: a new command needs no per-handler wiring to get a readable Activity row —
populate `ChangedIds` and `RefreshHint` on the result (which `ToCommandResult`
already does) and the row describes itself. See
[[command-service-is-the-only-mutation-path]] and [[verify-claims-by-re-running]].
