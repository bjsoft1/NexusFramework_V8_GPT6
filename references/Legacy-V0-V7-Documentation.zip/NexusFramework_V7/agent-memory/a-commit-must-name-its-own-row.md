---
name: a-commit-must-name-its-own-row
description: A deferred UI commit resolved against the current selection writes to whatever the user clicked next, and the tests that would catch it are the ones nobody writes.
metadata:
  type: feedback
---

Any editor that commits **later than the interaction that filled it** must carry the
identity of what it was editing. Resolving the target from the selection at commit
time is wrong, because the gesture that ends the edit is usually the gesture that
moves the selection.

Inline rename is the canonical case and shipped broken in V7 until 2026-08-28. An
`SInlineEditableTextBlock` commits its text when it loses keyboard focus. Clicking
another row moves the selection *first*, so `ExecuteRename` — which read
`Context.Selection` — applied the name typed into one row to the row that was clicked.
When the two were siblings it refused with `Nexus.Authoring.NameCollision`, naming a
row the user had never edited. When they were under different parents **it succeeded
silently**, with an undo step indistinguishable from a deliberate rename.

**Why the suite was green.** Every rename test set the selection to the row it was
renaming, which is the one arrangement in which selection and target agree. The test
that finds this is the one that deliberately puts the selection somewhere else — and
that is not an exotic case, it is what happens whenever an edit ends with a click
rather than with Enter, which is most of the time. A generated default name that is
already unique makes it more likely still, because accepting the offered name by
clicking away becomes the commonest thing a user does with a new row.

**How to apply:** when a command can be invoked by a deferred commit, give it a target
that does not come from live selection state. In V7 `FNexusAuthoringView` already
tracked the rename target and nothing cleared it on a selection change, so the fix was
to ask the view and let the selection be only the fallback for the no-editor-open case.
Widen the guard at the same time — the same click can clear the selection entirely, and
a guard that refuses "select something first" for text the user has already typed is
the same bug wearing a politer message. Add the widget-side check too: a row that is
not the live target must not commit at all, because a list rebuild can outlive the
editor that opened. Related: [[declared-is-not-reachable]] and
[[command-service-is-the-only-mutation-path]].
