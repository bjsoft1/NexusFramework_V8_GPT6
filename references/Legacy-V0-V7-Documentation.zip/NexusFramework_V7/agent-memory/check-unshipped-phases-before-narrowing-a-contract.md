---
name: check-unshipped-phases-before-narrowing-a-contract
description: The unshipped phase docs are the spec for a contract you are about to narrow, and they name owners for things that look like dead code.
metadata:
  type: feedback
---

Before narrowing a shared contract — an enum, a legality rule, a registry — read
`project-specifications/phases/*.md` for **every phase that has not started**, not
just the phase that owns the contract today. Two different things come out of it, and
both change the work.

**They are often already written against the shape you are moving to.** Narrowing the
entity ladder to State > City > Highway > Highway Point on 2026-08-28 looked like a
redesign until three unstarted phases turned out to assume exactly it: phase-16
compiles "canonical State/City/Highway/HighwayPoint records"; phase-11 lists junctions
and lanes *beside* those four as graph attributes rather than as rows; phase-09 and
phase-12 treat junctions purely as landscape topology. That turned a contract change
into a narrowing, and it is the difference between reopening downstream phases and
not.

**They name owners for things that read as dead code.** `ENexusEntityKind::SubPoint`
was about to be cleaned up along with its `NexusRuntimeDataset` payload carve-out.
`phases/phase-14.md` lists "sub-points" as an Activation Point deliverable, so both
had an owner and a date. The grep that finds a symbol unused in shipped code cannot
see the phase that is going to use it.

**Why:** an unstarted phase doc is a specification that no code satisfies yet, so
nothing in the build points at it and no test fails when you contradict it. It is
invisible to every tool that would otherwise catch the mistake. `TASK-LIST.md` also
makes this expensive after the fact: "a changed architectural contract reopens the
owning checkpoint and every affected downstream phase."

**How to apply:** grep the phase docs for the domain nouns, not for the symbol —
`junction`, `sub-point`, `highway point` found all of this; `ENexusEntityKind` found
none of it. Then check where in the phase order the change lands: Phase 08's own scope
is "integrated audit and correction of Phases 03–07" *and* "freeze of UI/service
contracts consumed by later systems", so a correction is cheap before that freeze and
a break after it. When a kind or value must leave a contract, **retire it rather than
delete it** — removing a value from a serialized `UENUM` reindexes it and silently
changes the meaning of records already on disk. See [[v7-phase-governance]] and
[[command-service-is-the-only-mutation-path]].
