# 2026-08-27 — Shell chrome scoped, and who writes the asset

Closes [`shell-chrome-and-density.md`](../../agent-todos/ready-for-review/shell-chrome-and-density.md)
(all four) and [`save-and-dirty-ownership.md`](../../agent-todos/ready-for-review/save-and-dirty-ownership.md)
(all three). Both files carry the full write-up; this records what was learned.

`PASS: 122 tests, 0 failures` on three clean builds via `Scripts/VerifyPhase07Crud.ps1`,
`FOUNDATION STRUCTURAL SCAN: PASS`, 124/124 across `Nexus.V7`. Re-run per
[[verify-claims-by-re-running]].

## Shared construction was read as identical content

`SNexusShellSurface::Construct` built the same seven-slot column for every surface,
with no branch. The class comment gave the reason — the three surfaces share the frame
"so they cannot drift apart visually" — and that reason is sound for *construction*
and was never a reason for the same *content*. Three open tabs meant three toolbars,
three notification lists, and three copies of every banner, each with its own Dismiss,
any one of which cleared all three.

The fix is `FNexusSurfaceChrome::For(Surface)`: three booleans resolved once at the top
of `Construct`. Keeping the shared builder and giving it per-surface rules was the
whole change; the alternative — a second widget class per surface — is how V0–V6 grew
three palettes.

**The general shape: a comment that justifies a mechanism will be read as justifying
everything the mechanism happens to do.** If the reason only covers half, say which
half in the comment.

## `InvokedFrom` names the control, not the panel

The handover said `FNexusCommandContext` already carried the invoking surface. It does
not. `InvokedFrom` is `"Surface"`, `"CommandPalette"`, `"CommandList"`,
`"StatusAction"`, `"Confirmation"` — the control, and every one of the three surfaces
passes the same `"Surface"`. `WorkspaceState.FocusedSurface` was no better: it moves
only when the module raises a tab itself, never when the user clicks into one.

Worth knowing generally: **`FName` tags that read like an origin usually name a
mechanism.** The module now tracks `ActiveSurface`, set from tab activation (before its
focus guard — the user has moved there whether or not the module touches focus), from
the surface's own `OnRunCommand`, and from `FocusSurface`.

The origin is applied by a **scope**, not a parameter on `Post`. A command handler may
post its own message — `Nexus.About` does — and an argument would mean the handler
that forgot went back to appearing on all three tabs. Same reasoning as
[[command-service-is-the-only-mutation-path]]: put the rule where forgetting is
impossible, not where remembering is required.

## Removing a write invalidated a guard that read its side effect

`FNexusDocumentStore::Create` no longer saves the package, per V7-UX-SPEC.md 12.1. Its
already-exists guard was two disk checks, `DoesPackageExist` and `FileExists`, and both
stopped covering the case the moment the write went: a second New Document under the
same name finds nothing on disk, gets the existing **in-memory** package back out of
`CreatePackage`, and constructs a second asset over the first one's name. `FindPackage`
is the third check now.

The same assumption sat in a second place, and it would have been a regression shipped
by the fix for the first: `ExecuteNewDocument`'s unique-name loop skipped a candidate
only if `DoesPackageExist` found it on disk, so a second **New Document** in one session
would regenerate the first one's name and be refused by the guard above.

**A guard that reads a side effect of an operation is only as good as that operation.**
Recorded here because it will recur: this codebase has several checks that stand in for
state by looking at what a write left behind — and when you remove a write, look for
every one of them, not just the one the test caught.

## `PromptForCheckoutAndSave` cannot be used headless

The obvious call for "save through Unreal's path" is
`FEditorFileUtils::PromptForCheckoutAndSave`. It **returns `PR_Cancelled` without
saving anything** under `FApp::IsUnattended()` when `bAlreadyCheckedOut` is false —
`FileHelpers.cpp:4664`. Every headless run, automation included, reports a cancelled
save. The first build with it failed `Nexus.V7.Crud.DocumentLifecycle` exactly that way.

`UEditorLoadingAndSavingUtils::SavePackages` is what that function's own unattended
branch falls back to: source-control checkout when SCC is enabled, mark-for-add for a
newly created file, the same `InternalPromptForCheckoutAndSave` with `bUseDialog =
false`, and no prompt at all. That is the one to reach for from a surface that may not
open a dialog.

## A name that would have regrown the bug

The Details footer said `"Saved"` when nothing had been written. The string was the
reported defect; the enum behind it was `ENexusDetailsAutosaveState::Saved`, and
leaving that name would have regrown the same label the next time someone wrote one
from it. Renamed to `Applied` across all 24 references. No test had to be loosened —
all six read the enum, none the literal.

Same family as the `FName`-case bug in
[the previous log](2026-08-24-confirmation-popup-and-refresh.md): **the layer that
names a state decides what every layer above it will say about it.**

## The guard, proven by reverting

`Nexus.V7.Shell.ChromeIsNotRepeated` counts widgets by type across all three surfaces
(`NexusShell::CountSurfaceWidgetsOfType`). Reverted both fixes and re-ran before
claiming it works — `to be 1, but it was 3`, twice. Nothing counted shared chrome
across surfaces before, which is precisely how three copies shipped with every
per-surface assertion green. Another instance of the shape in
[[declared-is-not-reachable]], turned around: each piece was correct, and the defect
was only in how many of them there were.

## Not covered

Whether a panel reads as clean is a person's judgement. Source-control checkout and
Unreal's close-the-editor save prompt need a real SCC provider and a real editor
session. All of it is E3 checks 14 and 15 in
`project-specifications/evidence/phase-07-e3-manual-checklist-2026-08-24.md`,
written to be run with all three tabs open at once — the only configuration in which
the original report is visible.

---

# Later the same day — the document never looked like it needed saving

Closes [`dirty-and-save-affordance.md`](../../agent-todos/ready-for-review/dirty-and-save-affordance.md).
`PASS: 122 tests, 0 failures`, 125/125 across `Nexus.V7`.

## A correct flag with nothing between it and the user

Reported as *"the editor not tracking maybe it has some changes and need to save"*,
which reads like a state bug and was not one. `Modify()` + `MarkPackageDirty()` on
every mutation, `UPackage::IsDirty()` read every paint, `DocumentLifecycle` asserting
it, Unreal's own asterisk working. Two separate presentation failures:

1. `UNSAVED` was drawn in `Nexus.Text.Caption` — 8pt `TextMuted`, the smallest size
   and lowest-contrast colour the palette defines. It **passes** the contrast test.
   **Passing a contrast threshold is not being noticed**, and nothing measures the
   difference. Worth carrying into any future palette work.
2. `Nexus.Document.Save` was reachable from the command palette and nowhere else —
   no toolbar entry, none of §3.1's ten Window-submenu entries, not the row context
   menu (which draws Create/Edit/Context, and Save is in File), no chord.

**When a report names a mechanism ("not tracking"), check the mechanism first and
then check every layer above it.** The user's diagnosis was wrong and their
observation was exactly right; both halves matter.

## The worst kind of unreachable command

Third instance of [[declared-is-not-reachable]] here, and the one with teeth: the
command that could not be found was the one that protects the user's work, against a
design where every edit marks dirty and writes nothing on purpose (12.1). The two
facts are individually correct and jointly a data-loss trap.

**A deliberate "we never write silently" decision creates an obligation to make
writing obvious.** That obligation was never written down anywhere, which is why
nothing caught it.

## A fix for a misleading string shipped a second misleading string

The `"Saved"` → `"Applied — Ctrl+S saves the asset"` change from earlier the same day
was wrong: the shell is a nomad tab, so `Ctrl+S` is Unreal's level save. The same
sentence had gone into `phases/phase-07.md`. It names no chord now.

**A replacement string needs the same scrutiny the original failed** — the instinct
after finding one lie is to write something confident, and confidence is what made
the first one a problem.

## Guard

`Nexus.V7.Shell.SaveIsReachable` builds a real strip against a dirty document and
**clicks the button** (`SButton::SimulateClick`), asserting the command id that comes
back. Proven by unwiring `HandleSaveDocument` first — a builder-level test would have
passed against a button connected to nothing.

---

# Later still — a new document could not be authored, and V6's config asset

Closes items 1 and 2 of
[`empty-tree-cannot-author.md`](../../agent-todos/ready-for-review/empty-tree-cannot-author.md).
`PASS: 122 tests, 0 failures`, 126/126 across `Nexus.V7`.

## Collapsed is not hidden — it is gone

`SNexusHierarchyTree` collapsed its `SListView` whenever it had no rows and drew a
state message in its place. **A collapsed widget receives no mouse events**, and
Create lives in the list's right-click menu, so a brand-new empty document had no
surface a right-click could land on. From zero, nothing could be made.

**`EVisibility::Collapsed` on a container removes an interaction, not just some
pixels.** Worth checking anywhere this codebase toggles a container by visibility to
show an alternative — the alternative inherits the space and not the behaviour. The
Content Browser and World Outliner keep their list live and draw the empty message
over it; an `SOverlay` with `SelfHitTestInvisible` on the panel is the shape.

`SelfHitTestInvisible` excuses only the container. Child `STextBlock`s need
`HitTestInvisible` of their own or they eat the click the list underneath needs.

## The willing layer and the unreachable one, again

`FNexusAuthoringView::GetLegalCreateKinds` had handled the empty case since it was
written, with a comment saying an empty document has to be startable from somewhere.
World and State are legal at the root. Every test of Create passed — all of them ran
against a selection.

Fourth instance of [[declared-is-not-reachable]] this week. The recurring shape is
now unmistakable: **this project's failures are almost never in the rule, and almost
always in whether any gesture reaches it.** A guard that calls the rule is worth
little here; one that builds the widget and presses it is worth a lot.

## One bug forcing the other

The user's second report — no asset, no dirty state — was a *consequence* of the
first. The empty-tree bug forced them onto `Nexus.Fixture.LoadSample`, and a fixture
lives in the transient package where `MarkPackageDirty` does nothing, so `IsDirty` is
false however much is edited. The strip drew empty space and gave no reason.

**When two reports arrive together, check whether the first one's workaround produces
the second.** It cost a while to see that the fixture was not incidental context but
the cause.

Now `IN MEMORY - NO ASSET` in `Stale` purple — deliberately not the `Dirty` amber,
because amber promises work that can be saved and this is the one state where none
can be.

## A message with an expiry date

`StateNoDocument` read *"Phase 07 delivers the authoring entry point that opens one"*,
and a test asserted the string `Phase 07` was present. True when written; false the
day Phase 07 shipped; and the test kept it that way.

**A user-facing string that names a future phase is a lie with a scheduled start
date, and a test asserting it is a lock on the lie.** The catalog's "this command
arrives in Phase N" refusals are the legitimate case — they describe something that
has genuinely not shipped and are regenerated from the catalog. A hand-written one in
a view is not. Both now name the command instead.

## V6's per-map config asset — answered, not fixed

V6 auto-created `Content/NF/Maps/<MapName>/NexusConfig.uasset` next to the level.
V7 does not, on purpose twice over: `V7-ARCHITECTURE.md` replaced convention-based
discovery with an explicit `ANexusWorldAnchor` so that *"discovery never chooses the
first asset or first Landscape it happens to find"*, and `phases/phase-10.md` owns
"Automatic world-config discovery/creation" with Phase 10 not started.

Recorded here because the question will be asked again by anyone who used V6: **the
answer is a phase-scope answer plus an architecture decision, not a defect**, and
reinstating V6's behaviour would reopen Phase 01.
