# 2026-09-02 — F-08-17: Undo/Redo scoped, and a live widget fighting the test

The E0 review run earlier the same day ([[a-document-must-not-lose-unrelated-work-on-a-scoped-command]]'s
log) filed E0-01: `UNexusEditorSubsystem::RefreshAfterUndo` — run after every
successful Undo/Redo — discarded every unsaved Details edit in the document,
including parked drafts with nothing to do with the transaction being undone. Same
defect shape as F-08-16's `Revert()` bug, in a path that fix never reached because
native engine undo bypasses `CheckConfirmation` entirely.

**Production fix, one line.** `RefreshAfterUndo` called `Repository.NotifyChanged(Hierarchy,
{})` and then, redundantly, `FNexusDetailsView::Get().ReloadFromSource()`.
`NotifyChanged` alone already broadcasts synchronously to
`FNexusDetailsView::HandleRepositoryChanged`, which parks and reclaims a dirty
currently-selected draft exactly like every other repository-driven refresh in the
product. `ReloadFromSource()` unconditionally resets `KeptDrafts` with no reclaim
step of its own, undoing what the first call had just done correctly. Deleted the
second call.

**The regression test then failed twice, for reasons that had nothing to do with the
fix.** First attempt set selection via `FNexusDetailsView::Get().SetSelection(...)`
directly; second attempt switched to the "correct" `Subsystem->SetSingleSelection(...)`
API. Both failed identically: `GetDirtyTargetCount()` read 0 and `GetKeptDraftCount()`
read 2 right after `RefreshAfterUndo()`, as if the fix hadn't worked. Temporary
diagnostic `UE_LOG`s at `HandleRepositoryChanged`, `RebuildTargets`'s reclaim branch,
and `SetSelection`'s entry (all removed once confirmed) showed the reclaim
*succeeding* exactly as designed, and then, milliseconds later, something calling
`SetSelection` again with an empty array. A captured callstack
(`FPlatformStackWalk::StackWalkAndDump`) named the actual caller: a real
`SNexusHierarchyTree` widget, alive in this editor process from workspace/layout
restoration even under `-unattended -NullRHI`, reacting to the test's own repository
broadcast by pushing its own (empty, unrelated) selection back onto the subsystem
via `PushSelectionToEditor()`. See
[[a-global-singleton-view-can-fight-a-headless-test]].

**Fixed in the test only**: `FNexusHierarchyView::Get().BindRepository(nullptr)` for
the test's duration, rebound via `ON_SCOPE_EXIT` to `&Subsystem->GetRepository()` —
exactly what `Initialize()` leaves it as. No production code changed for this part.

**Verified by re-running at every step**, per [[verify-claims-by-re-running]]: the
isolated test failed twice with the exact symptoms above (confirmed via diagnostics
and a callstack, not assumed), passed cleanly once the view was detached, then the
full clean gate (`Scripts\VerifyPhase08UiGate.ps1`, no `-SkipBuilds`) confirmed
`PASS: 157 tests, 0 failures`, `PASS: 21 budget measurements, 0 over`, `PHASE 08
E1+E2: PASS`. Crud's count moves 22 → 23, exactly the one new test.

Full account:
[evidence/phase-08-f08-17-undo-redo-scope-2026-09-02.md](../../project-specifications/evidence/phase-08-f08-17-undo-redo-scope-2026-09-02.md).
Does not move Phase 08's status: E3 has not run, F-08-06 and F-08-15 still need the
user's reading, and E0-02/E0-03 from the same review are recorded but not yet acted
on.
