# 2026-09-02 — F-08-19: every successful command records what it did (E0-02)

The last open finding from the 2026-09-02 E0 independent review. **E0-02,
Warning**: F-08-16 taught `FNexusCommandService::Execute` to write a real Activity
message and target summary by reusing a destructive command's *confirmed preview* —
but a non-destructive command builds no preview, so Apply, Create, Rename, Reparent,
Duplicate, Save, New/Open/Close, Undo and Redo still fell through to
`FNexusOperationHistory::Complete`'s bare status word ("Completed", origin "no
explicit target"). The everyday case, not a corner one, and the prose read as if
F-08-16 had closed it.

**User direction (2026-09-02, via AskUserQuestion):** fix now rather than defer;
synthesize centrally in the command service from what the result already carries
rather than adding a per-handler success-message field to the soon-frozen
`FNexusCommandResult`.

**Fix.** New `SummariseSuccessfulCommand` helper in `NexusCommandService.cpp`, called
for exactly the `else` branch that previously wrote nothing:

- `DescribeChangedEntities` resolves `Result.ChangedIds` against the live
  `Context.Document` to `"DisplayName (Kind)"` / `"DisplayName (Activation Point)"`,
  joined with `"; "` when 3 or fewer, `"N item(s)"` past that (the F-08-16
  `DescribeConfirmedTarget` threshold). Message `"<Label>: <entities>."`, target
  summary = the list. This is the path Apply/Create/Duplicate/Rename/Reparent take,
  because `FNexusEntityMutationResult::ToCommandResult` already fills `ChangedIds`.
- else `RefreshHint::Document` or a `DocumentId` in `ChangedIds` → `"<Label>: the
  active document."` / `"the active document"` (Save, New, Open, Close, Reload, Undo,
  Redo).
- else — a Phase 05 view-only command, or a valid no-op — → `"<Label>."`, no target.

The document pointer is `::IsValid`-checked before deref because Close/Reload can
leave `Context.Document` on a replaced object. Includes added:
`NexusEntityCommands.h` (for `NexusEntityKinds::GetDisplayName`), `UObject/Object.h`
(for `::IsValid`). `FNexusOperationHistory::Complete` untouched — its `"Completed"`
fallback survives for direct callers but the service success path no longer reaches
it. `FNexusCommandResult` gains no field.

**New test** `Nexus.V7.Command.SuccessfulCommandRecordsSummary`
(`NexusCommandSystemTests.cpp`): a scripted non-destructive handler through an
isolated service + history against a two-entity document, asserting the entry for
five result shapes (one named entity / several / document-level / valid no-op / an
id the document no longer holds) — none may record the "Completed" / "no explicit
target" fallback. The F-08-16 destructive-path test is unchanged and green.

**Verified by re-running** (`Scripts\VerifyPhase08UiGate.ps1 -RunLabel
2026-09-02-f08-19`): three clean builds; `PASS: 159 tests, 0 failures`; `PASS: 21
budget measurements, 0 over`; `PHASE 08 E1+E2: PASS`. `Nexus.V7.Command` moves 17 →
18, exactly the one new test; no other suite's count moved. Budget artifact
`Saved/NexusV7/Phase08/ui-budgets-2026-09-02-f08-19.txt`, 1,011 bytes, SHA-256
`E6437D1CBA6A2CDB787DBEC194F3D7F1E205640919BFEB5636C17BDF4F62D31D`.

New memory:
[[a-cross-cutting-fix-built-on-a-per-path-artifact-inherits-that-path]] — the shape
E0-02 is an instance of.

With E0-01 (F-08-17), E0-03 (F-08-18) and E0-02 (F-08-19) closed and E0-04
Information-only, every finding from the 2026-09-02 independent review is acted on.
Does **not** move Phase 08's status: E3 has not run, and F-08-06 and F-08-15 still
need the user's reading. Full account:
[evidence/phase-08-f08-19-activity-summary-2026-09-02.md](../../project-specifications/evidence/phase-08-f08-19-activity-summary-2026-09-02.md).
