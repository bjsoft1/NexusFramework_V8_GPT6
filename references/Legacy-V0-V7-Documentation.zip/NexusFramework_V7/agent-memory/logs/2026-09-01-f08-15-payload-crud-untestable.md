# 2026-09-01 — F-08-15: Phase 08's payload CRUD task has the same gap as F-08-06

Checked Phase 08 task 3, "exercise real fixed and dynamic-array payload CRUD through
save, close, restart, reload, undo, and redo," against the actual UI rather than
taking the checklist wording at face value. `NexusCommandCatalog.cpp` has zero
occurrences of `Activation` anywhere — no delivered handler, no pending-phase stub
either, which is a stronger absence than the sixteen commands F-08-05 already covers.
`FNexusActivationPointCommandService::Create/Update/Delete` exist and are tested;
nothing in the UI calls them. See [[the-bottom-two-rungs-are-not-hand-authored]].

Not a new fact: `phases/phase-07.md` already records the identical omission against
its own near-identical unchecked task 3, in more explicit words ("...created
**entirely through the UI**"). Phase 08's own ledger just hadn't said so yet for its
own task list — an omission of *recording*, not of *reality*.

What is actually provable today, all at the command-service level:
`Nexus.V7.Foundation.ActivationPointCrudTransactions` (create/undo/redo/update of a
payload with a nested dynamic array), `Nexus.V7.Foundation.RealAssetCrudRoundTrip`
(save/reload of fixed and array payload shapes), and a genuine three-process cold
restart (`Nexus.V7.ColdRestart.01_Prepare`/`02`/`03`, via
`Scripts\VerifyPhase01ColdRestart.ps1` — Phase 01 already built real
`UnrealEditor-Cmd.exe`-restart infrastructure, it has just never been pointed at
activation-point data). None of it goes through a click.

Recorded in `phase-08.md` and `PHASE-STATUS.md` as F-08-15, needing the user's
reading the same way F-08-05/F-08-06 did, per
[[v7-phase-governance]]: record and ask, don't narrow the task on an agent's own
initiative.
