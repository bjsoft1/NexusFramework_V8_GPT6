# 2026-08-27 — The per-map document, and a deferral that should have ended two rounds earlier

Closes item 3 of [`empty-tree-cannot-author.md`](../../agent-todos/ready-for-review/empty-tree-cannot-author.md)
and adds the Create Default seed under item 1. That file carries the full write-up;
this records what was learned.

`Result: Succeeded` on the editor target, `PASS: 124 tests, 0 failures` via
`Scripts/VerifyPhase07Crud.ps1 -SkipBuilds`. Re-run per [[verify-claims-by-re-running]].
The three clean builds and the full `Nexus.V7` sweep were not re-run for this change.

## A correct scope answer, given three times, is not an answer

The user asked three times for the per-map config asset V6 generated. Each time the
reply was some form of "Phase 10 owns automatic world-config discovery, Phase 10 is
blocked behind 09, behind the Phase 08 gate, behind this phase." Every clause of that
was true. It was still the wrong thing to say on the second and third pass, and the
fourth message opened with the user being angry.

The gate model exists so implementation claims cannot be mistaken for evidence
([[v7-phase-governance]]). It does not exist to decide what a user is allowed to
have. When a request keeps coming back, the phase boundary stops being information
and becomes a way of not doing the work: the useful move is to build the smallest
honest version, say exactly which part of the owning phase it does *not* deliver, and
write the pull-forward down where the owning phase will see it.

`phases/phase-10.md` now carries a **Delivered Early** section naming what shipped and
what is still its own — `ANexusWorldAnchor`, ownership-mismatch clone/relink/cancel,
and everything from mapping onward. Its first task's checkbox stays unchecked, because
that task says "using Phase 01 ownership rules" and the anchor *is* those rules. A
boundary that gets crossed and not recorded stops meaning anything.

## Deriving one path is not the discovery the architecture forbids

`V7-ARCHITECTURE.md` says discovery "never chooses the first asset or first Landscape
it happens to find." That sentence was cited twice as forbidding V6's convention, and
it does not: it forbids a *search*. One exact package name derived from one world
package is the opposite of a search — it is total, deterministic, and has no candidate
set to pick a winner from.

The anchor is still the right long-term mechanism, because a derived path cannot
survive a map being renamed or duplicated. So the convention ships as a documented
fallback that the anchor will take precedence over, not as a replacement for it.

**The general shape: an architecture rule against ambiguity is not a rule against
convention.** Check which one the sentence actually prohibits before citing it.

## V6's create path wrote the file; ours must not

V6's `FNexusConfigAssetIO::LoadOrCreateConfigAsset` called `SavePackage` on creation,
so opening a map wrote a `.uasset`. Copying that would have contradicted
`V7-UX-SPEC.md` 12.1 and Unreal's own create-asset flow, both of which leave a new
asset in memory with an asterisk until the user saves.

Leaving it dirty and unsaved is also what the user actually described wanting — *"make
it dirty and showing unsaved in UE editor"* — which is worth noting on its own: the
report named the *observable state*, not the mechanism, and the mechanism V6 used was
the wrong half to copy.

## The delegate that does not fire for a new level

V6 recorded, from reading `FileHelpers.cpp` / `LevelEditorSubsystem.cpp` /
`EditorServer.cpp` rather than assuming, that File > New Level routes through
`UEditorEngine::NewMap()` and broadcasts **only** `FEditorDelegates::MapChange` with
the `NewMap` flag — never `OnMapOpened`. Without binding both, switching from a saved
map to a blank one leaves the saved map's document active and editable.

That is a V6 bug that V6 already paid for and wrote down. Reading the previous
version's own notes before rebuilding a feature it had is worth more than reading its
code.

## An auto-bind must not run under `-unattended`

The bind creates an unsaved package beside whatever map is open. An automation run
opens whatever map it was pointed at, so without a guard the verification script would
leave a dirty package in the project it is about to measure. `FApp::IsUnattended()`
and `IsRunningCommandlet()` gate it.

The cost is honest and recorded: `FEditorDelegates::OnMapOpened` firing for real has
no automated coverage. `Nexus.V7.Crud.WorldDocumentBinding` covers the derivation and
the resolve — everything the delegate calls — and the delegate itself stays a manual
check.

## A probe that returns its own expectation proves nothing

`EmptyHierarchyActionCreates` pressed the empty state's first button and then did
this:

```cpp
OutCommandId = NexusCommands::Create;
```

It returned the answer as a literal. The test asserting `Command == NexusCommands::Create`
would have passed against a button wired to nothing at all. It now reads the document
back through the subsystem and returns the rows as `Kind: Name`.

Same family as [[declared-is-not-reachable]], one layer in: there, a surface was
declared and unreachable; here, a probe observed nothing and reported success anyway.
**A test hook that constructs part of its own expected value has a hole exactly that
size.**
