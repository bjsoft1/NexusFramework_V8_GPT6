# 2026-08-24 — Delete confirmation popup, view refresh, copyable messages

Closes all four items of
[`agent-todos/ready-for-review/need-enhancement.md`](../../agent-todos/ready-for-review/need-enhancement.md),
reported by the user against the Phase 07 CRUD build. The full write-up is in that
file; this log records what was learned rather than what was changed.

## The one that mattered: no command refreshed anything

Reported as "after delete the tree view not refresh". It was not about delete.

`FNexusEditorUIModule::RunCommand` and `AcceptPendingConfirmation` both called
`FNexusCommandService::Get().Execute` directly. Only
`UNexusEditorSubsystem::ExecuteCommand` calls
`Repository.NotifyChanged(Result.RefreshHint, Result.ChangedIds)`, and that broadcast
is the single signal every view has. So **every** command run from the shell mutated
correctly and told nothing. Delete is where it shows, because a stale row is one you
can select and then act on.

Nothing about the mutation was wrong. `ExecuteDelete` returned the right hint, the
entities went, the revision advanced. Every existing assertion passed. The gap was
between "the document changed" and "anything was told", and no test looked there.

Recorded on [[command-service-is-the-only-mutation-path]], which already described
the mutation seam and now describes the refresh half too.

The shell had a reason to go around the subsystem: its context carries the invoking
surface and, for a destructive command, the approval the user gave against a specific
preview, and the subsystem's `ExecuteCommand` built its own. The fix was an overload
that takes the caller's context, not a rule against having one.

## Two symptoms, one cause

Items 1 and 4 — "the delete message should show popup" and "when asking the delete
then focus next tab" — were the same defect. `SNexusConfirmationBar` was built by
`SNexusShellSurface::BuildCommandBar`, which every surface runs, so three open
surfaces meant three confirmation bars each calling `SetKeyboardFocus` on its own
cancel button. And because an inline strip is invisible unless you are looking at the
surface that drew it, `RunCommand` called `FocusSurface` to make it findable — which
invokes a tab, and moved the user off whatever they were on.

The user's own guess in item 4 ("maybe auto fixed if convert into dialog") was right,
and worth taking seriously as a diagnosis rather than a preference.

`SNexusConfirmationDialog` is a `PushMenu` popup, the same mechanism the command
palette uses. Still not an OS modal, so `Nexus.V7.Shell.NotificationsAreNonModal`
passes unchanged. V7-UX-SPEC.md section 15 permits a dialog for destructive
confirmation; the Phase 04 decision to go inline was a choice, not a constraint.

## A test caught its own explanation

`Nexus.V7.Shell.ConfirmationIsAPopup` reads `RunCommand`'s destructive branch and
fails if it contains `FocusSurface`. First run: red — on the code comment explaining
that `FocusSurface` had been removed. Matching now includes the open paren and the
comment was reworded. `Nexus.V7.Module.UiMutationBoundary` already carries a note
about exactly this ("prose about the flag — this comment included — cannot satisfy
the rule on its own"); it is a recurring shape in this codebase's source-scan tests,
not a one-off.

## Three commands that existed and could not be reached

`Nexus.History.CopyEntry`, `Nexus.History.CopyTechnicalDetails`, and
`Nexus.Debug.CopyDiagnostics` have been registered, eligible, and listed in the
palette since Phase 04. `SNexusActivityLog`'s own header claimed "cancelling,
copying, and clearing all go back through the command service" — true, and no surface
could open a menu containing them. Another instance of
[[declared-is-not-reachable]]; the guard summons the menu from a real list rather
than calling `NexusMenus`, because a builder-level test would have passed the whole
time.

## Slate notes worth keeping

- `STextBlock` cannot be selected at all. A read-only `SMultiLineEditableText` looks
  identical, takes no typed character, commits nothing, opens no transaction, and
  gives selection, `Ctrl+C`, and a Copy / Select All context menu.
  `NexusShellUI::MakeSelectableText`.
- Its `TextStyle` is copied into the text layout during `Construct`, so passing the
  address of a temporary style is safe — which is what lets a per-instance colour
  override work without registering a new style token.
- A style is fixed at construction, so live colour comes from
  `FSlateColor::UseForeground()` plus the containing `SBorder`'s `ForegroundColor`.
  `FSlateTextRun::OnPaint` resolves it against the inherited widget style each paint.
- Do not put one inside a list row: it swallows the click that selects the row. Give
  the list a context menu instead.
- `SMenuEntryBlock::OnClicked` dismisses the menu stack **before** running the
  action, specifically so an action can open a new menu. A popup raised from a
  context-menu entry survives.

## Verified

Three clean builds and `PASS: 119 tests, 0 failures` via
`Scripts/VerifyPhase07Crud.ps1`; `FOUNDATION STRUCTURAL SCAN: PASS`; 123/123 across
all of `Nexus.V7`. Re-run per [[verify-claims-by-re-running]].

## Not covered

`PushMenu` needs a real window, so nothing here proves the popup lands over the
focused surface, or that clicking away dismisses it. Nor can automation drag a mouse
across a selectable message. Both are now E3 checklist item 6 and the new item 13 in
`project-specifications/evidence/phase-07-e3-manual-checklist-2026-08-24.md`.

---

# Follow-up, same day — rename, and who owns saving

## Accepting an offered name was reported as an error

`Nexus.Authoring.NoChange`, Blocking, from creating a point and immediately renaming.
`ExecuteCreate` opens inline rename on the new row with its generated name in the box;
`SInlineEditableTextBlock` commits on Enter *and* on focus loss; the row ran Rename
with the unchanged name; the service refused it as Blocking. So the commonest thing to
do with a new row — accept the name — produced a red banner.

The general shape is worth remembering: **a refusal that is correct at one layer can be
wrong at another.** "Rename this to the name it already has" is genuinely not a rename,
and `FNexusEntityCommandService::Rename` is right to refuse it. But the command layer
knows the user was *accepting* rather than *asking*, and that is the layer that has to
decide. The fix went into `ExecuteRename`, not the row widget, so the palette, `F2`,
and automation all get it.

Second-order: `FName` compares case-insensitively, so the equality test read
`point` → `Point` as no change. Before the fix that was a Blocking error; the fix would
have turned it into a *silent* no-op, which is worse. Both layers now use
`ENameCase::CaseSensitive`. Watch for this whenever `FName` equality stands in for "did
the user change anything" — it is the wrong comparison for anything a human typed.

## Save and dirty ownership — handed over, not fixed

The user reported the system "auto saving" and wanting mutations to mark the package
dirty and let Unreal do the write. Audited every write path: entity mutations, Details
Apply, and the activation-point commands all do `Modify()` + `MarkPackageDirty()` with
no write, and draft autosave writes only to `Saved/NexusV7/Recovery`. All correct
against V7-UX-SPEC.md 12.1 and 12.2, and already guarded.

Three things are not:

1. `FNexusDocumentStore::Create` calls `Save(Document)`, so New Document silently
   writes the package — the one thing 12.1 names outright.
2. `Nexus.Document.Save` calls `UPackage::Save` directly rather than going through
   Unreal's save path, so no source-control checkout happens.
3. The Details footer says `"Saved"` when the draft is applied and the package is
   merely dirty. Probably most of why the report reads the way it does: the wording
   promises a write the code correctly does not perform.

Written up in `agent-todos/ready-for-review/save-and-dirty-ownership.md` rather
than fixed, because it is over the time bar the user set and item 1 changes
user-visible behaviour on a phase awaiting review. Item 2 needs the user's decision,
not an agent's.
