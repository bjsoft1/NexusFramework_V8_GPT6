# 2026-08-28 — The hierarchy ladder narrowed to four rungs

Asked for by the user during Phase 08: one child kind per level, no Sub Point, no
hand-created highway points, a numbered default name, and the default seed unchanged.
The user then asked, before any code was written, that the docs and the upcoming
phases be checked for conflicts first. That check changed two of my conclusions and is
the most useful part of this log.

## What changed

The authoring ladder is **State > City > Highway > Highway Point**, adjacent only. The
document root takes a State and nothing else, because the document is itself the
world. `World`, `Road`, `Junction`, and `SubPoint` are retired from the ladder while
staying `ENexusEntityKind` values.

Structural legality and hand-creatability became two questions.
`NexusEntityKinds::IsLegalChild` keeps Highway > Highway Point valid, because Phase 10
reconciles those points from landscape geometry and writes them as ordinary records;
the new `GetCreatableChildKinds` withholds that one pair from every Create surface. The
menus, the empty-state buttons, and the multi-parent intersection all moved to the
creatable list; nothing else did.

Default names are `New <Kind> <N>`, counted across the whole document so no two rows in
one tree read `New City 1`. The number is generated rather than left to collision
uniquing, because a ` 2` suffix on a name that already ends in a number reads as a
bug. `MakeDefaultName` now takes the document. Create counts against the candidate as
it grows, so a batch of three Cities numbers 3, 4, 5 rather than repeating.

## What the pre-flight check found

**Three unstarted phases already assumed the four rungs.** phase-16 compiles "canonical
State/City/Highway/HighwayPoint records"; phase-11 lists junctions and lanes beside
those four as graph attributes; phase-09 and phase-12 treat junctions as landscape
topology. So this is a narrowing, not a contract redesign, and no downstream phase
needs rework.

**Two things I had wrong and would have broken.** `phases/phase-14.md` lists
"sub-points" as an Activation Point deliverable and `NexusRuntimeDataset.cpp:319`
already treats `SubPoint` as a payload-carrying kind beside `ActivationPoint` — I had
listed that carve-out as dead code to clean, and it is not. And
`ENexusEntityKind::World` is the selection key for the *document itself* in the Reload
and Close previews, which is a better reason for World not being a creatable row than
the one I had. Generalized into
[[check-unshipped-phases-before-narrowing-a-contract]].

## Verification

Clean editor build, no new warnings. `Scripts\VerifyPhase07Crud.ps1 -SkipBuilds`:
**125 tests, 0 failures**, one more than the 124 baseline, being the new
`Nexus.V7.Crud.DefaultNaming`. `Scripts\VerifyPhase08UiGate.ps1 -SkipBuilds`: every
suite passes except `Nexus.V7.UiGate.SelectAllAtScale`, which is F-08-04 and was
already open and deliberately left failing.

**No E3.** This change is visible almost entirely in menus, buttons, and the names new
rows carry, which is exactly what automation cannot see. Checks 2, 17, and 20 of
`phase-07-e3-manual-checklist-2026-08-24.md` asserted the eight-rung ladder and a
Create World button; they are amended in place with the date, following that file's own
convention, and still need a person.

## F-08-07, found by using the feature the change touched

The user created a Highway, clicked another row while the new row's inline editor was
still open, and got
`Nexus.Authoring.NameCollision: Another item under the same parent is already called
'New Highway 4'`.

The collision was the lucky case. An inline editor commits when it loses keyboard
focus; the click that takes focus away moves the **selection** first; and
`ExecuteRename` resolved its target from the selection. So the text typed into one row
was written onto the row that had just been clicked — refusing when that row was a
sibling, and **succeeding silently when it was under a different parent**. An entity
renamed by a click, with an undo step that looks deliberate.

Every rename test passed throughout, because every one of them sets the selection to
the row it is editing. The test that catches it is the one that deliberately puts the
selection somewhere else — which is what actually happens whenever a rename ends by
clicking rather than by pressing Enter, i.e. most of the time.

`FNexusAuthoringView` already held the rename target and nothing cleared it on a
selection change, so the fix was to ask the view rather than the selection; the
selection is now only the fallback for a rename with no editor open. The guard widened
to match, because the same click can clear the selection and it used to refuse with
"Select an item in the hierarchy to rename" — blaming the user for a rename they had
already typed. `Nexus.V7.Crud.RenameFollowsItsRow` covers it, and was verified by
disabling the fix and watching it fail with the exact message the user quoted.

The numbered default names made this *more* likely to be hit, not less: every new row
now arrives with a name that is unique among its siblings and already selected in the
box, so the commonest thing to do with it is accept it by clicking elsewhere.

## F-08-08, the gap the narrowing exposed

*"How i can create the state? Not possible to create state."* With one State in the
document there was no way to make a second. A State row offers City inside it, and a
State's parent is the document root — which is not a row anyone can select. The only
route was to clear the selection first, and nothing on screen says so.

The narrowing did not introduce this so much as finish it: with eight rungs the root
offered World *and* State, and every rung offered several children, so the missing
sideways route was never the only thing standing between a user and what they wanted.

Create now carries a **target** beside its kind. `AlongsideSelection` creates under the
parent the selected row already has, which for a State is the root, deduplicated so two
selected siblings produce one new row rather than two. The submenu draws two sections —
*Inside the selection* and *Alongside the selection* — so a State row can offer City and
State at once without either entry becoming a sentence.

Two traps worth remembering. The kind has to be validated against the list the chosen
entry came from: `ResolveCreateKind` checks the pending kind against the legal list and
falls back to `Legal[0]`, so validating a sibling choice against the *child* list would
have silently made a City when the user picked State. And the target must be cleared by
the command while the kind stays sticky — the kind is a preference, "alongside" is one
click's instruction, and a sticky one would redirect the next Insert.

A Highway also stops being a Create dead end: nothing goes inside it, but another
Highway goes beside it. That made the Highway branch of `GetEmptyCreateReason`
unreachable, so it was removed rather than left to look like it still fires.

## Left undone on purpose

Activation points still have no UI gesture — the record already carries `AnchorId`,
`TypeKey`, and the `LocalTransform` that is the offset the user described, so the data
model needs nothing; the gizmo is Phase 12 and the type registry is Phase 14. Road and
Junction are retired without a replacement: they return as a *type* of highway point,
which is a property on a rung and not a rung, and no phase owns that field yet.
`NexusCloneRekeyTests` still builds a Point directly under a State, which the new rule
would refuse; it writes records directly rather than through the command service, so it
still passes, and rewriting it would have meant renumbering index-based references for
no behavioural gain.
