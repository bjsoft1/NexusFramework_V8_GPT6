# 2026-08-28 — Phase 08: the budgets nobody had measured

Started Phase 08, the UI Completion Gate, on the user's instruction against an unmet
dependency (Phases 05–07 are Ready for Review, not Complete). Full write-up in
[`phase-08-ui-gate-2026-08-28.md`](../../project-specifications/evidence/phase-08-ui-gate-2026-08-28.md);
this records what was learned.

`Result: Succeeded` on the editor target. 136 of 137 tests pass — the one failure is
F-08-04 and is left failing on purpose. Re-run per [[verify-claims-by-re-running]] via
`Scripts/VerifyPhase08UiGate.ps1`. The three clean builds were not run.

## A test that disclaims being evidence is a gate item with nothing behind it

Phase 08's acceptance gate says "Representative scale meets Phase 01 UI budgets."
Sitting right next to it was `Nexus.V7.Hierarchy.Scale`, which builds the 100,000-row
reference tree, times three operations, and then says in its own comment:

> Section 12's budgets are targets on a reference workstation that is not necessarily
> this machine, so the ceilings here are deliberately loose. They catch a collapse
> into quadratic work; they are not the budget measurement.

Every word of that is honest and correct. It is also the exact shape of a gap that
survives review: a suite named `Scale`, at reference scale, green, adjacent to a gate
item about scale — and satisfying none of it. Reading the test list would tell you the
budget was covered. Only reading the comment tells you it is not.

**The general shape: a disclaimer inside a passing test is invisible from the test
list, the suite name, and the pass count.** When a gate item claims a number, go and
find the assertion that holds that number. If no assertion names it, it is not
measured, however many green tests surround it.

## Budgets measured only at the size the spec names hide the defects users hit

Measuring for the first time found four Blocking defects. All four were invisible to
every existing suite, and the reason is the same each time: the existing tests use the
size the spec's budget names, and three of the four defects are quadratic or
per-element costs that are free at that size.

The clearest case. Section 19 budgets "multi-selection summary for 1,000 selected
loaded items: 300 ms". At 1,000 items V7 answers in 13.7 ms — a 22x margin, a very
green test. Underneath it, three separate paths deduplicated or tested membership with
a linear scan: `FNexusSelectionModel::SetSelection`, `InvertVisible`, and
`FNexusDetailsView::SetSelection`. Select All Visible is a Phase 05 command bound to a
chord, and it hands the *entire tree* to all three at once. At 100,000 rows that is
about five billion comparisons per path. Not a slow command — an editor that stops
responding, shipped, with a green multi-selection test.

**The size in the budget is the size the spec chose to write down, not the size the
command can be handed.** For every budget, ask separately what the largest input a
user can produce is, and measure that too. The budget number tells you what is
acceptable; it does not tell you what is reachable.

## Four sorts formatted a GUID into a string, twice, per comparison

The stable tie-break in four different sorts was `Left.ToString() < Right.ToString()`
on an `FNexusId`. Sorting the reference tree is ~1.7 million comparisons, so ~3.4
million 36-character GUID formats, allocated and discarded. Sort went 411.6 → 28.7 ms
when that became a component comparison.

The same file's filter opened by building `NameText`, `TypeText`, `KindText`, and
`IdText` for every row before looking at which terms the query actually had — 400,000
allocations per keystroke, of which a typical query uses one, and the unused `IdText`
was the most expensive of the four.

Both read as perfectly ordinary code. Neither is visible as a defect at any size the
other suites use. **A per-element allocation is not a smell until you multiply it by
the reference scale**, and nothing in the codebase multiplies it for you.

## Proving an optimisation preserves order, instead of arguing it

Replacing the string tie-break changes the ordering unless GUID-component order and
lowercase-hyphenated-hex-string order agree. They do agree, and there is a clean
argument for why — fixed-width lowercase hex, separators at identical offsets. The
argument was still not written into a comment and left there.

`Nexus.V7.UiGate.IdOrdering` holds the two orderings against each other over 225,996
pairs, including crafted component-boundary cases, and checks the comparator is
irreflexive and asymmetric. If the argument had been wrong, every stable order in the
editor would have shifted silently and saved expansion and selection state would stop
lining up with the rows they were recorded against — and nothing else would have said
so. Same family as [[declared-is-not-reachable]]: the claim and the check look
equally green until one of them is actually run.

## Leaving a test failing is sometimes the honest option

F-08-04 is open: `FNexusDetailsView` builds a draft proxy `UObject` for every selected
entity, eagerly. Section 19's multi-selection line ends "with details calculated
incrementally afterward if needed" — a design instruction V7 does not follow — so
Select All on the reference tree costs 1264 ms against a 300 ms budget.

The tempting moves were both wrong. Relaxing the assertion to a ceiling the current
behaviour meets would turn the budget into a description of whatever the code does.
Fixing it means a bounded or incremental target build, which changes a contract Phase
06 owns, and `V7-QUALITY-GATES.md` makes a changed architectural contract a decision
that reopens the owning checkpoint — not an implementing agent's call
([[v7-phase-governance]]).

So the assertion stays written against the budget, and its failure message names the
missing mechanism rather than just the number. A gate phase is the one place where a
red test is the correct output.

## Two findings that are not code

**F-08-05.** The Phase 08 gate says "No required UI behavior is deferred to Phase 09
or later" and "no dead command remains". The catalog deliberately registers 16
commands owned by Phases 10–16 that refuse by name, which is Phase 04's design and is
correct. Both sentences cannot stand as written; someone has to say which reading
holds. **F-08-06.** This phase lists the ownership-mismatch state among those to test,
and `phases/phase-10.md` "Delivered Early" already reserves it.

Neither is fixable by writing code, and guessing an answer would bury the conflict
rather than resolve it — the mistake recorded in
[2026-08-27](2026-08-27-per-map-document-and-default-seed.md) in its other direction.
