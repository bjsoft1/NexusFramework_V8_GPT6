# 2026-08-31 — Phase 08 large row-menu hover lag

After the collapsed-tree correction, a manual Large 808 run exposed a second scale
path: moving the pointer over a row context menu stalled the whole editor.

The menu itself was not large. Slate repeatedly polled the shared command list and
the hovered tooltip. `CanInitiate` treated "can start a destructive command" as
"build its complete preview now", so Delete rebuilt and discarded the selected
State's full cascade impact on every paint.

The command-handler contract now separates cheap preview capability from preview
materialization. Live menu guards check the capability; a click builds the actual
preview; approval and execution retain current-guard, command-identity, token,
revision, and current preview-viability checks. The counting command regression
polls initiation 128 times and requires zero preview builds.

The source and test are unbuilt/unrun because the local `dotnet.exe` application
error still prevents UnrealBuildTool from starting. Evidence is in
`project-specifications/evidence/phase-08-large-context-menu-hover-2026-08-31.md`.
