# 2026-09-01 — Phase 08: dotnet.exe resolved, first clean E1+E2 pass, F-08-14

The `dotnet.exe`/UnrealBuildTool startup failure that had left the 2026-08-31
collapsed-tree-lag and row-menu-hover-lag commits unbuilt and unrun is resolved on
this workstation; a plain editor build now succeeds. Ran the full
`Scripts\VerifyPhase08UiGate.ps1` gate (clean builds, not `-SkipBuilds`) for the first
time covering those two corrections together with the bounded-Details correction
before them.

That run failed `Nexus.V7.Crud.RecoveryBeforeReload`. The test was added in the same
commit as bounded-Details (8a617fe) but *after* that commit's own cited evidence run
had finished — the cited log has zero occurrences of the test's name — so this was
its first-ever execution, not a regression from either lag fix.

Root cause and fix: [[reload-can-pre-update-the-pointer-your-guard-checks]].
`SetActiveDocument`'s `ActiveDocument == InDocument` no-op guard was satisfied before
Reload's explicit call ever ran, because `UPackageTools::ReloadPackages` had already
repointed `ActiveDocument` at the new object. Added a `bForceRebind` parameter, `true`
only from the Reload call site. Confirmed the failure first with temporary diagnostic
logging (removed once the cause was confirmed), then confirmed the fix with the full
`Nexus.V7.Crud` suite (22 tests, 0 failures, no other regressions).

Full clean run after the fix: 154 tests, 0 failures; 21 budget measurements, 0 over;
all three targets built clean. `PHASE 08 E1+E2: PASS`. This is Phase 08's first-ever
full clean E1+E2 pass. It is implementing-agent evidence only — E0, E3, and F-08-06
remain, and seven of nine task lines are still unchecked or partial. Full evidence in
project-specifications/evidence/phase-08-clean-gate-and-f08-14-2026-09-01.md.

A peer Claude session (`nexusframework-v7-17`) was found active in the same working
directory partway through this work; confirmed via cross-session message that it had
made no edits and would stay off `NexusEditor/` until this pass finished.
