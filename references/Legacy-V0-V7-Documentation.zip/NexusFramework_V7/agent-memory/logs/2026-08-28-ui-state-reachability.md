# 2026-08-28 — The shell state nobody could get into

Phase 08, second pass. Task: *"Test empty, loading, dirty, invalid, blocked,
unknown-payload, stale, save-failure, and ownership-mismatch states."*

## What made this task look already-done

`Nexus.V7.Shell.StateDerivation` has seventeen cases covering all nine
`ENexusShellState` values plus every precedence rule between them.
`Nexus.V7.Shell.StatePresentation` checks the headline, detail, and action each state
draws. `Nexus.V7.Hierarchy.ViewStates` and the Details suite do the same for their own
enums. The first Phase 08 pass looked at that and wrote, correctly, that the eight
non-ownership states "are all present".

Every one of those tests builds an `FNexusShellSignals` by hand, sets the fields it
wants, and reads the state back. That proves the derivation and the wording. It cannot
prove that anything in the editor ever sets those fields.

`grep` for the writer, not the reader. `SetSourceStale` had no caller. `bSourceStale`
was written by nothing. `ENexusShellState::Stale` was unreachable.

## Why it mattered rather than being tidy

The state's own comment says "derived from a source that has since moved on".
`FNexusDetailsView::IsDraftStale` detects that exact thing, has done since Phase 06,
and Apply refuses while it is true with "The document changed after these edits were
made."

So the editor had a panel telling the user their edit could not be committed, and a
context strip on the same screen saying `Dirty`. Nothing was wrong with either half.
The two were never connected.

The `bSourceStale` member is not dead in the long run — Phase 09's landscape source is
a second staleness, and the Home health list already carries a "Landscape source
binding" line for it, deferred by name. So the fix ORs the Details answer in rather
than replacing the member, and adds a second health line, "Pending edits", because one
`Stale` chip cannot say which of the two is meant.

The half that is easy to miss: the provider had to subscribe to
`FNexusDetailsView::OnChanged`. Staleness *starts* on a repository change, which the
provider already heard. It *ends* on a reload or a revert, which move no revision and
broadcast nothing the provider was listening to. Without the subscription the strip
would have stayed Stale after Apply had stopped being refused — the same defect
pointing the other way.

## Three more, found by doing the work rather than by looking for them

**The gate script ate its own evidence.** `-RunLabel` defaulted to `yyyy-MM-dd`, and
both Phase 08 passes ran on 2026-08-28, so the second `Copy-Item -Force` replaced the
budget artifact the first pass cites by SHA-256. The dated-name convention *was* the
fix for this class on 2026-08-23; it separates phases and not runs, and a gate script
is precisely the one that gets re-run several times in a day. Now `yyyy-MM-dd-HHmmss`,
and the copy refuses an existing destination instead of forcing — the second half
matters because an explicit `-RunLabel` can still reproduce a cited name. The
overwritten file is gone; `Saved/` is gitignored.

**A modal dialog in an unattended run.** The new migrated-document test loads a copy of
the frozen schema-v1 fixture. Migration marks the package dirty on load, by design;
`UPackageTools::UnloadPackages` cannot unload a dirty package and says so in a **modal
dialog**, which `-unattended` answers itself. The run exits 0, reports nothing, and
leaves a `.uasset` in `Content/` every time. Clearing the dirty flag on the scratch
copy before unloading fixes it. Worth knowing before writing the next test that loads
a migrating package.

**C5038 on every editor build.** `SNexusContextStrip::FArguments` initialised out of
declaration order. Harmless in effect. E1 for this phase is a *clean* editor build, and
a build carrying one permanent warning is a build where the next one is invisible.

## Where the task stopped

Ownership-mismatch, the ninth state, has no representation in the build at all — no
shell state, no target state, no diagnostic code, nothing that detects it — and
`phases/phase-10.md` reserves it. Building one here would be a placeholder, which the
same gate forbids. F-08-06 is narrowed to one question with two answers and needs the
user, not more work.

## Numbers

E1 clean, no warnings. 143 of 144 pass. The one failure is
`Nexus.V7.UiGate.SelectAllAtScale` — F-08-04, open by design.

Evidence: `project-specifications/evidence/phase-08-ui-states-2026-08-28.md`.
Negative proof: `Saved/Logs/P08-UiStates-negative.log`.
