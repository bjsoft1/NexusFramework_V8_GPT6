# 2026-08-24 — Details panel killed undo outright (bug 4)

Closes item 4 of
[`agent-todos/ready-for-review/bugs-redu-undo__scape-click.md`](../../agent-todos/ready-for-review/bugs-redu-undo__scape-click.md).
Items 1–3 were fixed on 2026-08-23 in the same report. This one was a **regression
introduced by the fix for item 2**, reported by the user as "the undo redo not working
now, maybe completely broken".

## What was actually wrong

Not a refresh problem like bug 1. Undo and redo were *gone*: `Ctrl+Z` did nothing at
all, permanently, once the Details panel had been typed into and the edit abandoned.

The live-text rows in `NexusDetailsCustomization.cpp` write through an
`IPropertyHandle` on every keystroke. The property editor opens an editor transaction
on the first interactive write and closes it only on a finishing write. The bug 2 fix
added an early return from `OnTextCommitted` for `ETextCommit::OnCleared` (Escape) and
then rebuilt the panel via `RevertField`, destroying the handle with its transaction
still open. `UTransBuffer::CanUndo` refuses while `ActiveCount != 0`.

One press of Escape therefore disabled undo for the whole session. Changing selection
mid-edit did the same.

The mechanism is recorded as a durable memory:
[[interactive-property-writes-open-transactions]].

## Fix

Details rows now always write with `EPropertyValueSetFlags::NotTransactable`. The
target is a transient draft proxy, never the document; the undoable step is the Apply
commit, which has its own `FScopedTransaction`. Nothing is lost — the proxy is
`RF_Transient` and not `RF_Transactional`, so the transaction recorded nothing and was
being popped as `IsTransient()` regardless.

Two smaller changes went with it:

- `PostUndo` defers its refresh by one tick. It runs while the transaction system is
  unwinding and the property editor is a client of the same broadcast, so rebinding an
  `IDetailsView` from inside it re-enters a property editor mid-undo.
- The queued refresh is now held as an `FTSTicker::FDelegateHandle` and cancelled in
  `Deinitialize`, rather than relying on the tick finding a null document on a
  torn-down subsystem.

## Guards added

The defect spans two layers, so it takes two.

| Guard | Holds |
|---|---|
| `Nexus.V7.Module.UiMutationBoundary` (extended) | Any NexusEditorUI file calling `SetValueFromFormattedString` must name `EPropertyValueSetFlags::NotTransactable`. |
| `Nexus.V7.Details.UndoAfterAutosave` (new) | An autosaved edit is one undoable step; it round-trips through `UndoTransaction`/`RedoTransaction`; the repository read path serves the restored value after `RebuildIndex()`; `IsTransactionActive()` is false either side. |

The first is a **source scan** on purpose. The bad code compiled, passed all 100 tests,
and shipped — the existing forbidden-string list in that same test already catches a
widget that opens a transaction itself, but could not see one the property editor opens
on the widget's behalf. It matches the qualified `EPropertyValueSetFlags::NotTransactable`
so that prose about the flag cannot satisfy the rule.

`Scripts/VerifyPhase06Details.ps1` expected-count for `Nexus.V7.Details` moved 22 → 23.

## Proven, not asserted

Per [[verify-claims-by-re-running]], the fix was reverted and the suite re-run.
`Nexus.V7.Module.UiMutationBoundary` failed with

> Expected 'NexusDetailsCustomization.cpp writes the draft proxy with NotTransactable,
> or undo dies the first time an edit is abandoned' to be true.

Restored and re-verified.

## Verification

```
PASS: clean build NexusFrameworkEditor-Win64-Development
PASS: clean build NexusFramework-Win64-Development
PASS: clean build NexusFramework-Win64-Shipping
PASS: Nexus.V7.Module - 12 results
PASS: Nexus.V7.Command - 17 results
PASS: Nexus.V7.Hierarchy - 14 results
PASS: Nexus.V7.Shell - 14 results
PASS: Nexus.V7.Details - 23 results
PASS: Nexus.V7.Foundation - 21 results
PASS: 101 tests, 0 failures
PHASE 06 DETAILS: PASS
```

Four `UnrealEditor.exe` processes were running during the clean builds. The script
warned, as designed; the builds succeeded anyway.

## Still open

No automated test presses Escape in a real text box — the customization is behind
Slate and cannot be typed into headlessly. The source guard stands in for it. **E3
checklist item 5 still needs a human at the keyboard**, and this bug is the argument
for why: it is the second time a Details defect reached the user with a green suite.
See [[declared-is-not-reachable]].
