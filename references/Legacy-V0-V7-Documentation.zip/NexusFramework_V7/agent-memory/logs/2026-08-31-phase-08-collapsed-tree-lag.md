# 2026-08-31 — Phase 08 collapsed-tree idle lag

A manual `Nexus.Fixture.LoadSample Large 808` run found a scale failure outside the
existing timed algorithms: the editor stayed laggy after the 100,000-row fixture had
loaded even though the tree was collapsed and `SListView` was virtualized.

The draw-order getter still scanned and reserved for all logical keys on each view
broadcast. The hidden Filters section built a duplicate invisible row array. Several
Slate-bound shell getters also repeated `CanSaveLosslessly` and recovery-directory
work during paint. The correction adds a cached roots/expanded-branches traversal,
preserves authored sibling ordering, suppresses hidden Filters rows and tree-only
listeners, reuses tree item handles across selection repainting, releases presentation
memory on collapse/clear-search, and caches shell validation/document information by
cheap document state.

The full logical hierarchy intentionally remains available for search, reveal, and
diagnostic safety; the lazy boundary is presentation and idle work. New deterministic
tests cover ten visited roots in the collapsed Large fixture and one expensive shell
state computation across repeated Slate-style reads. They are not yet run because
the local `dotnet.exe` application error blocks UnrealBuildTool. Evidence is in
`project-specifications/evidence/phase-08-large-hierarchy-idle-lag-2026-08-31.md`.
