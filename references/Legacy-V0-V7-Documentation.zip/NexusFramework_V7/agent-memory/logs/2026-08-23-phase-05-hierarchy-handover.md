# 2026-08-23 — Phase 04 accepted, Phase 05 started — handover

Written mid-task because the session ran out of budget. Phase 05 is **started but
not implemented**. Read this before touching anything.

## What actually happened this session

1. The user said "UI displaying good, next phase" after their E3 editor session.
   That is the user accepting Phase 04. Per `V7-QUALITY-GATES.md` §1 an AI may
   never set Complete, so this was transcribed as the user's decision, not made.
2. Phase 04 was moved to **Complete**, Phase 05 to **In Progress**, in both
   `project-specifications/PHASE-STATUS.md` and the two phase files.
3. Exactly one Phase 05 source file was written, and it is a header with no
   implementation yet: `NexusEditor/Public/NexusHierarchyModel.h`.

## Build state — important

**Nothing was built and nothing was tested this session.** The tree is still
buildable: `NexusHierarchyModel.h` is not `#include`d anywhere, and UBT compiles
translation units, so an orphan header does not break the build. It has no `.cpp`.

Four `UnrealEditor.exe` processes were live during this session, so a build would
have failed on locked DLLs regardless. **Close the editor before building.**

## What the Phase 04 acceptance record says, and why it is worded that way

The acceptance is recorded as resting on E1 (three clean builds), E2 (64/64
tests), and the user's own editor session — explicitly **not** as an itemised
eleven-of-eleven pass of
`evidence/phase-04-e3-manual-checklist-2026-08-23.md`, because the user did not
report the items back one by one. F-E3-03, the focus-recursion stack overflow
that has no automated guard, is recorded as covered by the session not crashing
rather than by a repro of the tab-switch/Refresh sequence that caused it.

If the user later confirms they did work through the eleven items, upgrade that
wording in `PHASE-STATUS.md` and `phases/phase-04.md`. Do not upgrade it on
inference.

**Closed on 2026-08-23, after this log was first written.** The E3 record is no
longer a loose end. All eleven **Result:** fields in the checklist now read *"Not
reported individually"* and point at a new **Run 2** section that states what the
acceptance rests on and what it does not; `evidence/phase-04-commands-2026-08-23.md`
had its Verdict, its fifth gate item, its structural-scan capture, and its first Open
item rewritten to match. Nothing was upgraded to a pass. Running items 1–11 on a
current build is still what would turn the session acceptance into an itemised
record — that remains available, not required.

## Phase 05 design that was settled before the session ended

Read `V7-UX-SPEC.md` §7 (Hierarchy tab), §17.2 (hierarchy states), §19 and §21,
plus `V7-ARCHITECTURE.md` §7 and §12. The plan below is consistent with all of
them and with the existing code, which was read in full.

### The data already exists — do not invent identity

- `FNexusSelectionKey` (kind + `FNexusId` GUID) in `NexusCoreTypes.h` is already
  the stable row key §7.2 asks for. Use it. Never key a row by index or name.
- `INexusRepository` (`NexusEditor/Public/NexusRepository.h`) already gives
  `GetRootEntities`, `GetChildren`, `FindEntity`, `FindActivationPoint`, a
  revision, and `OnChanged(Hint, ChangedIds)`. Reads go through it; **writes only
  through `INexusCommandService`**.
- Hierarchy levels come from `ENexusEntityKind`; rows are
  `FNexusAuthoringRecord` (parented by `ParentId`) plus
  `FNexusActivationPointRecord` (parented by `AnchorId`).

### Planned files

In `NexusEditor` (no Slate, so all of it is provable in automation):

| File | Holds |
|---|---|
| `Public/NexusHierarchyModel.h` | **written** — badges, `FNexusHierarchyNode`, `FNexusHierarchySnapshot` |
| `Private/NexusHierarchyModel.cpp` | not written — build, patch, ancestors, subtree, flatten |
| `NexusHierarchyQuery.h/.cpp` | `type:`/`status:`/`is:`/`id:`/`path:` parse, AND across categories and OR within one, chips, ancestor-context filtering |
| `NexusSelectionModel.h/.cpp` | click/ctrl/shift, select-all-visible, invert, back/forward history, stale-key reconcile |
| `NexusHierarchyFavorites.h/.cpp` | user-local favorites by stable key, unresolved entries kept not dropped |
| `NexusSyntheticHierarchy.h/.cpp` | the deterministic fake data source §21 mandates |
| `Private/NexusHierarchyCommands.cpp` | the 19 Phase 05 handlers |

In `NexusEditorUI`: `SNexusHierarchyTree.h/.cpp`, wired into
`SNexusShellSurface::BuildSectionContent` where `SectionTree` and `SectionFilters`
currently fall through to `SNexusStateView`.

In `NexusTests`: `NexusHierarchyTests.cpp`, suite `Nexus.V7.Hierarchy.*`.

Then: `Scripts/VerifyPhase05Hierarchy.ps1` (copy `VerifyPhase04Commands.ps1` and
move the expected counts), an evidence record, an E3 checklist, and a log.

### The 19 Phase 05 commands are already in the catalog

`NexusCommandCatalog.cpp` lines ~438–584, each `.Phase(5)`: RevealInTree,
CopyName, CopyId, CopyPath, SelectAllVisible, InvertVisibleSelection,
ClearSelection, SelectionBack, SelectionForward, AddFavorite, RemoveFavorite,
ManageFavorites, ExpandAll, CollapseAll, ExpandSelection, CollapseSelection,
FocusSearch, ClearSearch, SaveSearch.

Do **not** hand-write a second command list — `V7-ARCHITECTURE.md` §7 forbids it.
Register a handler per id and move
`NexusCommandCatalog::DeliveredThroughPhase` from 4 to 5 only once every one of
those 19 genuinely works, since that constant is what makes unbuilt commands
refuse by name.

### The problem Phase 05 has to solve first: there is nothing to show

Nothing in the editor calls `SetActiveDocument` — only tests do. Phase 07 owns
the authoring entry point (finding F-09), so the shell has reported Empty since
Phase 03 and a tree built now would be empty at E3 too.

Settled approach: `FNexusSyntheticHierarchy` builds a transient
`UNexusWorldDefinition` deterministically (GUIDs hashed from seed plus index, so
runs reproduce), covering the §21 shapes — empty, normal, deep, wide, invalid
(duplicate names, missing parents, cycles), and 100,000 rows. Expose it through
**editor console commands** (`Nexus.Fixture.LoadSample`, `Nexus.Fixture.Clear`),
never a menu entry. Console commands are developer tooling, so this satisfies §21
and gives E3 real rows without Phase 05 claiming Phase 07's entry point or
leaving a dead menu item that would fail the Phase 08 freeze gate.

### The one gate that needs a deliberate seam

*"A one-item change does not require a visible full-tree rebuild."* The written
header already carries it: `FNexusHierarchySnapshot::GetRebuildCount()` and
`GetPatchCount()`. `ENexusRefreshHint::Records`/`Diagnostics` must patch only the
named rows; `Hierarchy`/`Document` may rebuild. Assert the counters — "it felt
fast" is not evidence.

## Carry this into Phase 05 above everything else

Phases 03 and 04 each shipped a surface that no click or keystroke could reach,
with every declaration test green — see
[Declared is not reachable](../declared-is-not-reachable.md). A tree row that
cannot be clicked passes every test about what it holds. Phase 05's guards have
to drive interaction: click, ctrl-click, shift-click, arrow keys, the context
menu, and the chords, against a real widget.
