# 2026-08-23 — Phase 04: the command system, and accepting Phase 03

Agent: Claude (Opus 5). Continues
[2026-08-23 Phase 03 UI shell](2026-08-23-phase-03-ui-shell.md).

## Phase 03 was accepted on the user's E3

The user performed the E3 pass at the editor and reported it done. That closes the
three manual gate items Phase 03 could not reach from automation: layout survival
across a restart, the focus path and absence of clipping in a live window, and the
user's judgement of visual quality. Phase 03 is **Complete**.

Recorded plainly in the phase file and the ledger that E3 rests on the user's own
inspection rather than on automation, and that no independent E0 review was
performed — the same shape as Phase 02. "Accepted" and "independently verified" are
different claims and a later reader must not read one as the other.

## The shape of Phase 04

Two new public headers in `NexusEditor`, six new sources in `NexusEditorUI`, one
new test file, and Phase 03's hand-written `TCommands` list deleted.

**The catalog is data.** `NexusCommandCatalog` holds sixty-three commands as one
table — id, label, description, category, menu group, icon, chord, shortcut scope,
synonyms, risk, expected duration, owning phase. The Window submenu, the toolbar,
context menus, the palette, and the Slate `FUICommandInfo` set are all generated
from it.

The judgement that mattered here was deleting `FNexusEditorCommands` rather than
extending it. Phase 03 left eight hand-written `UI_COMMAND` entries; keeping them
beside a sixty-three-row catalog would have meant two lists that agree today. The
whole point of the phase's acceptance gate — one implementation regardless of
invocation surface — is unprovable if there are two descriptions of what the
commands are. `Nexus.V7.Command.SurfaceParity` compares each surface to the catalog
precisely because there is nothing else to compare it to.

**The confirmation gate is in the service, and it checks the revision.** A command
declares itself destructive in the catalog; the service refuses to execute it
unless the invocation carries an approval whose command id, preview token, *and
document revision* all match a preview the service itself minted.

The revision check is the part worth remembering. Without it the gate is
ceremonial: a user approves a preview, the document changes underneath, and the
command runs against something the preview never described. With it, a stale
approval is refused by code with a message saying so. A destructive command that
cannot produce a preview is refused for that reason alone, so "we forgot to write
the preview" is a failing test rather than an unguarded delete.

**Every unbuilt command is registered and refuses by name.** Twenty-four commands
are implemented; the other thirty-nine get `FNexusPendingPhaseCommandHandler`,
which refuses with `Nexus.Command.NotYetDelivered` and names the delivering phase.

This is the Phase 03 defect generalised. That defect was one button wired to a
command that could only ever fail. The fix there was to name the phase instead of
pretending. Here that is the rule for the entire inventory: nothing can be offered
without either working or saying when it will, and
`Nexus.V7.Command.DisabledReasons` walks every later-phase command asserting its
refusal names its phase.

There is a real cost: two thirds of the palette is disabled on a fresh install.
Hiding them was the alternative and it is worse — the palette is where a user looks
when they cannot find a command, and a palette that hides most of the product sends
them out of the tool. Recorded as an open item so a reviewer does not read the
inventory as a claim that all of it works.

## The spec conflict, and how it was resolved

V7-UX-SPEC.md §15 permits a modal dialog for destructive confirmation.
`Nexus.V7.Shell.NotificationsAreNonModal` — which Phase 03 froze — forbids every
modal API in `NexusEditorUI`. Both cannot be satisfied by a modal.

Resolved by confirming inline: `SNexusConfirmationBar` is a region of the surface
directly under the toolbar that raises it, showing the consequence, the affected
count, and a named verb rather than a generic OK, with the safe control first and
holding keyboard focus. §15 *permits* a modal; it does not require one, and every
property it asks a modal to have — clear title, consequence, primary action, safe
default, keyboard focus — is satisfied here without one.

Recorded in `V7-ARCHITECTURE.md` §7 rather than only in the evidence, because
Phases 05 through 20 will add destructive commands and must inherit the decision
instead of rediscovering the conflict and reaching for a dialog.

## Where the scope rule ended up living

The Activity scopes started in the widget as a `MakeFilter` static. Moving them to
`NexusOperationHistory.h` beside the record was not a testing convenience, though
it made the test possible: which entries belong to "Blocking" is a property of an
operation, not of Slate, and a second view in a later phase must get the same
answer as the first.

The same reasoning kept `NexusEditor` types out of `NexusEditorUI`'s public
headers. `FNexusPendingConfirmation` carries the approval as plain fields —
command id, token, revision, count — and the module assembles the real
`FNexusCommandConfirmation` in the `.cpp`. `NexusShellFactory` exposes the palette's
rows as a plain struct and the Activity scope wording by integer index for the same
reason. The boundary is stated in `NexusShellStateProvider.h` and it would have
been easy to quietly widen it for the sake of one test.

## Negative proofs

Six guards were broken on purpose, built, run, and reverted across two runs.

The duplicate chord break failed **two** tests, not one: `Shortcuts` caught it in
the catalog, and `SurfaceParity` caught it because Slate's input binding manager
refused the second claim, so the command's actual chord came back empty against a
catalog saying `Ctrl+F`. Recorded that way rather than smoothed into a tidy
one-break-one-failure table — two independent detections of one defect is a
stronger result than one, and hiding it would have made the evidence less true.

## What tripped

`VerifyFoundation.ps1` scans for debt markers and `unimplemented` is one of them,
so `FillUnimplementedCommands` failed the structural scan. Renamed to
`FillPendingPhaseCommands`, which reads better anyway and matches its counterpart
`RemovePendingPhaseCommands`. Worth knowing before naming anything else: the
banned words are TODO, FIXME, session-only, mock, placeholder, stub, and
unimplemented, over the whole plugin and project Source tree.

`FKey::IsValid` needed `InputCore` in `NexusTests.Build.cs`. `FBindingContext` has
no virtual destructor, so `FNexusUICommands` cannot declare one `override`, and its
registrations are released from `Unregister()` rather than from the destructor
because releasing them needs a shared reference to `this`.

## State at the end of the session

Phase 04 is **Ready for Review**, which is the implementing agent's ceiling. Three
clean builds, 62/62 tests, zero automation warnings or errors, structural scan
PASS. E3 is not satisfied and one acceptance-gate item depends on it: whether menus
and shortcuts are understandable in a live editor. The gate script is
`Scripts/VerifyPhase04Commands.ps1`; evidence is
[phase-04-commands-2026-08-23.md](../../project-specifications/evidence/phase-04-commands-2026-08-23.md).

Nothing binds an authoring document from the editor yet — Phase 07 owns that entry
point per finding F-09 — so every command needing a document will refuse with a
document-related reason during E3. That is correct behaviour, and
`Nexus.V7.Command.ScriptedInvocation` asserts each such refusal carries a reason.

## E3 run 1 and the two defects it found — 2026-08-23

The user opened the editor against the Phase 04 review candidate and stopped at item
4 of the eleven-item E3 checklist.

**F-E3-01 — the palette swallowed any command that opens a surface.**
`SNexusCommandPalette::ChooseSelected` dispatched the chosen command and dismissed
the palette afterwards. `Show Keyboard Shortcuts` is implemented as the palette
reopened in shortcuts-only mode, so: dispatch asked the module for the shortcuts
list, the module found a palette already open and refocused it instead, then the
dismissal closed it. The command ran and succeeded and left nothing on screen.
Fixed by dismissing before dispatching, with both delegates copied to locals because
dismissing can destroy the widget. `OpenCommandPalette` additionally now only reuses
an open palette in the same mode.

**F-E3-02 — no keyboard shortcut could fire.** No widget in `NexusEditorUI` ever
called `ProcessCommandBindings`. All eleven chords were dead. Fixed by giving
`SNexusShellSurface` an `OnKeyDown` that routes into its command list, reporting
`SupportsKeyboardFocus`, and focusing the surface when its tab activates. Routing at
the surface rather than registering globally is also what keeps the chords
tab-scoped, which section 16.1 requires.

Two guards added — `Nexus.V7.Command.PaletteCommitOrder` and
`Nexus.V7.Command.ChordRouting` — each reinstated as the original defect, rebuilt,
and seen to fail by name while the other fifteen passed. Suite is now 17 command
tests, 64 total, and the gate script's expected count moved with it. Full gate re-run
as `-RunLabel 2026-08-23-e3fix`: three clean builds, 64/64, zero warnings, zero
errors.

The durable lesson is written up as [[declared-is-not-reachable]]. Both defects were
in the wiring between a correct model and the input that reaches it, and no test that
inspected the model could see either one.

**Not carried out:** E3 items 1, 2, and 5 through 11 were never reached, so the fifth
acceptance-gate item is recorded as Not met and the run restarts from item 1.

### F-E3-03 — the fix for F-E3-02 crashed the editor

`EXCEPTION_STACK_OVERFLOW` on clicking Refresh; four editor processes lost. The
tab-activation focus hook added for F-E3-02 recursed:
`FSlateApplication::SetUserFocus` notifies the dock stack,
`SDockingTabStack::OnFocusChanging` calls `SDockTab::ActivateInParent`, that fires
`OnTabActivated`, which set focus again. Fixed with a `bFocusingSurface` re-entrancy
guard plus an early return when the surface already holds focus.

No automated guard exists for it and the evidence says so: the recursion needs a real
dock tab in a real window, which `-NullRHI` automation does not have. Held instead by
a launch smoke test — engine initialized, 150 s alive, zero crash markers — and
explicitly assigned to E3 run 2.

The sharper lesson, on top of [[declared-is-not-reachable]]: for the time between the
F-E3-02 fix and this one, the evidence record asserted both defects were fixed and
verified, with E1 and E2 green, on a build that crashed on the first Refresh. Green
automation over a build nobody has launched is a statement about the automation. When
a fix touches editor-only wiring that the headless suite cannot reach, launch the
editor before writing the word "verified".
