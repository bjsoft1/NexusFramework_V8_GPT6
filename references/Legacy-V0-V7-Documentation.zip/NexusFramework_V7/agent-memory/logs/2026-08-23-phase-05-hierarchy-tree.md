# 2026-08-23 — Phase 05 Hierarchy Tree View implemented

Supersedes the implementation plan in
[the Phase 05 handover](2026-08-23-phase-05-hierarchy-handover.md), which was written
mid-task when the previous session ran out of budget. The plan it carried was followed
almost exactly; the differences are recorded below.

## What shipped

Ten new source files. `NexusEditor` gained the whole decision-making layer, which has
no Slate in it and is therefore driven directly by automation:

- `NexusHierarchyModel` — `FNexusHierarchySnapshot`, ten row badges.
- `NexusHierarchyQuery` — `type:` `status:` `is:` `id:` `path:`, chips, four sort modes.
- `NexusSelectionModel` — click, ctrl, shift-range, arrows, history, reconcile.
- `NexusHierarchyFavorites` — user-local, ordered, unresolved entries kept.
- `NexusHierarchyView` — expansion, search, saved searches, scroll anchor, five states.
- `NexusHierarchyCommands` — the nineteen Phase 05 handlers.
- `NexusSyntheticHierarchy` — the deterministic fixture source.

`NexusEditorUI` gained `SNexusHierarchyTree`, wired into `SNexusShellSurface` where
`SectionTree` and `SectionFilters` previously fell through to `SNexusStateView`.
`NexusTests` gained `NexusHierarchyTests.cpp` — fourteen tests, `Nexus.V7.Hierarchy.*`.

`NexusCommandCatalog::DeliveredThroughPhase` moved 4 → 5.

## Where the plan changed

1. **Sorting was added.** The plan did not mention it; the phase task list asks for
   "deterministic sorting", so `ENexusHierarchySort` has four modes and every one falls
   back to the stable ID, with `SearchAndFilter` asserting determinism across all four.
2. **No `Loading` state.** The task list asks for one. The snapshot is built
   synchronously, so no frame is drawn during a build and a loading state could never
   render. Recorded as a deliberate omission in the evidence rather than faked.
3. **`SNexusHierarchyRow` is declared in the header, not kept private to the .cpp.**
   That is what lets `Nexus.V7.Hierarchy.RowsAreReachable` build a real row and send it
   a real `OnMouseButtonDown`, instead of calling the handler behind it. Calling the
   handler proves the handler works and says nothing about whether the row can be
   pressed — which is the exact gap that let Phases 03 and 04 each ship an unreachable
   surface.
4. **The tree is an `SListView`, not an `STreeView`.** Expansion belongs to the view
   model, and `STreeView` would own a second copy of it. The list is virtualized over
   the view model's visible rows and the list's own selection is switched off for the
   same reason.

## Four defects the guards caught before the editor was opened

Worth carrying forward, because this is the outcome Phase 05 was structured to produce.

1. **`Nodes[NodeIndex].ChildIndices.Add(AppendPoint(...))`** — C++ evaluates the object
   expression before the argument, so the address of `ChildIndices` was taken and then
   invalidated by the reallocation the append performs. Survived 92 rows; access
   violation at 100,000. **The general lesson: never index a container in the same
   expression as a call that can grow it.**
2. **Two fixture shapes shared identities.** IDs hashed from seed and row index meant
   `Deep` and `Normal` at the same seed produced the same GUIDs *and* the same kinds at
   the same depths, so selection keys collided across documents. A switch then looked
   exactly like a stale-key bug. The shape is now folded into the seed.
3. **An unquoted two-word search matched 72 rows, not 1** — correct behaviour (bare
   words are ORed), wrong test. Both readings are now pinned.
4. **Two order-dependent assertions**: `Focus Search`'s refusal depended on whether the
   running editor already had a Hierarchy tab open, and the snapshot counters carry
   across tests on the process-wide view model. Both are now isolated.

## Things a later phase will need to know

- **Five badges have no data source.** Dirty, Inherited, Verified, Draft, and Conflict
  have glyphs, reasons, draw order, and coverage, and nothing in the persisted record
  can set them. Deriving them from something plausible would put markers on rows that
  mean nothing. Phase 07 owns drafts and dirty state; the validation phases own the
  rest.
- **The fixtures have no menu entry and must not gain one.** `Nexus.Fixture.LoadSample`
  and `Nexus.Fixture.Clear` are console commands precisely so Phase 05 does not claim
  Phase 07's authoring entry point or leave a dead menu item for the Phase 08 freeze
  gate to find.
- **`FNexusHierarchyView::Get()` is process-wide** and bound by
  `UNexusEditorSubsystem::Initialize`. A test that takes it over must give it back;
  `FScopedViewBinding` in the test file is the pattern.
- **Escalation from patch to rebuild is deliberate** in three cases: an unknown changed
  ID, a moved `Kind` or `SortOrder`, and a `Records` hint with no IDs. Each would
  otherwise produce a plausible-looking wrong tree.

## State at the end of the session

Phase 05 is **Ready for Review**, which is the implementing agent's ceiling. E1 (three
clean builds) and E2 (the full regression suite) are green with zero warnings. E3 has
**not** been run; two of the five acceptance-gate items name it, and
`evidence/phase-05-e3-manual-checklist-2026-08-23.md` is the sixteen-item script.

Four `UnrealEditor.exe` processes were running throughout and the clean builds
succeeded anyway. The gate script warns about them rather than refusing, because
closing someone else's editor is not a script's decision.
