# 2026-08-31 — Bounded Details selection

Phase 08's remaining scale failure, F-08-04, was not a ceiling to relax. A real
Ctrl+A could select 100,000 items, and Details eagerly created a baseline/draft
proxy pair for every one. The normal command applies only materialized targets, so a
first-N shortcut would have made the editor silently apply to a subset of the visible
selection.

The correction keeps all selected keys and their order. At more than 1,000 keys,
SelectionDeferred reports an explicit summary-only Details state and refuses property
editing, Apply, Revert, and revert preview. A pre-existing dirty proxy from a
still-selected entity may remain dormant solely for recovery and is revision-checked
on return to a small selection. Drafts outside the active binding retain their
baselines for recovery capture; a large existing recovery record restores into the
same parked store without bypassing the editing limit.

Tracing the real route found another problem: UNexusEditorSubsystem itself performed
an O(n-squared) order-preserving dedupe before Details saw the keys. It now uses a set,
and a regression drives that exact subsystem route rather than bypassing it.

The Development Editor target compiled successfully but was non-clean and non-gating.
The Phase 08 E2 gate run with -SkipBuilds reported 148 tests and 21 budget
measurements, all passing. The gate script was corrected so such runs explicitly
report E2-only rather than falsely implying E1 passed. This is not Phase 08
acceptance: clean target builds, E0, E3, seven task lines, and F-08-06 remain. Full evidence is in
project-specifications/evidence/phase-08-large-selection-2026-08-31.md. See also
[[large-details-does-not-mean-partial-batch]].
