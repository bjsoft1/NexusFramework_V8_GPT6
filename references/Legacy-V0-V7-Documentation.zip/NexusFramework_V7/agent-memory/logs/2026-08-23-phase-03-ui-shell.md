# 2026-08-23 — Phase 03: the UI shell, and accepting Phase 02

Agent: Claude (Opus 5). Continues
[2026-08-23 Phase 02 evidence and carried findings](2026-08-23-phase-02-evidence-and-carried-findings.md).

## Phase 02 was accepted with E0 waived

The user inspected the editor, reported no crash and a visible dockable panel, and
asked for the next phase a second time after the E0 gap had been explained. That is
their acceptance decision, so Phase 02 is **Complete** — but the ledger, the phase
file, and the README all now say in as many words that E0 was *waived, not
satisfied*, because "accepted" and "independently verified" are different claims and
a later reader must not confuse them. The boundary claims an E0 review would have
checked are held instead by `Nexus.V7.Module.RuntimeBoundary` and
`Nexus.V7.Module.HostDatasetContract`, both proven by being made to fail.

## What the shell is

Twenty-one new files in `NexusEditorUI` behind six new public headers, and the two
Phase 01 preview-panel files deleted. The shape that matters:

**State derivation is a pure function.** `DeriveShellState(FNexusShellSignals)` maps
any combination of signals onto exactly one of nine states, and
`MakeShellStatus(Surface, Signals)` turns that into a headline, an explanation, and
at most one action. Neither touches the editor. That single decision is what lets
Phase 03's central requirement — every state has an intentional presentation — be
proven exhaustively in automation rather than by looking at the editor and hoping.

**The provider is the only window outward.** `INexusShellStateProvider` has two
implementations: `FNexusEditorShellStateProvider`, which reads
`UNexusEditorSubsystem`, and `FNexusStaticShellStateProvider`, whose signals are set
directly. Tests use the second to drive the real widgets through all twenty-seven
surface-by-state combinations. No widget can reach a mutation path it was not handed.

**Nothing invented is displayed.** Blocking and warning counts come from conditions
the document can genuinely report today — future schema, a save that would lose
data, migration on load. Where a capability does not exist yet, Home names the phase
that brings it instead of drawing an empty box, and the command palette sits in the
context strip disabled with its reason rather than being hidden.

## Two things worth remembering

**Contrast is testable, so it was tested.** The palette is defined from sRGB hex via
`FLinearColor::FromSRGBColor`, which makes the stored values genuinely linear, which
in turn makes WCAG relative luminance correct to compute directly from the channels.
`Nexus.V7.Shell.PaletteContrast` holds body text to 4.5:1 and every state colour to
3:1 on all three surfaces. Writing the palette as `FLinearColor(r/255, ...)` instead
would have made every figure wrong by roughly a factor of two while still looking
plausible. See [[verify-claims-by-re-running]].

**Three regions do not fit in a docked tab, and min-widths hide that.** The first
draft gave each region an SSplitter `MinSize` of 180, which reads as safe and is
not: three of them need 540 units before padding, wider than a normally docked
Unreal tab, and SSplitter overflows rather than shrinking below a minimum — so the
shell would have clipped its own navigation and nobody would have found out until
E3. The fix is a rule instead of a minimum: `NexusShell::GetRegionVisibility(Width)`
drops the third region below 720 and swaps the rail for a horizontal strip below
420. Keeping it a pure function of width is what makes the breakpoints testable,
including the assertion that whatever survives a breakpoint actually fits inside it.

**The user found the one place I broke my own rule, in about a minute.** Every
unbuilt capability in this shell names the phase that delivers it — except the Empty
state, which offered "Create a document" wired to `Nexus.Document.Initialize`. That
command refuses when no document is open, which is the only condition the Empty
state is shown under, so the button could not ever succeed. Behind it sat a second
defect: `ReportFailure` had no way to be cleared, so the surface stayed on the
failure message until the editor restarted. The structural fix is that an action now
carries an explicit `ENexusShellActionKind` instead of the implicit "run the command
if one is named, otherwise navigate" — implicit routing is what let a label and a
command disagree — plus a `CanExecute` check before any command runs, and a
dismissible Failure. The lesson is narrower than "test more": a rule that every
other state follows is worth asserting mechanically, because the one exception is
the one that ships.

**`SlatePrepass` turns a manual DPI check into an automated one.** Constructing each
surface and laying it out at 1.0 and 2.0 scale catches null brushes, zero-sized
regions, and layout that collapses under scaling, without a person resizing the
editor. It does not replace E3 — tooltip placement and the keyboard focus path still
need eyes — but it removes the part of "verify high-DPI scaling" that a machine can
actually do.

## Traps hit

- Inside `namespace NexusStyle`, an unqualified `ToString(State)` is ambiguous
  against the global `ToString` overloads from Json and LogVerbosity. Qualify it.
- `GEditor->Trans->GetQueueLength()` needs `Editor/Transactor.h`; `Editor.h` only
  forward-declares `UTransactor`.
- A private dependency's public dependencies give include paths but not link
  symbols. `NexusEditorUI` had to name `Engine`, `EditorSubsystem`, and
  `NexusAuthoring` itself.
- `VerifyFoundation.ps1` fails on the words *placeholder* and *mock* anywhere in
  source, including inside a comment explaining that something is deliberately not
  one. Reword rather than argue: the scan is blunt on purpose.

## State at the end of this session

Phase 03 is **Ready for Review**. On the delivered tree: 3/3 clean builds and 47/47
tests (14 `Nexus.V7.Shell`, 12 `Nexus.V7.Module`, 21 `Nexus.V7.Foundation`) with
zero automation warnings or errors, and a passing structural scan.

Evidence: `project-specifications/evidence/phase-03-ui-shell-2026-08-23.md`.

Not done: **E3**. Three acceptance-gate items need a person at the editor — layout
survival across a restart, the focus path and clipping in a live window, and the
user's judgement of visual quality. Phase 04 cannot start until the user accepts
Phase 03 as Complete. See [[v7-phase-governance]].
