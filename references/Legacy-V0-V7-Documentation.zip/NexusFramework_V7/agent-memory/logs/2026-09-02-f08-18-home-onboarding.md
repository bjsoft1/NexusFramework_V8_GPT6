# 2026-09-02 — F-08-18: Home's onboarding badges and text made honest

The same E0 review that filed E0-01 (fixed as F-08-17) also filed **E0-03,
Warning**: `SNexusHomeView`'s four onboarding badges included two
(`ENexusShellState::Empty`, hardcoded) that never reflected real state, and two of
the four step bodies said "...arrive with Phase 05" / "...arrive with Phase 06" —
true when this widget was written in Phase 03, false since those phases shipped, and
never revisited. The review also noted zero test coverage existed for this widget at
all.

**Fix.** Refactored the inline step computation in `HandleStateChanged()` into
`SNexusHomeView::ComputeOnboardingSteps(const FNexusShellDocumentInfo&)`, a static,
pure function with no Slate dependency — the same shape `DeriveShellState` already
proved works well for exactly this kind of state-to-presentation mapping. Steps 3
("Edit in Details") and 4 ("Resolve findings in Activity") now use the same
`ContentStep` signal (`EntityCount > 0`) step 2 already computes, rather than a new
invented one: editing a property or reviewing activity both need an entity to act on,
same as building the hierarchy does. Steps 2 and 3's text now describes the
capability as delivered and live instead of arriving with a named phase (step 4's
text already read that way).

**New public surface**, mirroring how `HomeRecoveryRunsCommands` already lets
`NexusTests` reach a private `NexusEditorUI` widget without crossing the module
boundary: `FNexusHomeOnboardingStepInfo` in the public `NexusShellTypes.h`, and
`NexusShell::GetHomeOnboardingSteps(...)` in `NexusShellFactory.h`, implemented in
`SNexusShellSurface.cpp` (same module as the private `SNexusHomeView.h`) as a thin
forward to the static method.

**New test**, `Nexus.V7.Shell.HomeOnboardingReflectsRealState` — the widget's first
ever — asserts all four steps against three document states (no document / bound, no
content / bound, with content) and that no step's body names a future phase once it
reads Ready.

**Verified by re-running**: isolated test passed on the first run after the
refactor; full clean gate (`Scripts\VerifyPhase08UiGate.ps1`) confirmed `PASS: 158
tests, 0 failures`, `PASS: 21 budget measurements, 0 over`, `PHASE 08 E1+E2: PASS`.
Shell's count moves 20 → 21, exactly the one new test.

Full account:
[evidence/phase-08-f08-18-home-onboarding-2026-09-02.md](../../project-specifications/evidence/phase-08-f08-18-home-onboarding-2026-09-02.md).
Does not move Phase 08's status: E3 has not run, F-08-06 and F-08-15 still need the
user's reading, and E0-02 from the same review remains open.
