---
name: a-state-needs-a-writer-not-just-a-reader
description: A presentation state can be exhaustively derived, presented, and precedence-tested while nothing in the product ever sets the signal behind it; test the producer, not the derivation.
metadata:
  type: feedback
---

When a type enumerates presentation states, the test that assigns the signals by hand
and checks the output proves the **derivation**. It says nothing about whether the
product can ever produce those signals, and the two look equally green.

V7 shipped `ENexusShellState::Stale` documented, derived by `DeriveShellState`, ranked
in the precedence order, given a headline and a detail by `MakeShellStatus`, and
covered by cases in both `Nexus.V7.Shell.StateDerivation` and
`Nexus.V7.Shell.StatePresentation`. `FNexusEditorShellStateProvider::GetSignals` read
`bSourceStale` from a member **nothing in the editor had ever written**;
`SetSourceStale` had no caller outside its own header.

It was not a state V7 did not need. `FNexusDetailsView::IsDraftStale` detects exactly
what the state describes and Apply refuses while it holds — so the panel was telling
the user their edit could not be committed while the context strip beside it said
`Dirty`. Recorded as F-08-09 on 2026-08-28.

**Why:** an undelivered *command* announces itself — `OwnerPhase` plus
`FNexusPendingPhaseCommandHandler` makes it refuse by name. A state has no equivalent.
An unreachable one is indistinguishable from a reachable one from the enum, the
derivation, the presentation, and every test over those three.

**How to apply:**

- For every state enum, write one test that drives the **real provider** over the real
  subsystem into each state through a real condition, and assert the set it reached has
  as many members as the enum. `Nexus.V7.UiStates.EveryShellStateHasARealProducer` is
  the pattern; a state added later then fails until something can enter it.
- When auditing, grep for the **writer** of a signal, not its readers. Readers are
  plentiful and prove nothing.
- Two producers of one state need two explanations. The shell keeps `bSourceStale` for
  the Phase 09 landscape source and ORs in the draft answer, with a separate Home
  health line for each, because one chip cannot say which staleness is meant.
- A state that *ends* without a signal needs its own subscription. Draft staleness
  starts on a repository change and ends on a revert, which moves no revision — so the
  provider subscribes to `FNexusDetailsView::OnChanged` as well.

See [[declared-is-not-reachable]], which is the same class for commands and widgets,
and [[measure-at-the-reachable-size]].
