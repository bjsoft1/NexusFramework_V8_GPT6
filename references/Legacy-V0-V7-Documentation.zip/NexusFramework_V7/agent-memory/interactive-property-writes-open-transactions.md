---
name: interactive-property-writes-open-transactions
description: A transactable IPropertyHandle write opens an editor transaction that stays open until a finishing write; abandon the edit and undo dies for the whole session.
metadata:
  type: reference
---

Writing through an `IPropertyHandle` is not a plain value assignment. Read
`FPropertyValueImpl::ImportText` in
`Engine/Source/Editor/PropertyEditor/Private/PropertyHandleImpl.cpp`:

- `bTransactable = (Flags & EPropertyValueSetFlags::NotTransactable) == 0`
- `bFinished     = (Flags & EPropertyValueSetFlags::InteractiveChange) == 0`

`GEditor->BeginTransaction` is called on the first **interactive** write, and
`GEditor->EndTransaction` only on a later **finishing** write. Between the two the
transaction is open by design — that is how a slider drag or a typed word becomes one
undo step.

**The trap.** Any path that starts an interactive write and never performs the
finishing write leaves the transaction open forever. `UTransBuffer::CanUndo` returns
false whenever `ActiveCount != 0`, so an open transaction does not corrupt undo, it
**removes undo and redo entirely for the rest of the session**. Nothing logs, nothing
asserts, and the only symptom is that `Ctrl+Z` stops responding.

Escape handlers, early returns on `ETextCommit::OnCleared`, and anything that rebuilds
a panel mid-edit are the paths that do this — the handle is destroyed while its
transaction is still open. V7 shipped exactly that bug; see
[[v7-phase-governance]] for why it reached a human rather than a test.

**How to apply.** When a details row edits a *transient draft proxy* rather than the
document, always pass `EPropertyValueSetFlags::NotTransactable`. The proxy is
`RF_Transient` and not `RF_Transactional`, so `Modify()` records nothing and
`UTransBuffer::End` pops the finished transaction as `IsTransient()` anyway — the
transaction was never buying anything, and could only leak. The undoable step belongs
on the command that writes the document, under its own `FScopedTransaction`. This is
enforced by `Nexus.V7.Module.UiMutationBoundary`, which is a source scan because the
defect compiles cleanly; see
[[command-service-is-the-only-mutation-path]].

**Diagnosing it.** `GEditor->IsTransactionActive()` is the direct check. A test that
means to assert undo works should assert this is false rather than only asserting that
values round-trip, because a dangling transaction makes `UndoTransaction()` return
false rather than restore the wrong thing.
