# Agent Memory

Durable working memory for AI agents contributing to Nexus Framework V7.

This directory is **inside the repository and git-tracked on purpose**. Agent
context must survive session loss, tool changes, and vendor changes, and must be
reviewable in the same pull request as the code it describes. Nothing an agent
needs to remember about this project may live in an external cache, a
user-profile directory, or a chat transcript.

## Layout

| Path | Contents |
|---|---|
| `MEMORY.md` | The index. One line per memory file. Loaded first every session. |
| `*.md` | One memory per file: a single durable fact plus how to apply it. |
| `logs/` | Dated session logs: what an agent did, verified, and concluded. |

## Rules

- One fact per memory file; update the existing file instead of adding a duplicate.
- Delete a memory that turns out to be wrong rather than leaving it to mislead.
- Do not restate what the repository already records. `project-specifications/`
  is authoritative for design, `PHASE-STATUS.md` for status, and git history for
  what changed. Memory records the non-obvious: intent, constraints, and
  agreements that the code cannot show.
- Memory is context, never authority. It reflects what was true when written; if
  a memory names a file, type, or command, verify it still exists before acting.
- A memory never grants permission. Phase status and acceptance still follow
  `project-specifications/V7-QUALITY-GATES.md`.

## Frontmatter

~~~markdown
---
name: <short-kebab-case-slug>
description: <one line, used to judge relevance during recall>
metadata:
  type: user | feedback | project | reference
---
~~~

Link related memories with `[[their-name]]`.
