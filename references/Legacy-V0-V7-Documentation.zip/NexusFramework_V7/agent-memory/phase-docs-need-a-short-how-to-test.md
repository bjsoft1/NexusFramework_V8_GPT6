---
name: phase-docs-need-a-short-how-to-test
description: Every completed phase or sub-phase must publish a 5-6 point How to Test written for a person clicking the UI, plus the console command that generates test data.
metadata:
  type: feedback
---

When a phase **or sub-phase** is finished, it must carry a **How to Test** section of
**five or six numbered points**. Each point is one action and one expected result, in
a line or two. Commands are verbatim so they can be pasted. It goes in
`project-specifications/phases/phase-NN.md` and near the top of that phase's evidence
record — before the design narrative, not after it.

**The user-facing handoff is part of the requirement.** Repeat the same five or six
short points in the response that presents the finished phase or sub-phase. Lead
with the phase's true status, and if the latest source has not been built or tested,
say that before the checklist rather than implying the UI is ready to verify.

**Write it for someone clicking the UI, not reading the code.** Every point a person
performs must name what they click, type, or press, and what they should see. "Verify
the selection model handles multi-select" is not a test step; "Click a row, then
`Ctrl`-click two more → all three highlight and the breadcrumb follows the last one"
is. A QA reader must never have to open a source file to know what to do.

**Give the data-setup command.** If the phase can be exercised against generated
data, the section must say how to produce it. For V7 that is the developer fixture,
registered by `FNexusSyntheticHierarchy::RegisterConsoleCommands` and typed into the
editor console:

~~~text
Nexus.Fixture.LoadSample <Empty|Normal|Deep|Wide|Invalid|Large> [Seed]
Nexus.Fixture.Clear
~~~

`Normal` is a small healthy tree, `Deep` one long chain, `Wide` one parent with
several hundred children, `Invalid` duplicate names plus a missing parent, a cycle,
and an unanchored point, and `Large` one hundred thousand rows for the scale checks.
The seed is optional and the shapes are deterministic, so two people running the same
line see the same document.

**The fixture is in-memory and cannot be saved.** It is right for shape, scale,
filtering, selection, and layout, and wrong for anything about persistence: CRUD,
save, dirty state, reload, and the restart check all need a real asset made with
**New Document**, and `Nexus.Document.Save` refuses a fixture by name. Say which of
the two a point needs, or QA will use the convenient one and get a refusal that looks
like a defect.

**Why:** The user asked for the 5-6 point form on 2026-08-24, after Phase 07's
evidence ran to 258 lines with the commands buried inside it, and extended it on
2026-08-27 to require UI-level steps and the data-generation command, so QA can run a
phase without reading the implementation. These records are written to be
*re-executed* rather than read — see [[verify-claims-by-re-running]] — and that only
works if a person can find the steps in seconds and perform them without help.

**How to apply:** Cover both halves in the six points — what automation proves and
what a person still has to look at. Name the gate script and its exact expected
output line first, then the data-setup command if one applies, then the three or four
manual checks carrying the most risk. Point at the full E3 checklist for the complete
run rather than reproducing it. Prefer a check that has caught something before: the
undo-after-slider-drag step in `phase-06.md` exists because
[[interactive-property-writes-open-transactions]] shipped green. This does not replace
the E3 checklist or shorten the evidence record — it is the way in to both. See
[[v7-phase-governance]] for who may act on the result.
