---
name: a-global-singleton-view-can-fight-a-headless-test
description: A real SNexusHierarchyTree widget, alive from workspace restoration even under -unattended -NullRHI, reacted to a test's own repository broadcast by pushing its own stale selection back onto the subsystem, clobbering the exact state under test.
metadata:
  type: feedback
---

`FNexusHierarchyView::Get()` and `FNexusDetailsView::Get()` are process-global
singletons, bound once at `UNexusEditorSubsystem::Initialize` and shared by every
real widget and every test that runs in the same `UnrealEditor-Cmd.exe` process. A
test that drives the real subsystem and broadcasts a repository change (e.g. calling
`RefreshAfterUndo()` directly, or anything that reaches
`Repository.NotifyChanged(...)`) is not driving an isolated sandbox — if a real
`SNexusHierarchyTree` happens to be alive (workspace/layout restoration can construct
one even in an unattended, `-NullRHI` run, since Slate widget construction does not
require an actual renderer), it reacts exactly like it would for a real user:
`SNexusHierarchyTree::Refresh()` calls `PushSelectionToEditor()`, which reads the
widget's *own* `FNexusSelectionModel` (never told about the test's entities) and
pushes it onto `UNexusEditorSubsystem::SetSelection`, which propagates into
`FNexusDetailsView::Get().SetSelection(...)` — silently overwriting whatever
selection the test had just set, moments after the test itself set it.

**Why:** Two different regression-test attempts for [[a-document-must-not-lose-unrelated-work-on-a-scoped-command]]'s
undo/redo cousin (F-08-17) failed with a symptom that looked exactly like the
production bug being fixed (drafts vanishing, `KeptDrafts` count wrong) — first when
selection was set directly on `FNexusDetailsView::Get()`, then again after switching
to the "correct," subsystem-routed `SetSingleSelection` API. Both failed the same
way because neither touched the actual source of interference:
`FNexusHierarchyView::Get()`'s own selection model, which only a real row click (or
the widget itself) normally updates. A captured callstack
(`FPlatformStackWalk::StackWalkAndDump`), not static reading, is what actually found
this — three rounds of plausible-looking static analysis missed it.

**How to apply:** A test that broadcasts a change on the real, global repository and
then asserts on selection- or draft-scoped state afterward should detach
`FNexusHierarchyView::Get()` from the repository for its duration
(`BindRepository(nullptr)`, restored via `ON_SCOPE_EXIT` to
`&Subsystem->GetRepository()`) — the same isolation
`Nexus.V7.Crud.DeleteRefreshesViews` already gets for free by binding its *own*
local `FNexusHierarchyView` instance instead of the global one. Any other test doing
the same kind of real-subsystem, real-repository broadcast and asserting on
downstream selection/draft state is equally exposed, whether or not it has hit this
yet. When a test's own diagnostic trace looks internally consistent but still
disagrees with the observed final value, suspect a listener outside the code you're
reading before suspecting the code itself.
