---
name: verify-claims-by-re-running
description: Evidence claims in this project must be re-executed, not read; the exact commands that work on this workstation are recorded here.
metadata:
  type: reference
---

V7 evidence records are written by agents, so a reviewer re-runs them rather than
reading them. These commands work on the reference workstation (UE 5.8.1 at
`C:\Program Files\Epic Games\UE_5.8`, project at
`E:\Projects\Game\UE\NexusFramework\NexusFramework_V7`):

~~~text
# E1 — editor build
Build.bat NexusFrameworkEditor Win64 Development -Project=<repo>\NexusFramework.uproject -WaitMutex -NoHotReloadFromIDE

# E1 — cold non-editor build, and the boundary proof
Build.bat NexusFramework Win64 Shipping -Project=<repo>\NexusFramework.uproject -WaitMutex -clean
Build.bat NexusFramework Win64 Shipping -Project=<repo>\NexusFramework.uproject -WaitMutex
# then read the [n/m] Compile lines: only NexusCore, NexusRuntime, NexusV7Host may appear

# E2 — foundation suite (21 tests)
UnrealEditor-Cmd.exe <repo>\NexusFramework.uproject -unattended -NullRHI -NoSplash -NoSound \
  -ExecCmds="Automation RunTests Nexus.V7.Foundation; Quit" \
  -TestExit="Automation Test Queue Empty" -log="<name>.log" -stdout

# Structural / boundary scan
powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyFoundation.ps1
~~~

**Gotcha:** passing `-abslog=<path>` to `UnrealEditor-Cmd.exe` made the process
exit after platform-SDK validation without running any test, while still returning
exit code 0. Use `-log="<name>.log"` (relative, lands in `Saved/Logs/`) and always
confirm the log actually contains `TEST COMPLETE. EXIT CODE: 0` plus one
`Result={Success}` line per test. A zero exit code alone proves nothing here.

**The Foundation suite is not enough for anything touching the compiled dataset.**
`Source/NexusV7Host/NexusV7Host.cpp` re-asserts about sixty fields of the compiled
fixture literally, and it lives in the game host target, not the plugin — so it is
invisible to a plugin-wide search and to every editor-side test. Change
`NexusRuntimeDatasetTestFixture.h` and you must change the host too, or the editor
build, all 21 tests, the cook, and the package will pass while the packaged
runtime exits 31 with `NEXUS_PHASE01_PACKAGED_DATASET_LOAD: FAIL`. Always finish
with `Scripts/VerifyPhase01CookPackage.ps1`. Recorded as F-10.

Evidence artifacts live under `Saved/Logs/`, which is gitignored, so they cannot be
verified from a clone — see F-05 in [[phase-01-e0-outcome]].
