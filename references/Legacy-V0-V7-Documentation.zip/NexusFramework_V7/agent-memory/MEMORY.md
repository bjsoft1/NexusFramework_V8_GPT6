# Memory Index

Read this first. One line per memory; open the file before relying on it.
Conventions and rules are in [README.md](README.md).

- [Agent memory lives in the repo](agent-memory-lives-in-repo.md) — memory and logs are committed here, never to an external cache.
- [V7 phase governance](v7-phase-governance.md) — an AI may never mark a phase Complete or Ready for Manual QA.
- [Phase 01 E0 outcome](phase-01-e0-outcome.md) — builds and tests reproduced, but two Blocking schema findings keep Phase 01 unaccepted.
- [Verify claims by re-running](verify-claims-by-re-running.md) — the exact build/test commands, and the flag that silently skips every test.
- [Command service is the only mutation path](command-service-is-the-only-mutation-path.md) — how to add a feature without breaking the UI/authoring boundary, and why executing on the service refreshes nothing.
- [Evidence scripts need dated artifact names](evidence-scripts-need-dated-artifact-names.md) — a fixed log filename overwrites the artifact an earlier phase cited by digest.
- [Shell palette is sRGB and contrast-tested](shell-palette-is-srgb-and-contrast-tested.md) — why UI colours are written as hex, and the ratios automation holds them to.
- [Declared is not reachable](declared-is-not-reachable.md) — two V7 phases shipped surfaces no keystroke or click could reach, with every declaration test green.
- [Interactive property writes open transactions](interactive-property-writes-open-transactions.md) — a transactable IPropertyHandle write left open kills undo for the whole session, silently.
- [Graph validation is not payload-type validation](graph-validation-is-not-payload-type-validation.md) — the Phase 01 validator also checks activation-point TypeKeys, which blocks every unrelated edit until Phase 14.
- [Phase docs need a short How to Test](phase-docs-need-a-short-how-to-test.md) — every finished phase or sub-phase carries and gives the user a 5-6 point UI test checklist, plus any console data command.
- [Virtualized rows can still do full-tree work](virtualized-rows-can-still-do-full-tree-work.md) — drawing ten widgets proves nothing about full input scans, hidden row copies, or document-sized Slate getters.
- [Destructive previews do not belong in eligibility](destructive-previews-do-not-belong-in-eligibility.md) — live menu guards may be polled every paint, so check preview capability there and materialize consequences only after invocation.
- [Measure at the reachable size](measure-at-the-reachable-size.md) — a budget checked only at the size the spec names passes while the same code hangs the editor.
- [Check unshipped phases before narrowing a contract](check-unshipped-phases-before-narrowing-a-contract.md) — they usually already assume the new shape, and they own the "dead code" you were about to delete.
- [A commit must name its own row](a-commit-must-name-its-own-row.md) — an editor that commits on focus loss writes to whatever the user clicked next, and every test agreed with it.
- [A state needs a writer, not just a reader](a-state-needs-a-writer-not-just-a-reader.md) — a presentation state can be fully derived, drawn, and precedence-tested while nothing in the product can enter it.
- [Nothing autosaves the document](nothing-autosaves-the-document.md) — two unrelated things named "autosave" and neither writes the asset; only the Save command does.
- [The bottom two rungs are not hand-authored](the-bottom-two-rungs-are-not-hand-authored.md) — Create offers State, City, Highway and stops, on purpose; points sync from the landscape and activation points come later.
- [Large Details does not mean partial batch](large-details-does-not-mean-partial-batch.md) — preserve a large ordered selection as a summary, never bind a first-N subset that Apply could silently mutate.
- [Reload can pre-update the pointer your guard checks](reload-can-pre-update-the-pointer-your-guard-checks.md) — UPackageTools::ReloadPackages silently repoints a rooted reference before your own explicit switch handler runs, defeating a pointer-equality no-op guard.
- [A document must not lose unrelated work on a scoped command](a-document-must-not-lose-unrelated-work-on-a-scoped-command.md) — Revert Draft's preview named only the selected entity, but its handler reset every parked draft in the document as a silent side effect.
- [A getter that aggregates can fail a narrow assertion](a-getter-that-aggregates-can-fail-a-narrow-assertion.md) — IsDirty() is document-wide by design; a new test assumed it was selection-scoped and failed against a getter that was already correct.
- [A global singleton view can fight a headless test](a-global-singleton-view-can-fight-a-headless-test.md) — a live SNexusHierarchyTree from workspace restoration reacted to a test's own repository broadcast and clobbered the selection state the test was checking.
- [A cross-cutting fix built on a per-path artifact inherits that path](a-cross-cutting-fix-built-on-a-per-path-artifact-inherits-that-path.md) — F-08-16 reused the confirmed preview, which only destructive commands build, so it covered only them; F-08-19 rebuilt the Activity summary on Result.ChangedIds, which every command carries.
- [Gate task lines carve out to the owning phase](gate-task-lines-carve-out-to-the-owning-phase.md) — F-08-05/06/15: a UI-gate line for a capability no shipped phase provides is closed done-for-what-this-phase-owns, carved out to the later phase, by a user reading — never placeholdered, never left open forever.

## Logs

- [2026-08-22 — Phase 01 E0 independent review](logs/2026-08-22-phase-01-e0-review.md)
- [2026-08-22 — Phase 02 module foundation](logs/2026-08-22-phase-02-module-foundation.md)
- [2026-08-23 — Phase 02 evidence and carried findings](logs/2026-08-23-phase-02-evidence-and-carried-findings.md)
- [2026-08-23 — Phase 03 UI shell, and accepting Phase 02](logs/2026-08-23-phase-03-ui-shell.md)
- [2026-08-23 — Phase 04 accepted, Phase 05 started (handover)](logs/2026-08-23-phase-05-hierarchy-handover.md)
- [2026-08-23 — Phase 05 hierarchy tree implemented](logs/2026-08-23-phase-05-hierarchy-tree.md)
- [2026-08-24 — Details panel killed undo outright (bug 4)](logs/2026-08-24-details-undo-regression.md)
- [2026-08-24 — Phase 07 full UI CRUD](logs/2026-08-24-phase-07-crud.md)
- [2026-08-24 — Delete confirmation popup, view refresh, copyable messages](logs/2026-08-24-confirmation-popup-and-refresh.md) — plus the rename `NoChange` fix and the save/dirty handover.
- [2026-08-27 — Shell chrome scoped, and who writes the asset](logs/2026-08-27-shell-chrome-and-save-ownership.md) — one banner per command instead of three, the save path that returns "cancelled" headless, and the Save command no click could reach.
- [2026-08-27 — The per-map document, and a deferral that should have ended earlier](logs/2026-08-27-per-map-document-and-default-seed.md) — V6's map-folder config asset restored as a dirty unsaved document, the Create Default seed, and why a correct phase-scope answer stopped being one on the third telling.
- [2026-08-28 — Phase 08: the budgets nobody had measured](logs/2026-08-28-phase-08-budgets.md) — the scale test that disclaimed being the scale measurement, and the four Blocking defects behind it.
- [2026-08-28 — The hierarchy ladder narrowed to four rungs](logs/2026-08-28-hierarchy-ladder-narrowed.md) — State > City > Highway > Highway Point, adjacent only; what the pre-flight phase-doc check caught before any code was written.
- [2026-08-28 — The shell state nobody could get into](logs/2026-08-28-ui-state-reachability.md) — nine states derivation-tested, one of them unreachable; plus the gate script that overwrote its own cited evidence and a modal dialog inside an unattended run.
- [2026-08-31 — Bounded Details selection](logs/2026-08-31-phase-08-bounded-details.md) — a 100,000-item Ctrl+A must stay whole without becoming a partial batch edit.
- [2026-08-31 — Phase 08 collapsed-tree idle lag](logs/2026-08-31-phase-08-collapsed-tree-lag.md) — a virtualized ten-root view was still doing 100,000-row work during broadcasts and paint.
- [2026-08-31 — Phase 08 row-menu hover lag](logs/2026-08-31-phase-08-context-menu-hover-lag.md) — destructive eligibility rebuilt Delete's full Large-document preview on every menu repaint.
- [2026-09-01 — Phase 08: dotnet.exe resolved, first clean E1+E2 pass, F-08-14](logs/2026-09-01-phase-08-f08-14-reload-rebind.md) — a reload silently pre-updated the pointer SetActiveDocument's no-op guard checks, so Recover Draft found nothing after a reload; caught by a regression test that had never actually run before.
- [2026-09-01 — F-08-15: payload CRUD task has the same gap as F-08-06](logs/2026-09-01-f08-15-payload-crud-untestable.md) — Phase 08's fixed/dynamic-array payload CRUD task line is untestable through the UI because no gesture creates an Activation Point yet; Phase 07 already recorded the same fact, Phase 08's own ledger hadn't.
- [2026-09-02 — F-08-16: Revert scoped to selection, and a wrong test assertion](logs/2026-09-02-f08-16-revert-scope.md) — Revert Draft no longer wipes unrelated kept drafts and Activity now records a real summary; re-running the gate found the commit's own new test asserted a document-wide getter should read selection-scoped.
- [2026-09-02 — F-08-17: Undo/Redo scoped, and a live widget fighting the test](logs/2026-09-02-f08-17-undo-redo-scope.md) — an E0 review's Blocking finding, fixed by deleting one redundant call; the regression test then fought a real SNexusHierarchyTree sharing the global Hierarchy singleton before a captured callstack found why.
- [2026-09-02 — F-08-18: Home's onboarding badges and text made honest](logs/2026-09-02-f08-18-home-onboarding.md) — two hardcoded badges and two stale "arrives with Phase X" bodies fixed by extracting a pure ComputeOnboardingSteps function, with the widget's first-ever test.
- [2026-09-02 — F-08-19: every successful command records what it did](logs/2026-09-02-f08-19-activity-summary.md) — E0-02 closed; F-08-16's Activity-summary fix reused a destructive-only artifact, so F-08-19 rebuilt it centrally on Result.ChangedIds. Every 2026-09-02 E0 finding now acted on.
- [2026-09-02 — F-08-06 and F-08-15 answered](logs/2026-09-02-f08-06-f08-15-decisions.md) — the two open Phase 08 readings: ownership-mismatch defers to Phase 10, payload CRUD satisfied by its service-level proof. Docs only. No finding waits on the user now; E3 does.
