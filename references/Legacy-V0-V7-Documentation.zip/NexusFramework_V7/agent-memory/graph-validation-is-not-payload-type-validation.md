---
name: graph-validation-is-not-payload-type-validation
description: The Phase 01 graph validator also checks activation-point payload types, which blocks every unrelated entity edit on any V7 document until Phase 14.
metadata:
  type: project
---

`ValidateOwnedDocumentGraph` in `NexusActivationPointCommands.cpp` validates two
different things under one name. The structural half — unique owned IDs, resolvable
parents, no parent cycles, resolvable anchors, losslessly persistable payloads — is
what any mutation needs. The last statement then calls `ValidateCandidate`, which
validates every `FNexusActivationPointRecord` against `FNexusPayloadTypeRegistry`.

**Nothing registers a payload type in this build.** The synthetic fixtures stamp
`Nexus.Synthetic.ActivationPoint`, which is unregistered, so any mutation routed
through the full validator on a document holding an activation point is refused with
`UnknownTypeKey` — including renaming a City, which has nothing to do with
activation points. Phase 14 owns the real payload type catalog; until it ships,
**every document in the project is in this state**.

**Why:** this cost the entire first run of the Phase 07 CRUD suite. Every test failed
at once, and the failures pointed at the entity service rather than at the validator,
because the refusal arrives as `GraphRejected` with an activation-point message
attached. Reading it as "my new code is broken" wastes the whole debugging pass.

**How to apply:** an entity or document mutation calls
`FNexusActivationPointCommandService::ValidateCandidateGraph`, which runs the
structural rules and stops before the registry check. Only an *activation point*
mutation should validate payload types. If you add a mutation and every test fails
with a message naming a TypeKey, this is why — do not "fix" it by registering a
fixture type, which would hide it again for real documents. Recorded in
`V7-ARCHITECTURE.md` §7. See [[command-service-is-the-only-mutation-path]] and
[[verify-claims-by-re-running]].
