---
name: large-details-does-not-mean-partial-batch
description: A large Details selection must remain whole in a summary-only state, never become a first-N batch that can silently mutate only a subset.
metadata:
  type: project
---

When Details has more than 1,000 selected keys, preserve the entire ordered selection
but enter SelectionDeferred and unbind materialized property targets. Do not optimize
by keeping the first N proxies while Apply remains available: the command applies only
the targets it receives, so that turns one visible selection into a hidden partial
batch.

A pre-existing dirty proxy for a still-selected entity may remain dormant solely for
recovery while deferred. When a selection narrows, rebuild it and keep the normal
source-revision staleness check. The actual hierarchy route also matters:
UNexusEditorSubsystem must deduplicate with an order-preserving set, not a linear
Contains scan per selected key. The regression pair is
Nexus.V7.Details.LargeSelectionDeferred and
Nexus.V7.UiGate.SubsystemSelectionForwarding.
