---
name: a-getter-that-aggregates-can-fail-a-narrow-assertion
description: A regression test assumed IsDirty() reflected only the current selection; it aggregates over parked drafts too, so a correct fix looked like a second bug until the getter's actual scope was checked against its other callers.
metadata:
  type: feedback
---

Before writing `TestFalse(..., SomeAggregateGetter())` to prove "the thing I just
fixed is clean," check what the getter actually walks — not what the scenario in
front of you suggests it walks.

`FNexusDetailsView::IsDirty()` is document-wide by design: it walks `KeptDrafts`
(every parked, off-selection draft) as well as the currently bound `Targets`. A new
test for [[a-document-must-not-lose-unrelated-work-on-a-scoped-command]] (F-08-16)
dirtied one entity, parked it, dirtied and reverted a second entity, then asserted
`IsDirty()` was `false` — which failed, because the first entity's parked draft was
still legitimately dirty. That looked like Revert had failed to clear something. It
had not; the assertion asked the wrong question. `GetDirtyTargetCount()`, scoped to
`Targets` only, was the getter that actually answers "did Revert clear the target it
ran against."

**Why:** `IsDirty()`'s document-wide scope was not a guess — an earlier, already
passing test (`Nexus.V7.Details.LargeSelectionDeferred`) already asserts `IsDirty()`
stays `true` for a dirty draft parked outside the interactive selection. The new test
contradicted an invariant the suite already proved, and re-running the actual gate
(never trusting a diff by inspection, per [[verify-claims-by-re-running]]) is what
surfaced the contradiction — a code reading would have had no reason to doubt either
line.

**How to apply:** When a new assertion on a shared/cached/aggregate getter fails,
grep the same file for other assertions on that getter before assuming the
production code regressed. If two tests want different scopes of the same concept
("is anything in this document unsaved" vs. "is the thing I just touched unsaved"),
that is a sign two different getters are needed, not that one of the tests is
obviously right.
