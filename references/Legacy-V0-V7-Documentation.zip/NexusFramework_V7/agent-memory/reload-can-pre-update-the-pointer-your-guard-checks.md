---
name: reload-can-pre-update-the-pointer-your-guard-checks
description: UPackageTools::ReloadPackages silently repoints every reachable reference to a reloaded object before your explicit switch handler runs, which can defeat a pointer-equality no-op guard.
metadata:
  type: project
---

`UNexusEditorSubsystem::SetActiveDocument` opened with `if (ActiveDocument ==
InDocument) { return Unchanged; }`, a reasonable fast path for callers where nothing
changed. It broke specifically for the Reload command: `ExecuteReload` calls
`UPackageTools::ReloadPackages` on the currently active document's package, and that
engine call performs its own reference-replacement pass over every still-reachable
reference to the old object — `ActiveDocument`, a rooted `UPROPERTY`, included —
*before* `ExecuteReload`'s own explicit `SetActiveDocument(Inner.Document, ...)` call
ever runs. By the time that call happens, `ActiveDocument` already equals
`InDocument`, the guard reads "unchanged", and the repository rebind, selection reset,
and both change broadcasts are all skipped. The repository is left holding a weak
reference to the object the reload just destroyed, and every downstream read (Details'
`Recover Draft` in this case) silently fails against it.

The failure was invisible for a full day of otherwise-passing evidence because the
one test that exercised the reload-then-recover path
(`Nexus.V7.Crud.RecoveryBeforeReload`) was added to the tree after the evidence run
that cited "148 passed" had already finished — it had literally never executed until
a later, unrelated full clean-build pass ran the whole suite for real. See
[[verify-claims-by-re-running]] and [[declared-is-not-reachable]] for the same
pattern in other forms: a claim of coverage is only as good as the run that produced
it, and code that has never actually executed can pass its own commit message.

**Why:** Any editor engine call that reloads, replaces, or garbage-collects a UObject
in place (`ReloadPackages`, `CollectGarbage`, asset reimport) can silently update
reachable strong references *ahead of* your own explicit hand-off logic, making a
`before == after` identity check lie about whether dependent state actually still
matches. This is not unique to `SetActiveDocument`; any code with a "did the object
I'm tracking actually change" fast path built on raw pointer or `TObjectPtr` equality
is exposed to it if anything upstream of that check can trigger such a replacement.

**How to apply:** When a caller *knows* it just performed an operation that can
silently reassign references ahead of it (a reload being the clearest case in this
codebase), do not trust a pointer-equality no-op guard on the object it produced —
force the downstream rebind explicitly rather than asking the guard to notice. Here
that is `SetActiveDocument`'s `bForceRebind` parameter, set `true` only by
`ExecuteReload`. Do not weaken the guard for every caller; New/Open/Close Document and
every other caller still benefit from the fast path being trustworthy for them.

**Independent read, 2026-09-01 (a peer session, `nexusframework-v7-17`, that did not
implement the fix; read-only, confirmed correct).** Two follow-ups worth carrying,
neither implemented yet:

- **A self-healing form is possible and stronger than the opt-in flag alone.**
  `Repository::Document` is a plain `TWeakObjectPtr` inside a non-`UObject` struct, so
  Unreal's reference-replacement pass never visits it — after a reload,
  `Repository.GetDocument() != InDocument` even though `ActiveDocument == InDocument`
  already lies. Widening the guard to
  `if (!bForceRebind && ActiveDocument == InDocument && Repository.GetDocument() ==
  InDocument)` would make the rebind happen automatically for *any* future caller
  that introduces a second silent-replace path (a Revert, a Reimport, another
  `ReloadPackages` site) without that caller needing to know to pass the flag — closing
  exactly the class of silent regression this lesson describes. **Caveat, and the
  reason this was not applied here:** it changes `Unchanged` semantics — any state
  where `Repository` has already drifted from `ActiveDocument` for some other reason
  now returns `Changed`, which could disagree with a test asserting `Unchanged`. Needs
  its own verification pass against the full suite before landing; keep
  `bForceRebind` as belt-and-braces regardless.
- **A same-shape, currently-unreachable site.** `BindDocumentForActiveWorld`
  (`NexusEditorSubsystem.cpp:176-183`) guards on
  `FNexusDocumentStore::GetPackageName(ActiveDocument) == PackageName` and returns
  before ever calling `SetActiveDocument` — the same "guard reads a value reload can
  pre-update" shape. Not exploitable today because `ExecuteReload` force-rebinds
  first, so by the time this runs again `ActiveDocument`/`Repository` already agree.
  Worth re-checking if that ordering ever changes. The `Repository.GetDocument() ==
  ActiveDocument` check above would harden this one for free if adopted.

Also worth recording: verifying the fix's full clean-gate run left two untracked,
un-gitignored stray assets (`Content/Nexus/NexusWorld_1.uasset`,
`NexusWorld_2.uasset`) behind — automated `New Document` tests running against the
project's real default package path more than once in a session, incrementing the
suffix counter each time. Deleted rather than committed. A pre-commit `git status`
sweep of `Content/` is worth it after any session that ran the Crud/UiGate suites
more than once, since `Content/Imports/` is the only path this repo's `.gitignore`
excludes.
