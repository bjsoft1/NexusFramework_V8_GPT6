---
name: destructive-previews-do-not-belong-in-eligibility
description: Live command guards may be polled during every Slate paint; they must check preview capability without materializing document-sized consequences.
metadata:
  type: feedback
---

Slate command enablement and bound tooltips can be evaluated repeatedly while a menu
is open and again whenever pointer movement repaints it. `CanInitiate` must therefore
remain a cheap, side-effect-free guard. For a destructive command it may verify that
the handler **supports** a preview, but it must not build the preview merely to decide
whether the menu item is enabled.

Build the real preview once, after invocation, from a fresh command context. The
confirmation must carry its command identity and document revision into approval;
execution must re-run the ordinary guard and reject stale/mismatched approval. The
backend may call a state-dependent preview again after an otherwise-valid approval
to verify that it still succeeds, but that work never belongs in paint-time
eligibility.

Why: with `Nexus.Fixture.LoadSample Large 808`, hovering the row menu repeatedly
built Delete's full cascade preview. One State affected thousands of rows, so every
menu repaint rescanned the 100,000-record document and allocated thousands of text
lines even though the command had not been clicked.
