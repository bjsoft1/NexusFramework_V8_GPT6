---
name: the-bottom-two-rungs-are-not-hand-authored
description: Only State, City, and Highway are creatable by hand; Highway Points sync from the landscape and Activation Points arrive in a later phase, and that is the intended shape rather than missing work.
metadata:
  type: project
---

Confirmed by the user on 2026-08-28:

> *"Hierarchy : State > City > Highway > Points auto sync from landscape > Activation
> point will crate in future phase."*

and, asked whether either should be hand-creatable now:

> *"it will comes maybe in future phase."*

So on a new document the Create menu offers **State, City, Highway** and then stops.
That is finished behaviour, not a gap for the Phase 08 gate to close.

- **Highway Point** — `IsLegalChild` accepts one under a Highway, `GetCreatableChildKinds`
  withholds it from every menu. A highway point **is** a Landscape spline segment point
  — a tangent point — and the sync is deliberately **one-way**: Landscape to Nexus,
  never back. Authoring one here would mean writing a control point into the spline,
  which needs exactly the engine spline/junction/tangent APIs V7 forbids Nexus tools
  from calling. The user chose one direction to remove that problem entirely, so Nexus
  reads the tangent data and keeps it as City and Highway information.
- **Activation Point** — not a rung at all. A record in `ActivationPoints` with an
  `AnchorId` and a `LocalTransform`. `FNexusActivationPointCommandService::Create`,
  `Update`, and `Delete` exist and are covered by the Phase 01 suite, and **nothing in
  the UI calls them, deliberately**. Phase 12 gives the gizmo, Phase 14 the type
  registry.

**Why this needs saying:** "the hierarchy is correct" and "a person can build the whole
hierarchy" are different claims, and only the first is true today. The tree renders all
five levels — activation points are grouped by anchor in `NexusHierarchyModel` — so
looking at a seeded document makes the shape appear fully authorable. It is not, and
adding a Create route would be the placeholder the Phase 08 gate forbids.

**How to apply:** do not treat the absent Create entries as an oversight, and do not
"fix" `GetCreatableChildKinds` to match `IsLegalChild`. Structural legality and
hand-creatability are two questions the kind registry answers separately, by design.
`V7-ARCHITECTURE.md` §"Entity kind legality" is authoritative. See
[[check-unshipped-phases-before-narrowing-a-contract]] and
[[nothing-autosaves-the-document]].
