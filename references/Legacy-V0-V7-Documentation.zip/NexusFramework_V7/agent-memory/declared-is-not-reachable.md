---
name: declared-is-not-reachable
description: A test that a binding is declared says nothing about whether pressing the key or clicking the row does anything; V7 has shipped two review candidates with unreachable surfaces.
metadata:
  type: feedback
---

Assert **reachability**, not just declaration. In V7 the same class of defect has now
escaped automation twice, and both times the user found it in the first minutes of
looking at the editor:

- **Phase 03** offered a "Create a document" action wired to a command that could only
  ever refuse. Every test about what the action *held* passed.
- **Phase 04** shipped with all eleven keyboard shortcuts dead.
  `Nexus.V7.Command.Shortcuts` asserted they were declared, unique, correctly scoped,
  and carried on real `FUICommandInfo` objects — every one of those was true, and no
  widget ever called `ProcessCommandBindings`. In the same phase the command palette
  dispatched a command and then dismissed itself, erasing any command that opens a
  surface of its own.

**Why:** a declaration test and a reachability test look equally green. The catalog,
the binding table, and the widget tree can each be individually correct while nothing
connects them, and that gap is invisible from inside any one of the three.

**How to apply:** for every surface a user acts through, write one test that performs
the user's act on the real widget and asserts the effect — send the key event to the
surface, commit the palette row, click the tree row — rather than asserting the
binding exists. `Nexus.V7.Command.ChordRouting` and
`Nexus.V7.Command.PaletteCommitOrder` are the pattern. Phase 05 inherits the risk
directly: a tree row that cannot be clicked passes every test about what it contains.
The same class reached a *state* on 2026-08-28 — see
[[a-state-needs-a-writer-not-just-a-reader]], where the rule becomes "grep for the
writer of a signal, not its readers". See also
[[command-service-is-the-only-mutation-path]] and [[verify-claims-by-re-running]].
