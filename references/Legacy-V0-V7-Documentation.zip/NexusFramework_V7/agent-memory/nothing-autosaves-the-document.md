---
name: nothing-autosaves-the-document
description: V7 never writes the authoring asset by itself — edits go into the document and mark it dirty, and only the Save command writes disk; two unrelated things named "autosave" make this easy to get wrong.
metadata:
  type: project
---

The user's core model, stated on 2026-08-28 and verified against the code the same
day:

> *"We do not auto save our info, we just make our hierarchy dirty and user manually
> save it."*

`FNexusDocumentStore::Save` is the only writer of the `.uasset`, and the Save command
is its only caller. Nothing else, on any timer, in any handler, at shutdown, or on
document switch, writes the asset.

**Two things in the code are called "autosave" and neither saves the document:**

| Name | What it actually does |
|---|---|
| Property-edit auto-commit — `FNexusDetailsView::SetCommitHandler` → `UNexusEditorSubsystem::CommitDetailsDraft` | A *finished* property edit commits itself through the Apply command instead of waiting for a button, the way a native Unreal details panel behaves. It writes into the in-memory document and marks the package dirty. No disk write. |
| Draft recovery — `UNexusEditorSubsystem::TickAutosave` → `AutosaveDrafts` → `FNexusDraftRecoveryStore::Write` | After ten idle seconds, writes a crash-recovery copy of any **still-unapplied** draft under `Saved/NexusV7/`. Never touches the asset. Section 12.2. |

**Why it matters:** "autosave" in a grep result reads as "the file is being written",
and a change made on that assumption would either add a real disk write the user does
not want, or remove the auto-*commit* the user explicitly asked for. Both are wrong in
opposite directions.

**The signal is the package dirty flag.** The shell, the context strip, and Unreal's
own asterisk all read it. Undo and redo re-mark it, and `RefreshAfterUndo` rebuilds
the repository index and reloads Details from what the undo left behind.

**How to apply:** before touching anything named autosave, decide which of the two you
are in. If a change would cause the `.uasset` to be written without the user asking,
it is wrong regardless of how convenient it is. See
[[command-service-is-the-only-mutation-path]] and
[[a-state-needs-a-writer-not-just-a-reader]] — the Stale state exists precisely because
a draft can sit unapplied while the document moves underneath it.
