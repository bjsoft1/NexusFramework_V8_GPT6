---
name: virtualized-rows-can-still-do-full-tree-work
description: A virtualized Slate list can draw ten rows while its input and bound UI getters still rescan all 100,000 logical records.
metadata:
  type: feedback
---

`SListView` virtualization proves only that off-screen row **widgets** are not
realized. It does not prove the array supplied to the list is cheap to derive, that a
hidden sibling panel is not making its own copy, or that Slate-bound label/brush
getters are not performing full-document work several times per paint.

For the Nexus hierarchy, the default collapsed/unfiltered/authored path must traverse
only roots and explicitly expanded branches, cache that presentation order until the
snapshot/filter/expansion changes, and reuse it across selection-only broadcasts.
The Slate item-source handles need the same generation boundary, or a selection-only
repaint can still allocate every visible handle again. Hidden panels must not
materialize rows they cannot draw. Collapsing or clearing a broad query must also
release large backing allocations rather than only setting the logical length to zero.

The complete logical index may still be eager where search, reveal, stable keys, and
invalid/unresolved rows require it. Be precise in handoffs: "lazy presentation rows"
does not mean "hidden domain records were deleted." Measure initial load separately
from continued idle interaction, and inspect every Slate-bound getter for work whose
cost grows with document size.

Why: `Nexus.Fixture.LoadSample Large 808` looked collapsed and used a virtualized
list, yet stayed laggy because every broadcast scanned the full filter order and
shell paint attributes repeatedly ran save-safety validation and recovery lookup.
