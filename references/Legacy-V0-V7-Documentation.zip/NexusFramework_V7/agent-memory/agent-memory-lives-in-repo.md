---
name: agent-memory-lives-in-repo
description: All agent memory and session logs for this project must be written inside the repo under agent-memory/ and committed, never to an external cache directory.
metadata:
  type: feedback
---

Every agent memory, note, and session log for Nexus Framework V7 is written to
`agent-memory/` in this repository and committed with the work it describes.
Do not write project memory to a user-profile memory directory, a temp cache, or
any location outside the repository.

**Why:** The user stated this directly on 2026-08-22. This project is worked on
by more than one AI (it was started with ChatGPT and continued by Claude), so
memory held in one vendor's private cache is invisible to the next contributor
and to the user. Git-tracked memory is reviewable, diffable, survives session
and tool loss, and travels with a clone.

**How to apply:** At session start, read `agent-memory/MEMORY.md` before acting.
When recording something durable, add or update a file in `agent-memory/` and add
its one-line pointer to `MEMORY.md`. Write session narrative to
`agent-memory/logs/<date>-<topic>.md`. Scratch files that are genuinely
throwaway still belong in the session scratchpad, not here — this directory is
for what the next contributor must know. See [[v7-phase-governance]].
