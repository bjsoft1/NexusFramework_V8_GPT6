---
name: evidence-scripts-need-dated-artifact-names
description: A verification script that writes a fixed log filename destroys the evidence an earlier phase cited by digest; every such script takes -RunLabel.
metadata:
  type: project
---

Every V7 verification script that produces a cited artifact takes a `-RunLabel`
parameter defaulting to `(Get-Date -Format 'yyyy-MM-dd')`, and every log name it
writes interpolates it. This applies to `Scripts/VerifyPhase01CookPackage.ps1`,
`Scripts/VerifyPhase02Modules.ps1`, and any script added later that a phase's
evidence record will cite.

**Why:** `V7-QUALITY-GATES.md` §2 identifies each cited artifact by name, byte
count, and lowercase SHA-256 so a later reader can prove the file they hold is the
file that was cited. A script that writes a constant filename — or worse, one with
a *different* date baked into a string literal — quietly overwrites that exact
file on its next run, and the digest in the accepted evidence record then matches
nothing on disk. Discovered on 2026-08-23: re-running the cook/package proof to
verify a Phase 02 change would have overwritten the three
`...-2026-08-22.log` artifacts that the accepted Phase 01 evidence cites.

**A date is not enough within a day.** Both Phase 08 passes ran on 2026-08-28, and the
second overwrote the `ui-budgets-2026-08-28.txt` the first cites by SHA-256. A gate
script is the one that gets re-run several times on the day it is being worked on, so
`Scripts/VerifyPhase08UiGate.ps1` now defaults to `yyyy-MM-dd-HHmmss` **and refuses an
existing destination instead of forcing** — the refusal is the half that also covers an
explicit `-RunLabel`, which is the only way a cited name can be produced again.
Recorded as F-08-10.

**How to apply:** Before re-running any verification script, check whether its
output names are constant, and whether a same-day re-run would collide. If they are, add `-RunLabel` first, then run. Pass an
explicit label only to reproduce a previous run's names deliberately — for example
`-RunLabel 2026-08-23-negative` for a run that proves a guard fails. Keep the
negative-proof log and cite it too; a guard is only evidence once it has been seen
to fail. See [[verify-claims-by-re-running]] and [[v7-phase-governance]].
