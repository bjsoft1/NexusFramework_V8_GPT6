---
name: gate-task-lines-carve-out-to-the-owning-phase
description: A Phase 08 gate task line for a capability no shipped phase provides is closed by carving that part out to the phase that owns it, not left open and not placeholdered.
metadata:
  type: project
---

Three Phase 08 UI-gate task lines have hit the same wall: the line asks to verify
something the build genuinely cannot do yet, because the capability belongs to a
later, unshipped phase. Each was resolved the same way — a user reading that carves
the untestable part out to the owning phase, and marks the line done for what Phase
08 actually owns.

- **F-08-05** (2026-08-28): "no required UI behavior is deferred to Phase 09+" does
  not outlaw the catalog's 16 pending-phase commands. They stay, refusing by name.
- **F-08-06** (2026-09-02): the ownership-mismatch shell state has no representation
  in the build and `phases/phase-10.md` reserves it → defers to Phase 10. Task line 5
  is satisfied by the eight states that a real editor condition produces.
- **F-08-15** (2026-09-02): payload CRUD "through save, close, restart, reload, undo,
  redo" is proven at the command-service level (incl. a genuine three-process cold
  restart), but no UI gesture creates an Activation Point → the UI-authored half
  defers to Phase 14. `phases/phase-07.md` already recorded the identical limit.

**Why:** the gate forbids placeholders, so building a fake representation to satisfy
a checkbox would fail the gate on its own terms. Leaving the line unchecked forever
would block a phase on work it was never meant to contain. The carve-out — done, for
what this phase owns; named, for what a later phase owns — is the honest third option,
and it is a user reading, not an implementer's call ([[v7-phase-governance]]).

**How to apply:** when a gate task line cannot be exercised because the producing
gesture or state lives in an unshipped phase, do not code around it and do not just
leave it `[~]`. Confirm no shipped phase owes the capability (check the phase docs),
confirm a later phase already reserves it, then take it to the user as a plain
question. Record the decision in `PHASE-STATUS.md` and the phase doc with the
carve-out named. See [[the-bottom-two-rungs-are-not-hand-authored]] and
[[check-unshipped-phases-before-narrowing-a-contract]].
