# Nexus Framework V7

Nexus Framework V7 is a clean-slate Unreal Engine 5.8 world-authoring and runtime
framework. It learns from V0-V6 without copying their structural debt.

V7 is deliberately:

- UI-first: the complete editor experience must be finished and accepted at Phase 08 before Landscape work may start.
- Trustworthy: every saved record has stable identity, schema versioning, undo support,
  validation, and visible freshness state.
- Large-world ready: multi-Landscape and World Partition are foundational constraints.
- Deterministic: generation and compilation must produce repeatable, traceable output.
- Runtime clean: packaged modules never depend on Slate, UnrealEd, or authoring objects.
- Evidence gated: an AI may prepare a phase for review, but cannot self-declare manual
  QA or a release gate complete.

Start with `TASK-LIST.md`. The canonical design and phase status live under
`project-specifications`.

Current state: **Phase 01 is Complete**, accepted by the user on 2026-08-22 after
an independent E0 review, its remediation, and the user's own inspection. That
review raised two Blocking findings against the frozen runtime schema — an
aggregate hierarchy record could not fit inside one cell, and cell-major order
conflicted with the preceding-parent rule — and both were decided and enforced in
`V7-ARCHITECTURE.md` §10.

**Phase 02 (Project/Module Foundation) is Complete**, accepted by the user on
2026-08-23. The nine modules have a shared idempotent lifecycle, per-module log
categories, project settings, and diagnostic/result contracts in `NexusCore`.
`INexusCommandService` and `INexusRepository` are the mutation and read seams;
automated tests enforce the dependency graph, reject editor-only modules in the
packaged boundary, prove the module graph is acyclic, and fail if UI code
bypasses the command seam. Three clean builds and 33/33 tests pass, and each
boundary guard was made to fail on purpose before being trusted. Phase 02's
independent E0 module-dependency review was waived rather than performed; see
`PHASE-STATUS.md` for what that leaves unverified.

**Phase 03 (Professional UI Shell) is Complete**, accepted by the user on
2026-08-23 after they performed the E3 pass themselves. The Phase 01 preview panels
are gone. `Window > Nexus Framework V7` is the single entry point to three Nomad
tabs — Hierarchy, Details, and Activity — sharing one frame: a context strip, an
inline non-modal notification region, a resizable three-region body, and a status
footer. Home is a view inside Hierarchy so it cannot be closed and lost. Every
surface renders one of nine states through a pure derivation function and a single
state provider, which is how all nine are proven present in automation rather than
by eye. Three clean builds and 47/47 tests passed, and six of the new guards were
made to fail on purpose before being trusted. As with Phase 02, no independent E0
review was performed; acceptance rests on E1, E2, and the user's editor session.

**Phase 04 (Menus & Command System) is Ready for Review.** One command model now
powers every surface. `NexusCommandCatalog` describes sixty-three commands as data
— id, label, description, category, menu group, icon, chord, scope, synonyms, risk,
expected duration, and the phase that delivers it — and the Window submenu, the
toolbar, context menus, the `Ctrl+Shift+P` command palette, and the Slate command
set are all generated from it, so no two surfaces can disagree about a command.
Destructive commands are gated in the service rather than in the UI: they need an
approved preview whose document revision still matches, and the shell asks inline
rather than with a modal dialog. Long commands report real progress into one
Activity entry and observe cancellation only at declared safe boundaries. The
twenty-four commands this build owns work; the other thirty-nine are registered and
refuse by name with the phase that delivers them, so nothing is offered that cannot
either work or say when it will. Three clean builds and 62/62 tests pass, and six
guards were made to fail on purpose before being trusted. Phase 04 still needs the
E3 manual pass — menu placement, shortcut behaviour, palette keyboard flow, tooltip
placement, and a clean exit — and then the user's acceptance. No Phase 03 or 04
surface may be cited as Phase 05–08 evidence until then.
