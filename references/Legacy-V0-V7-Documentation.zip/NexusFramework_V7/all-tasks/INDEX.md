# All Tasks — Nexus Framework V7 Consolidated Bundle

A copy of every phase, bug, challenge, agent memory, evidence artifact, and log for
this project, gathered in one place on 2026-09-06.

The original repo folder structure is mirrored inside this bundle, so every relative
link between the copied documents still resolves here. **This is a snapshot copy —
the live originals remain in their own folders and stay authoritative.** Edits made in
here do not flow back.

## Start here

| What | Where |
|---|---|
| The 20-phase task list and status rules | [TASK-LIST.md](TASK-LIST.md) |
| Authoritative phase-status ledger | [project-specifications/PHASE-STATUS.md](project-specifications/PHASE-STATUS.md) |
| Open bugs and handovers | [agent-todos/ready-for-review/](agent-todos/ready-for-review/) |
| Agent memory index | [agent-memory/MEMORY.md](agent-memory/MEMORY.md) |
| Project readme | [PROJECT-README.md](PROJECT-README.md) |

## Phases

All 20 phase specs: [project-specifications/phases/](project-specifications/phases/)

Status as copied — 01-04 Complete, 05-07 Ready for Review, 08 In Progress, 09-20 Not
Started. `PHASE-STATUS.md` wins over any other mirror of that status.

- [Phase 01 — Architecture Lock & Serialization Spike](project-specifications/phases/phase-01.md) — Complete
- [Phase 02 — Project/Module Foundation](project-specifications/phases/phase-02.md) — Complete
- [Phase 03 — Professional UI Shell](project-specifications/phases/phase-03.md) — Complete
- [Phase 04 — Menus & Command System](project-specifications/phases/phase-04.md) — Complete
- [Phase 05 — Hierarchy Tree View](project-specifications/phases/phase-05.md) — Ready for Review
- [Phase 06 — Details Panel](project-specifications/phases/phase-06.md) — Ready for Review
- [Phase 07 — Full UI CRUD](project-specifications/phases/phase-07.md) — Ready for Review
- [Phase 08 — UI Completion Gate](project-specifications/phases/phase-08.md) — **In Progress (current work)**
- [Phase 09 — Landscape Reader & Identity](project-specifications/phases/phase-09.md) — Not Started
- [Phase 10 — Mapping, Config & Reconciliation](project-specifications/phases/phase-10.md) — Not Started
- [Phase 11 — Representation Graph & Enforced Validation](project-specifications/phases/phase-11.md) — Not Started
- [Phase 12 — Diagnostics, Debug Visualization & Gizmos](project-specifications/phases/phase-12.md) — Not Started
- [Phase 13 — Static Generation & Streaming](project-specifications/phases/phase-13.md) — Not Started
- [Phase 14 — Activation Registry & Real Payload Types](project-specifications/phases/phase-14.md) — Not Started
- [Phase 15 — Editor Architecture Checkpoint](project-specifications/phases/phase-15.md) — Not Started
- [Phase 16 — Deterministic Runtime Compiler](project-specifications/phases/phase-16.md) — Not Started
- [Phase 17 — Runtime Activation System](project-specifications/phases/phase-17.md) — Not Started
- [Phase 18 — Real Scale, Cook & Package Gate](project-specifications/phases/phase-18.md) — Not Started
- [Phase 19 — Human Verification & Publish UI](project-specifications/phases/phase-19.md) — Not Started
- [Phase 20 — Final Publish Gate](project-specifications/phases/phase-20.md) — Not Started

## Bugs, challenges and handovers

Open items awaiting review — [agent-todos/ready-for-review/](agent-todos/ready-for-review/):

- [bugs-redu-undo__scape-click.md](agent-todos/ready-for-review/bugs-redu-undo__scape-click.md) — undo/redo, tree refresh and escape-click defects
- [dirty-and-save-affordance.md](agent-todos/ready-for-review/dirty-and-save-affordance.md) — the document never looked like it needed saving, and could not be saved
- [empty-tree-cannot-author.md](agent-todos/ready-for-review/empty-tree-cannot-author.md) — a new document could not be authored, and a fixture looked like lost work
- [need-enhancement.md](agent-todos/ready-for-review/need-enhancement.md) — requested improvements to the current phase
- [save-and-dirty-ownership.md](agent-todos/ready-for-review/save-and-dirty-ownership.md) — handover: who owns writing the asset to disk
- [shell-chrome-and-density.md](agent-todos/ready-for-review/shell-chrome-and-density.md) — handover: the shell repeats its chrome on every tab, and it is too big

`ready-for-development/` and `closed/` were copied and are empty apart from their
`.gitkeep` markers.

Phase 08's numbered findings (F-08-xx) live inside
[phase-08.md](project-specifications/phases/phase-08.md) rather than as separate
files; the per-finding evidence is under `project-specifications/evidence/`.

## Agent memory

[agent-memory/](agent-memory/) — 26 single-fact memory files plus the session logs.

- [MEMORY.md](agent-memory/MEMORY.md) — the index; read it before relying on any single memory
- [README.md](agent-memory/README.md) — conventions and rules for the memory set
- [agent-memory/logs/](agent-memory/logs/) — 25 dated work logs, 2026-08-22 through 2026-09-02

## Evidence

[project-specifications/evidence/](project-specifications/evidence/) — 27 dated
evidence documents, one per phase gate, review, or finding. These cite log files by
name and digest; the logs they cite are included below.

## Specifications

- [V7-MASTER-PLAN.md](project-specifications/V7-MASTER-PLAN.md)
- [V7-ARCHITECTURE.md](project-specifications/V7-ARCHITECTURE.md)
- [V7-PRODUCT-VISION.md](project-specifications/V7-PRODUCT-VISION.md)
- [V7-QUALITY-GATES.md](project-specifications/V7-QUALITY-GATES.md)
- [V7-UX-SPEC.md](project-specifications/V7-UX-SPEC.md)
- [V0-V6-LESSONS.md](project-specifications/V0-V6-LESSONS.md)
- [backlog/](project-specifications/backlog/) — 5 approved-for-later items. Nothing here is approved work.

## Logs and artifacts

- [Saved/Logs/](Saved/Logs/) — 340 build and automation logs (~60 MB), including every
  `Automation-*`, `UBT-*`, and manifest log cited by an evidence document
- [Saved/NexusV7/Phase08/](Saved/NexusV7/Phase08/) — 18 UI responsiveness budget
  measurement artifacts
- [Saved/NexusV7/Recovery/](Saved/NexusV7/Recovery/) — draft recovery JSON
- [Saved/Crashes/](Saved/Crashes/) — 17 crash reports, text only (`.log`,
  `.runtime-xml`, `.ini`). The `.dmp` memory dumps were **not** copied: 57 MB of
  binaries that no document references. They are still in `Saved/Crashes/` in the repo.

## Verification scripts

[Scripts/](Scripts/) — the 11 PowerShell scripts the evidence documents were produced
with, one per phase gate plus the content manifest.

## Agent rules

[.cursor/rules/phase-ui-verification-handoff.mdc](.cursor/rules/phase-ui-verification-handoff.mdc)

## What was not copied

Source code (`Source/`, `Plugins/`), engine config (`Config/`), UE content assets
(`Content/`, `Imports/`), build output (`Binaries/`, `Intermediate/`,
`DerivedDataCache/`), autosaves, and crash `.dmp` binaries. Everything in this bundle
is a document, a log, or a verification script.
