# Backlog

`TASK-LIST.md` permits exactly two homes for newly discovered work: **the owning
phase**, or **a separately approved future backlog**. No suffix phases. This directory
is that backlog.

An item lands here when the work is real and understood but its owning phase is not
yet decided. Anything whose owner *is* obvious belongs in that phase's file instead.

## Rules

- **A backlog item is not approved work.** Nothing here may be implemented until it is
  assigned to a phase and that phase's task list carries it. An agent that finds a
  backlog item and starts coding has skipped the approval this directory exists to
  preserve.
- **One item per file**, named `B-NN-<slug>.md`, numbered in creation order and never
  reused.
- **Each item must be completable by someone who was not in the conversation.** State
  what was decided, who decided it, what is still open, and what the work touches. A
  note that only makes sense to its author is not a backlog item.
- **Record the open questions as questions.** Do not resolve an ambiguity by picking a
  side and writing it as settled; that is how an assumption becomes a schema
  migration two phases later.
- When an item is assigned, move its content into the owning phase file and leave the
  item here with a line naming that phase and the date.

## Status

| Item | Subject | Owner phase | Status |
|---|---|---|---|
| [B-01](B-01-world-root-row.md) | `Nexus World` root row in the hierarchy | unassigned | Open |
| [B-02](B-02-highway-mesh-info-cascade.md) | The mesh config data asset and its override cascade | unassigned | Open — conflicts with `phases/phase-14.md` over activation meshes |
| [B-03](B-03-highway-point-attributes.md) | Highway Point attributes from the landscape sync | unassigned | Open |
| [B-04](B-04-landscape-vertical-slice.md) | Landscape vertical slice, to validate the schema before the Phase 08 freeze | unassigned | Open — **needs a governance decision first** |
| [B-05](B-05-lane-and-width-data-model.md) | Lane count, lane width, and walkable width have no home | unassigned | Open — blocks B-02 and B-04 |

## Start here

**A new agent picking up this directory should read [B-04](B-04-landscape-vertical-slice.md)
first.** It is the only item with a deadline attached, it explains why, and it names the
order the rest are best taken in.

B-01, B-02, and B-03 were stated by the user on 2026-08-28 and are related: B-01 is
where B-02's global defaults live, and B-03 is the other half of what a synced highway
point carries.

B-04 and B-05 came from a direction review the same day. B-05 is a **hole in the
design** rather than unbuilt work — three planned phases consume lane data that no
phase produces and no record stores — and it sits on the critical path to the user's
stated main goal.
