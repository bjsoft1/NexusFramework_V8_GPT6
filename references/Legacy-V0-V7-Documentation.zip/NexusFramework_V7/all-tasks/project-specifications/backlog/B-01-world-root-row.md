# B-01 — A `Nexus World` root row in the hierarchy

**Raised:** 2026-08-28, by the user.
**Owner phase:** unassigned.
**Status:** Open. Not approved for implementation.

## What

The hierarchy gains a single root row at index 0, named `Nexus World`.

```
Nexus World          <- index 0, exactly one, rename-only
  > State
      > City
          > Highway
              > Highway Point        (landscape-synced, see B-03)
                  > Activation Point (future phase)
```

Stated by the user:

> *"0 index [Nexus World] alwasy not able to delete, add, just allow rename, inside it
> state, city, highway which is currnently exist."*

Its rules, as given:

| Operation | Allowed |
|---|---|
| Rename | **Yes** |
| Create another | **No** — there is exactly one |
| Delete | **No** |

It is the answer to "where do global settings live": they hang off this row. See
[B-02](B-02-highway-mesh-info-cascade.md), which is the first occupant.

## Why this is not a trivial addition

**It reverses a decision made earlier the same day.** On 2026-08-28 the ladder was
narrowed to four rungs and `World` was explicitly retired from it, recorded in
`V7-ARCHITECTURE.md` §"Entity kind legality" as:

> *"The document root, which takes a State and nothing else. There is no World row
> because the document* is *the world."*

That reasoning was sound for the hierarchy **as a pure containment ladder**. It stops
being sound once the root has to *hold data* — global mesh info needs somewhere to
live and something to select, and a row is how a user reaches settings in this editor.
So this is new information rather than a reversal on the same facts.

**One thing makes it cheap:** `ENexusEntityKind::World` was retired but **never
deleted** — deleting an enum value would reindex every serialized record. The value
still exists and is still used to key the document in the Reload and Close previews.
There is no migration to write for the kind itself.

## What it touches

Roughly, and to be confirmed by whoever implements it:

- `NexusEntityKinds::GetLadder` / `IsLegalChild` / `GetCreatableChildKinds` in
  `NexusEntityCommands.cpp` — the root currently accepts `State` at depth 0. It would
  accept `World`, and `World` would accept `State`.
- `NexusEntityKinds::IsRetired` — `World` comes off that list.
- `FNexusHierarchyModel` — the tree has **no root row today**; States are top-level
  `Roots`. A synthetic-or-real root node is a structural change to model building,
  expansion, and every index walk.
- Create, Delete, and Duplicate guards — all three must refuse `World` by name, with a
  reason, not by omission. `Nexus.V7.Command.DisabledReasons` fails a silent refusal.
- Default naming, `Nexus.V7.Crud.DefaultNaming`.
- The Phase 07 E3 manual checklist — checks 2, 17, and 20 were already amended once on
  2026-08-28 for the ladder narrowing and would need amending again.
- Every test asserting the root offers exactly one kind, notably
  `Nexus.V7.Crud.CreateMenuIsReachable` ("the root offers one kind" / "and it is
  State").

## Open questions

1. **Is the row a real record or a synthetic node?** A real `FNexusAuthoringRecord` of
   kind `World` is savable and can carry payload — needed if B-02's global settings
   live on it. A synthetic node cannot carry data. The B-02 requirement points hard at
   *real record*, which means existing documents need one created on load, which is a
   migration.
2. **What names it by default, and what happens to a document that has none?**
3. **Does Rename on it rename the asset, or only the display name?** The document
   already has a display name from `FNexusDocumentStore::GetDisplayName`, and two
   editable names for one thing is a trap.
4. **Does the row appear before B-02 exists?** An empty root row that holds nothing is
   arguably the placeholder the Phase 08 gate forbids — or arguably the container that
   makes the tree honest. This is a judgement the owning phase must make explicitly.

## Timing — read this before scheduling it

**Phase 08 freezes the UI, command, repository, and selection contracts.** The shape of
the hierarchy root is one of them. The ladder narrowing on 2026-08-28 was deliberately
done *before* that freeze for exactly this reason, and the record says so:

> *"the entity-kind registry is one of the contracts that freeze covers, so narrowing
> it afterwards would have been a break rather than a correction."*

The same argument applies here. Landing B-01 **before** the freeze is a correction;
landing it after is a contract break, and `TASK-LIST.md` makes a changed architectural
contract reopen the owning checkpoint and every affected downstream phase.

That is an argument about *cost*, not a decision. The user's framing — *"this comes in
future"* — is about B-02's settings, and it is not yet established whether the row
itself should arrive with them or ahead of them. **The owning phase must decide this
consciously rather than inherit it by scheduling.**

## Acceptance sketch

- Exactly one `Nexus World` row, always at index 0, in every document including an
  empty one.
- Create and Delete refuse it **with a stated reason**, on every surface: menu,
  context menu, palette, shortcut, and automation.
- Rename works, is undoable, and marks the document dirty.
- A document authored before this change opens, displays, and gains its root row
  without losing a record — with a migration test, per `V7-ARCHITECTURE.md` §5.
- E3: a person confirms the root row reads as the world and not as clutter.
