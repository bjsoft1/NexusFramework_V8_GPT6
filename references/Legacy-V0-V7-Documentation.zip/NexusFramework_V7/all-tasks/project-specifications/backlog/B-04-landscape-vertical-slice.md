# B-04 — Landscape vertical slice: prove the data model before Phase 08 freezes it

**Raised:** 2026-08-28, from a direction review requested by the user.
**Owner phase:** unassigned — see "Governance" below, this needs a decision first.
**Status:** Open. **Not approved for implementation.**
**Depends on nothing. Blocks:** a safe Phase 08 contract freeze.

---

## Why this exists

A direction review on 2026-08-28 compared the build against the user's five stated
goals. Findings, in order of seriousness:

1. **`NexusLandscapeEditor` is a 24-line empty module.** So is `NexusGeneration`.
   After eight phases, **no code has ever read a Landscape spline.** The user's stated
   main goal — *"grab the landscape segment tangent info and put highway mesh"* — is at
   zero.
2. **Lane count, lane width, and walkable width exist nowhere.** Not in
   `FNexusAuthoringRecord`, not in any spec, not in any phase task list. `phases/phase-11.md`
   promises *lane queries* over data that no phase produces, and the mesh cascade in
   [B-02](B-02-highway-mesh-info-cascade.md) selects meshes **by lane count** — a number
   nothing stores. See [B-05](B-05-lane-and-width-data-model.md).
3. **Phase 08 freezes the UI, command, repository, and selection contracts.** Phases
   05–07 built the entire UI, and the authoring schema was frozen in Phase 01, all
   without a single byte of real Landscape data ever having been read. The contracts
   describe an *imagined* input shape.

Point 3 is the reason this item is urgent rather than merely important.
`TASK-LIST.md`: *"A changed architectural contract reopens the owning checkpoint and
every affected downstream phase."* If Phase 09 reads a real spline and the data does
not fit what Phase 08 froze, Phase 08 reopens and the UI work is redone.

The cheap way to find that out is to read one spline **now**.

## What this is

A **spike**, in the sense Phase 01 used the word: a throwaway proof that answers a
design question, not a feature. Its output is knowledge plus a corrected schema, not a
shipping surface.

It must prove one sentence end to end:

> **One Landscape spline → one Highway with ordered Highway Points carrying real
> tangents, a lane count and a lane width → one mesh placed on the correct path.**

If that sentence holds, the frozen contracts survive Phase 09 and the freeze is safe.
If it does not, the schema is corrected **before** the freeze, at a fraction of the
cost.

## Governance — read before starting

This item conflicts with two standing rules, and **neither may be broken silently**:

- `TASK-LIST.md`: *"Phase 09 cannot start until the Phase 08 UI Completion Gate is
  Complete."*
- `TASK-LIST.md`: *"No suffix phases are permitted."*

So this is **not** Phase 09 starting early and **must not** become "Phase 8.5".

Three legitimate routes exist. **The user picks one; do not choose for them:**

| Route | What it means |
|---|---|
| **A — Spike inside Phase 08** | The gate's own scope is "integrated audit and correction of Phases 03–07" and it owns the contract freeze. Validating a contract before freezing it is squarely inside that. Nothing ships; findings feed the freeze. **This is the recommended route.** |
| **B — Reorder the plan** | Move the Landscape reader ahead of the UI gate. Honest, and a large tracker change affecting every downstream dependency line. |
| **C — Accept the risk** | Freeze now, discover the mismatch at Phase 09, reopen Phase 08 then. Legitimate if the user judges the schema likely correct — but it must be a **recorded decision**, not a default. |

Record the answer in `PHASE-STATUS.md` before writing any code.

## Scope

**In:**

- Read one real Landscape spline: control points, ordered segments, Hermite tangents,
  start/end direction, and the connection graph. `phases/phase-09.md` already lists
  exactly these — reuse its wording, do not invent a parallel vocabulary.
- Map that onto the existing `State > City > Highway > Highway Point` records.
- Carry a lane count and a lane width through to a placed mesh. See
  [B-05](B-05-lane-and-width-data-model.md) for the data-model question this forces.
- Place one static mesh along the resulting path.
- **Write down every place the real data did not fit the frozen schema.** This list is
  the actual deliverable.

**Out:**

- Multi-Landscape, World Partition, streaming proxies, junction topology, reconciliation,
  diff/merge, conflict resolution. All belong to Phases 09 and 10 and none is needed to
  answer the question.
- Any menu entry, toolbar button, or shipping surface. A console command is the correct
  entry point — `FNexusSyntheticHierarchy::RegisterConsoleCommands` is the precedent and
  the reason is recorded there: a menu item would either claim a later phase's entry
  point or leave a dead item that fails the Phase 08 freeze gate.
- Generation quality. One mesh on the right path is the bar. Not seams, not materials,
  not instancing, not LODs.
- Marking any phase Complete. See `agent-memory/v7-phase-governance.md`: **an AI may
  never mark a phase Complete or Ready for Manual QA.**

## Order of work

**Docs first, then code.** Both are required; the docs half is what survives.

1. **Get the governance route decided** (A/B/C above) and record it in `PHASE-STATUS.md`.
2. **Resolve [B-05](B-05-lane-and-width-data-model.md) on paper** — where lane count and
   width live, and whether they are authored, landscape-derived, or resolved through the
   [B-02](B-02-highway-mesh-info-cascade.md) cascade. Writing code before this is
   answered will produce a schema field in the wrong place, and the schema is versioned
   and migrated, so a wrong field is expensive to remove.
3. **Write the spike** behind a console command, in `NexusLandscapeEditor`, respecting
   the module boundary: `NexusLandscapeEditor` is Editor-only and nothing it does may
   reach a packaged target. `Nexus.V7.Module.RuntimeBoundary` will fail the build if it
   does.
4. **Mutate only through the command service.** See
   `agent-memory/command-service-is-the-only-mutation-path.md`. Writing records directly
   changes the document and tells nothing that reads it.
5. **Record the mismatch list** in a dated evidence file, and update
   `V7-ARCHITECTURE.md` §5 and §8 with whatever the real data proved wrong.
6. **Fold the corrections into the owning phase docs** — Phase 09's task list, and the
   Phase 08 freeze item — rather than leaving them in this backlog item.

## Acceptance

- A console command turns one real Landscape spline into Highway Points in the document,
  with tangents that match the spline, undoable, and marking the document dirty.
- The points survive save, editor restart, and reload with their tangents intact.
- One mesh is placed along that path, at the correct positions and orientations.
- A written list of every place the real spline data did not fit the existing schema,
  **including "nothing" if that is the answer** — a clean result is a result and is the
  evidence that makes the Phase 08 freeze safe.
- E1 clean build, E2 the full `Nexus.V7` sweep with no new failures.
  `Nexus.V7.UiGate.SelectAllAtScale` is expected to fail; it is F-08-04 and open by
  design. Commands are in `agent-memory/verify-claims-by-re-running.md`.
- **E3 is a person's job.** Do not claim it.

## Related

- [B-01](B-01-world-root-row.md) — the `Nexus World` root row, also wanted before the freeze.
- [B-02](B-02-highway-mesh-info-cascade.md) — the mesh config asset this slice places a mesh from.
- [B-03](B-03-highway-point-attributes.md) — junction type, code name, and feature flags on a point.
- [B-05](B-05-lane-and-width-data-model.md) — the lane and width hole this slice must close.
