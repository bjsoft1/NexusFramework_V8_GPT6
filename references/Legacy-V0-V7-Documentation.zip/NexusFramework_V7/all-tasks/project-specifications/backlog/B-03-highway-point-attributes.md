# B-03 — Highway Point attributes from the landscape sync

**Raised:** 2026-08-28, by the user.
**Owner phase:** unassigned.
**Status:** Open. Not approved for implementation.

## What

A Highway Point is a Landscape spline segment point — a tangent point — synced
one-way into Nexus and never authored by hand. It is the end of the containment
ladder and takes no part in the [B-02](B-02-highway-mesh-info-cascade.md) mesh
cascade. What it does carry is its own attributes. Stated by the user:

> *"The points only contain some info, in future like: junctions type in enum, code as
> id name for developer helper, features: has trafic light, has cross walk, and more
> liek this."*

Three kinds of attribute, and they behave differently:

| Attribute | Shape | Notes |
|---|---|---|
| **Junction type** | enum | Not free text. `Road` and `Junction` were retired from `ENexusEntityKind` on 2026-08-28 specifically to come back *as a type of highway point* — this is that. See `V7-ARCHITECTURE.md` §"Entity kind legality". |
| **Code / ID name** | short string | A developer-facing handle, distinct from both `FNexusId` and the display name. A **third** name on one record; see open question 1. |
| **Features** | set of flags | `has traffic light`, `has crosswalk`, "and more like this" — an open set, so not a fixed bitmask struct. |

## Why the features flags need care

The features list overlaps Activation Points, and the boundary is not obvious.

A traffic light and a crosswalk are both named in `phases/phase-14.md` as **Activation
Point types** with their own payloads — the Traffic Light with pole and LED offsets and
signal grouping, the Crosswalk with endpoints, width, waiting points, and traffic-light
linkage. So `has traffic light` on a point can mean either:

- **a summary** — derived, "an activation point of that type is anchored here", never
  authored, and it must never be editable or it will disagree with the truth; or
- **an intent** — authored, "a traffic light belongs here", which generation or
  reconciliation later satisfies by creating the activation point.

These are opposite data-flow directions and `V7-ARCHITECTURE.md` §3 forbids
hand-authoring derived data. **The owning phase must pick one explicitly.** Guessing
produces a flag that is sometimes stale and sometimes authoritative, which is worse
than either.

## Open questions

1. **Is the code/ID name unique, and scoped to what?** Document, highway, or nothing.
   A record would then carry `FNexusId`, a display name, and this — and
   `Nexus.V7.Crud.Rename` already enforces sibling-name collision rules on the display
   name. State whether the code name gets its own rule or none.
2. **Features: derived or authored?** See above. This is the blocking one.
3. **Does the junction-type enum replace any use of `ENexusEntityKind::Road` /
   `::Junction`,** or is it a new independent enum? Those two values still exist,
   retired, and are serialized in existing documents.
4. **Are these attributes overwritten by the next landscape sync?** The point itself is
   landscape-derived, so a re-sync rewrites its geometry. If a user set a code name and
   feature flags on it, a naive re-sync destroys them. Reconciliation must preserve the
   authored half across a sync of the derived half, and that rule belongs with
   `phases/phase-10.md`.

Question 4 is the one most likely to be discovered late and expensively.

## What it touches

- Authoring schema — new fields on the highway-point record. **Schema addition against
  the Phase 01 frozen schema**: version bump plus migration, per `V7-ARCHITECTURE.md` §5.
- `phases/phase-09.md` — the reader already extracts control points, Hermite tangents,
  and the connection graph. Junction type is plausibly derivable there rather than
  authored.
- `phases/phase-10.md` — reconciliation, and open question 4.
- `phases/phase-11.md` — validation of junction shape already appears in its task list.
- `phases/phase-14.md` — the activation-point types the feature flags overlap.
- Details panel — a highway point is not hand-creatable but **is** selectable and
  editable today, so these fields would appear in the existing panel with no new
  surface needed.
