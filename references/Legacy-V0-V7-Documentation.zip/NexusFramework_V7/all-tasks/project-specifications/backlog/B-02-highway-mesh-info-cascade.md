# B-02 — The mesh config data asset and its override cascade

**Raised:** 2026-08-28, by the user. Extended the same day.
**Owner phase:** unassigned.
**Status:** Open. Not approved for implementation.

## What it is

A **data asset**, referenced by authoring records rather than embedded in them.
Confirmed by the user:

> *"the highway mesh config is data assets"*

That settles the storage question: it is a project asset with its own lifetime,
editable outside any one document, and referenceable from many. Records point at it.

## What it holds

Broader than the name suggests. The user's list:

> *"it has info: highway mesh, trafilic light, city light, activation mesh: parking,
> bus stop, and more ...."*

So at least:

| Group | Entries |
|---|---|
| Highway geometry | a mesh per lane count — 1, 2, 4, 6, 8, … — every junction type, transitions between differing lane counts, curves |
| Fixtures | traffic light, city light |
| Activation meshes | parking, bus stop, "and more" |

**The name undersells it.** This is the project's mesh catalog, not a road-only table.
Whoever owns this should name the asset for what it is, because "highway mesh config"
will read as road-only to everyone who meets it later and the parking mesh will end up
somewhere else as a result.

The entry list is explicitly open-ended — *"and more"*, twice. It must not be a fixed
struct of named fields that requires a schema change per new mesh type.

## How it resolves

Walk up the ladder until a value is found:

> *"if null check parent level if still null check parnet level if still null check
> parnet level and so on."*

```
Nexus World   <- B-01. The global set; the walk ends here.
  > State
      > City
          > Highway     <- the deepest level that participates
              > Highway Point   does not participate; see B-03
```

**The chain ends at Highway** — *"Yes, Highway is end chain."*

Null means "not set here", not "set to nothing". A level states only what it changes.
Retuning the global asset must move every entity that never disagreed with it.

### The failure mode this design exists to avoid

Resolving the chain **eagerly at author time** — writing effective values onto each
record when they are set — produces an identical result on day one and permanently
destroys the ability to retune globally, silently, for every document already saved
that way.

Resolve at **read/generation time** by walking up, which is what the user described.
If a resolved snapshot is ever cached for performance, it is derived data and takes a
source hash per `V7-ARCHITECTURE.md` §3; it is never written back into authoring
records.

## The one question left on the cascade

**Is the null checked on the asset reference, or on each entry inside it?**

The phrasing — *"it has info: highway mesh, traffic light, … so, if null check parent
level"* — enumerates the entries and then applies the null rule, which reads as
**per-entry**. Per-entry is also the only reading under which the cascade is worth
having: under whole-asset fallback, a City that wants a different bus stop mesh must
duplicate the entire global asset, and it then stops tracking every global change —
which is the eager-resolution failure above, arrived at by a different route.

So per-entry is the working assumption. The sub-question that genuinely remains:

> **Can a level hold no config asset at all?** I.e. is a City with a null *asset
> reference* simply transparent — the walk continues to State — or must every level
> carry an asset once the feature exists?

Transparent is almost certainly right, and it makes the two nulls compose: a level
with no asset passes through entirely, and a level with an asset passes through
entry by entry. One line of confirmation closes this.

Worked example to confirm against:

- Global asset sets the 4-lane mesh to **A** and the bus stop mesh to **P**.
- State sets nothing.
- City sets only the bus stop mesh to **Q**.
- A Highway under that City resolves: 4-lane → **A** (from Global), bus stop → **Q**
  (from City).
- Changing Global's 4-lane mesh to **B** moves that Highway to **B** with no
  re-authoring anywhere.

## Conflict to resolve before this is scheduled

**`phases/phase-14.md` already assigns meshes per activation type.** Its task list
carries:

- *"Implement Bus Stop stopping/entry/exit, passenger waiting points, seats, shelter,
  **meshes**, and lane/road relationships."*
- *"Implement Seat grouping/capacity/occupancy/spacing/**mesh data**."*
- *"Implement Parking layout, bays, entry/exit, vehicle rules, dimensions, **meshes**,
  and occupancy authoring data."*

The user's list puts parking and bus stop meshes in **this** cascading asset. Both
cannot own them. The options:

1. The config asset owns every mesh, and Phase 14's payloads hold behaviour, geometry,
   and offsets but **no mesh references** — they resolve theirs through the cascade
   like everything else.
2. Phase 14's payloads own per-instance meshes, and the config asset supplies only the
   default a new instance starts from.
3. The config asset covers road geometry and fixtures; activation meshes stay with
   Phase 14 — which contradicts the user's list as stated.

Option 1 is the one consistent with *"we set in global, but allow to override as
fallback"*, and it is a real narrowing of Phase 14's task list rather than an
observation. **It must be decided before either phase is implemented**, because both
descriptions currently promise the same field.

`V7-QUALITY-GATES.md` treats one source of truth per data class as a hard rule, and
`V0-V6-LESSONS.md` §"One source of truth per data class" exists because this went
wrong before.

## What it touches

- **A new data asset type** — `UNexusMeshConfig` or similar, in `NexusAuthoring` if
  documents reference it, with the open-entry shape the "and more" requires.
- **Authoring schema** — a config reference on the World, State, City, and Highway
  records. A schema addition against the Phase 01 frozen schema: version bump plus
  migration, with the coverage `V7-ARCHITECTURE.md` §5 mandates.
- **[B-01](B-01-world-root-row.md)** — the World row is where the global reference
  lives, and it does not exist yet. This item depends on it.
- **Details panel** — an override editor that distinguishes *inherited from where*,
  *overridden here*, and *unset*. A field that cannot say which level its value came
  from makes a four-level cascade unusable in practice. This is the largest UI piece
  and it is not a stock property row.
- **`phases/phase-11.md`** — validation of a dangling asset reference and of a null
  that reaches the top of the walk unresolved. §9's hard-gate posture argues for
  blocking generation rather than falling back to an engine default.
- **`phases/phase-13.md`** — generation consumes the resolved catalog.
- **`phases/phase-14.md`** — the conflict above.

## Which phase should own it

Still undecided; the user said so, and said to record it rather than guess.

| Half | Natural owner |
|---|---|
| The data asset type and its entry shape | needs an owner |
| Config reference fields, schema migration, Details override UI | needs an owner; touches the Phase 08 contract freeze via B-01 |
| Dangling / unresolved reference validation | `phases/phase-11.md` |
| Generation consuming the resolved catalog | `phases/phase-13.md` |
| Activation-mesh ownership | `phases/phase-14.md`, per the conflict above |

`TASK-LIST.md` forbids suffix phases, so this cannot become "Phase 13a". Either one
existing phase absorbs it whole, or it is split across the phases above with the asset
type and schema landing first.
