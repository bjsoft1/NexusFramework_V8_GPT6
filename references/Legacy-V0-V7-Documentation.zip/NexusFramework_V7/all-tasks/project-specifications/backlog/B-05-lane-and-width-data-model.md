# B-05 — Lane count, lane width, and walkable width have no home

**Raised:** 2026-08-28, from a direction review requested by the user.
**Owner phase:** unassigned.
**Status:** Open. **Not approved for implementation.**
**Blocks:** [B-02](B-02-highway-mesh-info-cascade.md) and [B-04](B-04-landscape-vertical-slice.md).

---

## The hole

The user's main goal, stated 2026-08-28:

> *"the highway has lane, lane width, human wallable or not width and more. so,
> according to this our Future AI walk, drive and more"*

A search of the whole repository on 2026-08-28 returned **zero hits** for lane width,
walkable width, or any equivalent — in `project-specifications/` and in
`Plugins/NexusFrameworkV7/Source/` alike.

`FNexusAuthoringRecord` carries exactly five fields: `Identity`, `Kind`, `ParentId`,
`SortOrder`, `Payload`. There is no lane data on it, and nothing else holds any.

**Three places already assume this data exists:**

| Where | What it assumes |
|---|---|
| `phases/phase-11.md` | *"Implement hierarchy, adjacency, junction, **lane**, path-neighbor, owner, and nearby-anchor queries."* — queries over data no phase produces. |
| `phases/phase-13.md` | *"Roads, junctions, **lanes/markings**, sidewalks, curbs …"* — generates from it. |
| [B-02](B-02-highway-mesh-info-cascade.md) | The mesh cascade selects **by lane count** — 1, 2, 4, 6, 8. That number is stored nowhere. |

So the plan has a consumer, a generator, and a selector for data that has no producer
and no field. This is a gap in the design, not merely unbuilt work, and it is on the
critical path to the user's stated main goal.

## What has to be decided

### 1. Where does lane data live?

Three candidates, and they are not equivalent:

| Option | Consequence |
|---|---|
| On the **Highway** record | One lane count for a whole highway. Simple. Cannot express a road that widens. |
| On the **Highway Point** record | Lane count can change along the road, which is what makes transition meshes meaningful — [B-02](B-02-highway-mesh-info-cascade.md) explicitly lists *"transitions highway mesh"*, which only exist if lane count varies between points. |
| Resolved through the **[B-02](B-02-highway-mesh-info-cascade.md) cascade** | World/State/City/Highway defaults with per-level override, same walk-up rule as meshes. |

The presence of transition meshes in the user's own list is strong evidence that lane
count varies **along** a highway, which points at the Highway Point — or at a
per-segment record that does not exist yet. **Confirm with the user; do not infer.**

### 2. Is it authored or landscape-derived?

The sync is one-way and a Highway Point is landscape-derived (`V7-ARCHITECTURE.md` §8).
So:

- If lane data is **authored**, a Highway Point holds both derived geometry and authored
  values, and the next sync must preserve the authored half while rewriting the derived
  half. That rule does not exist yet and belongs with `phases/phase-10.md`. It is the
  same problem [B-03](B-03-highway-point-attributes.md) raises for code names and feature
  flags, and the two should be solved once.
- If it is **derived**, something in the Landscape must express lane count, and
  `phases/phase-09.md` currently extracts only control points, tangents, and topology.
  Nothing in that list carries a lane count, so a source would have to be identified.

`V7-ARCHITECTURE.md` §3 forbids hand-authoring derived data, so this cannot be left
ambiguous — a field that is sometimes authored and sometimes overwritten by a sync is
the worst of both.

### 3. What exactly is "human walkable or not width"?

Read as sidewalk width, with zero or absent meaning *not walkable*. `phases/phase-13.md`
already generates **sidewalks**, so a term probably exists there to reuse rather than
invent. Confirm the intended meaning before naming the field — this is the one item on
this page whose meaning is genuinely unclear from the quote.

### 4. What consumes it, and when?

The user's framing is explicit that this is for **future AI walk and drive**, and that
the near-term need is smaller:

> *"for now we just need city, highway points segment info and place our mesh in
> correct path."*

So lane width and walkable width may only need to be **stored and carried** now, with
pathfinding consuming them much later (`V7-ARCHITECTURE.md` §"routing/pathfinding is
compiled from validated lanes and junctions"). Storing a field correctly now is cheap;
adding it after the schema freeze is a migration. **That asymmetry is the argument for
settling this before Phase 08 freezes, even though nothing consumes it yet.**

## Cost of getting it wrong

The authoring schema is versioned and every change needs a migration with the coverage
`V7-ARCHITECTURE.md` §5 mandates — oldest supported version, previous version, unknown
future version, interruption, and repeated load. A field placed on the wrong record is
therefore not a refactor; it is a migration to add it and a second migration to move it,
with a schema version burned on each.

This is why [B-04](B-04-landscape-vertical-slice.md) puts "resolve B-05 on paper" ahead
of writing any code.

## What it touches

- `FNexusAuthoringRecord` and/or `FNexusActivationPointRecord` in
  `NexusAuthoring/Public/NexusWorldDefinition.h` — schema addition, version bump,
  migration, migration tests.
- Details panel — new fields appear automatically through the reflection-driven proxy
  path (`UNexusDetailsProxy::CollectDirtyFields`), so no bespoke UI is needed unless the
  values are cascade-resolved, which needs the inherited/overridden/unset display
  [B-02](B-02-highway-mesh-info-cascade.md) describes.
- `phases/phase-09.md` — if derived, the extraction list grows.
- `phases/phase-10.md` — preserving authored values across a re-sync.
- `phases/phase-11.md` — its lane queries finally have something to query.
- `phases/phase-13.md` — generation, and the sidewalk terminology question.
