# Phase 06 — Details Panel — Evidence — 2026-08-23

## Status of this record

This satisfies the **implementing-agent portion** of the Phase 06 gate only. E1 and
E2 are green on a clean tree. **E3 is not satisfied**, and one acceptance-gate item
depends entirely on it: *"User approves clarity and editing ergonomics."* The script
is [Phase 06 E3 manual checklist](phase-06-e3-manual-checklist-2026-08-23.md).

No independent E0 review was performed, as with Phases 02 through 05.

## Gate script

`Scripts/VerifyPhase06Details.ps1`. It performs three clean builds and runs six
suites, and it fails rather than passes when the automation log has no results, has
no completion marker, or returns fewer results than a suite is expected to produce.

```
PASS: clean build NexusFrameworkEditor-Win64-Development
PASS: clean build NexusFramework-Win64-Development
PASS: clean build NexusFramework-Win64-Shipping
PASS: Nexus.V7.Module     - 12 results
PASS: Nexus.V7.Command    - 17 results
PASS: Nexus.V7.Hierarchy  - 14 results
PASS: Nexus.V7.Shell      - 14 results
PASS: Nexus.V7.Details    - 20 results
PASS: Nexus.V7.Foundation - 21 results
PASS: 98 tests, 0 failures
PHASE 06 DETAILS: PASS
```

Zero automation warnings and zero automation errors. Three further tests —
`Nexus.V7.ColdRestart` and `Nexus.V7.RuntimeCook` — exist in the tree and are not named
by this gate because they belong to the Phase 01 restart and cook gates.

## E1 — clean builds

| Target | Configuration | Result |
|---|---|---|
| NexusFrameworkEditor | Win64 Development | Succeeded |
| NexusFramework | Win64 Development | Succeeded |
| NexusFramework | Win64 Shipping | Succeeded |

The two non-editor targets are built because this phase adds reflected `UObject`
edit proxies to `NexusEditor` and takes a `PropertyEditor` dependency in
`NexusEditorUI`. An editor-only type reaching a packaged target has to fail here
rather than at Phase 18, and `Nexus.V7.Module.RuntimeBoundary` still passes.

## E2 — automation

The twenty `Nexus.V7.Details` tests this phase owns, plus the seventy-eight tests
the earlier phases froze.

| Test | What it holds |
|---|---|
| `StableBinding` | Reversing `Entities` leaves the panel on the same entity with the same values. |
| `GenericFieldPath` | A scalar, a record int, a payload float, a payload array, and an array nested inside it all diff and commit through one reflection walk. |
| `Autosave` | An interactive change does not commit; a finished one does, reaches the document, and leaves nothing pending. |
| `AutosaveHolds` | An invalid value is held with a reason, kept rather than discarded, and commits once corrected. |
| `AutosaveStale` | A draft whose source moved is refused rather than overwriting newer values. |
| `LiveEdit` | A finished edit registers without a commit, an invalid value blocks immediately, and the panel is not asked to rebind. |
| `NoDanglingTarget` | Deleting mid-edit gives `TargetsMissing`, keeps the draft, refuses to commit, and crashes nothing. |
| `MixedValues` | Agreed fields read unmixed, disagreeing fields read mixed, and a shared-field edit does not flatten distinct names. |
| `ValidationExplains` | An invalid field carries a blocking finding whose message names the repair, and the finding clears when fixed. |
| `ApplyStaleness` | A draft outliving its source revision is refused by name, and reloading clears it. |
| `RevertIsDraftOnly` | Revert restores the draft and moves neither the record nor the revision. |
| `RevertNeedsConfirmation` | Unconfirmed Revert is refused; the preview names the entity and the field count; approved Revert runs. |
| `DraftIsKept` | Navigating away parks a dirty draft, navigating back restores it, a document change drops it. |
| `ReadOnlyTargets` | An unresolvable payload is shown, explained, and refuses writes rather than being hidden. |
| `ApplyLabel` | `Apply 1 Change`, `Apply 2 Changes`, `Apply to 2 Items`. |
| `NoDoubleApply` | Both footer commands refuse by name while a commit is running. |
| `CommandCoverage` | `DeliveredThroughPhase` is 6 and both Phase 06 commands resolve to real handlers that refuse with reasons. |
| `HealthyFixtureIsNotBlocked` | Normal, Deep, and Wide save losslessly; Invalid still does not. |
| `PanelIsReachable` | A real `IDetailsView` comes up bound to 0, 1, and 2 drafts, and the footer's enablement is the guard's. |
| `Breadcrumb` | State/City/Highway/Point resolves root-first, and a parent cycle does not spin the walk. |

## Three design decisions

**The diff is a reflection walk, not a field list.** `UNexusDetailsProxy::CollectDirtyFields`
iterates `CPF_Edit` properties and asks `FProperty::Identical`. A bool, an `FName`, an
`FTransform`, an `FInstancedStruct` payload, and a `TArray` nested two levels inside
that payload are all answered by the same call, and the same call decides
"Multiple Values" for a multi-selection — so a field can never read as equal in one
place and different in the other. Adding a field to a proxy subclass is enough to make
it diff, multi-edit, validate, and apply. That is what the first acceptance-gate item,
*"through one generic path"*, is asking for, and `GenericFieldPath` exercises it from a
scalar down to an array inside an array.

**Everything a control decides lives in `FNexusDetailsView`, which has no Slate.**
Phases 03, 04, and 05 each shipped a surface whose behaviour lived where only a real
window could reach, and each time the first look at the editor found what the suite
could not. So dirty state, mixed values, validation, Apply's label, Apply's
eligibility, and what Revert would discard are all answered by a class a test drives
directly. What genuinely remains in the widget — that an `IDetailsView` actually comes
up bound to the right proxies — is held by `PanelIsReachable`, which builds the real
panel and counts what the real property view bound.

**Validation checks what the document itself enforces, and nothing more.** Phase 11
owns the validation service. Until it exists, Details validates exactly the invariants
`UNexusWorldDefinition::CanSaveLosslessly` already enforces, so a draft Details accepts
is a draft the document agrees to save. Inventing extra rules now would mean Phase 11
arriving to find a shipped panel it disagrees with.

## A defect the phase's own guards caught

`IsDraftStale` originally compared the repository's revision to the revision the
targets were last rebuilt at. Those two are always equal, because a repository change
is what triggers the rebuild — so the check could never fire, and a draft could be
applied against source the user never saw. `ApplyStaleness` failed on the first run
and named it.

The fix moves the question to where it belongs: each draft keeps the revision it was
authored against, each baseline carries the revision it was loaded at, and a dirty
target whose two differ is stale. A draft parked and reclaimed keeps its original
revision rather than adopting the reloaded baseline's, which is the case that would
otherwise silently re-base an edit.

## A defect found at the editor, before E3 — Apply waited for focus to leave

**Reported by the user on first use:** Apply only became available after editing a
text field *and clicking away*. They asked for it to activate on the change itself.

Three separate causes, and the first two were not the interesting ones.

1. **The panel rebound on every edit.** `HandleViewChanged` called
   `SetObjects(..., bForceRefresh=true)` unconditionally, so any property change
   rebuilt every row underneath the widget being typed into. `FNexusDetailsView` now
   carries a **structure serial** bumped only by a rebuild, a reload, or a revert; a
   plain edit broadcasts without it, and the panel compares before rebinding.
2. **Validation was cached and only recomputed on the finished-editing signal.**
   Dirty state and `CanApply` are computed on demand and were already live — Slate
   re-evaluates a bound `IsEnabled` every frame — so for a checkbox or a spinner the
   footer already kept up. Validation did not, which meant a value that became invalid
   mid-edit did not block Apply until focus moved. `UNexusDetailsProxy` now raises
   `OnProxyEdited` from `PostEditChangeProperty` and `PostEditChangeChainProperty`,
   unfiltered by change type, and the view recomputes from that.
3. **The real cause: text never reached the proxy until commit.** The property
   editor's stock text row writes on Enter or focus loss. No amount of refreshing helps
   — the value genuinely is not there yet. `FNexusDetailsLiveTextCustomization` is
   registered on this panel's property view only, and replaces `FName`, `FString`, and
   `FText` rows with a box whose `OnTextChanged` writes through the property handle
   using `EPropertyValueSetFlags::InteractiveChange`. The commit that follows is an
   ordinary set, so a finished edit is still one undoable step rather than one per
   keystroke. The box is deliberately uncontrolled: a `Text` attribute bound to the
   handle re-reads every frame and moves the caret while the user is still typing.

`Nexus.V7.Details.LiveEdit` is the guard. It drives `PostEditChangeProperty` with
`EPropertyChangeType::Interactive` and no commit, and asserts the draft reads dirty,
Apply enables, an invalid value blocks Apply immediately, and — the part that matters
for typing — **the structure serial does not move**, because asking the panel to
rebind is what made the field unusable.

The guard was proven by reinstating the defect: the subscription in `RebuildTargets`
was commented out, rebuilt, and `LiveEdit` failed by name on its validation
assertions while the other sixteen passed. Worth recording precisely, because the
dirty and Apply assertions *passed* with the defect present — those were already live,
and the honest scope of cause 2 is validation only.

## Autosave — the Apply button is gone

**Decided by the user during the build, overriding V7-UX-SPEC.md §8.2 and §12.3.**
Section 12.3 says outright that "the user must still Apply". A native Unreal details
panel has no Apply button, and requiring a press per field is not what anyone editing
properties here expects. Recorded in `V7-ARCHITECTURE.md` §7.

A **finished** property edit commits itself. The draft lifecycle is otherwise
unchanged — edits land on proxies, validate, and commit through the `Apply` command as
one transaction. Only who triggers the last step moved, so there is still exactly one
mutation seam.

- `EPropertyChangeType::Interactive` never commits. Mid-drag and mid-keystroke values
  are not ones the user has finished choosing, and committing them would leave one
  undo step per character.
- Autosave calls the same `CanApply` guard the command re-checks, so the two can never
  disagree about what is committable.
- A declined edit is **held, never discarded**, with the reason on screen. Correcting
  it and leaving the field saves it.

**The footer has no buttons.** It reports `Saved`, `Editing — saves when you finish`,
or `Not saved — <reason>`, plus an `Esc to discard this field` hint that appears only
while a field is being edited. A Discard control was built and then removed on the
user's instruction: beside a field still being typed into it acts on a half-finished
value, and it misbehaved for exactly that reason. Escape abandons the field; undo
reverses a committed edit.

Escape needed real handling rather than just `RevertTextOnEscape`. Text is written to
the proxy on every keystroke, so restoring only the visible text would leave the box
showing the old value while the draft held the abandoned one — and autosave would then
commit what the user had just cancelled. The customization writes the last accepted
value back on `ETextCommit::OnCleared`.

`Revert Draft` remains a catalog command with a real handler and its
destructive-confirmation gate, reachable from the palette and menus. Removing a footer
control is not removing a command.

Three tests cover it: `Autosave` (interactive does not commit, finished does, the value
reaches the document and nothing is left pending), `AutosaveHolds` (an invalid value is
held with a reason and commits once corrected), and `AutosaveStale` (a draft whose
source moved is refused rather than overwriting newer values).

`Autosave` failed on its first run, and the cause was the harness rather than the
product: the test's commit route executed the command but did not call
`Repository.NotifyChanged`, which `UNexusEditorSubsystem::ExecuteCommand` does. Without
it the baselines never reloaded and a saved draft still read dirty. The harness now
mirrors the subsystem exactly — a test that diverges from the real commit path proves
nothing about it.

## A finding carried in from Phase 05

**F-E3-04 is fixed here.** The Phase 05 E3 run found the shell reporting
*"Blocked — 1 blocking finding"* on a fixture shape documented as healthy. The cause
was `FNexusSyntheticHierarchy` setting `ExpectedWorldPackage` to `/Nexus/Synthetic`,
a root nothing mounts, so `FPackageName::IsValidLongPackageName` failed and the
document refused to declare itself saveable. It now uses `/Game/NexusV7Tests/SyntheticWorld`,
the root every other fixture in the tree already used.

Every Phase 05 test built that fixture and none asked the document whether it was
saveable. `Nexus.V7.Details.HealthyFixtureIsNotBlocked` is that missing question,
asked of Normal, Deep, and Wide — and asked in reverse of Invalid, so the hierarchy
suite's broken-data coverage cannot quietly become valid data.

## A decision that binds later phases

V7-UX-SPEC.md section 8.2 wants **Apply / Keep Draft / Discard / Cancel** when the
selection changes with a draft dirty. `Nexus.V7.Shell.NotificationsAreNonModal`
forbids the dialog that would ask. Phase 06 makes **Keep Draft the behaviour rather
than an option**: navigating away parks the draft, coming back restores it, Revert is
the explicit Discard, and nothing interrupts the user to ask. A count of parked drafts
is shown in the panel so the state is visible rather than merely safe. Recorded in
`V7-ARCHITECTURE.md` section 7.

## Deliberate omissions

- **Impact and Diff drawers** (V7-UX-SPEC.md section 8.1, "optional") are not built.
  Section 10.1 requires preview for Delete, reparent, and relationship replacement —
  all Phase 07 — and states that an ordinary single-item property Apply does not need
  one. Revert, which is destructive, does build a real preview.
- **`Apply Valid Targets Only`** (section 8.3) is not offered. It may be offered only
  where the operation declares partial application safe, and no operation declares
  that yet. Batch Apply is atomic, and skipped targets are listed before it runs.
- **Autosave and the recovery store** (section 12) belong to Phase 07's save workflow.
  Kept drafts live for the session and are not written to disk.
- **Property help, units, and constraints** are carried as `UPROPERTY` metadata —
  tooltips, `ClampMin` — rather than as a separate help system. Section 9.2's
  requirement that property-level messages be keyboard reachable is met by the
  native property view; a bespoke system would be a second thing to keep in step.

## Cited artifacts

From the final gate run, after the live-edit fix and the `LoadedRevision` cleanup
described above.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `Saved/Logs/Automation-Phase06-Details-2026-08-23.log` | 372,735 | `C33F26DE6B2AE68A8CCECEC243BB244CCD61119712E1D462A084E881196BA504` |
| `Saved/Logs/UBT-Phase06-NexusFrameworkEditor-Win64-Development-2026-08-23.log` | 9,980 | `EE513AD3600F34F7CFEF03517911878D4CDAC72355D94B74E6AB05F7CB8DAAA9` |
| `Saved/Logs/UBT-Phase06-NexusFramework-Win64-Development-2026-08-23.log` | 4,836 | `9F6010C618F978FA12D5B54AE2B1969D33E23F854EF1DA5CE63DBD64D9AFD388` |
| `Saved/Logs/UBT-Phase06-NexusFramework-Win64-Shipping-2026-08-23.log` | 4,604 | `9D33D1C49E19E4E8C824EBA828732CB095595D70948A82207A69B90C62D0D613` |

`LoadedRevision` on `FNexusDetailsView` became write-only when staleness moved to a
per-target comparison, and was removed rather than left as a member a later reader
would assume still meant something. The gate was re-run afterwards; the digests above
are from that run.

## A note on the working tree

The test suite regenerates `Content/NexusV7Tests/Runtime/P01_RuntimeDataset.uasset`,
the Phase 01 compiled-dataset fixture. Commit `efc8db8` removed that file from
tracking, so it reappears as untracked after any run. It is a test byproduct and is
deliberately not committed.

## What this phase added

| File | Role |
|---|---|
| `NexusEditor/Public/NexusDetailsModel.h` + `.cpp` | Edit proxies and the reflection diff. |
| `NexusEditor/Public/NexusDetailsView.h` + `.cpp` | Targets, drafts, validation, Apply plan, eligibility. |
| `NexusEditor/Public/NexusDetailsCommands.h` + `.cpp` | `Apply` and `Revert Draft` handlers. |
| `NexusEditorUI/Private/Widgets/SNexusDetailsPanel.h` + `.cpp` | The surface and its test seams. |
| `NexusTests/Private/NexusDetailsTests.cpp` | The sixteen tests above. |
| `Scripts/VerifyPhase06Details.ps1` | The gate. |
