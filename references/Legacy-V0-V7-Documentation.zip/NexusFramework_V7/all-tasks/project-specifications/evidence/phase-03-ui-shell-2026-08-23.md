# Phase 03 Professional UI Shell Evidence — 2026-08-23

## Verdict

**Ready for Review — not Complete.** E1 and E2 are green on a clean tree. E3 is not
satisfied: three acceptance-gate items need a person at the editor, and the
implementing agent cannot produce that evidence. Two of the five gate items are
ticked; the other three are recorded below with exactly which half of each is
already held and which half is outstanding.

## Environment

- Unreal Engine 5.8.1, CL 56057345, `C:\Program Files\Epic Games\UE_5.8`.
- Visual Studio 14.44.35228 toolchain, Windows 10.0.26100.0 SDK.
- Windows 10 Pro 19045, 16 physical cores, 61.6 GB.
- Gate script: `Scripts/VerifyPhase03Shell.ps1 -RunLabel 2026-08-23`.

## E1 — Clean builds

Every target was built with `-clean` first, so none of these reused an object file.

| Target | Configuration | Result |
|---|---|---|
| `NexusFrameworkEditor` | Win64 Development | PASS |
| `NexusFramework` | Win64 Development | PASS |
| `NexusFramework` | Win64 Shipping | PASS |

Phase 03's own gate needs only the editor build. The two non-editor targets are
built because this phase changed `NexusEditorUI`'s dependency list — adding
`Engine`, `EditorSubsystem`, `UnrealEd`, and `NexusAuthoring` — and an editor-only
module leaking into a packaged target has to fail here rather than at Phase 18. It
did not: `Nexus.V7.Module.RuntimeBoundary` and the clean Shipping link both still
pass.

## E2 — Automation

Command run by the script:

```
UnrealEditor-Cmd.exe NexusFramework.uproject -unattended -nop4 -nosplash -NullRHI
  -nosound -ExecCmds="Automation RunTests Nexus.V7.Shell+Nexus.V7.Module+Nexus.V7.Foundation; Quit"
  -TestExit="Automation Test Queue Empty" -log=Automation-Phase03-Shell-2026-08-23.log
```

Observed in the cited log:

- 47 results, all `Result={Success}`; 0 non-success results.
- 14 `Nexus.V7.Shell` (this phase), 12 `Nexus.V7.Module` (Phase 02), 21
  `Nexus.V7.Foundation` (Phase 01).
- Zero `LogAutomationController: Warning:` and zero `LogAutomationController: Error:`
  lines.
- Suite wall time 1.51 s, from the first `Test Started` at `02.52.35:418` to
  `**** TEST COMPLETE. EXIT CODE: 0 ****` at `02.52.36:930`.
- Editor process exit code 0.

An earlier attempt at this same run aborted during the clean Development Game build
with `cl : Command line error D8022 : cannot open ... .obj.rsp` on two response
files. No Nexus process was holding the intermediate directory, the failure did not
reproduce, and the immediate re-run — the one cited here — built all three targets
clean. It is recorded because a reader comparing timestamps would otherwise find a
failed build log with no explanation, not because it indicates anything about the
code.

The script does not treat a zero exit code as sufficient. It fails if the log
contains no results at all, if the completion marker is absent, if any result is
non-success, or if fewer than 14 shell results appear — the last of these because a
renamed test category would otherwise turn into silent loss of coverage while still
exiting zero.

### What the fourteen shell tests hold

| Test | What it holds |
|---|---|
| `ActionsAreRunnable` | No state offers an action the shell cannot complete: label and action kind always agree, no Phase 03 state offers to run a command, Failure is always dismissible, and the no-document state offers nothing while naming the phase that will. |
| `StateDerivation` | Seventeen signal sets map onto the nine states, every state is proven reachable, and the precedence order is asserted case by case rather than described in prose. |
| `StatePresentation` | All 27 surface-by-state combinations carry a headline and an explanation, any offered action carries a tooltip, Failure repeats the reason it was given, and each surface distinguishes "no document" from "empty document" in its own words. |
| `SurfaceIdentity` | The three tab ids are asserted as literal strings, are unique, round-trip both ways, and an unknown id resolves to no surface. |
| `ResponsiveLayout` | Both layout breakpoints, that navigation is reachable in exactly one form at every width, and that the regions surviving each breakpoint actually fit inside it. |
| `WorkspaceRoundTrip` | Each of the three workspace defaults is usable and serialises and parses back identically with no repair reported. |
| `WorkspaceRecovery` | Ten saved-layout cases, from nothing-written-yet to a state naming surfaces this build does not have, each recover to a usable workspace, report the right recovery reason, and need no second repair. |
| `Notifications` | Post, dismiss, dismiss-by-severity, newest-first ordering, most-severe lookup, the unresolved predicate, and the retention cap discarding oldest first. |
| `NotificationsAreNonModal` | No `NexusEditorUI` source reaches `AddModalWindow`, `FMessageDialog`, `EAppMsgType`, or `FSuppressableWarningDialog`. |
| `StyleTokens` | Every brush, text style, and button style the shell names resolves; every state has a status glyph; registering twice is a no-op and unregistering twice is safe. |
| `PaletteContrast` | WCAG ratios for 10 text pairings at 4.5:1 and 39 state and severity pairings at 3:1, plus a self-check that the measure reports 21:1 for black on white. |
| `TabSpawners` | Exactly the three Nomad spawners are registered and no fourth Nexus surface exists. |
| `SurfaceLayout` | The real surfaces are constructed for all 27 surface-by-state combinations and laid out at 100% and 200% scale, each yielding a non-degenerate desired size, and a post-construction state change is picked up without rebuilding. |
| `Recents` | The recent-document list drops blanks and duplicates, trims entries, preserves order, and is capped. |

## Two design decisions are what make the above testable

**State derivation is a pure function.** `DeriveShellState(FNexusShellSignals)` maps
any combination of signals onto exactly one of nine states, and
`MakeShellStatus(Surface, Signals)` turns that into a headline, an explanation, and
at most one action. Neither touches the editor. Phase 03's central requirement —
that every state has an intentional presentation — is therefore proven exhaustively
rather than sampled by eye.

**Widgets see the world only through `INexusShellStateProvider`.** The live
implementation reads `UNexusEditorSubsystem`; the other has its signals assigned
directly, which is how automation drives the real widgets into all nine states. This
also keeps V7-ARCHITECTURE.md section 7 enforceable: no widget can reach a mutation
path it was not handed, and `Nexus.V7.Module.UiMutationBoundary` still passes over
the enlarged module.

## A defect the user found in the first minute of looking

The first build of this shell offered a button on the no-document Empty state
labelled "Create a document", wired to `Nexus.Document.Initialize`. That command
stamps identity onto a document that is **already open**; its first guard refuses
when `Context.HasDocument()` is false, which is exactly the condition the Empty
state is shown under. The button could only ever fail, and on the user's first press
it did, leaving the surface reading "The last operation failed".

Two defects, not one:

1. **An action was offered that could not succeed.** Creating or binding an authoring
   document is the Phase 07 entry point recorded as Phase 01 finding F-09. Phase 03
   had no business offering it. Every other unbuilt capability in this shell names
   the phase that delivers it; this one alone pretended to work.
2. **Failure had no way out.** `ReportFailure` is cleared only by a later successful
   command or a document change, neither of which was reachable. The surface stayed
   on the message until the editor restarted.

Both are fixed:

- The no-document state offers no action and says which phase delivers the entry
  point.
- `FNexusShellStatus` now carries an explicit `ENexusShellActionKind`
  (`OpenDiagnostics`, `DismissFailure`, `RunCommand`) instead of the implicit rule
  "run the command if one is named, otherwise navigate". That implicit rule is what
  allowed the defect to exist.
- Failure offers "Dismiss and continue", which clears the recorded failure. The
  footer's Diagnostics button remains the route to detail on every surface.
- `RunStatusCommand` checks `INexusCommandService::CanExecute` **before** executing
  and shows the command's own refusal reason. Executing first and reporting a
  generic failure afterwards is how the defect presented itself.

`Nexus.V7.Shell.ActionsAreRunnable` now holds all of this, and the defect was
reinstated verbatim to prove the guard catches it — see Run 3 below.

## Six guards were proven to fail

A guard that has never been seen to fail is an assumption. These were broken on
purpose, built, and run; each failed by name while the rest passed. Both runs were
retained.

**Run 1 — four independent breaks, four attributable failures.**
`Automation-Phase03-Shell-2026-08-23-negative.log`.

| Break | Test that failed |
|---|---|
| `TextMuted` changed to `#3A4450`, below the body-text ratio | `Nexus.V7.Shell.PaletteContrast` |
| The Ready state's `Detail` removed | `Nexus.V7.Shell.StatePresentation` |
| An `FMessageDialog` reference added to a shell source file | `Nexus.V7.Shell.NotificationsAreNonModal` |
| `Nexus.Brush.NegativeProofMissing` named but never registered | `Nexus.V7.Shell.StyleTokens` |

The other eight tests passed in that run, so each failure is attributable to its own
break rather than to a general collapse.

**Run 2 — the layout breakpoint.**
`Automation-Phase03-Shell-2026-08-23-negative-layout.log`. `WideLayoutWidth` was
lowered from 720 to 300, which is narrower than three regions at their minimum width
can occupy. `Nexus.V7.Shell.ResponsiveLayout` failed alone; the other twelve passed.

**Run 3 — the unrunnable action, reinstated verbatim.**
`Automation-Phase03-Shell-2026-08-23-negative-action.log`. The no-document Empty
state was given back its "Create a document" label, `ActionKind = RunCommand`, and
`ActionCommand = Nexus.Document.Initialize` — the exact defect reported from the
editor. `Nexus.V7.Shell.ActionsAreRunnable` and `Nexus.V7.Shell.StatePresentation`
both failed; the other twelve passed. The guard therefore reproduces the reported
bug rather than merely describing it.

All six breaks were reverted and the editor was rebuilt from the restored source.

## A narrow-window defect found and fixed during this phase

The first layout gave each of the three regions an `SSplitter` `MinSize` of 180
units. That reads as a safety margin and is not one: three of them need 540 units
before padding, which is wider than a normally docked Unreal tab, and `SSplitter`
overflows its allotted geometry rather than shrinking a slot below its minimum. The
shell would have clipped its own navigation, and nothing would have caught it before
the E3 pass.

The fix is a rule rather than a minimum. `NexusShell::GetRegionVisibility(Width)` is
a pure function that drops the third region below 720 units and replaces the
navigation rail with a horizontal, horizontally-scrollable section strip below 420;
`MinRegionWidth` is now 140, so a rail and a content region fit inside a normal
dock. Because the rule is a pure function, `Nexus.V7.Shell.ResponsiveLayout` pins
both breakpoints and asserts that whatever survives a breakpoint actually fits
inside it.

## Accessibility and DPI, and what is still manual

| Requirement | How it is held | Level |
|---|---|---|
| High-DPI scaling | Every surface laid out at 100% and 200% scale in `SurfaceLayout`; all spacing is the shared Slate-unit scale, which is DPI-independent by construction | E2 |
| Readable contrast | `PaletteContrast`, WCAG 2.1 relative luminance, 4.5:1 body and 3:1 state colours on all three surfaces | E2 |
| Not relying on colour alone | Status glyph shape is redundant with colour: filled circles for settled states, outlines for transient ones, square corners for states that stop work | E2 (`StyleTokens` asserts every state has a glyph) |
| Narrow-window behaviour | `ResponsiveLayout` breakpoints; long text wraps, and the document label ellipsises with the full value in its tooltip | E2 |
| Keyboard focus path | Every control is an `SButton` or `SComboButton`, both focusable by default, so all are in the tab order | **E3** |
| Tooltip placement | Tooltips are set on every non-obvious control, including the disabled command-palette affordance | **E3** |
| Clean editor exit | Shutdown order, and the lifetime token below | **E3** |

Hairline borders and separators are deliberately excluded from the contrast test.
WCAG 1.4.11 covers information needed to identify a component or its state, and this
shell identifies state with a shaped glyph plus text, never with a border.

## Shutdown safety

Unregistering a Nomad tab spawner does not close the tabs it already produced, so a
surface can outlive the module that made it. Every callback a surface holds is
therefore guarded by a weak token that `OnNexusModuleShutdown` drops before tearing
down the state those callbacks touch; the state provider and notification centre are
shared pointers rather than module members, so a surviving surface keeps them alive
instead of dangling. The provider re-resolves the editor subsystem on the way out
rather than caching it, because the subsystem can already be gone during editor exit.

This is reasoned and structural, **not proven by automation**. Simulating a tab that
outlives its module would require unloading `NexusEditorUI` mid-session. The
observable check is a clean editor exit, which is E3.

## Structural scan

`Scripts/VerifyFoundation.ps1` re-run after every source and document change:

```
FOUNDATION STRUCTURAL SCAN: PASS
Failures=0
Phase status mirrors - 01 Complete; 02 Complete; 03 Ready for Review; 04-20 Not Started
```

## Acceptance gate

| Gate item | Status | Held by |
|---|---|---|
| Shell opens from a stable editor entry point and never duplicates itself | **Met** | One `Window > Nexus Framework V7` submenu is the only entry point; tabs are `ETabSpawnerMenuType::Hidden` so no second route exists. `TryInvokeTab` both opens and focuses, so asking twice cannot spawn twice. `Nexus.V7.Shell.TabSpawners` asserts exactly three spawners and no fourth. |
| Layout survives editor restart and recovers from invalid saved layout | **Half met** | Recovery is proven at E2 across ten corruption cases, and a repaired or unreadable layout raises a notification rather than being silently corrected. Survival across a restart is **E3**. |
| Every defined state has an intentional, understandable presentation | **Met** | `Nexus.V7.Shell.StatePresentation` over all 27 surface-by-state combinations, plus `SurfaceLayout` proving each one actually lays out. |
| No clipped text, broken focus path, unreadable contrast, or shutdown error remains | **Half met** | Contrast at E2; wrapping and ellipsis-with-tooltip in place; responsive breakpoints tested. Focus path in a live window and a clean editor exit are **E3**. |
| User approves the shell's professional visual quality | **Not met** | The user's alone. |

## The E3 checklist

Nothing in this shell can be driven with data yet, and that is the phase boundary
rather than an omission: `UNexusEditorSubsystem::SetActiveDocument` is called from
nothing but automation, there is no asset factory, and no content-browser binding
exists. Phase 07 delivers the entry point that binds a document. A shell reporting
"Empty — no document" is therefore the correct behaviour, and the deliverable under
review is the shell itself.

What a person needs to check, in the order the gate items depend on it:

1. `Window > Nexus Framework V7 > Open Nexus Workspace` opens three tabs.
2. Each tab docks, undocks, closes, and reopens; none ever appears twice.
3. Default, Authoring, and Review each open and close tabs to match.
4. Home toggles from the context strip and from the navigation rail, and the two
   always agree about which is showing.
5. Narrowing a tab drops the third region near 720 units, then replaces the
   navigation rail with a horizontal strip near 420.
6. At the desktop's own display scaling, and at the editor's application scale, no
   text is clipped and no control overlaps.
7. Tab traversal reaches every control, and the focused control is visible.
8. Restarting the editor restores the tabs where they were left.
9. Closing the editor produces no error or warning on exit.

Items 5, 7, 8, and 9 are the four this automation cannot reach, and they map onto
the three unticked acceptance-gate items.

## Artifacts

Every file below is in `Saved/Logs/`, identified by byte count and lowercase SHA-256
as V7-QUALITY-GATES.md section 2 requires.

| Artifact (`Saved/Logs/`) | Bytes | SHA-256 |
|---|---:|---|
| `UBT-Phase03-NexusFrameworkEditor-Win64-Development-2026-08-23.log` | 4,310 | `66fe695fcf5189266acceaeb40703e524a431f030b5809f7a4e205632449e8fb` |
| `UBT-Phase03-NexusFramework-Win64-Development-2026-08-23.log` | 2,420 | `3a78d5ebbea12c676f4619ec4fc05579281d34aa4746d3703c3359ba94cb5749` |
| `UBT-Phase03-NexusFramework-Win64-Shipping-2026-08-23.log` | 2,303 | `07fbb49681dbe5cb8817add61ea9acbab220c28f95cdb06a48628645440ff910` |
| `Automation-Phase03-Shell-2026-08-23.log` | 328,524 | `eabda5698ba171469dac464f4bbb8bf5d801111ae27ff61a745e12ce8d72880b` |
| `Automation-Phase03-Shell-2026-08-23-negative.log` | 293,346 | `0e90e03cd6ad4090550517aa98cd9354a4f512792d7697a1a7990a7d4068d919` |
| `Automation-Phase03-Shell-2026-08-23-negative-layout.log` | 292,632 | `a63cf913dac5d8f1fbb5263eda8e2494e4d061aad602e66cfb2dc71bff4839bc` |
| `Automation-Phase03-Shell-2026-08-23-negative-action.log` | 293,770 | `fb0e308f3267725205ca85b6eb703326ab0e5511a00f97a7e230ffdc93f8e32d` |
| `Foundation-Structural-Scan-Phase03-Final-2026-08-23.log` | 1,428 | `b603f647e8f8182955c4e6cb59917772382465f17870881f6daf02dedf38e896` |

## Open items

1. **E3 has not been performed.** Docking, resizing, DPI at the desktop's own
   scaling, keyboard traversal, tooltip placement, switching maps, restarting the
   editor, and a clean exit. Three acceptance-gate items depend on it.
2. **Shutdown safety is structural, not proven.** See the section above. A clean
   editor exit during E3 is the observable check.
3. **Phase 02's E0 was waived, not satisfied**, and that carries forward as context
   rather than as a Phase 03 finding. See `PHASE-STATUS.md`.
4. **The command palette is deliberately inert.** It occupies its place in the
   context strip, disabled, with a tooltip naming Phase 04 as its owner. The
   alternative — hiding it — would move the strip's layout when it arrives.
5. **No document can be bound from the editor.** `SetActiveDocument` has no caller
   outside automation, and Phase 07 owns the entry point that changes that. Every
   surface will therefore report Empty during E3, which is the correct behaviour and
   not a defect. `Nexus.V7.Shell.ActionsAreRunnable` keeps the shell from offering a
   step it cannot complete while that remains true.
5. **Section content is state presentation, not features.** World tree, filters,
   properties, validation, history, and source freshness each render their surface's
   state and name the phase that fills them. Phase 03's scope excludes production
   hierarchy data, property editing, and CRUD.
