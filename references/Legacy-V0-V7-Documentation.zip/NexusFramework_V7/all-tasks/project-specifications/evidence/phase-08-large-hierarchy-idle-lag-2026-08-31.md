# Phase 08 — collapsed large-hierarchy idle lag (2026-08-31)

Implementation record for the persistent editor lag reported after
`Nexus.Fixture.LoadSample Large 808`. Phase 08 remains **In Progress**. This source
has not built and the new tests have not run because `dotnet.exe` fails before
UnrealBuildTool can start; therefore this record is not E1, E2, E3, or acceptance.

## How to Test After the Latest Source Builds

1. Open **Window > Nexus Framework V7 > Open Default Workspace** and select the
   **Hierarchy** section → the tree, Details, and Activity surfaces are available.
2. Enter `Nexus.Fixture.LoadSample Large 808` in the editor console, then run
   **Collapse All** from `Ctrl+Shift+P` if enabled → exactly ten State root rows are
   drawn after the one-time fixture construction finishes.
3. Switch between Hierarchy, Details, and Activity, open an Unreal Editor menu, and
   resize a Nexus panel → the editor remains responsive instead of continually
   stalling on the hidden 100,000 rows.
4. Expand **State 01**, then **City 01-01**, and collapse **State 01** → only the
   opened branch appears, and collapse returns immediately to the ten roots.
5. Type `Activation 088890` in Hierarchy search → the hidden logical record and its
   ancestor path appear; clear search → the ten collapsed roots return without
   keeping the filtered presentation rows alive.
6. Enter `Nexus.Fixture.Clear` in the editor console → the fixture disappears, the
   no-document state is shown, and the editor remains responsive.

## Cause and correction

- The old visible-row getter scanned and reserved for all 100,000 filter-order keys
  on every relevant broadcast even when only ten roots could be drawn.
- The default unfiltered/authored view now caches a depth-first visible list and does
  not descend through collapsed nodes. Selection-only broadcasts reuse that cache.
- The preconstructed Filters section no longer materializes an invisible duplicate
  row list or binds tree-only reveal/rename listeners.
- The real tree keeps its row-key objects across selection-only visual refreshes;
  only a new visible-row generation rebuilds that item source.
- Collapse and clear-search paths release large row/expansion backing allocations.
- Repeated shell badge, status, Home-health, and context-strip reads reuse a keyed
  save-safety result and document-info snapshot rather than rescanning the document
  or recovery directory during one paint.
- The complete logical hierarchy remains indexed in memory deliberately: collapsed
  descendants still have to be searchable, revealable by stable key, and available
  for invalid/unresolved-row diagnostics. What is lazy is the Slate/presentation row
  list and the work performed during idle repainting.

## Added regression coverage (not yet run)

- `Nexus.V7.Hierarchy.VisibleRowsCache`
- `Nexus.V7.UiStates.LargeDocumentStateReadsAreCached`

Expected focused properties are ten visited/materialized roots while collapsed, one
visible branch after expanding a root, no rebuild on repeated reads or selection
broadcasts, preserved authored order through activation-point siblings, and one
validation/document-info build across repeated Slate-style reads.

## Build/test blocker

No build command was retried for this record. The previously observed Windows
`dotnet.exe - Application Error` (`0xe0434352`) still makes a build attempt unsafe as
evidence until the toolchain process issue is resolved. Static `git diff --check`
passes for the changed lag-fix files, with only existing LF-to-CRLF notices.
