# V7 Reference Environment — 2026-08-22

This is the build/test workstation record used by the Phase 01 reference baseline.

- Unreal Engine: 5.8.1, CL 56057345
- Operating system: Microsoft Windows 10 Pro, build 19045
- CPU: AMD Ryzen 9 9950X, 16 physical cores / 32 logical processors
- Memory: 61.6 GiB physical
- GPU: NVIDIA GeForce RTX 3070, driver 32.0.16.1088
- Primary large disk observed: XOC-SP900 SSD
- MSVC toolchain: 14.44.35228
- Windows SDK: 10.0.26100.0
- Build accelerator: Unreal Build Accelerator, local executor, up to 16 actions
- Project: E:/Projects/Game/UE/NexusFramework/NexusFramework_V7
- E: volume at final instrumentation: 629.38 GiB free, 300.74 GiB used
- Power scheme: Balanced
- Display scaling: 96 DPI (100%)
- Available physical memory at instrumentation: 39.59 GiB
- CPU load at instrumentation: 18%
- Largest background consumers included Visual Studio, Memory Compression,
  Defender, browser, and AI/editor processes
- Thermal state: unavailable from the exposed Windows instrumentation; not inferred

This is a reference comparison point, not a universal hardware budget.
