# Phase 02 Module Foundation Evidence — 2026-08-23

## Verdict

**Ready for Review — not Complete.** E1 and E2 are green, the structural scan
passes, and the two Phase 01 findings carried into this phase are closed with
recorded decisions. Phase 02's required evidence also includes E0, an independent
module-dependency review; this agent implemented Phase 02 and cannot serve as its
own E0 reviewer. E0 and user acceptance both remain outstanding.

## Environment

The Phase 01 baseline workstation: Unreal Engine 5.8.1 CL 56057345, Windows 10 Pro
19045, MSVC 14.44.35228, Windows SDK 10.0.26100.0. Full record:
[reference environment](reference-environment-2026-08-22.md).

## E1 — Clean builds

`Scripts/VerifyPhase02Modules.ps1` runs `Build.bat ... -clean` before each build
and records a pass only on exit code 0, so none of these can come from an
incremental artifact.

| Target | Configuration | Result |
|---|---|---|
| `NexusFrameworkEditor` | Win64 Development | PASS |
| `NexusFramework` | Win64 Development | PASS |
| `NexusFramework` | Win64 Shipping | PASS |

The Shipping link is the independent confirmation that only `NexusCore`,
`NexusRuntime`, and `NexusV7Host` enter a packaged target.

## E2 — Automation

Command:

```
powershell -NoProfile -ExecutionPolicy Bypass -File Scripts/VerifyPhase02Modules.ps1
```

Result: **33 tests, 33 `Result={Success}`, 0 failures**, editor exit code 0,
7.61 s total, zero automation warnings or errors, and the log carries
`TEST COMPLETE. EXIT CODE: 0`. The script refuses to read an empty run as success —
it fails when the log contains no test results at all, which is the exact failure
mode observed earlier with `-abslog`, where the editor exited 0 without running a
single test.

The run is the twelve `Nexus.V7.Module` tests this phase owns plus the twenty-one
`Nexus.V7.Foundation` tests Phase 01 froze, so Phase 02 cannot pass by regressing
Phase 01.

`Nexus.V7.Module` — twelve tests:

| Test | What it holds |
|---|---|
| `LoadState` | Every approved module is loaded and reports itself loaded. |
| `IdempotentLifecycle` | Repeated startup/shutdown leaves no duplicate or leaked registration. |
| `CommandServiceContract` | Result success is derived from diagnostics, so a Blocking diagnostic cannot report success. |
| `InitializeDocumentCommand` | The first real command runs through `INexusCommandService` end to end. |
| `SubsystemSeam` | `UNexusEditorSubsystem` owns the repository and builds command contexts. |
| `ProjectSettings` | `UNexusProjectSettings` resolves its report directory and default cell size. |
| `TestHarness` | Automation discovery and the canonical fixture helpers are reachable. |
| `RuntimeBoundary` | `NexusCore` depends on no Nexus module; `NexusRuntime`'s only Nexus edge is `NexusCore`; neither packaged module reaches an editor-only engine module. |
| `GraphIsAcyclic` | The nine-module dependency graph has no cycle. |
| `PluginDescriptor` | Descriptor module types match the runtime/editor split they claim. |
| `UiMutationBoundary` | No `NexusEditorUI` source reaches a concrete mutation service, `FScopedTransaction`, or `->Modify()`. |
| `HostDatasetContract` | Every identity literal the packaged host still spells out matches the canonical fixture, and the host does not reach the dataset's bulk accessors. |

## Both boundary guards were proven to fail

A guard that has never failed is not evidence, so each was made to fail on purpose
and then reverted.

**Runtime boundary.** `UnrealEd` and `NexusAuthoring` were injected into
`NexusRuntime.Build.cs`. `Nexus.V7.Module.RuntimeBoundary` failed by name and the
run exited non-zero. Reverted from git HEAD.

**Host dataset contract.** `NexusV7Host.cpp`'s `SourceRevision` literal was changed
from 42 to 43 — exactly the silent drift F-10 describes — and the full script was
re-run against three clean builds.

All three clean builds still passed — the drift is invisible to the compiler,
which is the whole point of the finding. The run then reported
`FAIL: HostDatasetContract` and exited 1 with
`The automation log does not contain a passing completion marker`. The recorded
assertion was `Expected 'the host asserts the fixture's source revision' to be
true` at `NexusModuleBoundaryTests.cpp(456)`. Log:
`Saved/Logs/Automation-Phase02-Modules-2026-08-23-negative.log`.

The host source was then restored and the passing run below was produced from the
restored tree.

## E0 carried findings closed in this phase

Phase 01 accepted F-08 and F-10 as non-blocking and carried both into Phase 02.
Both are now dispositioned, and the decisions live in `V7-ARCHITECTURE.md` §6 so
they bind later phases instead of sitting only in an evidence file.

### F-08 — two Phase 02 preconditions

**The `NexusEditorUI` command edge.** `NexusEditorUI.Build.cs` now declares
`NexusCore` and `NexusEditor` as private dependencies, so the UI can reach
`INexusCommandService` deliberately in the direction the architecture allows,
rather than Phase 03 adding the edge incidentally to make a widget compile.
`Nexus.V7.Module.UiMutationBoundary` holds the UI to issuing commands.

**Continuous integration.** Decided: V7 does not create a CI pipeline in Phase 02.
Every gate needs a licensed UE 5.8 installation and a clean build of three targets,
which a hosted runner cannot provide; a self-hosted runner on the single build
workstation would run the same scripts against the same tree and add no independent
verification. `.github/workflows/` stays empty and `Scripts/VerifyPhase02Modules.ps1`
is the mandatory pre-review gate. The architecture's CI clause takes effect
unchanged if a dedicated build machine is ever provisioned.

### F-10 — the compiled fixture's expected shape was duplicated

Decided in favour of the review's second option. Canonical fixture truth stays in
`NexusTests` and is never lifted into a module that ships; the alternative — a
runtime-safe shared header both sides consume — was rejected for that reason.

`NexusV7Host.cpp` was narrowed from roughly sixty literal field assertions to what
only a packaged runtime can prove: the cooked asset loads, `Validate` passes,
`IsFreshFor` matches the expected source fingerprint, and one record key resolves
through the packaged entity index to exact payload bytes.
`UNexusRuntimeDataset::Validate` already re-derives the deterministic Build ID and
re-checks header counts, canonical cell and record order, cell containment,
duplicate identity, parent validity and acyclicity, routes, and every payload
digest — so narrowing the host removed duplication, not coverage. The host also now
logs the specific validation error and item index instead of a bare FAIL.

`Nexus.V7.Module.HostDatasetContract` owns the remaining overlap at E2. It checks
the host's source hash, compiler fingerprint, source document id, source revision,
probe record id, probe entity kind, and probe payload bytes against the values the
fixture actually produces, and it fails the host for reaching `GetHeader`,
`GetCells`, `GetRecords`, `GetEntityIndex`, `GetRouteEdges`, or `GetPayloadStorage`
— the mechanism by which duplicated shape assertions accumulated the first time.

## E4 — the narrowed host re-proved

Phase 02's gate is E1 + E2, but this phase changed code whose only proof is E4, so
the packaged path was re-run rather than left unverified.

```
powershell -NoProfile -ExecutionPolicy Bypass -File Scripts/VerifyPhase01CookPackage.ps1
```

`PHASE 01 COOK/PACKAGE/RUNTIME-DATASET LOAD: PASS`. The fixture-preparation
automation passed, the full cook produced **518 packages with 0 errors and 0
warnings** in 16.84 s, stage/pak/IoStore/archive completed, `BuildCookRun` reported
`BUILD SUCCESSFUL` in 52.76 s with `ExitCode=0`, and the packaged executable logged
`NEXUS_PHASE01_PACKAGED_DATASET_LOAD: PASS` and exited 0.

Two things worth recording from that run. The regenerated fixture asset
`Content/NexusV7Tests/Runtime/P01_RuntimeDataset` came back byte-identical — it
produced no git change — which is an independent signal that compiled-dataset
generation is deterministic. And the narrowed host is genuinely exercising the
packaged asset rather than passing vacuously: it resolves the probe key through
the cooked entity index and compares payload bytes, which is the same path the
old sixty-assertion version used to reach.

`Scripts/VerifyPhase01CookPackage.ps1` had hard-coded `2026-08-22` into three
artifact names, so re-running it would have overwritten logs that the Phase 01
evidence record cites by digest. Both verification scripts now take a `-RunLabel`
that defaults to the current date, so a re-run can no longer destroy an earlier
run's cited artifacts.

## Structural scan

`Scripts/VerifyFoundation.ps1`: `FOUNDATION STRUCTURAL SCAN: PASS`, failures 0 —
exact 20 phase files, 20×9 required sections, ledger/mirror agreement on every
phase, nine module descriptors mapped to Build.cs and `IMPLEMENT_MODULE`, zero
forbidden runtime-boundary references, zero source-debt markers.

The scan was run twice: once against the code as verified, and again after this
phase's status was advanced, so `Phase status mirrors` is recorded as
`01 Complete; 02 Ready for Review` on the delivered tree rather than on a tree
that no longer exists. The scan reads `PHASE-STATUS.md` as the authority and fails
on any drift between it and a phase file's Status heading.

## Acceptance gate

| Gate item | Held by |
|---|---|
| Every approved module loads and unloads without errors or leaked registrations | `Nexus.V7.Module.LoadState`, `Nexus.V7.Module.IdempotentLifecycle` |
| `NexusRuntime` builds with zero dependency on authoring, editor, generation, or compiler modules | `Nexus.V7.Module.RuntimeBoundary` plus the clean Shipping build |
| Tests are discovered and can fail the build | Both negative proofs above; the script exits non-zero on any failed result and on a run that produced no results |
| No circular module dependency exists | `Nexus.V7.Module.GraphIsAcyclic` |
| No feature code bypasses the command/service boundary | `Nexus.V7.Module.UiMutationBoundary`, `Nexus.V7.Module.CommandServiceContract` |

## Artifacts

Raw logs stay under `Saved/`, which is not under source control, so each is
identified here by byte count and lowercase SHA-256 as `V7-QUALITY-GATES.md` §2
requires. Digests recorded 2026-08-23.

| Artifact (`Saved/Logs/`) | Bytes | SHA-256 |
|---|---:|---|
| `UBT-Phase02-NexusFrameworkEditor-Win64-Development-2026-08-23.log` | 8,188 | `838f9774f1ea7aa3c31ca07b350fde3cc15e617dc6b53c9a6111267e70e9dedc` |
| `UBT-Phase02-NexusFramework-Win64-Development-2026-08-23.log` | 4,458 | `68b058ff3f4f3bcbc5ec85ae74178ac4c4f24c2900ba44b7d4e7526221104ed1` |
| `UBT-Phase02-NexusFramework-Win64-Shipping-2026-08-23.log` | 4,602 | `cb66acf5132bec24aa82d36edd643bab6e878eb8c684cd62e257b794641ceb57` |
| `Automation-Phase02-Modules-2026-08-23.log` | 314,847 | `e3bdfc216f80c7c123b074449c7ab5cb2149be22f7d67758bf6d5f839d9ee8a4` |
| `Automation-Phase02-Modules-2026-08-23-negative.log` | 315,477 | `b3021912155c18f6a613ec4cc5b7f3f72535db46ddf0bac8abb56ca64bad3859` |
| `Foundation-Structural-Scan-Phase02-2026-08-23.log` | 1,423 | `ba8d6dac954a19ecaebc1f56865f54d89164fb220fed5b183dd17d2c13701028` |
| `Foundation-Structural-Scan-Phase02-Final-2026-08-23.log` | 1,428 | `455ff91021368b2d9ae2153d782a7e6d695fdf3c9198e3c0b18cef1b37ea08fb` |
| `Automation-RuntimeCook-Prepare-2026-08-23.log` | 288,160 | `c7f4814a8d116007e6a315fac6f242b75671b93a8c966bde0fef99b54f2a4fda` |
| `UAT-Phase01-CookPackage-2026-08-23.log` | 144,658 | `f35ea1f86fe829d264643c6813e756b7a46a74e916b26ff6a6711cff678b3150` |
| `Packaged-RuntimeDataset-2026-08-23.log` | 67,159 | `d8c1fe9eb8d38d2286c5bad843db98b99d4a1e707fadc3f2e91a7ea6bc66b427` |

The negative-proof row is retained deliberately: it is the artifact that shows the
new guard failing, and a guard is only evidence once it has been seen to fail.

## Open items carried out of Phase 02

- **E0 is not satisfied.** Phase 02 requires an independent module-dependency
  review. This agent implemented the phase and cannot review its own work.
- F-06 (authoring payloads persisted twice, no authoring-size budget) and F-07
  (load delegate hygiene) remain carried to Phase 07, unchanged by this phase.
- F-09 (no non-test entry point creates a `UNexusWorldDefinition`) remains carried
  to Phase 07. Phase 02 adds no Slate widgets by design; the module, tab, and menu
  code visible in the editor is still labelled non-production Phase 01 spike
  infrastructure and is not Phase 02, 03, or 04 acceptance evidence.
