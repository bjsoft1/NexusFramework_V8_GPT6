# Phase 08 — F-08-16, Revert scoped to selection, and a wrong test assertion caught re-running it (2026-09-02)

Implementing-agent evidence. This is not an acceptance record. Phase 08 remains In
Progress: its dependency is unmet, E0 and E3 have not run, and F-08-06 still needs a
user decision.

## What this pass closes

Commit `bd92ac6` ("Improve destructive command logging and draft handling") landed
with two production fixes and two new regression tests, but — per
[[verify-claims-by-re-running]] — had not yet been through an actual clean-build gate
run. Running it found that one of the two new tests asserted the wrong thing.

## F-08-16 — Revert Draft was wiping unrelated kept drafts, and Activity recorded no summary — fixed in bd92ac6

**Blocking, fixed** (before this pass; verified here for the first time).
`FNexusDetailsView::Revert()` unconditionally called `KeptDrafts.Reset()` as a side
effect of reverting the *currently selected* target, so reverting one entity's
unapplied edit silently discarded every unrelated parked draft elsewhere in the
document — while Revert's own preview only ever named the selected entity, so the
user was never told the parked work was at risk. Separately, `Execute()` only ever
passed a `Message` to `FNexusOperationHistory::Complete` on failure, so a successful
destructive command left Activity with the bare status word ("Completed") instead of
what actually happened.

**Fix.** `Revert()` no longer touches `KeptDrafts`; `DiscardKeptDrafts()` remains the
explicit, separate operation for clearing parked work. `FNexusCommandService::Execute`
now reuses the `FNexusCommandPreview` that `CheckConfirmation` already built and
verified against the approval, rather than rebuilding it, to populate both the
Activity message (the confirmed preview's summary) and a new `TargetSummary` field
(named items when three or fewer, a count otherwise — the same threshold this project
uses elsewhere).

## The regression test that shipped with the fix asserted the wrong invariant

`Nexus.V7.Details.RevertLeavesKeptDrafts` (added in the same commit) failed on the
first real run:

    Error: Expected 'clearing the selected draft' to be false.
    [NexusDetailsTests.cpp(680)]

**Not a production defect.** The test dirtied City A, navigated away (parking it in
`KeptDrafts`), dirtied City B (the current selection), reverted B, and then asserted
`Fixture.View().IsDirty()` was `false`. But `FNexusDetailsView::IsDirty()` is
document-wide by design — it walks `KeptDrafts` as well as the currently bound
`Targets` — which is exactly what `Nexus.V7.Details.LargeSelectionDeferred` already
proves elsewhere in the same file (`TestTrue("the existing dirty draft remains
protected", Fixture.View().IsDirty())` for a dirty draft outside the interactive
selection). City A's parked draft was still legitimately dirty, so `IsDirty()`
correctly stayed `true`; the new test's own later lines already relied on that draft
surviving. `GetDirtyTargetCount()`, which counts only the currently-bound `Targets`
and ignores `KeptDrafts`, is the assertion that actually answers "did Revert clear the
target it was run against."

**Fix.** Changed the one assertion:

    TestFalse(TEXT("clearing the selected draft"), Fixture.View().IsDirty());
    // to
    TestEqual(TEXT("clearing the selected draft"), Fixture.View().GetDirtyTargetCount(), 0);

No production code changed for this correction. Nothing else in the test needed to
change — `GetKeptDraftCount() == 1`, `HasKeptDraftFor(Cities[0])`, and re-selecting
City A to confirm its edit survived were all already correct.

**Verified by re-running, not by inspection.** The first full gate run (`RunLabel
2026-09-02-104526`) failed exactly this one assertion with everything else — three
clean builds, the other 155 tests, all 21 budgets — passing. After the one-line test
fix, a second full clean run (`RunLabel 2026-09-02-104935`) passed outright.

## Commands and results

Full gate, with clean builds (no `-SkipBuilds`):

    powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1

First run (`2026-09-02-104526`) — one failure, the test bug above:

- `PASS: clean build NexusFrameworkEditor-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Shipping`
- `FAIL: Nexus.V7.Details.RevertLeavesKeptDrafts`
- Every other suite passed; all 21 budgets passed.

Second run (`2026-09-02-104935`), after fixing the assertion:

- `PASS: clean build NexusFrameworkEditor-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Shipping`
- Suite counts: Hierarchy 17, UiStates 5, Module 12, Details 28, Foundation 21,
  UiGate 10, Command 17, Crud 22, Shell 20.
- `PASS: 156 tests, 0 failures`
- `PASS: 21 budget measurements, 0 over`
- `PHASE 08 E1+E2: PASS`

Details' count moves from 26 (the 2026-09-01 F-08-14 pass) to 28 — exactly the two
tests this commit added
(`Nexus.V7.Details.RevertLeavesKeptDrafts`,
`Nexus.V7.Details.RevertRecordsActivitySummary`). No other suite's count moved.

Budget artifact: `Saved/NexusV7/Phase08/ui-budgets-2026-09-02-104935.txt`, 1,011
bytes, SHA-256
`13082C0DED6B83AC77F524606BFA46279E0CC0AF1B786EC7643E8257FCBA1E7A`.
Automation log: `Saved/Logs/Automation-Phase08-UiGate-2026-09-02-104935.log`.

Key measurements on this pass (all budgets met, no overages across all 21):

- `Filter.100kRows.p95Ms=8.267` (budget 150)
- `Sort.100kRows.worstMs=8.461` (budget 150)
- `Search.100kEntities.worstKeystrokeMs=42.254` (budget 250)
- `IncrementalRefresh.100kRows.p95Ms=3.104` (budget 50)
- `Details.selectAllVisible.ms=4.333` (budget 300)
- `Selection.hierarchyToDetails.ms=9.473` (budget 100)
- `Shell.coldThreeTab.ms=4.358` (budget 750)

## What remains

E0 and E3 have not run. F-08-06 (ownership-mismatch) and F-08-15 (payload CRUD UI
gesture) still need the user's reading. Seven of Phase 08's nine task lines remain
unchecked or partial. This pass does not by itself move Phase 08 or any earlier
phase's status.
