# Phase 08 — F-08-18, Home's onboarding badges and text made honest (2026-09-02)

Implementing-agent evidence. This is not an acceptance record. Phase 08 remains In
Progress: its dependency is unmet, E3 has not run, and F-08-06 and F-08-15 still need
a user decision.

## What this closes

[The E0 independent review](phase-08-e0-independent-review-2026-09-02.md) filed
**E0-03, Warning**: Home's onboarding widget (`SNexusHomeView`) had two of its four
badges hardcoded to `ENexusShellState::Empty` regardless of the real document or
editor state, and two of the four step bodies described already-shipped Phase 05/06
work as a future phase delivery. This closes it as **F-08-18**.

## F-08-18 — Home onboarding steps now computed, and covered for the first time

**Warning, fixed.** `SNexusHomeView::HandleStateChanged()` computed
`DocumentStep` and `ContentStep` from real `FNexusShellDocumentInfo` fields
(`bHasDocument`, `EntityCount`), used them for steps 1 and 2, and then hardcoded
`ENexusShellState::Empty` for steps 3 ("Edit in Details") and 4 ("Resolve findings in
Activity") — correct when this widget was first written in Phase 03, before Phases
05 and 06 existed, and never revisited once they shipped. Steps 2 and 3's body text
had the same problem in words: *"...arrive with Phase 05"* / *"...arrive with Phase
06"*, describing capabilities the build has actually delivered as still pending.

**Fix.** Extracted the whole computation into a new pure function,
`SNexusHomeView::ComputeOnboardingSteps(const FNexusShellDocumentInfo&) -> TArray<FNexusHomeOnboardingStepInfo>`
(`FNexusHomeOnboardingStepInfo` declared in the public `NexusShellTypes.h`) — the
same shape as `DeriveShellState`, with no Slate dependency, so what each badge and
body actually say is provable directly rather than only by looking at Home.
Steps 3 and 4 now use the same `ContentStep` signal step 2 already computes (`EntityCount > 0`):
editing a property and reviewing activity/diagnostics both require an entity to act
on, exactly like building the hierarchy does, so reusing that already-real signal is
honest rather than a second, differently-named copy of it or an invented new one.
Steps 2 and 3's text now describes the capability as delivered and live rather than
arriving with a named phase. Step 4's text already read that way and needed no
change. `HandleStateChanged()` now just calls `ComputeOnboardingSteps` and builds a
row per entry.

A new public wrapper, `NexusShell::GetHomeOnboardingSteps(const FNexusShellDocumentInfo&)`
in `NexusShellFactory.h`/`SNexusShellSurface.cpp`, forwards to the static method —
the same pattern `HomeRecoveryRunsCommands` and `CountSurfaceWidgetsOfType` already
use to let `NexusTests` reach a private `NexusEditorUI` widget without crossing the
module's private/public boundary.

**Test coverage for this widget goes from zero to one.** The E0 review noted no test
in `NexusTests` had ever referenced `SNexusHomeView`. `Nexus.V7.Shell.HomeOnboardingReflectsRealState`
now asserts: with no document, all four steps read Empty; with a document bound but
no content, step 1 reads Ready and steps 2–4 read Empty (proving they are no longer
hardcoded); with a document and content, all four read Ready; and none of the four
bodies contains the phrase "arrive with Phase" once the steps are Ready.

**Verified by re-running**, per `[[verify-claims-by-re-running]]`: the isolated test
passed on the first run after the refactor, and a full clean gate confirmed no
regression elsewhere.

## Commands and results

    powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1

- `PASS: clean build NexusFrameworkEditor-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Shipping`
- Suite counts: Hierarchy 17, UiStates 5, Module 12, Details 28, Foundation 21,
  UiGate 10, Command 17, Crud 23, Shell 21.
- `PASS: 158 tests, 0 failures`
- `PASS: 21 budget measurements, 0 over`
- `PHASE 08 E1+E2: PASS`

Shell's count moves from 20 to 21 — exactly the one new test this fix added. No
other suite's count moved.

Budget artifact: `Saved/NexusV7/Phase08/ui-budgets-2026-09-02-121636.txt`, 1,011
bytes, SHA-256
`C4500755C8455F0BBE489232823847CED21736D54026552F624C459CCA1DCD69`.

## What remains

E3 has not run. F-08-06 and F-08-15 still need the user's reading. E0-02 (the
F-08-16 Activity-summary fix reaches only destructive commands) from the same review
is recorded but not acted on. This pass does not by itself move Phase 08 or any
earlier phase's status.
