# Phase 08 — UI Completion Gate: first measurement pass (2026-08-28)

Implementing-agent evidence for the Phase 08 UI Completion Gate. This is E1 and E2
only. It is **not** an acceptance record: Phase 08 additionally requires E0
independent review and E3 user manual acceptance, and neither has been performed.

Phase 08's dependency line reads "Phases 03, 04, 05, 06, and 07 Complete." Phases 05,
06, and 07 are Ready for Review, not Complete, and their E3 runs have not happened.
Work started here on the user's instruction, the same way Phase 06 started on an
incomplete Phase 05 and Phase 07 on an incomplete Phase 06. That is recorded rather
than smoothed over.

## Commands

```text
Build.bat NexusFrameworkEditor Win64 Development -Project=<repo>\NexusFramework.uproject -WaitMutex -NoHotReloadFromIDE
powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1 -SkipBuilds
```

`Scripts/VerifyPhase08UiGate.ps1` runs the whole `Nexus.V7` sweep rather than one
suite, because Phase 08's gate is that every Phase 03–07 gate still holds *together*.
It also deletes and then collects the budget report, and emits a dated artifact with
a byte count and a SHA-256.

## E1 — build

`Result: Succeeded` on `NexusFrameworkEditor Win64 Development`. The three clean
builds (`-clean` on editor, Game Development, and Game Shipping) were **not** run for
this pass; `-SkipBuilds` was used. They are required before this phase is proposed for
review.

## E2 — automated

136 of 137 tests pass. The one failure is a genuine finding, not a flake, and is
described under F-08-04 below.

| Suite | Results |
|---|---:|
| `Nexus.V7.Foundation` | 21 |
| `Nexus.V7.Module` | 12 |
| `Nexus.V7.Shell` | 19 |
| `Nexus.V7.Command` | 17 |
| `Nexus.V7.Hierarchy` | 15 |
| `Nexus.V7.Details` | 23 |
| `Nexus.V7.Crud` | 17 |
| `Nexus.V7.UiGate` | 9 (new) |

## The gap this pass closed

Phase 08's acceptance gate includes "Representative scale meets Phase 01 UI budgets."
Nothing measured one. `Nexus.V7.Hierarchy.Scale` says so in its own comment — its
ceilings are "deliberately loose", they "catch a collapse into quadratic work", and
"they are not the budget measurement". So the gate item had a test next to it that
explicitly disclaimed being evidence for it.

`Nexus.V7.UiGate` is that measurement. Every test names the exact line it checks from
`V7-UX-SPEC.md` section 19 or `V7-ARCHITECTURE.md` section 12 and asserts against that
number rather than one chosen to pass, and every measurement is appended to a report
file so the number survives the log.

## Budget results

Reference dataset: `ENexusSyntheticShape::Large`, 100,000 hierarchy rows.

Artifact: `Saved/NexusV7/Phase08/ui-budgets-2026-08-28.txt`, 1003 bytes,
SHA-256 `08FE3B16920CDA334192F7BD5EA1257B02B2DE76B5E9943B4BDF7A3FF2DD0F18`.

> **This artifact no longer exists.** A second Phase 08 pass ran later on 2026-08-28,
> and `-RunLabel` defaulted to the date alone, so the copy step overwrote the file
> this citation identifies. The digest above is now unverifiable and the numbers in
> the table below are the only surviving record of that run. Recorded as F-08-10 in
> [the UI-state pass](phase-08-ui-states-2026-08-28.md), which is also where the fix
> is: the label now carries a time, and the script refuses to overwrite an artifact
> that already exists rather than doing it silently.

| Measurement | Budget | Before | After | |
|---|---:|---:|---:|---|
| Filter, 100k rows, p95 | 150 ms | 111.5 | **19.4** | PASS |
| Sort, 100k rows, worst | 150 ms | 411.6 | **28.7** | PASS |
| Search, 100k entities, worst keystroke | 250 ms | 617.2 | **181.4** | PASS |
| Search, clear | 250 ms | 447.3 | **59.8** | PASS |
| Incremental refresh, p95 | 50 ms | — | **22.9** | PASS |
| Incremental refresh, rebuild count | 0 | — | **0** | PASS |
| Select All Visible, 100k rows | 100 ms | — | **22.4** | PASS |
| Invert Selection, 100k rows | 100 ms | — | **63.4** | PASS |
| Single selection to Details bound, p95 | 150 ms | — | **5.8** | PASS |
| 1,000-item multi-selection summary | 300 ms | — | **13.7** | PASS |
| **Select All → Details bound, 100k rows** | **300 ms** | — | **1264.5** | **OVER** |
| Command palette, cold open | 250 ms | — | **0.4** | PASS |
| Command palette, warm keystroke, p95 | 100 ms | — | **0.4** | PASS |
| Cold three-tab workspace shell | 750 ms | — | **10.6** | PASS |
| Warm single-tab invoke, p95 | 250 ms | — | **7.8** | PASS |

"Before" is the measurement taken before the corrections below; a dash means the
measurement did not exist.

Recorded without a budget: 100,000-row document and snapshot cost ~48 MiB process
resident delta, and a second build costs the same, so nothing retains the first.

The filter budget is stated at 10,000 rows and measured here at 100,000 — ten times
harder than the budget asks. The 10,000-row budget passes a fortiori.

These ran on this workstation, which is not certified as the reference workstation.
They are a regression guard; the recorded reference run is what the gate cites.

## Corrections applied

### F-08-01 — Sort tie-breakers stringified two GUIDs per comparison (Blocking, fixed)

Four sorts spelled their stable tie-break as `Left.ToString() < Right.ToString()` on
a `FNexusId`. Sorting the 100,000-row reference tree ran roughly 1.7 million
comparisons and therefore allocated roughly 3.4 million strings, each one formatting
a GUID into 36 characters and discarding it.

Sites: `NexusHierarchyQuery.cpp:373`, `NexusHierarchyModel.cpp:366`,
`NexusHierarchyModel.cpp:509`, `NexusRepository.cpp:83`.

Fixed by adding `FNexusId::operator<`, which compares the GUID components.
`EGuidFormats::DigitsWithHyphensLower` prints A, B, C, D as fixed-width lowercase hex
with the separators at identical offsets in every ID, so the two orderings are the
same — and `Nexus.V7.UiGate.IdOrdering` holds them against each other over 225,996
pairs, including crafted component-boundary cases, rather than leaving the claim in a
comment. The comparator is also checked for irreflexivity and asymmetry.

Sort at reference scale: 411.6 ms → 28.7 ms.

### F-08-02 — The filter allocated four strings per row before knowing which it needed (Blocking, fixed)

`FNexusHierarchyQuery::Matches` runs once per row and opened by building `NameText`,
`TypeText`, `KindText`, and `IdText` unconditionally — 400,000 allocations per
keystroke at reference scale, of which a typical query uses one. `IdText` was the
worst: formatting a GUID, for a term almost no query carries.

Fixed by building each only when the corresponding term list is non-empty, still at
most once per row.

Search worst keystroke: 617.2 ms → 181.4 ms. Filter p95: 111.5 ms → 19.4 ms.

### F-08-03 — Three quadratic paths on the selection route (Blocking, fixed)

`FNexusSelectionModel::SetSelection` deduplicated with `AddUnique`;
`FNexusSelectionModel::InvertVisible` used two nested linear `Contains`;
`FNexusDetailsView::SetSelection` did both. Each is quadratic in the size of the
selection.

Select All Visible is a Phase 05 command that ships in this build and is bound to a
chord, and on the reference tree it hands the entire tree to all three in one call —
about five billion comparisons per path. That is an editor that stops responding, not
a slow command.

No test caught it because section 19 budgets multi-selection at 1,000 items, and at
1,000 items all three passed comfortably. The size that decides whether the command is
usable is 100,000.

Fixed by deduplicating and testing membership through `TSet` in all three, preserving
the caller's order. `Nexus.V7.UiGate.SelectAllAtScale` performs Select All and both
directions of Invert at reference scale and asserts order row-for-row as well as time.

Select All: 22.4 ms. Invert: 63.4 ms. Details bound to 10,000 rows: 224 ms → 114 ms,
and its scaling ratio for ten times the items fell from 23.5x to 8.3x.

### F-08-04 — Details builds a draft proxy for every selected entity, eagerly (Blocking, OPEN)

Section 19's multi-selection line reads in full: "Multi-selection summary for 1,000
selected loaded items: 300 ms, **with details calculated incrementally afterward if
needed**." The trailing clause is a design instruction and V7 does not follow it.
`FNexusDetailsView::RebuildTargets` constructs a draft proxy `UObject` for every
selected entity however many there are.

So the 1,000-item case passes on speed (13.7 ms) while the mechanism the budget
assumes is absent, and Select All on the reference tree pays for 100,000 proxies
nothing will draw: **1264 ms**, measured between 665 ms and 1265 ms across runs as
GC pressure varies.

This is left open and failing. Closing it means a bounded or incremental target
build, which changes a contract Phase 06 owns, and `V7-QUALITY-GATES.md` makes a
changed architectural contract a decision that reopens the owning checkpoint. That is
the user's call, not the implementing agent's.

`Nexus.V7.UiGate.SelectAllAtScale` fails on this assertion. The assertion is written
against the budget, not against a ceiling chosen to accommodate the current
behaviour, and its message names the missing mechanism.

## Audit findings carried, not yet resolved

### F-08-05 — "No required UI behavior is deferred to Phase 09 or later" vs. the pending-phase catalog (Information, CLOSED 2026-08-28)

> **Resolved by the user on 2026-08-28: the commands stay.** The gate item means
> *nothing Phases 03-08 owe is deferred*. A menu entry that answers "Phase 12 delivers
> this" states a fact and is not a dead item. User: *"maybe no need to change here
> phase 12 will done."* The original finding is left below as written.

The Phase 08 acceptance gate says no required UI behaviour may be deferred to Phase 09
or later and no dead command may remain. The command catalog deliberately registers
16 commands owned by Phases 10 through 16 — validation, impact, dependencies, quick
fix, conflict resolution, viewport focus, generation preview, runtime compile — each
refusing with the phase that delivers it. That is the Phase 04 design and it is
correct behaviour, not a dead item.

The two readings need reconciling in writing before the gate can be signed: either the
gate means "nothing Phases 03–08 owe is deferred" (which holds), or those 16 commands
must be removed from the catalog until their phase arrives (which would undo Phase
04's inventory). No code change is proposed here; the sentence needs an owner's
reading.

Verified during the audit: every command whose owning phase is 07 or earlier has a
real registered handler, and every command owned by a later phase resolves to
`FNexusPendingPhaseCommandHandler`, which names the delivering phase.
`DeliveredThroughPhase` is 7 and Phase 08 delivers no new commands, so it stays 7.

### F-08-06 — Ownership-mismatch state (Information, needs a decision)

Phase 08's task list names "ownership-mismatch" among the states to test.
`phases/phase-10.md` "Delivered Early" records ownership-mismatch clone/relink/cancel
as still belonging to Phase 10. The Phase 08 task and the Phase 10 reservation
overlap and one of them should give.

The other eight states in that task — empty, loading, dirty, invalid, blocked,
unknown-payload, stale, save-failure — are all present: `ENexusShellState` carries
nine states, `Nexus.V7.Shell.StateDerivation` and `Nexus.V7.Shell.StatePresentation`
cover them exhaustively, and unknown payloads surface through
`ENexusDetailsTargetState::UnknownPayload`.

### F-08-11 — Placeholder sweep found nothing (Information, no action)

> Recorded as F-08-07 on 2026-08-28 and renumbered later the same day: the user
> reported two Blocking defects that were logged as F-08-07 and F-08-08 in
> `PHASE-STATUS.md` before this collision was noticed. Those two are cited in commit
> messages; this one is not, so this is the entry that moved.

Recorded because a clean result is also a result. A case-insensitive sweep of the
plugin for `TODO`, `FIXME`, `HACK`, `placeholder`, `not implemented`, `stub`,
`for now`, and `mock` returns no marked incomplete work; the only hits are the word
"temporary" describing the atomic-write temp file in `NexusDraftRecovery`. This
covers marked placeholders only, and says nothing about unmarked ones — F-08-04 was
not marked.

## What this pass did not do

Phase 08 has nine tasks. This pass covers the responsiveness and scale task in full,
the audit and placeholder tasks in part, and none of the rest:

- E0 independent UI architecture and contract review — not performed.
- E3 user manual acceptance after cold restart — not performed, and it subsumes the
  outstanding Phase 05, 06, and 07 E3 runs.
- Three clean builds — not run for this pass.
- DPI, resize, contrast, keyboard navigation, focus restoration, shortcut discovery,
  tooltips at a real resolution — `Nexus.V7.Shell.SurfaceLayout` lays every surface
  out in every state at 100% and 200% and `Nexus.V7.Shell.PaletteContrast` holds the
  palette to a ratio, but painted appearance is E3.
- Tree scrolling frame rate on 100,000 rows — the CPU half is implied by the filter
  and refresh measurements; the 60/30 FPS line needs a renderer and is E3.
- Painted latency for "single selection to Details bound **and painted**" — binding
  is measured at 5.8 ms; painting is E3.
- Destructive previews, affected counts, confirmation, cancellation, rollback —
  covered by existing `Nexus.V7.Crud` and `Nexus.V7.Command` tests, not re-audited
  here.
- The UI/service contract freeze — not written.
