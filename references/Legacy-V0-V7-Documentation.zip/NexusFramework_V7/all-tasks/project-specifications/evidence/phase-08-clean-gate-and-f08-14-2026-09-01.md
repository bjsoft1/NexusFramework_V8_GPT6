# Phase 08 — first full clean E1+E2 pass, and F-08-14 (2026-09-01)

Implementing-agent evidence. This is not an acceptance record. Phase 08 remains In
Progress: its dependency is unmet, E0 and E3 have not run, and F-08-06 still needs a
user decision.

## What this pass closes

The 2026-08-31 collapsed-tree-lag and row-menu-hover-lag corrections
([evidence](phase-08-large-hierarchy-idle-lag-2026-08-31.md),
[evidence](phase-08-large-context-menu-hover-2026-08-31.md)) were committed with their
own regression tests **unbuilt and unrun**, because a local `dotnet.exe` error was
blocking UnrealBuildTool at the time. That blocker is gone on this workstation as of
this pass — a plain editor build now succeeds — so this is the first time those two
corrections, and the bounded-Details correction before them, have all been built and
run together in one clean E1+E2 sweep.

## F-08-14 — reload silently skipped the repository rebind, found by that first real run

**Blocking, fixed.** Running the full gate for the first time (rather than
`-SkipBuilds`) surfaced `Nexus.V7.Crud.RecoveryBeforeReload` failing with *"None of
the autosaved fields could be restored. The entities they belong to may no longer be
in the document."* `git blame` shows this test was added in the same commit as the
bounded-Details correction (8a617fe, 2026-08-31), but the evidence run that commit
cites (`-RunLabel 2026-08-31-f08-04-r5`, 148 tests) predates the test being added to
the tree — its own log has zero occurrences of the test's name. So this was the
**first time this specific test had ever actually executed**, not a regression from
the two lag fixes.

Root cause, isolated with temporary diagnostic logging (`UE_LOG` at each branch of
`FNexusDetailsView::FindOrCreateRecoveryDraft`, `SetSelection`, `RebuildTargets`, and
`UNexusEditorSubsystem::SetActiveDocument`, all removed again once the cause was
confirmed):

`UNexusEditorSubsystem::SetActiveDocument` starts with `if (ActiveDocument ==
InDocument) { return Unchanged; }` as a fast path for callers where nothing actually
changed. The Reload command's `ExecuteReload` calls
`FNexusDocumentStore::Reload(Context.Document)`, which invokes
`UPackageTools::ReloadPackages` on the currently active document's package —
and that engine call performs its own reference-replacement pass, silently repointing
every still-reachable reference to the old object (`ActiveDocument`, a rooted
`UPROPERTY`, included) at the newly reloaded object, *before* `ExecuteReload`'s
explicit `Subsystem->SetActiveDocument(Inner.Document, ...)` call ever runs. By the
time that call happens, `ActiveDocument` already equals `InDocument`, so the fast path
fires and `Repository.SetDocument(InDocument)` — along with the selection reset and
both change broadcasts — never runs. `FNexusWorldDefinitionRepository` is left
holding a weak reference to the pre-reload object, which the reload has destroyed;
`Repository->IsValid()` reads false from then on, and `Recover Draft`'s repository
fallback in `FindOrCreateRecoveryDraft` returns null for every entity, restoring zero
fields. Confirmed directly: a diagnostic on `SetActiveDocument`'s entry logged
`ActiveDocument=0x...BF40 InDocument=0x...BF40 equal=1` for the Reload call
specifically, the two pointers already identical on entry.

Fixed by adding a `bForceRebind` parameter to `SetActiveDocument` (default `false`,
preserving every other call site's existing behavior — New/Open/Close Document and
every test caller), passed `true` only from `ExecuteReload`, which is the one call
site whose `InDocument` can come from `ReloadPackages`. `SetActiveDocument`'s guard
becomes `if (!bForceRebind && ActiveDocument == InDocument)`. See
`Plugins/NexusFrameworkV7/Source/NexusEditor/Public/NexusEditorSubsystem.h`,
`Private/NexusEditorSubsystem.cpp`, and `Private/NexusAuthoringCommands.cpp`
(`ExecuteReload`).

**Verified by re-running the exact failure, not just asserting the fix.** Before
committing to the fix, the failure was reproduced in isolation
(`-ExecCmds="Automation RunTests Nexus.V7.Crud.RecoveryBeforeReload; Quit"`) with the
diagnostics in place, confirming `Repository->IsValid()` was false at the exact call
site. After the fix, the same targeted run passes, and the full `Nexus.V7.Crud` suite
(22 tests) passes with no other regressions.

This is a pre-existing defect in the Reload/recovery interaction, not something
introduced by the two lag-fix commits — it predates them and was invisible until its
one covering test finally ran for the first time.

### Independent read of the F-08-14 fix

A separate Claude session on the same workstation (`nexusframework-v7-17`), which did
not implement this fix and made no edits, reviewed it read-only and confirmed it
correct and correctly layered: `FNexusDocumentStore::Reload`'s one
`UPackageTools::ReloadPackages` call site has exactly one caller (`ExecuteReload`,
the site fixed); no other reference-replacement API
(`ForceReplaceReferences`/`FArchiveReplaceObjectRef`/`ConsolidateObjects`) is used
anywhere in the plugin; forcing the rebind through an already-equal pointer is
idempotent (`AutosaveDrafts` is suppressed via
`bOutgoingDraftsAlreadyRecovered=true`, everything after is unconditional
assignment/rebuild); and the repository genuinely cannot self-heal without this fix,
since `RebuildIndexIfStale`'s own staleness check (`IndexedDocument != Document`)
compares two weak pointers to the same destroyed object post-reload and never fires.
This is scoped review of one finding, not the Phase 08 E0 gate (an independent review
of the whole UI architecture and contract set), which remains unperformed.

Two follow-ups from that read, recorded but not implemented — see
[[reload-can-pre-update-the-pointer-your-guard-checks]] for the full reasoning:
a self-healing form of the guard that would also cover any future silent-replace path
without a caller needing to remember a flag (deferred: it changes `Unchanged`
semantics and needs its own full-suite verification pass), and a same-shape but
currently-unreachable site in `BindDocumentForActiveWorld`.

That read also caught a cleanup item: verifying this fix left two untracked,
un-gitignored stray assets (`Content/Nexus/NexusWorld_1.uasset`,
`NexusWorld_2.uasset`) from automated `New Document` tests running against the real
default package path across repeated suite runs. Deleted before they could be swept
into a commit.

## Commands and results

Full gate, with clean builds (no `-SkipBuilds`):

    powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1

Result:

- `PASS: clean build NexusFrameworkEditor-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Shipping`
- Suite counts: Hierarchy 17, UiStates 5, Module 12, Details 26, Foundation 21,
  UiGate 10, Command 17, Crud 22, Shell 20.
- `PASS: 154 tests, 0 failures`
- `PASS: 21 budget measurements, 0 over`
- `PHASE 08 E1+E2: PASS`

Budget artifact: `Saved/NexusV7/Phase08/ui-budgets-2026-09-01-193242.txt`, 1,013
bytes, SHA-256
`987C0B3C28F947FD0D0C8D2B3D62980F45E3EFE60A4408B5E850F84E446B1560`.
Automation log: `Saved/Logs/Automation-Phase08-UiGate-2026-09-01-193242.log`.

Key measurements on this pass (all budgets met, no overages across all 21):

- `Filter.100kRows.p95Ms=7.724` (budget 150)
- `Sort.100kRows.worstMs=11.722` (budget 150)
- `Search.100kEntities.worstKeystrokeMs=89.790` (budget 250)
- `IncrementalRefresh.100kRows.p95Ms=9.975` (budget 50)
- `Details.selectAllVisible.ms=4.667` (budget 300)
- `Selection.hierarchyToDetails.ms=9.803` (budget 100)
- `Shell.coldThreeTab.ms=4.598` (budget 750)

## What remains

E0 and E3 have not run. F-08-06 (ownership-mismatch) still has no representation in
the build and still needs the user's reading. Seven of Phase 08's nine task lines
remain unchecked or partial. This pass gives Phase 08 its first-ever clean E1+E2 run
covering everything implemented to date, including the two 2026-08-31 lag fixes and
the F-08-14 correction above — it does not by itself move Phase 08 or any earlier
phase's status.
