# Phase 01 Foundation Evidence — 2026-08-22

## Verdict

**Ready for Review — not Complete.** E1, E2, and E4 are green. Independent
architecture/traceability review E0 and user acceptance remain required.

## Final review-candidate update

- Cold Editor Development: passed, 67 actions, 30.406 s.
- Cold Game Development: passed, 11 actions, 27.006 s.
- Cold Game Shipping: passed, 10 actions, 26.818 s.
- Foundation automation: 21/21 passed, exit code 0, 14.513 s, 2,901.43 MiB
  peak working set, zero unexpected automation warnings/errors.
- Cold restart: passed in three separate editor processes.
- Full cook: 511 packages, zero cook warnings/errors; stage, pak/IoStore,
  archive, and packaged runtime dataset validation passed.
- Runtime schema is immutable and exact-validated; Build ID is derived from
  canonical schema/compiler/source provenance with BLAKE3.
- Migration is candidate-first, whole-document validated, and atomic.
- CRUD validates the complete owned graph; clone/rekey rewrites root references
  and registered IDs nested inside typed payloads.
- Real removed-native-type fixture passed clean-build load, read-only recovery,
  save, unload, reload, exact byte/hash preservation, and source-fixture integrity.

Final logs are retained under `Saved/Logs`, which is not under source control.
Each is identified below by byte count and lowercase SHA-256 as required by
`V7-QUALITY-GATES.md` §2 "Artifact retention", so a later reader can prove the
file they hold is the file cited here. Digests recorded 2026-08-22.

The cook/package and packaged-runtime rows were regenerated later that day, after
the E0 remediation changed the compiled fixture; their digests supersede the
pre-remediation values. See
[Phase 01 E0 independent review](phase-01-e0-independent-review-2026-08-22.md).

| Artifact (`Saved/Logs/`) | Bytes | SHA-256 |
|---|---:|---|
| `Automation-Foundation-Final-2026-08-22.log` | 304,917 | `66dcd2a678d7bf2b994d784101d57b9c3c70434aab4ba11c6a853cc486cd90ef` |
| `UBT-Editor-Cold-Final-2026-08-22.log` | 6,061 | `a44fc648c82edc848fbdda260736a9ff3339e7a44d652e334c1625ed8d719e7f` |
| `UBT-Game-Development-Cold-Final-2026-08-22.log` | 2,488 | `05cc5755f6b9424dbfa1d0ba1f12cf1e1a1c379d061942788674483fb2e7c248` |
| `UBT-Game-Shipping-Cold-Final-2026-08-22.log` | 2,437 | `84d230a782062bc3941e35358b15ba2b2a32ad80801950970c65a04169adbcfc` |
| `UAT-Phase01-CookPackage-2026-08-22.log` | 148,942 | `03b1780cd0b62f6bc93a9a02712fd7804bf36b9bfb2b410e115e5cc98ab0554c` |
| `Packaged-RuntimeDataset-2026-08-22.log` | 67,275 | `a9c5737eda5474555d08745b497b3e1c621f89593e5f90d63581cdd4fb26b85b` |
| `Foundation-Structural-Scan-Final-2026-08-22.log` | 1,075 | `3ba213e97f0be4a572806a3951c792fad80e3af66ef64f2dc4a22bcefc880d69` |
| `Content-Manifest-Final-2026-08-22.log` | 13,699 | `799c7d4efb62421f9201c7e41074535ad7adaa380b5d5c9a1d588d229f355171` |

The detailed baseline is in
[phase-01-baseline-2026-08-22.md](phase-01-baseline-2026-08-22.md).

Final structural scan: `FOUNDATION STRUCTURAL SCAN: PASS`, failures 0; exact
20 phase files, 20×9 required sections, Phase 01 Ready for Review mirror, nine
module descriptors/implementations, zero forbidden runtime-boundary references,
and zero source-debt markers. Log:
`Saved/Logs/Foundation-Structural-Scan-Final-2026-08-22.log`.

Final deterministic content manifest: 107 files, SHA-256
`e33950b9b76e53424902ef88be77adc34c3b27a31ca1de34e886c5fae4e958d3`.
Evidence markdown is excluded as self-referential material. Log:
`Saved/Logs/Content-Manifest-Final-2026-08-22.log`.

Immutable fixtures:

- Previous schema V1: 4,923 bytes; SHA-256
  `5945d8f70cb35c9f729cc1915512967e9f079b8917a7788d7682701a225eeb28`;
  BLAKE3-160 `b9c1dc290031a3d68a937ae9c3bf699d09326a5a`.
- Native struct rename V0: 5,100 bytes; SHA-256
  `51732c7361ea77789bdd7512eab5d7395e7aa0b41ccbc8d027d8377363a34b54`;
  BLAKE3-160 `9a53b4119726f059783c35560712d4b9f02c532d`.
- Removed native type V0: 5,535 bytes; SHA-256
  `a8c66df40eca1d5fdc7ddd8e864113627275eb4081b59ab38f4e7466a1b8d311`;
  BLAKE3-160 `ea341a65503af0f21ad49f5e0997f324c658eac2`.

The sections below preserve the earlier provisional checkpoint as historical
context; the final update above supersedes its open-item statements.

## Historical provisional checkpoint — implemented artifacts

- Clean Unreal Engine 5.8 project and NexusFrameworkV7 plugin.
- Nine plugin modules with explicit runtime/editor boundaries.
- Typed FNexusId identity and stable entity selection keys.
- Registered V7 custom serialization GUID.
- Versioned UNexusWorldDefinition schema with FInstancedStruct fields under
  persistence proof.
- Activation record with owner Landscape ID, anchor ID, Type Key, payload version,
  transform, enabled state, and an FInstancedStruct field intended for persistence;
  saved-asset persistence is not yet proven.
- Draft runtime dataset header with schema/compiler versions, a target
  deterministic-build-ID field, source ID/revision/hash, flat records, bounds, and
  payload bytes. Immutability and deterministic derivation are not yet proven.
- Central editor subsystem for active document plus ordered, document-bound,
  primary/anchor-aware multi-selection.
- Three independent non-production Nomad tab previews: Hierarchy, Details, and
  Activity.
- Window > Nexus Framework V7 foundation-preview menu and one shared command list.

## Provisional E1 observations — builds

All commands used Unreal Engine 5.8.1 installed at
C:/Program Files/Epic Games/UE_5.8. The
[reference environment](reference-environment-2026-08-22.md) records the hardware
and toolchain.

~~~text
Build.bat NexusFrameworkEditor Win64 Development
  -Project=E:/Projects/Game/UE/NexusFramework/NexusFramework_V7/NexusFramework.uproject
  -WaitMutex -NoHotReloadFromIDE
Result: Succeeded; 14.16 s; completed 2026-08-22 17:25:35 +05:45
Raw log: Saved/Logs/UBT-Editor-Development-2026-08-22.log

Build.bat NexusFramework Win64 Development
  -Project=E:/Projects/Game/UE/NexusFramework/NexusFramework_V7/NexusFramework.uproject
  -WaitMutex
Result: Succeeded; 24.76 s; completed 2026-08-22 17:26:05 +05:45
Raw log: Saved/Logs/UBT-Game-Development-2026-08-22.log

Build.bat NexusFramework Win64 Shipping
  -Project=E:/Projects/Game/UE/NexusFramework/NexusFramework_V7/NexusFramework.uproject
  -WaitMutex
Result: Succeeded; 29.36 s; completed 2026-08-22 17:26:38 +05:45
Raw log: Saved/Logs/UBT-Game-Shipping-2026-08-22.log
~~~

The Game and Shipping actions compiled NexusCore, NexusRuntime, and NexusV7Host
only. NexusAuthoring, NexusEditor, NexusEditorUI, NexusLandscapeEditor,
NexusGeneration, NexusCompiler, and NexusTests did not enter the packaged target.
The empty Landscape, Generation, and Compiler scaffolds use `LoadingPhase: None`
and did not auto-load during the final editor automation run.

The raw logs are retained locally under Saved and are ignored by source control.
These command outcomes are not yet final gate evidence: the content manifest is
recorded below, but its cryptographic signature and a human reviewer are still
pending.

## Provisional boundary scan

~~~text
powershell.exe -NoProfile -ExecutionPolicy Bypass
  -File Scripts/VerifyFoundation.ps1
Result: FOUNDATION STRUCTURAL SCAN: PASS; Failures=0
Completed: 2026-08-22 17:27:30 +05:45
Raw log: Saved/Logs/Foundation-Structural-Scan-2026-08-22.log
~~~

The scan proved that the plugin descriptor listed exactly nine modules, every
module had matching build rules and an implementation unit, all 20 phase filenames
matched phase-01 through phase-20, all phase files contained the nine mandatory
sections, both JSON descriptors parsed, and NexusCore/NexusRuntime/NexusV7Host
contained zero editor/UI/Landscape/authoring references. The Game and Shipping
build action lists independently showed only NexusCore, NexusRuntime, and
NexusV7Host.

## Provisional content manifest

~~~text
powershell.exe -NoProfile -ExecutionPolicy Bypass
  -File Scripts/Get-ContentManifest.ps1
Result: 79 files
Manifest SHA-256: 2518436bb9ab52075c165d7fe1e8a84c2ffcfc0d406dc1a3778bb2c1978c49e2
Completed: 2026-08-22 17:28:11 +05:45
Raw manifest: Saved/Logs/Content-Manifest-2026-08-22.log
~~~

The deterministic manifest hashes normalized relative path plus each file's
SHA-256 in ordinal path order. It excludes generated/ignored artifacts and this
evidence report itself to avoid self-reference. The manifest is reproducible but
not yet signed or independently approved.

## Provisional E2 observations — automated tests

~~~text
UnrealEditor-Cmd.exe NexusFramework.uproject -unattended -NullRHI
  -ExecCmds="Automation RunTests Nexus.V7.Foundation;Quit"
Result: TEST COMPLETE. EXIT CODE: 0
Completed: 2026-08-22 17:26:55 +05:45
Raw log: Saved/Logs/Automation-Foundation-2026-08-22.log
~~~

Passed:

1. Nexus.V7.Foundation.StableIdentity — same-process typed-ID/key copy and hash contract
2. Nexus.V7.Foundation.SelectionState — duplicate normalization, primary/anchor,
   revision, stale-document rejection, origin updates, and equivalent write-back
   recursion protection
3. Nexus.V7.Foundation.InstancedPayloadMemoryRoundTrip

The payload test covers an ID field, scalar value, nested dynamic arrays, and a soft
object reference through UNexusWorldDefinition serialization in memory.

## Deliberately open evidence

- Persistent .uasset creation, edit, delete, save, close, and reload.
- Transactional mutation plus exact undo/redo.
- Cold-editor restart of fixed and dynamic payload proof assets.
- Previous-schema migration and repeated-load idempotence.
- Struct rename/Core Redirect and unknown/missing type recovery.
- Opaque recovery-envelope implementation and corruption test.
- World duplicate clone/re-key and mismatch/relink workflows.
- Cooked runtime asset load and complete package run.
- Manual visual/docking/DPI/theme/accessibility evidence for the UI.
- Reference-scale and performance measurements.

Those items are now green as recorded in the final update. Phase 01 remains
Ready for Review—not Complete—until independent E0 and user acceptance.
