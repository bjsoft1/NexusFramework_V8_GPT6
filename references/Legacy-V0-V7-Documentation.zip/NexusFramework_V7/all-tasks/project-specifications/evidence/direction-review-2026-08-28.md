# Direction review — 2026-08-28

Requested by the user: *"check is project going good direction?"*, against five stated
goals. This is an assessment, not phase evidence, and it accepts no phase.

The user named a path, `C:\nexus.workspace\NexusFrameworks\NexusFramework_V7_2026-08-22`,
which **does not exist on this machine** — there is no `NexusFrameworks` directory on any
drive, and `E:\Projects\Game\UE\NexusFramework\NexusFramework_V7` is the only V7 present.
That repository was reviewed instead. If a separate dated copy exists elsewhere, this
review does not cover it.

## Phase state

| Phase | Status | Note |
|---|---|---|
| 01–04 | Complete | User-accepted |
| 05, 06, 07 | Ready for Review | **No E3 run on any of the three.** Each was implemented on top of the previous one before that one met its gate |
| 08 | In Progress | 2 of 9 tasks; 0 of 6 acceptance-gate items |
| 09–20 | Not Started | — |

## Against the five goals

| # | Goal | Finding |
|---|---|---|
| 1 | `Nexus World > State > City > Highway > Highway Point > Activation Point` | `Nexus World` row absent; the other five levels are correct and render. [B-01](../backlog/B-01-world-root-row.md) |
| 2 | Highway Point syncs from Landscape, the rest are creatable | State, City, Highway creatable. Highway Point correctly withheld. **Activation Point not creatable from any surface** — the service exists and is tested, nothing calls it |
| 3 | Activation Point gizmo, grab and move | Not started; Phase 12 owns it. **No architectural risk found** — `FNexusActivationPointRecord` already carries `AnchorId` and `LocalTransform`, which is what a gizmo needs |
| 4 | Highway mesh config holding every mesh | Does not exist. No owning phase. [B-02](../backlog/B-02-highway-mesh-info-cascade.md) |
| 5 | Tangent → mesh placement, with lanes and widths | **Nothing exists.** See below |

## The three findings that matter

### 1. No Landscape code exists at all

`NexusLandscapeEditor/Private/NexusLandscapeEditorModule.cpp` is **24 lines** — an empty
module stub. `NexusGeneration` is the same. Eight phases in, nothing has read a spline.

The user's stated main goal is *"grab the landscape segment tangent info and put highway
mesh"*. It is at zero.

This is the planned order rather than a deviation — the 20-phase plan puts all UI before
any backend — so it is reported as a fact about where the product stands, not as a
process failure.

### 2. Lane count, lane width, and walkable width exist nowhere

A repository-wide search returns **zero hits** across `project-specifications/` and
`Plugins/NexusFrameworkV7/Source/` alike. `FNexusAuthoringRecord` holds `Identity`,
`Kind`, `ParentId`, `SortOrder`, `Payload`, and nothing else.

Three planned things already depend on this data:

- `phases/phase-11.md` implements **lane queries** over it;
- `phases/phase-13.md` **generates** lanes, markings, and sidewalks from it;
- the mesh cascade selects a mesh **by lane count**.

A consumer, a generator, and a selector, with no producer and no field. **This is a gap
in the design, not unbuilt work**, and it sits on the critical path to goal 5. Recorded
as [B-05](../backlog/B-05-lane-and-width-data-model.md).

### 3. Phase 08 is about to freeze contracts that have never met their input

Phase 08's last task is *"Freeze documented UI state, command, repository, selection, and
diagnostics contracts."* Phases 05–07 built the whole UI and Phase 01 froze the authoring
schema — none of it against real Landscape data, because none has ever been read.

`TASK-LIST.md`: *"A changed architectural contract reopens the owning checkpoint and
every affected downstream phase."* If Phase 09 reads a spline and the shape does not fit,
Phase 08 reopens and the UI work is redone.

This is the finding with a deadline, and the reason
[B-04](../backlog/B-04-landscape-vertical-slice.md) exists.

## What is genuinely good

Reported because a review that lists only problems misrepresents the state of the work.

- Identity, migration, transactions, and lossless payload recovery are real, tested, and
  were independently re-executed at the Phase 01 E0 review.
- The module boundary is enforced by a test that fails the build, not by convention.
- The mutation seam holds: one command service, and every surface routes through it.
- The test suite catches real defects rather than restating the code. Phase 08's first
  pass found four Blocking performance defects, one of which would have hung the editor
  on a keystroke; its second found a shell state nothing could enter. Both classes were
  invisible to every earlier suite.

The foundations are sound. The gap is that the product's central function has not been
attempted, and the schema that function will drive is about to be frozen without it.

## Recommendation

Build one thin vertical slice before the freeze: **one spline → one Highway with lane
count and width → one mesh placed on the correct path.** It is small, it is throwaway,
and it converts the largest open risk in the plan into a written list of schema
corrections while those corrections are still cheap.

Scope, governance conflict, and acceptance criteria are in
[B-04](../backlog/B-04-landscape-vertical-slice.md). The governance question — whether
that slice sits inside Phase 08, reorders the plan, or is declined in favour of accepting
the risk — is the user's, and B-04 does not choose for them.
