# Phase 01 Reference Baseline — 2026-08-22

## Fixtures

- TinyPayload: `FNexusTestPayload` with scalar, nested dynamic array, soft object
  reference, and nested `FNexusId` clone/rekey field.
- SelectionState: ordered document-bound multi-selection with primary, anchor,
  origin, and revision.
- Environment: [reference-environment-2026-08-22.md](reference-environment-2026-08-22.md).

## Results

- Cold Editor Win64 Development: 30.406 s, 67 actions, passed.
- Cold Game Win64 Development: 27.006 s, 11 actions, passed.
- Cold Game Win64 Shipping: 26.818 s, 10 actions, passed.
- Foundation suite: 21/21, 14.513 s, exit code 0.
- Foundation peak working set: 3,042,369,536 bytes / 2,901.43 MiB.
- TinyPayload serialized size: 2,659 bytes.
- SelectionState serialized size: 1,718 bytes.
- Combined serialized size: 4,377 bytes.

## Commands and retained logs

Cold builds used `Build.bat <Target> Win64 <Configuration> <uproject>
-WaitMutex -gather` after the matching `-clean` invocation.

Foundation automation used:

~~~text
UnrealEditor-Cmd.exe NexusFramework.uproject -unattended -NullRHI -NoSplash -NoSound
  -ExecCmds="Automation RunTests Nexus.V7.Foundation; Quit"
  -TestExit="Automation Test Queue Empty"
~~~

Retained logs:

- `Saved/Logs/UBT-Editor-Cold-Final-2026-08-22.log`
- `Saved/Logs/UBT-Game-Development-Cold-Final-2026-08-22.log`
- `Saved/Logs/UBT-Game-Shipping-Cold-Final-2026-08-22.log`
- `Saved/Logs/Automation-Foundation-Final-2026-08-22.log`

This baseline is the initial regression reference. Later phases must explain
material movement rather than silently replacing these values.
