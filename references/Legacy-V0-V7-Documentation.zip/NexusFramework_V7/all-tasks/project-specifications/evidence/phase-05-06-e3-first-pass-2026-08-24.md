# Phase 05 + 06 — E3 first pass, six checks — 2026-08-24

A short prioritised run for a single sitting. **This does not replace** the two full
E3 scripts — `phase-05-e3-manual-checklist-2026-08-23.md` (16 checks) and
`phase-06-e3-manual-checklist-2026-08-23.md` (14 checks). Those are still required
before either phase can be accepted.

What this page is for: the six checks that carry the most risk right now. Four of them
cover bugs reported from the editor and fixed on 23–24 August; the last two cover the
two failure modes this project has actually shipped twice — a surface that no click can
reach, and data that does not survive a restart.

**Do not mark any phase Complete from this page.** Six checks are not an E3 pass. Record
what you see and hand it back.

## Before you start

Close any running editor first — four `UnrealEditor.exe` processes were up during the
last build and they hold the plugin DLLs open.

Open `NexusFramework.uproject`, then open the Nexus workspace tab and load the sample
document you normally use. If you want the automated side re-verified first, this is
the whole of it and it takes about three minutes:

```
powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase06Details.ps1 -SkipBuilds
```

Expect `PASS: 101 tests, 0 failures` and `PHASE 06 DETAILS: PASS`. Drop `-SkipBuilds`
to include the three clean builds (about fifteen minutes).

---

## 1. Undo survives an abandoned edit — **the one that matters**

Fixed 2026-08-24. Automation cannot reach it; the text box is behind Slate. If only one
check gets run today, run this one.

**Do,** in one sequence, without restarting the editor:

1. Select a City. Click into **Name**, type anything, press `Escape`.
2. Click into **Sort Order**, change it, click away so it saves.
3. Press `Ctrl+Z`, then `Ctrl+Y`.
4. Select a *different* entity, start typing in **Name**, and — without pressing Escape
   — click straight onto another row in the tree.
5. Press `Ctrl+Z` again.

**Expect:** every `Ctrl+Z` and `Ctrl+Y` responds, at every step.

**Fail if:** undo and redo go completely dead from step 3 or step 5 onward — including
for unrelated actions anywhere else in the editor — and stay dead until you restart.
That is the exact bug that was fixed; a partial or slow undo is a different defect,
note it separately.

**Result:**

## 2. Undo refreshes the tree, not just the data

Bug 1 of the same report. The fix defers the refresh by one tick, so watch the tree
rather than the Details panel.

**Do:** rename a City so it saves and the tree row changes. Press `Ctrl+Z`.

**Expect:** the **tree row text** goes back to the old name, within a frame. Selection
stays where it was.

**Fail if:** the Details panel shows the reverted value but the tree row still shows the
new one, or you have to click another row to make the tree catch up.

**Result:**

## 3. Editing the same entity twice in a row keeps saving

Bug 3. One successful save used to lock that entity for the rest of the session.

**Do:** pick one City. Change **Sort Order**, leave the field. Change it again, leave.
Again. Four times total, same entity, without selecting anything else in between.

**Expect:** all four save. The footer reads **Saved** each time (it reads
*"Editing — saves when you finish"* while the field has focus).

**Fail if:** the first saves and any later one refuses with the banner *"The document
changed after these edits were made. Refresh to see the current values, then apply
again. Your edits are kept until you do."*

**Result:**

## 4. Escape abandons the edit, and it stays abandoned

Bug 2. The trap is the *second* half — the value used to come back on focus change.

**Do:** click into **Name**, type something different, press `Escape`. Then click onto
another row and back again.

**Expect:** the field is back to its original value, and still is when you return. The
footer never reads **Saved** and the tree row never changes. While the field has focus
a hint reads *"Esc to discard this field"*.

**Fail if:** the typed value reappears after the focus change, or the change saves
anyway when you click away.

**Result:**

## 5. Every surface is actually reachable by mouse *and* keyboard

Two earlier V7 phases shipped surfaces that no keystroke or click could reach while
every automated declaration test stayed green. This is the check that catches that
class, and it is why it is on a six-item list.

**Do:** without touching the mouse, `Tab` through the Details panel and the tree. Then
with the mouse only, exercise the tree: expand, collapse, ctrl-click a multi-selection,
shift-click a range. Try the search box and a couple of the filter chips.

**Expect:** focus is visible at every stop and never gets stuck in a loop or vanishes.
Everything that looks interactive responds. Anything not delivered yet says which phase
delivers it rather than doing nothing.

**Fail if:** a control is visible but inert, focus disappears, or `Tab` cycles a subset
of the panel forever. Note *which* control — that detail is the whole value of this
check.

**Result:**

## 6. It survives a restart

Session-only data is explicitly not acceptance evidence for these phases.

**Do:** make two or three edits of different kinds — a rename, a number, a
multi-selection edit. Save the asset. Close the editor completely. Reopen and go back
to the same entities.

**Expect:** every edit is there, with the right values on the right entities.

**Fail if:** anything reverted, landed on the wrong entity, or the asset prompts to save
again when you have changed nothing since reopening.

**Result:**

---

## After the run

Write the outcome of each check above, then hand it back. If all six pass, the next step
is the two full E3 scripts, not acceptance — Phase 07 is blocked on **Phase 06
Complete**, and Complete needs the full E3 evidence, which is your call and not the
implementing agent's.

If any check fails, the failing check number and what you saw is enough to act on; a
screenshot helps for check 5.
