# Phase 08 — E0 Independent Architecture & Contract Review — 2026-09-02

## Reviewer and independence

Reviewer: Claude (Sonnet 5) session, acting as the independent E0 reviewer.
Independence basis: this reviewer implemented none of Phase 08's code, tests, or
evidence records, including the most recent work (F-08-16, commit `bd92ac6`, and
the test-assertion correction in `fe616fa`/`2e61180`). Everything below was
re-read, re-run, or re-derived by this reviewer directly against the tree as it
stands on `master`, not copied from `phase-08.md` or `PHASE-STATUS.md`.

Scope: `project-specifications/phases/phase-08.md`, `PHASE-STATUS.md`,
`TASK-LIST.md`, `V7-ARCHITECTURE.md`, `V7-UX-SPEC.md`, `V7-QUALITY-GATES.md`, the
`NexusEditor` and `NexusEditorUI` plugin modules, `NexusTests`, and
`Scripts/VerifyPhase08UiGate.ps1`.

## Verdict

**Not accepted. Phase 08 remains In Progress**, which is consistent with its own
ledger (seven of nine task lines unchecked or partial, E0 and E3 not run, F-08-06
and F-08-15 still awaiting the user's reading). This review does not move Phase 08
to Ready for Manual QA — it cannot yet, independent of this review's own findings,
because the implementing agent's own required task list and E3 are still
outstanding.

Beyond confirming the project's own open items, this review found **one new
Blocking defect** that no prior pass recorded: **Undo and Redo silently discard
every unsaved Details edit in the document**, including parked "kept" drafts that
have nothing to do with the transaction being undone — the same class of bug
F-08-16 just fixed in `Revert()`, still present and untested in a far more
frequently used path. One Warning-level gap in the F-08-16 fix itself (the
Activity-summary correction only reaches destructive commands), one Warning-level
stale/misleading-badge defect on the Home tab, and a few Information items are
also recorded below.

F-08-06 and F-08-15 were independently checked against the source, not just read
from the ledger, and both hold up exactly as described.

## Independently re-executed verification

| Check | Command / method | Result |
|---|---|---|
| Working tree state | `git status`, `git diff --stat`, `git log --oneline -10` | Clean tree; `HEAD` is `2e61180` ("Fix \"Revert Draft\" to only discard selected draft"), one commit ahead of the `fe616fa` this review's brief named as most recent — see "Note on task-brief drift" below. No production source differs from the state the last recorded clean-build pass ran against. |
| E2 automation (builds **not** re-run by this reviewer) | `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1 -SkipBuilds -RunLabel "e0-review-2026-09-02"` | `PASS: 156 tests, 0 failures`; `PASS: 21 budget measurements, 0 over`; `PHASE 08 E2: PASS (builds skipped; E1 not evaluated)`. Reproduces the counts in `evidence/phase-08-f08-16-revert-scope-2026-09-02.md` exactly (same 156/21). |
| Budget artifact | `sha256sum Saved/NexusV7/Phase08/ui-budgets-e0-review-2026-09-02.txt` | 1,011 bytes; SHA-256 `7fab2087d28bfd824e5f0d8e6315b806ce74790d39fcd948107bf1e927c90679` — independently hashed by this reviewer, not taken from the script's own printed digest. |
| Working tree after the run | `git status --porcelain` | Empty. The automation run leaves no tracked-file residue (no stray `Content/` assets this time). |
| F-08-15 claim ("zero occurrences of `Activation` in the catalog") | `grep -c Activation NexusCommandCatalog.cpp`; also swept `NexusEditor` and `NexusEditorUI` for `TODO\|FIXME\|placeholder\|stub\|mock\|HACK\|NotImplemented` | Confirmed: 0 occurrences of `Activation` in the catalog; 0 hits for the placeholder-language sweep in either module. |
| F-08-06 claim ("no representation anywhere in the build") | `grep -ri "ownership.mismatch"` across `Plugins/NexusFrameworkV7/Source` | Confirmed: the only hit is a comment in `NexusUiStateTests.cpp` quoting the phase-08 task line itself. No enum member, diagnostic code, or shell state exists for it. |
| Shell state enum completeness | Read `NexusShellTypes.h` | Confirmed 9 states (`Loading, Empty, Ready, Dirty, Warning, Blocked, Stale, Working, Failure`) and `StateCount = 9`; none represents ownership-mismatch, consistent with F-08-06. |
| F-08-16 fix itself | Read `NexusDetailsView.cpp::Revert()`, `NexusCommandService.cpp::Execute()`, `NexusOperationHistory.cpp::Complete()` | Confirmed as described: `Revert()` no longer touches `KeptDrafts`; `Execute()` reuses the `CheckConfirmation`-verified preview to populate `Message`/`TargetSummary` for a successful **destructive** command. Correctly implemented for what it claims to cover (see Warning finding below on its scope). |
| New finding: Undo/Redo vs. `KeptDrafts` | Read `NexusEditorSubsystem.cpp` (`PostUndo`, `RefreshAfterUndo`) and `NexusDetailsView.cpp` (`ReloadFromSource`) | Confirmed: every successful Undo/Redo calls `ReloadFromSource()` unconditionally, which resets `KeptDrafts` and rebuilds `Targets` regardless of whether the undone transaction touched the selected or parked entities. No test in `NexusTests` exercises this interaction (`grep RefreshAfterUndo\|PostUndo\|PostRedo` over `NexusTests` returns one unrelated comment only). |

**Not independently reproduced by this reviewer**: the three clean builds (Editor
Development, Game Development, Game Shipping). Per the task brief, those were run
moments before this review began, in this same tree, with no production-source
changes since (confirmed by `git status`/`git diff` above showing only
documentation and this new evidence file as differences). This review therefore
rests its automation confidence on the `-SkipBuilds` re-run above, exactly as
`evidence/phase-08-clean-gate-and-f08-14-2026-09-01.md`'s "Independent read of the
F-08-14 fix" section and the Phase 01 E0 review both did for scoped/non-build
verification — stated here explicitly rather than implied.

### Note on task-brief drift

This review's brief stated that the F-08-16 write-up
(`evidence/phase-08-f08-16-revert-scope-2026-09-02.md`), the `phase-08.md` and
`PHASE-STATUS.md` edits, and two `agent-memory/` notes were uncommitted
working-tree changes at hand-off. By the time this review began, `git log` showed
them already committed as `2e61180` ("Fix \"Revert Draft\" to only discard
selected draft"), on top of `fe616fa`. The working tree is fully clean; nothing
was lost or needs reconciling. This is recorded only because the brief
specifically asked this review to verify that claim rather than repeat it, per
this project's own `[[verify-claims-by-re-running]]` convention.

## Findings

Severities follow the same convention the Phase 01 E0 review used, keyed to
`V7-ARCHITECTURE.md` §9's Blocking/Warning/Information definitions.

### E0-01 — Blocking — Undo and Redo silently discard every unsaved Details edit, including parked work the operation never touched

`UNexusEditorSubsystem::PostUndo` (`NexusEditorSubsystem.cpp`) schedules
`RefreshAfterUndo` on the next tick for every successful undo or redo (`PostRedo`
forwards to `PostUndo`). `RefreshAfterUndo` unconditionally calls
`FNexusDetailsView::Get().ReloadFromSource()`. `ReloadFromSource()`
(`NexusDetailsView.cpp:1312`) does two things with no scoping to what the
undone/redone transaction actually changed:

```cpp
void FNexusDetailsView::ReloadFromSource()
{
    KeptDrafts.Reset();
    if (IsSelectionDeferred())
    {
        Targets.Reset();
        ...
    }
    else
    {
        RebuildTargets();   // rebuilds fresh baseline+draft for the CURRENT selection
    }
    ChangedEvent.Broadcast();
}
```

`KeptDrafts.Reset()` clears every parked, unapplied draft in the document —
exactly the container F-08-16 just fixed `Revert()` to leave alone, for exactly
the reason recorded in the new `agent-memory` note that shipped with that fix:
*"a document must not lose unrelated work on a scoped command."* `RebuildTargets()`
separately re-loads the currently selected target(s) from the document, discarding
any unapplied edit sitting on the current selection as well, even when the
undone/redone transaction has nothing to do with the current selection.

**Concretely:** a user can be mid-edit on City B (an interactive/unapplied draft,
which the "Not saved — &lt;reason&gt;" footer and the visible parked-draft count
exist specifically to represent per `V7-ARCHITECTURE.md` §"Details drafts and Keep
Draft"), have City A's earlier edit legitimately parked in `KeptDrafts` from
navigating away, and then press **Ctrl+Z** to undo something completely unrelated
— a Create, a Rename, a Delete on a different entity entirely. Both City A's and
City B's unsaved work vanish with no preview, no confirmation, no Activity entry,
and no warning of any kind, because Undo does not go through
`FNexusCommandService::CheckConfirmation`/`BuildPreview` at all — it is the
engine's native transaction system, so the destructive-preview gate this project
built specifically to make "the preview describes what will happen" a guarantee
never sees it. The visible parked-draft count (`SNexusDetailsPanel.cpp:429,554,568`
reads `GetKeptDraftCount()`) will simply drop to zero.

This directly contradicts `V7-UX-SPEC.md` §22's Authoring acceptance line —
**"Undo/redo restores exact authored state and a valid selection"** — one of the
named Phase 8 freeze acceptance criteria. It is also the identical defect *shape*
to F-08-16 (a scoped, single-entity operation clearing state belonging to
unrelated entities as a side effect), just in a code path the F-08-16 fix did not
audit: that fix's own retrospective note recommends grepping "a handler for
resets/clears on shared containers... when reviewing anything gated by
`CheckConfirmation`" — `RefreshAfterUndo`/`ReloadFromSource` is not gated by
`CheckConfirmation` (it is a native-undo callback, not a catalog command), so it
fell outside that check's stated scope even though it touches the exact same
`KeptDrafts` container.

No test anywhere in `NexusTests` exercises this: `Nexus.V7.Details.LiveEdit`'s
undo test (`NexusDetailsTests.cpp` ~line 1500) calls
`Fixture.Repository.RebuildIndex()` directly rather than going through
`UNexusEditorSubsystem::RefreshAfterUndo`/`ReloadFromSource`, and sets up no
`KeptDrafts` scenario at all, so it cannot see this.

**Consequence if unaddressed:** this is a live, silent data-loss path in the
single most common editor action (undo), reachable today with a document, two
entities, and one Ctrl+Z — not a hypothetical or a corner case gated behind a
future phase.

### E0-02 — Warning — F-08-16's Activity-summary fix reaches only destructive commands; every other successful command still shows bare "Completed"

`FNexusCommandService::Execute` (`NexusCommandService.cpp:445`) only populates
`Message`/`TargetSummary` from `ConfirmedPreview.Summary` when
`CheckConfirmation` actually built and returned a confirmed preview — which only
happens for a command the catalog marks destructive
(`CheckConfirmation` returns `true` immediately, without touching
`OutConfirmedPreview`, for any non-destructive command). `FNexusCommandResult`
(`NexusResult.h`) carries no message field of its own on success — only
`Diagnostics`, which is empty for an ordinary successful command. So for every
non-destructive successful command — **Apply** (`ExecuteApply`,
`NexusDetailsCommands.cpp:214`, the single most frequently invoked mutation in the
product given Phase 06's auto-commit-on-finished-edit design), Create, Rename,
Reparent, Duplicate, Save Document, New/Open/Close Document
(`ExecuteCloseDocument`, `NexusAuthoringCommands.cpp:1184`, confirmed returning a
bare `Success()`), Undo, Redo — `Message` stays empty and
`FNexusOperationHistory::Complete` falls back to
`GetStatusDisplayName(Succeeded)`, i.e. the literal word **"Completed"**, with an
empty `TargetSummary`.

This is the exact defect F-08-16's own commit message describes ("a successful
[...] command left the Activity log with just the word 'Completed' instead of a
real summary") but the fix, as implemented, narrows the claim to destructive
commands specifically without saying so in `phase-08.md`'s or
`PHASE-STATUS.md`'s prose, both of which read as if the general problem is now
closed ("Both are fixed"). A user applying a property edit, creating an entity, or
saving a document still gets an Activity row that says nothing more than
"Completed" — which is the everyday case, not the destructive-command corner case
this fix actually reaches.

### E0-03 — Warning — Home tab onboarding badges are hardcoded to "Empty" and its text still describes delivered Phase 05/06 work as future

`SNexusHomeView::HandleStateChanged` (`SNexusHomeView.cpp:500-550`) builds four
onboarding steps. Step 2's badge is computed (`ContentStep`), but **Steps 3 and 4
are hardcoded to `ENexusShellState::Empty`** regardless of the real document or
editor state:

```cpp
const FStep Steps[] = {
    { Step1Title, Step1Body, DocumentStep },
    { Step2Title, Step2Body, ContentStep },
    { Step3Title, Step3Body, ENexusShellState::Empty },   // always Empty
    { Step4Title, Step4Body, ENexusShellState::Empty }    // always Empty
};
```

Step 2's body text also still reads *"The world tree, filters, and multi-select
arrive with Phase 05"* and Step 3's reads *"Property editing, mixed values, and
inline validation arrive with Phase 06"* — future tense, naming phases that have
in fact already shipped this exact functionality (Phases 05-07 are Ready for
Review with real, tested hierarchy/details/CRUD implementations, and Phase 08
itself has been measuring and hardening that same work for the past several
days). Home is a live, reachable surface — `phases/phase-08.md`'s own "How to
Test" script explicitly opens it ("Open Home: the strip says...") — so this is not
dead code.

This is a concrete, previously-unrecorded instance of exactly what the still-open
Phase 08 task *"Remove or complete every placeholder, mock-only dependency, dead
action, misleading badge, and false-success path"* names: a badge that always
reads Empty no matter what is true, next to text promising work as a future
phase delivery when that phase has already delivered it. No test in `NexusTests`
covers this widget's onboarding content (`grep` for `Onboarding`, `Step1`…`Step4`,
or `"arrive with Phase"` in `NexusTests` returns nothing), so nothing would catch
a regression or catch this going stale further. This does not newly block
anything the ledger has not already flagged as open (that acceptance-gate task
line is honestly still unchecked), but it is worth naming so the specific example
is not lost when that task is finally closed out.

### E0-04 — Information — three responsiveness budgets are analogized extensions of section 19/12, not literal lines, disclosed honestly in code

Checking every `Record(...)` call in `NexusUiGateTests.cpp` against
`V7-UX-SPEC.md` §19 and `V7-ARCHITECTURE.md` §12 line-by-line: 18 of the 21
budgets map onto an explicit named line (filter/sort-adjacent 150 ms, incremental
refresh 50 ms, palette cold/warm open, single/multi-selection Details bounds,
shell cold/warm open, search 250 ms). Three do not have a literal source line:

- `Sort.100kRows.worstMs` (budget 150 ms) — the test's own comment says so:
  *"No section 19 line names sort, so it is held to the same ceiling as the
  filter it shares a code path and a keystroke with."*
- `Selection.selectAllVisible.ms` / `Selection.invertVisible*.ms` (budget 100 ms
  each) — reasonably read from §19's generic *"Visible response to input: 100 ms
  maximum,"* but not a bullet that names selection by name.
- `Palette.warmKeystroke.p95Ms` (budget 100 ms) — same generic bucket; §19 only
  names palette *open* (warm 100 ms / cold 250 ms) explicitly, not a keystroke
  inside an already-open palette.

None of this is a hidden problem — the sort case is disclosed in the test source
itself, and all three apply the *stricter* interpretation (measuring at the
100,000-row reference scale against a ceiling the spec wrote for a 10,000-row
filter, in the sort case) rather than a looser one. Recorded because the task
brief specifically asked this review to check the budget-to-spec mapping, and two
of the three mappings are not self-evident from the locked documents alone.

### On F-08-06 and F-08-15

Both were checked against the source directly rather than accepted from the
ledger, and both hold up exactly as `phase-08.md` and `PHASE-STATUS.md` describe:

- **F-08-06.** `ENexusShellState` has exactly 9 members and none represents
  ownership-mismatch; a repository-wide search finds no diagnostic code, target
  state, or detector for it anywhere in `Plugins/NexusFrameworkV7/Source`. The
  characterization "no representation in the build at all" is accurate, not an
  overstatement.
- **F-08-15.** `NexusCommandCatalog.cpp` has zero occurrences of `Activation`,
  confirmed by direct search — a stronger absence than the sixteen deliberately
  pending-phase commands F-08-05 covers, since this entity kind is not even
  registered as a future command. `FNexusActivationPointCommandService` and
  `Nexus.V7.Foundation.ActivationPointCrudTransactions` exist and are exercised
  by tests, confirmed by direct file inspection, corroborating the claim that the
  service-level proof is real even though no UI gesture reaches it.

This review found nothing further to add on either beyond what is already
tracked — no third state or command surfaces either one, and no evidence
contradicts the "cannot be tested until Phase 10/14" framing for either.

## Accepted without qualification

- **The destructive-confirmation gate** (`FNexusCommandService::CheckConfirmation`,
  `CanInitiate`, `BuildPreview`): identity, preview-token, and document-revision
  checks are all present and correctly ordered; a stale or mismatched approval is
  refused before a handler runs. `SupportsPreview` as a cheap capability check
  kept out of the Slate paint path (F-08-13's fix) is a sound design and this
  review found no path that bypasses it for a real destructive command's
  execution.
- **The `Revert()` fix itself** (F-08-16), read directly in
  `NexusDetailsView.cpp:1234-1263`: it now touches only the currently bound
  `Targets` and leaves `KeptDrafts` alone, matching its own code comment and the
  evidence record exactly. Correctly scoped for what it covers.
- **The bounded-Details-selection mechanism** (F-08-04's fix): `SelectionDeferred`
  correctly refuses editing, Apply, Revert, and revert preview above 1,000
  materialized targets, and this review's own reproduction of the gate suite
  confirms the 21/21 budget pass including `Details.selectAllVisible.ms=4.167`
  against its 300 ms ceiling.
- **156/156 automated tests and 21/21 budget measurements**, independently
  reproduced by this reviewer via `-SkipBuilds` against the same tree the last
  recorded full clean triple-build ran against, with a working tree left clean
  afterward.
- **F-08-06 and F-08-15's characterizations**, independently confirmed against
  source as described above.
- **The command palette's generic reachability of catalog-only commands** (e.g.
  `Nexus.View.CollapseAll`/`ExpandAll`, which have no toolbar, Window-submenu, or
  row-context-menu entry): confirmed by reading `SNexusCommandPalette::BuildEntries`,
  which iterates `NexusCommandCatalog::GetAll()` directly. This is a deliberate,
  documented design choice (`NexusMenus.cpp`'s own comment: *"everything else is
  one Ctrl+Shift+P away"*), not an unreachable-surface defect of the kind
  `agent-memory/declared-is-not-reachable.md` warns about.

## What this review recommends before Phase 08 can advance

This review has no authority to change status and does not attempt to. For the
record, in addition to the seven still-unchecked task lines and the outstanding
E3 run the project's own ledger already names:

1. **E0-01 needs a fix and a regression test** before this class of silent data
   loss can be considered closed — the same rigor F-08-16 applied to `Revert()`
   needs to reach `RefreshAfterUndo`/`ReloadFromSource`.
2. E0-02 and E0-03 should at minimum be recorded against the open "Remove or
   complete every placeholder... misleading badge... false-success path" task
   line so they are not lost, whether or not the user decides they are worth
   fixing before the freeze.

## Authority note

This review satisfies the E0 inspection requirement only. It does not constitute
Ready for Manual QA, does not substitute for E3 manual QA, and does not mark
Phase 08 Complete or change any Status field. Per `V7-QUALITY-GATES.md` §1, only
the user may move a phase to Complete, and only an independent review may move
accepted work to Ready for Manual QA — this review does not find Phase 08's
current state acceptable enough to do so, both because of its own outstanding
task list and because of the new Blocking finding above.
