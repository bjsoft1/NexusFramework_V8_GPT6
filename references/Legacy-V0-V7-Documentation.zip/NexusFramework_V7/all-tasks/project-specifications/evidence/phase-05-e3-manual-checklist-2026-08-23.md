# Phase 05 E3 — Manual Test Script — 2026-08-23

## What this closes

E1 (clean builds) and E2 (automation) are recorded in
[Phase 05 hierarchy](phase-05-hierarchy-2026-08-23.md). Two acceptance-gate items
can only be closed by a person at the editor:

- *"Representative large-tree interaction meets the Phase 01 responsiveness budget"* —
  automation asserts the tree does not collapse into linear work, but whether a
  100,000-row tree **feels** responsive is a judgement only a person makes.
- *"A one-item change does not require a visible full-tree rebuild"* — the counters
  prove no rebuild happened; whether the *view* flickered, jumped, or lost its
  scroll position is visible only on screen.

The other three gate items are held at E2 and are re-checked here by eye.

## Before you start

**Close every running editor before building.** Four `UnrealEditor.exe` processes
holding the plugin DLLs open is what a locked-file link error looks like.

Everything below starts from the console (`` ` `` or `Tilde`), because nothing in the
editor binds an authoring document yet — Phase 07 owns that entry point per Phase 01
finding F-09. The fixtures are developer tooling and deliberately have **no menu
entry**: one would either claim Phase 07's entry point or leave a dead item that
fails the Phase 08 freeze gate.

```
Nexus.Fixture.LoadSample Normal        loads a small healthy tree
Nexus.Fixture.LoadSample Deep          one 64-level chain
Nexus.Fixture.LoadSample Wide          one parent, 500 children
Nexus.Fixture.LoadSample Invalid       duplicate names, a missing parent, a cycle
Nexus.Fixture.LoadSample Large         100,000 rows
Nexus.Fixture.LoadSample Normal 42     the same shape from a different seed
Nexus.Fixture.Clear                    unbinds, returning the shell to Empty
```

Identity is hashed from the shape and the seed, so a defect found here is
reproducible from those two words alone. Record them with any failure.

## Read this first: three behaviours that are correct, not defects

1. **The Details and Activity tabs are unchanged.** Phase 06 delivers Details;
   Phase 05 only fills the Hierarchy tab's *World tree* and *Filters* sections.
2. **Rows cannot be renamed, created, or deleted.** Those commands are owned by
   Phase 07 and refuse **by name**. A refusal naming its phase is a pass.
3. **A fixture is not a document you can save.** It is transient and unbound; the
   shell's own state reflects that. Nothing you do here writes to disk except
   favorites, which are a per-user preference.

---

## The checks

### 1. A fixture loads and the tree fills

**Do:** open `Window > Nexus Framework V7 > Open Hierarchy`. Note what the World tree
section says with nothing loaded. Then run `Nexus.Fixture.LoadSample Normal`.

**Expect:** before loading, a sentence naming **Phase 07** as the phase that will open
a real document — not "error", not an empty panel. After loading, roots appear and the
row count beside the search box reads **92 rows**.

**Fail if:** the empty state is blank or reads as a failure, the tree stays empty after
loading, or the count disagrees with what is drawn.

**Result:** PASS on what this item asserts, with **F-E3-04** raised alongside it. The
empty state named Phase 07, the fixture loaded, and States, Cities and Highways drew.
The Details surface then reported **Blocked — 1 blocking finding**, which this item does
not cover and note 3 above does not license. Recorded under Findings below.

### 2. Rows are readable, and the badges say what they mean

**Do:** expand a State, then a City, then a Highway. Hover a row's name, its type, and
any badge glyph.

**Expect:** indentation makes the level obvious; the expander arrow is on rows with
children and absent on leaves; the kind is shown on the right; the name tooltip is the
full slash-separated path. Every badge glyph has a tooltip that is a sentence, not a
repeat of the glyph.

**Fail if:** indentation is ambiguous, an expander appears on a leaf, a tooltip is
empty, or two different badges draw the same glyph.

**Result:**

### 3. Clicking a row selects that row

**Do:** click a row. Then ctrl-click two more. Then click one row and shift-click a row
four below it.

**Expect:** a plain click replaces the selection; ctrl adds and removes; shift takes the
inclusive range **as drawn on screen**. The breadcrumb under the tree follows the
primary selection.

**Fail if:** clicking the row's empty space to the right of its name does nothing, a
range includes rows that are not visible, or the breadcrumb shows a different row.

**Result:**

### 4. The tree is usable without a mouse

**Do:** click once into the tree, then use only the keyboard: `Down`, `Up`, `Home`,
`End`, `Right` on a collapsed parent, `Right` again, `Left` twice, and `Shift+Down`.

**Expect:** the primary moves one row per press; `Right` opens a closed parent and then
steps into its first child; `Left` closes an open parent and then steps to its owner;
`Shift+Down` extends the range.

**Fail if:** any key does nothing, focus escapes the tree, or `Left` on a root throws
the selection somewhere unrelated.

**Result:**

### 5. Right-clicking a row raises the context menu for **that** row

**Do:** select one row with a left click. Then right-click a **different** row.

**Expect:** the right-clicked row becomes the selection *before* the menu opens, and
the menu describes that row. Entries owned by later phases are present and disabled,
each naming its phase in the tooltip.

**Fail if:** the menu acts on the previously selected row, no menu appears, or a
disabled entry gives no reason.

**Result:**

### 6. Search and filter

**Do:** in the search box type, in turn: `City`, `type:City`, `type:City type:State`,
`type:City path:"State 01"`, `is:leaf`, `status:warning`, and finally `zzzz`.

**Expect:** results narrow as terms are added across categories and widen with a second
term in the same category. Each term appears as a removable chip. `zzzz` produces the
no-results state with a sentence telling you how to get back.

**Fail if:** typing feels laggy, a chip does not remove its own term, adding a second
`type:` narrows instead of widening, or the no-results state is a blank panel.

**Result:**

### 7. A filtered result is never shown detached from where it lives

**Do:** with `Nexus.Fixture.LoadSample Normal` loaded, collapse everything, then search
for `Point 01-01-01-01`.

**Expect:** the matching row is visible, and so are its owners — dimmed, so they read as
context rather than as results. Clearing the search returns the tree to the **collapsed**
state you left it in, not splayed open where the filter went.

**Fail if:** the match appears as a lone root, the ancestors look like results, or
clearing the search leaves the tree opened up.

**Result:**

### 8. Expansion commands

**Do:** run Expand All, then Collapse All, then select two rows and run Expand Selection
and Collapse Selection.

**Expect:** each does what its label says. Run Collapse All twice: the second time the
command is disabled with a reason rather than doing nothing.

**Fail if:** a command silently no-ops, or Expand All opens rows the filter is hiding.

**Result:**

### 9. Favorites

**Do:** select a row and press `Ctrl+Space`. Confirm the badge appears. Run
`Manage Favorites`. Then run `Nexus.Fixture.LoadSample Deep` and open the Filters
section.

**Expect:** the favorite badge appears on the row. Manage Favorites filters the tree to
`is:favorite`. After loading a different fixture the favorite is **still listed**, marked
*not in this document* — it is not silently discarded.

**Fail if:** the favorites list empties when the document changes, the badge does not
appear, or Add Favorite on an already-favorited row does nothing without saying why.

**Result:**

### 10. Selection history

**Do:** click four different rows in turn. Press `Alt+Left` twice, then `Alt+Right`
once. Then click a new row and press `Alt+Right` again.

**Expect:** back and forward walk the selections you made. After making a new selection,
forward is disabled with a reason — the forward branch was discarded, which is what
every back/forward affordance does.

**Fail if:** back restores a row that no longer exists, or the chords do nothing.

**Result:**

### 11. Search commands from the keyboard

**Do:** with focus in the tree, press `Ctrl+F`. Type `type:City`. Run Save Search, then
Clear Search, then look at the Filters section.

**Expect:** `Ctrl+F` moves the caret into the search box. Save Search keeps the query and
it is listed under SAVED SEARCHES. Clear Search empties the box and restores the tree.
Running Save Search twice on the same query is refused with a reason.

**Fail if:** `Ctrl+F` does nothing, or fires from outside a Nexus tab.

**Result:**

### 12. A one-item change does not visibly rebuild the tree — **gate item**

**Do:** load `Normal`, expand several branches, scroll down, and select a row. Then run
Refresh from the toolbar.

**Expect:** expansion, selection, and scroll position are exactly where you left them.
Nothing flashes, collapses, or jumps to the top.

**Fail if:** the tree visibly redraws from the top, the scroll jumps, or expansion is
lost. Automation proves no rebuild ran; this item is about whether the *view* held
still, which only you can see.

**Result:**

### 13. Reference scale — **gate item**

**Do:** run `Nexus.Fixture.LoadSample Large` (100,000 rows). Expand a branch. Scroll
with the wheel and by dragging the scrollbar from top to bottom. Type `type:Highway`
into the search box, then clear it.

**Expect:** scrolling stays smooth; the row count reads **100000 rows**; the filter
settles quickly enough that typing does not feel blocked. V7-ARCHITECTURE.md section 12
sets 150 ms for a filter over 10,000 loaded rows and 250 ms for first results over
100,000 entities — you are judging whether it feels within that, not timing it.

**Fail if:** the editor stalls, scrolling stutters badly, or the search box stops
accepting input while it filters.

**Result:**

### 14. Broken data is shown, not hidden

**Do:** run `Nexus.Fixture.LoadSample Invalid`.

**Expect:** every one of these appears, badged and explained by tooltip — a row whose
parent is missing, two rows in a parent cycle, an activation point with no anchor, and
two pairs of same-named siblings warned about. Nothing hangs, and expanding a cycle
member does not recurse.

**Fail if:** any of those rows is missing, the editor hangs, or a cycle can be expanded
forever.

**Result:**

### 15. Carried from Phase 04: the focus-recursion crash has not returned

**Do:** switch between the three Nexus tabs repeatedly. Click Refresh from each surface.
Click a Nexus tab header and immediately press `Ctrl+Shift+P`.

**Expect:** no crash. F-E3-03 was a stack overflow on exactly this path and still has
**no automated guard** — the recursion needs a real dock tab in a real window, which the
headless environment does not have. This is the only place it is checked.

**Fail if:** the editor crashes or freezes.

**Result:**

### 16. A clean exit

**Do:** run `Nexus.Fixture.Clear`, then close the editor normally.

**Expect:** the tree returns to the Phase 07 empty state. The editor exits with no error
or warning dialog, and no crash reporter.

**Fail if:** anything is logged as an error on shutdown.

**Result:**

---

## Findings raised during this run

### F-E3-04 — a healthy fixture puts the shell in Blocked — **fixed 2026-08-23**

**Severity:** Blocking for the E3 record, not for the hierarchy. The tree itself is
correct; what is wrong is the state the rest of the shell derives from the fixture.

**Seen:** `Nexus.Fixture.LoadSample Normal`, then any row selected. The Details surface
shows a red **Blocked** badge, the headline *1 blocking finding*, the explanation *"The
next stage cannot run safely until these are resolved. The affected entities stay
editable."*, and a *Review in Activity* action.

**Cause.** `FNexusEditorShellStateProvider::GetSignals` raises `BlockingCount` for
exactly two conditions — `IsFutureSchema()` and `!CanSaveLosslessly()`. The fixture sets
`SchemaVersion = NexusSchema::Authoring`, so it is the second; and because
`CanSaveLosslessly` returns on its first failure, one finding means exactly one tripped
check.

`FNexusSyntheticHierarchy` builds the document with

```cpp
Document->ExpectedWorldPackage = TEXT("/Nexus/Synthetic");
```

and there is no `/Nexus/` mount point: the plugin is `NexusFrameworkV7`, so its content
root would be `/NexusFrameworkV7/`, and it declares no `Content` directory at all.
`FPackageName::IsValidLongPackageName` therefore fails and
`UNexusWorldDefinition::CanSaveLosslessly` rejects with *"expected world package is not a
valid long package name"*. Every other fixture in the tree uses a mounted root —
`/Game/NexusV7Tests/SyntheticWorld` in both `NexusCommandTests.cpp` and
`NexusPersistenceTests.cpp`.

**Why note 3 does not cover this.** Note 3 says a fixture is not a document you can save
and that the shell's state reflects that. This block is not fixture-ness. Point
`ExpectedWorldPackage` at a mounted root and the same document becomes lossless-saveable
and the shell reads Ready, while remaining exactly as transient and unbound. The shape
`Normal` is specified as *a small healthy tree*, and a healthy tree reporting that the
next stage cannot run safely is a false alarm.

**Why no test caught it.** The Phase 05 suite does build this fixture — `FFixture` in
`NexusHierarchyTests.cpp` — but asserts only snapshot and tree behaviour. Nothing asks
the shell what state a bound fixture produces. This is the same shape as the Phase 03 and
Phase 04 first-look defects: the automation asserted what it was pointed at.

**Fixed during Phase 06, 2026-08-23.** `FNexusSyntheticHierarchy` now stamps
`/Game/NexusV7Tests/SyntheticWorld`, the mounted root every other fixture in the tree
already used. `Nexus.V7.Details.HealthyFixtureIsNotBlocked` is the guard: it asserts
the Normal, Deep, and Wide shapes each save losslessly, and asserts in reverse that the
Invalid shape still does not, so the hierarchy suite's broken-data coverage cannot
quietly become valid data. Recorded in
[Phase 06 details](phase-06-details-2026-08-23.md).

**The rest of this checklist is still unrun.** Items 2 through 16 were never reached.
Fixing F-E3-04 closes one finding; it does not close E3.

---

## After the run

Report each item as PASS or FAIL with what you saw. Failures are recorded and fixed
before the phase moves; passes are written into `phase-05-hierarchy-2026-08-23.md` as
the E3 record.

Per `V7-QUALITY-GATES.md` section 1, only you can then mark Phase 05 **Complete** in
`PHASE-STATUS.md`. If you accept the phase without working through these sixteen items
one by one, say so — the record will say it rests on a session acceptance rather than
on an itemised pass, the way Phase 04's does.
