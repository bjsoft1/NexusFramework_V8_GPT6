# Phase 08 — bounded Details selection (2026-08-31)

Implementing-agent evidence for the F-08-04 correction. This is not an acceptance
record. Phase 08 remains In Progress: its dependency is unmet, E0 and E3 have not
run, clean target builds have not run, and F-08-06 still needs a user decision.

## Contract

The reachable Ctrl+A path can hand 100,000 selected items to Details. Creating a
baseline and draft proxy for each of them was eager, expensive, and unsafe because
Apply operates only on materialized targets. The contract is now:

- At 1,000 selected entities or fewer, Details retains the normal full
  baseline/draft, multi-edit behavior.
- Above 1,000, SelectionDeferred preserves the full ordered selection but renders an
  explicit summary-only state. Native property bindings are empty; inspection,
  editing, Apply, Revert, and revert preview require narrowing first.
- No first-N or representative proxy set is permitted. It would make the user see
  one selection but let Apply mutate only a hidden subset.
- A pre-existing dirty proxy from a still-selected entity may remain dormant solely
  for recovery. Narrowing back to it rebuilds and revision-checks the draft.
- A dirty target outside the active binding keeps its baseline with its draft, so
  recovery serializes its actual field delta. A recovery record over the limit
  restores into parked storage rather than an editable proxy prefix.

The actual UNexusEditorSubsystem handoff also now deduplicates through an
order-preserving set. This removes a separate O(n-squared) path that direct
Details-only tests did not exercise.

## Commands and results

Non-gating Development Editor compile:

    C:\Program Files\Epic Games\UE_5.8\Engine\Build\BatchFiles\Build.bat NexusFrameworkEditor Win64 Development -Project=E:\Projects\Game\UE\NexusFramework\NexusFramework_V7\NexusFramework.uproject -WaitMutex -NoHotReloadFromIDE

Result: succeeded, 17 actions. This was not a clean build and is not E1 evidence.

E2 automated regression:

    powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1 -SkipBuilds -RunLabel 2026-08-31-f08-04-r5

Result: 148 tests passed, 0 failures; 21 budget measurements, 0 overages. Suite
counts: Foundation 21, Module 12, Shell 19, Command 17, Hierarchy 15, Details 26,
Crud 20, UiGate 10, UiStates 4, ColdRestart 3, and RuntimeCook 1.

Key measurements on this test station:

- Details Select All, 100,000 summary: 3.578 ms, ceiling 300 ms.
- Details, 1,000 interactive targets: 4.327 ms, ceiling 300 ms.
- Hierarchy to subsystem to Details, 100,000 selected keys: 7.726 ms, ceiling 100 ms.
- Select All Visible: 5.366 ms, ceiling 100 ms.

The resulting budget artifact is
Saved/NexusV7/Phase08/ui-budgets-2026-08-31-f08-04-r5.txt, 1,011 bytes, SHA-256
bce7ad867dfebf570755dad3c6d3912f0111dd28af376bdf85f3da26c9f23d8f.

## What remains

The gate script now reports this `-SkipBuilds` invocation accurately as `Phase 08 E2:
PASS`; E1 was not evaluated. The non-clean Development Editor compile and this suite
do not replace the phase's required clean target set. Manual QA must confirm the
large-selection summary in the editor, including its explicit message and absence of
partial property editing.
