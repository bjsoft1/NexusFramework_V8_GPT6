# Phase 08 — UI Completion Gate: presentation-state pass (2026-08-28)

Implementing-agent evidence for the second Phase 08 pass. E1 and E2 only. It is
**not** an acceptance record: Phase 08 additionally requires E0 independent review
and E3 user manual acceptance, and neither has been performed.

The dependency line — Phases 03 through 07 Complete — is still not satisfied. Phases
05, 06, and 07 remain Ready for Review with no E3 run. Work continued on the user's
instruction, as recorded in
[the first pass](phase-08-ui-gate-2026-08-28.md).

This pass covers one task: *"Test empty, loading, dirty, invalid, blocked,
unknown-payload, stale, save-failure, and ownership-mismatch states."*

## Commands

```text
Build.bat NexusFrameworkEditor Win64 Development -Project=<repo>\NexusFramework.uproject -WaitMutex -NoHotReloadFromIDE
powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1 -SkipBuilds
```

## E1 — build

`Result: Succeeded` on `NexusFrameworkEditor Win64 Development`, **with no warnings**.
The build before this pass emitted one (C5038); see F-08-12. The three clean builds
(`-clean` on editor, Game Development, and Game Shipping) were not run; `-SkipBuilds`
was used, as in the first pass. They are required before this phase is proposed for
review.

## E2 — automated

143 of 144 tests pass. The single failure is `Nexus.V7.UiGate.SelectAllAtScale`,
which is F-08-04 from the first pass: open by design, because closing it changes a
contract Phase 06 owns.

| Suite | Results |
|---|---:|
| `Nexus.V7.Foundation` | 21 |
| `Nexus.V7.Module` | 12 |
| `Nexus.V7.Shell` | 19 |
| `Nexus.V7.Command` | 17 |
| `Nexus.V7.Hierarchy` | 15 |
| `Nexus.V7.Details` | 23 |
| `Nexus.V7.Crud` | 20 |
| `Nexus.V7.UiGate` | 9 |
| `Nexus.V7.UiStates` | 4 (new) |

Budget artifact for this run: `Saved/NexusV7/Phase08/ui-budgets-2026-08-28-083606.txt`,
995 bytes, SHA-256
`214210E7DA76BEE3211B2612691DD32157977C866798074E3C6B3D7D0EC7B4B8`. Every budget
passes except `Details.selectAllVisible.ms=329.8` against 300.0, which is F-08-04.

## The gap this pass closed

The state task had tests behind it and they were all asking a different question.

`Nexus.V7.Shell.StateDerivation` builds an `FNexusShellSignals` by hand, sets the
fields it wants, and checks which of the nine states comes out. It covers every state
and every precedence rule between them, and it is the right test for the derivation.
`Nexus.V7.Shell.StatePresentation` does the same for the headline, detail, and action
each state draws.

Neither says anything about whether the editor can ever produce those signals. A
state can be exhaustively derived, exhaustively presented, and unreachable, and all
the tests stay green.

`Nexus.V7.UiStates` asks the other question. It drives the real
`FNexusEditorShellStateProvider` over the real `UNexusEditorSubsystem`, puts a real
document into each condition, and reads the state back out.

| State | The condition that produces it |
|---|---|
| Loading | a provider whose editor is not there — before the subsystem exists, and after `Shutdown` |
| Empty | no active document; and an active document with no entities and no activation points |
| Ready | a real asset whose package is not dirty |
| Dirty | a real asset created by `FNexusDocumentStore::Create`, in memory and unsaved |
| Warning | the frozen schema-v1 fixture, loaded and migrated forward |
| Blocked | a document `CanSaveLosslessly` refuses — a broken parent link, or an unknown payload with no complete recovery representation |
| Stale | a Details draft authored against a revision the document has since left behind |
| Working | `FNexusShellWorkScope`, which every command execution opens around itself |
| Failure | the reason string a real refused save returned |

`Nexus.V7.UiStates.EveryShellStateHasARealProducer` walks all nine in one test and
asserts the set it reached has nine members, so a tenth state added later fails until
something can enter it.

## F-08-09 — the Stale state nothing could enter (Blocking, fixed)

`ENexusShellState::Stale` is documented ("Content is valid but derived from a source
that has since moved on"), derived by `DeriveShellState`, given a headline and a
detail by `MakeShellStatus`, ranked in the precedence order above Warning and below
Blocked, and covered by five assertions across two suites.

`FNexusEditorShellStateProvider::GetSignals` set `Signals.bSourceStale` from a member
that **nothing in the editor ever wrote**. `SetSourceStale` had no caller outside its
own header. The state was unreachable from the moment it was written.

It was not an unneeded state. `FNexusDetailsView::IsDraftStale` detects the exact
condition the state describes — a draft whose `SourceRevision` no longer matches the
baseline it is diffed against — and Apply refuses while it is true, saying "The
document changed after these edits were made." The shell, meanwhile, showed `Dirty`,
or `Ready`. Two surfaces disagreeing about whether the user's edit can be committed.

**Fixed.** `GetSignals` now reads `bSourceStale || FNexusDetailsView::Get().IsDraftStale()`.
The member stays, and keeps its name, because Phase 09 owns a second staleness — the
landscape source a document is bound to — and the Home health list already carries a
"Landscape source binding" line that reports only that one. A second health line,
"Pending edits", names the draft case, because one `Stale` chip cannot say which of
the two is meant.

The provider also subscribes to `FNexusDetailsView::OnChanged` now. Staleness starts
on a repository change, which the provider already heard, but it *ends* on a reload or
a revert, which moves no revision and broadcasts nothing the provider was listening
for. Without that subscription the strip stayed Stale after Apply had stopped being
refused.

**Verified by disabling the fix**: reverting `GetSignals` to the single member and
rebuilding makes `Nexus.V7.UiStates.EveryShellStateHasARealProducer` fail with
`a document under a stale draft reads as Stale, not Ready` and
`every shell state has a real producer: expected 9, was 8`. Log:
`Saved/Logs/P08-UiStates-negative.log`.

This is the third instance of the class recorded in `agent-memory/declared-is-not-reachable.md`,
and the first where the unreachable thing was a *state* rather than a command or a
widget. A command that is not delivered says so by name, through `OwnerPhase` and
`FNexusPendingPhaseCommandHandler`. A state has no equivalent, so an unreachable one
looks exactly like a reachable one from every angle except this test.

## F-08-10 — a same-day re-run destroyed a cited artifact (Blocking, fixed)

`Scripts/VerifyPhase08UiGate.ps1` defaulted `-RunLabel` to `yyyy-MM-dd` and copied the
budget report to `ui-budgets-<label>.txt` with `-Force`. The first pass ran on
2026-08-28 and its evidence record cites that file by byte count and SHA-256. This
pass ran on 2026-08-28 as well, and silently replaced it.

The dated-name convention exists because of exactly this failure — it was added on
2026-08-23 after a re-run would have overwritten three artifacts the accepted Phase 01
evidence cites. A date is enough between phases and not enough within a day, and a
gate script is the one that gets re-run repeatedly on the day it is being worked on.

**Fixed** two ways, because either alone leaves a hole:

- The default label is now `yyyy-MM-dd-HHmmss`, so an unattended re-run cannot collide.
- The copy step **refuses** when the destination already exists, rather than forcing.
  That covers the case the default cannot: an explicit `-RunLabel`, which is the only
  way a name an evidence record already cites can be produced again.

The overwritten artifact is not recoverable — `Saved/` is gitignored, per F-05 in the
Phase 01 E0 record. The first pass's evidence record now carries a note at the
citation saying so, rather than continuing to offer a digest that matches nothing.

## F-08-12 — one compiler warning inside a "clean editor build" (Warning, fixed)

`SNexusContextStrip::FArguments` listed its member initialisers as `_Workspace`,
`_HomeVisible`, `_Compact` while declaring them as `_Compact`, `_StateProvider`,
`_Workspace`, `_HomeVisible`, so MSVC emitted C5038 on every editor build.

Harmless in effect — all three initialise to constants — but E1 for this phase is a
*clean* editor build, and a build that always emits one warning is a build in which
the next warning is invisible. Reordered to declaration order, with the reason in a
comment so it does not drift back.

## F-08-13 — a test opened a modal dialog in an unattended run (Blocking, fixed)

Found while writing this pass's own suite, in this pass's own code, and recorded
because the mechanism is not specific to it.

`Nexus.V7.UiStates.MigratedDocumentWarns` loads a copy of the frozen schema-v1
fixture. Migration marks the package dirty on load, by design. `UPackageTools::UnloadPackages`
cannot unload a dirty package, and says so **in a modal dialog** — which an unattended
`-unattended` run answers itself and continues past, leaving the package resident and
its `.uasset` on disk. Every run left another asset in `Content/NexusV7Tests/`.

The log line is `Message dialog closed, result: Ok, title: Message, text: The
following assets have been modified and cannot be unloaded`. Nothing failed, nothing
was reported, and the run exited 0.

Fixed by clearing the dirty flag on the scratch copy before unloading it, and by
deleting the folder as well as the file. Any future test that loads a package which
migrates on load needs the same, so this is recorded rather than just fixed.

## F-08-06 — ownership-mismatch is the one state this task could not test

The nine states named in the task are eight plus ownership-mismatch. The eight are
covered above, each by a real editor condition. Ownership-mismatch has no
representation anywhere in the build: no shell state, no details target state, no
diagnostic code, and nothing that detects it.

That is not an omission this pass should close by inventing one.
`phases/phase-10.md` reserves ownership-mismatch detection and its clone/relink/cancel
choice for Phase 10, and building a state for a condition Phase 09's landscape reader
does not yet produce would be a placeholder — which the same gate forbids.

F-08-06 was already open as "needs a decision" after the first pass. This pass
narrows it to a single question with two answers and no third: either the Phase 08
task line drops ownership-mismatch and defers to the Phase 10 reservation, or the
Phase 10 reservation gives it up and Phase 09/10 work has to start before this gate
can close. It cannot be tested here either way.

## What this pass did not do

- E0 independent UI architecture and contract review — not performed.
- E3 user manual acceptance after cold restart — not performed, and it still subsumes
  the outstanding Phase 05, 06, and 07 E3 runs.
- Three clean builds — not run.
- The other seven Phase 08 tasks. The audit of every menu, toolbar, shortcut, context
  action, tree control, details field, and CRUD action is partially done across both
  passes and is not claimed as complete; fixed and dynamic-array payload CRUD through
  the full save/close/restart/reload/undo/redo cycle, the accessibility and DPI pass,
  the destructive-action pass, and the UI/service contract freeze are all untouched.
- F-08-04 remains open and failing, and F-08-05 and F-08-06 still need an owner's
  reading rather than code.
