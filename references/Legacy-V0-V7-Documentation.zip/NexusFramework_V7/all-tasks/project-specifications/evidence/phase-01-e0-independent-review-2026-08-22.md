# Phase 01 — E0 Independent Architecture & Traceability Review — 2026-08-22

## Reviewer and independence

Reviewer: Claude (Opus 5) session, acting as the independent E0 reviewer.
Independence basis: Phase 01 was implemented by a different agent (ChatGPT). This
reviewer wrote none of the Phase 01 code, evidence, or specifications under review.

Scope: `V7-ARCHITECTURE.md`, `V7-QUALITY-GATES.md`, `phases/phase-01.md`, the nine
plugin modules, and the retained Phase 01 evidence records.

## Verdict

**Not accepted yet — Phase 01 remains Ready for Review.**

The implementation is of high quality and every claim this reviewer could
re-execute reproduced exactly. Acceptance is withheld for one reason only:
Phase 01's own gate freezes the runtime asset schema, and two constraints inside
that frozen schema cannot be satisfied by the hierarchy the architecture mandates
(F-01, F-02). Phase 01 exists precisely to remove late blockers of this class, so
these must be dispositioned before the phase advances.

No defect was found in persistence, identity, migration, transaction, or module
boundary work. Those areas are accepted.

## Independently re-executed verification

Every result below was produced by this reviewer on 2026-08-22, not copied from
the implementer's records.

| Check | Command | Result |
|---|---|---|
| E1 editor build | `Build.bat NexusFrameworkEditor Win64 Development -Project=<repo>\NexusFramework.uproject -WaitMutex -NoHotReloadFromIDE` | Succeeded; tree compiles as committed; 0 warnings |
| E1 cold shipping build | `Build.bat NexusFramework Win64 Shipping ... -clean`, then the same command without `-clean` | Succeeded; 14 actions; 27.06 s; 0 warnings |
| Runtime boundary at link level | compile action list of the cold Shipping build | Only `NexusCore`, `NexusRuntime`, and `NexusV7Host` compiled and linked |
| E2 automation | `UnrealEditor-Cmd.exe NexusFramework.uproject -unattended -NullRHI -NoSplash -NoSound -ExecCmds="Automation RunTests Nexus.V7.Foundation; Quit" -TestExit="Automation Test Queue Empty"` | 21/21 Success; `TEST COMPLETE. EXIT CODE: 0`; zero Error/Warning lines |
| Structural scan | `Scripts/VerifyFoundation.ps1` | `FOUNDATION STRUCTURAL SCAN: PASS`, Failures=0 |
| Working tree | `git status --porcelain` after the automation run | Clean; the suite leaves no stray generated asset |

Reviewer artifact, identified per `V7-QUALITY-GATES.md` §2 "Artifact retention":

| Artifact (`Saved/Logs/`) | Bytes | SHA-256 |
|---|---:|---|
| `E0-IndependentReview-Foundation.log` | 304,922 | `0a72ae74de3b9cfdafe70126faae9937d29cd6a4ab6cd6855c3ad3e3d7e28ffa` |

Build logs were written to the reviewer session scratchpad and are not retained.

Architectural invariant 4 ("no editor-only reference appears in a Shipping
dependency") is therefore proven at link level, not only by text scan.

## Findings

Severities use the `V7-ARCHITECTURE.md` §9 definitions.

### F-01 — Blocking — a compiled record must fit inside one cell

`NexusRuntimeDataset.cpp` validation requires every record to carry a valid box
(`IsValidBox`) **and** requires `Cell.Bounds.IsInsideOrOn(Record.Bounds)` for every
record in that cell's range.

A `World`, `State`, `City`, or `Highway` record aggregates an extent far larger
than one cell, so no legal `CellIndex` exists for it. The frozen schema states no
rule for how a non-leaf hierarchy entity is stored. If the intended answer is
"aggregate records carry degenerate bounds at their transform origin", that is a
schema rule that must be written down and validated, not left implicit.

Consequence if unresolved: Phase 16 discovers that the frozen runtime schema
cannot express the mandated hierarchy, which reopens Phase 01 and every phase
built on the compiled contract.

### F-02 — Blocking — parent ordering is unsatisfiable across cells

Canonical record order is cell → kind → id
(`ENexusRuntimeRecordOrder::CellThenKindThenId`), and validation additionally
requires `ParentIndex == INDEX_NONE` or `ParentIndex < RecordIndex` — the parent
must physically precede the child.

Because ordering is cell-major, a parent can only precede its child when the
parent's cell sorts before the child's cell. Multi-Landscape and World Partition
are non-negotiable architecture decisions, so a parent and child in different
cells is the ordinary case, not an edge case. Nothing constrains a parent's cell
coordinate to sort first, and F-01 leaves the parent's cell assignment undefined
in the first place.

Consequence if unresolved: identical to F-01. The two must be answered together,
because the answer to F-01 determines a parent's cell.

### F-03 — Warning — the compiled-schema fixture is degenerate

`NexusRuntimeDatasetTestFixture.h` builds one cell containing two records, both
leaf kinds (`ActivationPoint`, `SubPoint`), with the parent at index 0 and the
child at index 1. It exercises no second cell, no hierarchy-kind record, and no
cross-cell parent — that is, none of the conditions in F-01 or F-02.

The "immutable runtime schema is exact-validated" claim is accurate for what the
fixture covers and unproven for the shape the architecture requires. The fixture
must grow alongside the F-01/F-02 decision.

### F-04 — Warning — recorded evidence commands are not reproducible verbatim

`phase-01-foundation-2026-08-22.md` records build commands against
`E:/Projects/Game/UE/NexusFramework/NexusFramework/_V7/NexusFramework.uproject`.
That path does not exist; the project is at
`E:/Projects/Game/UE/NexusFramework/NexusFramework_V7/`, which is what
`reference-environment-2026-08-22.md` correctly records.

`V7-QUALITY-GATES.md` §1 requires evidence to name the exact command. A reviewer
following the recorded command verbatim cannot run it.

### F-05 — Warning — no evidence artifact is under version control

Every artifact named as retained evidence lives under `Saved/Logs/`, and
`.gitignore` excludes `Saved/`. The 147 log files do exist on this workstation and
this reviewer read them, but they cannot be verified from a clone, cannot be
attached to a review, and are lost with the workstation.

Recommendation: retain the specific artifacts a gate cites — not the whole log
directory — in a tracked evidence path, or record each artifact's SHA-256 in the
evidence file so a later reader can prove the file they hold is the file that was
cited.

### F-06 — Information — authoring payloads are persisted twice

`FNexusPersistentPayload::Serialize` writes the reflected `FInstancedStruct` and
then writes the full recovery-envelope body, which itself contains another copy of
the payload bytes plus a BLAKE3 digest and a custom-version table. This is a
deliberate, well-reasoned trade: it is what makes a missing or renamed type
non-destructive.

The cost is that authoring payload storage is roughly doubled.
`V7-ARCHITECTURE.md` §12 locks a 128 MiB budget for *compiled* data but sets no
budget for authoring asset size or document load time at the locked reference
scale of 100,000 Activation Points. Recommend adding one before Phase 07 so the
trade is measured rather than discovered.

### F-07 — Information — a load-time delegate can outlive its purpose

`UNexusWorldDefinition::MarkMigratedPackageDirtyAfterLoad` binds to
`FCoreUObjectDelegates::OnEndLoadPackage` and unbinds only when its own package
appears in the callback context. A migrated object whose package never reaches
that boundary keeps the binding for the rest of the session and is invoked on
every subsequent package load. Harmless today; worth a bounded unbind.

### F-08 — Information — two Phase 02 preconditions are visible now

- `.github/workflows/` exists but is empty. `V7-ARCHITECTURE.md` §6 states the
  module-boundary test "becomes mandatory CI coverage when a CI pipeline exists",
  and Phase 02 owns the dependency test. Phase 02 should decide explicitly whether
  it also creates the pipeline.
- `NexusEditorUI.Build.cs` declares no dependency on `NexusEditor` or `NexusCore`,
  so the UI currently cannot reach `INexusCommandService`. Phase 02's
  command/service seam task must add that edge deliberately, in the direction the
  architecture allows, rather than letting Phase 03 add it incidentally to make a
  widget compile.

### F-09 — Information — Phase 01 cannot be verified by hand, only by automation

There is no non-test entry point that produces a valid `UNexusWorldDefinition`.
`FNexusActivationPointCommandService::InitializeDocument` is the only code that
assigns a document a valid `DocumentId` and `WorldBindingId`, and its only callers
are `NexusCommandTests.cpp` and `NexusPersistenceTests.cpp`. The plugin registers
no `UFactory` and no asset type actions.

The practical consequence for a human tester: creating a Nexus World Definition
through the Content Browser's Data Asset picker succeeds, but **saving it fails**,
because `CanSaveLosslessly` correctly rejects a document whose IDs are invalid. The
editor reports `LogNexus: Error ... cannot be saved losslessly: document and
world-binding IDs must both be valid`. That is the save gate working as designed,
but it reads as a bug to anyone who has not read this note.

This is not a Phase 01 defect — `phases/phase-01.md` puts production UI out of
scope and the phase requires no E3 manual evidence. It is recorded because it
defines what acceptance can and cannot rest on: every Phase 01 persistence,
migration, transaction, and restart guarantee is proven by automation only. Phase
07 (Full UI CRUD) owns the authoring entry point that makes these paths reachable
by hand.

### F-10 — Warning — the compiled fixture's expected shape is duplicated

The canonical compiled dataset is described in two unrelated places:
`Plugins/.../NexusTests/Private/NexusRuntimeDatasetTestFixture.h` builds it, and
`Source/NexusV7Host/NexusV7Host.cpp` re-asserts roughly sixty of its fields
literally. Nothing links them, and they sit in different module trees — one in the
plugin's editor test module, one in the game host target.

This was found the hard way during the F-01/F-02 remediation: updating the fixture
and every editor-side test left the packaged host still asserting the old shape
(`CellCount == 1`, `RecordCount == 2`, `Records[0].ParentIndex == INDEX_NONE`).
Editor builds, all 21 Foundation tests, the cook, and the package all passed; only
the packaged runtime caught it, exiting 31 with
`NEXUS_PHASE01_PACKAGED_DATASET_LOAD: FAIL`. The gate did its job, but it is the
slowest possible feedback for a mismatch that no earlier stage can see.

The host cannot include the test header — `NexusTests` is an editor module and the
host must link in a packaged build — so some duplication is structural. It can
still be reduced: either lift the expected shape into a runtime-safe shared header
that both consume, or narrow the host to `Validate()` plus a small provenance and
identity subset and let the editor suite own exhaustive field checking. Recommend
deciding this in Phase 02 alongside the module-boundary test, since it is
fundamentally a question about where shared test truth is allowed to live.

## Accepted without qualification

- Identity: `FNexusId` is a persisted `FGuid` wrapper. No name, array index, or
  pointer is used as identity anywhere reviewed.
- Persistence: the envelope preserves declared struct path, BLAKE3 integrity,
  archive and custom-version context, and exact bytes. A future envelope version is
  preserved verbatim and never reinterpreted by current code.
- Save gate: `UNexusWorldDefinition::CanSaveLosslessly` validates the whole document
  graph — duplicate IDs, dangling parents, parent cycles, dangling anchors, invalid
  Landscape owners, non-finite transforms, registry/TypeKey agreement — and rejects
  the package save rather than writing damaged data. The rejection correctly
  completes `Super::Serialize` before calling `SetError`.
- Migration: candidate-first and atomic. Nothing is committed to live fields until
  the migrated candidate passes whole-document validation.
- Transactions: every mutation validates a full copy, then opens exactly one
  `FScopedTransaction`, calls `Modify()`, and replaces the array atomically. The
  revision counter guards negative and `MAX_int64` states.
- Registry: never silently replaces a registration, and unregistration requires an
  exact match, so a module cannot remove a registration it does not own.
- Compiler seam: `INexusCompilerAdapter` takes and returns value data with no
  `UObject`, asset, or package type in its signature. An adapter cannot mutate
  authoring state.
- Determinism: the Build ID derives from canonical provenance via BLAKE3 with
  explicit big-endian assembly. GUID and key comparison is explicit and total.

## Required to move Phase 01 to Ready for Manual QA

1. Disposition F-01 and F-02 together as an explicit architecture decision recorded
   in `V7-ARCHITECTURE.md` — either a stated storage rule for non-leaf and
   cross-cell records, or an amendment to the frozen runtime schema.
2. Extend the compiled-dataset fixture to cover the decided shape (F-03): at
   minimum two cells, one hierarchy-kind record, and a cross-cell parent.
3. Correct the project path in the Phase 01 evidence record (F-04).
4. Decide the evidence-retention rule (F-05).

F-06, F-07, and F-08 do not block Phase 01. They are recorded so they are not
rediscovered later as surprises.

## Remediation applied — 2026-08-22, after the review

The user directed that the minimal fix be applied and that the evidence-retention
rule be digest-based. All five items listed above as required are now done.

**F-01 and F-02 — architecture decision recorded, validator updated.**
`V7-ARCHITECTURE.md` §10 gained "Cell assignment and hierarchy ownership", which
decides three things: a record belongs to the cell whose `Coordinate` equals
`floor(origin / CellSize)`; a cell's stored `Bounds` is loose and must cover its
records while being allowed to exceed its own partition box, which is how an
aggregate hierarchy record is stored; and ownership is validated as an acyclic
graph rather than by record position. `NexusRuntimeDataset.cpp` now enforces the
origin-to-coordinate rule, accepts any parent index other than self, and proves
acyclicity in one linear pass. The stored layout did not change and no dataset
that was valid before became invalid.

**F-03 — fixture extended.** `NexusRuntimeDatasetTestFixture.h` now builds two
cells, three records, and a `City` hierarchy owner whose extent crosses cells and
whose cell sorts *after* the cell holding its child — the exact shape that was
previously unrepresentable. Five negative tests were added: misplaced origin,
parent cycle, self parent, out-of-range parent, and a corrected duplicate-index
case that the old fixture had silently turned into a no-op.

**F-04 — evidence path corrected** in `phase-01-foundation-2026-08-22.md`.

**F-05 — retention rule decided.** `V7-QUALITY-GATES.md` §2 now requires every
cited artifact to carry its byte count and lowercase SHA-256. The Phase 01
foundation record was updated with a digest table for all eight artifacts it
cites. Committing logs to the repository was considered and rejected.

**F-16 forward item.** The Phase 16 task list gained the requirement to fix one
canonical formula for a cell's stored bounds, since validation enforces only
containment and several different bounds satisfy it.

### Post-remediation verification

| Check | Result |
|---|---|
| Editor build | Succeeded; recompiled 4 translation units; 0 warnings |
| `Nexus.V7.Foundation` | 21/21 Success; `EXIT CODE: 0` |
| `Nexus.V7.RuntimeCook.PrepareDataset` | Success; `P01_RuntimeDataset.uasset` regenerated from the new fixture |
| Cold clean Win64 Shipping build | Succeeded; 26.14 s; only NexusCore, NexusRuntime, NexusV7Host compiled and linked |
| `Scripts/VerifyPhase01ColdRestart.ps1` | `PHASE 01 COLD-RESTART PROOF: PASS (3 separate editor processes)` |
| `Scripts/VerifyPhase01CookPackage.ps1` | `PHASE 01 COOK/PACKAGE/RUNTIME-DATASET LOAD: PASS`; packaged runtime logged `NEXUS_PHASE01_PACKAGED_DATASET_LOAD: PASS` |
| `Scripts/VerifyFoundation.ps1` | `FOUNDATION STRUCTURAL SCAN: PASS`, Failures=0 |
| `Scripts/Get-ContentManifest.ps1` | 114 files; SHA-256 `61a0f4059f2e199bb9d679a1c6e243f679e48b6466056ed0e4747b2287794931` |

The first cook/package run of the remediated tree **failed**, and correctly so: the
packaged host still asserted the pre-remediation fixture shape and exited 31 with
`NEXUS_PHASE01_PACKAGED_DATASET_LOAD: FAIL`. `Source/NexusV7Host/NexusV7Host.cpp`
was updated to the new shape and the run then passed. This is recorded as F-10;
the E4 gate was the only stage that could detect it.

The packaged runtime now verifies the F-01/F-02 decision end to end: it asserts
that cell 1's stored bounds reach back across cell 0, that record 0's parent is
record 2, and that the aggregate owner carries no activation payload — all after
cook, pak/IoStore, and a real packaged load.

The manifest moved from 107 files to 114 because this session added the
`agent-memory/` directory; evidence markdown remains excluded as self-referential.

### Why Phase 01 still is not Ready for Manual QA

The remediation above was written by the reviewer. Relative to that change this
session is the implementing agent, not an independent one, so it may not certify
its own work — the same rule that made this E0 review meaningful in the first
place. Phase 01 therefore stays at Ready for Review. It advances when either the
user accepts the remediation, or a second independent pass reviews it.

## Authority note

This review satisfies the E0 inspection requirement only. It does not constitute
Ready for Manual QA, does not substitute for E3 manual QA, and does not mark
Phase 01 Complete. Per `V7-QUALITY-GATES.md` §1, only the user may move Phase 01
to Complete.
