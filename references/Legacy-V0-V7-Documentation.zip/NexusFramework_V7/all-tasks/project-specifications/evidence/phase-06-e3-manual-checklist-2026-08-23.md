# Phase 06 E3 — Manual Test Script — 2026-08-23

## What this closes

E1 and E2 are recorded in [Phase 06 details](phase-06-details-2026-08-23.md). One
acceptance-gate item can only be closed by a person at the editor:

- *"User approves clarity and editing ergonomics."*

The other four gate items are held at E2 and are re-checked here by eye.

**Amended 2026-08-31.** Check 14 records the Phase 08 bounded-Details correction.
This E3 run is still unperformed and must assess the corrected contract.

## Before you start

**Close every running editor before building.** Editors holding the plugin DLLs open
is what a locked-file link error looks like.

Everything starts from the console (`` ` ``), because nothing in the editor binds an
authoring document yet — Phase 07 owns that entry point per Phase 01 finding F-09.

```
Nexus.Fixture.LoadSample Normal        a small healthy tree, 92 rows
Nexus.Fixture.LoadSample Invalid       duplicate names, a missing parent, a cycle
Nexus.Fixture.LoadSample Large         a 100,000-row responsiveness fixture
Nexus.Fixture.Clear                    unbinds, returning the shell to Empty
```

Open `Window > Nexus Framework V7 > Open Hierarchy`, and the Details tab beside it.

## Read this first: four behaviours that are correct, not defects

1. **Rows cannot be created, renamed from the tree, or deleted.** Those commands are
   owned by Phase 07 and refuse **by name**. A refusal naming its phase is a pass.
2. **Kind and Parent are shown and not editable.** Reparenting is a structural move
   that recomputes cell assignment; Phase 07 owns it. A field you cannot edit here is
   not a broken field.
3. **The shell no longer reports Blocked on a healthy fixture.** That was F-E3-04
   from the Phase 05 run and it is fixed. If you see Blocked on `Normal`, that is a
   regression and worth stopping for.
4. **Saving marks the package dirty.** Edits save themselves when you leave a field —
   there is no Apply button, by design. The fixture is transient and there is nothing to
   write it to; Phase 07 owns save to disk. A dirty marker is correct.

---

## The checks

### 1. Selecting a row fills Details

**Do:** load `Normal`. Click a City in the tree, then look at Details.

**Expect:** the header names the city; the breadcrumb reads State / City; categories
Identity, Hierarchy, and Payload are present; Kind and Parent are visibly read-only.
The footer has **no buttons** — it is a status line, and with nothing edited it is
blank.

**Fail if:** Details stays empty, shows the previous selection, or the footer offers a
button.

**Result:**

### 2. Opening Details *after* selecting still resolves

**Do:** close the Details tab. Select a Highway in the tree. Reopen Details.

**Expect:** it comes up on the Highway you selected, not empty and not on something
else. This is the explicit requirement at the end of V7-UX-SPEC.md section 8.1.

**Fail if:** the panel opens empty or on a stale target.

**Result:**

### 3. Typing saves itself — the main check

**Do:** click into the entity's Name field and type. Watch the footer while you type.
Then click somewhere else, or press `Enter`.

**Expect:** while typing, the footer reads **Editing — saves when you finish** with a
hint that Escape discards the field. The caret stays where you put it and the field
does not reset under you. On leaving the field, the footer turns green and reads
**Saved**, and the tree row's name updates to match. No button was pressed.

**Fail if:** the caret jumps to the start, the text resets while typing, the footer
never reaches Saved, or the tree does not follow.

**Result:**

### 4. Escape abandons the field

**Do:** click into Name, type something different, then press `Escape` **before**
leaving the field.

**Expect:** the field returns to its previous value and the footer does **not** say
Saved. Then click away — still nothing is saved, because there is nothing to save. The
tree row keeps its original name.

**Fail if:** the box shows the old text but the change is saved anyway when you click
away, or Escape leaves the field showing the typed value.

**Result:**

### 5. Undo reverses a saved edit

**Do:** change Sort Order and leave the field so it saves. Then press `Ctrl+Z`.

**Expect:** the value returns to what it was and Details shows it. Note that undo now
works **one field at a time** — each finished edit is its own step, which is what a
native Unreal panel does.

**Fail if:** undo does nothing, undoes more than the one field, or leaves Details
showing a value the document no longer holds.

**Result:**

### 5a. Undo still works after an edit is abandoned — run this immediately after 4

**This is the highest-value check on the page.** Run it as its own step and in this
exact order; do not assume check 5 covers it.

**Do, in one sequence without restarting the editor:**

1. Click into Name, type anything, press `Escape`.
2. Click into Sort Order, change it, leave the field so it saves.
3. Press `Ctrl+Z`. Then press `Ctrl+Y`.
4. Now select a *different* entity, start typing in its Name, and — without pressing
   Escape — click straight onto another row in the tree.
5. Press `Ctrl+Z` again.

**Expect:** every `Ctrl+Z` and `Ctrl+Y` responds. Undo is not slow, not partial: it
either works or it is dead, and dead is the failure being looked for.

**Fail if:** undo and redo do nothing *at all* from step 3 or step 5 onward, including
on unrelated actions elsewhere in the editor, and stay dead until the editor is
restarted.

**Why this exists.** Until 2026-08-24 both abandonment paths — `Escape`, and changing
selection mid-edit — left an editor transaction open. `UTransBuffer::CanUndo` refuses
while any transaction is active, so a single `Escape` disabled undo and redo for the
rest of the session. Checks 4 and 5 run back to back would have caught it, which is
the point: they were never run. Automation cannot reach this one — the text box is
behind Slate and cannot be typed into headlessly — so
`Nexus.V7.Module.UiMutationBoundary` guards the source-level rule and this check
guards the behaviour. See `agent-todos/ready-for-review/bugs-redu-undo__scape-click.md`
item 4.

**Result:**

### 6. Multi-selection shows mixed values honestly

**Do:** ctrl-click three Cities. Look at Name, then at Sort Order.

**Expect:** fields the three disagree on read **Multiple Values**; fields they agree on
show the shared value. Editing Sort Order sets it on all three, and leaving the field
saves all three in one step — one undo reverses the whole batch.

**Fail if:** one entity's name is shown as if it were all of theirs, saving a shared
field overwrites the distinct names, or undo takes three presses.

**Result:**

### 7. An invalid field explains itself and is not saved

**Do:** set Sort Order to `-1` and leave the field.

**Expect:** a blocking message appears that names the repair, not just the problem, and
the footer reads **Not saved** with that reason. The value is *kept in the panel* — it
is not thrown away. Setting it to `0` and leaving the field clears the message and
saves.

**Fail if:** `-1` reaches the document, the message is a bare field name, the edit is
discarded, or the message persists after the field is fixed.

**Result:**

### 8. An edit is kept when you navigate away

**Do:** put City A's Sort Order into an invalid state — `-1` — so it cannot save, then
click City B without correcting it. Then click City A again.

**Expect:** a line appears noting an unsaved edit is being kept while B is selected;
returning to A restores it exactly. Nothing interrupts you to ask.

**Fail if:** the edit is silently lost, or a modal asks what to do with it.

**Result:**

### 9. Deleting the thing you are editing

**Do:** edit a field, then with that entity still selected run
`Nexus.Fixture.LoadSample Normal` again to rebuild the document underneath it.

**Expect:** Details reports its targets are gone in a sentence, does not crash, and
does not throw the edit away. Nothing is saved.

**Fail if:** the editor crashes, the panel shows stale fields as if they were live, or
the edit vanishes without being mentioned.

**Result:**

### 10. Broken data does not break the panel

**Do:** run `Nexus.Fixture.LoadSample Invalid`. Select, in turn, the row with the
missing parent, a row in the cycle, and the unanchored activation point.

**Expect:** each selects and shows fields. The breadcrumb on the cycle member
terminates rather than growing forever. Nothing hangs.

**Fail if:** the editor hangs, the breadcrumb repeats endlessly, or selecting a broken
row shows nothing at all.

**Result:**

### 11. The panel is readable and reachable by keyboard

**Do:** narrow the Details tab until it is roughly a third of its width. Then tab
through the panel from the header to the footer.

**Expect:** nothing clips; long names wrap rather than being cut; the search box, the
property rows, and the footer status are all reachable and show a visible focus ring.

**Fail if:** text clips, the footer is pushed off-screen, or tabbing cannot reach a
property row.

**Result:**

### 12. Carried from Phase 04: the focus-recursion crash has not returned

**Do:** switch between the three Nexus tabs repeatedly while a draft is dirty. Click
Refresh from each surface.

**Expect:** no crash. F-E3-03 was a stack overflow on this path and still has **no
automated guard**; Details rebinding its property view on every change is a new
opportunity for the same shape of re-entry.

**Fail if:** the editor crashes or freezes.

**Result:**

### 13. A clean exit

**Do:** run `Nexus.Fixture.Clear`, then close the editor normally.

**Expect:** Details returns to its no-document sentence naming Phase 07. The editor
exits with no error dialog and no crash reporter.

**Fail if:** anything is logged as an error on shutdown.

**Result:**

### 14. Large selection remains whole and summary-only — added 2026-08-31

**Do:** run Nexus.Fixture.LoadSample Large. Put focus in Hierarchy and press Ctrl+A;
then open Details. Narrow the selection back to one row.

**Expect:** the header reports the full selection count for the 100,000-row fixture
and Details tells you to refine to 1,000 or fewer. It has no bound property grid,
per-item Copy ID action, or usable Apply or Revert action while deferred. After
narrowing, the selected row's normal Details fields return.

**Fail if:** Details shows properties for only a hidden prefix of the selection,
permits a partial Apply or Revert, loses the count, or fails to restore normal fields
after narrowing.

**Result:**

---

## After the run

Report each item as PASS or FAIL with what you saw. Failures are recorded and fixed
before the phase moves.

Per `V7-QUALITY-GATES.md` section 1, only you can then mark Phase 06 **Complete** in
`PHASE-STATUS.md`. If you accept the phase without working through these fourteen
items one by one, say so — the record will say it rests on a session acceptance rather
than on an itemised pass, the way Phase 04's and Phase 05's do.
