# Phase 07 — E3 manual checklist — 2026-08-24

Twenty-one checks. Every acceptance-gate item in `phases/phase-07.md` depends on this
run; none of them can be met by automation, and the last one cannot be met by
anything except closing the editor and opening it again.

**Do not mark the phase Complete from this page.** Record what you see against each
check and hand it back. Complete is your call, and it needs this run to pass.

**Amended 2026-08-28.** Checks 2, 17, and 20 asserted the eight-rung ladder and the
Create World button, both of which are gone: the hierarchy is now State > City >
Highway > Highway Point, adjacent only, and default names are numbered. The change
and its reasoning are in `V7-ARCHITECTURE.md` §"Entity kind legality". Check 3 gained
the click-away case that found F-08-07, where an inline rename wrote its text onto
whichever row was clicked next, and check 2 the Alongside section that made a second
State reachable at all (F-08-08). Nothing else on this page moved.

## Before you start

Close any running editor first — four `UnrealEditor.exe` processes were up during
the last build and they hold the plugin DLLs open.

If you want the automated side re-verified first, this is the whole of it and it
takes about three minutes:

```
powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase07Crud.ps1 -SkipBuilds
```

Expect `PASS: 127 tests, 0 failures` and `PHASE 07 CRUD: PASS`. Drop `-SkipBuilds`
to include the three clean builds (about fifteen minutes).

Then open `NexusFramework.uproject` and the Nexus workspace tab. **Do not load a
console fixture for this run.** Everything below works on a real asset, which is
the whole point of the phase — a fixture document cannot be saved and will refuse
by name if you try.

---

## Short on time? The seven that carry the risk

If you cannot do all twenty-one in one sitting, do these. They are checks 1, 2, 6, 7,
8, 12, and 19 below, in the order you would naturally perform them — each one is
written out in full further down.

| # | Do | Expect |
|---|---|---|
| 1 | `Ctrl+Shift+P` → **New Document** | An asset under `/Game/Nexus`, **unsaved**; surfaces stop saying Empty |
| 2 | Right-click tree → **Create ▸** | Two sections: one child kind *inside*, that row's own kind *alongside*; new row opens into rename as `New State 1` |
| 6 | Select a parent row, press `Delete` | A popup naming what goes, over the tab you are on; Cancel changes nothing; the tree updates |
| 7 | `Ctrl+Z` once, then `Ctrl+Y` | One press restores the whole subtree; undo keeps working after |
| 8 | Edit, **Save Document**, Save again | Dirty → clean; the second save refuses instead of faking success |
| 12 | Save, close the editor, reopen, **Open Document** | Everything returns correct; the asset is not dirty |
| 19 | File > Open Level > `NF/Maps/LV0_Development1` | `LV0_Development1/NexusConfig` appears **unsaved**, and is the active document |

**Seven is not an E3 pass.** The remaining thirteen cover surface parity,
keyboard-only reachability, reload, multi-parent create, duplicate independence, the
partial-failure case, and the default-hierarchy seed. Record what you ran either way.

---

## 1. A document can be made from the editor at all

This is Phase 01 finding F-09, open since 22 August: until now nothing in the
product could bind an authoring document.

**Do:** open the command palette (`Ctrl+Shift+P`) and run **New Document**.

**Expect:** a `NexusWorld` asset appears under `/Game/Nexus` in the Content
Browser **marked unsaved** — an asterisk on the tile, nothing yet written to
disk — the Nexus surfaces bind to it, and the context strip names it and says
`UNSAVED`. The hierarchy shows an empty document rather than "no document".

Creating no longer writes the package. That is the change, not a regression:
V7-UX-SPEC.md 12.1 forbids an authoring path from silently invoking a package
save, and Unreal's own create-asset flow behaves the same way. Closing the editor
now raises Unreal's standard "save these packages?" prompt instead of losing the
document silently.

**Then:** run **New Document** a second time without saving the first.

**Expect:** a second asset named `NexusWorld_1`. The name generation used to consult
only the disk, which was enough while creating also wrote; it now checks memory too.

**Fail if:** the command refuses, no asset appears, the surfaces still say
nothing is open, a `.uasset` is already on disk before you save, **or the second New
Document refuses with "already exists"**.

**Result:**

## 2. Create is registry-driven, and says what it will make

Rewritten 2026-08-28. The ladder was narrowed from eight rungs to four, adjacent
only, and this check asserted the old shape at every step. See
`V7-ARCHITECTURE.md` §"Entity kind legality".

**Do:** right-click in the empty tree. Look at the **Create** submenu. Create a
**State**. Then right-click the new State and look at its Create submenu. Then do
the same on the City you make under it, and on a Highway under that.

**Expect:** the submenu has **two sections**. *Inside the selection* holds one kind
and no more — the root offers **State**, a State offers **City**, a City offers
**Highway**, and a Highway offers nothing there because its points come from the
landscape. *Alongside the selection* holds that row's own kind: a State offers
**State**, which goes to the document root and is **the only way to make a second
State**; a City offers City, a Highway offers Highway.

With nothing selected there is one section only, because the root's children *are*
the root list and showing it twice would be two entries doing one thing.

No World anywhere; the document is itself the world. No Road, Junction, or Sub Point
anywhere; they are retired.

The new item is selected and its name is already in an edit box, pre-filled with
**`New State 1`** — the kind, then one past however many of that kind the document
holds. Make a second and it is `New State 2`.

**Then:** with a State selected, run **Create ▸ Alongside ▸ State**.

**Expect:** the new State appears at the **document root**, beside the one you had
selected — not inside it. Then select two Cities under the same State and use
*Alongside*: exactly **one** City is added, because they share one parent, and the
entry says `City (1)` rather than `City (2)`.

**Fail if:** any level offers more than its one child kind inside; the *Alongside*
section is missing, or a State cannot be created from a State row; **an item chosen
from *Alongside* lands inside the selected row instead of beside it** — picking
"State" and getting a City is the specific way this fails; World, Road, Junction, or
Sub Point appears; a Highway offers Highway Point rather than another Highway; the
default name has no number, or the number restarts under each parent; the new item is
created but not selected; or you have to press F2 yourself to name it.

**Result:**

## 3. Inline rename, including the collision case

**Do:** name the new State `Alpha` and press Enter. Create a second State and try
to name it `Alpha` too. Then give it a different name. Press `F2` on either one,
type something, and press `Escape`.

**Expect:** the first rename commits. The second is refused **inline, with a
suggested free name in the message** (`'Alpha' is already used here. Try 'Alpha 2'.`)
and the box stays open so you can correct it. Escape abandons the edit and leaves
the original name.

**Then — added 2026-08-28, this is the one the user hit.** Create a Highway, and while
its name is still in the edit box, **click a different row instead of pressing Enter**.
Do it once on a sibling under the same parent, and once on a row under a different
parent.

**Expect:** the new Highway keeps the name it was offered, the row you clicked keeps
its own name and becomes selected, and **no error appears** — accepting the offered
name by clicking away is an acceptance, not a rename. Then do the same having actually
typed a new name: it must land on the row whose editor was open, never on the row you
clicked.

**Fail if:** a `Nexus.Authoring.NameCollision` banner appears naming a row you did not
edit; the row you clicked gets renamed; anything asks you to "select an item in the
hierarchy to rename" after you have already typed one; or the typed name goes nowhere.
The silent version — the *other* row quietly taking the name, with no error at all — is
the one worth looking twice for, because nothing on screen announces it.

**Fail if:** the collision is accepted, or refused without a suggestion, or Escape
commits the typed name.

**Result:**

## 4. Multi-parent Create says how many

**Do:** select both States (ctrl-click). Right-click and open the Create submenu.

**Expect:** each kind reads `City (2)` — the count of items it would make. Running
it creates one child under **each** selected State, not one in total.

**Fail if:** the count is missing or wrong, or only one child is created.

**Result:**

## 5. Duplicate copies the subtree and nothing is shared

**Do:** build a small tree — a State with two Cities, one City with a Highway.
Select the City with the Highway and run **Duplicate** from the context menu. Then
rename something inside the *copy*.

**Expect:** the copy appears beside the original with a distinguishing name, the
Highway is copied under it, and selection moves to the copy. Renaming inside the
copy does **not** change the original.

**Fail if:** the copy's child points at the original's, editing one changes the
other, or the copy lands somewhere unexpected in the tree.

**Result:**

## 6. Delete shows what it will take, and Cancel changes nothing

Rewritten 2026-08-24. This check previously required the confirmation to be an
inline strip under the toolbar. It is now a popup, for the reasons in
`agent-todos/ready-for-review/need-enhancement.md`: the strip was drawn inside
every open surface, three copies fought over keyboard focus, and raising it brought
another tab forward.

**Do:** open the **Details** tab so it is the one in front. Then click a row in the
Hierarchy tab, select the State at the top of your tree, and press `Delete`.

**Expect:** a popup over the Hierarchy tab naming the count and listing what goes
with it (`Delete 1 selected item and 4 items beneath them.`). **The tab you are on
does not change.** The safe control — *Leave things as they are* — has focus, and
the other control names the verb rather than saying OK. Press `Escape`.

**Then:** press `Delete` again and click outside the popup instead.

**Expect:** both dismiss it and change nothing at all.

**Then:** press `Delete` a third time and confirm it.

**Expect:** the whole subtree goes, **and the tree redraws without it** — no row for
a record that is gone. Selection moves to the nearest surviving row rather than to
nothing.

**Fail if:** the editor switches tabs when the question appears; the popup traps
input so the rest of the editor is unusable; the count is wrong; Cancel, Escape, or
clicking away deletes anything; or the tree is left showing rows that are gone.
That last one was the bug: the delete worked and nothing on screen moved.

**Result:**

## 7. One Ctrl+Z brings the whole subtree back

**Do:** immediately after the delete in check 6, press `Ctrl+Z`. Then `Ctrl+Y`.

**Expect:** one undo restores every deleted row **and** the Details panel and tree
agree afterwards. Redo removes them again. Undo and redo keep working for the rest
of the session.

**Fail if:** undo restores only part of the subtree, needs several presses, leaves
the tree showing the pre-undo state, or stops working entirely. The last of those
is the shape of the bug fixed on 24 August — note it loudly if it comes back.

**Result:**

## 8. Save, and the dirty state that goes with it

**Do:** make an edit. Look at the context strip. Run **Save Document**. Look again.
Then run Save a second time without changing anything.

**Expect:** the strip shows the document as dirty after the edit and clean after
the save. The second Save refuses with *"The document has no unsaved changes."*
rather than writing again or reporting a success that did nothing.

**Fail if:** the dirty indicator does not move, or a save that wrote nothing reports
success.

**Result:**

## 9. Reload discards, and says so first

**Do:** make an edit and **do not** save. Run **Reload Document**.

**Expect:** a confirmation naming the document and saying the unsaved change will
be discarded. Confirming re-reads from disk and the edit is gone. The tree and
Details both show the saved state, not the discarded one.

**Fail if:** it reloads without asking, keeps the unsaved edit, or leaves any
surface showing the old document.

**Result:**

## 10. Every surface reaches the same commands

Two earlier V7 phases shipped surfaces that no keystroke or click could reach while
every automated declaration test stayed green, so this check is here on purpose.

**Do:** perform one Create, one Rename, one Duplicate, and one Delete — each from a
*different* surface: the row context menu, the `F2` / `Insert` / `Delete` chords,
the command palette, and the toolbar. Then, without touching the mouse, `Tab`
through the tree and the Details panel.

**Expect:** all four work identically wherever they are invoked, disabled entries
explain themselves in their tooltip, and focus is visible at every Tab stop and
never gets stuck.

**Fail if:** a command behaves differently depending on where it was invoked, a
control is visible but inert, or focus disappears. Note **which** control — that
detail is the whole value of this check.

**Result:**

## 11. A failed operation leaves nothing half-done

**Do:** with two entities selected, delete one of them from a *second* editor
surface or undo it, then confirm the pending delete from the first. Alternatively:
select several rows, start a Delete, and press `Ctrl+Z` before confirming.

**Expect:** the operation refuses with a reason about the document having changed,
and **nothing** is deleted — not the still-present one either. The approval is
refused because it describes a document that has moved.

**Fail if:** part of the operation goes through, or it succeeds against a document
that is no longer what the preview described.

**Result:**

## 12. It survives a real editor restart — **the one that matters**

Session-only data is explicitly not acceptance evidence for this phase, and no
automation in this project can restart an editor.

**Do:** build a tree of at least three levels with several named entities. Save.
**Close the editor completely.** Reopen it, open the same asset, and run
**Open Document** on it.

**Expect:** every entity is there with the right name, the right kind, and the right
parent. Nothing has moved, nothing is duplicated, and the asset does not prompt to
save again when you have changed nothing since reopening.

**Fail if:** anything reverted, landed under the wrong parent, lost its name, or the
document comes back dirty.

**Result:**

## 13. Every message can be selected and copied

Added 2026-08-24. Automation can prove the widgets are the selectable kind and that
they are where they should be; it cannot drag a mouse across one.

**Do:** make a command fail or refuse — pressing `Delete` with nothing selected is
the easiest. A banner appears at the top of the surface. Drag across its text.

**Expect:** the text highlights and a caret appears. `Ctrl+C` copies it. Right-click
offers **Copy** and **Select All**. The banner's own **Copy** button puts the
message and its detail on the clipboard together. Paste somewhere to confirm.

**Then:** try the same on the footer status line, the Details tab's validation
findings, its dirty/stale banner, and the state message a surface shows when nothing
is selected.

**Then:** open the **Activity** tab and right-click any entry.

**Expect:** a **Copy** menu with *Copy Activity Entry*, *Copy Technical Details*, and
*Copy Diagnostics*. Right-clicking a row selects that row first, so the entry you
copy is the one you aimed at. Entries with nothing to copy are disabled with a
reason rather than missing.

**Fail if:** any of that text cannot be selected; the Details dirty/stale banner has
lost its colour, which is drawn differently now that it is selectable; a right-click
on an Activity row copies a different row; or clicking into a message swallows a
keystroke the surface should have handled — try `Ctrl+Shift+P` right after clicking
into a banner.

**Result:**

---

## 14. The chrome appears once, not once per tab — **open all three tabs first**

This is the only check in the list that is invisible with a single tab open, which
is why it shipped: every surface, examined on its own, was correct.

**Do:** open **Hierarchy**, **Details**, and **Activity** at once, side by side or
as three tabs you can switch between quickly. Then run any command that produces a
message — **Validate Document** is the easiest — from the Hierarchy tab.

**Expect:**

- **One** banner, on Hierarchy, the tab you ran it from. Not one per tab. Dismiss it
  and it goes; nothing is left behind on the other two.
- **One** toolbar in the whole workspace, on Hierarchy. Details ends its chrome at
  the context strip and goes straight into properties; Activity into its list.
- The toolbar has three buttons — Refresh, Validate Document, Show Diagnostics —
  and no Command Palette button, because the context strip directly above it has
  one. The `…` overflow is not a defect; section 18.3 requires it.
- The context strip is on all three tabs, which section 3.3 requires, but only
  Hierarchy draws the full one. Details and Activity show the badge, the document
  name, and `UNSAVED` — hover for the entity count, revision, and path.
- No surface header. The tab label already carries the surface name and its tooltip
  the description; the readiness badge now appears twice per panel (strip and
  footer) rather than three times.

**Then:** run a command from **Details** — `Ctrl+Shift+P` → **Revert Draft** with
nothing to revert will refuse and produce a message. The banner must appear on
**Details**, not on Hierarchy.

**Then:** set the editor to **200%** DPI and look again.

**Fail if:** a message appears on more than one tab at once; dismissing on one tab
leaves a copy on another; a message appears on a tab other than the one you invoked
from; more than one toolbar is visible; anything clips or overlaps at 200%; or the
toolbar buttons are too small to hit comfortably — the glyphs are 16px now, down
from 20, and that is the floor.

**Result:**

---

## 15. The Details footer no longer claims a save it did not make

**Do:** select an entity, change a property, and press Enter. Watch the footer line
under the property list.

**Expect:** **"Applied — Ctrl+S saves the asset"**. While you are still typing or
mid-drag it reads **"Editing — applies when you finish"**.

It used to say **"Saved"**, while nothing had been written to disk — the draft had
been committed to the document in memory and the package marked dirty, which is what
V7-UX-SPEC.md 12.1 requires and is not a save. The wording promised the write the
code correctly does not perform.

**Then:** confirm the context strip still says `UNSAVED` at that moment, and that
`Ctrl+S` is what clears it.

**Fail if:** the footer says "Saved" anywhere before the asset is actually written,
or the strip goes clean without a save.

**Result:**

---

## 16. The document says it needs saving, and can be saved

**Reported by the user 2026-08-27:** *"when i made any changes, i cannot see the
dirty in editor and editor not showing dirty or save, the editor not tracking maybe
it has some changes and need to save."*

The flag was correct throughout — every entity edit marks the package dirty, and
`Nexus.V7.Crud.DocumentLifecycle` proves it. Two things were wrong: the marker was
drawn in the shell's smallest, lowest-contrast text token, and **Save Document was
reachable only from the command palette** — no toolbar entry, none of the ten
entries §3.1 fixes for the Window submenu, not the row context menu, and no chord.

**Do:** make any change — create an entity, rename one, or edit a property and press
Enter. Look at the context strip.

**Expect:** amber **`UNSAVED`** at body weight, not small grey text, with a **Save**
button beside it. Both appear on all three tabs, because §3.3 puts the strip on all
three. The Hierarchy toolbar also leads with **Save Document**.

**Then:** press **Save**.

**Expect:** the `UNSAVED` marker and the Save button both disappear, the Content
Browser asterisk clears, and the `.uasset` is on disk. Press it again with nothing
to save and it is not offered — the command refuses a clean document by name, so the
control is hidden rather than present-and-useless.

**Then:** check the Content Browser while dirty.

**Expect:** an asterisk on the asset tile, and the asset listed under
`File > Save All`. Unreal's own tracking was never broken; it is worth confirming
alongside the shell's.

**Fail if:** the marker is hard to notice; the Save button is missing, disabled while
dirty, or still offered when clean; pressing it does nothing; or `Ctrl+S` is needed
to save the Nexus asset — it is Unreal's level save and is deliberately not this.

**Result:**

---

## 17. A brand-new document can be authored from zero

**Reported by the user 2026-08-27:** *"in first time the tree has empty and not
showing any options, to create, state, city or anythings, so, from 0 i am not able to
create any things, I need to run console command for some demo then allow to create."*

**Do not load a fixture for this check.** Loading one is the workaround that hid the
bug; the whole point is the state a real **New Document** leaves you in.

**Do:** `Ctrl+Shift+P` → **New Document**. Look at the Hierarchy tab.

**Expect:** a headline **"This document is empty"**, a sentence naming what to do,
and a **Create State** button. There is no Create World button as of 2026-08-28 —
the document is itself the world. Press **Create State**.

**Expect:** a State row appears, selected, with `New State 1` already in edit mode.

**Then:** right-click anywhere in the blank area of the tree, not on a row.

**Expect:** the same context menu a row gives, with **Create ▸** offering State.
Empty space is right-clickable now; it used to be a collapsed widget that received
no mouse events at all.

**Then:** with the State selected, right-click it and check **Create ▸** again.

**Expect:** **City**, and nothing else.

**Fail if:** the empty tree shows a bare sentence with no buttons; right-clicking
blank space does nothing; the buttons offer a kind the menu does not, or the reverse;
or the message mentions "Phase 07", which has shipped.

**Result:**

---

## 18. A fixture document says it is one

**Do:** in the editor console, `Nexus.Fixture.LoadSample Normal`. Edit anything —
rename a row, change a property.

**Expect:** the context strip shows **`IN MEMORY - NO ASSET`** in purple, and **no**
Save button. Hovering it explains that the document came from the fixture command,
has no asset behind it, and that New Document makes a real one.

It must **not** show amber `UNSAVED`. A fixture lives in the transient package, so
marking it dirty does nothing and it can never be saved — the strip used to draw
nothing at all here, which reads as the editor having lost the edits.

**Then:** `Nexus.Fixture.Clear`, then **New Document**, and edit again.

**Expect:** amber `UNSAVED` and a working **Save** button, as in check 16.

**Fail if:** a fixture shows `UNSAVED` or a Save button; a real document shows
`IN MEMORY`; or either shows nothing at all after an edit.

**Note for whoever runs this:** the per-map config asset V6 auto-created beside the
level (`Content/NF/Maps/<MapName>/NexusConfig.uasset`) **now exists in V7** — it is
check 19 below. This note previously said it was not expected to, on the grounds that
`phases/phase-10.md` owned it; that was true of the phase boundary and was still the
wrong answer to give a third time.

**Result:**

---

## 19. Opening a map produces the map's own document, unsaved

**Reported by the user three times, and refused three times before this:** *"the
previous project … LV0_Development1 auto generate config file and make it dirty and
showing unsaved in UE editor but not in our project???"*

**Do:** File > Open Level → `Content/NF/Maps/LV0_Development1`. Then look at the
Content Browser folder `Content/NF/Maps/LV0_Development1/` and at the Nexus context
strip.

**Expect:** a `NexusConfig` asset in that folder with an asterisk, amber `UNSAVED` on
the strip, and no `NexusConfig.uasset` on disk yet. It is the active document, so the
Hierarchy tab is showing it.

This is V6's convention — V6 wrote the same path — with one deliberate difference:
V6 saved the file immediately and this does not. An asset written because you opened
a map is a file nobody asked for; unsaved-with-an-asterisk is what Unreal's own
create-asset flow does, and it is what the report asked for.

**Then:** press **Save** on the strip. Then File > Open Level →
`Content/NF/Maps/LV0_Development2`.

**Expect:** the first asset is now on disk and clean, and the document switches to
`LV0_Development2`'s own — created fresh and unsaved, not the first map's.

**Then:** File > New Level → Empty Level.

**Expect:** the Nexus document goes away rather than the previous map's staying live.
A blank level that still edits the level before it is a real bug V6 shipped.

**Then:** switch back to `LV0_Development1`.

**Expect:** its saved document opens with whatever you put in it, not an empty one.

**Fail if:** no asset appears; one appears already saved to disk; the document does
not follow the map; a blank new level keeps the previous map's document; or the
document that comes back on the second visit has lost its contents.

**Note:** `Nexus.AutoBindWorldDocument 0` disables this. And no automation covers the
map-open half of it — the bind is skipped under `-unattended`, so this check is the
only proof the delegate fires.

**Result:**

---

## 20. Create Default seeds the whole spine from an empty tree

**Reported by the user 2026-08-27:** *"if tree is empty then show the create button as
create default and create > Default State > Default City > Default Highway."*

**Do:** with an empty document active — the one check 19 just made is ideal — look at
the Hierarchy tab's empty panel.

**Expect:** **Create Default** as the first and primary button, then **Create
State** — and, as of 2026-08-28, no Create World beside it.

**Then:** press **Create Default**.

**Expect:** three rows — `Default State`, with `Default City` under it, with `Default
Highway` under that. The State is selected. **No rename box opens**, because all three
already carry the names the button promised.

**Then:** press `Ctrl+Z` once.

**Expect:** all three go together. It is one transaction, not three.

**Then:** press `Ctrl+Y`, and look at the empty panel again — it is gone, because
there are rows now. Right-click a row and open **Create ▸**.

**Expect:** the Create group also lists **Create Default Hierarchy**, and it is
disabled with a reason naming the entity count and pointing at Create. It is offered
only from empty, so a second press cannot make a second `Default State`.

**Fail if:** the button is missing or is not first; it makes fewer than three rows or
parents them wrongly; the names differ; a rename box opens; one `Ctrl+Z` leaves any of
them behind; or it stays available on a document that already has rows.

**Result:**

---

## 21. The tree rows read as a tree

**Asked for 2026-08-27:** *"the tree view design is not very good. make it more good
looks if possible, put the arrow icon good put just more 10% padding."*

This one is judgement, not pass/fail arithmetic — say what you see.

**Do:** open a document with a few levels of nesting and look at the rows.

**Expect:**
- The expander is the **engine's tree arrow**, the same glyph the World Outliner
  draws. It used to be the letters `v` and `>` in the body font.
- Rows with children and rows without **start their names in the same place**.
- Selection is a **rounded accent pill inset from the panel edge**, not a flat bar
  running corner to corner.
- Hovering an unselected row gives it a **faint fill**; hovering the selected row
  changes nothing, because it is already the strongest thing on screen.
- Rows are **slightly less cramped** than before — 10% more padding, which is about
  a pixel a side. It is meant to be felt rather than measured.

**Fail if:** the arrow is a letter or a box glyph; names shift horizontally depending
on whether a row has children; the selection pill clips the text or touches the row
above; hover and selection are hard to tell apart; or the extra padding has made rows
tall enough to fit fewer of them on screen than is comfortable.

**Result:**

---

## After the run

Write the outcome of each check above and hand it back.

If all twenty-one pass, the seven acceptance-gate items in `phases/phase-07.md` can be
assessed — that assessment is yours, not the implementing agent's. Phase 08 is the
UI Completion Gate and is blocked on this phase being Complete.

If any check fails, the failing check number and what you saw is enough to act on; a
screenshot helps for check 10.

**Still outstanding regardless of this run,** and recorded in
`phase-07-crud-2026-08-24.md` rather than hidden here: reparent has no UI gesture,
conflict handling does not cover an externally changed asset, activation points are
not creatable from the UI until Phase 14, and Home does not yet list recoverable
work.
