# Phase 04 Menus & Command System Evidence — 2026-08-23

## Verdict

**Complete.** E1 and E2 are green on a clean tree. E3 was accepted by the user on
2026-08-23, and per `V7-QUALITY-GATES.md` §1 that decision is theirs alone.

Read the E3 acceptance precisely, because it is narrower than an itemised pass. E3
run 1 **found two Blocking defects**, both in the half of the phase automation was
not reaching: the surfaces that turn a command into something a person can actually
invoke. A third defect was introduced by the fix for the second. All three are fixed;
the first two are held by new guards that were proven to fail. See
[The three E3 findings](#the-three-e3-findings) below.

The planned re-run from the top did **not** happen. The user worked in the rebuilt
editor and accepted the result as a whole — *"UI displaying good"* — without
reporting checklist items 1–11 back individually. The fifth gate item was closed on
that acceptance, and the eleven `Result:` fields in
[the manual checklist](phase-04-e3-manual-checklist-2026-08-23.md) say so rather than
claiming passes. F-E3-03 in particular has no automated guard and no reported repro
of the tab-switch/Refresh sequence; it rests on the session not crashing.

Four of the five gate items are held at E2. The fifth is held by that session
acceptance.


## The three E3 findings

Both were found by a person at the editor within minutes of opening it, and neither
could have been found by the E2 suite as it stood. That is worth recording plainly:
the suite tested that the command model was correct and complete, and both defects
were in the wiring between that model and the keyboard.

### F-E3-01 — the palette swallowed any command that opens a surface

**Symptom.** `Show Keyboard Shortcuts` appeared to do nothing. The only trace it had
run at all was an Activity entry reporting success.

**Cause.** `SNexusCommandPalette::ChooseSelected` dispatched the chosen command and
dismissed the palette afterwards. `Show Keyboard Shortcuts` is implemented as the
palette reopened in shortcuts-only mode, so the sequence was: dispatch, which asked
the module to open the shortcuts list; the module found a palette already open and
refocused it instead; then the dismissal closed it. The command ran, succeeded, and
left nothing on screen.

`Command Palette` invoked from inside the palette had the same fate. Every other
command was unaffected, which is why the surface looked healthy.

**Fix.** The palette dismisses first and dispatches second, with both delegates
copied to locals because dismissing can destroy the widget. The ordering is stated
as a contract on `ChooseSelected` rather than left as an implementation detail.

Separately, `FNexusEditorUIModule::OpenCommandPalette` now only reuses an open
palette when it is in the *same* mode. Asking for the full list while the
shortcuts-only list is open replaces it rather than focusing the wrong one — the
same defect in quieter form.

**Guard.** `Nexus.V7.Command.PaletteCommitOrder` drives a real palette widget
through a commit and asserts the dismissal was observed before the dispatch.

### F-E3-02 — not one keyboard shortcut in the product could fire

**Symptom.** `Ctrl+Shift+P` did not open the palette.

**Cause.** No widget in `NexusEditorUI` ever called `ProcessCommandBindings`. The
chords were declared in the catalog, carried on real `FUICommandInfo` objects, and
mapped into the module's `FUICommandList` with execute and can-execute actions — and
then nothing routed a key event into that list. All eleven chords were dead, not
just the one the user pressed.

This is the more serious of the two, because `Nexus.V7.Command.Shortcuts` passes
against it. That test asserts the chords are declared, unique, correctly scoped, and
that Slate's `FUICommandInfo` set carries exactly what the catalog declares. Every
one of those assertions was true. None of them asks whether pressing the key does
anything, which is the difference between a shortcut and a table entry.

**Fix.** `SNexusShellSurface` now overrides `OnKeyDown` and routes the event into
its command list, and reports `SupportsKeyboardFocus`. The tab focuses the surface
when it is activated, because a surface that never holds focus never sees a key.

Routing at the surface rather than registering globally is what makes the chords
tab-scoped, which section 16.1 requires: they fire inside a Nexus tab and nowhere
else. An unbound key returns `Unhandled` and bubbles out, so the shell does not eat
editor shortcuts while it has focus.

**Guard.** `Nexus.V7.Command.ChordRouting` sends every catalog chord to a real
surface and asserts each one reaches a command list. The binding it uses is its own,
so nothing executes for real; what is under test is reachability. It also asserts
the count is eleven, so a chord added later is covered by the same loop rather than
quietly uncovered.

### F-E3-03 — the F-E3-02 fix crashed the editor, and this record was wrong for an hour

**Symptom.** `EXCEPTION_STACK_OVERFLOW` on clicking Refresh. Four editor processes
died this way.

**Cause.** Mine, introduced by the F-E3-02 fix and not by the original phase. To make
a tab-scoped chord reachable the moment a tab is activated, `SpawnSurfaceTab` hooked
`SDockTab::SetOnTabActivated` and called `SetKeyboardFocus` on the surface. That
recurses: `FSlateApplication::SetUserFocus` notifies the dock stack,
`SDockingTabStack::OnFocusChanging` calls `SDockTab::ActivateInParent`, and that
fires `OnTabActivated` again. The two called each other until the stack overflowed.

**Fix.** A re-entrancy guard, `bFocusingSurface`, set for the duration of the focus
call so the nested activation returns immediately. The callback also returns early
when the surface or a descendant already holds focus, which is the common case once
the user is working in the tab and which also stops it stealing focus from a control
they are typing in.

**What is *not* held.** There is no automated guard for this one, and the record
should say so rather than imply the fix is proven. The recursion needs a real dock
tab in a real window, which the `-NullRHI` automation environment does not have. What
was done instead: the full suite is green (64/64), and the editor was launched with
the fixed build, reached `Engine is initialized`, and ran for 150 s with zero
`EXCEPTION_`, `Fatal error`, or `Assertion failed` lines in
`SmokeTest-FocusGuard-2026-08-23.log`. That covers startup and tab spawning. It does
**not** cover the click path that produced the crash, so **E3 run 2 owns this**:
switch tabs repeatedly and click Refresh from every surface.

**What it says about the record.** Between the F-E3-02 fix and this one, this
document claimed both E3 defects were fixed and verified, on a build that crashed on
the first Refresh. E1 and E2 were green the whole time. That is the same lesson as
[[declared-is-not-reachable]] arriving a second time in one day: a green suite over a
build nobody has run is a statement about the suite.

## Environment

- Unreal Engine 5.8.1, `C:\Program Files\Epic Games\UE_5.8`.
- Visual Studio 14.44.35228 toolchain, Windows 10.0.26100.0 SDK.
- Windows 10 Pro 19045, 16 physical cores, 61.6 GB.
- Gate script: `Scripts/VerifyPhase04Commands.ps1`, run as `-RunLabel 2026-08-23`
  for the first review candidate and re-run as `-RunLabel 2026-08-23-e3fix` after the
  two E3 run-1 fixes. Both runs are retained.

## E1 — Clean builds

Every target was built with `-clean` first, so none of these reused an object file.
The table is the `-RunLabel 2026-08-23-e3fix` re-run, taken after the two E3 run-1
fixes; the original review candidate built the same three targets clean and also
passed.

| Target | Configuration | Result |
|---|---|---|
| `NexusFrameworkEditor` | Win64 Development | PASS |
| `NexusFramework` | Win64 Development | PASS |
| `NexusFramework` | Win64 Shipping | PASS |

Phase 04's own gate needs only the editor build. The two non-editor targets are
built because this phase added two public headers to `NexusEditor` and six sources
to `NexusEditorUI`, and an editor-only module leaking into a packaged target has to
fail here rather than at Phase 18. It did not: `Nexus.V7.Module.RuntimeBoundary`
and the clean Shipping link both still pass.

## E2 — Automation

Command run by the script:

```
UnrealEditor-Cmd.exe NexusFramework.uproject -unattended -nop4 -nosplash -NullRHI
  -nosound -ExecCmds="Automation RunTests Nexus.V7.Command+Nexus.V7.Shell+Nexus.V7.Module+Nexus.V7.Foundation; Quit"
  -TestExit="Automation Test Queue Empty" -log=Automation-Phase04-Commands-2026-08-23.log
```

Observed in `Automation-Phase04-Commands-2026-08-23-e3fix.log`, the run taken after
the two E3 run-1 fixes over three fresh clean builds:

- 64 results, all `Result={Success}`; 0 non-success results.
- 17 `Nexus.V7.Command` (this phase), 14 `Nexus.V7.Shell` (Phase 03), 12
  `Nexus.V7.Module` (Phase 02), 21 `Nexus.V7.Foundation` (Phase 01).
- Zero `LogAutomationController: Warning:` and zero `LogAutomationController: Error:`
  lines.
- Suite wall time 2.34 s, from the first `Test Started` at `06.53.07:166` to
  `**** TEST COMPLETE. EXIT CODE: 0 ****` at `06.53.09:502`.
- Editor process exit code 0.

The first review candidate's run, `Automation-Phase04-Commands-2026-08-23.log`, is
retained: 62 results, all Success, 15 command tests. The difference is the two guards
added for F-E3-01 and F-E3-02.

The script does not treat a zero exit code as sufficient. It fails if the log
contains no results at all, if the completion marker is absent, if any result is
non-success, or if any of the four suites returns fewer results than its recorded
count — the last of these because a renamed test category would otherwise turn into
silent loss of coverage while still exiting zero.

### What the seventeen command tests hold

| Test | What it holds |
|---|---|
| `CatalogIntegrity` | Every command has a namespaced id, a label no other command uses, a description that is not its own label, and an owning phase in range; ids are unique; every palette category and every menu group is populated; cancellation is offered only by commands long enough to need it and always by ones long enough to require it; a chord implies a scope and no chord implies none. Also that Phase 02's `NexusEditorCommandNames::InitializeDocument` and the catalog's name are the same address. |
| `InventoryCoverage` | All 44 commands V7-UX-SPEC.md section 6.1 names are present, asserted as a literal list rather than derived from the catalog, plus the Window submenu's ten entries in section 3.1's exact order. |
| `Shortcuts` | No two commands claim one chord in one scope; the eleven section 16.1 defaults are bound to exactly their specified chords, are tab-scoped, and name keys this build knows; no global chord takes an editor-reserved one. |
| `IconsResolve` | Every icon the catalog names resolves in the application style set, so a named-but-missing icon fails here rather than rendering as a checkerboard in a menu. |
| `Registration` | Registering twice fails, a non-owner cannot unregister, unregistering twice is refused, an empty name is refused, an unknown command returns a blocking result rather than asserting, filling pending-phase handlers leaves a real handler its slot and is idempotent, and removing them takes back exactly what filling added. |
| `DisabledReasons` | Every command owned by a later phase refuses with the not-yet-delivered code and names that phase in its message; a handler that refuses without a reason still produces a blocking result, never runs, and is recorded as Blocked with a message. |
| `DestructiveConfirmation` | A destructive command is refused without an approval, with the wrong command's approval, and with an approval computed against a stale revision; a matching approval lets it through; a destructive command that cannot preview itself is refused rather than allowed through unpreviewed; every delivered destructive command is registered. |
| `ProgressAndCancellation` | A thousand progress reports leave one entry with a count of a thousand; a report after completion is refused; an uncancellable operation refuses cancellation; `ShouldStop` is false inside an atomic section and true outside it, with the section stating its reason; a reporting command produces exactly one entry that becomes the finished one. |
| `OperationHistory` | Newest-first ordering, all six outcomes representable, Clear Completed keeping running, blocking, and recovery entries, the 500-entry cap, the cap never discarding an unresolved entry, four filter dimensions, and recency that excludes failures and collapses duplicates to their newest use. |
| `HistoryExport` | An exported entry carries its command, revision, and target; the project path is labelled rather than pasted bare; token and password values are removed entirely with the surrounding text intact; the unresolved export includes failures and excludes settled entries; exporting an unknown id returns nothing rather than asserting. |
| `RoutingParity` | The same command from four surfaces produces four identical successes, reaches one handler, records the invoking surface without behaving differently, and produces one Activity entry each; a refusal gives the identical reason from every surface. |
| `ScriptedInvocation` | Every catalog command is registered in the live process registry, answers `CanExecute` with no document present, gives a non-empty reason when it refuses, and has a display name; the thirteen commands the shell owns are real handlers rather than pending-phase fillers. |
| `PaletteSearch` | An empty query lists every command grouped under one heading per category; recents lead only when the query is empty and never contain a destructive command; fuzzy matching works across label, synonym, and full id; the best label match ranks first; a non-matching query returns nothing; the same query always produces the same order; shortcut-only mode shows only bound commands; every row has a label and a group, and every disabled row has a reason. |
| `SurfaceParity` | Toolbar, context menu, and Window submenu list only catalog commands with no duplicates; the palette lists every catalog command; Slate binds exactly the catalog, and every Slate chord is the chord the catalog declares. |
| `ActivityScopes` | All six Activity scopes have a name, an empty-state headline, and an explanation that is not the headline repeated; the six scopes separate running, blocking, recovery, finished, and advisory entries correctly and combine with a text filter. |
| `PaletteCommitOrder` | Committing a row on a real palette widget dismisses the palette **before** it dispatches the command, so a command that opens a surface of its own is not closed by the commit that ran it; the highlighted row is the one that runs; and Show Keyboard Shortcuts is present and enabled, since the palette is the only surface that offers it. Guards F-E3-01. |
| `ChordRouting` | Every one of the eleven catalog chords, sent as a key event to a real shell surface, reaches a command list; the loop asserts it covered eleven, so a chord added later cannot be silently uncovered; and a command with no chord routes nothing, so no pass is vacuous. Guards F-E3-02. |

## Three design decisions are what make the above testable

**The catalog is data, and every surface is generated from it.** `NexusCommandCatalog`
holds 63 commands as a table: id, label, description, category, menu group, icon,
chord, scope, synonyms, risk, expected duration, and owning phase. The Window
submenu, the toolbar, context menus, the palette, and the Slate `FUICommandInfo`
set are all built by reading it. Section 6.3's requirement that every surface map
to the same command ids is therefore checkable by comparing each surface against
one table, rather than by comparing two hand-written lists that drift.

Phase 03's eight hand-written `TCommands` entries were deleted rather than kept
alongside. A second list is exactly how a menu entry and a palette entry come to
advertise different shortcuts for one command.

**The confirmation gate lives in the service, not in the UI.** A command declares
itself destructive in the catalog; `FNexusCommandService` then refuses to execute
it unless the invocation carries an approval whose command id, preview token, and
**document revision** all match a preview the service itself minted. A surface that
forgets to ask does not get a second chance to be wrong, and an approval computed
against a document that has since changed is refused rather than honoured — which
is the difference between a confirmation and a formality.

A destructive command that cannot describe what it would change is refused for
that reason alone, so "we forgot to write the preview" is a failing test rather
than a silently unguarded delete.

**Every unbuilt command is registered and refuses by name.** Sixty-three commands
are catalogued; this build implements the twenty-four it owns and fills the rest
with `FNexusPendingPhaseCommandHandler`, which refuses with
`Nexus.Command.NotYetDelivered` and a message naming the delivering phase. The
whole command surface is therefore discoverable, and no part of it can be offered
without either working or saying when it will. This is the Phase 03 defect —
a button wired to a command that could only ever fail — made structurally
impossible at the scale of the full inventory.

## A decision that binds later phases: confirmation is inline, not modal

V7-UX-SPEC.md section 15 permits a modal dialog for destructive confirmation.
`Nexus.V7.Shell.NotificationsAreNonModal`, which Phase 03 froze, forbids every
modal API in `NexusEditorUI`. Both cannot be satisfied by a modal.

Phase 04 confirms inline: `SNexusConfirmationBar` is a region of the surface,
directly under the toolbar that can raise it, showing the consequence, the affected
count, and a named verb rather than a generic OK. The safe control comes first and
takes keyboard focus, so a user who presses Enter without reading does not run the
command. The section 15 rules a modal exists to satisfy — clear title, consequence,
primary action, safe default, keyboard focus — are all met, and the confirmation
cannot be lost behind another window or steal input from the editor.

Recorded in `V7-ARCHITECTURE.md` §7 so Phases 05–20 inherit the decision rather
than rediscovering the conflict.

## Eight guards were proven to fail

A guard that has never been seen to fail is an assumption. These were broken on
purpose, built, and run; each failed by name while the rest passed. All three runs
were retained.

**Run 1 — four independent breaks, five attributable failures.**
`Automation-Phase04-Commands-2026-08-23-negative.log`.

| Break | Test(s) that failed |
|---|---|
| `Nexus.Operation.Refresh` given `Ctrl+F`, already claimed by `Nexus.Search.Focus` | `Nexus.V7.Command.Shortcuts` **and** `Nexus.V7.Command.SurfaceParity` |
| The destructive confirmation gate returning true when no approval is held | `Nexus.V7.Command.DestructiveConfirmation` |
| The pending-phase handler's refusal no longer naming its delivering phase | `Nexus.V7.Command.DisabledReasons` |
| `ClearCompleted` removing every entry rather than keeping unresolved ones | `Nexus.V7.Command.OperationHistory` |

The duplicate chord failing two tests is not a loss of attribution but a second
independent detection of the same defect: the conflict detector caught it in the
catalog, and Slate's input binding manager refused the second claim, so
`SurfaceParity` observed the command's actual chord come back empty against a
catalog that said `Ctrl+F`. The log records both messages by name. The other ten
tests passed in that run.

**Run 2 — two breaks in the UI layer.**
`Automation-Phase04-Commands-2026-08-23-negative-surfaces.log`.

| Break | Test that failed |
|---|---|
| The toolbar list naming `Nexus.Toolbar.NegativeProofCommand`, which is not in the catalog | `Nexus.V7.Command.SurfaceParity` |
| The palette's recency block no longer excluding destructive commands | `Nexus.V7.Command.PaletteSearch` |

The other thirteen tests passed. All six breaks were reverted and the editor was
rebuilt from the restored source; a `NegativeProof` scan over the plugin's Source
tree returns nothing.

**Run 3 — the two E3 fixes, broken independently.**
`Automation-Phase04-ChordFix-2026-08-23-negative.log`.

| Break | Test that failed |
|---|---|
| `SNexusShellSurface::OnKeyDown` returning `Unhandled` without consulting the command list, which is exactly the state F-E3-02 was found in | `Nexus.V7.Command.ChordRouting` |
| The palette dispatching before dismissing, which is exactly the state F-E3-01 was found in | `Nexus.V7.Command.PaletteCommitOrder` |

The other fifteen passed. `ChordRouting` named each dead chord individually —
`Nexus.View.CommandPalette fires from a Nexus surface when Ctrl+Shift+P is pressed`
was the first of eleven — so the failure output says which shortcuts are unreachable
rather than only that something is wrong. Both breaks were reverted, the editor was
rebuilt from the restored source, and the full suite returned 64/64.

## Progress, cancellation, and the atomic-section rule

Section 15 sets four feedback bands by expected duration, and the catalog records
which band each command is in. The service reads that: a command declared `Long` or
`Extended` opens its Activity entry with a progress fraction rather than an
indeterminate one, and only an `Extended` command may declare `bSupportsCancel`.
`CatalogIntegrity` asserts both directions of that rule, so a command cannot claim
cancellation it is too short to need or omit it when it is long enough to owe it.

Cancellation is cooperative and bounded. `FNexusCommandProgress::ShouldStop` returns
false inside an atomic section regardless of what the user asked for, so a command
that checks it at every loop iteration physically cannot abandon a half-applied
mutation. The section carries the reason it is atomic, which is what section 17.5's
"cancellation unavailable during atomic section with explanation" state renders.

Coalescing is likewise structural rather than a convention: `ReportProgress`
mutates the running entry in place and increments a counter. A thousand reports
leave one entry with a count of a thousand, which is what `ProgressAndCancellation`
asserts. A report arriving after completion is refused, so a stale operation cannot
rewrite a record the user has already been shown.

## Activity

The Activity surface renders `FNexusOperationHistory` as one filterable list with
six scopes, which is what section 14.1 asks for: Running, Blocking, Warnings,
History, and Recovery exist as filters rather than as five panels, so a running
operation and the failure it produced are one keystroke apart.

Which entries a scope shows is decided in `NexusOperationHistory.h` beside the
record, not in the widget. That is what lets `ActivityScopes` assert the separation
without a window, and it means a second view added in a later phase gets the same
answer as the first.

Each entry carries timestamp, status, severity, command, actor, target summary,
duration, message, diagnostics, technical details, source revision, and transaction
title. Running entries carry a real fraction and phase text rather than a spinner,
and a Cancel control that is disabled with a stated reason when the operation
declared itself uncancellable.

Export is redacted: the project and engine directories are replaced with `<project>`
and `<engine>`, and anything spelled as a credential has its value removed entirely
rather than shortened. `HistoryExport` asserts the redaction and asserts that the
text around it survives, because an unreadable export is not a safe one.

## Accessibility and what is still manual

| Requirement | How it is held | Level |
|---|---|---|
| One implementation per command | `RoutingParity` over four surfaces; `SurfaceParity` comparing every surface to the catalog | E2 |
| Accurate availability and disabled reasons | `DisabledReasons`, `PaletteSearch`, `ScriptedInvocation`; the service supplies a reason when a handler refuses without one | E2 |
| Destructive commands take the confirmation path | `DestructiveConfirmation`, including the stale-revision case | E2 |
| Long commands expose progress and safe cancellation | `ProgressAndCancellation`, `CatalogIntegrity`'s duration/cancel rule | E2 |
| Palette and menu contents, order, and grouping | `InventoryCoverage`, `SurfaceParity`, `PaletteSearch` | E2 |
| Shortcut conflicts | `Shortcuts` against both other Nexus commands and the editor's reserved chords | E2 |
| Shortcuts actually fire | `ChordRouting` sends every catalog chord to a real surface. Added after F-E3-02; the phase shipped its first review candidate with all eleven dead | E2 |
| Icons resolve | `IconsResolve` against the live application style set | E2 |
| Not relying on colour alone | Destructive rows carry the words "confirms first"; Activity rows carry the status as a word | E2 |
| Menus and shortcuts understandable without external documentation | Every command has a one-sentence description shown as its tooltip, and `Show Keyboard Shortcuts` lists every bound chord | Partly **E3** |
| Discoverability in a live editor: menu placement, tooltip readability, palette keyboard flow | — | **E3** |

## Structural scan

`Scripts/VerifyFoundation.ps1` re-run after every source and document change:

```
FOUNDATION STRUCTURAL SCAN: PASS
Failures=0
Phase status mirrors - 01 Complete; 02 Complete; 03 Complete; 04 Ready for Review; 05-20 Not Started
```

That capture predates the acceptance. Re-run of the same script after Phase 04 was
accepted and this document closed out, 2026-08-23:

```
PASS: Phase status mirrors - 01 Complete; 02 Complete; 03 Complete; 04 Complete; 05 In Progress; 06 Not Started; ... 20 Not Started
Failures=0
FOUNDATION STRUCTURAL SCAN: PASS
```

## Acceptance gate

| Gate item | Status | Held by |
|---|---|---|
| A command has one implementation regardless of invocation surface | **Met** | `RoutingParity` runs the same command from four surfaces and asserts one handler, identical results, and identical refusal reasons. `SurfaceParity` asserts every surface is generated from the catalog. The invoking surface is recorded and never branched on. |
| All visible commands have accurate availability and disabled reasons | **Met** | `DisabledReasons` over every later-phase command, `ScriptedInvocation` over every catalog command, `PaletteSearch` over every palette row. The service supplies a reason when a handler refuses without one, so an unexplained disabled control cannot reach the screen. |
| Destructive commands require the approved preview/confirmation path | **Met** | `DestructiveConfirmation`: refused without approval, with a mismatched approval, with a stale-revision approval, and when the command cannot preview itself. The gate is in the service, so it applies to every surface and to automation. |
| Long commands expose progress and safe cancellation | **Met** | `ProgressAndCancellation` plus `CatalogIntegrity`'s duration rule. Cancellation is refused inside a declared atomic section, with the reason. |
| Menus and shortcuts are understandable without external documentation | **Met** | Held at E2 and by the user's E3 session. E2: every command carries a one-sentence description used as its tooltip, disabled entries append their refusal to it, `Show Keyboard Shortcuts` lists every bound chord from the catalog, and `ChordRouting` proves those chords fire. E3: run 1 stopped at checklist item 4 having found F-E3-01 and F-E3-02, both since fixed; the planned re-run from the top was not performed, and the user instead accepted the rebuilt editor as a whole. This item rests on that session acceptance, not on an itemised 11-of-11 pass — see [the manual checklist](phase-04-e3-manual-checklist-2026-08-23.md). |

## The E3 checklist

What a person needs to check, in the order the gate depends on it. Each item below
is expanded into steps, expected results, and pass/fail criteria in
[Phase 04 E3 manual test script](phase-04-e3-manual-checklist-2026-08-23.md):

1. `Window > Nexus Framework V7` lists exactly ten entries in the specified order.
2. Each entry does what its label says; invoking an open tab focuses it rather than
   duplicating it.
3. `Ctrl+Shift+P` opens the palette while a Nexus tab has focus, and does nothing
   while it does not.
4. In the palette: typing filters, Up and Down move the highlight past group
   headings, Enter runs the highlighted command, Escape closes and returns focus.
5. A disabled palette row shows its reason on the row, not only in a tooltip.
6. `Reset Nexus UI State` raises the inline confirmation rather than acting, the
   safe control has focus, and cancelling changes nothing.
7. Confirming it discards the saved layout and nothing else.
8. `Clear Completed History` keeps running, blocking, and recovery entries.
9. The Activity tab lists commands as they are run, with target, duration, and
   result; the scope buttons filter it.
10. Tooltips are readable and correctly placed at the desktop's own display scaling.
11. Closing the editor produces no error or warning on exit.

Items 3 through 11 are the ones this automation cannot reach.

## Artifacts

Every file below is in `Saved/Logs/`, identified by byte count and lowercase SHA-256
as V7-QUALITY-GATES.md section 2 requires.

| Artifact (`Saved/Logs/`) | Bytes | SHA-256 |
|---|---:|---|
| `UBT-Phase04-NexusFrameworkEditor-Win64-Development-2026-08-23.log` | 5,126 | `693c122985dae405ddf26b0bf81df1c4dc141fd89d442757dc62bb83ae511171` |
| `UBT-Phase04-NexusFramework-Win64-Development-2026-08-23.log` | 2,231 | `40620195b1f93123a61d2e6240e8407deda29219b2310bb852f56f85830984af` |
| `UBT-Phase04-NexusFramework-Win64-Shipping-2026-08-23.log` | 2,303 | `0240ccced61e4b2bb4a505060f5ce98d8902d3201bb2cd13615fa05877eb5d22` |
| `Automation-Phase04-Commands-2026-08-23.log` | 341,287 | `65af95c314490fecc65f4ebb68e164b3be793e713f9bfcf000a6d9179aa97546` |
| `Automation-Phase04-Commands-2026-08-23-negative.log` | 304,624 | `0c8e06321650709455932defa66a59eecf19d0bcc34bdfa5bde0f86046a9c0e7` |
| `Automation-Phase04-Commands-2026-08-23-negative-surfaces.log` | 291,287 | `6db94884739303793dd183c9728b90a42854c77b1d9bc736079665103bbe08ba` |
| `Foundation-Structural-Scan-Phase04-2026-08-23.log` | 1,420 | `a160c3a6022f6d4c265b5707875d7b8a15e026cdb0072e16e45e7816d3ce2173` |
| `Foundation-Structural-Scan-Phase04-Final-2026-08-23.log` | 1,425 | `7e8b34f9b21d6719017e84940c307680c21656a0a38c1a48e71378a38ebc7798` |

### Added by the E3 run-1 fixes — `-RunLabel 2026-08-23-e3fix`

The original run's artifacts above are retained unchanged; these are a second,
separately labelled run so nothing an earlier record cites by digest is overwritten.

| Artifact (`Saved/Logs/`) | Bytes | SHA-256 |
|---|---:|---|
| `UBT-Phase04-NexusFrameworkEditor-Win64-Development-2026-08-23-e3fix.log` | 4,367 | `9d4c20dd5dfc2ac2f038df105cfe034f98154465fef0a60da0c0ff3d1506247e` |
| `UBT-Phase04-NexusFramework-Win64-Development-2026-08-23-e3fix.log` | 2,421 | `431914183f91a6eb18d046319cba20a4b377fa74b32095929c8007d9f02ff15b` |
| `UBT-Phase04-NexusFramework-Win64-Shipping-2026-08-23-e3fix.log` | 2,303 | `4926ab3f24097cd701c116e9dcc1c53a7ecb42c9d9712ce1e8fb7236a74ce2c5` |
| `Automation-Phase04-Commands-2026-08-23-e3fix.log` | 343,176 | `ba539b1cda2ef3c0476df7419dcdb12c5d6a9185da21c825e01436e46e1bf1cc` |
| `Automation-Phase04-ChordFix-2026-08-23-negative.log` | 296,607 | `65fa299e76eb129e6777cd5d8b8f7b5172f7f662f15e81cb9651d05a8f2a7adc` |
| `Automation-Phase04-ChordFix-2026-08-23-restored.log` | 343,183 | `fcf370857580477a27a31c37ab5804e8ba53f2fd1972f1fb2b43b0e39dd11d3b` |

`Automation-Phase04-Commands-2026-08-23-e3fix.log` is the gate script's own run over
three fresh clean builds: 64 results, all Success, zero automation warnings and zero
automation errors, completion marker exit 0. `-restored` is the same suite run
directly after reverting the run-3 negative breaks, and matches it.

## Open items

1. **E3 closed on a session acceptance, not on an itemised pass.** Run 1 stopped at
   item 4 and found F-E3-01 and F-E3-02, both now fixed and guarded; F-E3-03 was
   introduced by the second fix and is fixed but unguarded. The planned re-run from
   the top was not performed: items 1 through 11 — the Window submenu, palette
   keyboard flow, disabled-row reasons, the inline confirmation, Clear Completed,
   Activity, tooltip placement at the desktop's own scaling, and a clean editor exit
   — were never reported back one by one. The user accepted the rebuilt editor as a
   whole and marked the phase Complete on that, which closed the fifth gate item.
   The eleven `Result:` fields in the checklist record this rather than claiming
   passes. Running items 1–11 on a current build is what would upgrade the record.
2. **Thirty-nine of the sixty-three commands are owned by a later phase.** They are
   registered, listed, and refuse by name with the phase that delivers them. This
   is deliberate — the palette is the place a user looks when they cannot find a
   command, and a palette that hides two thirds of the product would send them
   looking elsewhere. It is recorded so a reviewer does not read the inventory as
   a claim that all of it works.
3. **Undo and Redo call the editor's transaction system and keep no history of
   their own.** They are registered from `NexusEditor` rather than `NexusEditorUI`
   specifically so the UI module cannot reach the transactor; the module boundary
   test would fail if it tried.
4. **Nothing binds an authoring document from the editor yet.** Phase 07 owns that
   entry point per Phase 01 finding F-09, so every command needing a document
   refuses with a document-related reason during E3. That is correct behaviour and
   not a defect; `ScriptedInvocation` asserts each such refusal carries a reason.
5. **The context-menu framework has no rows to be summoned from yet.** Phase 04
   delivers the builder, its groups, its ordering, and its live tooltips; Phase 05
   delivers the tree rows that raise it. `SurfaceParity` covers the entries it
   would show.
6. **Phase 02's E0 was waived, not satisfied**, and that carries forward as context
   rather than as a Phase 04 finding. See `PHASE-STATUS.md`.
