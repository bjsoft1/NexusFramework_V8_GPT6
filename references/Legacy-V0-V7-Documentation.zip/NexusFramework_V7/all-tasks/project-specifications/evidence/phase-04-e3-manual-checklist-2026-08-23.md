# Phase 04 E3 — Manual Test Script — 2026-08-23

## What this closes

Phase 04 is **Complete** as of 2026-08-23. E1 (three clean builds) and E2 (64/64
automation tests) are green and recorded in
[Phase 04 command system](phase-04-commands-2026-08-23.md). The fifth acceptance-gate
item — *"Menus and shortcuts are understandable without external documentation"* —
could only be closed by a person at the editor, and it was: on a whole-session
acceptance, not on an itemised pass of this script.

This file is the script that was written for that pass. Items 1 and 2 are partly held
by automation and are re-checked here by eye; items 3–11 are the ones automation
cannot reach.

Run 1 was performed on 2026-08-23 and stopped at item 4 with two Blocking defects; a
third was introduced by the fix for the second. All three are fixed. Run 2 did not
restart from item 1 as this file plans —
[Run 2](#run-2--2026-08-23--closed-by-session-acceptance) records what closed the gate
instead, and what that does and does not cover.

## Run 1 — 2026-08-23 — stopped at item 4; three Blocking defects

The first attempt did not get past the keyboard. Two defects were found in the phase
and a third was introduced by the fix for the second. All three are fixed;
**the run has to start again from item 1 on the rebuilt editor.**

| Item | Result |
|---:|---|
| 3. `Ctrl+Shift+P` opens the palette | **FAIL** — F-E3-02 |
| 4. Palette keyboard flow | **FAIL** — F-E3-01, found via `Show Keyboard Shortcuts` |
| 1, 2, 5–11 | Not reached |

**F-E3-01 — the palette swallowed any command that opens a surface.** Choosing
`Show Keyboard Shortcuts` appeared to do nothing; the only trace was an Activity
entry saying it had succeeded. The palette dispatched the command and dismissed
itself *afterwards*, and since that command works by reopening the palette in
shortcuts-only mode, the dismissal closed the list the command had just opened.
Fixed: the palette dismisses before it dispatches. Guarded by
`Nexus.V7.Command.PaletteCommitOrder`.

**F-E3-02 — no keyboard shortcut in the product could fire.** `Ctrl+Shift+P` did
nothing, and neither did the other ten. The chords were declared in the catalog,
carried on real Slate command objects, and mapped into the module's command list —
and no widget ever routed a key event into that list. Fixed: the shell surface now
handles key input and routes it to its command list, and the tab gives the surface
focus when it is activated. Guarded by `Nexus.V7.Command.ChordRouting`, which sends
all eleven chords to a real surface and names each one that fails.

### F-E3-03 — the F-E3-02 fix crashed the editor on Refresh

Introduced by the fix above, not by the original phase, and found the same way: at
the editor. `EXCEPTION_STACK_OVERFLOW` on clicking Refresh, four editor processes
lost.

Making the surface take keyboard focus when its tab activates recurses — setting
focus makes the dock stack re-activate the tab, which sets focus again. Fixed with a
re-entrancy guard plus an early return when the surface already holds focus.

**This one has no automated guard**, and that is stated rather than papered over: the
recursion needs a real dock tab in a real window, which the headless automation
environment does not have. What was done instead — full suite 64/64, and the editor
launched on the fixed build, reached `Engine is initialized`, and ran 150 s with no
crash markers. That covers startup, not the click.

**So run 2 owns it.** While working through the checklist, deliberately: switch
between the three Nexus tabs repeatedly, click Refresh from each surface, and
click a Nexus tab header then immediately press `Ctrl+Shift+P`. If the editor is
going to overflow again, that is where it will happen.

Both guards were reinstated as defects, rebuilt, and seen to fail by name while the
other fifteen tests passed; then reverted, rebuilt, and the full suite returned
64/64 with zero warnings and zero errors.

**What this changes for run 2.** Item 3 is no longer a formality — it is the item
that failed. Try the chords for later-phase commands too (`F2`, `Delete`, `Insert`):
each should now refuse *by name*, where before they did nothing at all, and the
difference between those two is exactly what run 1 could not see.

## Run 2 — 2026-08-23 — closed by session acceptance

Run 2 was **not** performed as an itemised pass of the eleven checks below. The user
worked in the rebuilt editor and accepted the result — *"UI displaying good"* —
without reporting items 1–11 back one at a time.

Phase 04 was marked **Complete** on that basis, and per `V7-QUALITY-GATES.md` §1 that
decision is the user's alone to make. What the acceptance rests on, stated plainly so
that a reviewer does not read more into it than is there:

| Evidence | Standing |
|---|---|
| E1 — three clean builds | Recorded, green |
| E2 — 64/64 automation tests | Recorded, green |
| E3 — editor session on the rebuilt tree | Accepted by the user as a whole |
| E3 — items 1–11 individually | **Not reported back; no per-item PASS is claimed** |

`F-E3-03` needs its own line, because run 2 was written above as the run that owns
it. It still has **no automated guard** — the recursion needs a real dock tab in a
real window, which the headless environment does not have — and the tab-switch /
Refresh sequence prescribed above was not reported back either. It is recorded here
as **covered by the session not crashing**. That is weaker than a repro of the
sequence, and is deliberately not written up as one.

The eleven checks below are kept in full rather than struck out. They are the script
to run if this is ever to be upgraded from a session acceptance into an itemised
record, and each item's **Result:** field points back to this section rather than
claiming a pass it was not given.

## Before you start

- **No rebuild is needed.** The editor binaries in
  `Plugins/NexusFrameworkV7/Binaries/Win64/` were rebuilt on 2026-08-23 after the
  two run-1 fixes, and no source file is newer than them.
- Launch by opening `NexusFramework.uproject`, or from a shell:

  ```
  & "C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe" "e:\Projects\Game\UE\NexusFramework\NexusFramework_V7\NexusFramework.uproject"
  ```

- Keep the editor's Output Log open (`Window > Output Log`) for item 11.
- Run at your desktop's own display scaling — do not set it to 100% for the test.
  Item 10 exists specifically to check the scaling you actually work at.

## Read this first: four behaviours that are correct, not defects

A large share of what you will see is a command declining to run. These are the
designed Phase 04 result; reading them as bugs would fail the phase for doing the
right thing.

1. **39 of the 63 commands refuse by name.** This build implements the 24 it owns.
   Every other command is registered, listed, searchable, and refuses with a message
   naming the phase that delivers it — for example, Delete refusing because Phase 07
   delivers it. A command that refuses **with its phase named** is a pass. A command
   that refuses with a blank or generic reason, or that appears to do nothing at all,
   is a fail.
2. **Every command that needs a document refuses.** Nothing binds an authoring
   document from the editor yet; Phase 07 owns that entry point (Phase 01 finding
   F-09). So `Initialize Document`, `Save Document`, and similar refuse with a
   document-related reason. That is correct.
3. **The tree context menu has no rows to be summoned from.** Phase 04 delivers the
   context-menu builder and its groups; Phase 05 delivers the tree rows that raise
   it. There is nothing to right-click yet.
4. **The shell reports Empty.** Same cause as 2 — no document is bound. Phase 03 was
   accepted with this behaviour.

### The 24 commands this build actually implements

Open Home · Open Nexus Workspace · Open Default Workspace · Open Authoring Workspace ·
Open Review Workspace · Open Hierarchy · Open Details · Open Activity ·
Command Palette · Restore Last Workspace · Reset Nexus UI State ·
Initialize Document · Undo · Redo · Refresh · Retry Last Failed Operation ·
Cancel Operation · Copy Activity Entry · Copy Technical Details ·
Clear Completed History · Show Diagnostics · Copy Diagnostics ·
Show Keyboard Shortcuts · About Nexus Framework V7

Only one of the eleven bound shortcuts belongs to a delivered command:
**`Ctrl+Shift+P` → Command Palette**. The other ten (`Insert`, `F2`, `Ctrl+Enter`,
`Delete`, `F`, `Ctrl+A`, `Alt+Left`, `Alt+Right`, `Ctrl+Space`, `Ctrl+F`) are bound
to Phase 05/06/07/12 commands and must refuse **naming that phase** when pressed
inside a Nexus tab. That refusal is the thing being tested, not a shortcoming.

---

## The checks

### 1. The Window submenu lists exactly ten entries in the specified order

**Do:** open `Window > Nexus Framework V7`.

**Expect** four sections, ten entries, in this order and nothing else:

| Section | Entries |
|---|---|
| Open | Open Home |
| Workspaces | Open Default Workspace, Open Authoring Workspace, Open Review Workspace |
| Surfaces | Open Hierarchy, Open Details, Open Activity |
| Tools | Command Palette, Restore Last Workspace, Reset Nexus UI State |

**Fail if:** an entry is missing, an eleventh appears, the order differs, or the
Nexus tabs also appear loose in the generic `Window` list — they are hidden from it
on purpose, because this submenu is meant to be the one way in.

**Result:** Not reported individually — see [Run 2](#run-2--2026-08-23--closed-by-session-acceptance).

### 2. Each entry does what its label says; an open tab is focused, not duplicated

**Do:** invoke all ten in turn. Then invoke `Open Hierarchy` a second time while the
Hierarchy tab is already open; repeat for Details and Activity.

**Expect:** each opens or switches to the named surface. The second invocation
**focuses the existing tab**. Hover each entry and read its tooltip: one sentence
describing what the command does.

**Fail if:** a second tab of the same surface appears, an entry opens the wrong
surface, or a tooltip is empty or merely repeats the label.

**Result:** Not reported individually — see [Run 2](#run-2--2026-08-23--closed-by-session-acceptance).

### 3. `Ctrl+Shift+P` opens the palette in a Nexus tab, and does nothing outside one

**Do:** click inside a Nexus V7 tab and press `Ctrl+Shift+P`. Close it with `Escape`.
Now click into the level viewport or the Content Browser and press `Ctrl+Shift+P`
again. Finally, with the palette open, press the chord a second time.

**Expect:** the palette opens the first time. From the viewport nothing happens — the
chord is scoped to Nexus tabs and must not fire elsewhere. Pressing it while the
palette is already up focuses the open palette rather than stacking a second one.

**Fail if:** the chord fires from the viewport, a second palette stacks, or the chord
collides with an Unreal Editor default.

**Result:** Not reported individually — see [Run 2](#run-2--2026-08-23--closed-by-session-acceptance).

### 4. Palette keyboard flow: type, arrow, Enter, Escape

**Do:** open the palette and, without touching the mouse — type a few letters; press
`Down` and `Up` repeatedly, through and past a group heading; press `Enter` on a
highlighted command; reopen it and press `Escape`.

**Expect:** typing filters as you type. `Up`/`Down` move the highlight and **skip
over group headings** rather than stopping on them. `Enter` runs the highlighted
command. `Escape` closes the palette and returns keyboard focus to the surface you
came from. With an empty query the list shows every command grouped by category,
with recents leading.

**Fail if:** the highlight lands on a heading, `Enter` runs the wrong row, or focus
is lost after `Escape` — that is, the next keystroke goes nowhere.

**Result:** Not reported individually — see [Run 2](#run-2--2026-08-23--closed-by-session-acceptance).

### 5. A disabled palette row shows its reason on the row itself

**Do:** in the palette, type `delete`, then `generate`, then `validate`.

**Expect:** each row is visibly unavailable **and the reason is printed on the row**,
not hidden in a tooltip you have to hover for. The reason names the delivering phase.

**Fail if:** a row is greyed with no visible reason, or the reason appears only on
hover.

**Result:** Not reported individually — see [Run 2](#run-2--2026-08-23--closed-by-session-acceptance).

### 6. `Reset Nexus UI State` confirms inline, safe control first, cancel is a no-op

**Do:** arrange the workspace so you would notice it changing — open two or three
tabs, resize a region. Invoke `Window > Nexus Framework V7 > Reset Nexus UI State`.
Do not click anything: look at it, then press `Enter` without moving the mouse.

**Expect:** a confirmation bar appears **inside the surface, directly under the
toolbar** — not a modal dialog, not a separate window. It states what will be
discarded (the saved workspace, N open surfaces, the Home setting, the
recent-document list), says no document data changes, and offers a named verb rather
than a generic OK. The **safe control holds keyboard focus**, so pressing `Enter`
blind cancels. After cancelling, the workspace is exactly as it was.

**Fail if:** a modal dialog appears, the destructive control has focus, the bar can
be lost behind another window, or cancelling changed anything.

**Result:** Not reported individually — see [Run 2](#run-2--2026-08-23--closed-by-session-acceptance).

### 7. Confirming the reset discards the saved layout and nothing else

**Do:** invoke it again and confirm this time.

**Expect:** the shell returns to its default arrangement, and the recent-document
list and Home setting are cleared. **No project asset, no content, and no
editor-wide setting changes.** Check the Content Browser is untouched.

**Fail if:** anything outside the Nexus workspace state changed.

**Result:** Not reported individually — see [Run 2](#run-2--2026-08-23--closed-by-session-acceptance).

### 8. `Clear Completed History` keeps running, blocking, and recovery entries

**Do:** open the Activity tab. Run several commands so history has entries — mix
successes (`Refresh`, `Open Details`) with refusals (`Delete`, `Save Document`). Then
run `Clear Completed History` from the palette.

**Expect:** finished, successful entries are removed. **Failures, blocking entries,
and anything offering a recovery action remain.** This is the difference between
"clear completed" and "clear everything"; it is one of the six defects automation was
proven to catch, and it is worth confirming by eye.

**Fail if:** the list empties completely, or an unresolved entry disappears.

**Result:** Not reported individually — see [Run 2](#run-2--2026-08-23--closed-by-session-acceptance).

### 9. Activity lists commands as they run, with target, duration and result; scopes filter

**Do:** with the Activity tab open, run commands from three different surfaces — the
Window submenu, the toolbar, and the palette. Then click each scope button in turn.

**Expect:** one entry per invocation, newest first, each carrying its command name,
target summary, duration, result, and the surface that invoked it. The same command
run from three surfaces produces three identical-looking results — no surface behaves
differently. The six scope buttons filter the one list rather than opening separate
panels, and each empty scope shows a headline and an explanation rather than a blank
area.

**Fail if:** an invocation produces no entry or two entries, results differ by
surface, a scope shows the wrong entries, or an empty scope is blank.

**Result:** Not reported individually — see [Run 2](#run-2--2026-08-23--closed-by-session-acceptance).

### 10. Tooltips are readable and correctly placed at your desktop's own scaling

**Do:** at your normal display scaling, hover a Window submenu entry, each of the four
toolbar buttons (Command Palette, Refresh, Validate Document, Show Diagnostics), and
a disabled palette row.

**Expect:** the tooltip is legible, is not clipped, does not run off-screen, and does
not cover the thing it describes. A disabled entry's tooltip shows the description
**and** appends `Unavailable: <reason>`.

**Then run `Show Keyboard Shortcuts`** from the palette. It must list every bound
chord, read from the catalog rather than from a document. Cross-check three of them
against what the menus advertise for the same commands — they must agree.

**Fail if:** any tooltip clips, is unreadable at your scaling, or advertises a chord
the shortcut list disagrees with.

**Result:** Not reported individually — see [Run 2](#run-2--2026-08-23--closed-by-session-acceptance).

### 11. Closing the editor produces no error or warning on exit

**Do:** with several Nexus tabs open, close the editor normally. Read the tail of the
Output Log, and the newest file in `Saved/Logs/`.

**Expect:** a clean exit. No assertion, no crash reporter, and no `Error:` or
`Warning:` line attributable to a `Nexus` module during shutdown.

**Fail if:** shutdown logs a Nexus error or warning, or the process does not exit.

**Result:** Not reported individually — see [Run 2](#run-2--2026-08-23--closed-by-session-acceptance).

---

## Also worth doing, though no gate depends on it

- **Restart and reopen.** Phase 03's gate covered layout survival, but Phase 04 added
  recents and palette state. Reopening should restore what you left.
- **Run one command from all four surfaces** — Window submenu, toolbar, palette, and
  shortcut — and confirm the Activity entries are indistinguishable except for the
  recorded surface. This is `RoutingParity` at E2; seeing it is worth two minutes.

## The evidence record's six open items, and which of them you can test

| Open item | Testable here? |
|---|---|
| 1. E3 has not been performed | **Yes — this document is it.** Items 1–11. |
| 2. 39 of 63 commands are owned by a later phase | Partly — items 3 and 5 confirm each refuses *by name*. That they are unbuilt is by design. |
| 3. Undo/Redo use the editor transactor and keep no history of their own | No. Held by the module-boundary test; there is nothing to undo until Phase 07 binds a document. |
| 4. Nothing binds an authoring document yet | No. Phase 07 owns it (F-09). Its visible effect is the refusals in item 5. |
| 5. The context-menu framework has no rows to summon it from | No. Phase 05 delivers the tree rows. |
| 6. Phase 02's E0 was waived | No. Context carried forward, not a Phase 04 finding. |

## After the run

*Retained as written. This is the procedure if the eleven items are ever run
properly; it is not what happened. The outcome follows it.*

Report each item as PASS or FAIL with what you saw. Failures are recorded and fixed
before the phase moves; passes are written into `phase-04-commands-2026-08-23.md` as
the E3 record, and the acceptance gate's fifth item moves from **Half met** to
**Met**.

Per `V7-QUALITY-GATES.md`, only you can then mark Phase 04 **Complete** in
`PHASE-STATUS.md`. Phase 05 lists *"Phase 04 Complete"* as a hard dependency, so that
decision is what unblocks the Hierarchy Tree View.

### Outcome — 2026-08-23

The eleven items were **not** reported back individually. The user accepted the
rebuilt editor as a whole, Phase 04 was marked **Complete** on that decision, the
gate's fifth item was checked, and Phase 05 was unblocked on that basis.

Upgrading this into an itemised record means running items 1–11 from the top on a
current build and replacing each **Result:** line with what was seen. Until then the
per-item fields point at
[Run 2](#run-2--2026-08-23--closed-by-session-acceptance) and claim nothing.
