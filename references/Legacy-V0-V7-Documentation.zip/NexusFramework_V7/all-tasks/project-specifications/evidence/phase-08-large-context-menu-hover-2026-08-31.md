# Phase 08 — large-hierarchy context-menu hover lag (2026-08-31)

Implementation record for the severe row-menu lag reported after
`Nexus.Fixture.LoadSample Large 808`. Phase 08 remains **In Progress**. The latest
source has not built and the updated regression has not run because the local
`dotnet.exe` application error prevents UnrealBuildTool from starting. This record
is therefore not E1, E2, E3, or phase acceptance.

## How to Test After the Latest Source Builds

1. Open **Window > Nexus Framework V7 > Open Default Workspace** and show the
   **Hierarchy** tree → the Nexus row menu is available.
2. Enter `Nexus.Fixture.LoadSample Large 808` in the editor console and wait for the
   ten collapsed State roots → fixture construction finishes before interaction is
   judged.
3. Right-click **State 01** → the row menu opens promptly without a document-sized
   pause.
4. Move the pointer repeatedly across **Duplicate**, **Revert Draft**, **Delete**,
   and the Context entries for ten seconds → highlighting and tooltips stay smooth.
5. Press **Escape**, select **State 02**, and reopen the row menu → enabled states
   and disabled reasons are recalculated for the new selection.
6. Enter `Nexus.Fixture.Clear` in the editor console → the synthetic document is
   removed and the normal empty state returns.

## Cause

Every row-menu command uses the shared command list, whose live `CanExecute` is
polled by Slate while a menu is painted. The hovered entry's bound tooltip also
queries the same path. For a destructive command, `CanInitiate` previously called
`BuildPreview` merely to decide whether the command could start.

For Delete on a Large State, that preview constructs the complete cascade impact,
scans the 100,000-record document, and formats thousands of affected-item lines.
Pointer movement repaints the menu, so the full preview was built and discarded
again and again even though Delete had not been clicked. Virtualized hierarchy rows
cannot protect work performed by command eligibility.

## Correction

- `INexusCommandHandler::SupportsPreview` is a cheap capability query, defaulting to
  false so a destructive handler cannot accidentally become unguarded.
- The Authoring, Details, and shell delegate wrappers report support only when their
  preview delegate is bound.
- `CanInitiate` still runs the live ordinary guard and still returns the exact
  disabled reason, but checks only preview capability for destructive commands.
- `RequestConfirmation` remains the one place that builds the actual preview after
  a click, from a fresh command context.
- A matching approval still makes the backend verify that the preview implementation
  succeeds for the current context. That happens after cheap command/token/revision
  checks and never during menu paint.

No command result or mutation route is cached. UX specification section 6.3 remains
true: eligibility is queried live and the backend repeats validation at execution.
Only pre-click consequence materialization was removed from Slate paint.

## Added regression coverage (not yet run)

`Nexus.V7.Command.DestructiveConfirmation` now polls destructive initiation 128
times through an isolated counting handler and requires zero preview builds. An
explicit `BuildPreview` must increment the count exactly once; unapproved
eligibility must not increment it. Approved backend checks deliberately verify the
current preview again. A destructive handler with no preview capability remains
disabled with `Nexus.Command.PreviewUnavailable` and receives no preview call, while
a state-dependent preview that advertises support but returns false is refused after
approval.

Focused automation after a successful latest build:

    Automation RunTests Nexus.V7.Command.DestructiveConfirmation

Expected result: the test completes with zero errors and zero warnings. Full Phase
08 E2 remains the separate gate:

    powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1 -SkipBuilds

## Verification state

Static `git diff --check` passes with only line-ending conversion notices. No build
or automation command was retried for this record because the known `dotnet.exe`
failure would not produce meaningful UnrealBuildTool evidence.
