# Phase 08 — F-08-17, Undo/Redo scoped to what it actually changed (2026-09-02)

Implementing-agent evidence. This is not an acceptance record. Phase 08 remains In
Progress: its dependency is unmet, E3 has not run, and F-08-06 and F-08-15 still need
a user decision.

## What this closes

[The E0 independent review](phase-08-e0-independent-review-2026-09-02.md) filed
**E0-01, Blocking**: Undo and Redo silently discarded every unsaved Details edit in
the document, including parked "kept" drafts that had nothing to do with the
transaction being undone — the same defect shape F-08-16 had just fixed in
`Revert()`, still present in a far more common, ungated path. This closes it as
**F-08-17**.

## F-08-17 — Undo/Redo discarded unrelated drafts — fixed

**Blocking, fixed.** `UNexusEditorSubsystem::RefreshAfterUndo` — scheduled after
every successful Undo or Redo — called `Repository.RebuildIndex()`,
`Repository.NotifyChanged(Hierarchy, {})`, **and then** a separate
`FNexusDetailsView::Get().ReloadFromSource()`. `NotifyChanged` alone already
broadcasts synchronously to `FNexusDetailsView::HandleRepositoryChanged`, which parks
any dirty currently-selected draft into `KeptDrafts` and reclaims it while
rebuilding — the same machinery every other repository-driven refresh in the product
relies on, including staleness detection. The second call, `ReloadFromSource()`,
unconditionally resets `KeptDrafts` with no park-and-reclaim step of its own,
discarding every unrelated parked draft in the document and the draft the first call
had just reclaimed, on every single undo or redo, regardless of what the
undone/redone transaction actually touched.

**Fix.** Deleted the redundant `ReloadFromSource()` call. `Repository.NotifyChanged`
is sufficient on its own — this is not a new mechanism, it is the one every other
refresh path already uses. `ReloadFromSource()` itself is untouched and keeps its own
existing unit tests; it is simply no longer called from this one site. See
`Plugins/NexusFrameworkV7/Source/NexusEditor/Private/NexusEditorSubsystem.cpp`,
`RefreshAfterUndo()`.

## A live Slate widget made the first version of the regression test fail for a reason that had nothing to do with the fix

The new regression test, `Nexus.V7.Crud.UndoPreservesDrafts`, failed twice before it
correctly proved the fix — both times for reasons in the *test*, not the production
code, found by re-running rather than trusting either the code or the first failure.

**First failure.** The test set selection by calling `FNexusDetailsView::Get().SetSelection(...)`
directly. Temporary diagnostic logging (`UE_LOG` at `HandleRepositoryChanged`,
`RebuildTargets`'s reclaim branch, and `SetSelection`'s entry, all removed once the
cause was confirmed) showed the park-and-reclaim inside `RefreshAfterUndo` succeeding
exactly as designed — and then, a few log lines later, `SetSelection` being called
again with an **empty** array, undoing it. A captured stack trace
(`FPlatformStackWalk::StackWalkAndDump`) named the caller precisely:

    FNexusCrudUndoPreservesDraftsTest::RunTest
     -> UNexusEditorSubsystem::RefreshAfterUndo
      -> Repository.OnChanged() broadcast
       -> FNexusHierarchyView::Refresh
        -> FNexusHierarchyView::OnChanged() broadcast
         -> SNexusHierarchyTree::Refresh
          -> SNexusHierarchyTree::PushSelectionToEditor
           -> UNexusEditorSubsystem::SetSelection (with the tree widget's own, unrelated selection)
            -> FNexusDetailsView::Get().SetSelection (now empty)

A real `SNexusHierarchyTree` widget is alive in this editor process — most likely
from workspace/layout restoration at `UnrealEditor-Cmd.exe` startup, which can
construct real Slate widgets under `-NullRHI -unattended` even though nothing is
rendered — and it shares the process-global `FNexusHierarchyView::Get()` singleton
with the test. When the test's own `RefreshAfterUndo()` broadcasts a Hierarchy hint
on the real repository, that widget's `Refresh()` reacts by pushing *its own* Slate
tree selection (empty — it was never told about this test's cities) back onto the
subsystem, which propagates into Details and clobbers the very state the test is
checking. This is not a new defect; it is a pre-existing, generally-latent property
of running automation against a real editor process, and other tests in this suite
that touch the same repository (`Nexus.V7.Crud.DeleteRefreshesViews`, for one) are
equally exposed to it — they simply do not assert on post-broadcast selection/draft
state, so it stays invisible to them.

**Second failure, same root cause.** Routing selection through
`Subsystem->SetSingleSelection(...)` instead of `Details.SetSelection(...)` directly
was not sufficient: `SNexusHierarchyTree::PushSelectionToEditor()` reads
`FNexusHierarchyView::Get()`'s *own* `FNexusSelectionModel`, which the subsystem's
selection setters never touch, so the same interference recurred regardless of which
API the test called.

**Fix, in the test only.** `FNexusHierarchyView::Get().BindRepository(nullptr)` for
the duration of the test, rebound to `&Subsystem->GetRepository()` — exactly what
`UNexusEditorSubsystem::Initialize` leaves it as — via `ON_SCOPE_EXIT`, so a real tab
resumes seeing the live repository once the test finishes. No production code changed
for this correction.

**Verified by re-running, not by inspection**, per `[[verify-claims-by-re-running]]`,
at every step: the isolated test
(`-ExecCmds="Automation RunTests Nexus.V7.Crud.UndoPreservesDrafts; Quit"`) failed
twice with the exact symptoms above, confirmed via diagnostic logging and a captured
callstack rather than assumed; then passed cleanly once the view was detached; then
the full clean gate was re-run once more to confirm nothing else regressed.

## Commands and results

    powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1

- `PASS: clean build NexusFrameworkEditor-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Shipping`
- Suite counts: Hierarchy 17, UiStates 5, Module 12, Details 28, Foundation 21,
  UiGate 10, Command 17, Crud 23, Shell 20.
- `PASS: 157 tests, 0 failures`
- `PASS: 21 budget measurements, 0 over`
- `PHASE 08 E1+E2: PASS`

Crud's count moves from 22 (the F-08-16 pass) to 23 — exactly the one test this fix
added, `Nexus.V7.Crud.UndoPreservesDrafts`. No other suite's count moved.

Budget artifact: `Saved/NexusV7/Phase08/ui-budgets-2026-09-02-114854.txt`, 1,011
bytes, SHA-256
`40263C80551B3482C6491BD705EC215252F5E2D68B7F7626EFE1353C2A4E8B9A`.

## What remains

E3 has not run. F-08-06 and F-08-15 still need the user's reading. E0-02 (the
Activity-summary fix reaches only destructive commands) and E0-03 (Home's stale
onboarding badges) from the same independent review are recorded but not yet acted
on — they were left for a separate decision. This pass does not by itself move Phase
08 or any earlier phase's status.
