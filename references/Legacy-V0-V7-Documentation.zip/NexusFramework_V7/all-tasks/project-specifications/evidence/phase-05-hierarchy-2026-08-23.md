# Phase 05 Hierarchy Tree View Evidence — 2026-08-23

## Verdict

**Ready for Review — not Complete.** E1 and E2 are green on a clean tree. E3 has not
been run; two of the five acceptance-gate items depend on it, and per
`V7-QUALITY-GATES.md` section 1 only the user can mark the phase Complete.

The script for that run is
[Phase 05 E3 manual checklist](phase-05-e3-manual-checklist-2026-08-23.md).

## What this phase delivers

A hierarchy browser whose entire decision-making layer has no Slate in it.

| Where | What |
|---|---|
| `NexusEditor/NexusHierarchyModel` | `FNexusHierarchySnapshot`: the presented tree for one document revision, built from `INexusRepository` and patched in place. Ten row badges with glyphs and reasons. |
| `NexusEditor/NexusHierarchyQuery` | `type:` `status:` `is:` `id:` `path:` parsing, AND across categories and OR within one, removable chips, four sort modes, ancestor-context filtering. |
| `NexusEditor/NexusSelectionModel` | Click, ctrl-click, shift-range, arrow navigation, select-all-visible, invert, and this session's selection history. |
| `NexusEditor/NexusHierarchyFavorites` | User-local favorites by stable key, ordered, persisted per project, unresolved entries kept. |
| `NexusEditor/NexusHierarchyView` | The view model that ties those together: expansion, search text, saved searches, scroll anchor, and the five view states. |
| `NexusEditor/NexusHierarchyCommands` | The nineteen Phase 05 command handlers. |
| `NexusEditor/NexusSyntheticHierarchy` | The deterministic fixture source, reached only from the console. |
| `NexusEditorUI/SNexusHierarchyTree` | The widget: a virtualized `SListView`, a row, a search box, chips, and a breadcrumb. Drawing and input forwarding, nothing else. |

`SNexusShellSurface` now builds the Hierarchy tab's *World tree* and *Filters*
sections from this widget instead of falling through to the generic state view.

## The five design decisions that carry the phase

### 1. The view model owns everything a row does; the widget owns none of it

Phases 03 and 04 each shipped a surface no click or keystroke could reach, with every
declaration test green — see [Declared is not reachable](../declared-is-not-reachable.md).
A tree row is exactly that shape of risk: it can pass every assertion about what it
holds and still be unclickable.

So click semantics, range extension, keyboard movement, expansion, filtering, and
history all live in `FNexusHierarchyView` and `FNexusSelectionModel`, which contain no
Slate and are driven directly by `Nexus.V7.Hierarchy.SelectionInteraction`. What is
left in the widget is drawing and event forwarding — and that residue is itself
covered by `Nexus.V7.Hierarchy.RowsAreReachable`, which builds a **real row widget**
and sends it a **real `OnMouseButtonDown`**, rather than calling the click handler
behind it. Calling the handler would prove the handler works and say nothing about
whether the row can be pressed.

### 2. Nothing is dropped, including the broken rows

`INexusRepository::GetRootEntities` returns entities with no parent, so a tree built
by walking down from the roots silently loses every record whose parent is missing and
every record caught in a parent cycle — which are precisely the rows a user opens the
hierarchy to find. `V7-QUALITY-GATES.md` section 7 forbids that.

The snapshot therefore enumerates every persisted record and classifies parentage
first. Records that name a missing parent, and every member of a parent cycle, are
promoted to badged roots. Cycle members are skipped when recursing into children,
which is also what stops the depth-first build from recursing forever.

Cycles are found by one linear colouring pass over the parent graph rather than by
walking up from each row, because each record names at most one parent — that graph is
functional, and the per-row walk would be quadratic on the Deep fixture.

### 3. The incremental-refresh gate needed a seam, not a stopwatch

*"A one-item change does not require a visible full-tree rebuild."* "It felt fast" is
not evidence, so `FNexusHierarchySnapshot` counts what it did:
`GetRebuildCount()`, `GetPatchCount()`, and `GetLastPatchedRowCount()`.

`ENexusRefreshHint::Records` and `Diagnostics` patch the named rows only.
`Hierarchy` and `Document` rebuild. Three cases deliberately escalate a patch to a
rebuild rather than producing a plausible-looking wrong tree:

- a changed ID the snapshot has never seen (the change added structure, whatever the
  hint claimed);
- a row whose `Kind` or `SortOrder` moved (identity and sibling position are structure);
- a `Records` hint with an empty ID list (the claim that only named rows moved is
  unverifiable, so it is not taken on trust).

A rename rewrites the path text of the renamed row's whole subtree. That is still a
patch: the gate forbids rebuilding the whole tree for a one-item change, not touching
the rows whose displayed text genuinely changed.

### 4. There was nothing to show, and the fix is a console command

Nothing in the editor binds an authoring document — Phase 07 owns that entry point per
Phase 01 finding F-09 — so the shell has reported Empty since Phase 03 and a tree built
now would have been empty at E3 too.

`FNexusSyntheticHierarchy` builds a transient document deterministically, covering the
shapes `V7-UX-SPEC.md` section 21 mandates: Empty, Normal, Deep, Wide, Invalid, and
Large at the reference scale of 100,000 rows. Identity is hashed from the shape, the
seed, and the row index, so a defect found at the editor is reproducible from the shape
and the seed alone with no asset to pass around — and two shapes at the same seed do
not hand out the same IDs, which is the collision `DocumentSwitching` caught.

It is reached through `Nexus.Fixture.LoadSample` and `Nexus.Fixture.Clear` and
through **no menu entry**. A menu entry would either claim Phase 07's authoring entry
point or leave a dead item that fails the Phase 08 freeze gate; a console command is
unambiguously developer tooling and satisfies section 21 without doing either.

### 5. Five view states, and no `Loading`

`NoDocument`, `Empty`, `NoResults`, `Error`, `Ready`. The phase task list asks for a
loading state as well, and this build does not have one: the snapshot is built
synchronously, so no frame is ever drawn during a build and a loading state could not
render. Shipping one would mean shipping a state that never appears. Recorded here as a
deliberate omission rather than left to be noticed.

The `NoDocument` message names **Phase 07** as the phase that will open a document, so
an unfinished shell reads as unfinished rather than as broken.

## Notable: the four defects this phase's own guards caught

All four were found by automation before the editor was ever opened, which is the
difference this phase was trying to make after Phases 03 and 04.

**A dangling reference at scale.** `Nodes[NodeIndex].ChildIndices.Add(AppendPoint(...))`
looks correct and is not: C++ evaluates the object expression before the argument, so
the address of `ChildIndices` was taken and then invalidated by the array reallocation
`AppendPoint` performs. It survived the 92-row Normal fixture and produced an
`EXCEPTION_ACCESS_VIOLATION` on the 100,000-row one. Fixed by completing the append
before the lookup. `Nexus.V7.Hierarchy.Scale` is what found it, and is what would find
it again.

**Two fixture shapes shared their identities.** IDs were hashed from the seed and the
row index, so `Deep` and `Normal` requested with the same seed handed out the same
GUIDs for their first sixty-four rows — and `Deep`'s ladder puts the same entity kind
at the same depth, so the selection *keys* collided too. Switching documents then left
a selection, an expansion, and a favorite from the previous document resolving against
the new one, which is indistinguishable from a stale-key bug and would have been
diagnosed as one. The shape is now folded into the seed.
`Nexus.V7.Hierarchy.DocumentSwitching` found it on its first run.

**A search that matched seventy-two rows instead of one.** Not a defect: bare words are
separate terms, ORed, which is what a search box does, and quoting is how a phrase is
searched. The test was written against the wrong reading of its own query. Both
readings are now pinned so neither can drift into the other.

**Two order-dependent assertions.** `Focus Search` refuses when no surface is listening
for the focus request; asserting that against the live command service failed because
the running editor already had a Hierarchy tab bound. And the snapshot's counters
survive a rebuild on purpose, so a test asserting "no patches happened" was reading the
previous test's arithmetic. Neither assertion was wrong about the behaviour; both were
wrong to ask a question whose answer depended on what else had run. `Focus Search` is
now exercised against an isolated `FNexusCommandService` and `FNexusHierarchyView`, and
the shared view model's counters are reset when a test takes it over.

## The nineteen commands

Registered against the catalog's existing IDs. `V7-ARCHITECTURE.md` section 7 forbids a
second command list, because a menu and a palette built from two lists eventually
advertise two different shortcuts for one command.

| Group | Commands |
|---|---|
| Row-targeted | Reveal in Tree, Copy Name, Copy ID, Copy Path |
| Selection | Select All Visible, Invert Visible Selection, Clear Selection, Previous Selection, Next Selection |
| Favorites | Add Favorite, Remove Favorite, Manage Favorites |
| Tree shape | Expand All, Collapse All, Expand Selection, Collapse Selection |
| Search | Focus Search, Clear Search, Save Search |

`NexusCommandCatalog::DeliveredThroughPhase` moved from 4 to 5 **only after** all
nineteen had real handlers. `Nexus.V7.Hierarchy.CommandCoverage` asserts that every
catalog command at or below that number is registered and, when it refuses, refuses
with a reason of its own rather than the not-yet-delivered code — so raising the
constant early becomes a failing test rather than a menu of commands that quietly do
nothing.

Every one of them changes what the user is looking at and never the document, so none
reports `bChanged` and none advances a revision.

## E1 — clean builds

`Scripts/VerifyPhase05Hierarchy.ps1`, engine 5.8, Win64.

| Target | Configuration | Result |
|---|---|---|
| `NexusFrameworkEditor` | Development | PASS |
| `NexusFramework` | Development | PASS |
| `NexusFramework` | Shipping | PASS |

Each is a `-clean` build followed by a full build. The two non-editor targets are
built because this phase added public headers to `NexusEditor` and new source to
`NexusEditorUI`; an editor-only module leaking into a packaged target fails here
rather than at Phase 18.

Four `UnrealEditor.exe` processes were running throughout and the clean builds
succeeded anyway. The script warns about that rather than refusing: a locked-file
failure is recoverable and obvious, and closing someone else's editor is not a
script's decision to make.

## E2 — automation

**78 tests, 0 failures, 0 automation warnings, 0 errors.**

| Suite | Tests | Owner |
|---|---|---|
| `Nexus.V7.Hierarchy` | 14 | This phase |
| `Nexus.V7.Command` | 17 | Phase 04, frozen |
| `Nexus.V7.Shell` | 14 | Phase 03, frozen |
| `Nexus.V7.Module` | 12 | Phase 02, frozen |
| `Nexus.V7.Foundation` | 21 | Phase 01, frozen |

The fourteen this phase owns:

| Test | What it holds |
|---|---|
| `Badges` | Ten badges, each with a distinct glyph and a non-empty reason, blocking drawn first. |
| `StableIdentity` | The persisted array is reversed and the key still resolves to the same entity; duplicate-named siblings keep distinct keys and are both warned about. |
| `UnmatchedRows` | Every record has a row: a missing parent, both members of a cycle, and an unanchored activation point are shown and badged, and a cycle member's subtree terminates. |
| `IncrementalRefresh` | One patch, zero rebuilds, one row rewritten; descendant paths follow a rename; `SortOrder`, an unknown ID, and an empty ID list each escalate to a rebuild; a selection-only hint touches nothing. |
| `SearchAndFilter` | Parsing of all five prefixes, quoted phrases, AND across categories and OR within one, ancestor context, chips, the no-results state, and determinism across four sort modes. |
| `SelectionInteraction` | Click, ctrl, shift-range bounded by the visible list, arrows, select-all, invert, history back/forward and branch discard, and reconcile after a deletion. |
| `Favorites` | Add, remove, reorder, unresolved entries kept and labelled, config round-trip including a label containing the separator, and one malformed line skipped rather than fatal. |
| `ViewStates` | `NoDocument` names Phase 07, `Empty`, `NoResults` says how to recover, `Ready` says nothing. |
| `ExpansionSurvivesRefresh` | Expansion, selection, and scroll anchor survive a full rebuild; a filter's own expansion is discarded on clearing the search and the user's is not; reveal opens a row's owners. |
| `CommandCoverage` | The catalog's Phase 05 set and the registered handlers are the same set; every delivered command refuses with a reason of its own; behaviour of add/remove favorite, reveal, select-all, clear, history, collapse, expand, save and clear search; Focus Search proven both ways against an isolated registry. |
| `RowsAreReachable` | A real row widget receives a real `OnMouseButtonDown` with modifiers; Down, Up, End move the selection through a real tree widget; an out-of-range index and an unowned key both report failure. |
| `Scale` | 100,000 rows built and filtered; one row changing still patches with zero rebuilds. |
| `DocumentSwitching` | Fifty consecutive one-item edits stay fifty patches; a world switch drops selection and expansion, keeps the favorite as unresolved, and resolves it again on switching back. |
| `SyntheticFixtures` | Determinism by seed and index, all six shapes parse and build, and both console commands are registered under the names the E3 script uses. |

### Measured, not asserted

| What | Observed |
|---|---|
| One-item patch, 92-row tree | 0.019 ms |
| One-item patch, 100,000-row tree | 5.548 ms |
| Fifty consecutive one-item refreshes | 0.658 ms |
| Building the 100,000-row tree | 110.4 ms |
| Filtering the 100,000-row tree | 55.7 ms |

`V7-ARCHITECTURE.md` section 12 sets p95 at or below 50 ms for an incremental refresh
and 150 ms for a filter over 10,000 loaded rows, and calls those targets on a reference
workstation. This is not that workstation, so the suite's own ceilings are deliberately
loose and these numbers are reported rather than asserted against the budget. The
structural claim — that one changed row does not become work proportional to the tree —
is the assertion, and it holds at both sizes.

## Structural scan

`Scripts/VerifyFoundation.ps1`, re-run after every source and document change:

```
PASS: Phase status mirrors - 01 Complete; 02 Complete; 03 Complete; 04 Complete; 05 Ready for Review; 06-20 Not Started
PASS: Runtime dependency boundary - zero forbidden editor/UI/authoring/Landscape references
PASS: Source debt markers - zero matches
Failures=0
FOUNDATION STRUCTURAL SCAN: PASS
```

The debt-marker check earned its place this phase. It failed on a diagnostic code
named `NothingToDoCode` — which contains the substring "ToDo" — and on a comment using
the word "placeholder". Neither was debt, and both were renamed rather than exempted:
a scan that starts collecting exceptions stops being a scan.

## Acceptance gate

| Gate item | Status | Held by |
|---|---|---|
| Every item is keyed by stable identity and selects the intended entity | **Met** | `StableIdentity` reverses the persisted array and shows the key still resolves to the same entity; duplicate-named siblings keep distinct keys and are both warned about. `UnmatchedRows` shows no record is dropped. |
| Search/filter/sort are correct and retain understandable context | **Met** | `SearchAndFilter`: parsing, AND across categories, OR within one, quoted phrases, chip removal, the no-results state, and determinism across all four sort modes. Ancestors of a match are kept and marked as context. |
| A one-item change does not require a visible full-tree rebuild | **Held at E2; E3 confirms the view** | `IncrementalRefresh` and `Scale` assert the counters: one patch, zero rebuilds, one row rewritten, at 92 rows and at 100,000. Whether the *view* held still is checklist item 12. |
| Representative large-tree interaction meets the Phase 01 responsiveness budget | **Held at E2; E3 confirms the feel** | `Scale` builds and filters the 100,000-row reference tree and asserts a one-row patch stays independent of tree size. The section 12 budgets are targets on a reference workstation that is not necessarily the machine running the suite, so the suite's ceilings are deliberately loose and the timings are reported rather than asserted. Checklist item 13 is the judgement. |
| Selection and expansion survive refresh, save/reload, and undo/redo | **Met** | `ExpansionSurvivesRefresh` keeps expansion, selection, and the scroll anchor across a full rebuild, and shows that a filter's own expansion is discarded on clearing the search while the user's is not. `SelectionInteraction` shows a deleted row leaves the selection and the history rather than dangling. |

## Open items

1. **E3 has not been run.** Two gate items name it explicitly. The script is written
   and is sixteen items.
2. **`Loading` is not a state.** See design decision 5. It becomes real when a phase
   introduces an asynchronous build, and not before.
3. **Five badges have no data source yet.** Dirty, Inherited, Verified, Draft, and
   Conflict have glyphs, reasons, draw order, and test coverage, and nothing in the
   persisted record can currently set them. Deriving them from something plausible
   would put markers on rows that mean nothing. Phase 07 (drafts and dirty state) and
   the validation phases are where they gain sources.
4. **Favorites are per user, per project, and not versioned.** They are a preference,
   stored in `GEditorPerProjectIni`. A favorite that does not resolve against the open
   document is listed as *not in this document* rather than dropped.
5. **The fixtures have no menu entry, on purpose.** See design decision 4. If Phase 08's
   freeze gate ever finds a Nexus menu item that does nothing, it will not be this.
6. **Phase 02's E0 was waived**, and that carries forward as context rather than as a
   Phase 05 finding. See `PHASE-STATUS.md`.
