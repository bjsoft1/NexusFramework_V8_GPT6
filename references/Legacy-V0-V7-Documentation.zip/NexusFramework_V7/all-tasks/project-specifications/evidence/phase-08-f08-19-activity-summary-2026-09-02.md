# Phase 08 — F-08-19, every successful command records what it did (2026-09-02)

Implementing-agent evidence. This is not an acceptance record. Phase 08 remains In
Progress: its dependency is unmet, E3 has not run, and F-08-06 and F-08-15 still need
a user decision.

## What this closes

[The E0 independent review](phase-08-e0-independent-review-2026-09-02.md) filed
**E0-02, Warning**: F-08-16 made `FNexusCommandService::Execute` reuse a destructive
command's confirmed preview to write a real Activity message and target summary, but
a non-destructive command builds no preview, so **Apply, Create, Rename, Reparent,
Duplicate, Save, New/Open/Close, Undo, and Redo** still fell back to
`FNexusOperationHistory::Complete`'s bare status word — the literal text
**"Completed"** on line two of the Activity row, with line three reading
**"no explicit target"** — for the everyday case, not a corner case. `phase-08.md`
and `PHASE-STATUS.md` prose read as if F-08-16 had closed the general problem; it had
not. This closes it as **F-08-19**.

The user's direction (2026-09-02): fix it now rather than defer, and synthesize the
summary centrally in the command service from what the result already carries rather
than adding a per-handler success-message field to the soon-frozen
`FNexusCommandResult` contract.

## F-08-19 — the synthesis is one place, covering every command uniformly

**Warning, fixed.** `FNexusCommandService::Execute` already had a three-way branch
for the completion `Message`/`TargetSummary`: a failure reason on failure, the
confirmed preview's summary for a successful destructive command, and — implicitly —
nothing for everything else. That third case now calls a new anonymous-namespace
helper, `SummariseSuccessfulCommand`, before `OperationHistory.Complete`:

- **Named entities.** `DescribeChangedEntities` resolves `Result.ChangedIds`
  against the live `Context.Document` — each id to `"DisplayName (Kind)"` for an
  entity or `"DisplayName (Activation Point)"` for a point — and joins them with
  `"; "` when there are three or fewer, or reports `"N item(s)"` past that. This is
  the same "specific when small, a count when large" threshold `DescribeConfirmedTarget`
  (F-08-16) already applies to a destructive preview. The message becomes
  `"<Label>: <entities>."` and the target summary is the entity list itself. This is
  the path Apply, Create, Create Default Hierarchy, Duplicate, Rename, and Reparent
  take, because `FNexusEntityMutationResult::ToCommandResult` already puts every
  created/changed/removed id into `ChangedIds`.
- **Document-level.** When nothing resolves but the result is `RefreshHint::Document`
  or `ChangedIds` holds the document's own `DocumentId`, the message is
  `"<Label>: the active document."` and the target summary is `"the active document"`.
  Save, New, Open, Close, Reload, Undo, and Redo take this path.
- **Neither.** A view-only command (the Phase 05 hierarchy commands — Collapse All,
  Expand All, Clear Selection …) or a valid no-op (a rename to the current name)
  changes no nameable state; the message is `"<Label>."` — still the command by
  name, never the status word — and no target summary is claimed.

The document pointer is `::IsValid`-checked before it is dereferenced, because a
lifecycle command (Close, Reload) can leave `Context.Document` pointing at an object
the command just replaced. `FNexusOperationHistory::Complete` is untouched: its
`"Completed"` fallback still exists as a defensive default for a direct caller, but
the command-service path now always hands it a real message on success.

`FNexusCommandResult` gains no field. `NexusCommandService.cpp` gains
`#include "NexusEntityCommands.h"` (for `NexusEntityKinds::GetDisplayName`) and
`#include "UObject/Object.h"` (for `::IsValid`).

## Test coverage

`Nexus.V7.Command.SuccessfulCommandRecordsSummary` (new,
`NexusCommandSystemTests.cpp`) runs a scripted non-destructive handler through an
isolated `FNexusCommandService` + `FNexusOperationHistory` against a two-entity
document and asserts the resulting Activity entry for five result shapes:

1. one changed entity → the message names it ("Downtown"), the target summary carries
   the name and the kind ("City"), and neither is the `"Completed"` / `"no explicit
   target"` fallback;
2. two changed entities → both are named rather than collapsed to a count;
3. `RefreshHint::Document` with no ids → target summary is exactly
   `"the active document"`;
4. a valid no-op (`bChanged == false`, no ids) → the message still contains the
   command's own label, not `"Completed"`;
5. an id the document does not hold → falls back to the command name, not a phantom
   entity and not `"Completed"`.

The F-08-16 test `Nexus.V7.Details.RevertRecordsActivitySummary` is unchanged and
still passes: the destructive path it exercises is untouched.

## Commands and results

    powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1 -RunLabel 2026-09-02-f08-19

- `PASS: clean build NexusFrameworkEditor-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Development`
- `PASS: clean build NexusFramework-Win64-Shipping`
- Suite counts: Hierarchy 17, UiStates 5, Module 12, Details 28, Foundation 21,
  UiGate 10, Command 18, Crud 23, Shell 21.
- `PASS: 159 tests, 0 failures`
- `PASS: 21 budget measurements, 0 over`
- `PHASE 08 E1+E2: PASS`

Command's count moves from 17 to 18 — exactly the one new test this fix added. No
other suite's count moved.

Budget artifact: `Saved/NexusV7/Phase08/ui-budgets-2026-09-02-f08-19.txt`, 1,011
bytes, SHA-256
`E6437D1CBA6A2CDB787DBEC194F3D7F1E205640919BFEB5636C17BDF4F62D31D`.

## How to Test This Correction

1. Open **Window > Nexus Framework V7 > Open Default Workspace**, press
   `Ctrl+Shift+P` > **New Document**, and create the default hierarchy → a State,
   City, and Highway appear.
2. Select the City, open **Details**, change its display name, and let it
   auto-commit → open **Activity**: the newest row reads **Apply Property Changes**
   and its detail line names the City and its kind, not the word "Completed", and the
   origin line names the entity instead of "no explicit target".
3. Press `Ctrl+Shift+P` > **Save Document** → the newest Activity row's detail line
   reads "Save Document: the active document.", not "Completed".
4. Select the State and press `Ctrl+Shift+P` > **Duplicate** → the Activity row names
   the copy (or, if you multi-select first, lists up to three names and then a
   count).
5. Press `Ctrl+Z` → the **Undo** row's detail line reads "Undo: the active
   document.", never a bare "Completed".
6. Press `Ctrl+Shift+P` > **Collapse All** → its Activity row reads "Collapse All."
   — the command by name, with no target claimed, rather than the status word.

Automated regression:

    powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1

Expected: `PASS: 159 tests, 0 failures`, `PHASE 08 E1+E2: PASS`, and
`PASS: Nexus.V7.Command - 18 results` in particular.

## What remains

E3 has not run. F-08-06 and F-08-15 still need the user's reading. Every E0 finding
from [the 2026-09-02 independent review](phase-08-e0-independent-review-2026-09-02.md)
is now acted on (E0-01 as F-08-17, E0-03 as F-08-18, E0-02 as F-08-19); E0-04 was
Information only. This pass does not by itself move Phase 08 or any earlier phase's
status.
