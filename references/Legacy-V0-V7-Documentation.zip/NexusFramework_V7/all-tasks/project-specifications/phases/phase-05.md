# Phase 05 — Hierarchy Tree View

## Status

Ready for Review

## Objective

Build a production hierarchy browser that remains fast, clear, and selection-stable from a tiny test map to a large world.

## Scope

- State→City→Highway→HighwayPoint→placed-object presentation.
- Virtualization, incremental refresh, search, filter, sort, expansion, selection, context actions, breadcrumbs, and status badges.
- View-model separation from persistence and business logic, plus favorites and selection history.

## Out of Scope

- Details-property implementation.
- Final CRUD mutation logic.
- Viewport gizmos or Landscape extraction.

## Tasks

- [x] Define stable tree item/view-model IDs independent of row index and display text.
- [x] Render all hierarchy levels plus object type, validation, dirty, inherited, stale, and verification badges. Ten badges have glyphs, reasons, and draw order; five of them (dirty, inherited, verified, draft, conflict) have no source in the persisted record at this phase and are deliberately never asserted rather than derived from something plausible.
- [x] Implement virtualized rows and incremental diff refresh without full-tree rebuild for one-item changes.
- [x] Add debounced search, type/status filters, deterministic sorting, and clear-filter affordance.
- [x] Preserve expansion, selection, scroll, and focus across refresh and undo/redo.
- [x] Support single/multi-select, keyboard navigation, range selection, context menu, and breadcrumb synchronization.
- [x] Add favorites, recent selection/history navigation, and stable cross-tab selection through the shared selection service. Focus in Viewport is a Phase 12 command and still refuses by name.
- [x] Add useful empty/no-results/error states, plus a no-document state naming Phase 07. There is no loading state: the snapshot is built synchronously, so no frame is drawn during a build and one could never render.
- [x] Test duplicate display names, missing parents, large datasets, rapid changes, and world switches.

## How to Test

Six steps. The first two are automated and take about three minutes, including the
100,000-row timings. The rest need the editor and a real document. The full manual
run is `evidence/phase-05-e3-manual-checklist-2026-08-23.md`.

1. **Run the gate.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase05Hierarchy.ps1 -SkipBuilds`
   → expect `PASS: 83 tests, 0 failures` and `PHASE 05 HIERARCHY: PASS`, plus two
   `TIMING:` lines for filtering and patching 100,000 rows.
2. **Run the structural scan.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyFoundation.ps1`
   → expect `FOUNDATION STRUCTURAL SCAN: PASS`.
3. **Load a tree and select in it.** Editor console: `Nexus.Fixture.LoadSample Normal`.
   Click a row, then `Ctrl`-click and `Shift`-click others.
   → selection behaves like the Content Browser's: `Ctrl` toggles, `Shift` extends,
   and the breadcrumb follows the primary selection.
4. **Drive the tree from the keyboard only.** `Down`, `Up`, `Left`, `Home`.
   → every row is reachable without a mouse, and `Left` moves to the parent rather
   than doing nothing at the top of a branch.
5. **Filter it.** Type `type:City status:warning` in the search box.
   → terms combine with AND across categories and OR within one; the chip strip
   shows what is active; clearing restores the full tree with selection intact.
6. **Check the shapes that break trees.** `Nexus.Fixture.LoadSample Deep`, then
   `Wide`, then `Large` (100,000 rows), then `Invalid`.
   → `Deep` indents and scrolls without clipping, `Wide` stays responsive, `Large`
   opens and filters without a freeze, and `Invalid` — duplicate names, a missing
   parent, a cycle, an unanchored point — **shows the rows it holds with badges**
   rather than refusing to draw them. Select a row and filter it out of view: the
   selection survives and the summary says so.

## Dependencies

- Phase 04 Complete.
- Phase 01 representative persisted data provider available.

## Required Evidence

- E1: clean editor build.
- E2: hierarchy, filter, selection preservation, incremental refresh, and scale tests.
- E3: manual navigation, readability, keyboard, context, refresh, and responsiveness review.

## Acceptance Gate

- [x] Every item is keyed by stable identity and selects the intended entity.
- [x] Search/filter/sort are correct and retain understandable context.
- [ ] A one-item change does not require a visible full-tree rebuild. Held at E2 on the snapshot rebuild/patch counters at 92 rows and at 100,000; whether the view held still is E3 checklist item 12.
- [ ] Representative large-tree interaction meets the Phase 01 responsiveness budget. Held at E2 on the reference-scale build and filter; the judgement of whether it feels responsive is E3 checklist item 13.
- [x] Selection and expansion survive refresh, save/reload, and undo/redo.

## Risks

- Binding rows directly to mutable array addresses can create stale selection and crashes.
- Full rebuilds can freeze the editor at scale.
- Filtering without ancestor context can make results appear disconnected or misleading.
