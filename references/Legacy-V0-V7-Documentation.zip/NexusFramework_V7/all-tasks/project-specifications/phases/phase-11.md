# Phase 11 — Representation Graph & Enforced Validation

## Status

Not Started

## Objective

Construct the canonical authoring representation and query surfaces from validated mapping data, with stage types and backend guards that make invalid downstream consumption impossible.

## Scope

- States, Cities, Highways, ordered HighwayPoints, segments, junctions, lanes, sidewalks, connections, and activation anchors.
- Stable lookup indices and relationship queries.
- Information/Warning/Blocking validation and validated-stage wrappers.

## Out of Scope

- Viewport rendering and gizmos.
- Mesh generation.
- Specialized activation payload catalog.
- Runtime asset compilation.

## Tasks

- [ ] Define one canonical representation for hierarchy, point order, connections, ownership, and relationship references.
- [ ] Build stable ID→record indices without storing array addresses across rebuilds.
- [ ] Implement hierarchy, adjacency, junction, lane, path-neighbor, owner, and nearby-anchor queries.
- [ ] Detect missing/duplicate IDs, dangling references, invalid membership, broken segments, invalid tangents, malformed junctions, and cross-owner relationships.
- [ ] Introduce validated source, mapping, and representation wrappers with validator-controlled construction.
- [ ] Enforce guards inside services so menu state, scripts, tests, and direct callers receive the same Blocking behavior.
- [ ] Support draft authoring warnings while blocking structurally unsafe save or downstream stage execution as specified.
- [ ] Track representation revision and invalidate dependent generation/compiler snapshots after mutation.
- [ ] Test deterministic rebuild, lookup/query correctness, invalid fixtures, large graphs, and stale-wrapper rejection.

## Dependencies

- Phase 10 Complete.

## Required Evidence

- E0: graph and validation API review.
- E1: clean editor build.
- E2: representation, relationship, query, validation-enforcement, determinism, and scale tests.

## Acceptance Gate

- [ ] Every reference and relationship invariant is validated.
- [ ] No downstream service accepts an unvalidated representation.
- [ ] Backend guards cannot be bypassed by direct command or script invocation.
- [ ] Same input produces the same representation and diagnostics order.
- [ ] Queries meet the Phase 01 editor budget.
- [ ] Any mutation invalidates stale dependent snapshots.

## Risks

- Duplicating hierarchical and flat truth can allow them to diverge.
- Public constructors for “validated” types can undermine the entire gate.
- Rebuilding all indices after small edits may fail editor-scale targets.
