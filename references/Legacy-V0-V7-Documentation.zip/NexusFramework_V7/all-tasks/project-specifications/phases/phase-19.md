# Phase 19 — Human Verification & Publish UI

## Status

Not Started

## Objective

Provide one trustworthy publish-preflight workspace where a human can browse every generated/compiled item, focus it in context, record type-appropriate verification, see freshness and validation state, and understand exactly why a world is or is not publishable.

## Scope

- Content verification tree, viewport focus, per-instance/type checklists, reviewer/time records, invalidation, rollups, warning disposition, compile freshness, and publish preflight.
- State→City→Highway→Point→static/activation content hierarchy.

## Out of Scope

- Treating checkbox presence as proof without focusing/inspecting the object.
- Allowing verification to survive a relevant source change.
- Bypassing compiler, package, scale, or Blocking validation gates.

## Tasks

- [ ] Build a virtualized verification tree over every current hierarchy and placed/generated/activation instance.
- [ ] Add filter by unverified, failed, stale, warning, type, owner, reviewer, and search text.
- [ ] Reuse the canonical selection/focus service to frame each entity in the viewport.
- [ ] Define data-driven global and type-specific checklist templates.
- [ ] Persist verification Target ID, target content hash/revision, checks, result, reviewer, UTC time, comment, and evidence references.
- [ ] Invalidate verification automatically when relevant source, payload, generated output, compiler version, or checklist template changes.
- [ ] Show verified/total rollups at every hierarchy level without allowing parent checkboxes to hide unreviewed children.
- [ ] Integrate Blocking diagnostics, warning resolve/accept decisions, runtime freshness, Phase 18 results, and package status.
- [ ] Provide explicit preflight reasons and navigation/fix actions for every failed gate.
- [ ] Prevent “never opened,” missing-record, stale-record, or partially checked items from counting as verified.
- [ ] Run a full human review on the release-candidate canonical world.

## Dependencies

- Phase 18 Complete.

## Required Evidence

- E1: clean editor build.
- E2: tree completeness, hash invalidation, checklist versioning, rollup, focus, preflight, and regression tests.
- E3: user review of every release-candidate category plus deliberate stale/unverified/blocking cases.

## Acceptance Gate

- [ ] Every current verifiable instance appears exactly once in the correct hierarchy.
- [ ] Focus selects/frames the correct current entity.
- [ ] Relevant edits invalidate prior verification.
- [ ] Missing, partial, failed, and stale reviews block preflight.
- [ ] Warnings have explicit recorded dispositions.
- [ ] User completes and approves the release-candidate verification pass.

## Risks

- Verification keyed only by ID can remain falsely valid after content changes.
- Huge per-instance trees can become unusable without virtualization and filters.
- A generic checklist can miss critical type-specific visual/gameplay conditions.
- Verification UI can falsely imply publish readiness if other gates are not integrated.
