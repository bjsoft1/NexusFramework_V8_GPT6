# Phase 18 — Real Scale, Cook & Package Gate

## Status

Not Started

## Objective

Prove V7 on a representative production-scale world, not only synthetic fixtures: editor authoring, visualization, generation, compilation, World Partition, cook, package, standalone runtime, memory, frame time, queries, pooling, and recovery must all meet locked budgets.

## Scope

- Real scale dataset/map and reproducible benchmark protocol.
- Cold builds, cook, package, standalone runs, World Partition travel/streaming, stress/failure scenarios, profiling, leak checks, and corrective optimization.

## Out of Scope

- Redefining budgets after seeing results without explicit user approval.
- Passing only synthetic registry/object-count commands.
- Adding unrelated product features.

## Tasks

- [ ] Build or designate a representative production-scale canonical world with real geometry, hierarchy, generation, and activation diversity.
- [ ] Record hardware, engine version, build configuration, dataset counts, map, camera/player path, and benchmark procedure.
- [ ] Measure UI open/refresh/search/selection/details/diagnostics/viewport performance.
- [ ] Measure reader, reconciliation, representation, validation, generation, compile, save, and reload time/memory.
- [ ] Measure runtime asset size/load, spatial/path queries, frame/game-thread time, active Actors, pool behavior, streaming, and teleport recovery.
- [ ] Run repeated World Partition cell load/unload, map travel, world teardown, and long-duration soak tests.
- [ ] Run cold editor/game builds, full cook, package, and standalone launch with no editor modules.
- [ ] Check warnings, ensures, crashes, memory growth, leaked packages/Actors/delegates, stale output, and nondeterministic compile.
- [ ] Optimize measured bottlenecks without weakening correctness or evidence.
- [ ] Re-run the full benchmark after every corrective change and record before/after results.

## Dependencies

- Phase 17 Complete.

## Required Evidence

- E0: benchmark representativeness and protocol review.
- E1: clean cold Editor and Game builds.
- E2: full regression suite after optimization.
- E4: recorded real-scale profile, cook/package, standalone, World Partition, soak, and budget results.

## Acceptance Gate

- [ ] Representative real data—not synthetic-only data—was used.
- [ ] Every Phase 01 performance and capacity budget passes.
- [ ] Cook/package/standalone complete without editor dependency or missing cooked assets.
- [ ] No unresolved crash, ensure, leak, unbounded growth, or nondeterminism remains.
- [ ] Streaming, travel, teleport, and teardown remain correct under stress.
- [ ] Benchmark is reproducible from its recorded protocol.

## Risks

- An unrepresentative “large” map can conceal production bottlenecks.
- Profiling Development Editor alone can misrepresent packaged runtime behavior.
- Optimizations can bypass validation, identity, or verification provenance.
- World Partition stress can reveal ownership assumptions that require earlier-phase reopening.
