# Phase 07 — Full UI CRUD

## Status

Ready for Review

## Objective

Complete all user-facing Create, Read, Update, Duplicate, Delete, bulk-edit, undo/redo, save/reload, and recovery workflows against the real versioned V7 authoring repository.

## Scope

- Real persisted repository and representative heterogeneous payloads.
- Create wizards/templates, update/rename/move, duplicate, delete, bulk actions, reference-impact preview, transactions, dirty/save state, atomic failure recovery, and action history.
- Unified tree/details/menu/shortcut behavior.

## Out of Scope

- Landscape-derived automatic mapping.
- Production activation type catalog.
- Static generation and runtime compilation.
- Session-only data as acceptance evidence.

## Tasks

- [x] Implement real world-config repository operations through stable IDs and Phase 01 storage contracts.
- [x] Add guided Create flows with type selection, owner/anchor choice, defaults, validation, and cancel.
- [ ] Implement update, rename, reparent/move where legal, duplicate with ID remap, and explicit batch edits.
- [x] Add Delete preview listing children, inbound references, generated consequences, and orphan policy.
- [x] Make every mutation transactional with complete undo/redo across repository, tree, details, and selection.
- [x] Add dirty state, explicit save, autosave policy, save failure recovery, and cold-reload behavior.
- [x] Ensure a failed multi-step operation rolls back atomically.
- [ ] Add conflict handling for stale selection, external asset change, unknown payload, and ownership mismatch.
- [x] Record actionable success/failure summaries without modal spam or false success.
- [ ] Run restart tests with fixed and dynamic-array payload data created entirely through the UI.

The three unchecked items are unchecked deliberately, and each is short of a
named thing rather than of work in general:

- **Reparent/move** has its service, its legality rule, its cycle refusal, and its
  tests, and no gesture in the UI reaches it. The tree has no drag-and-drop and the
  catalog has no Move command, so today a move is only performable from automation.
- **Conflict handling** covers stale selection and unknown payload — both refuse by
  name with the reason — and does not cover external asset change or ownership
  mismatch. Those are reconciliation against a source, which Phase 10 owns; V7-UX-SPEC.md
  section 13 also requires a per-field resolver that this phase does not build.
- **Restart tests** run against a package reload rather than an editor restart. The
  automated half is `Nexus.V7.Crud.DocumentLifecycle`; the editor restart is E3, and
  no automation in this project can perform one.

## How to Test

Eight steps. The first two are automated and take about three minutes; the rest need
the editor open. The full manual run is
`evidence/phase-07-e3-manual-checklist-2026-08-24.md`.

**Do not use `Nexus.Fixture.LoadSample` for this phase.** The fixture document is
in-memory, so it cannot be saved and `Nexus.Document.Save` refuses it by name —
which looks like a defect and is not. Everything below needs a real asset made with
**New Document**. The fixture is for Phases 03-06, where shape and scale are the
subject and persistence is not.

1. **Run the gate.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase07Crud.ps1 -SkipBuilds`
   → expect `PASS: 124 tests, 0 failures` and `PHASE 07 CRUD: PASS`.
   Drop `-SkipBuilds` for the three clean builds (~15 min).
2. **Run the structural scan.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyFoundation.ps1`
   → expect `FOUNDATION STRUCTURAL SCAN: PASS`.
3. **Make a document, and save it.** Open the Nexus workspace, `Ctrl+Shift+P` →
   **New Document**, then press the **Save** button on the context strip.
   → the asset appears under `/Game/Nexus` **unsaved** — amber `UNSAVED` on the
   strip, an asterisk in the Content Browser, nothing yet on disk — and **Save**
   writes it and clears both. Creating no longer writes the package. Note that
   `Ctrl+S` is Unreal's level save, not this: the strip button and the toolbar's
   **Save Document** are the two routes.
4. **Create, rename, duplicate, delete.** Right-click the tree → **Create ▸ State**;
   name it; right-click → **Duplicate**; select the original and press `Delete`.
   → Create offers only legal child kinds, the new row opens straight into rename,
   and Delete confirms in a **popup** naming what it will remove, over the tab you
   are already on. Cancel changes nothing; confirming redraws the tree without it.
5. **Undo it.** `Ctrl+Z` once after the delete, then `Ctrl+Y`.
   → one press restores the whole subtree; tree and Details agree; undo keeps
   working for the rest of the session.
6. **Restart.** Save, close the editor completely, reopen, and **Open Document**.
   → every entity is there with the right name, kind, and parent. This is the one
   no automation can perform.
7. **Open a map, and look for its document.** File > Open Level >
   `Content/NF/Maps/LV0_Development1`.
   → `NF/Maps/LV0_Development1/NexusConfig` becomes the active document and shows
   as **unsaved** — amber `UNSAVED` on the strip, an asterisk in the Content
   Browser, nothing on disk until you save it. Switching to another saved map
   switches the document with it; File > New Level clears it rather than leaving the
   previous map's document live. `Nexus.AutoBindWorldDocument 0` turns this off.
   This is the V6 behaviour that was missing, and no automation covers the map-open
   half of it: the bind is skipped under `-unattended`.
8. **Start from zero.** With that fresh, empty document active, look at the tree.
   → the empty panel offers **Create Default** first, then Create State and
   Create World. Pressing Create Default makes `Default State > Default City >
   Default Highway` and selects the State; one `Ctrl+Z` removes all three. It is
   offered only while the document is empty.

## Dependencies

- Phase 06 Complete.
- Phase 01 persistence/versioning contract remains unchanged.

## Required Evidence

- E1: clean editor and cold reflected-data builds.
- E2: full CRUD, duplicate/remap, reference impact, transactions, rollback, save/reload, and regression tests.
- E3: manual end-to-end UI CRUD, confirmation, undo/redo, failure recovery, and restart review.

## Acceptance Gate

- [ ] Every visible CRUD command works against real persistent data.
- [ ] Created fixed and array payloads survive a full editor restart.
- [ ] Duplicate creates unique IDs and remaps internal references correctly.
- [ ] Delete cannot silently cascade or orphan data without showing the approved result.
- [ ] Undo/redo restores data, selection, tree, and details consistently.
- [ ] Failed operations leave no partial mutation.
- [ ] No session-only store or mock provider is required.

## Risks

- Partial transactions can desynchronize UI and asset state.
- Delete/reparent rules can corrupt hierarchy if inbound references are not considered.
- Autosave during an invalid intermediate edit can persist structural corruption.
