# Phase 09 — Landscape Reader & Identity

## Status

Not Started

## Objective

Read all relevant Landscape Spline geometry and topology safely into a validated source snapshot while preserving stable identity across restart, multiple Landscapes, map switches, edits, deletion, and duplication.

## Scope

- Multi-Landscape enumeration and ownership.
- Control points, segments, endpoints, transforms, tangents, connections, loops, junctions, and stable source identities.
- Cache invalidation, transaction observation, safe engine API usage, and source validation.

## Out of Scope

- State/City/Highway membership mapping.
- Authoring generated geometry back into Landscape.
- Static mesh generation or runtime compilation.

## Tasks

- [ ] Enumerate every supported logical Landscape instead of choosing the first actor.
- [ ] Assign/resolve stable Landscape identity and validate streaming proxies/owners correctly.
- [ ] Extract control points, connected segments, start/end direction, locations, rotations, Hermite tangents, and connection graph.
- [ ] Implement the approved stable control-point identity mechanism transactionally in Nexus binding/reconciliation data only; never rename, tag, subclass, or otherwise mutate Landscape spline points for identity.
- [ ] Verify every resolved engine object belongs to the current World and intended Landscape component.
- [ ] Invalidate source caches on map switch, close, object replace/delete, undo/redo, and Landscape transaction.
- [ ] Handle deleted control points reparented to transient storage as invalid even when non-null.
- [ ] Implement finite/normalized tangent and safe junction-rotation checks without unsafe engine auto-selection/rotation calls.
- [ ] Produce immutable source snapshots plus Information/Warning/Blocking diagnostics.
- [ ] Test simple chains, loops, shared points, three/four-way junctions, two Landscapes, two resident maps, duplication, and restart.

## Dependencies

- Phase 08 Complete. This dependency cannot be waived.

## Required Evidence

- E1: clean editor and cold reflected-schema builds.
- E2: geometry, topology, identity, ownership, invalidation, cross-map, junction, and regression tests.
- E3: manual Landscape edit/map-switch/restart verification on named fixtures.

## Acceptance Gate

- [ ] Every supported Landscape is read and owned independently.
- [ ] Identity survives cold restart and normal topology edits.
- [ ] A stale object from another map/Landscape is always rejected.
- [ ] Loops and multi-way junctions produce correct topology and finite tangents.
- [ ] Source Blocking findings prevent downstream mapping.
- [ ] Reader does not alter Landscape geometry.

## Risks

- Engine-object lifetime can make stale pointers appear valid.
- Structural fingerprints can become ambiguous after topology edits; ambiguity must
  block Apply because V7 forbids identity tags/renames on Landscape spline points.
- Zero derivatives and junction rotation can trigger known engine crash classes.
- World Partition proxies may be double-counted as separate Landscapes.
