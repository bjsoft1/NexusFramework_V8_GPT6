# Phase 16 — Deterministic Runtime Compiler

## Status

Not Started

## Objective

Compile the validated authoring representation into an immutable, runtime-safe, deterministic, versioned asset that contains every required topology and activation field, validates before save, and proves its freshness against the source.

## Scope

- Runtime schema/header and per-type compiler adapters.
- Hierarchy/topology, paths/connections, geometry values, classification, activation payloads, streaming chunks, lookup indices, spatial data, provenance, hashes, and validation.
- Round-trip, determinism, stale detection, and atomic replacement.

## Out of Scope

- Runtime Actor activation behavior.
- Editor-only validation messages or object pointers in the cooked schema.
- Saving partially compiled or invalid runtime assets.

## Tasks

- [ ] Implement the locked runtime asset header with schema/custom/compiler versions, Build ID, source IDs/revision/hash, bounds, and streaming metadata.
- [ ] Compile canonical State/City/Highway/HighwayPoint records, ordered topology, tangents, start/end roles, junction/connectivity, lanes, sidewalks, and pathfinding inputs.
- [ ] Compile every registered activation through its explicit adapter into runtime-safe payload data.
- [ ] Compile classification, ownership, parent/relationship references, World Partition chunks, lookup tables, and spatial indices.
- [ ] Exclude editor-only data, raw/editor object pointers, diagnostics text, transient state, and runtime occupancy state.
- [ ] Sort and normalize inputs so identical logical input produces identical logical/serialized output.
- [ ] Fix exactly one canonical formula for a cell's stored bounds — the tight union of its records' bounds is the expected choice — so that two clean compiles of equal input produce byte-equal cells. Validation enforces only containment, which several different bounds satisfy. Carried from the 2026-08-22 Phase 01 E0 review (F-01); see `V7-ARCHITECTURE.md` §10 "Cell assignment and hierarchy ownership".
- [ ] Validate duplicate/missing IDs, unresolved references, invalid values/assets, adapter omissions, chunk ownership, index bounds, and payload/type mismatches.
- [ ] Refuse save/replacement on Blocking findings and preserve the last known-good runtime asset.
- [ ] Mark existing output stale immediately when source revision/hash changes.
- [ ] Add compile cancellation at safe stages and actionable progress/failure summaries.
- [ ] Prove save/reload, previous-schema migration policy, cook inclusion, and standalone runtime deserialization.

## Dependencies

- Phase 15 Complete.

## Required Evidence

- E0: runtime schema and field-traceability review.
- E1: clean editor and non-editor Game builds.
- E2: adapter, validation, deterministic compile, round-trip, stale, cancellation, and regression tests.
- E4: cook/package and standalone runtime asset load proof.

## Acceptance Gate

- [ ] Every required authoring/runtime field has a tested compile path.
- [ ] Same input produces the same normalized runtime output and content hash.
- [ ] Invalid input cannot create or replace a runtime asset.
- [ ] Last known-good output survives a failed compile.
- [ ] Runtime asset loads without any editor module.
- [ ] Source revision/hash mismatch reliably marks and blocks stale output.

## Risks

- Hidden iteration-order nondeterminism can change output hashes.
- A generic payload can accidentally retain editor-only references.
- Duplicated hierarchy and lookup data can drift if compiled independently.
- Replacing a good asset before final validation can leave the project without runnable data.
