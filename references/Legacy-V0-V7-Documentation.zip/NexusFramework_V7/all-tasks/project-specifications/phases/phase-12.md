# Phase 12 — Diagnostics, Debug Visualization & Gizmos

## Status

Not Started

## Objective

Make every important authoring, mapping, validation, generation, and activation fact visible and editable through scalable diagnostics, viewport overlays, click-to-focus, and safe selection-driven gizmos.

## Scope

- Data-driven debug category registry and tree.
- Diagnostics list/details, filtering, focus, overlay rendering, labels, LOD/culling, selection, proxy interaction, and gizmo transactions.
- Fixed and array sub-point visualization/editing.

## Out of Scope

- Production static mesh generation.
- Editing Landscape geometry through Nexus gizmos.
- Spawning one proxy Actor or gizmo for every logical object.

## Tasks

- [ ] Create registry-driven debug categories with no central closed-enum edit required for a new feature.
- [ ] Build category tree, saved visibility/style settings, search, solo/mute, and sensible presets.
- [ ] Build diagnostics panel with severity, stage, owner, entity, message, repair guidance, copy/export, and click-to-focus.
- [ ] Render curve-accurate roads, points, tangents, directions, junctions, lanes, hierarchy, mapping IDs, activations, bounds, and errors using shared primitives.
- [ ] Add distance/viewport culling, label budgets, LOD, render snapshots, and performance counters.
- [ ] Implement selection-driven viewport interaction and a bounded nearby proxy pool where native editor interaction is needed.
- [ ] Implement gizmo editing for one selected base/fixed/array sub-point with exact key addressing.
- [ ] Route every edit through FScopedTransaction and the real persisted repository.
- [ ] Verify undo/redo, selection restore, focus, array independence, map switch, and no Landscape geometry mutation.
- [ ] Add zero-framework-edit onboarding proof for one new diagnostic category and one new gizmo-capable payload field.

## Dependencies

- Phase 11 Complete.
- May run in parallel with Phase 13 only if it does not violate the active-work limit.

## Required Evidence

- E1: clean editor build and cold build for reflected helper types.
- E2: registry, renderer, focus, selection, gizmo addressing, transaction, culling, and scale tests.
- E3: manual overlay accuracy, interaction, visual readability, array independence, and performance review.

## Acceptance Gate

- [ ] Every Blocking diagnostic can focus or clearly locate its target.
- [ ] New categories register without editing a closed central switch.
- [ ] Visualization is accurate, readable, and within budget at representative scale.
- [ ] Gizmos edit only the selected persisted field and never Landscape geometry.
- [ ] Undo/redo and array-element independence pass.
- [ ] No unbounded Actor/proxy/gizmo population exists.

## Risks

- Per-frame reflection or full-dataset scanning can freeze the viewport.
- Native spline selection APIs are known unsafe.
- Array element bindings can point to moved memory after resize/reorder.
- Debug visuals can appear authoritative while using a stale snapshot.
