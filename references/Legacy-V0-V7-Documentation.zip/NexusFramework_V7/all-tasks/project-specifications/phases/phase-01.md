# Phase 01 — Architecture Lock & Serialization Spike

## Status

Complete

## Objective

Remove every architecture decision that could become a late compiler, persistence, identity, validation, multi-Landscape, or runtime blocker. Prove the highest-risk decisions with a working vertical serialization spike rather than documentation alone.

## Scope

- V0–V6 feature and failure traceability.
- Module ownership and legal dependency directions.
- World/config/Landscape ownership and identity.
- Persistent heterogeneous activation payload architecture.
- Versioning, migration, runtime-schema, validation, freshness, UX, and performance contracts.
- Small fixed-payload and dynamic-array-payload proof assets.

## Out of Scope

- Production UI implementation.
- Full Landscape reading or mapping.
- Real gameplay object catalog.
- Static generation, runtime activation, or production release.
- Copying V0–V6 implementation code.

## Tasks

- [x] Produce a V0–V6 Keep/Redesign/Drop matrix covering features, optimizations, crashes, and process failures.
- [x] Record ADRs for NexusCore, NexusAuthoring, NexusEditorUI, NexusEditor, NexusLandscapeEditor, NexusGeneration, NexusCompiler, NexusRuntime, and NexusTests responsibilities.
- [x] Lock the validated-stage data flow and prohibit runtime-to-editor dependency.
- [x] Lock multiple-Landscape support: one world-owned config, stable Landscape IDs, and explicit cross-Landscape relationships.
- [x] Decide config discovery/ownership behavior for world rename, duplication, mismatch, clone, and relink.
- [x] Decide whether one-time control-point name/tag identity mutation is allowed; V7 forbids it as an identity shortcut.
- [x] Define stable domain IDs, owner IDs, duplication remap, soft-reference ownership checks, orphan handling, and cache invalidation.
- [x] Define the persisted activation record with registry Type Key, payload version, and reflected FInstancedStruct payload.
- [x] Implement fixed-field and dynamic-array spike payloads using the intended real asset storage path.
- [x] Prove create/edit/delete, transaction, undo/redo, save/reload, and cold editor restart.
- [x] Register a V7 custom serialization version and prove an old→new payload migration against an immutable fixture.
- [x] Prove struct rename/redirect and real removed-native-type behavior without silent data loss.
- [x] Prove cook/package viability for every type intended to cross the runtime boundary.
- [x] Freeze the immutable runtime asset header, canonical record/cell/index/route strategy, value-only compiler adapter, deterministic Build ID, and source freshness rule.
- [x] Freeze Information/Warning/Blocking behavior and validated wrapper construction rules.
- [x] Record unsafe engine API guardrails, including native spline selection, control-point subclassing, deleted/reparented spline objects, and junction rotation/tangent crash mitigation.
- [x] Define measurable UI responsiveness, editor scale, compiler determinism, runtime query, memory, active-Actor, cook, and package budgets.
- [x] Record the initial reference baseline using the canonical TinyPayload and SelectionState fixtures: cold Editor/Game/Shipping build time, foundation-suite time, serialized byte count, and peak process memory; retain the exact commands and results in `evidence/phase-01-baseline-<date>.md`.
- [x] Record canonical test fixtures and evidence-report format.

## How to Test

Six steps. The first three are automated. Steps 4-6 are the ones only a person can
do; the cook in step 3 takes the longest by far.

1. **Run the foundation suite.**
   `UnrealEditor-Cmd.exe NexusFramework.uproject -unattended -NullRHI -NoSplash -NoSound -ExecCmds="Automation RunTests Nexus.V7.Foundation; Quit" -TestExit="Automation Test Queue Empty" -log="foundation.log" -stdout`
   → 21 `Result={Success}` lines and `TEST COMPLETE. EXIT CODE: 0` in
   `Saved/Logs/foundation.log`. A zero exit code alone proves nothing here — read
   the log.
2. **Prove cold restart.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase01ColdRestart.ps1`
   → `PHASE 01 COLD-RESTART PROOF: PASS (3 separate editor processes)`. Three
   processes, because one process reloading a package is not a restart.
3. **Prove cook and package.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase01CookPackage.ps1`
   → `PHASE 01 COOK/PACKAGE/RUNTIME-DATASET LOAD: PASS`. Run this after **any**
   change to the dataset fixture: the packaged host re-asserts about sixty fields
   that no editor-side test can see.
4. **Edit a spike asset by hand.** Open a `TinyPayload` fixture, change a field,
   `Ctrl+Z`, `Ctrl+Y`, save, reload.
   → the value round-trips and undo/redo stay working for the rest of the session.
5. **Open the migration fixture.** Load the immutable old-schema asset.
   → it migrates on load, reports that it did, and asks to be saved once. Nothing
   is silently dropped.
6. **Close and reopen the editor**, then open the same asset again.
   → identical contents and identity. Session-only state is not evidence here.

## Dependencies

- Direct reading of V0–V6 architecture, source, histories, and known failure reports.
- Unreal Engine version and toolchain used by the V7 host project.

## Required Evidence

- E0: signed architecture/traceability review with no undecided critical item.
- E1: cold build of the spike and affected modules.
- E2: automated serialization, transaction, migration, validation, and determinism tests.
- E4: cold restart plus cook/package load proof for the chosen payload/runtime approach.

Current evidence: [phase-01-foundation-2026-08-22.md](../evidence/phase-01-foundation-2026-08-22.md).
Baseline: [phase-01-baseline-2026-08-22.md](../evidence/phase-01-baseline-2026-08-22.md).

E1, E2, and E4 are green. E0 was performed on 2026-08-22 by an independent
reviewer and did **not** accept the phase:
[E0 independent review](../evidence/phase-01-e0-independent-review-2026-08-22.md).

All five required E0 items were remediated on 2026-08-22:

- F-01/F-02: `V7-ARCHITECTURE.md` §10 "Cell assignment and hierarchy ownership"
  decides cell assignment by origin, loose cell bounds, and acyclic-graph
  ownership; `NexusRuntimeDataset.cpp` enforces all three.
- F-03: the compiled-dataset fixture now covers two cells and a cross-cell
  hierarchy owner, with five added negative tests.
- F-04: the evidence project path is corrected.
- F-05: `V7-QUALITY-GATES.md` §2 requires a byte count and SHA-256 per artifact.

The remediation was authored by the reviewer, so Phase 01 remains Ready for
Review until the user accepts it or a second independent pass reviews it.

## Acceptance Gate

- [x] All Phase 01 tasks have concrete decisions or passing proof.
- [x] FInstancedStruct fixed and array payloads survive save, cold restart, undo/redo, and migration.
- [x] Missing/mismatched types cannot silently discard or overwrite data.
- [x] Multiple-Landscape and identity scope is explicit and schema-ready.
- [x] Runtime schema and editor/runtime module boundary are frozen.
- [x] Blocking validation is programmatically enforceable.
- [x] Performance and UX budgets are measurable.
- [x] The initial reference baseline names its fixtures, hardware, metrics, commands, results, and retained evidence artifact.
- [x] No mandatory decision is deferred to a later phase. *(Unchecked by the
  2026-08-22 E0 review for F-01/F-02, then restored the same day: cell assignment,
  loose cell bounds, and acyclic ownership are now decided in `V7-ARCHITECTURE.md`
  §10. Phase 16 carries only the implementation task of fixing one canonical
  formula for a cell's stored bounds, not the decision itself.)*

## Risks

- FInstancedStruct behavior may not meet migration or cook requirements; failure requires changing the storage design now.
- Native Landscape keys and geometry fingerprints may still resolve ambiguously after topology edits; ambiguity must remain visible and block Apply rather than mutate source names/tags.
- A runtime schema optimized too early may harm extensibility; one left too generic may fail scale budgets.
- World duplication and cross-map residency can create valid-looking but incorrectly owned references.
- Reflected-type testing through Live Coding can hide restart and serialization defects.
