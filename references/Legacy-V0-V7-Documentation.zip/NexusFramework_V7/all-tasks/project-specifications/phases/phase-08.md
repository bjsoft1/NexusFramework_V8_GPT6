# Phase 08 — UI Completion Gate

## Status

In Progress

## Objective

Prove that the entire UI product—shell, menus, tree, details, CRUD, persistence, accessibility, reliability, and responsiveness—is genuinely complete before any Landscape/backend phase starts.

## Scope

- Integrated audit and correction of Phases 03–07.
- Real repository data, representative scale, restart behavior, failure states, and user manual acceptance.
- Freeze of UI/service contracts consumed by later systems.

## Out of Scope

- Landscape reader, mapping, generation, or runtime implementation.
- Passing placeholders because a later phase might wire them.
- Acceptance based only on screenshots or code review.

## Tasks

- [ ] Audit every menu, toolbar, shortcut, context action, tree control, details field, CRUD action, and state presentation.
- [ ] Remove or complete every placeholder, mock-only dependency, dead action, misleading badge, and false-success path.
- [x] Exercise real fixed and dynamic-array payload CRUD through save, close, restart, reload, undo, and redo. *F-08-15, user reading 2026-09-02: satisfied by the command-service-level proof — create/update/delete/undo/redo on a nested dynamic array, save/reload for fixed and array shapes, and a genuine three-process cold restart. No UI gesture creates the payload-carrying Activation Point and none is owed before Phase 14; `phases/phase-07.md` records the identical limit against its own near-identical task 3. The UI-authored half is verifiable only once Phase 14 delivers the gesture.*
- [x] Run representative large-tree responsiveness, memory, incremental refresh, search, sort, and multi-selection tests.
- [x] Test empty, loading, dirty, invalid, blocked, unknown-payload, stale, save-failure, and ownership-mismatch states. *Eight of nine are produced by a real editor condition and asserted against `FNexusEditorShellStateProvider`. F-08-06, user reading 2026-09-02: ownership-mismatch has no representation in the build and `phases/phase-10.md` reserves the condition it describes, so it defers to Phase 10 rather than being placeholdered into this gate.*
- [ ] Verify DPI, resize, contrast, keyboard navigation, focus restoration, shortcut discovery, tooltips, and screen readability.
- [ ] Verify destructive previews, affected counts, confirmations, cancellation, rollback, and action summaries.
- [ ] Produce a user-executed manual QA record and resolve every failure before sign-off.
- [ ] Freeze documented UI state, command, repository, selection, and diagnostics contracts.

## How to Test the Current Implemented Work

Phase 08 remains **In Progress**. These six checks cover the work implemented so
far; they are not the complete E3 run or acceptance. Run them only after the latest
source builds successfully.

The `dotnet.exe`/UnrealBuildTool startup failure that had blocked a combined build is
resolved on this workstation as of 2026-09-01: all three targets now build clean.
That first real combined build and test run found and fixed F-08-14, a defect
specifically in step 6 below — see
[the evidence](../evidence/phase-08-clean-gate-and-f08-14-2026-09-01.md). Step 6 now
passes; it did not before this fix, in any build.

1. **Open the current workspace.** In Unreal Editor choose **Window > Nexus
   Framework V7 > Open Default Workspace** → Hierarchy, Details, and Activity open
   together with Home visible.
2. **Check the collapsed large tree.** Run `Nexus.Fixture.LoadSample Large 808`, then
   press `Ctrl+Shift+P` and run **Collapse All** if it is enabled → only ten State
   roots are drawn. Switch Nexus tabs, open an editor menu, and expand/collapse
   **State 01** → after the one-time fixture load, the editor remains responsive and
   only the opened branch appears.
3. **Check deferred Details at scale.** Press `Ctrl+Shift+P`, run **Expand All**, then
   focus Hierarchy and press `Ctrl+A` → Details reports the full 100,000-item
   selection and the 1,000-item limit, with no property bindings, Copy ID, Apply, or
   Revert. Run **Clear Selection**, then **Collapse All**, and click one row → normal
   fields return.
4. **Check destructive confirmation on a real asset.** First run
   `Nexus.Fixture.Clear`; fixtures cannot test saving or recovery. Press
   `Ctrl+Shift+P` > **New Document**, create the default hierarchy, select a row,
   and press `Delete` → the
   preview names affected items and defaults to **Leave things as they are**. That
   choice changes nothing; the specific **Yes, ...** action deletes, and `Ctrl+Z`
   restores the row.
5. **Check refused inline rename.** Under **Default State**, create a second City,
   press `F2`, type **Default City**, and press Enter → the collision is refused but
   the edit box stays open with the typed text intact until you correct it.
6. **Check reload recovery and Home.** Correct the second City to a unique name and
   save. In Details, change its display name back to **Default City**, leave the
   blocked draft untouched for 10 seconds, then run `Ctrl+Shift+P` > **Reload
   Document** and accept its preview → the draft becomes recoverable instead of
   disappearing. Open Home: the strip says **DRAFT RECOVERABLE**, never **UNDO
   AVAILABLE**, and **Recover Draft**, **Review Recovery**, and **Discard Draft** are
   present; Discard previews first and Recover restores an unapplied draft.

Automated E2 command after a successful latest build:

    powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1 -SkipBuilds

Expected final line: `PHASE 08 E2: PASS (builds skipped; E1 not evaluated)`.

## Dependencies

- Phases 03, 04, 05, 06, and 07 Complete.

## Required Evidence

- E0: independent UI architecture and contract review.
- E1: clean editor build.
- E2: complete UI integration/regression suite and representative scale metrics.
- E3: user manual visual and interaction acceptance after a cold restart.

## Acceptance Gate

- [ ] All Phase 03–07 acceptance gates remain satisfied together.
- [ ] No required UI behavior is deferred to Phase 09 or later.
- [ ] No placeholder, dead command, mock-only path, or session-only persistence remains.
- [ ] Representative scale meets Phase 01 UI budgets.
- [ ] All manual UI checks are recorded and passed.
- [ ] User explicitly authorizes backend work to begin.

## Risks

- Pressure to begin backend work can normalize unfinished UI debt.
- A polished happy path can hide poor failure recovery and destructive-action trust.
- Scale failures discovered here may require tree/view-model redesign rather than tuning.

## Progress — 2026-08-28

First measurement pass. E1 and E2 only; no E0, no E3, no clean builds.

Started while Phases 05, 06, and 07 are Ready for Review rather than Complete, on the
user's instruction, the same way Phase 06 and Phase 07 each started on an unmet
dependency. The Dependencies line above is not satisfied.

The responsiveness and scale task is done and is the one task that had no evidence at
all behind it: its gate item says "Representative scale meets Phase 01 UI budgets" and
`Nexus.V7.Hierarchy.Scale` disclaims, in its own comment, being that measurement. The
new `Nexus.V7.UiGate` suite measures the `V7-UX-SPEC.md` section 19 and
`V7-ARCHITECTURE.md` section 12 budgets at 100,000 rows and records them to a dated,
digested artifact.

Measuring found four blocking defects. Three are fixed:

- **F-08-01** — four sort tie-breakers formatted two GUIDs into strings per
  comparison; ~3.4 million allocations to sort the reference tree. Sort 411.6 → 28.7 ms.
- **F-08-02** — the row filter built four strings per row before knowing which the
  query needed. Search worst keystroke 617.2 → 181.4 ms.
- **F-08-03** — three quadratic paths on the selection route. Select All Visible, a
  Phase 05 command bound to a chord, would have hung the editor on the reference tree.

One is open and failing:

- **F-08-04** — Details builds a draft proxy for every selected entity eagerly.
  Section 19 requires details to be "calculated incrementally afterward if needed" and
  there is no such path, so Select All costs 1264 ms. Closing it changes a contract
  Phase 06 owns, which is the user's decision.

Two audit findings need an owner's reading rather than code: **F-08-05**, whether
"no required UI behavior is deferred to Phase 09 or later" outlaws the catalog's 16
deliberate pending-phase commands; and **F-08-06**, whether the ownership-mismatch
state belongs to this phase or to the Phase 10 reservation that already claims it.

Evidence: [Phase 08 UI gate first pass](../evidence/phase-08-ui-gate-2026-08-28.md).
Script: `Scripts/VerifyPhase08UiGate.ps1`.

## Progress — hierarchy ladder narrowed, 2026-08-28

Part of "integrated audit and correction of Phases 03–07", and deliberately ahead of
"freeze documented UI state, command, repository, selection, and diagnostics
contracts" further up this page: the entity-kind registry is one of the contracts
that freeze covers, so narrowing it afterwards would have been a break rather than a
correction.

The ladder is **State > City > Highway > Highway Point**, adjacent only. The root
takes a State, because the document is itself the world. `World`, `Road`, `Junction`,
and `SubPoint` are retired from the ladder while remaining enum values — Road and
Junction return in a later phase as a *type* of highway point, `phases/phase-14.md`
still owns sub-points, and `World` keys the document in the Reload and Close previews.

Structural legality and hand-creatability are now separate questions. A Highway Point
is a legal child of a Highway — Phase 10 writes them from landscape geometry — and is
withheld from every Create surface, so `IsLegalChild` and `GetCreatableChildKinds`
disagree on exactly that one pair and on nothing else.

Default names carry a number: `New City 3`, counted across the document so no two
rows in one tree read `New City 1`.

E1: clean editor build. E2: 125 tests, 0 failures on the Phase 07 sweep — the extra
one over the 124 baseline is `Nexus.V7.Crud.DefaultNaming`. The full gate sweep is
134 passing with `Nexus.V7.UiGate.SelectAllAtScale` still failing on F-08-04, which
is unrelated and was already open.

**Not E3, and the E3 debt grew.** Checks 2, 17, and 20 of the Phase 07 manual
checklist asserted the eight-rung ladder and a Create World button. They are amended
in place, marked with the date, and still need a person to run them. Nothing else on
that page moved.

## Progress — presentation states, 2026-08-28

E1 and E2 only. The state task above is eight-ninths done: every state named in it
except ownership-mismatch is now produced by a real editor condition and asserted
against the real `FNexusEditorShellStateProvider`, not against hand-built signals.

The task already had tests behind it — `Nexus.V7.Shell.StateDerivation` and
`Nexus.V7.Shell.StatePresentation` cover all nine shell states exhaustively — and they
answer a different question. They assign `FNexusShellSignals` directly, so they prove
the derivation and the wording are right and say nothing about whether the editor can
ever produce those signals. A state can be fully derived, fully presented, and
unreachable, with every test green.

**F-08-09, Blocking, fixed.** `ENexusShellState::Stale` was exactly that.
`GetSignals` read `bSourceStale` from a member nothing in the editor had ever written;
`SetSourceStale` had no caller. Meanwhile `FNexusDetailsView::IsDraftStale` detects
the condition the state describes and Apply refuses while it holds — so the panel said
the edit could not be committed and the shell said `Dirty`. `GetSignals` now reads the
Details view, the provider subscribes to `OnChanged` so a reload *clears* the state,
and a "Pending edits" health line distinguishes it from the Phase 09 landscape source
that still owns the member. Verified by disabling the fix and watching the new test
fail.

Three more, all fixed: **F-08-10**, a same-day re-run of the gate script overwrote the
budget artifact the first pass cites by SHA-256 — the label now carries a time and the
copy refuses rather than forces; **F-08-12**, a C5038 warning inside what E1 calls a
clean editor build; **F-08-13**, a test of this pass's own opened a modal dialog in an
unattended run and left an asset behind on every run.

**F-08-06 is narrowed, not closed.** Ownership-mismatch has no representation in the
build at all, and `phases/phase-10.md` reserves it. Building one here would be a
placeholder, which this gate forbids. Either this task line defers to that reservation
or the reservation gives it up; it cannot be tested either way.

E2: 143 of 144 pass. The one failure is `Nexus.V7.UiGate.SelectAllAtScale`, which is
F-08-04 and open by design.

Evidence: [Phase 08 presentation states](../evidence/phase-08-ui-states-2026-08-28.md).

## Decisions — 2026-08-28

The user answered two of the three findings that needed a reading rather than code.

**F-08-05 is closed. The pending-phase commands stay.** "No required UI behavior is
deferred to Phase 09 or later" means *nothing Phases 03–08 owe is deferred*. A command
that answers "Phase 12 delivers this" is telling the truth and is not a dead item, so
the catalog keeps its Phase 10–16 entries and keeps refusing by name. The acceptance
gate item is read as satisfiable on those terms.

**The hierarchy is confirmed as `State > City > Highway > Points > Activation Point`,
with the bottom two deliberately not hand-creatable.** Highway Points auto-sync from
the landscape in Phase 09/10; Activation Points arrive with Phases 12 and 14. On a new
document the Create menu offers State, City, and Highway and then stops, and that is
the intended shape rather than a gap this gate has to close. `V7-ARCHITECTURE.md`
§"Entity kind legality" carries the confirmed wording.

Also verified against the code while answering, and correct as described: nothing
autosaves the `.uasset` — a finished property edit auto-commits into the *document*
and marks it dirty, a ten-second idle timer writes a crash-recovery copy of unapplied
drafts under `Saved/`, and only the Save command writes the asset. Undo and redo
re-mark the document dirty and reload Details from what the undo left behind.

**F-08-06 is still open.** Ownership-mismatch remains the one state in the task list
above with no representation in the build and a Phase 10 reservation over it.

## Progress — bounded Details selection, 2026-08-31

**F-08-04 — Blocking, fixed at E2.** The Details path had eagerly created a baseline
and a draft proxy for every selected item, so a real 100,000-item Ctrl+A allocated
and bound a proxy set that could neither meet the responsiveness budget nor honestly
be treated as incremental. Details now fully materializes an interactive selection of
at most 1,000 entities. A larger selection preserves every ordered key but enters
SelectionDeferred: native Details is unbound, the panel gives an explicit
summary-only message, and field editing, Apply, Revert, and revert preview refuse
until the selection is narrowed.

No representative prefix is bound or applied. A pre-existing dirty proxy for a
still-selected entity may remain dormant solely for recovery while the large summary
is shown and is revision-checked when narrowed back into an interactive selection.
Drafts outside the active binding retain their baselines for exact recovery capture,
and a recovery record over the interactive bound restores into that safe parked store.
During the same trace, the real UNexusEditorSubsystem selection handoff was found to
deduplicate with an O(n-squared) ordered Contains loop; it now uses an
order-preserving set, and a regression follows the actual subsystem route rather than
only invoking the Details view directly.

The Phase 06 contract correction is recorded in V7-UX-SPEC.md sections 7.4, 8, 17.3,
and 19; V7-ARCHITECTURE.md section 7; and phase-06.md with its amended unrun E3
checklist. It does not make Phase 06 accepted or waive any Phase 08 dependency or
human gate.

E2 ran Scripts\VerifyPhase08UiGate.ps1 with -SkipBuilds and run label
2026-08-31-f08-04-r5: 148 tests passed with 0 failures; all 21 budget measurements were
within their assertions. The 100,000-item Details summary measured 3.578 ms against
its 300 ms ceiling and the actual hierarchy-to-subsystem-to-Details route measured
7.726 ms against its 100 ms ceiling. A separate non-clean NexusFrameworkEditor Win64
Development compile succeeded in 17 actions, but is non-gating evidence only. The
automation invocation correctly reports E2 only because it skipped builds. Evidence
and artifact digest are in evidence/phase-08-large-selection-2026-08-31.md.

Phase 08 remains In Progress. E0 and E3 have not run; seven task lines remain
unchecked or partial; the clean-build evidence is incomplete; and F-08-06 still
requires the user's decision.

## Progress — collapsed large-tree idle lag, 2026-08-31

A user run of `Nexus.Fixture.LoadSample Large 808` found a gap the prior scale
measurements did not exercise: after the fixture loaded, the whole editor remained
laggy even while the hierarchy looked collapsed. `SListView` was virtualizing row
widgets, but `FNexusHierarchyView::GetRowsInView` still reserved and scanned the full
100,000-key filter order on every view broadcast. The hidden Filters section also
allocated its own invisible row-key objects, and Slate-bound shell getters repeated
whole-document save-safety validation and recovery-directory reads during painting.

The implemented correction keeps the complete logical snapshot for search, reveal,
stable identity, and unresolved-row safety, but lazily materializes the draw list from
roots and descends only into explicitly expanded branches in the default authored
view. The result is cached across selection-only broadcasts. The Filters panel no
longer owns an invisible row list, and the real tree reuses its row-key objects when
only selection visuals change. Authored `SortOrder`/stable-ID order is preserved while
sorting only sibling sets on opened branches. Collapsing/clearing a broad query
releases the large visible-row and expansion allocations. Shell validation and
document-info snapshots are cached by document identity, revision, dirty state, and
recovery time, so several badge/label reads in one paint do not each scan the document.

`Nexus.V7.Hierarchy.VisibleRowsCache` asserts that the collapsed Large fixture visits
and materializes ten roots, that opening one root visits only its direct visible
branch, and that repeated reads and selection broadcasts do not traverse again.
The same regression compares the lazy mixed entity/activation branch against the
established authored filter order.
`Nexus.V7.UiStates.LargeDocumentStateReadsAreCached` asserts repeated live Slate-state
reads perform one document validation and one document-info build. Both tests and the
latest source are currently **unbuilt and unrun** because the local `dotnet.exe`
application error prevents UnrealBuildTool from starting. This is implementation
evidence, not E1/E2 acceptance. See
[the focused evidence record](../evidence/phase-08-large-hierarchy-idle-lag-2026-08-31.md).

## Progress — large row-menu hover lag, 2026-08-31

The collapsed-tree correction exposed a separate command-surface scale failure.
After `Nexus.Fixture.LoadSample Large 808`, right-clicking a State and moving the
pointer through the row menu repeatedly stalled the editor. Slate polls shared
command enablement while painting and the hovered tooltip asks for the disabled
reason. `CanInitiate` built a complete destructive preview on each of those reads,
so Delete rescanned the 100,000-record document and formatted the selected State's
thousands of affected items over and over before any click occurred.

Command handlers now expose a cheap `SupportsPreview` capability. Live eligibility
still evaluates the current ordinary guard and disabled reason, but destructive
initiation only checks that capability. The actual consequence is built only after
the user invokes the command. Confirmation and execution keep the current guard,
command identity, valid-token, and document-revision checks; an otherwise-valid
approval also verifies that a state-dependent preview still succeeds, outside the
paint path.

`Nexus.V7.Command.DestructiveConfirmation` now performs 128 menu-style initiation
polls and requires zero calls to `BuildPreview`; explicit and approved backend
preview checks are counted separately. The latest source and updated test are
**unbuilt and unrun** because the local `dotnet.exe` application error still
prevents UnrealBuildTool from starting. This is implementation evidence only. See
[the focused evidence record](../evidence/phase-08-large-context-menu-hover-2026-08-31.md).

### How to Test This Correction After the Latest Source Builds

1. Open **Window > Nexus Framework V7 > Open Default Workspace** and show the
   **Hierarchy** tree → the row menu is available.
2. Enter `Nexus.Fixture.LoadSample Large 808` and wait for ten collapsed State roots
   → fixture construction is finished before measuring interaction.
3. Right-click **State 01** → the row menu opens promptly without a document-sized
   pause.
4. Sweep the pointer across **Duplicate**, **Revert Draft**, **Delete**, and Context
   entries for ten seconds → highlights and tooltips remain smooth.
5. Press **Escape**, select **State 02**, and reopen the menu → command states and
   disabled reasons reflect the new selection.
6. Enter `Nexus.Fixture.Clear` → the synthetic fixture is removed and the empty
   state returns.

## Progress — first full clean E1+E2 pass, and F-08-14, 2026-09-01

The local `dotnet.exe`/UnrealBuildTool startup failure that had left the two
2026-08-31 lag fixes above unbuilt and unrun is resolved on this workstation. This is
the first time the collapsed-tree-lag fix, the row-menu-hover-lag fix, and the
bounded-Details correction have all been built and run together.

**F-08-14, Blocking, fixed.** That first real run — with clean builds rather than
`-SkipBuilds` — failed `Nexus.V7.Crud.RecoveryBeforeReload` with *"None of the
autosaved fields could be restored."* This test was added in the same commit as the
bounded-Details correction but after that commit's own evidence run had already
finished, so it had never actually executed before; this was not a regression from
the two lag fixes.

Root cause: `UNexusEditorSubsystem::SetActiveDocument`'s `ActiveDocument ==
InDocument` no-op guard is fooled by `UPackageTools::ReloadPackages` (called from the
Reload command), which silently repoints the still-rooted `ActiveDocument` pointer at
the newly reloaded object *before* Reload's explicit `SetActiveDocument` call runs.
The guard then reads that as "nothing changed" and skips rebinding the Details
repository, leaving it pointed at the pre-reload object the reload just destroyed —
so `Recover Draft` cannot find any entity to restore into. Fixed with a
`bForceRebind` parameter on `SetActiveDocument`, passed `true` only from the Reload
path; every other caller keeps the old fast-path behavior. Verified by reproducing
the failure in isolation with diagnostic logging before fixing it, then confirming
the full `Nexus.V7.Crud` suite (22 tests) passes afterward with no other regressions.
Full account: [evidence](../evidence/phase-08-clean-gate-and-f08-14-2026-09-01.md).

E1: three clean builds (`NexusFrameworkEditor`/`NexusFramework` Development,
`NexusFramework` Shipping). E2:
`Scripts\VerifyPhase08UiGate.ps1` (no `-SkipBuilds`) — 154 tests, 0 failures; 21
budget measurements, 0 over. `PHASE 08 E1+E2: PASS`.

**Still open.** E0 and E3 have not run. F-08-06 and F-08-15 (below) still need the
user's reading. Seven of the nine task lines above remain unchecked or partial.

### How to Test This Correction

1. Open **Window > Nexus Framework V7 > Open Default Workspace**, press
   `Ctrl+Shift+P` > **New Document**, and create the default hierarchy → a State,
   City, and Highway appear in Hierarchy.
2. Select the State, open Details, change its display name, and let it auto-commit
   (click elsewhere or wait a moment) → the context strip shows unsaved changes.
3. Press `Ctrl+Shift+P` > **Save Document** → the strip shows the document as saved.
4. In Details, change the State's display name again but do **not** save.
5. Press `Ctrl+Shift+P` > **Reload Document** and accept its preview → the edit is
   gone from the field, and Home shows **DRAFT RECOVERABLE**.
6. Open Home and press **Recover Draft** → the State's Details field shows your
   unsaved edit again, restored rather than lost. This is the exact path that failed
   before this fix and now succeeds.

Automated regression:

    powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase08UiGate.ps1

Expected: `PASS: 154 tests, 0 failures`, `PHASE 08 E1+E2: PASS`, and `PASS: Nexus.V7.Crud - 22 results` in particular.

## F-08-15 — payload CRUD task line is untestable through the UI, needs a reading — 2026-09-01

Checking task line 3 above found the same shape of gap as F-08-06: the task asks to
"exercise real fixed and dynamic-array payload CRUD through save, close, restart,
reload, undo, and redo," and **no UI gesture creates the payload-carrying entity at
all**. `NexusCommandCatalog.cpp` has zero occurrences of `Activation` anywhere — not
even as one of the sixteen deliberately-registered pending-phase commands F-08-05
covers, so this absence is stronger than those. `FNexusActivationPointCommandService`
exists and is tested; nothing in the UI calls it. This confirms
[[the-bottom-two-rungs-are-not-hand-authored]] at a different task line than the one
it was first recorded against.

**This is not a new fact — `phases/phase-07.md` already records it against its own,
near-identical unchecked task 3** ("restart tests with fixed and dynamic-array
payload data created **entirely through the UI**"), with the deliberate-omission note
that activation points are not creatable from the UI until Phase 14. Phase 08's task
3 asks for the same thing without the words "through the UI," and nothing in this
ledger had yet said explicitly that the same limit applies here too.

**What is provably true today, at the command-service level, not through the UI:**

- Create/undo/redo/update on a payload with a nested dynamic array:
  `Nexus.V7.Foundation.ActivationPointCrudTransactions`
  (`NexusTests/Private/NexusCommandTests.cpp:47`).
- Save/reload for both a fixed-shape and an array-shape payload:
  `Nexus.V7.Foundation.RealAssetCrudRoundTrip`
  (`NexusTests/Private/NexusPersistenceTests.cpp:283`).
- A genuine **cold restart across three separate `UnrealEditor-Cmd.exe` processes**,
  not a same-process reload: `Nexus.V7.ColdRestart.01_Prepare` /
  `02_VerifyAndMutate` / `03_FinalVerify`
  (`NexusPersistenceTests.cpp:368,385,443`), orchestrated by
  `Scripts\VerifyPhase01ColdRestart.ps1`. This exists and works; it has just never
  been pointed at UI-authored activation-point data, because there is no UI gesture
  that authors any.
- The Details reflection path already proves it can diff/apply a payload scalar and a
  nested array generically (`Nexus.V7.Details.GenericFieldPath`), but that test
  drives it against an ordinary entity's incidental `Payload` field, not a real
  Activation Point — production entities have no `TypeKey` and nothing ever sets
  that field outside the test.

**What cannot be verified until Phase 14:** payload data authored by an actual click
in the editor, round-tripped through save/close/restart/reload/undo/redo as a user
would experience it — because the click to create it does not exist yet.

**Needs the user's reading, same as F-08-05/F-08-06 were.** The question is whether
task 3 is satisfied by this service-level proof plus Phase 07's already-recorded
omission, or whether it stays open/unchecked until Phase 14 delivers the UI gesture.
Recorded rather than decided, per `agent-memory/v7-phase-governance.md`.

## F-08-16 — Revert Draft was wiping unrelated kept drafts, and a wrong test assertion — 2026-09-02

**Blocking, fixed.** `FNexusDetailsView::Revert()` unconditionally reset every parked
`KeptDrafts` entry as a side effect of reverting the *currently selected* target, so
reverting one entity's unapplied edit silently discarded unrelated unapplied work
elsewhere in the document — while Revert's own preview only ever named the selected
entity, so nothing warned the user the parked work was at risk. Separately, a
successful destructive command left Activity with only the bare status word
("Completed"): `Execute()` passed a `Message` to `OperationHistory.Complete` on
failure only. Both fixed in commit `bd92ac6`. `Revert()` now leaves `KeptDrafts`
untouched — `DiscardKeptDrafts()` remains the explicit, separate operation for
clearing parked work — and `Execute()` reuses the `FNexusCommandPreview` that
`CheckConfirmation` already built and verified against the approval to populate both
the Activity message and a new `TargetSummary` (named items when three or fewer, a
count otherwise) instead of rebuilding a possibly document-sized preview a second
time.

**Re-running the gate caught a wrong assertion in the regression test that shipped
with the fix, not a second production defect.**
`Nexus.V7.Details.RevertLeavesKeptDrafts` asserted `Fixture.View().IsDirty()` was
`false` immediately after reverting the selected target, while an unrelated kept
draft for a different entity was still legitimately dirty. `IsDirty()` is
document-wide by design — it walks `KeptDrafts` as well as the bound `Targets`, which
`Nexus.V7.Details.LargeSelectionDeferred` already establishes elsewhere in the same
file — so it correctly stayed `true`. `GetDirtyTargetCount()`, which counts only the
currently-bound `Targets`, is the assertion that actually answers "did Revert clear
the target it ran against"; the test now checks that instead. No production code
changed for this correction, and every other assertion in the test — that the parked
draft survives with its actual value intact — was already correct.

**Verified by re-running the exact gate, not by inspection**, per
[[verify-claims-by-re-running]]: the first full clean run
(`2026-09-02-104526`) failed exactly this one assertion with three clean builds and
every other suite green; after the one-line test fix, a second full clean run
(`2026-09-02-104935`) passed outright — `PASS: 156 tests, 0 failures`, `PASS: 21
budget measurements, 0 over`, `PHASE 08 E1+E2: PASS`. Details' suite count moves from
26 to 28, exactly the two tests this commit added; no other suite's count moved. Full
account: [F-08-16 evidence](../evidence/phase-08-f08-16-revert-scope-2026-09-02.md).

## Independent review — 2026-09-02

An E0 independent architecture and contract review was performed against the tree
this phase has produced so far (Phases 03–08's UI/service code, plus the F-08-16 fix
and its evidence). It independently reproduced the 156-test/21-budget clean pass
current at the time, confirmed F-08-06 and F-08-15's characterizations directly
against source, and accepted the destructive-confirmation gate, the `Revert()` fix,
and the bounded-Details mechanism without qualification. It also filed three new
findings: E0-01 (Blocking, closed below as F-08-17), E0-02 (Warning — the F-08-16
Activity-summary fix reaches only destructive commands; every other successful
command, Apply included, still logs the bare word "Completed"), and E0-03 (Warning —
Home's onboarding widget has two badges hardcoded to `Empty` and text still
describing already-shipped Phase 05/06 work as a future phase delivery). The review
did not accept Phase 08 and did not move it to Ready for Manual QA — both because its
own outstanding task list remains and because of E0-01. Full record:
[E0 independent review](../evidence/phase-08-e0-independent-review-2026-09-02.md).

## F-08-17 — Undo/Redo discarded unrelated drafts (E0-01) — 2026-09-02

**Blocking, fixed.** The independent E0 review above filed E0-01: Undo and Redo
silently discarded every unsaved Details edit in the document, including parked
"kept" drafts with nothing to do with the transaction being undone — the same defect
shape F-08-16 had just fixed in `Revert()`, still present in a far more common,
ungated path (native engine undo bypasses `CheckConfirmation` entirely). Closed here
as F-08-17.

`UNexusEditorSubsystem::RefreshAfterUndo` called `Repository.NotifyChanged(Hierarchy,
{})` — which already broadcasts synchronously to `FNexusDetailsView::HandleRepositoryChanged`,
parking and reclaiming a dirty currently-selected draft exactly as every other
repository-driven refresh does — and then, redundantly, a separate
`FNexusDetailsView::Get().ReloadFromSource()`, which unconditionally resets
`KeptDrafts` with no reclaim step of its own, undoing what the first call had just
done correctly. Fixed by deleting the redundant second call; `NotifyChanged` alone
was already sufficient.

**The new regression test failed twice for reasons that had nothing to do with the
fix**, both found by re-running rather than trusting the result. A real
`SNexusHierarchyTree` widget — alive in this editor process from workspace/layout
restoration even under `-unattended -NullRHI` — shares the process-global
`FNexusHierarchyView::Get()` singleton with the test. Diagnostic logging and a
captured callstack showed it reacting to the test's own repository broadcast by
pushing its own, unrelated selection back onto the subsystem, clobbering the exact
state the test was checking, regardless of whether the test set selection via
`FNexusDetailsView::Get().SetSelection` or `Subsystem->SetSingleSelection`. Fixed in
the test only, by detaching `FNexusHierarchyView::Get()` from the repository for the
test's duration and rebinding it afterward to exactly what
`UNexusEditorSubsystem::Initialize` leaves it as.

E1: three clean builds. E2: `Scripts\VerifyPhase08UiGate.ps1` — `PASS: 157 tests, 0
failures`; `PASS: 21 budget measurements, 0 over`; `PHASE 08 E1+E2: PASS`. Crud's
count moves from 22 to 23, exactly the one new test. Full account:
[F-08-17 evidence](../evidence/phase-08-f08-17-undo-redo-scope-2026-09-02.md).

E0-02 (the F-08-16 Activity-summary fix reaches only destructive commands) and E0-03
(Home's onboarding badges are stale) from the same review are recorded but not acted
on here.

## F-08-18 — Home's onboarding badges and text made honest (E0-03) — 2026-09-02

**Warning, fixed.** Two of Home's four onboarding badges (`SNexusHomeView`) were
hardcoded to `Empty` regardless of the real document or editor state, and two of the
four step bodies said "...arrive with Phase 05" / "...arrive with Phase 06" —
correct when this widget was first written in Phase 03, before those phases existed,
never revisited once they shipped.

Extracted the whole computation into a new pure function,
`SNexusHomeView::ComputeOnboardingSteps`, the same shape as `DeriveShellState`, with
no Slate dependency. Steps 3 and 4 now reuse the same `ContentStep` signal step 2
already computes (`EntityCount > 0`) — editing a property and reviewing
activity/diagnostics both need an entity to act on, exactly like building the
hierarchy does, so this is an honest reuse of an already-real signal rather than an
invented one. Steps 2 and 3's text now describes the capability as delivered rather
than arriving with a named phase.

**Test coverage for this widget goes from zero to one**, per the review's own note
that nothing had ever tested it. `Nexus.V7.Shell.HomeOnboardingReflectsRealState`
asserts all three document states (no document / bound with no content / bound with
content) against all four steps, and that no body claims a future phase once ready.

E1: three clean builds. E2: `PASS: 158 tests, 0 failures`; `PASS: 21 budget
measurements, 0 over`; `PHASE 08 E1+E2: PASS`. Shell's count moves from 20 to 21,
exactly the one new test. Full account:
[F-08-18 evidence](../evidence/phase-08-f08-18-home-onboarding-2026-09-02.md).

## F-08-19 — every successful command records what it did, not "Completed" (E0-02) — 2026-09-02

**Warning, fixed.** The 2026-09-02 E0 review's E0-02: F-08-16 taught
`FNexusCommandService::Execute` to write a real Activity message and target summary
by reusing a destructive command's *confirmed preview* — but a non-destructive
command builds no preview, so Apply, Create, Rename, Reparent, Duplicate, Save,
New/Open/Close, Undo and Redo still fell through to
`FNexusOperationHistory::Complete`'s bare status word ("Completed" on the row's
detail line, "no explicit target" on its origin line), which is the everyday case,
not a corner one. Closed here as F-08-19.

Per the user's direction, the fix is one place and changes no contract: a new
`SummariseSuccessfulCommand` helper in `NexusCommandService.cpp`, called for exactly
the `else` branch that previously wrote nothing. It resolves `Result.ChangedIds`
against the live document to `"DisplayName (Kind)"` — named when three or fewer, a
count past that, the F-08-16 threshold — for both the message and the target summary;
failing that, a `RefreshHint::Document` or a `DocumentId` in `ChangedIds` gives "the
active document"; failing that, a view-only command or a valid no-op is recorded by
its own name rather than by status. The document pointer is `::IsValid`-checked
before it is read, because Close and Reload can leave `Context.Document` pointing at
a replaced object. `FNexusCommandResult` gains no field; `Complete`'s fallback is
untouched and is now effectively unreached on the command-service success path.

`Nexus.V7.Command.SuccessfulCommandRecordsSummary` (new) asserts the recorded entry
for five result shapes — one named entity, several named entities, a document-level
command, a valid no-op, and an id the document no longer holds — none of which may
record the "Completed" / "no explicit target" fallback. The F-08-16 destructive-path
test is unchanged and still green.

E1: three clean builds. E2: `Scripts\VerifyPhase08UiGate.ps1` — `PASS: 159 tests, 0
failures`; `PASS: 21 budget measurements, 0 over`; `PHASE 08 E1+E2: PASS`. Command's
count moves from 17 to 18, exactly the one new test. Full account:
[F-08-19 evidence](../evidence/phase-08-f08-19-activity-summary-2026-09-02.md).

With E0-01 (F-08-17), E0-03 (F-08-18) and E0-02 (F-08-19) all closed, and E0-04
Information-only, every finding from the 2026-09-02 independent review is now acted
on. Phase 08 remains In Progress: E3 has not run. F-08-06 and F-08-15 were answered
on 2026-09-02 — see the decisions section below.

## Backlog raised during Phase 08 — 2026-08-28

Three design items were stated by the user while answering the questions above. None
is Phase 08 work and none is approved for implementation; they are recorded in
[the backlog](../backlog/README.md) so the owning phase inherits them.

**[B-01](../backlog/B-01-world-root-row.md) is the one with a Phase 08 bearing.** A
`Nexus World` root row — one, at index 0, rename-only, never created or deleted — is
where the global mesh settings are meant to live. It reintroduces a row this phase
retired earlier the same day, and the hierarchy root shape is one of the contracts the
freeze at the end of this phase covers. Landing it before the freeze is a correction;
landing it after is a contract break that reopens the owning checkpoint. **That timing
is a decision for the user, not a scheduling accident**, and the item says so rather
than assuming either way.

[B-02](../backlog/B-02-highway-mesh-info-cascade.md) is the mesh catalog and its
Global > State > City > Highway fallback chain; [B-03](../backlog/B-03-highway-point-attributes.md)
is what a synced highway point carries instead — junction type, developer code name,
and feature flags.

**A direction review the same day added two more, and one of them bears on the freeze
directly.** [B-05](../backlog/B-05-lane-and-width-data-model.md): lane count, lane
width, and walkable width exist nowhere in the repository, while Phase 11 plans to query
them, Phase 13 plans to generate from them, and B-02 selects meshes by lane count. A
consumer, a generator, and a selector, with no producer and no field.
[B-04](../backlog/B-04-landscape-vertical-slice.md): no Landscape code exists at all --
`NexusLandscapeEditor` is a 24-line stub -- so the contracts this phase is about to
freeze have never met the data they describe. B-04 proposes one thin slice to find that
out while corrections are still cheap, and names the governance decision it needs first.
Full assessment: [direction review](../evidence/direction-review-2026-08-28.md).

## Decisions — 2026-09-02

The two task lines that needed an owner's reading rather than code are answered. Both
were asked as plain questions and answered directly; neither changes a contract, and
both resolve the way an earlier Phase 08 reading (F-08-05) did — carve the untestable
part out to the phase that already owns it, rather than leave it open or placeholder
it here.

**F-08-06 — CLOSED. Ownership-mismatch defers to Phase 10.**

> User, 2026-09-02: defer to Phase 10.

The ownership-mismatch shell state has no representation anywhere in the build, and
`phases/phase-10.md` already reserves the condition it describes. Task line 5 is read
as satisfied by the eight states a real editor condition produces and that are
asserted against the real `FNexusEditorShellStateProvider`; ownership-mismatch is
explicitly carved out to the Phase 10 reservation. Building a representation inside
this gate would be the placeholder the gate forbids.

**F-08-15 — CLOSED. The payload-CRUD task line is satisfied by its service-level proof.**

> User, 2026-09-02: satisfied by service-level proof + Phase 07 omission.

Task 3 is proven at the command-service level —
`Nexus.V7.Foundation.ActivationPointCrudTransactions` (create/update/delete/undo/redo
on a nested dynamic array), `Nexus.V7.Foundation.RealAssetCrudRoundTrip` (save/reload,
fixed and array shapes), and `Nexus.V7.ColdRestart.01/02/03` (a genuine three-process
cold restart, not a same-process reload). No UI gesture creates the payload-carrying
Activation Point and none is owed before Phase 14; `phases/phase-07.md` records the
identical limit against its own near-identical task 3. The UI-authored half is
verifiable only once Phase 14 delivers the gesture.

**Where this leaves Phase 08.** Still **In Progress**. Three of nine task lines are now
done (3, 4, 5). The six that remain — the menu/placeholder audits (1, 2), the
DPI/keyboard/contrast and destructive-preview verifications (6, 7), the user-executed
manual QA record (8), and the contract freeze (9) — are E3-gated or the freeze itself.
No finding now waits on the user; E3 does, and Phase 08's E3 subsumes the outstanding
E3 for Phases 05–07.
