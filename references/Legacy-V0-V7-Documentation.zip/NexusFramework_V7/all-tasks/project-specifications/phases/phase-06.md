# Phase 06 — Details Panel

## Status

Ready for Review

## Objective

Provide a clear, powerful inspector for base records and heterogeneous payloads, with safe editing, understandable inheritance, validation feedback, and synchronized selection.

## Scope

- Selection summary, breadcrumb, property categories, dynamic FInstancedStruct payload inspection, arrays, multi-selection, reset/default, read-only computed data, help, and validation.
- Draft working copies, continuous validation, property diff, impact preview, Apply, Revert, and edit-intent handoff to services.

## Out of Scope

- Final create/duplicate/delete workflows.
- Landscape geometry editing.
- Runtime activation or generation-specific gizmos.

## Tasks

- [x] Bind details content by stable selected ID, never by transient row or array address.
- [x] Show identity, ownership, hierarchy, source, base fields, payload fields, and computed fields in intentional categories. Categories come from `UPROPERTY` metadata on the edit proxies, so the panel and the property view cannot disagree about where a field belongs.
- [x] Render registered FInstancedStruct payloads, nested structs, fixed sub-points, and dynamic arrays generically. One reflection walk over `CPF_Edit` properties answers diff, mixed-value, and apply for every shape.
- [x] Support safe multi-selection with mixed-value presentation and explicit batch-edit scope. Batch Apply is atomic and skipped targets are listed before it runs. `Apply Valid Targets Only` is deliberately not offered: V7-UX-SPEC.md section 8.3 permits it only where an operation declares partial application safe, and none does yet.
- [x] Keep property edits in a draft until Apply; show material diffs, downstream impact, validation, conflict, and stale-impact state. The Impact and Diff drawers section 8.1 calls optional are not built — section 10.1 states an ordinary single-item property Apply does not require one, and every case that does require one belongs to Phase 07.
- [x] Implement Revert against the draft only and Apply as one service request, never direct widget mutation.
- [x] Add reset-to-default, inherited/overridden indicators, property help, units, constraints, and validation messages. Help, units, and constraints are `UPROPERTY` metadata rather than a parallel help system. **Inherited/overridden indicators are deliberately absent**: nothing in the persisted record carries inheritance at this phase, and deriving an indicator from something plausible is what Phase 05 refused to do for its five unsourced badges.
- [x] Synchronize tree selection, breadcrumb navigation, details, and selection clearing.
- [x] Route changes through transaction/validation services and expose dirty state immediately.
- [x] Handle deleted, missing, invalid, unknown-payload, and read-only targets without crashing or discarding data.

## How to Test

Six steps. The first two are automated and take about three minutes; steps 3-6 are
where this phase has broken before — an interactive property write once killed undo
for the whole session with every test green. The full manual run is
`evidence/phase-06-e3-manual-checklist-2026-08-23.md`.

1. **Run the gate.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase06Details.ps1 -SkipBuilds`
   → expect every listed suite to pass and `PHASE 06 DETAILS: PASS`.
2. **Run the structural scan.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyFoundation.ps1`
   → expect `FOUNDATION STRUCTURAL SCAN: PASS`.
3. **Make a real document and edit a property.** `Ctrl+Shift+P` → **New Document**
   (not `Nexus.Fixture.LoadSample`: a fixture is in-memory, so it cannot be saved
   and the dirty state below never appears). Select an entity, change a property,
   press Enter.
   → the footer reads **"Applied — the asset is not saved yet"**, and the context
   strip shows amber `UNSAVED` beside a **Save** button. "Applied" is not "saved":
   nothing reaches disk until you press it.
4. **Undo it, then undo again.** `Ctrl+Z` twice, then `Ctrl+Y` twice.
   → each press moves one step and **undo keeps working for the rest of the
   session**. Drag a slider and release before testing this: an interactive write
   that leaves a transaction open kills undo silently, which is bug 4 in
   `agent-todos/ready-for-review/bugs-redu-undo__scape-click.md`.
5. **Press `Escape` mid-edit, then click away and back.**
   → the field resets to its committed value and **stays** reset. It used to come
   back on the next focus change.
6. **Select two entities of different kinds.** `Nexus.Fixture.LoadSample Normal` is
   the quickest way to get a mixed tree for this one.
   → shared properties edit together, differing values read as multiple, and the
   banner says how many are selected and what will change.

## Contract correction — 2026-08-31

The Phase 08 scale gate found that eagerly creating the Phase 06 baseline/draft proxy
pair for every item in a real Ctrl+A selection does not meet the Details budget. The
interactive Details contract is now bounded at 1,000 selected entities: at or below
that size, full multi-edit behavior is unchanged. Above it, the entire ordered
selection remains selected but Details enters a summary-only state; property bindings,
editing, Apply, and Revert are unavailable until the user narrows the selection.

It must not bind or apply a representative prefix. A pre-existing dirty proxy for a
still-selected entity may remain dormant solely for recovery while the summary is
shown, then is revision-checked when that entity is materialized again. Phase 08
automated coverage includes Nexus.V7.Details.LargeSelectionDeferred,
Nexus.V7.UiGate.SelectAllAtScale, and
Nexus.V7.UiGate.SubsystemSelectionForwarding.

This corrects a Phase 06-owned contract but does not change this phase's Ready for
Review status or satisfy its E3 acceptance. Its unrun E3 checklist is amended with a
large-selection check on 2026-08-31; it must be run against the corrected contract,
not the previous always-proxy assumption.

## Dependencies

- Phase 05 Complete. **Not met when this phase was implemented.** Phase 05 stood at
  Ready for Review with its sixteen-item E3 script unrun, and the user chose to
  proceed. Phase 05's F-E3-04 was fixed here and is guarded by
  `Nexus.V7.Details.HealthyFixtureIsNotBlocked`; the rest of the Phase 05 E3 script
  remains unrun and is not satisfied by anything in this phase.

## Required Evidence

- E1: clean editor build and cold build for reflected test payload changes.
- E2: binding, arrays, multi-edit, validation, deletion-during-edit, and transaction tests.
- E3: manual property readability, editing, keyboard, tooltip, breadcrumb, and error-state review.

## Acceptance Gate

- [x] Fixed and dynamic-array payload fields edit correctly through one generic path. Held at E2 by `Nexus.V7.Details.GenericFieldPath`, which edits a record int, a payload scalar, a payload array, and an array nested inside that array, and asserts all four on the committed record.
- [x] Details never retain a dangling target after refresh, delete, map switch, or undo. Held at E2 by `Nexus.V7.Details.NoDanglingTarget` and `StableBinding`. Behaviour under a live window is E3 checklist item 9.
- [x] Mixed and inherited values are not misrepresented. Held at E2 by `Nexus.V7.Details.MixedValues`. Inherited values are not misrepresented because none are claimed — see the indicators note in Tasks.
- [x] Every invalid field explains the problem and repair path. Held at E2 by `Nexus.V7.Details.ValidationExplains`, which asserts the message is a sentence naming the repair rather than a restated field name.
- [ ] User approves clarity and editing ergonomics. **Not met.** Requires E3; the script is `evidence/phase-06-e3-manual-checklist-2026-08-23.md`.

## Risks

- Reflection-driven details can expose unsafe or irrelevant implementation fields.
- Multi-edit can unintentionally overwrite unique values.
- Raw struct-memory bindings can become invalid after array reallocation or payload replacement.
