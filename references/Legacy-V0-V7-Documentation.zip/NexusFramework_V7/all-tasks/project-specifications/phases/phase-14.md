# Phase 14 — Activation Registry & Real Payload Types

## Status

Not Started

## Objective

Deliver a persistent, extensible Activation Point system and the real initial object catalog, proving authoring, visualization, editing, validation, relationships, and compiler-adapter readiness without session-only substitutes.

## Scope

- Base activation record, type registry, typed payloads, sub-points, classification pairing, validation, queries, debug/gizmo integration, and compiler adapter declarations.
- Traffic Light, City Light, Crosswalk, Bus Stop, Seat, Parking, Advertisement, TV, Hospital, Police Station, Petrol Station, Charging Station, and Service Garage.

## Out of Scope

- Final runtime asset emission.
- Runtime Actor spawning/pooling.
- Per-type framework switches or ad hoc storage arrays.

## Tasks

- [ ] Implement registry definitions for Type Key, display metadata, payload struct, payload version/migrator, classification, validators, debug renderer, gizmo capability, and compiler adapter.
- [ ] Store every real instance in the Phase 01/07 versioned FInstancedStruct repository.
- [ ] Implement Traffic Light pole/vehicle LED/pedestrian LED offsets, controlled lanes/roads, and signal grouping.
- [ ] Implement City Light static pole/runtime source split.
- [ ] Implement Crosswalk endpoints/width/waiting points and traffic-light linkage.
- [ ] Implement Bus Stop stopping/entry/exit, passenger waiting points, seats, shelter, meshes, and lane/road relationships.
- [ ] Implement Seat grouping/capacity/occupancy/spacing/mesh data.
- [ ] Implement Parking layout, bays, entry/exit, vehicle rules, dimensions, meshes, and occupancy authoring data.
- [ ] Implement Advertisement and TV interaction/screen data.
- [ ] Implement Hospital, Police, Petrol, Charging, and Service Garage entrances, bays/sub-points, and service metadata.
- [ ] Prove fixed and N≥3 array sub-points visualize, select, edit, undo/redo, save, restart, and reload independently.
- [ ] Prove a new test type can register, persist, validate, visualize, edit, and expose a compiler adapter without framework-file edits.
- [ ] Remove or prohibit every session-only production path.

## Dependencies

- Phase 11 Complete.
- Phase 12 complete for full visualization/gizmo acceptance.
- Phase 13 classification registry available for static/dynamic pairing.

## Required Evidence

- E0: per-type schema and runtime-needs review.
- E1: clean editor and cold reflected-schema builds.
- E2: registry, persistence, migration, relationships, sub-point, validator, adapter, and onboarding tests.
- E3: manual per-type placement, details, visualization, gizmo, undo/redo, restart, and query review.

## Acceptance Gate

- [ ] Every named type uses real persistent storage.
- [ ] Every named type has explicit classification and compiler-adapter readiness.
- [ ] Fixed and array payloads survive restart with exact values and relationships.
- [ ] New-type onboarding requires no closed-enum/switch/framework edit.
- [ ] All per-type validators and queries pass.
- [ ] No export dependency is blocked by an unresolved authoring-payload decision.

## Risks

- Generic registration can hide missing type-specific invariants.
- Payload struct evolution can corrupt old assets without per-type migrations.
- Static/dynamic halves can drift if not linked by stable identity.
- A “generic” compiler adapter contract may still require runtime schema changes per type.
