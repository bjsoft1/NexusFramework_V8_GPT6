# Phase 10 — Mapping, Config & Reconciliation

## Status

Not Started

## Objective

Map validated Landscape source entities into the persistent V7 world hierarchy and reconcile topology changes predictably without destructive rebuilds, cross-map leakage, duplicate identity, or silent data loss.

## Scope

- Automatic world-config discovery/creation.
- Source→HighwayPoint mapping; State, City, Highway, Landscape ownership; ordered point membership; cross-Landscape links.
- Previewable, deterministic, idempotent reconciliation and orphan review.

## Out of Scope

- Final representation query graph.
- Static generation, gameplay activation, or runtime export.
- Silent wipe-and-rebuild synchronization.

## Tasks

- [ ] Implement automatic world-config resolve/create using Phase 01 ownership rules.
- [ ] Detect config/world ownership mismatch and offer explicit clone/relink/cancel behavior.
- [ ] Map each source entity to exactly one persistent identity without using array position or location hash as primary identity.
- [ ] Build State→City→Highway→ordered HighwayPoint membership with explicit Landscape ownership.
- [ ] Support cross-Landscape highways/relationships under the locked product rules.
- [ ] Compute a deterministic reconciliation plan before mutating data.
- [ ] Present creates, reuses, moves, conflicts, broken references, and orphans in preview/diff form.
- [ ] Apply only the explicit mutation set inside one transaction; preserve unrelated tuned data.
- [ ] Quarantine unmatched/orphaned records instead of silently deleting them.
- [ ] Make repeated reconciliation with unchanged input produce zero changes.
- [ ] Test insert/remove/reconnect, loop wraparound, shared junction, merge/import, duplicate map, map rename, two resident maps, undo/redo, save/reload, and restart.

## Delivered Early

**"Automatic world-config discovery/creation" — the convention half — shipped in
Phase 07 on 2026-08-27, at the user's third request.**

`FNexusDocumentStore::GetDocumentPackageNameForWorldPackage` derives
`<MapFolder>/<MapName>/NexusConfig` from a world package, `ResolveForWorldPackage`
opens or creates the document there, and `UNexusEditorSubsystem` calls it from
`FEditorDelegates::OnMapOpened` and `MapChange`. This restores the V6 behaviour the
user reported missing three times: opening a map produces its config asset, dirty
and unsaved, visible in the editor as unsaved work.

**What this does not deliver, and what is still Phase 10's:**

- The `ANexusWorldAnchor` soft reference from `V7-ARCHITECTURE.md`. A derived path
  is a fallback, not ownership; the anchor is authoritative once Phase 09 creates
  it, and this convention must yield to it.
- Ownership-mismatch detection and the clone/relink/cancel choice. A duplicated map
  currently derives a new path and creates a fresh empty document, which is the safe
  outcome but not the reviewed one the second task asks for.
- Everything from the third task down: mapping, membership, reconciliation, preview,
  orphan quarantine, idempotence.

The first task's checkbox stays unchecked because the task as written is
"using Phase 01 ownership rules", and the anchor is those rules.

Recorded here rather than absorbed silently: a boundary that gets crossed and not
written down is a boundary that stops meaning anything.

## Dependencies

- Phase 09 Complete.

## Required Evidence

- E1: clean editor and cold serialization build.
- E2: mapping uniqueness, reconciliation, idempotence, ownership, orphan, transaction, restart, and regression tests.
- E3: manual preview/apply/cancel/undo and topology-change verification.

## Acceptance Gate

- [ ] Every live source entity maps exactly once and every mapping resolves to its current owner.
- [ ] Reconciliation is deterministic and idempotent.
- [ ] No unrelated user-tuned data changes during sync.
- [ ] Orphans and conflicts remain visible and recoverable.
- [ ] Cross-map and cross-Landscape contamination tests pass.
- [ ] Blocking mapping findings prevent representation construction.

## Risks

- Topology matching can confuse “same physical entity” with merely nearby geometry.
- Reconciliation in two independent directions can drift if they do not share one plan.
- Map duplication may accidentally share one config or preserve duplicate domain IDs.
