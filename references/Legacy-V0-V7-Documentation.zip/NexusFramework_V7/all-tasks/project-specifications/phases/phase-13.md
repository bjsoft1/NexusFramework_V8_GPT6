# Phase 13 — Static Generation & Streaming

## Status

Not Started

## Objective

Generate deterministic, classification-driven, optimized static world content for roads and infrastructure while preserving authored intent, supporting World Partition, and making regeneration previewable and reversible.

## Scope

- Registry-backed object classification.
- Roads, junctions, lanes/markings, sidewalks, curbs, poles/static halves, decoration, static meshes, instancing, merge groups, streaming cells, provenance, and cleanup.
- Preview/apply/regenerate workflows and generation validation.

## Out of Scope

- Dynamic Actor activation.
- Runtime schema compilation.
- Silent broad reclassification/remeshing of existing user-tuned content.

## Tasks

- [ ] Replace closed generation enums/switches with a registry-backed classification and generator contract.
- [ ] Define explicit Static, Instanced, Merged Static, Runtime Activated, Runtime Persistent, Editor Only, and Debug Only classifications.
- [ ] Generate road surfaces and lane/sidewalk/curb geometry from validated curves with seam and junction continuity.
- [ ] Implement deterministic lane-aware junction selection and safe closed-form orientation/tangent handling.
- [ ] Generate configured static infrastructure and decoration without mixing dynamic activation halves.
- [ ] Group instances/meshes by material, mesh, cell, classification, and policy without losing provenance.
- [ ] Integrate World Partition/Data Layer/streaming-cell ownership according to Phase 01 contracts.
- [ ] Preview creates/updates/deletes and estimated cost before applying generation.
- [ ] Apply only the explicit generation mutation set transactionally; preserve unrelated hand-authored content.
- [ ] Stamp source revision/hash and generator version on generated output and detect stale content.
- [ ] Validate missing assets, invalid classification, bounds, seams, overlaps, ownership, and orphaned generated content.

## Dependencies

- Phase 11 Complete.
- May run in parallel with Phase 12 only under the active-work rule.

## Required Evidence

- E1: clean editor build.
- E2: classification, geometry, determinism, seam, junction, instancing, streaming, stale, and cleanup tests.
- E3: manual road/junction/sidewalk/infrastructure visual QA plus preview/undo review.

## Acceptance Gate

- [ ] Every generated object has an explicit registered classification and provenance.
- [ ] Repeating generation with unchanged input produces no changes.
- [ ] Roads/junctions have no unacceptable gaps, flips, or crash-prone rotations.
- [ ] Preview accurately describes the applied mutation set.
- [ ] Undo/cleanup affects only owned generated content.
- [ ] Representative generation meets Phase 01 editor budgets.

## Risks

- Junction math can trigger engine quaternion/tangent failures.
- Broad generator passes can overwrite user-authored meshes or transforms.
- Instancing/merging can remove identity needed for verification or runtime linkage.
- Streaming ownership mistakes can create duplicate or missing content.
