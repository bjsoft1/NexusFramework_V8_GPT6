# Phase 04 — Menus & Command System

## Status

Complete

## Objective

Create one discoverable, testable command model that powers the main menu, toolbar, context menus, shortcuts, and later automation without duplicating behavior.

## Scope

- Command registry, command palette, Activity operation/history model, and command-service routing.
- Main menu, toolbar, context-menu framework, shortcuts, command search/discovery, and can-execute explanations.
- Progress, cancellation, confirmation, and result presentation contracts.

## Out of Scope

- Final CRUD repository implementation.
- Landscape mapping or generation commands.
- UI-specific copies of business logic.

## Tasks

- [x] Define command IDs, labels, descriptions, icons, shortcuts, categories, and ownership.
- [x] Register File, Edit, Create, View, Validate, Generate, Compile, Debug, Help, and context-menu groups.
- [x] Implement the Window > Nexus Framework V7 submenu and exact Home/workspace/tab/palette/reset entry behavior from the UX specification.
- [x] Implement the searchable command palette as an overlay/menu, not a fourth tab.
- [x] Route every surface through the same execute/can-execute service.
- [x] Surface disabled-command reasons instead of silently doing nothing.
- [x] Add progress and safe cancellation contracts for long-running commands.
- [x] Add confirmation/preview contracts for delete, reconcile, regenerate, and other destructive actions.
- [x] Add recent-action/result history sufficient to diagnose failures.
- [x] Feed the Activity tab with active operations, validation context, history, recovery actions, durations, targets, and technical details without per-tick noise.
- [x] Test shortcut conflicts, repeated registration, shutdown cleanup, and scripted invocation.

## How to Test

Six steps. The first two are automated and take about two minutes. Steps 3-6 are
the reachability checks — this phase registered the full command inventory, and a
command that is registered but that no click can reach has shipped here twice. The
full manual run is `evidence/phase-04-e3-manual-checklist-2026-08-23.md`.

1. **Run the gate.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase04Commands.ps1 -SkipBuilds`
   → expect `PASS: 69 tests, 0 failures` and `PHASE 04 COMMAND SYSTEM: PASS`.
2. **Run the structural scan.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyFoundation.ps1`
   → expect `FOUNDATION STRUCTURAL SCAN: PASS`.
3. **Open the palette.** `Nexus.Fixture.LoadSample Normal` so commands have
   something to act on, then `Ctrl+Shift+P` with a Nexus tab focused.
   → every command is listed with its shortcut; a command a later phase delivers is
   disabled and **says which phase**, rather than being missing or silently failing.
4. **Check the chord is tab-scoped.** Press `Ctrl+Shift+P` with the Content Browser
   focused instead.
   → nothing happens. A Nexus chord that fires outside a Nexus tab is a defect.
5. **Run the same command two ways** — the Hierarchy toolbar and the palette.
   → identical outcome and identical refusal text. The surfaces map to command ids,
   not to their own copies of the behaviour.
6. **Run a destructive command.**
   → it asks first, in a popup over the tab you are already on, naming what it will
   do. Cancel changes nothing; the Activity tab records both the ask and the answer.

## Dependencies

- Phase 03 Complete.

## Required Evidence

- E1: clean editor build.
- E2: command registration, routing, can-execute, cancellation, and cleanup tests.
- E3: manual discoverability, shortcut, menu, toolbar, context, and disabled-reason review.

## Acceptance Gate

- [x] A command has one implementation regardless of invocation surface.
- [x] All visible commands have accurate availability and disabled reasons.
- [x] Destructive commands require the approved preview/confirmation path.
- [x] Long commands expose progress and safe cancellation.
- [x] Menus and shortcuts are understandable without external documentation.

The last item is split across evidence levels. Every command carries a
one-sentence description used as its tooltip, a disabled entry appends its refusal
to that tooltip, and `Show Keyboard Shortcuts` lists every bound chord from the
catalog rather than from a document, and `Nexus.V7.Command.ChordRouting` proves those
chords fire. Whether a person can find and understand them in a live editor is E3.
E3 run 1 was performed on 2026-08-23, stopped at checklist item 4, and found two
Blocking defects (F-E3-01, F-E3-02); both are fixed and guarded, and the run has to
restart from item 1. Evidence:
[Phase 04 command system](../evidence/phase-04-commands-2026-08-23.md).

The script a person runs to produce that E3 pass is
[Phase 04 E3 manual test script](../evidence/phase-04-e3-manual-checklist-2026-08-23.md).

### E3 outcome — 2026-08-23

E3 run 2 was performed by the user on the rebuilt editor and the phase was
accepted. The user reported the UI displaying correctly and moved the phase to
Complete.

**What that acceptance rests on, stated exactly.** The user's own inspection of
the running editor, on top of E1 (three clean builds) and E2 (64/64 automation
tests). The eleven checklist items in
[the E3 script](../evidence/phase-04-e3-manual-checklist-2026-08-23.md) were not
reported back individually, so this record does not claim an itemised
eleven-of-eleven pass. Notably, F-E3-03 — the focus-recursion stack overflow,
which has no automated guard — was assigned to run 2; the editor session
completed without a crash, which covers it by observation rather than by a
scripted repro of the tab-switch/Refresh sequence.

As with Phases 02 and 03, no independent E0 review was performed.

## Risks

- Duplicated handlers will diverge and bypass validation.
- Global shortcuts can conflict with Unreal Editor defaults.
- Commands registered before their services exist can appear functional while doing nothing.
