# Phase 03 — Professional UI Shell

## Status

Complete

## Objective

Deliver the polished, dockable, resilient three-tab Nexus workspace shell and shared visual language that every later UI feature uses.

## Scope

- Exactly three independent Nomad tabs: Nexus V7 Hierarchy, Nexus V7 Details, and Nexus V7 Activity; Home is a view inside Hierarchy.
- Header, navigation regions, content split, status/health region, and notifications.
- Loading, empty, ready, dirty, warning, blocked, stale, working, and failure presentation.
- Styling, DPI, keyboard focus, layout persistence, and safe lifecycle.

## Out of Scope

- Final menus/commands.
- Production hierarchy data, property editing, or CRUD.
- Landscape and generation logic.

## Tasks

- [x] Register the three stable Nomad tab IDs and make each tab independently dockable, closable, reopenable, and focusable without duplication.
- [x] Build Home inside Hierarchy plus Default, Authoring, and Review workspaces with resilient saved layouts.
- [x] Create reusable typography, spacing, color, icon, button, banner, badge, and separator styles.
- [x] Add the shared context strip to every tab with document, readiness, workspace, dirty/recovery, Home, and command-palette state.
- [x] Add Home onboarding, recent/recovery context, current-world/config summary, safest-next-action, and system-health presentation.
- [x] Add navigation/content/details regions that resize gracefully and support focus traversal.
- [x] Implement all required loading/empty/error/blocked/stale view states against a UI-state provider.
- [x] Add non-modal notifications and a clear path from error summary to diagnostics.
- [x] Verify high-DPI scaling, readable contrast, keyboard focus, tooltip placement, and narrow-window behavior.
- [x] Unregister tabs, styles, extenders, and delegates safely on shutdown/reload.

## How to Test

Six steps. The first two are automated and take about two minutes; the rest are
what a person has to look at, because "does this read as a professional shell" is
not a property automation can assert. The full record is
`evidence/phase-03-ui-shell-2026-08-23.md`.

1. **Run the gate.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase03Shell.ps1 -SkipBuilds`
   → expect `PASS: 52 tests, 0 failures` and `PHASE 03 UI SHELL: PASS`.
2. **Run the structural scan.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyFoundation.ps1`
   → expect `FOUNDATION STRUCTURAL SCAN: PASS`.
3. **Load data and open all three tabs.** In the editor console type
   `Nexus.Fixture.LoadSample Normal`, then `Window > Nexus Framework V7` →
   Hierarchy, Details, Activity. `Nexus.Fixture.Clear` returns the empty state,
   which is worth looking at too.
   → each opens, each carries the context strip, and none repeats the others'
   chrome: one toolbar and one banner per message across the whole workspace.
4. **Resize a tab narrow, then wide.**
   → regions drop whole rather than squeezing to unusable widths, and nothing
   clips. Repeat at **200%** editor DPI.
5. **Drag a tab out and dock it elsewhere**, then restart the editor.
   → the layout returns. Corrupt `Saved/NexusV7` first and it reports the repair
   rather than silently resetting.
6. **Select a message and copy it.** Click into any banner or the status footer.
   → the text selects, `Ctrl+C` works, and the right-click menu offers Copy and
   Select All. Nothing in the shell is a modal.

## Dependencies

- Phase 02 Complete.

## Required Evidence

- E1: clean editor build.
- E2: tab lifecycle, state rendering, and layout persistence automation where feasible.
- E3: manual docking, resize, DPI, keyboard, map-switch, restart, and visual polish review.

Current evidence:
[phase-03-ui-shell-2026-08-23.md](../evidence/phase-03-ui-shell-2026-08-23.md).

E1 and E2 are green. `Scripts/VerifyPhase03Shell.ps1` builds all three targets clean
and runs `Nexus.V7.Shell` alongside the Phase 01 and Phase 02 regression suites. The
two non-editor targets are built even though this phase's gate needs only the editor
one, because the shell changed `NexusEditorUI`'s dependencies and an editor-only
module leaking into a packaged target has to fail here rather than at Phase 18.

The fourteen `Nexus.V7.Shell` tests hold the parts of this phase that can be checked
without a person at the editor. All nine view states are proven reachable and each
is proven to carry a headline, an explanation, and a tooltip on any action it
offers; the real surfaces are constructed and laid out in all twenty-seven
surface-by-state combinations at both 100% and 200% scale; every saved-workspace
corruption case recovers to a usable arrangement; and the palette is held to WCAG
contrast ratios rather than to opinion.

Narrow-window behaviour is a rule rather than a hope. Three regions at their
minimum widths need more room than a normally docked tab has, so the surface drops
whole regions as it narrows — the third region below 720 units, the navigation rail
below 420, where a horizontal section strip replaces it — and
`Nexus.V7.Shell.ResponsiveLayout` pins both breakpoints, checks that navigation
stays reachable in exactly one form at every width, and asserts that the regions
which survive each breakpoint actually fit inside it.

Six of the new guards were made to fail on purpose and each failed by name while
the others passed, so none of them is an untested claim.

The sixth guard exists because the user's first look at the shell found a defect
this phase had shipped: a "Create a document" button on the no-document state, wired
to a command that refuses when no document is open, and a Failure state with no way
to dismiss it. Actions now carry an explicit kind, eligibility is checked before any
command runs, Failure is dismissible, and `Nexus.V7.Shell.ActionsAreRunnable` was
proven to catch the original defect by reinstating it verbatim. Note that nothing
binds an authoring document from the editor yet — Phase 07 owns that entry point per
finding F-09 — so every surface reporting Empty during E3 is correct behaviour.

**E3 is not satisfied**, and three acceptance-gate items depend on it: layout
survival across an editor restart, the keyboard focus path and absence of clipping
in a live window, and the user's judgement of visual quality. Those need a person at
the editor and cannot be produced by automation.

## Acceptance Gate

- [x] Shell opens from a stable editor entry point and never duplicates itself.
- [x] Layout survives editor restart and recovers from invalid saved layout.
- [x] Every defined state has an intentional, understandable presentation.
- [x] No clipped text, broken focus path, unreadable contrast, or shutdown error remains.
- [x] User approves the shell's professional visual quality.

Two of these gate items are split across evidence levels. Recovery from an
invalid saved layout is proven at E2 across ten corruption cases; survival
across an editor restart is E3. Readable contrast is proven at E2 against WCAG
ratios and text wraps or ellipsises with a tooltip rather than clipping; the
focus path in a live window and a clean editor exit are E3.

The three manual gate items were performed by the user at the editor on
2026-08-23 and passed: the shell's layout survived an editor restart, the live
window showed no clipped text and no broken focus path, the editor exited
cleanly, and the user approved the shell's visual quality. E3 therefore rests on
the user's own inspection rather than on automation, which is what E3 is; the E2
halves of the split items are the ones recorded above.

## Risks

- Styling without a shared system will cause inconsistent later panels.
- Layout persistence can retain stale widgets or delegates across reload.
- A health display not backed by state contracts can become misleading decoration.
