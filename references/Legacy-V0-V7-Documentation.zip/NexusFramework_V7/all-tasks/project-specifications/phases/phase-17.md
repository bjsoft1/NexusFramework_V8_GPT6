# Phase 17 — Runtime Activation System

## Status

Not Started

## Objective

Consume compiled V7 data in packaged runtime, provide fast world/path queries, and activate only nearby dynamic behavior through deterministic spatial selection and completely resettable Actor pools.

## Scope

- Runtime asset lifecycle, immutable lookup/query service, road/path graph access, spatial index, activation policies, Actor pooling, timing/distance rules, streaming integration, and instrumentation.
- Logical-object versus active-Actor separation.

## Out of Scope

- Reading Landscape or editor config at runtime.
- One persistent Actor per logical object.
- Editing authoring data in packaged gameplay.

## Tasks

- [ ] Load and validate runtime asset version, world ownership, chunk metadata, and required assets.
- [ ] Build or consume compiled ID/index, hierarchy, road-neighbor, junction, lane, path, and nearby-object query surfaces.
- [ ] Expose deterministic route/pathfinding inputs preserving useful V0 behavior without actor-owned graph data.
- [ ] Prove continuous lane following, smooth lane changes, highway transitions,
  dead-end reversal, and seeded/randomized traffic distribution against compiled
  lane/junction data.
- [ ] Query activation candidates through compiled spatial data without full-dataset scans.
- [ ] Apply type policy, distance, active-time, streaming, priority, and budget rules.
- [ ] Spawn or acquire pooled Actors only for selected Runtime Activated objects.
- [ ] Make activate, refresh, deactivate, unload, and repeated requests idempotent.
- [ ] Reset transform, components, delegates, timers, ownership, payload state, and gameplay state before pool reuse.
- [ ] Handle player teleport, world teardown, streaming-cell load/unload, missing assets, and corrupted/unsupported runtime data safely.
- [ ] Instrument query time, candidates, active counts, pool hits/misses, spawn time, deactivation, memory, and budget pressure.
- [ ] Test multiple observers if supported by Phase 01 scope.

## Dependencies

- Phase 16 Complete.

## Required Evidence

- E1: clean non-editor Game and editor builds.
- E2: load, query, path, activation, idempotence, pooling reset, streaming, teleport, teardown, and regression tests.
- E4: packaged standalone runtime behavior and performance proof on representative data.

## Acceptance Gate

- [ ] Runtime never loads Nexus editor/authoring modules or assets.
- [ ] Query and activation costs meet Phase 01 budgets.
- [ ] Logical object count is independent of active Actor count.
- [ ] Pooled Actors show no state leakage between identities/types.
- [ ] Streaming and teleport cannot leak or duplicate active Actors.
- [ ] Invalid/unsupported runtime data fails safely with an actionable reason.
- [ ] The named V0 traffic behaviors remain stable across cell unload/reload and
  have automated fixtures plus a runtime soak.

## Risks

- Full scans hidden inside convenience queries can destroy runtime scale.
- Pool reset omissions can leak gameplay state across logical objects.
- Streaming and asynchronous activation can race world teardown.
- Path/query results can become inconsistent if runtime records duplicate topology truth.
