# Phase 02 — Project/Module Foundation

## Status

Complete

## Objective

Create a clean, buildable, testable plugin/module foundation that enforces the Phase 01 dependency contracts before feature work begins.

## Scope

- Plugin descriptor and module targets.
- Build dependencies and public/private API boundaries.
- Startup/shutdown lifecycle, logging, settings, command/service seams, and test harness.
- Empty but real host integration for editor and runtime targets.

## Out of Scope

- Production Slate UI.
- Landscape access, world generation, activation types, or runtime gameplay.
- Temporary cross-module dependencies “to make it compile.”

## Tasks

- [x] Configure NexusCore, NexusAuthoring, NexusEditorUI, NexusEditor, NexusLandscapeEditor, NexusGeneration, NexusCompiler, NexusRuntime, and NexusTests modules.
- [x] Encode the approved dependency graph in Build.cs and plugin descriptors.
- [x] Establish module API macros, directory conventions, log categories, settings, and error/result contracts.
- [x] Implement idempotent startup/shutdown and safe delegate/command unregistration.
- [x] Add shared command/service interfaces so UI never contains business logic.
- [x] Add automation discovery, canonical fixture helpers, and report output paths.
- [x] Add dependency tests that detect editor-only includes or modules entering NexusRuntime.
- [x] Build editor, game, and test targets from a clean state.

## How to Test

Six steps. The first two are automated and take about two minutes; the rest need
the editor open.

1. **Run the gate.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyPhase02Modules.ps1 -SkipBuilds`
   → expect `PASS: 33 tests, 0 failures` and `PHASE 02 MODULE FOUNDATION: PASS`.
   Drop `-SkipBuilds` for the clean builds.
2. **Run the structural scan.** `powershell -NoProfile -ExecutionPolicy Bypass -File Scripts\VerifyFoundation.ps1`
   → expect `FOUNDATION STRUCTURAL SCAN: PASS`, including
   `Exact module descriptor set` and `Runtime dependency boundary`.
3. **Check the boundary by building without the editor.**
   `Build.bat NexusFramework Win64 Shipping -Project=<repo>\NexusFramework.uproject -WaitMutex -clean`
   → only `NexusCore`, `NexusRuntime`, and `NexusV7Host` appear in the `Compile`
   lines. An editor module there is the failure this phase exists to prevent.
4. **Open the editor.** Launch `NexusFramework.uproject`.
   → it starts clean, and the log has no Nexus warnings or errors during startup.
5. **Check the plugin is loaded.** `Edit > Plugins`, search Nexus.
   → `NexusFrameworkV7` is enabled and lists its nine modules.
6. **Close and reopen the editor.**
   → no module-ordering warning on the second start, which is where load-order
   mistakes show up rather than on the first.

## Dependencies

- Phase 01 Complete.

## Required Evidence

- E0: module dependency review.
- E1: clean Development Editor and non-editor Game builds.
- E2: startup/shutdown, module-boundary, and test-discovery automation.

Current evidence:
[phase-02-module-foundation-2026-08-23.md](../evidence/phase-02-module-foundation-2026-08-23.md).

E1 and E2 are green on 2026-08-23: three clean builds (Development Editor,
Development Game, Shipping Game) and 33/33 automation tests — the twelve
`Nexus.V7.Module` tests this phase owns plus the twenty-one `Nexus.V7.Foundation`
tests Phase 01 froze — with zero automation warnings or errors. The structural
scan passes. Both boundary guards added in this phase were made to fail on purpose
and then reverted, so neither is an untested claim.

The two Phase 01 findings carried into this phase are closed: F-08 (the
`NexusEditorUI` command edge, and an explicit decision not to create a CI
pipeline) and F-10 (canonical fixture truth stays in `NexusTests`; the packaged
host was narrowed and `Nexus.V7.Module.HostDatasetContract` now holds its
remaining identity literals at E2). Both decisions are recorded in
`V7-ARCHITECTURE.md` §6. Because the F-10 change touched code that only E4
exercises, the cook/package proof was re-run rather than left unverified: 518
packages, 0 errors, 0 warnings, and `NEXUS_PHASE01_PACKAGED_DATASET_LOAD: PASS`.

E0 was **waived, not satisfied**. Phase 02 requires an independent
module-dependency review; none was performed, because the agent that implemented
this phase cannot review its own work and the user chose to proceed rather than
wait for one. The user accepted the phase on 2026-08-23 after inspecting the
editor themselves — no crash, no error, panel visible and dockable — so
acceptance rests on E1, E2, and that inspection. The boundary claims an E0 review
would have checked are held by `Nexus.V7.Module.RuntimeBoundary` and
`Nexus.V7.Module.HostDatasetContract`, both of which were made to fail on purpose
before being trusted.

## Acceptance Gate

- [x] Every approved module loads and unloads without errors or leaked registrations.
- [x] NexusRuntime builds with zero dependency on authoring, editor, generation, or compiler modules.
- [x] Tests are discovered and can fail the build.
- [x] No circular module dependency exists.
- [x] No feature code bypasses the command/service boundary.

## Risks

- Over-broad public dependencies will make later runtime separation expensive.
- Static registration or shutdown ordering can crash editor exit.
- Weak test integration can turn later “evidence” into manual claims.
