# Nexus Framework V7 — Phase Status

This is the sole authoritative phase-status ledger. Each phase file owns its
objective, tasks, evidence requirements, and acceptance gate; its Status heading is
a mirror. Any mismatch is a blocking tracker defect and this ledger wins until fixed.

| Phase | Name | Status | Required Gate |
|---:|---|---|---|
| 01 | Architecture Lock & Serialization Spike | **Complete** | Architecture/serialization proof |
| 02 | Project/Module Foundation | **Complete** | E1 + E2 |
| 03 | Professional UI Shell | **Complete** | E1 + E2 + E3 |
| 04 | Menus & Command System | **Complete** | E1 + E2 + E3 |
| 05 | Hierarchy Tree View | **Ready for Review** | E1 + E2 + E3 |
| 06 | Details Panel | **Ready for Review** | E1 + E2 + E3 |
| 07 | Full UI CRUD | **Ready for Review** | E1 + E2 + E3 + restart |
| 08 | UI Completion Gate | **In Progress** | Full UI checkpoint |
| 09 | Landscape Reader & Identity | Not Started | E1 + E2 + E3 + restart |
| 10 | Mapping, Config & Reconciliation | Not Started | E1 + E2 + E3 + restart |
| 11 | Representation Graph & Enforced Validation | Not Started | E1 + E2 |
| 12 | Diagnostics, Debug Visualization & Gizmos | Not Started | E1 + E2 + E3 |
| 13 | Static Generation & Streaming | Not Started | E1 + E2 + E3 |
| 14 | Activation Registry & Real Payload Types | Not Started | E1 + E2 + E3 + restart |
| 15 | Editor Architecture Checkpoint | Not Started | Full editor checkpoint |
| 16 | Deterministic Runtime Compiler | Not Started | E1 + E2 + E4 |
| 17 | Runtime Activation System | Not Started | E1 + E2 + E4 |
| 18 | Real Scale, Cook & Package Gate | Not Started | Scale/cook/package checkpoint |
| 19 | Human Verification & Publish UI | Not Started | E1 + E2 + E3 |
| 20 | Final Publish Gate | Not Started | Full release checkpoint |

## Current Work

Phases 01 through 04 are **Complete**. Phase 05, Hierarchy Tree View, Phase 06,
Details Panel, and Phase 07, Full UI CRUD, are all **Ready for Review**, which is the
implementing agent's ceiling: E1 and E2 are green on all three and E3 has been run on
none of them.

**Three phases are now stacked awaiting the same person.** Phase 06 was implemented
on a Phase 05 that had not met its own gate, and Phase 07 on a Phase 06 that had not
met its own, both on the user's explicit instruction. That is recorded in full under
each phase below rather than smoothed over, because the dependency lines in
`phases/phase-06.md` and `phases/phase-07.md` say "Phase 05 Complete" and "Phase 06
Complete" and neither is.

Phase 08 is the UI Completion Gate and is the point where this stops being
deferrable: its dependency line requires Phase 07 Complete, and Phase 09 and every
later backend phase are blocked behind it. The three E3 runs are therefore the
critical path, not the next implementation.

Phase 08 is nonetheless **In Progress** as of 2026-08-28, started on the user's
instruction against that unmet dependency, and its passes are recorded below.
Beginning it did not turn out to be merely procedural. Measuring the responsiveness
budgets for the first time found four Blocking defects, one of which would have hung
the editor on a keystroke at reference scale. Two more came from the user using the
editor. Testing the presentation states found a fifth: a shell state that was
documented, derived, drawn, and unreachable, while the panel it should have agreed
with was refusing the user's Apply.

**Three of Phase 08's nine tasks are done; six remain unchecked.** The responsiveness
task passes its E2 scale regression after F-08-04, and the payload-CRUD (3) and
presentation-state (5) task lines were closed by the 2026-09-02 decisions below. None
of the six acceptance-gate items is met. The three E3 runs remain outstanding and
Phase 08's own E3 subsumes them.

**No finding now waits on the user; E3 does.** F-08-06 and F-08-15 were answered on
2026-09-02 and are closed: ownership-mismatch defers to the Phase 10 reservation that
already claims it, and the payload-CRUD task line is satisfied by its
command-service-level proof — create/update/delete/undo/redo, save/reload, and a
genuine three-process cold restart — plus Phase 07's already-recorded "not
UI-authorable until Phase 14" omission. Task lines 3 and 5 are now checked with those
carve-outs named. F-08-05 was answered on 2026-08-28 and is closed: the catalog's
pending-phase commands stay, and the gate item means nothing Phases 03–08 owe is
deferred. F-08-04 was resolved at E2 on 2026-08-31 by a documented bounded-Details
contract correction; it does not make the owning Phase 06 accepted.

The authoring hierarchy is confirmed as `State > City > Highway > Points > Activation
Point`, where Points auto-sync from the landscape in Phase 09/10 and Activation Points
arrive in Phases 12 and 14. Only the first three rungs are hand-authored today, and
that is the intended shape rather than Phase 08 debt.

Phase 03 replaced the provisional Phase 01 vertical-spike panel with the real
three-tab workspace shell. The shell carries no production hierarchy data, property
editing, or CRUD — those belong to Phases 05–07 — and no shell surface may be cited
as Phase 05–08 acceptance evidence.

Phase 04 fills that shell's chrome with one command model. The full V7 command
inventory is registered; the commands this build owns work, and the rest refuse
with the phase that delivers them. No Phase 04 surface may be cited as Phase 05–08
acceptance evidence: a command that says "Phase 07 delivers this" is a correct
Phase 04 result and is not delivery of that command.

### Phase 01 review candidate

- Cold Editor, Game Development, and Game Shipping builds passed.
- All 21 Foundation automation tests passed with zero unexpected warnings/errors.
- Real asset CRUD, transaction undo/redo, cold restart, previous-schema migration,
  native struct redirect, and removed-native-type lossless recovery passed.
- Clone/rekey rewrites every owned root/reference and registered nested payload ID.
- Immutable runtime schema, deterministic provenance-derived Build ID, cook, package,
  and packaged-dataset validation passed.
- Exact 20-phase structure, runtime dependency boundary, and content manifest passed.

These results satisfy the implementing-agent portion of the Phase 01 gate only.
They do not satisfy independent E0 approval or any later phase. Evidence:
[Phase 01 foundation report](evidence/phase-01-foundation-2026-08-22.md).

### Phase 01 E0 independent review outcome — 2026-08-22

An independent E0 review was performed by an agent that did not implement
Phase 01. It re-executed the editor build, a cold clean Shipping build, the
21-test Foundation suite, and the structural scan; all reproduced. The Shipping
link action list independently confirms that only NexusCore, NexusRuntime, and
NexusV7Host enter a packaged target.

The review did **not** accept Phase 01. Persistence, identity, migration,
transaction, registry, compiler-seam, and module-boundary work are accepted. Two
Blocking findings remain against the runtime schema this phase freezes:

- **F-01** — every compiled record must carry valid bounds that fit inside its
  assigned cell, so a World/State/City/Highway record whose extent spans cells
  has no legal cell. The frozen schema states no storage rule for non-leaf
  records.
- **F-02** — canonical order is cell-major while `ParentIndex` must reference a
  preceding record, so a parent whose cell sorts after its child's cell cannot be
  represented. Under mandated multi-Landscape and World Partition this is the
  ordinary case.

Two Warnings (degenerate compiled-schema fixture; evidence traceability and
retention) and three Information findings are also recorded. Full record:
[Phase 01 E0 independent review](evidence/phase-01-e0-independent-review-2026-08-22.md).

### Phase 01 E0 remediation — 2026-08-22

All five required E0 items were applied the same day on the user's instruction.
`V7-ARCHITECTURE.md` §10 now decides cell assignment and hierarchy ownership,
`NexusRuntimeDataset.cpp` enforces it, the compiled-dataset fixture covers a
cross-cell hierarchy owner with five new negative tests, the evidence path is
corrected, and `V7-QUALITY-GATES.md` §2 now requires a byte count and SHA-256 for
every cited artifact. Post-remediation: 21/21 Foundation tests, cold Shipping
build clean with the boundary intact, structural scan PASS.

### Phase 01 acceptance — 2026-08-22

The user accepted Phase 01 and marked it Complete after reviewing the E0 record,
the remediation, and the editor themselves. All required Phase 01 evidence is
green on the accepted tree: E1 builds, E2 21/21 Foundation tests, cold restart
across three editor processes, and E4 cook/package with a passing packaged
runtime dataset load.

Five findings were recorded and accepted as non-blocking rather than fixed: F-06
(authoring payloads persisted twice, no authoring-size budget yet), F-07 (load
delegate hygiene), F-08 (Phase 02 preconditions), F-09 (Phase 01 is verifiable
only by automation; Phase 07 owns the authoring entry point), and F-10 (compiled
fixture shape duplicated between the test fixture and the packaged host). F-08
and F-10 are carried into Phase 02; F-06 into Phase 07; F-09 into Phase 07.

### Phase 02 review candidate — 2026-08-23

Phase 02 is **Ready for Review**, which is the implementing agent's ceiling. E1 and
E2 are green on a clean tree: three clean builds (Development Editor, Development
Game, Shipping Game) and 33/33 automation tests — the twelve `Nexus.V7.Module`
tests this phase owns plus the twenty-one `Nexus.V7.Foundation` tests Phase 01
froze — with zero automation warnings or errors. The structural scan passes.

Both boundary guards this phase relies on were made to fail on purpose and then
reverted. Injecting `UnrealEd` and `NexusAuthoring` into `NexusRuntime.Build.cs`
failed `Nexus.V7.Module.RuntimeBoundary` by name; changing the packaged host's
`SourceRevision` literal from 42 to 43 built cleanly on all three targets and
failed `Nexus.V7.Module.HostDatasetContract`, which is exactly the drift F-10
described.

The two Phase 01 findings carried into Phase 02 are closed, with both decisions
recorded in `V7-ARCHITECTURE.md` §6 so they bind later phases:

- **F-08** — `NexusEditorUI` now declares its `NexusCore` and `NexusEditor` edges
  deliberately, and V7 explicitly does not create a CI pipeline in Phase 02
  because every gate needs a licensed UE 5.8 toolchain that no hosted runner
  provides. `Scripts/VerifyPhase02Modules.ps1` is the mandatory pre-review gate.
- **F-10** — canonical fixture truth stays in `NexusTests` and is never lifted
  into a module that ships. `NexusV7Host.cpp` was narrowed from roughly sixty
  literal field assertions to `Validate`, `IsFreshFor`, and one record lookup, and
  `Nexus.V7.Module.HostDatasetContract` holds the remaining identity literals at
  E2. Because that change touched code only E4 exercises, cook/package was re-run:
  518 packages, 0 errors, 0 warnings, and `NEXUS_PHASE01_PACKAGED_DATASET_LOAD:
  PASS`. The regenerated fixture asset came back byte-identical.

Both verification scripts now take a `-RunLabel` defaulting to the current date.
They previously hard-coded `2026-08-22` into artifact names, so a re-run would have
overwritten logs the Phase 01 evidence record cites by digest.

These results satisfy the implementing-agent portion of the Phase 02 gate only.
Evidence: [Phase 02 module foundation](evidence/phase-02-module-foundation-2026-08-23.md).

### Phase 02 acceptance — 2026-08-23

The user accepted Phase 02 and marked it Complete after inspecting the editor
themselves and confirming no crash, no error, and a visible, dockable panel.

**E0 was waived, not satisfied.** Phase 02's required evidence lists an
independent module-dependency review. No such review was performed: the agent
that implemented the phase cannot review its own work, and the user chose to
proceed rather than wait for one. Acceptance of this phase therefore rests on
E1, E2, and the user's own editor inspection. This is recorded so that a later
reader cannot mistake acceptance for independent verification.

The module-boundary claims an E0 review would have checked are held by
automation instead: `Nexus.V7.Module.RuntimeBoundary` and
`Nexus.V7.Module.HostDatasetContract` were each made to fail on purpose and then
reverted, so both are proven guards rather than untested assertions.

### Phase 03 review candidate — 2026-08-23

Phase 03 is **Ready for Review**, which is the implementing agent's ceiling. E1 and
E2 are green on a clean tree: three clean builds and 47/47 automation tests — the
fourteen `Nexus.V7.Shell` tests this phase owns plus the twelve `Nexus.V7.Module` and
twenty-one `Nexus.V7.Foundation` tests the earlier phases froze — with zero
automation warnings or errors. The structural scan passes. The gate script is
`Scripts/VerifyPhase03Shell.ps1`.

The shell is three Nomad tabs — Nexus V7 Hierarchy, Details, and Activity — sharing
one frame: a context strip, a header, an inline notification region, a three-region
resizable body, and a status footer. Home is a view inside Hierarchy rather than a
fourth tab, so onboarding and recovery cannot be closed and lost.

Two design decisions carry the phase's testability:

- **State derivation is a pure function.** `DeriveShellState` maps any combination
  of signals onto exactly one of nine states with no editor dependency, so all nine
  are proven reachable and each is proven to carry a headline, an explanation, and a
  tooltip on any action it offers.
- **Widgets see the world only through `INexusShellStateProvider`.** A test supplies
  its own provider, which is how the real surfaces are constructed and laid out in
  all twenty-seven surface-by-state combinations at both 100% and 200% scale.

Readable contrast, normally an E3 judgement, is held at E2: the palette is defined
from sRGB hex so WCAG relative luminance is computable, and body text is held to
4.5:1 with every state colour to 3:1 on all three surfaces. Narrow-window behaviour
is likewise a rule with breakpoints rather than a hope — the surface drops whole
regions as it narrows instead of squeezing them until they clip.

Six of the new guards were made to fail on purpose — a low-contrast palette entry,
a state with no explanation, a modal API reachable from the shell, a style token
referenced but never registered, a layout breakpoint too small for the regions it
claims to fit, and an action offered from a state it cannot succeed in — and each
failed by name while the others passed.

The last of those came from the user's first look at the shell. It offered a
"Create a document" button on the no-document state wired to a command that refuses
when no document is open, so it could only ever fail, and the resulting Failure
state had no way to dismiss it. Both are fixed: actions now carry an explicit kind,
eligibility is checked before a command runs, Failure is dismissible, and
`Nexus.V7.Shell.ActionsAreRunnable` was proven to catch the original defect by
reinstating it verbatim. Nothing binds an authoring document from the editor yet —
Phase 07 owns that entry point per finding F-09 — so the shell reporting Empty
during E3 is correct behaviour rather than a defect.

These results satisfy the implementing-agent portion of the Phase 03 gate only.
**E3 is not satisfied**, and three acceptance-gate items depend on it: layout
survival across an editor restart, the keyboard focus path and absence of clipping
in a live window, and the user's judgement of visual quality. Evidence:
[Phase 03 UI shell](evidence/phase-03-ui-shell-2026-08-23.md).

### Phase 03 acceptance — 2026-08-23

The user performed E3 at the editor and accepted Phase 03 as **Complete**. The
three manual gate items passed: the layout survived an editor restart, the live
window showed no clipped text and no broken focus path, the editor exited cleanly,
and the user approved the shell's visual quality.

E3 therefore rests on the user's own inspection rather than on automation, which
is what E3 is. As with Phase 02, no independent E0 review was performed; acceptance
rests on E1, E2, and the user's editor session.

### Phase 04 review candidate — 2026-08-23

Phase 04 is **Ready for Review**, which is the implementing agent's ceiling. E1 and
E2 are green on a clean tree: three clean builds and 64/64 automation tests — the
seventeen `Nexus.V7.Command` tests this phase owns plus the fourteen `Nexus.V7.Shell`,
twelve `Nexus.V7.Module`, and twenty-one `Nexus.V7.Foundation` tests the earlier
phases froze — with zero automation warnings or errors. The structural scan passes.
The gate script is `Scripts/VerifyPhase04Commands.ps1`.

Three design decisions carry the phase:

- **The catalog is data and every surface is generated from it.** Sixty-three
  commands are described in one table — id, label, description, category, menu
  group, icon, chord, scope, synonyms, risk, expected duration, owning phase — and
  the Window submenu, toolbar, context menus, palette, and Slate command set are
  all built by reading it. Phase 03's hand-written eight-entry `TCommands` list was
  deleted rather than kept beside it, because a second list is how a menu and a
  palette come to advertise different shortcuts for one command.
- **The destructive-confirmation gate lives in the service.** A command declares
  itself destructive in the catalog; the service then refuses to execute it unless
  the invocation carries an approval whose command id, preview token, and document
  revision all match a preview the service itself minted. An approval computed
  against a document that has since changed is refused, which is the difference
  between a confirmation and a formality. A destructive command that cannot
  describe what it would change is refused for that reason alone.
- **Every unbuilt command is registered and refuses by name.** This build
  implements the twenty-four commands it owns; the other thirty-nine refuse with
  `Nexus.Command.NotYetDelivered` and a message naming the phase that delivers
  them. That makes the Phase 03 defect — an action offered that could only ever
  fail — structurally impossible across the whole inventory rather than avoided by
  care.

Six guards were made to fail on purpose and then reverted: a duplicate chord, a
bypassed confirmation gate, a refusal that stopped naming its phase, a Clear
Completed that cleared everything, a toolbar entry outside the catalog, and a
recency block that admitted a destructive command. Each failed by name while the
rest passed. The duplicate chord failed two guards independently — the conflict
detector in the catalog and the Slate-parity check — which is recorded rather than
smoothed over.

**A decision that binds later phases:** V7-UX-SPEC.md §15 permits a modal dialog
for destructive confirmation, and `Nexus.V7.Shell.NotificationsAreNonModal` forbids
every modal API in `NexusEditorUI`. Phase 04 confirms inline instead, in a region
of the surface directly under the toolbar that raises it, with the safe control
first and holding focus. Recorded in `V7-ARCHITECTURE.md` §7.

These results satisfy the implementing-agent portion of the Phase 04 gate only.
**E3 is not satisfied**, and one acceptance-gate item depends on it: whether menus
and shortcuts are understandable in a live editor. Evidence:
[Phase 04 command system](evidence/phase-04-commands-2026-08-23.md).

### Phase 04 E3 run 1 — 2026-08-23 — three Blocking defects, fixed

The user began E3 and stopped at item 4 of the eleven-item checklist. Two Blocking
defects were found, both in the wiring between the command model and the keyboard,
and neither reachable by the suite as it stood.

- **F-E3-01** — the command palette dispatched a chosen command and dismissed itself
  afterwards. `Show Keyboard Shortcuts` works by reopening the palette in
  shortcuts-only mode, so the dismissal closed the list the command had just opened:
  the command ran, succeeded, and left nothing on screen but an Activity entry.
- **F-E3-02** — **no keyboard shortcut in the product could fire.** All eleven chords
  were declared in the catalog, carried on real `FUICommandInfo` objects, and mapped
  into the module's command list, and no widget ever called `ProcessCommandBindings`.
  `Nexus.V7.Command.Shortcuts` passed against this the whole time, because it asserts
  the bindings are declared, unique, and correctly scoped — never that pressing the
  key does anything.

- **F-E3-03** — the F-E3-02 fix then crashed the editor. Making the surface take
  keyboard focus when its tab activates recurses: setting focus makes the dock stack
  re-activate the tab, which sets focus again, until the stack overflows. Four editor
  processes were lost to it. Fixed with a re-entrancy guard and an early return when
  the surface already holds focus. **This one has no automated guard** — the
  recursion needs a real dock tab in a real window, which the headless automation
  environment does not have. It is held instead by a launch smoke test (engine
  initialized, 150 s, no crash markers) and is explicitly assigned to E3 run 2.

All three are fixed. The palette now dismisses before it dispatches; the shell surface
routes key events into its command list and takes focus when its tab is activated,
which is also what keeps the chords tab-scoped rather than global. Two new guards,
`Nexus.V7.Command.PaletteCommitOrder` and `Nexus.V7.Command.ChordRouting`, were each
reinstated as the original defect, rebuilt, and seen to fail by name while the other
fifteen passed; then reverted, rebuilt, and the full suite returned 64/64 with zero
warnings and zero errors. The command suite is now 17 tests and the gate script's
expected count moved with it.

**E3 has to be re-run from item 1** on the rebuilt editor; items 1, 2, and 5 through
11 were never reached. The fifth acceptance-gate item is recorded as **Not met**
rather than half met until that run completes.

This is the second time a phase's first look at the editor found a defect that the
phase's own automation could not see — Phase 03's unrunnable action was the first.
Both were defects of reachability rather than of logic, which is worth carrying into
Phase 05: a tree row that cannot be clicked passes every test about what it holds.

### Phase 04 acceptance — 2026-08-23

The user performed E3 run 2 on the rebuilt editor, reported the UI displaying
correctly, and accepted Phase 04 as **Complete**. The fifth acceptance-gate item —
*"Menus and shortcuts are understandable without external documentation"* — moves
from **Not met** to **Met** on that inspection.

**What the acceptance rests on, stated exactly.** E1 (three clean builds), E2
(64/64 automation tests), and the user's own editor session. The eleven items in
the E3 script were not reported back individually, so this ledger does not claim an
itemised eleven-of-eleven pass. F-E3-03 — the focus-recursion stack overflow, the
one defect with no automated guard — was assigned to run 2 and is covered by the
session completing without a crash, not by a scripted repro of the
tab-switch/Refresh sequence that produced it. No independent E0 review was
performed, as with Phases 02 and 03.

Phase 04 Complete is the hard dependency Phase 05 lists, so the Hierarchy Tree View
is now unblocked.

### Phase 05 in progress — 2026-08-23

Phase 05, Hierarchy Tree View, is **In Progress**. It is the first phase that puts
production data on screen: the shell has reported Empty since Phase 03 because
nothing binds an authoring document, and Phase 07 still owns the authoring entry
point per finding F-09. Phase 05 therefore also delivers the deterministic fake
data source V7-UX-SPEC.md §21 requires, reachable from editor console commands
rather than from any product menu, so the tree can be reviewed at E3 and exercised
at scale in E2 without Phase 05 claiming Phase 07's entry point.

Carried into this phase from Phases 03 and 04: both first-look defects were
defects of **reachability**, not of logic — an action that could never run, and
chords that were declared but never routed. A tree row that cannot be clicked
passes every test about what it holds, so Phase 05's guards have to assert
interaction, not just content.


### Phase 05 review candidate — 2026-08-23

Phase 05 is **Ready for Review**, which is the implementing agent's ceiling. E1 and
E2 are green on a clean tree: three clean builds and 78/78 automation tests — the
fourteen `Nexus.V7.Hierarchy` tests this phase owns plus the seventeen
`Nexus.V7.Command`, fourteen `Nexus.V7.Shell`, twelve `Nexus.V7.Module`, and
twenty-one `Nexus.V7.Foundation` tests the earlier phases froze — with zero
automation warnings and zero errors. The structural scan passes. The gate script is
`Scripts/VerifyPhase05Hierarchy.ps1`. Evidence:
[Phase 05 hierarchy](evidence/phase-05-hierarchy-2026-08-23.md).

The Hierarchy tab's *World tree* and *Filters* sections are now real. Rows are keyed
by `FNexusSelectionKey`, never by index or name; the tree is a virtualized list over
a view model that owns click semantics, range selection, keyboard movement,
expansion, filtering, favorites, and selection history — and contains no Slate.

Three design decisions carry the phase:

- **The view model owns everything a row does.** Phases 03 and 04 each shipped a
  surface no click could reach with every declaration test green, so click and key
  handling live in `FNexusHierarchyView` and `FNexusSelectionModel` where automation
  can drive them directly. What is left in the widget is covered by
  `Nexus.V7.Hierarchy.RowsAreReachable`, which builds a real row and sends it a real
  mouse event rather than calling the handler behind it.
- **Broken rows are shown, not dropped.** A tree built by walking down from the
  repository's roots loses every record with a missing parent and every record in a
  parent cycle — exactly the rows a user opens the hierarchy to find.
  `V7-QUALITY-GATES.md` §7 forbids that, so the snapshot enumerates every record,
  classifies parentage in one linear pass, and promotes the broken ones to badged
  roots.
- **The incremental-refresh gate got a seam rather than a stopwatch.**
  `GetRebuildCount`, `GetPatchCount`, and `GetLastPatchedRowCount` are asserted at 92
  rows and at the reference scale of 100,000. Three cases deliberately escalate a
  patch to a rebuild rather than produce a plausible-looking wrong tree: an unknown
  changed ID, a moved `Kind` or `SortOrder`, and a `Records` hint with no IDs.

`NexusCommandCatalog::DeliveredThroughPhase` moved from 4 to 5 only after all
nineteen Phase 05 commands had real handlers.
`Nexus.V7.Hierarchy.CommandCoverage` asserts that every catalog command at or below
that number refuses with a reason of its own rather than the not-yet-delivered code,
so raising the constant early fails a test instead of shipping a menu of commands
that quietly do nothing.

**The phase's own guards caught two defects before the editor was opened**, which is
the difference this phase was trying to make. `Nodes[NodeIndex].ChildIndices.Add(AppendPoint(...))`
takes the address of `ChildIndices` before the append reallocates the array; it
survived the 92-row fixture and produced an `EXCEPTION_ACCESS_VIOLATION` on the
100,000-row one. And an assertion about `Focus Search` refusing with no surface open
failed because the running editor already had a Hierarchy tab bound — the behaviour
was right and the question was wrong, so both branches are now exercised against an
isolated command service.

**Two gate items are held at E2 and need E3**, and both are held for the same reason:
automation can prove the counters and the row counts, and only a person can say
whether the view held still and whether a hundred thousand rows feel responsive.
`evidence/phase-05-e3-manual-checklist-2026-08-23.md` is the sixteen-item script.

**Recorded as a deliberate omission:** the phase's task list asks for a loading state
and this build has none. The snapshot is built synchronously, so no frame is drawn
during a build and a loading state could not render. It becomes real when a phase
introduces an asynchronous build, and not before.
### Phase 05 E3 run 1 — 2026-08-23 — stopped at item 1, one finding

The user began E3, loaded the `Normal` fixture, and confirmed States, Cities, and
Highways drew. Item 1 passed on what it asserts. Selecting a row then showed the
Details surface reporting **Blocked — 1 blocking finding**, which item 1 does not
cover.

**F-E3-04.** `FNexusSyntheticHierarchy` stamped `ExpectedWorldPackage` as
`/Nexus/Synthetic`. Nothing mounts `/Nexus/` — the plugin is `NexusFrameworkV7` and
ships no `Content` directory — so `FPackageName::IsValidLongPackageName` failed,
`CanSaveLosslessly` refused the document, and the shell derived Blocked from a fixture
shape documented as *healthy*. Every other fixture in the tree already used
`/Game/NexusV7Tests/SyntheticWorld`.

Fixed during Phase 06 and guarded by `Nexus.V7.Details.HealthyFixtureIsNotBlocked`.
Every Phase 05 test built this fixture and none asked the document whether it was
saveable; that missing question is now asked of Normal, Deep, and Wide, and asked in
reverse of Invalid.

**Items 2 through 16 were never reached.** Phase 05's two E3-dependent gate items —
whether the view holds still on a one-item refresh, and whether 100,000 rows feel
responsive — remain **Not met**. The user chose to move to Phase 06 rather than
continue the run.

### Phase 06 review candidate — 2026-08-23

Phase 06 is **Ready for Review**. E1 and E2 are green on a clean tree: three clean
builds and 98/98 automation tests — the twenty `Nexus.V7.Details` tests this phase
owns plus the fourteen `Nexus.V7.Hierarchy`, seventeen `Nexus.V7.Command`, fourteen
`Nexus.V7.Shell`, twelve `Nexus.V7.Module`, and twenty-one `Nexus.V7.Foundation` tests
the earlier phases froze — with zero automation warnings and zero errors. The gate
script is `Scripts/VerifyPhase06Details.ps1`. Evidence:
[Phase 06 details](evidence/phase-06-details-2026-08-23.md).

The Details tab's *Properties* and *Validation* sections are now real. Selection binds
transient `UObject` edit proxies, never pointers into the document's struct arrays, and
a native `IDetailsView` renders them.

Three design decisions carry the phase:

- **The diff is a reflection walk, not a field list.** One pass over `CPF_Edit`
  properties asking `FProperty::Identical` answers dirty state, "Multiple Values", and
  what Apply writes — for a bool, an `FName`, an `FTransform`, an `FInstancedStruct`
  payload, and an array nested inside that payload alike. That single path is what the
  first acceptance-gate item asks for, and `GenericFieldPath` drives it from a scalar
  down to an array inside an array.
- **Everything a control decides lives in a class with no Slate.** Phases 03, 04, and
  05 each shipped a surface whose behaviour only a real window could reach. Dirty
  state, validation, Apply's label, Apply's eligibility, and what Revert would discard
  are answered by `FNexusDetailsView`, which a test drives directly. What is genuinely
  left in the widget is held by `Nexus.V7.Details.PanelIsReachable`, which builds the
  real panel and counts what the real property view bound.
- **Validation checks only what the document already enforces.** Phase 11 owns the
  validation service; until then Details validates exactly the invariants
  `CanSaveLosslessly` enforces, so a draft Details accepts is one the document agrees
  to save.

**A decision that binds later phases — autosave.** On the user's instruction and
overriding V7-UX-SPEC.md §8.2 and §12.3 (which says outright "the user must still
Apply"), a **finished** property edit commits itself. A native Unreal details panel
has no Apply button, and requiring a press per field is not what editing properties
here should feel like. The draft lifecycle is otherwise unchanged — proxies, validation,
one transaction through the `Apply` command — so there is still exactly one mutation
seam; only who triggers the last step moved.

`EPropertyChangeType::Interactive` never commits, so mid-drag and mid-keystroke values
are not written and undo does not fill with characters. Autosave calls the same
`CanApply` guard the command re-checks. A declined edit is held with its reason, never
discarded. **The footer has no buttons at all**: it reports `Saved` / `Editing` /
`Not saved — <reason>`. A Discard control was built and removed on the user's
instruction — beside a field still being typed into it acts on a half-finished value,
and misbehaved for that reason. Escape abandons the field, undo reverses a commit. The
one subtlety: text is written per keystroke, so Escape has to write the last accepted
value back on `ETextCommit::OnCleared`, or autosave would commit what was just
cancelled. `Revert Draft` survives as a catalog command with its confirmation gate;
removing a footer control is not removing a command. Undo granularity changes to one
step per finished field edit, which is the Unreal convention. Recorded in
`V7-ARCHITECTURE.md` §7.

**A decision that binds later phases — kept drafts.** V7-UX-SPEC.md §8.2 wants Apply /
Keep Draft / Discard / Cancel when the selection changes with a dirty draft, and
`Nexus.V7.Shell.NotificationsAreNonModal` forbids the dialog that would ask. Phase 06
makes **Keep Draft the behaviour rather than an option** — navigating away parks the
draft, returning restores it, Revert is the explicit Discard — and shows the parked
count so the state is visible. Recorded in `V7-ARCHITECTURE.md` §7.

**A defect found at the editor before E3, and fixed.** The user reported that Apply
only became available after editing a text field *and clicking away*. Three causes,
and the interesting one is the third: the panel rebound its property view on every
edit, which rebuilt every row under the widget being typed into; validation was cached
and only recomputed when a widget finished editing; and — the actual reason — the
property editor's stock text row does not write to the object until Enter or focus
loss, so there was nothing for Apply to see. The panel now rebinds only on a
**structure serial** change, proxies raise `OnProxyEdited` from
`PostEditChangeProperty` unfiltered by change type, and a per-instance
`FNexusDetailsLiveTextCustomization` makes text rows write as they are typed.
`Nexus.V7.Details.LiveEdit` is the guard, proven by reinstating the defect and seeing
it fail by name. Recorded honestly in the evidence: the dirty and Apply assertions
passed even with the defect present, because those were already computed on demand —
the cached half was validation only.

**The phase's own guards caught a defect before the editor was opened.**
`IsDraftStale` compared the repository's revision to the revision the targets were
last rebuilt at. Those are always equal, because a repository change is what triggers
the rebuild — so the check could never fire and a draft could be applied against source
the user never saw. `ApplyStaleness` failed on the first run and named it. Staleness is
now per-target: a draft keeps the revision it was authored against, and a dirty target
whose draft and baseline disagree is stale.

`NexusCommandCatalog::DeliveredThroughPhase` moved from 5 to 6 only after Apply and
Revert Draft had real handlers. `Nexus.V7.Hierarchy.CommandCoverage` pinned that
constant to exactly 5 and had to move with it; it now asserts `>= 5`, because pinning
it would make every later phase's delivery fail a hierarchy test and train whoever hits
it to edit the number rather than read the assertion.

**Recorded as deliberate omissions:** the Impact and Diff drawers (§8.1 calls them
optional, and §10.1 says an ordinary single-item property Apply does not need one);
`Apply Valid Targets Only` (§8.3 permits it only where an operation declares partial
application safe, and none does); autosave and the on-disk recovery store (§12, Phase
07's save workflow); and **inherited/overridden indicators** — nothing in the persisted
record carries inheritance at this phase, and deriving an indicator from something
plausible is exactly what Phase 05 refused to do for its five unsourced badges.

**E3 is not satisfied**, and one acceptance-gate item depends on it: whether the panel
is clear and comfortable to edit in. The thirteen-item script is
`evidence/phase-06-e3-manual-checklist-2026-08-23.md`.

### Phase 07 review candidate — 2026-08-24

Phase 07 is **Ready for Review**, which is the implementing agent's ceiling. E1 and
E2 are green on a clean tree: three clean builds and 115/115 automation tests — the
fourteen `Nexus.V7.Crud` tests this phase owns plus the twenty-three
`Nexus.V7.Details`, fourteen `Nexus.V7.Hierarchy`, seventeen `Nexus.V7.Command`,
fourteen `Nexus.V7.Shell`, twelve `Nexus.V7.Module`, and twenty-one
`Nexus.V7.Foundation` tests the earlier phases froze — with zero automation warnings
and zero errors. The structural scan passes. The gate script is
`Scripts/VerifyPhase07Crud.ps1`. Evidence:
[Phase 07 CRUD](evidence/phase-07-crud-2026-08-24.md).

**Started on a dependency that is not met, and the record says so.**
`phases/phase-07.md` lists "Phase 06 Complete"; Phase 06 is Ready for Review, and so
is Phase 05. Both are waiting on the same person for E3. This is the second time the
user has chosen to keep moving rather than wait — Phase 06 was implemented on an
unaccepted Phase 05 for the same reason. It is recorded rather than smoothed over,
because a reader coming to this ledger later must not mistake three stacked
review candidates for three accepted phases.

**Phase 01 finding F-09 is closed.** Until this phase the persisted authoring format
was verifiable only by automation, because nothing in the editor could bind a
document; the shell has reported Empty since Phase 03 for exactly that reason. Three
commands close it — `New Document`, `Open Document`, `Close Document` — added to the
catalog under V7-UX-SPEC.md §6.1, which sets a *minimum* inventory rather than a
closed one, and §3.3, which already assumes a document can be switched and closed.

Four design decisions carry the phase, all recorded in `V7-ARCHITECTURE.md` §7 so
they bind later phases:

- **Atomicity is structural, not procedural.** Every entity mutation builds a
  complete candidate copy of both document arrays, validates the whole graph, and
  only then opens one transaction that swaps them. Nothing is written until the
  whole candidate has passed, so a refused operation *cannot* leave a partial
  mutation — as opposed to not leaving one when every path remembers to unwind.
- **Kind legality constrains new intent and never validation.** A child must sit
  strictly deeper on the World→SubPoint ladder than its parent, asked of Create and
  Reparent only. V7-QUALITY-GATES.md §7 requires a document to show the rows it
  holds, and a rule that refused to load a City at the root would hide exactly the
  record a user opened the hierarchy to fix.
- **An already-invalid document can still have its broken rows deleted.** When a
  candidate fails validation the existing graph is validated too, because the two
  lead to different sentences. Delete alone proceeds in the second case: a document
  that is already invalid cannot be validated back into health, and refusing the
  removal would leave the user with no way out of a document a previous version
  wrote. An ordinary rename in the same document is still refused, with a message
  naming the pre-existing damage rather than blaming the edit.
- **Draft recovery is text, written whole, and never resolves a conflict itself.**
  Records go to `Saved/NexusV7/Recovery`, keyed by project, document, and the source
  revision they were authored against. A record whose revision no longer matches is
  refused by name: §13 forbids last-writer-wins without an explicit policy, and the
  per-field resolver belongs to Phase 10.

`NexusCommandCatalog::DeliveredThroughPhase` moved from 6 to 7 only once all eleven
Phase 07 commands had real handlers. `Nexus.V7.Details.CommandCoverage` pinned that
constant to exactly 6 and had to move with it; it now asserts `>= 6`, for the same
reason the hierarchy suite's equivalent asserts `>= 5` — pinning it makes every later
phase's delivery fail a test that says nothing about the phase it lives in.

**The phase's own suite caught a defect the first time it ran, and it was in Phase
01's code rather than this phase's.** The frozen graph validator ends by checking
every activation point against the payload type registry, and nothing in this build
registers a payload type — so *every entity mutation on any document holding an
activation point was refused*, renaming a City included. Until Phase 14 delivers the
real type catalog, every document in the project is in that state. Entity mutations
now run the structural rules and stop before the registry check; it is one
implementation with an explicit parameter, not a second copy of the rules.

**Proven, not asserted.** `Nexus.V7.Crud.AtomicRollback` was made to fail on purpose:
`ApplyBatch` was changed to write each record as it went, and the test failed by name
— *"and none of the valid edits was written"* — while the other thirteen passed.
Restored, rebuilt, and re-verified at 115/115.

**Recorded as deliberate omissions,** each short of a named thing rather than of work
in general: reparent has its service, legality rule, cycle refusal, and tests but no
UI gesture, because the tree has no drag-and-drop and the catalog has no Move
command; conflict handling covers stale selection and unknown payload and leaves
external asset change and ownership mismatch to Phase 10; activation points are not
creatable from the UI until Phase 14 registers a payload type; and Home does not yet
list recoverable work, though the store and the context strip's indicator are
delivered. The three corresponding task boxes in `phases/phase-07.md` are left
unchecked rather than claimed.

These results satisfy the implementing-agent portion of the Phase 07 gate only.
**E3 is not satisfied**, and *all seven* acceptance-gate items depend on it. The
eighteen-item script is
[phase-07-e3-manual-checklist-2026-08-24.md](evidence/phase-07-e3-manual-checklist-2026-08-24.md).
The restart item is the one nothing else can meet: this project's rule is that
session-only data is not acceptance evidence, the automated lifecycle test reloads a
package rather than restarting the editor, and only a person can close the editor and
open it again. No independent E0 review was performed, as with Phases 02 through 06.

### Phase 07 user-reported follow-up — 2026-08-27

Phase 07 stays **Ready for Review**. Two user reports against the Phase 07 build were
closed; no architectural contract changed, so no checkpoint reopens. Three clean
builds, `PASS: 122 tests, 0 failures`, `FOUNDATION STRUCTURAL SCAN: PASS`, and 124/124
across all of `Nexus.V7`.

**The chrome was built once per surface and drawn three times.**
[`shell-chrome-and-density.md`](../agent-todos/ready-for-review/shell-chrome-and-density.md).
`SNexusShellSurface::Construct` built the same seven-slot column for every surface with
no branch on which surface it was, so three open tabs meant three toolbars, three
notification lists, and three copies of every banner — each with its own Dismiss, any
one of which cleared all three. `FNexusSurfaceChrome::For(Surface)` now resolves the
per-surface rules once at the top of `Construct`, and
`FNexusShellNotification::Origin`, stamped by a scope around every command run, makes a
message belong to the surface it was invoked from. The toolbar is Hierarchy-only, which
is where V7-UX-SPEC.md §7.1 puts it; §8.1 gives Details a sticky footer instead and
§14.1 gives Activity a filterable list, so this moves toward the spec rather than away.

**Density.** `Nexus.ToolBar` is a Nexus-owned copy of the engine `SlimToolBar` with the
glyph at the engine-standard 16px and the padding cut: ~40px to ~22px. `Nexus.SearchBox`
takes the search field from `8,3,8,4` to `6,2,6,2` and no further, because a caret needs
the room. The surface header is gone outright — worth about 60px per tab, more than the
toolbar — since the tab label and its tooltip already carry the name and description,
and its readiness badge was the second of three on one panel.

**The context strip stays on all three tabs.** §3.3, §7.1 and §8.1 all require it, and
the user chose to condense rather than remove it: Details and Activity now show badge,
document name, and the dirty marker, with the entity count, revision, and path in the
tooltip the widget already built. **No spec amendment is needed** — §3.3 asks for a
*compact* strip and this is the first build in which it is one.

**Who writes the asset.**
[`save-and-dirty-ownership.md`](../agent-todos/ready-for-review/save-and-dirty-ownership.md).
`FNexusDocumentStore::Create` no longer calls `Save`, so `Nexus.Document.New` leaves the
asset dirty and unwritten as V7-UX-SPEC.md 12.1 requires and as Unreal's own
create-asset flow behaves; `Nexus.V7.Crud.DocumentLifecycle` flipped the assertion that
had pinned the old behaviour in place. `Nexus.Document.Save` goes through
`UEditorLoadingAndSavingUtils::SavePackages` rather than `UPackage::Save`, so a
source-controlled asset is checked out and a new file marked for add — the user's
decision, recorded because it changes user-visible behaviour on a phase awaiting review.
The Details footer says **"Applied — Ctrl+S saves the asset"** rather than "Saved", and
the enum behind it was renamed `Saved` → `Applied` so the label cannot regrow.

**New guard.** `Nexus.V7.Shell.ChromeIsNotRepeated` counts chrome widgets across all
three surfaces — nothing did before, which is how three copies shipped with every
per-surface assertion green. Proven by reverting both fixes and re-running it first.

**E3 gained two checks**, 14 and 15, both written to be run with all three tabs open at
once, which is the only configuration in which the original report is visible. The
checklist is eighteen items now, and the phase is no closer to Complete than it was:
E3 has still been run on none of Phases 05, 06, or 07.

### Phase 07 dirty and save affordance — 2026-08-27

Phase 07 stays **Ready for Review**. A third user report against the same build, and
the most serious of the three: *"when i made any changes, i cannot see the dirty in
editor and editor not showing dirty or save, the editor not tracking maybe it has
some changes and need to save."* Three clean builds, `PASS: 122 tests, 0 failures`,
`FOUNDATION STRUCTURAL SCAN: PASS`, 125/125 across all of `Nexus.V7`.

**The dirty flag was never wrong.** Every entity mutation does `Modify()` plus
`MarkPackageDirty()` inside its transaction, `FNexusDocumentStore::IsDirty` reads
`UPackage::IsDirty`, and `Nexus.V7.Crud.DocumentLifecycle` asserts it. Unreal's own
Content Browser asterisk worked throughout. What failed was everything between the
flag and the user:

- The `UNSAVED` marker was drawn in `Nexus.Text.Caption` — **8pt, `TextMuted`** — the
  smallest and lowest-contrast token in the palette, on a strip that until this week
  also carried a full document sentence, a workspace combo, and a palette button. It
  is now `Nexus.Text.BodyStrong` in the palette's `Dirty` amber.
- **`Nexus.Document.Save` was reachable from the command palette and nowhere else.**
  Not the toolbar; not the ten entries V7-UX-SPEC.md §3.1 fixes for the Window
  submenu; not the row context menu, which draws the Create, Edit, and Context groups
  and not File; and it has no chord, because §16 defines none. A user who did not
  already know the command's name could not save their work. Third instance of
  `declared-is-not-reachable` in this project.

**Two routes now.** A **Save** button sits beside the dirty marker in the context
strip — present on all three tabs, because §3.3 puts the strip on all three, and
visible only while there is something to save, which is exactly when `GuardSave`
considers the command eligible. And **Save Document** leads the Hierarchy toolbar.
Both go through `OnRunCommand`, so they share the palette's eligibility and refusals.

**One of the three was mine.** The Details footer line added earlier the same day
read *"Applied — Ctrl+S saves the asset"*. The shell is a nomad tab, so `Ctrl+S`
there is Unreal's level save; the line named a keystroke that does not do what it
said. It reads *"Applied — the asset is not saved yet"* now and names no chord. The
same false instruction had gone into `phases/phase-07.md` step 3 and is corrected
there.

**New guard.** `Nexus.V7.Shell.SaveIsReachable` asserts Save Document is in the
toolbar list, then builds a real context strip against a dirty document, finds the
button, and **clicks it**, checking the command id that comes back. Proven by
unwiring `HandleSaveDocument` and re-running: *"Expected 'the context strip's Save
control runs a command' to be true."* It also asserts the control is not offered
against a clean document.

**E3 gained check 16.** The checklist is sixteen items.

**Every phase file now carries a How to Test section**, six points each, per the
convention recorded on 2026-08-24; only `phase-07.md` had one. Phases 01 through 06
each state their gate script and its exact expected line — 33, 52, 69, 83, and 106
tests for 02 through 06, all re-run to confirm the numbers rather than copied.

### Phase 07 authoring from zero — 2026-08-27

Phase 07 stays **Ready for Review**. Two more user reports, one of which caused the
other. Three clean builds, `PASS: 122 tests, 0 failures`, `FOUNDATION STRUCTURAL SCAN:
PASS`, 126/126 across all of `Nexus.V7`. Written up in
[`empty-tree-cannot-author.md`](../agent-todos/ready-for-review/empty-tree-cannot-author.md).

**A new document could not be authored at all.** `SNexusHierarchyTree` collapsed its
list whenever it held no rows, and a collapsed widget receives no mouse events. Create
lives in the list's right-click menu, so an empty document — which is what New
Document produces — had no surface a right-click could land on and no way to make the
first entity. The user's workaround was `Nexus.Fixture.LoadSample`, and authoring from
zero is the one thing a fixture cannot help with.

The command layer was correct throughout, which is why every existing assertion
passed: `FNexusAuthoringView::GetLegalCreateKinds` already treats an empty selection
as targeting the document root, where World and State are legal, and says so in a
comment. Every test of Create ran against a selection.

The list and the empty state are an `SOverlay` now — the list always visible and
hit-testable as in the Content Browser and the World Outliner, the panel over it
`SelfHitTestInvisible` so it cannot swallow the right-click. The empty state also
gained a headline, a next action, and **Create State** / **Create World** buttons
built from the same `GetLegalCreateKinds` the menu uses, both routed through one new
`NexusMenus::RunCreate`. It now follows the pattern `SNexusActivityLog` has used for
its empty scopes since Phase 04.

**A stale message went with it.** `StateNoDocument` read *"Phase 07 delivers the
authoring entry point that opens one"* — true when written, false the moment Phase 07
delivered it, and a test asserted the string `Phase 07` was present. A message that
names a future phase has an expiry date; one that names the command does not. Both
now name New Document, and the test asserts the phase string is absent.

**The second report was a consequence of the first.** Forced onto a fixture, the user
saw no asset and no dirty state. A fixture lives in the transient package, so
`MarkPackageDirty` does nothing and `IsDirty` is false however much is edited — and
the strip drew empty space and no explanation, which reads as the editor having lost
the work. `FNexusShellDocumentInfo::bPersistent` now drives an `IN MEMORY - NO ASSET`
marker in the palette's `Stale` purple, deliberately not the `Dirty` amber, with a
tooltip naming the fixture command and New Document. Save stays hidden.

**On the per-map config asset V6 auto-created** — `Content/NF/Maps/<MapName>/NexusConfig.uasset`
— this is neither missing nor a regression. `V7-ARCHITECTURE.md` §"World/config
discovery and duplication" replaced that convention-based lookup with an explicit
editor-only `ANexusWorldAnchor` precisely so *"discovery never chooses the first asset
or first Landscape it happens to find"*; restoring V6's behaviour is an architecture
change that reopens Phase 01. And `phases/phase-10.md` owns it outright — scope bullet
one, *"Automatic world-config discovery/creation"* — with Phase 10 blocked behind 09,
behind the Phase 08 gate, behind this phase. `ANexusWorldAnchor` is not in the source
yet, by design.

**Superseded on 2026-08-27** by “Phase 07 per-map document and the default
hierarchy” below: the convention half of this was implemented after a third request.
The architecture point above still holds — the anchor remains authoritative once
Phase 09 creates it, and the derived path is a fallback, not ownership.

**Guards.** `Nexus.V7.Hierarchy.EmptyIsAuthorable` binds an empty document to both the
view and the subsystem — binding only the view would leave Create with nothing to
target and the test measuring the harness — then checks the real list's visibility,
reads the Create submenu, and presses the empty state's button. Proven by restoring
the collapse rule and re-running. `Nexus.V7.Shell.SaveIsReachable` gained the fixture
case. **E3 gained checks 17 and 18**; the checklist is eighteen items.

### Phase 07 per-map document and the default hierarchy — 2026-08-27

Phase 07 stays **Ready for Review**. `Result: Succeeded` on the editor target and
`PASS: 124 tests, 0 failures` via `Scripts/VerifyPhase07Crud.ps1 -SkipBuilds`. Written
up in [`empty-tree-cannot-author.md`](../agent-todos/ready-for-review/empty-tree-cannot-author.md).
The three clean builds and the full `Nexus.V7` sweep from the entry above have not
been re-run for this change.

**The per-map config asset is implemented, and the entry above is superseded on that
point.** The user asked for it three times and was answered three times with a phase
boundary. The boundary was real and the answer was still wrong: a correct scope
argument, repeated to someone who has already heard it twice, stops being
information.

`FNexusDocumentStore::GetDocumentPackageNameForWorldPackage` derives
`<MapFolder>/<MapName>/NexusConfig` from a world package — V6's own convention, and
the one Unreal's Landscape layer assets use. `ResolveForWorldPackage` opens that
document if it exists, returns the in-memory one if this session already made it, and
otherwise creates it. `UNexusEditorSubsystem` calls it from
`FEditorDelegates::OnMapOpened`, from `MapChange` (which is the only signal File > New
Level broadcasts — V6 established that from the engine source), and from one deferred
tick for the map already open at startup.

**One deliberate difference from V6: nothing is written to disk.** V6 called
`SavePackage` in its create path. V7 leaves the document dirty and unsaved, which is
what section 12.1 requires, what Unreal's own create-asset flow does, and what the
user described: *"make it dirty and showing unsaved in UE editor"*.

It binds nothing for an unsaved map, an engine map, or a play world, and it drops a
document it bound itself when the new map has none — leaving the previous map's
document live and editable is a bug V6 shipped and reported. `Nexus.AutoBindWorldDocument 0`
disables it; it is skipped under `-unattended` so an automation run cannot leave a
dirty package beside whatever map it opened.

**This is a Phase 10 task pulled forward, and `phases/phase-10.md` says so** under a
new "Delivered Early" heading, including what is still Phase 10's: the
`ANexusWorldAnchor` reference that is authoritative over this convention, the
ownership-mismatch clone/relink/cancel choice, and everything from mapping onward.
The first Phase 10 task stays unchecked, because "using Phase 01 ownership rules"
means the anchor and the anchor does not exist yet.

**Create Default.** The empty state's per-kind buttons left the user one row deep with
every kind below City still unreachable; the user asked for a `Default State >
Default City > Default Highway` seed instead. A new catalog command
`Nexus.Authoring.CreateDefaultHierarchy` makes that chain in one `CreateMany` — one
transaction, one undo step, identities generated up front so a child request can name
a parent created earlier in the same batch. It refuses a document that already holds
entities, and the button is drawn only when that guard says yes. It is V6's
`SeedDefaultHierarchyIfEmpty` with the automatic part removed: a press, not something
a document does to itself.

**Guards.** `Nexus.V7.Crud.DefaultHierarchy` and `Nexus.V7.Crud.WorldDocumentBinding`
are new. `Nexus.V7.Hierarchy.EmptyIsAuthorable`'s probe was returning the command id
as a literal, which would have passed against a button wired to nothing; it now reads
the seeded rows back out of the live document. **The map-open delegate itself is not
covered** — the bind is skipped under `-unattended`, so opening the map in an
interactive editor and seeing the asset appear dirty stays a manual check.

**Tree row presentation.** Asked for separately the same day: *"the tree view design is
not very good … put the arrow icon good put just more 10% padding."* The expander was
the literal characters `v` and `>` in the body font, and is now the engine's
`TreeArrow_Expanded`/`TreeArrow_Collapsed` brush centred in a fixed-width column, so
names line up whether or not a row has children. Selection moved from a flat
`SurfaceSunken` fill running corner to corner to an inset rounded accent pill
(`Nexus.Brush.RowSelected`), and rows gained a hover state they never had
(`Nexus.Brush.RowHovered`) — bound rather than resolved at construction, because a row
that only lights up when the list rebuilds lights up almost never. Padding is up ten
percent, applied to the row rather than to the 4px scale step: 24px of row becomes
26.4px, where ten percent of the step alone would have been 0.4px. Both new brushes
are in `GetBrushNames()`, so the existing shell test covers them resolving. **Whether
it looks right is a person's judgement and is E3 check 21**; no automation reaches it.

### Phase 08 first measurement pass — 2026-08-28

Phase 08 is In Progress. E1 and E2 only: 136 of 137 tests pass, no E0, no E3, no clean
builds, and the Dependencies line — Phases 03 through 07 Complete — is not satisfied.
Work started on the user's instruction, as Phases 06 and 07 each did on an unmet
dependency.

The gate item **"Representative scale meets Phase 01 UI budgets" had no evidence
behind it at all**. `Nexus.V7.Hierarchy.Scale` states in its own comment that its
ceilings are deliberately loose and are "not the budget measurement". The new
`Nexus.V7.UiGate` suite is that measurement: nine tests against the exact lines in
`V7-UX-SPEC.md` section 19 and `V7-ARCHITECTURE.md` section 12, at the 100,000-row
reference scale, appended to a dated artifact carrying a byte count and a SHA-256.

Measuring it found four Blocking defects that every previous phase gate had passed
over, because all four are invisible at the sizes the earlier suites use.

**Fixed.** F-08-01: four sort tie-breakers spelled as
`Left.ToString() < Right.ToString()` on an ID, formatting roughly 3.4 million GUID
strings to sort the reference tree; sort 411.6 → 28.7 ms. F-08-02: the row filter
built four strings per row before knowing which the query needed, 400,000 allocations
a keystroke; search worst keystroke 617.2 → 181.4 ms. F-08-03: three quadratic paths
on the selection route, so **Select All Visible — a Phase 05 command, bound to a
chord, shipping in this build — would have hung the editor on the reference tree**;
it now answers in 22.4 ms.

**Open.** F-08-04: `FNexusDetailsView` builds a draft proxy for every selected entity
eagerly. Section 19 requires details "calculated incrementally afterward if needed"
and no such path exists, so Select All costs 1264 ms against a 300 ms budget. The
1,000-item case the spec names passes at 13.7 ms, which is why nothing caught it.
`Nexus.V7.UiGate.SelectAllAtScale` fails on this and is left failing: closing it
changes a contract Phase 06 owns, and that reopens the owning checkpoint.

**Needs a reading, not code.** F-08-05: the gate says no required UI behaviour may be
deferred to Phase 09 or later, and the catalog deliberately registers 16 commands
owned by Phases 10 to 16 that refuse by name. Both cannot be right as written.
F-08-06: this phase lists the ownership-mismatch state among those to test, and
`phases/phase-10.md` "Delivered Early" already reserves it.

Evidence: [Phase 08 UI gate first pass](evidence/phase-08-ui-gate-2026-08-28.md).

### Hierarchy ladder narrowed to four rungs — 2026-08-28

On the user's instruction, and inside Phase 08's own scope of "integrated audit and
correction of Phases 03–07" — before the same phase freezes the UI/service contracts
later systems consume. Doing it after that freeze would have been a contract break;
doing it now costs an amendment to an E3 checklist that has not been run.

The authoring hierarchy is **State > City > Highway > Highway Point**, and each rung
accepts only the one directly below it. `World`, `Road`, `Junction`, and `SubPoint`
are retired from the ladder. A Highway Point stays a legal child of a Highway but is
never offered in a menu: Phase 10 reconciles those from landscape geometry, so
`IsLegalChild` and the new `GetCreatableChildKinds` now answer separately. Default
names are numbered document-wide — `New City 3` — rather than colliding into a ` 2`
suffix.

**Three unshipped phases already assumed this shape**, which is why the change is a
narrowing rather than a redesign: `phases/phase-16.md` compiles "canonical
State/City/Highway/HighwayPoint records"; `phases/phase-11.md` lists junctions and
lanes *beside* those four as graph attributes rather than as rows; `phases/phase-09.md`
and `phases/phase-12.md` treat junctions purely as landscape topology.

**Two things constrain the retirement.** `phases/phase-14.md` lists sub-points as an
Activation Point deliverable and `NexusRuntimeDataset` already treats `SubPoint` as a
payload-carrying kind, so the enum value and its runtime carve-out stay. `World` keys
the document itself in the Reload and Close previews. Deleting any value would
reindex `ENexusEntityKind` and change the kind of every record already serialized, so
all four remain values that nothing creates and nothing accepts.

E1 and E2 only: clean editor build, and 125 tests with 0 failures on the Phase 07
CRUD sweep — one more than the 124 baseline, being `Nexus.V7.Crud.DefaultNaming`.
**Not E3.** The rule change is visible only in menus, buttons, and the names new rows
carry, so checks 2, 17, and 20 of
[the Phase 07 E3 checklist](evidence/phase-07-e3-manual-checklist-2026-08-24.md) were
amended in place and still have to be run by a person.

Decision recorded in `V7-ARCHITECTURE.md` §"Entity kind legality", which supersedes
the eight-rung rule Phase 07 set on 2026-08-24.

`TASK-LIST.md` holds that a changed architectural contract reopens the owning
checkpoint and every affected downstream phase. The owner is **Phase 07**, which is
Ready for Review rather than Complete, so what reopens is its unrun E3 — it cannot be
assessed against the old checklist. **No downstream phase reopens**: Phases 10, 11,
14, and 16 are Not Started and each already describes the four-rung shape, which is
why this was assessed as a narrowing rather than a contract redesign.

### F-08-07 — inline rename wrote to the wrong row — 2026-08-28

**Blocking, fixed.** Reported by the user: creating a Highway and then clicking
another row while the inline editor was still open refused with
`Nexus.Authoring.NameCollision: Another item under the same parent is already called
'New Highway 4'`.

The collision was the *lucky* case. An inline editor commits its text when it loses
keyboard focus, and the click that takes focus away moves the **selection** first.
`ExecuteRename` resolved its target from the selection, so the name typed into one row
was applied to the row that had just been clicked. Against a sibling that refused, and
named a row the user had never opened an editor on. **Against a row under a different
parent it succeeded silently** — an entity renamed by a click, with an undo step that
looks deliberate. Every automated rename test passed throughout, because all of them
set the selection to the row they were editing.

The view already tracked which row the editor belonged to and nothing cleared it on a
selection change, so the fix is to ask it: an in-flight inline commit names its own
row, and only a rename with no editor open falls back to the selection. The guard was
widened to match, because the same click can clear the selection entirely and used to
refuse with "Select an item in the hierarchy to rename" — blaming the user for a
rename they had already typed. `SNexusHierarchyRow::HandleNameCommitted` also refuses
to commit when it is not the live rename target, so a stale row widget cannot write
another row's name.

Regression test `Nexus.V7.Crud.RenameFollowsItsRow`, **verified by disabling the fix
and watching it fail with the reported message**. Suite: 126 tests, 0 failures.

### F-08-08 — a second State could not be created — 2026-08-28

**Blocking, fixed.** Reported by the user: *"How i can create the state? Not possible
to create state."*

A State row offers City inside it, and a State's parent is the document root, which is
not a row anyone can select. So once a document had one State, the only route to a
second was to clear the selection first — and nothing on screen says so. Narrowing the
ladder to one child per rung is what made it total: before that the root at least
offered World and State together, and the same gap existed for every rung without
being reachable-looking.

Create now has a **target** as well as a kind. `UnderSelection` is what it always did;
`AlongsideSelection` creates under the parent the selected row already has, which for a
State is the root. The Create submenu draws two sections, *Inside the selection* and
*Alongside the selection*, so a State row offers City in the first and State in the
second and neither entry has to be relabelled into a sentence.

Three things fell out of it. The kind is validated against the list the chosen entry
came from — checking a sibling choice against the *child* list would have rejected it
and fallen back to the first child kind, so picking "State alongside" would have made a
City inside. The target is cleared by Create while the kind stays sticky, because
"alongside" belongs to the entry that was clicked and a sticky one would redirect the
next Insert. And a Highway is no longer a Create dead end: nothing goes inside it, but
another Highway goes beside it.

Regression test `Nexus.V7.Crud.CreateAlongside`, plus the submenu-parity assertions in
`Nexus.V7.Crud.CreateMenuIsReachable`. Suite: 127 tests, 0 failures.

### F-08-09 — a shell state nothing could enter — 2026-08-28

**Blocking, fixed.** Found by asking a question the existing state tests do not ask.
`Nexus.V7.Shell.StateDerivation` and `Nexus.V7.Shell.StatePresentation` build an
`FNexusShellSignals` by hand and check what comes out of it. Both cover all nine
states exhaustively. Neither says whether the editor can produce those signals.

`ENexusShellState::Stale` could not be produced. `GetSignals` read `bSourceStale` from
a member with **no caller anywhere in the editor** — `SetSourceStale` was dead API. The
state was documented, derived, ranked in the precedence order, given a headline and a
detail, and unreachable from the day it was written.

It was not a state V7 does not need. `FNexusDetailsView::IsDraftStale` detects exactly
what it describes — a draft authored against a revision the document has left behind —
and Apply refuses while it holds, with "The document changed after these edits were
made." The shell, at that same moment, said **Dirty**: one surface refusing the commit
and another reporting nothing wrong.

`GetSignals` now ORs in `FNexusDetailsView::Get().IsDraftStale()`. The member stays,
because Phase 09 owns a second staleness — the landscape source — that the Home health
list already reports separately; a new "Pending edits" line names the draft case, since
one Stale chip cannot say which of the two is meant. The provider also subscribes to
`OnChanged`, because staleness *ends* on a reload or a revert, which moves no revision
and would otherwise leave the strip Stale after Apply had stopped being refused.

New suite `Nexus.V7.UiStates`, four tests, driving the real provider over the real
subsystem. `EveryShellStateHasARealProducer` walks all nine states through real
conditions and asserts it reached nine, so a tenth added later fails until something
can enter it. **Verified by disabling the fix and watching it fail** with
`a document under a stale draft reads as Stale, not Ready`.

This is the third instance of `agent-memory/declared-is-not-reachable.md` and the first
where the unreachable thing is a *state*. A command that is not delivered says so by
name through `OwnerPhase`; a state has no equivalent.

### F-08-10 — a same-day re-run destroyed a cited artifact — 2026-08-28

**Blocking, fixed.** `Scripts/VerifyPhase08UiGate.ps1` labelled its budget artifact
`yyyy-MM-dd` and copied with `-Force`. The Phase 08 first pass ran on 2026-08-28 and
cites `ui-budgets-2026-08-28.txt` by byte count and SHA-256. This pass ran on the same
day and overwrote it. The digest in that record now matches nothing, and `Saved/` is
gitignored, so it is not recoverable — the note at the citation says so rather than
leaving a dead digest standing.

The dated-name convention was itself the fix for this failure class on 2026-08-23. A
date separates phases and not runs, and a gate script is the one that gets re-run
repeatedly within a day. The label now carries a time, **and** the copy step refuses an
existing destination instead of forcing, which is the half that also covers an explicit
`-RunLabel`.

### F-08-11 through F-08-13 — 2026-08-28

**F-08-11** is the first pass's placeholder sweep, renumbered from F-08-07 because the
user's two reported defects had taken 07 and 08 in this ledger before the collision was
noticed. Those two are named in commit messages; the sweep is not, so it is the entry
that moved.

**F-08-12, fixed.** `SNexusContextStrip::FArguments` initialised its members out of
declaration order, so every editor build emitted C5038. Harmless in effect, and E1 for
this phase is a *clean* editor build: a build that always carries one warning is a
build where the next one is invisible.

**F-08-13, fixed.** A test written in this pass loaded a package that migrates on load.
Migration marks it dirty, `UPackageTools::UnloadPackages` cannot unload a dirty package,
and it says so **in a modal dialog** — which an unattended run answers itself and
continues past, leaving an asset in `Content/` on every run and reporting nothing.
Recorded rather than only fixed, because any future test that loads a migrating package
hits the same thing.

### Phase 08 presentation-state pass — 2026-08-28

E1 and E2 only. Clean editor build with **no warnings** after F-08-12. 143 of 144 tests
pass; the failure is `Nexus.V7.UiGate.SelectAllAtScale`, which is F-08-04 and open by
design because closing it changes a contract Phase 06 owns.

Eight of the nine states the phase task names are now produced by real editor
conditions and read back through the real provider: empty, loading, dirty, invalid and
blocked, unknown-payload, stale, and save-failure.

**Ownership-mismatch is the ninth and could not be tested.** It has no representation
anywhere in the build — no shell state, no target state, no diagnostic code, nothing
that detects it — and `phases/phase-10.md` reserves it. Inventing one here would be a
placeholder, which this same gate forbids. F-08-06 is therefore narrowed to one
question with two answers: either the Phase 08 task line defers to the Phase 10
reservation, or that reservation gives it up and backend work has to start before this
gate can close. **This still needs the user's reading**, as does F-08-05.

Seven of the nine Phase 08 tasks remain, E0 has not been performed, and E3 — which
subsumes the outstanding Phase 05, 06, and 07 E3 runs — has not been performed.

Evidence: [Phase 08 presentation states](evidence/phase-08-ui-states-2026-08-28.md).

### User decisions on the open Phase 08 readings — 2026-08-28

Two of the three findings that needed an owner's reading rather than code are now
answered. Both were asked as plain questions and answered directly.

**F-08-05 — CLOSED. The pending-phase commands stay.** The gate item "No required UI
behavior is deferred to Phase 09 or later" is read as *nothing Phases 03–08 owe is
deferred*. The catalog's commands owned by Phases 10 to 16 keep their menu entries and
keep refusing by name with the phase that delivers them.

> User, 2026-08-28: *"maybe no need to change here phase 12 will done."*

That is the Phase 04 design and it is not a dead item: a command that answers "Phase 12
delivers this" told the user something true. `DeliveredThroughPhase` stays at 7, every
command at or below 7 has a real handler, and every command above it resolves to
`FNexusPendingPhaseCommandHandler`. `Nexus.V7.Hierarchy.CommandCoverage` holds that
line, so the reading is enforced rather than remembered.

**The hierarchy shape is confirmed, and the bottom two rungs are meant to be
unbuildable by hand.**

> User, 2026-08-28: *"Hierarchy : State > City > Highway > Points auto sync from
> landscape > Activation point will crate in future phase."*

This was raised because "the hierarchy is correct" and "a person can build the whole
hierarchy" are different sentences, and only the first is true today. On a new document
the Create menu offers State, City, and Highway and then stops. Highway Points are
reconciled from landscape geometry by Phase 09/10 and Activation Points arrive with
Phases 12 and 14 — `FNexusActivationPointCommandService::Create/Delete` already exists
and is tested, and nothing in the UI calls it, deliberately.

> User, 2026-08-28, on adding either by hand now: *"it will comes maybe in future
> phase."*

So Phase 08 does not owe a Create route for either. `V7-ARCHITECTURE.md`
§"Entity kind legality" carries the confirmed shape.

**Also confirmed against the code, all three correct as the user described them:**

- **Nothing autosaves the document.** `FNexusDocumentStore::Save` is the only writer of
  the `.uasset`, and the Save command is its only caller. The two things named
  "autosave" do something else: a finished property edit auto-commits *into the
  document* through the Apply command, which makes it dirty and writes nothing; and
  after ten idle seconds a crash-recovery copy of any still-unapplied draft is written
  under `Saved/`, never to the asset.
- **Dirty is the signal, and the user saves.** The package dirty flag is what the shell,
  the context strip, and Unreal's own asterisk all read.
- **Undo/redo re-marks the document dirty**, and `RefreshAfterUndo` rebuilds the index
  and reloads Details from what the undo actually left behind.

**F-08-06 remains open.** Ownership-mismatch is still the one state in the Phase 08
task list with no representation in the build and a Phase 10 reservation over it.

### Phase 08 bounded Details selection — 2026-08-31

**F-08-04, Blocking, resolved at E2.** The actual Ctrl+A route can select 100,000
items. Details now preserves every selected key but materializes editable
baseline/draft proxies only for selections of 1,000 or fewer. Above that bound it uses
SelectionDeferred: an explicit summary-only panel with native property bindings
removed. Editing, Apply, Revert, and revert preview refuse until the selection is
narrowed. A prefix must never be bound, because Apply would then silently mutate only
that subset.

A pre-existing dirty proxy from a still-selected entity remains dormant for recovery
during the summary state and is revision-checked when rematerialized. The real
subsystem selection path also changed from a quadratic ordered membership scan to an
order-preserving set. Automated tests cover the deferred state, recovery/staleness
after a repository change, the 1,000 interactive boundary, 100,000 Select All, and
the hierarchy-to-subsystem-to-Details route.

E2 ran Scripts\VerifyPhase08UiGate.ps1 -SkipBuilds -RunLabel 2026-08-31-f08-04-r5:
148 tests passed with 0 failures and 21 budget measurements had 0 overages. Its
artifact is Saved/NexusV7/Phase08/ui-budgets-2026-08-31-f08-04-r5.txt, 1,011 bytes,
SHA-256 bce7ad867dfebf570755dad3c6d3912f0111dd28af376bdf85f3da26c9f23d8f. A separate
non-clean Development Editor compile succeeded in 17 actions, but it is not E1
evidence. The corrected script verdict reports E2 only when builds are skipped. This
does not substitute for the required clean builds, E0, E3, or the still-open F-08-06
decision; Phase 08 remains In Progress. Phase 06 remains Ready for Review with its
unrun E3 checklist amended for this correction. Full
implementing-agent evidence:
[bounded Details selection](evidence/phase-08-large-selection-2026-08-31.md).

### Phase 08 first full clean E1+E2 pass, and F-08-14 — 2026-09-01

The two 2026-08-31 large-tree corrections above (collapsed-tree idle lag, row-menu
hover lag) were committed with their regression tests **unbuilt and unrun**: a local
`dotnet.exe` error was blocking UnrealBuildTool. That blocker is resolved on this
workstation — a plain editor build now succeeds — so this is the first combined clean
build and full `Nexus.V7` run covering those two corrections together with the
2026-08-31 bounded-Details correction before them.

**F-08-14, Blocking, fixed.** That first real run (clean builds, not `-SkipBuilds`)
failed `Nexus.V7.Crud.RecoveryBeforeReload`. Git history shows this test was added in
the same commit as the bounded-Details correction (8a617fe) but *after* that commit's
own cited evidence run had already finished — its log has zero occurrences of the
test's name — so this was the first time the test had ever actually executed, not a
regression from either lag fix.

Root cause: `UNexusEditorSubsystem::SetActiveDocument`'s `ActiveDocument == InDocument`
no-op fast path is fooled specifically by the Reload command, because
`UPackageTools::ReloadPackages` silently repoints the still-rooted `ActiveDocument`
pointer at the newly reloaded object *before* Reload's own explicit
`SetActiveDocument` call runs. The guard then reads "nothing changed" and skips
rebinding the Details repository, leaving it pointed at the object the reload just
destroyed — so a post-reload `Recover Draft` finds nothing to restore. Fixed with a
`bForceRebind` parameter passed `true` only from the Reload path; every other caller
(New/Open/Close Document, every test) keeps the prior fast-path behavior unchanged.
Confirmed by reproducing the failure in isolation with temporary diagnostic logging
before fixing it, then verifying the full `Nexus.V7.Crud` suite (22 tests) passes with
no other regressions after the fix.

E1: three clean builds, all passing. E2: `Scripts\VerifyPhase08UiGate.ps1` (no
`-SkipBuilds`) — 154 tests, 0 failures; 21 budget measurements, 0 over. `PHASE 08
E1+E2: PASS`. Budget artifact
`Saved/NexusV7/Phase08/ui-budgets-2026-09-01-193242.txt`, 1,013 bytes, SHA-256
`987C0B3C28F947FD0D0C8D2B3D62980F45E3EFE60A4408B5E850F84E446B1560`.

This is Phase 08's first-ever full clean E1+E2 pass covering everything implemented to
date. It does not by itself move Phase 08 or any earlier phase's status: E0 and E3
have not run, F-08-06 is still open, and seven of Phase 08's nine task lines remain
unchecked or partial. Full implementing-agent evidence:
[clean gate and F-08-14](evidence/phase-08-clean-gate-and-f08-14-2026-09-01.md).

### F-08-15 — payload CRUD task line has the same gap as F-08-06 — 2026-09-01

Checking Phase 08's task 3 ("exercise real fixed and dynamic-array payload CRUD
through save, close, restart, reload, undo, and redo") found it is currently
untestable through the UI for the same reason F-08-06 is: no UI gesture creates an
Activation Point, the only entity kind that carries a payload.
`NexusCommandCatalog.cpp` has zero occurrences of `Activation` anywhere — a stronger
absence than F-08-05's sixteen deliberately-registered pending-phase commands, since
this one isn't listed even as a future command.

This is not a new fact so much as an unrecorded one: `phases/phase-07.md` already
carries the identical omission against its own near-identical unchecked task 3, with
Phase 07's evidence explicitly noting activation points aren't creatable from the UI
until Phase 14. Phase 08's ledger had not yet said so for its own task list.

What is proven today at the command-service level rather than through the UI: create
/undo/redo/update of a payload with a nested dynamic array
(`Nexus.V7.Foundation.ActivationPointCrudTransactions`), save/reload of fixed and
array payload shapes (`Nexus.V7.Foundation.RealAssetCrudRoundTrip`), and a genuine
cold restart across three separate `UnrealEditor-Cmd.exe` processes
(`Nexus.V7.ColdRestart.01_Prepare`/`02_VerifyAndMutate`/`03_FinalVerify`, via
`Scripts\VerifyPhase01ColdRestart.ps1`) — all of it exercised against
`FNexusActivationPointCommandService` directly, never through a click. What cannot be
verified until Phase 14: the same data, authored by an actual UI gesture, round-tripped
the way a user would experience it.

**Needs the user's reading, same as F-08-05/F-08-06 were**: whether task 3 is
satisfied by this service-level proof plus Phase 07's recorded omission, or stays
open/unchecked until Phase 14. Recorded rather than decided. Full account:
[phase-08.md's F-08-15 section](phases/phase-08.md#f-08-15--payload-crud-task-line-is-untestable-through-the-ui-needs-a-reading--2026-09-01).

### F-08-16 — Revert scoped to the selection, and a wrong test assertion caught re-running it — 2026-09-02

**Blocking, fixed in commit `bd92ac6`.** `FNexusDetailsView::Revert()` reset every
parked `KeptDrafts` entry as a side effect of reverting only the currently selected
target, so reverting one entity's edit silently discarded unrelated unapplied work
elsewhere — and its own preview only ever named the selected entity, so nothing
warned the user. A successful destructive command also left Activity with the bare
status word instead of a real summary, because `Execute()` only ever passed a
`Message` on failure. `Revert()` now leaves `KeptDrafts` alone (`DiscardKeptDrafts()`
is the explicit operation for that), and `Execute()` reuses the already-verified
confirmed preview to record what actually happened, including a new `TargetSummary`.

**Re-running the gate — this project's standard rather than reading the diff — found
the commit's own new regression test asserted the wrong thing, not a second
production bug.** `Nexus.V7.Details.RevertLeavesKeptDrafts` expected
`Fixture.View().IsDirty()` to go `false` right after reverting the selected target,
but an unrelated kept draft was still legitimately dirty and `IsDirty()` is
document-wide by design — already established elsewhere by
`Nexus.V7.Details.LargeSelectionDeferred`. `GetDirtyTargetCount()`, scoped to the
currently-bound targets, is what the test needed. One assertion changed; no
production code did.

First full clean run (`2026-09-02-104526`): three clean builds and every suite but
that one assertion passed. Second, after the fix (`2026-09-02-104935`): `PASS: 156
tests, 0 failures`, `PASS: 21 budget measurements, 0 over`, `PHASE 08 E1+E2: PASS`.
Details' count moves from 26 to 28 — exactly the two tests this commit added.
Evidence: [F-08-16](evidence/phase-08-f08-16-revert-scope-2026-09-02.md).

### Independent review — 2026-09-02

An E0 independent architecture and contract review was performed against the tree
Phase 08 has produced so far. It independently reproduced the current clean E1+E2
pass (156 tests, 21 budgets at the time), confirmed F-08-06 and F-08-15's
characterizations directly against source rather than from the ledger, and accepted
the destructive-confirmation gate, the F-08-16 `Revert()` fix, and the
bounded-Details mechanism without qualification.

It also filed three new findings. **E0-01, Blocking** (closed below as F-08-17):
Undo and Redo silently discarded every unsaved Details edit in the document,
including parked drafts unrelated to the transaction being undone — the same defect
shape F-08-16 had just fixed in `Revert()`, in a path native engine undo reaches
without ever going through `CheckConfirmation`. **E0-02, Warning**: the F-08-16
Activity-summary fix reaches only destructive commands; Apply and every other
ordinary successful command still logs the bare word "Completed." **E0-03,
Warning**: Home's onboarding widget has two badges hardcoded to `Empty` and text
still describing already-shipped Phase 05/06 work as a future phase delivery.

The review did not accept Phase 08 and did not move it to Ready for Manual QA, both
because its own outstanding task list remains and because of E0-01. Evidence:
[E0 independent review](evidence/phase-08-e0-independent-review-2026-09-02.md).

### F-08-17 — Undo/Redo discarded unrelated drafts (E0-01 closed) — 2026-09-02

**Blocking, fixed.** `UNexusEditorSubsystem::RefreshAfterUndo` called
`Repository.NotifyChanged(Hierarchy, {})` — already sufficient on its own, since it
broadcasts synchronously to `FNexusDetailsView::HandleRepositoryChanged`, which parks
and reclaims a dirty currently-selected draft exactly as every other
repository-driven refresh does — and then, redundantly, a separate
`FNexusDetailsView::Get().ReloadFromSource()`, which unconditionally reset
`KeptDrafts` with no reclaim step, discarding every unrelated parked draft and the
one the first call had just reclaimed, on every undo or redo. Fixed by deleting the
redundant second call.

The new regression test failed twice for reasons unrelated to the fix, both found by
re-running rather than trusting the result: a real `SNexusHierarchyTree` widget alive
in the editor process (from workspace/layout restoration, possible even under
`-unattended -NullRHI`) shares the process-global `FNexusHierarchyView::Get()`
singleton and reacted to the test's own repository broadcast by pushing its own,
unrelated selection back onto the subsystem, clobbering the state under test. Fixed
in the test only, by detaching that view for the test's duration and rebinding it
afterward.

E1: three clean builds. E2: `PASS: 157 tests, 0 failures`; `PASS: 21 budget
measurements, 0 over`; `PHASE 08 E1+E2: PASS`. Crud's count moves from 22 to 23,
exactly the one new test. Evidence:
[F-08-17](evidence/phase-08-f08-17-undo-redo-scope-2026-09-02.md).

### F-08-18 — Home's onboarding badges and text made honest (E0-03 closed) — 2026-09-02

**Warning, fixed.** Two of Home's four onboarding badges were hardcoded to `Empty`
regardless of real state, and two of the four step bodies described already-shipped
Phase 05/06 work as a future phase delivery — both dating to Phase 03, before those
phases existed, never revisited once they shipped. Extracted the computation into a
new pure function, `SNexusHomeView::ComputeOnboardingSteps`, the same shape as
`DeriveShellState`. Steps 3 and 4 now reuse the same real `ContentStep` signal
(`EntityCount > 0`) step 2 already computes, rather than an invented new one; steps
2 and 3's text now describes the capability as delivered.

Test coverage for this widget goes from zero to one:
`Nexus.V7.Shell.HomeOnboardingReflectsRealState` asserts all four steps across all
three document states, and that no body claims a future phase once ready.

E1: three clean builds. E2: `PASS: 158 tests, 0 failures`; `PASS: 21 budget
measurements, 0 over`; `PHASE 08 E1+E2: PASS`. Shell's count moves from 20 to 21,
exactly the one new test. Evidence:
[F-08-18](evidence/phase-08-f08-18-home-onboarding-2026-09-02.md).

### F-08-19 — every successful command records what it did, not "Completed" (E0-02 closed) — 2026-09-02

**Warning, fixed.** F-08-16 taught `FNexusCommandService::Execute` to write a real
Activity message and target summary by reusing a destructive command's *confirmed
preview*. A non-destructive command builds no preview, so Apply, Create, Rename,
Reparent, Duplicate, Save, New/Open/Close, Undo and Redo still fell through to
`FNexusOperationHistory::Complete`'s bare status word ("Completed", with "no explicit
target" as the origin) — the everyday case, not a corner one.

Per the user's direction the fix is central and changes no contract: a new
`SummariseSuccessfulCommand` helper, called for exactly the branch that previously
wrote nothing, resolves `Result.ChangedIds` against the live document to
`"DisplayName (Kind)"` (named when three or fewer, a count past that — the F-08-16
threshold); failing that, a `RefreshHint::Document` or a `DocumentId` in the changed
ids gives "the active document"; failing that, a view-only command or valid no-op is
recorded by its own name. The document pointer is `::IsValid`-checked before use
because Close and Reload can leave `Context.Document` pointing at a replaced object.
`FNexusCommandResult` gains no field.

`Nexus.V7.Command.SuccessfulCommandRecordsSummary` (new) asserts the recorded entry
for five result shapes; the F-08-16 destructive-path test is unchanged and green.

E1: three clean builds. E2: `PASS: 159 tests, 0 failures`; `PASS: 21 budget
measurements, 0 over`; `PHASE 08 E1+E2: PASS`. Command's count moves from 17 to 18,
exactly the one new test. Budget artifact
`Saved/NexusV7/Phase08/ui-budgets-2026-09-02-f08-19.txt`, 1,011 bytes, SHA-256
`E6437D1CBA6A2CDB787DBEC194F3D7F1E205640919BFEB5636C17BDF4F62D31D`. Evidence:
[F-08-19](evidence/phase-08-f08-19-activity-summary-2026-09-02.md).

With E0-01 (F-08-17), E0-03 (F-08-18) and E0-02 (F-08-19) closed and E0-04
Information-only, every finding from the 2026-09-02 independent review is acted on.
Phase 08 stays In Progress: E3 has not run. F-08-06 and F-08-15 were answered on
2026-09-02 — see the decisions section below.

### User decisions — F-08-06 and F-08-15 — 2026-09-02

The two Phase 08 task lines that needed an owner's reading rather than code are
answered. Both were asked as plain questions and answered directly; neither changes a
contract, and both resolve the way F-08-05 did on 2026-08-28 — carve the untestable
part out to the phase that already owns it, rather than leave it open or placeholder
it inside this gate.

**F-08-06 — CLOSED. Ownership-mismatch defers to Phase 10.** The `ENexusShellState`
ownership-mismatch presentation has no representation anywhere in the build, and
`phases/phase-10.md` already reserves the condition it describes. Building one inside
this gate would be the placeholder the gate forbids. Task line 5 in
`phases/phase-08.md` is read as satisfied by the eight states a real editor condition
produces and that are asserted against the real `FNexusEditorShellStateProvider`;
ownership-mismatch is explicitly carved out to the Phase 10 reservation, the same way
F-08-05's pending-phase commands were carved out to their delivering phases. That
task line is now checked with the carve-out named in place.

**F-08-15 — CLOSED. The payload-CRUD task line is satisfied by its service-level
proof.** Task 3 asks to exercise real fixed and dynamic-array payload CRUD through
save, close, restart, reload, undo, and redo. No UI gesture creates the
payload-carrying Activation Point and none is owed before Phase 14 — see
`the-bottom-two-rungs-are-not-hand-authored` in agent-memory, and `phases/phase-07.md`
already records the identical limit against its own near-identical task 3. The
behaviour is proven at the command-service level:
`Nexus.V7.Foundation.ActivationPointCrudTransactions` (create/update/delete/undo/redo
on a nested dynamic array), `Nexus.V7.Foundation.RealAssetCrudRoundTrip` (save/reload,
fixed and array shapes), and `Nexus.V7.ColdRestart.01/02/03` (a genuine three-process
cold restart, not a same-process reload). Task 3 is checked with the F-08-15 note; the
UI-authored half is recorded as verifiable only once Phase 14 delivers the gesture.

Phase 08 stays **In Progress**. Of its nine task lines, three are now done (3, 4, 5);
the six that remain — the menu/placeholder audits (1, 2), the DPI/keyboard/contrast
and destructive-preview verifications (6, 7), the user-executed manual QA record (8),
and the contract freeze (9) — are E3-gated or the freeze itself. E3 has not run, and
Phase 08's E3 subsumes the outstanding E3 for Phases 05–07.

## UI Boundary

Phase 09 and every later backend phase remain blocked by dependency until Phase 08 is Complete.
