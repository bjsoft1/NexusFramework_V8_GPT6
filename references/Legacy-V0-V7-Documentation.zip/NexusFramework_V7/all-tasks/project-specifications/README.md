# Nexus Framework V7 — Project Specifications

V7 uses a strict 20-phase, UI-first production roadmap.

## Start Here

- [V7 Master Plan](V7-MASTER-PLAN.md) — product vision, architecture, V0–V6 lessons, and roadmap.
- [V7 Quality Gates](V7-QUALITY-GATES.md) — status authority, evidence, testing, persistence, identity, validation, runtime, and publish rules.
- [V0–V6 Lessons](V0-V6-LESSONS.md) — feature, optimization, failure, and process evidence carried into V7.
- [V7 Product Vision](V7-PRODUCT-VISION.md) — product principles and user-facing acceptance flows.
- [V7 Architecture](V7-ARCHITECTURE.md) — normative data ownership, module, identity, persistence, compiler, and runtime contracts.
- [V7 UX Specification](V7-UX-SPEC.md) — normative Phase 01–08 visible behavior and interaction contract.
- [Phase Status](PHASE-STATUS.md) — the sole authoritative status ledger.
- [Phase Files](phases/) — authoritative objective, task, evidence, and acceptance contracts; status headings mirror the ledger.
- [Evidence](evidence/) — build, automation, restart, cook, performance, and manual-review records.
- [Task List](../TASK-LIST.md) — concise execution order.

## Working Rules

- Exactly Phase 01 through Phase 20; no suffix phases.
- Phase 01 is Ready for Review; all other phases are Not Started.
- AI implementation stops at Ready for Review.
- Complete means all required evidence and manual checks passed.
- UI work must be fully completed and accepted at Phase 08 before Phase 09 may begin.
- Architecture checkpoints inspect working implementation, not planned text.
- V7 never uses a session-only substitute as proof of persistence or export.
- Every stage enforces blocking validation before downstream consumption.
