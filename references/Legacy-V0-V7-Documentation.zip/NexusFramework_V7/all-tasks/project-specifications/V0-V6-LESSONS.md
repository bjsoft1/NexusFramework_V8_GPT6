# Nexus Framework V0-V6 Lessons and V7 Traceability

**Purpose:** Preserve proven ideas, redesign fragile implementations, and explicitly reject patterns that caused drift, crashes, incomplete gates, or runtime risk.

V7 is informed by all prior versions but copies no behavior merely because it already exists. Every inherited capability must enter through V7 ownership, identity, persistence, validation, and module contracts.

## 1. Version-by-version findings

### V0 — Runtime traffic proof

V0 implemented an actor-owned road graph with pathfinding and traffic behavior:
continuous lane following, smooth lane changes, highway transitions, dead-end
reversal, and randomized vehicle distribution. This is implementation evidence, not
an automated-test claim. It remains valuable because Nexus must ultimately serve
runtime gameplay, not only visualize editor data.

The actor-owned graph and old editor mode are not suitable foundations for a large streamed world. Identity, authoring state, and runtime state were too closely coupled, and the authoring UX did not provide the structured data workflow required by later versions.

**V7 decision:** Keep traffic routing and pathfinding as a required outcome. Rebuild them against the immutable compiled lane/junction graph. Do not carry forward the actor-owned source graph or old editor-mode architecture.

### V1 — Transitional checkpoint

V1 was primarily an early checkpoint toward V2 rather than a durable architecture. It demonstrates useful iteration history but does not justify maintaining another parallel model.

**V7 decision:** Keep only verified behavior that appears in a named V7 requirement. Drop duplicate legacy branches and version-derived assumptions.

### V2 — Broad generation capability

V2 contained the deepest early generation pipeline: roads, junctions, sidewalks,
lights, parking, bus stops, decoration, merging, and later Landscape Spline use to
reduce curved-road gaps and cracks. It established the breadth expected of a
city/road framework.

Its `AProceduralCityBuilder` was correctly a thin orchestrator over
single-responsibility builders. Other proven ideas were a single-source GUID graph
without duplicated endpoint data, centralized deterministic junction analysis,
seeded generation, editable preview promotion, HISM usage, validation before final
build, and reload-before-create asset handling. The remaining limits were a
Details-panel-driven workflow, full-regeneration bias, and unstitched
cross-intersection lane links.

**V7 decision:** Keep the modular builder decomposition, deterministic/seeded graph
analysis, generation breadth, instancing, preview, validation, asset-reload, and
seam-quality lessons. Redesign generation as an incremental, source-hashed derived
stage fed by a validated snapshot. Drop full-world regeneration as the normal edit
path and do not leave cross-intersection connectivity incomplete.

### V3 — Stronger authoring UX

V3 introduced dedicated runtime/editor modules, a custom editor mode, Slate tools,
hit proxies, native spline editing, layout persistence, junction/lane tools, and
runtime path export. Its subsystem already owned the working graph, mutation APIs,
and transactions. It also contributed flat GUID pools with lazy indexes, shared
hierarchical highway ownership, geometric-crossing-versus-junction distinction,
cached analysis with AABB prefiltering, fixed deterministic gateways, and
delta-based city movement.

The proven failures were focus capture, native spline-visualizer interception,
gizmo/camera conflicts, and duplicate bake actors. Those lifecycle conflicts—not
direct widget mutation or mode-owned truth—are the reason to avoid making a custom
mode the only way to access V7.

**V7 decision:** Keep the subsystem/transaction foundation, GUID pools and indexes,
analysis optimizations, dockable workflow, native-feeling interaction, selection
synchronization, lane/junction authoring, and layout persistence. Redesign viewport
tools so focus, camera, native visualizers, gizmos, and bake ownership have explicit
lifecycle tests. Independent Nomad tabs remain usable without entering a mode.

### V4 — Hierarchy and export direction

V4 attempted to combine V3 authoring, V2 generation, and V0 traffic ideas. It
introduced continuous highways, hierarchical ownership, and proposed four export
tiers intended to derive from one compile. The compiler remained
`unimplemented()`; only Tier 4 had partial implementation, so the tiers were not a
completed production export system.

The partial Tier 4 runtime identity used an optional editable `FName Code` rather
than a stable GUID. Phase claims also failed to distinguish proposed schema,
implemented behavior, reviewed behavior, and verified behavior.

**V7 decision:** Keep continuous highway semantics, hierarchical ownership, the
single-compile intent, and explicit runtime consumers. Redesign export as one
canonical GUID-based compiled schema with derived views/profiles. Drop editable-name
runtime identity and all stub-as-complete claims.

### V5 — Landscape authority and large-world structure

V5 established the State -> City -> Highway -> Point hierarchy, made Landscape
authoritative for geometry, and added direct authoring, diagnostics, safe loading,
terrain controls, closed loops, sitable-point structures, explicit pull-on-save /
push-on-build direction, and `-1 / 0 / >0` inheritance semantics. It recognized
that large worlds and Landscape integration are central requirements.

Stale/orphaned `TSoftObjectPtr` references, reconciliation, load-dialog behavior,
and tangent/closed-loop/connector round-trip failures created production risk.
Large-world intent also needs multi-Landscape and World Partition support in every
API, not as a late extension.

**V7 decision:** Keep Landscape geometry authority, explicit direction at write/build
boundaries, inheritance semantics, loops, sitable points, the large-world hierarchy,
diagnostics, safe-loading goals, and terrain-aware tools. Redesign synchronization as
explicit Scan -> Diff -> Review -> Apply reconciliation with stable Nexus GUIDs.
Drop stale soft-reference assumptions and single-Landscape behavior.

### V6 — Staged pipeline and extensibility

V6 defined a strong staged direction: Landscape -> Reader -> Mapping ->
Representation -> Generation/Compilation. It also introduced a registry-driven
Activation Point model, scalable debug concepts, undo rules, curved debug lines,
spatial indexing, an O(points + segments) revision fingerprint, graph reuse in
diagnostics, and editor proxy pooling.

Execution exposed planning and quality problems. The work expanded to 108 phases;
tracker status and phase evidence could contradict one another; some Complete phases
retained unchecked manual criteria; many gates reported diagnostics without blocking
the pipeline. Only the first Landscape actor was supported. Persisted
`FInstancedStruct` payloads eventually landed on 2026-08-22, but only very late;
session-only test fixtures still coexist, and compiler/runtime consumption remains
unfinished. Compiler, runtime activation, representative scale testing, final QA,
and publication remained late and unfinished. V6 also used spline-point rename
identity, which V7 deliberately rejects.

**V7 decision:** Keep the staged data pipeline, registry-driven Activation Points,
revision-fingerprint and graph-reuse optimizations, proxy pooling, scalable
visualization, spatial-query direction, undo discipline, and curve-accurate
representation. Redesign as exactly 20 dependency-ordered phases, with payload
persistence proven in the first phase, one tracker, executable gates,
multi-Landscape support, and continuous release evidence. Drop rename-based source
identity, session fixtures as production proof, first-Landscape behavior,
contradictory completion states, and micro-phase proliferation.

## 2. Keep / Redesign / Drop traceability matrix

| Version | Keep in V7 | Redesign in V7 | Drop from V7 |
|---|---|---|---|
| V0 | Working traffic behavior; routing/pathfinding requirement | Compile lanes/junctions into an immutable runtime graph; ID-based runtime handles | Actor-owned authoritative road graph; old editor-mode foundation |
| V1 | Verified ideas that map to explicit V7 requirements | Absorb useful behavior into one architecture and test suite | Parallel checkpoint architecture and version-derived duplication |
| V2 | Modular builders; single-source GUID graph; deterministic junction analysis; seeded generation; HISM; editable preview; validation and asset reload rules; generation breadth | Frozen validated input, source hashes, incremental groups, stitched intersection lanes, seam/collision fixtures | Full regeneration as the normal edit path; Details panel as the whole workflow; incomplete cross-intersection lane links |
| V3 | Subsystem mutations/transactions; flat GUID pools and lazy indexes; cached/AABB analysis; dockable Slate UX; selection, viewport, lane/junction, layout, export intent | Explicit focus/camera/visualizer/gizmo/bake lifecycles; central multi-selection service; safe proxies | Mode-only access; native visualizer interception; duplicate bake actors; fragile gizmo/camera ownership |
| V4 | Continuous highways; hierarchical ownership; one-compile intent; explicit export consumers | One canonical stable-GUID compiled schema with derived profiles/views and deterministic hashes | Editable `FName` runtime identity; unimplemented compiler or schema represented as finished |
| V5 | Landscape geometry authority; hierarchy; pull-on-save/push-on-build direction; inheritance semantics; loops/sitable points; diagnostics | Multi-Landscape/World Partition from day one; explicit reconciliation; stable GUID bindings; supported Landscape transactions and round-trip fixtures | Stale/orphaned soft-reference assumptions; first/single Landscape behavior; unsafe tangent/connector paths |
| V6 | Staged pipeline; Activation registry; revision fingerprint; diagnostic graph reuse; proxy pooling; debug LOD/culling; spatial index; undo; curved visualization | Exactly 20 phases; payload persistence proven first; hard validator/compiler gates; one status source; representative scale tests | Rename-based spline identity; session fixtures as production evidence; advisory gates; unchecked Complete phases; late compiler/runtime/publish proof |

## 3. Cross-version decisions for V7

### UI is completed first

V3 showed the value of dedicated authoring UX, while later versions showed the cost of building data features through incomplete tools. V7 therefore completes the workspace shell, menus, Tree View, Details panel, CRUD, undo/redo, save/restart, accessibility, error states, and UI scale tests before Landscape integration begins.

The UI is backed by the real persistent authoring kernel, not mock data that must later be replaced.

### One source of truth per data class

- Landscape owns geometry.
- The Nexus world definition owns semantic authoring data and bindings.
- Generator output is derived.
- Compiler output is immutable runtime input.
- Runtime state and SaveGame data do not mutate authoring state.

This replaces V0/V2 actor ownership and V5-style bidirectional ambiguity.

### Identity is independent of Unreal object lifetime

Every persistent Nexus object has a stable GUID. External Landscape identity is a resolvable binding with a source locator and structural fingerprint. Rename, reparent, array reorder, streamed unload, and editor restart cannot change Nexus identity. Ambiguous reconciliation blocks apply.

### Persistence precedes domain expansion

The generic versioned `FInstancedStruct` payload path, type registry, save/reload behavior, and migration framework must pass before adding traffic lights, crosswalks, parking, bus stops, seats, advertisements, or service types. This prevents a repeat of V6's late persistence integration and the session-only test-fixture patterns that remained beside its saved payload path.

### Validation controls execution

Diagnostics are not merely a report. A blocker or error prevents the affected reconciliation, generation, compile, or publish operation. UI, automation, and commandlet callers receive the same structured result, and commandlets return failure.

### A compiled schema is the only runtime contract

V4's one-compile/multiple-consumer intent is retained and completed through one
authoritative runtime schema with derived views. Runtime modules never scan
Landscape or authoring assets. They load versioned per-cell compiled data containing
topology, routing, spatial indexes, generated references, and compact Activation
Point records.

### Scale is proven twice

Synthetic tests establish repeatable limits; representative multi-Landscape World Partition maps expose engine integration costs. Neither alone is sufficient. Performance budgets are chosen before implementation of the relevant stage and become hard release evidence.

### Phase truth is auditable

V7 uses exactly 20 phases and one canonical status ledger. Every phase has an
objective gate and named evidence. "Complete" means all required automated, restart,
undo, visual, migration, and performance checks for that phase are green. Later
phases cannot retroactively redefine an earlier gate.

## 4. Mandatory lesson-to-test coverage

| Lesson source | Required V7 regression evidence |
|---|---|
| V0 traffic/pathfinding | Lane/junction route fixtures, unreachable-route behavior, stable path results after cell unload/reload, and runtime traffic soak |
| V2 generation | Curved-road seams, junction joins, caps, collision, sidewalk/marking alignment, deterministic hashes, and affected-group-only rebuild |
| V3 authoring UX | Tree/Details/viewport selection synchronization, cancel paths, transactions, layout restart, hit testing, and large-hierarchy responsiveness |
| V4 hierarchy/export | State/City/Highway/Point ownership integrity, continuous-highway fixtures, compiled-schema compatibility, and canonical export hash |
| V5 Landscape/large-world | Multiple Landscapes, duplicate names, streamed cells, source deletion, map rename, split/merge reconciliation, and clean restart |
| V6 staged pipeline/registry | Stage dependency tests, persisted typed payload round-trip/migration, unknown-type preservation, hard gate failure, spatial query scale, and registry extension without core modification |

## 5. Explicit non-goals and safeguards

- V7 will not copy an old version wholesale.
- V7 will not promise automatic V0-V6 project migration before the V7 schema is stable. Any importer is read-only against the source, version-specific, previewable, and tested.
- V7 will not edit Landscape geometry as a side effect of scanning, selecting, reconciling, generating, or compiling.
- V7 will not treat a debug visualization, schema declaration, stub, or synthetic-only benchmark as proof that a production feature is complete.
- V7 will not publish with transient payload state, editor references in runtime data, unresolved identity conflicts, stale source hashes, or advisory-only validation failures.

## 6. Audit evidence anchors

The 2026-08-22 independent re-audit used working source and status artifacts, not
version names or roadmap claims alone. Representative anchors are:

- **V0:** NexusRoadPathfindingUtility.cpp, ANexusRoadAIActor.cpp, and
  ANexusRoadGraph.cpp under
  ../../../NexusFramework_V0/Source/NexusFramework/NF/.
- **V2:** .claude/skills/nexus-city-builder/SKILL.md,
  Private/City/ProceduralCityBuilder.cpp, and
  Private/City/CityJunctionAnalysis.cpp under
  ../../../NexusFramework_V2/.
- **V3:** NexusHighwayBuilderSubsystem.cpp,
  NexusHighwayJunctionAnalysis.cpp, and NexusHighwayDataCompiler.cpp under
  ../../../NexusFramework_V3/Source/.
- **V4:** NexusDataCompiler.cpp and NexusGeneratedCityDataAsset.h under
  ../../../NexusFramework_V4/Source/.
- **V5:** NexusFrameworkEditorSubsystem.cpp,
  ai-change-audits/2026-08-09/others/save-pull-only-no-landscape-mutation.md,
  and agent-todos/requirement-pending/closed-loop-diagonal-landscape-spline-crash.md
  under ../../../NexusFramework_V5/.
- **V6:** project-specifications/PHASE-STATUS.md,
  project-specifications/phases/phase-12.md,
  NexusActivationPoint.h, NexusActivationPointTestStore.h,
  NexusLandscapeReader.h, and NexusEditorProxyPool.h under
  ../../../NexusFramework_V6/.

These are navigation anchors, not a substitute for lesson-specific regression
tests. A V7 feature inherits a legacy claim only after the tests in Section 4 pass.

## 7. Acceptance statement

A legacy idea is considered successfully carried into V7 only when it:

1. follows V7 data ownership and stable identity;
2. persists and migrates where applicable;
3. is accessible through the command/transaction boundary;
4. passes hard validation before derived work;
5. compiles deterministically into the runtime schema when needed;
6. has lesson-specific automated and representative-map evidence;
7. leaves editor-only types and live pointers outside Shipping runtime code.

This traceability is the guardrail against repeating the same feature under a new folder while retaining the same architectural failure.
