# Closed-Loop + Diagonal Landscape Spline Crash (Q.IsNormalized / TArray resize)

## Description

Unresolved editor crash. Repro: new layout, add a City, Generate Random City
(closed square), add a diagonal connecting two existing points inside the
square, Save, Load — editor crashes. Two variants seen: `Assertion failed:
Q.IsNormalized()` in `LandscapeEditor` (`QuatRotationTranslationMatrix.h:81`),
and `Trying to resize TArray to an invalid size of 2147483648` in
`FBatchedElements::AddReserveLines`/`FLandscapeToolSplines::Render`. Deep
engine-source research already done
(`ai-change-audits/2026-08-09/research/quat-isnormalized-crash-deep-research.md`)
found a strong, source-verified lead that this is a stock UE 5.8 engine gap (an
unguarded `FQuat(Axis, Angle)` constructor fed a zero-length Hermite-curve
derivative via `GetSafeNormal()`), not confirmed as a Nexus data-correctness
bug — but not 100% proven either. **Do not modify rotation/tangent Save/Load
logic blindly** — read that research file's ranked hypothesis list and TODOs
first.

## Verification

1. Repro exactly: new layout, add City, Generate Random City (closed square),
   add diagonal between two existing points, Save, Load.
2. Confirm whether the crash still reproduces at all before changing anything.
3. If reproducible, follow the research file's TODO 1 (symbolize the existing
   crash minidump with real engine PDBs — Epic Games Launcher, GUI-only,
   multi-GB download) before attempting any code fix.
4. Any fix must not regress the already-fixed rotation/tangent Save/Load
   round-trip (`tangent-lost-on-save-load-roundtrip.md`,
   `sync-inspector-false-positive-tangent-mismatch.md`).
5. Build editor with 0 errors.

## Origin

Reported by the user with a very detailed investigation request (explicitly:
"do not assume this is an Unreal Engine bug," use installed UE 5.8 PDBs, trace
backward into Save/Load reconstruction, document root cause before fixing).
Investigated at length across this project's history — root cause narrowed but
not proven, no fix applied. Also requires a real design decision once/if
confirmed (Nexus-side avoidance vs. accepting it as an engine bug vs. an
engine-version workaround — see the research file's TODO 7), which is why this
belongs in `requirement-pending` rather than `ready-for-development` as-is.
Moved here on 2026-08-09 after the user asked for a sweep of assigned-but-not-
yet-done tasks.
