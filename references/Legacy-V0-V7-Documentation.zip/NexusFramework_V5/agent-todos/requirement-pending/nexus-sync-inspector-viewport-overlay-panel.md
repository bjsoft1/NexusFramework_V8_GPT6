# Nexus Sync Inspector Viewport Overlay Panel

## Description

Add a small, always-visible viewport overlay panel — separate from the existing
dockable `SNexusSyncInspectorPanel` diagnostic tab (extend/complement it, do not
duplicate its diff logic). Panel position is user-configurable (editor setting:
LeftTop / RightTop / BottomLeft / BottomRight / Center). Shows the current
"Active: State > City > Highway > Point" breadcrumb. Auto-refresh if a
background-safe mechanism exists (new thread or tick-based change detection);
otherwise refresh on every Save call, plus a manual reload button in the panel as
a fallback. Also show an "armed" hint when Generate City origin-click mode is
active (`IsGenerateCityOriginArmed`/`SetGenerateCityOriginArmed`) — e.g. "Click
landscape to generate city" — reuse this same panel rather than a second UI
element for that hint.

## Verification

1. Panel appears in the configured viewport corner/center, offset applied correctly.
2. Selecting a different State/City/Highway/Point updates the breadcrumb live.
3. Editing/saving the layout updates the panel without requiring the dockable
   Sync Inspector tab to have focus.
4. Arming Generate City (select a City, enable click-to-place) shows the hint
   text; clicking the landscape or disarming clears it.
5. Manual reload button (if implemented as the no-thread fallback) forces a refresh.
6. Build editor with 0 errors.

## Origin

Requested by the user earlier in this project's history, across two messages,
while other work (crash triage, save/load duplication bugs, architecture
redesign) was in progress — never implemented. Moved here on 2026-08-09 after
the user asked for a sweep of assigned-but-not-yet-done tasks. Not yet re-verified
against current code as still wanted/still accurate — needs user review before
`ready-for-development`.
