# Agent TODO Rules

## Purpose

This folder is the persistent TODO/workflow system for AI agents working on this project.

The user may start a completely new AI chat/agent every day.
Therefore, **this file is the source of truth for TODO workflow rules.**

The agent MUST read this file before processing `/TODO`.

---

# Workflow

```text
requirement-pending
        ↓
ready-for-development
        ↓
active
        ↓
ready-for-review
        ↓
ready-for-qa
        ↓
closed/YYYY-MM/
```

---

# Folder Rules

## 1. `requirement-pending/`

Tasks that are not ready for implementation.

Examples:

* Requirements unclear
* Design still being discussed
* Research required
* User approval required
* Dependencies not decided

Agents must NOT implement these tasks unless the user explicitly instructs them to do so.

---

## 2. `ready-for-development/`

Tasks that are fully defined and approved for implementation.

This is the **only folder an agent may automatically select a development task from**.

When the user says:

```text
/TODO
```

the agent must:

1. Read `ready-for-development/`.
2. Select exactly ONE task.
3. Move that task to `active/`.
4. Begin implementation.
5. Do not select another task until this task is completed or blocked.

The agent must NEVER automatically start a task without `/TODO`.

---

## 3. `active/`

Tasks currently being worked on by an AI agent.

When an agent selects a task, it MUST immediately move the task file:

```text
ready-for-development/
        ↓
active/
```

The task file in `active/` represents the task currently owned by the agent.

The agent must not silently work on unrelated tasks.

If blocked, leave the task in `active/` and document the blocker.

---

## 4. `ready-for-review/`

The AI implementation is complete and the user must review it.

After completing the task:

```text
active/
    ↓
ready-for-review/
```

The agent MUST NOT move it directly to `ready-for-qa/`.

The user controls the review stage.

Every completed task MUST contain:

```text
## Completed

Fixed: <short task title>

Completed: YYYY-MM-DD HH:MM <TIMEZONE>

Implemented and build verified.
Ready for user review.

## Verification

- <verification step>
- <verification step>
- <verification step>
- <verification step>
```

Completion time MUST be the actual time the agent finished the task.

---

## 5. `ready-for-qa/`

The user has reviewed the implementation and considers it ready for QA/testing.

**Only the user moves tasks into this folder.**

The AI agent must not move a task here unless the user explicitly instructs it.

QA should verify the feature/bug fix against real editor/game workflows.

If QA fails, the user may move the task back to `active/` or create a new task.

---

## 6. `closed/YYYY-MM/`

Completed and QA-approved historical tasks.

Example:

```text
closed/
├── 2026-08/
│   ├── fix-landscape-save-load.md
│   ├── fix-tree-clear-all.md
│   └── corner-sharp-detection.md
└── 2026-09/
```

**Only the user moves tasks into `closed/`.**

The AI must never close its own task.

When moving a task to `closed/`, preserve its complete history, including:

* Original description
* Implementation notes
* Completion timestamp
* Verification
* QA result
* Any final notes

---

# `/TODO` Command

`/TODO` is the explicit command that tells the AI:

> Find and start the next development task.

When `/TODO` is received:

```text
1. Read AGENT-TODO-RULES.md.
2. Inspect ready-for-development/.
3. Choose ONE task.
4. Move it immediately to active/.
5. Read the complete task.
6. Inspect relevant code/history.
7. Implement only that task.
8. Build and test.
9. Document the result.
10. Move the task to ready-for-review/.
11. Stop.
```

Do NOT automatically pick another task.

---

# Task Selection

When multiple tasks exist in `ready-for-development/`:

Prefer:

1. Explicit priority specified in the task.
2. Blocking/foundation tasks.
3. Older tasks.
4. Otherwise, the first clearly ready task.

Never choose from:

```text
requirement-pending/
active/
ready-for-review/
ready-for-qa/
closed/
```

Only `ready-for-development/` is the development queue.

---

# Task File Format

Every task should be a standalone Markdown file.

Example:

```markdown
# Fix Landscape Save/Load Rotation

## Description

Fix the Landscape rotation mismatch after Save → Load.
Landscape geometry must remain identical after reload.
Preserve all State, City, Highway and Point configuration.
Do not break the existing junction rotation fix.

## Verification

1. Create a T-junction.
2. Save the layout.
3. Load the layout.
4. Compare the curve and rotation.
5. Verify mesh assignment.
6. Test a closed segment.
7. Build editor with 0 errors.
```

Keep:

* Description: **5–10 lines maximum**
* Verification: **5–10 lines maximum**

---

# Completion Requirements

Before moving a task to `ready-for-review/`, the agent MUST:

* Implement the requested change.
* Build the affected module.
* Fix compile/link errors caused by the change.
* Perform practical verification where possible.
* Check that recently fixed related bugs still work.
* Document important implementation details.
* Add the actual completion date/time.

Completion format:

```markdown
## Completed

Fixed: <short task title>

Completed: 2026-08-09 17:30 NPT

Implemented and build verified.
Ready for user review.

## Verification

- <test 1>
- <test 2>
- <test 3>
- <test 4>
- <test 5>
```

---

# Important Safety Rules

### Never do this

```text
ready-for-development
        ↓
closed
```

### Never do this

```text
active
        ↓
ready-for-qa
```

### Never do this

Start a task automatically when the chat opens.

### Never do this

Pick multiple TODO tasks from the queue during one `/TODO` command.

### Never do this

Delete completed task files.

### Never do this

Assume a reported bug's proposed cause is correct.

### Never do this

Break an existing recently-fixed bug while implementing a new feature without investigating the regression.

---

# User-Controlled Stages

The AI controls:

```text
ready-for-development → active → ready-for-review
```

The user controls:

```text
ready-for-review → ready-for-qa → closed/YYYY-MM/
```

This separation is intentional.

The AI implements.

The user reviews.

The user sends the task to QA.

The user closes the task.

---

# New Chat / New Agent Rule

Every new AI chat starts with no assumption about previous agent state.

Before doing development work, the agent MUST inspect:

```text
agent-todos/AGENT-TODO-RULES.md
agent-todos/active/
agent-todos/ready-for-development/
```

However, the agent MUST NOT resume or start an `active/` task automatically.

If the user says `/TODO`, select a task only from:

```text
agent-todos/ready-for-development/
```

If an old task is still in `active/`, report that it exists if relevant, but do not automatically take ownership of it unless the user explicitly asks.

---

# `/TODO` Completion Response

After finishing the selected task, provide a concise report:

```text
TODO completed.

Task: <task name>
Status: Ready for Review
Completed: YYYY-MM-DD HH:MM <TIMEZONE>

Build: PASS
Verification: PASS

Task moved:
active/ → ready-for-review/
```

Then stop and wait for the user.

---

# Core Principle

**The filesystem is the persistent memory of the development workflow.**

Do not rely on previous chat history to know what tasks exist.

The task files are the source of truth.

The user controls review, QA, and closure.
