# Layout Load: Ownership Mismatch Flow + Landscape-Authoritative Refresh on Match

## Description

Follow-up to `layout_load_time_if_existing_segment_already_has_then_not_asking_queston`
(the "dialog not appearing" part of that task is already fixed — this covers the rest
of its original scope, now with concrete, user-approved design decisions).

**Part A — ownership mismatch detection + Copy/Override/Cancel** (approved design):
add `FName SavedMapPackage` to `UNexusLayoutAsset`, set it in `WriteWorldDataToAsset`
to the current map's package name. In `LoadLayout()`, if the picked Asset's
`SavedMapPackage` is set and differs from the current map's package name, show a new
Copy / Override / Cancel choice (separate from the existing LoadFresh/ImportAndMerge/
ShowMeFirst/Cancel dialog, which still applies once ownership is settled). Copy = load
the data, then immediately call the existing `SaveLayoutAs()` so it's saved as a new
asset tied to the current map (never silently overwrites the mismatched original).
Override = proceed exactly like today's Load Fresh, then run a `ComputeSyncDiff()`-style
check afterward and notify the user (pointing at the Sync Inspector tab) if any Mismatch
entries remain. Cancel = abort, no changes.

**Part B — same-map "landscape is authoritative" refresh** (needs careful
implementation, touches the most crash-sensitive code in this project — read
`ai-change-audits/2026-08-09/research/quat-isnormalized-crash-deep-research.md` and
the `nexus-editor-onboarding` skill first): when ownership matches, `LoadFresh` should
stop unconditionally calling `WipeLandscapeSplineGeometry` before materializing.
Investigation this pass confirmed `MaterializeMissingPointGeometry` already leaves an
already-resolving `SourcePoint` completely untouched (only creates fresh geometry when
nothing resolves) — so skipping the wipe on a same-map load mostly gets "landscape
stays authoritative" for free. The one real gap: the classification pass at the end of
`MaterializeMissingPointGeometry` (`RecomputePointClassification(..., bRestoreSavedRotation=true)`)
currently runs over every `TouchedPointIds` entry whenever `bAnyMaterialized` is true —
including already-resolved points that didn't need materializing — which would
overwrite their live (correct, current) rotation with the stale saved snapshot. Needs a
second set (e.g. `NewlyMaterializedPointIds`) so only points actually created this pass
get `bRestoreSavedRotation=true`; an already-resolving point whose connectivity
genuinely changed (a new neighbor got materialized next to it) still needs
reclassification, but WITHOUT the stale-rotation restore — decide the exact mechanism
during implementation, this is an engineering call, not a design one.

## Verification

1. Part A: Load a Layout whose `SavedMapPackage` differs from the current map → Copy/
   Override/Cancel dialog appears (not the LoadFresh/ImportAndMerge one directly).
2. Copy: saves a new asset via the folder dialog; original asset and current map/state
   untouched.
3. Override: behaves like today's Load Fresh; if Sync Inspector would report a
   Mismatch afterward, a notification appears pointing at it.
4. Part B: on a same-map Load, natively edit a point's rotation, Save is skipped
   (don't re-save), Load the same Layout again → the live/native rotation is preserved,
   NOT reverted to the older saved snapshot.
5. Part B regression check: a Load that both preserves already-resolving points AND
   materializes genuinely new ones (e.g. ImportAndMerge bringing in extra points) still
   classifies/meshes the new ones correctly, and reclassifies only the points whose
   connectivity actually changed.
6. Re-run the existing Save/Load round-trip verifications from
   `tangent-lost-on-save-load-roundtrip.md` and `sync-inspector-false-positive-tangent-mismatch.md`
   — this must not regress either.
7. Build editor with 0 errors.

## Origin

Split out of `layout_load_time_if_existing_segment_already_has_then_not_asking_queston.txt`
on 2026-08-09 after investigation found the original task's "existing safety flow"
premise didn't match the current codebase (no ownership field, no Copy/Override dialog
exist yet) and that the same-map refresh behavior touches the classification pass
implicated in the still-open `Q.IsNormalized()` crash investigation — too large and too
risky to bundle into the smaller, already-fixed "dialog not appearing" bug. User was
asked directly (AskUserQuestion) and approved: store map package name for ownership,
Override = Load Fresh + post-load Sync Inspector mismatch warning.

## Scope clarification — 2026-08-09 (implementation pass)

Before implementing, the user was consulted again directly in the same session (this
task's own description flags several points as needing an engineering/design call made
at implementation time, not before). Two things changed from this doc's original
wording as a result — **read this before assuming Part A/B below were implemented
exactly as originally described**:

- **Part B's literal mechanism ("LoadFresh should skip the wipe when ownership
  matches") was NOT implemented.** The user explicitly confirmed this session that
  Load Fresh's wipe-and-replace behavior is correct and intended as-is ("both button is
  same: task is landscape remove all segment info and we put layout segment info" —
  answering a direct question about whether "discard landscape data" and "Load Fresh"
  should be different buttons). Load Fresh is unchanged.
- **The underlying goal ("landscape geometry stays authoritative, don't stomp
  already-correct data") was instead redirected onto "Import and Merge"**, which the
  user separately specified needs real duplicate-point detection: an incoming Layout's
  point that's already physically present on the Landscape (tracked by the current
  session under a different GUID) must be recognized, have its identity fields
  (Code/Name/Id/parent) left untouched, and have ONLY its geometry snapshot refreshed
  from the live Landscape — never reclassified/remeshed. This is a superset of what
  Part B originally asked for the classification pass to do, just wired to a different
  entry point (Import and Merge, not Load Fresh).
- The `NewlyMaterializedPointIds` classification-pass fix Part B identified as "the one
  real gap" WAS implemented essentially as originally specified — it just now also
  serves the new duplicate-aware merge path, not a modified Load Fresh path.

Full implementation detail: `ai-change-audits/2026-08-09/feature-add/load-layout-ownership-and-duplicate-aware-merge.md`.

## Follow-up — 2026-08-09 (Load Fresh: map onto existing Landscape geometry instead of wiping)

After the below was already build-verified, the user asked directly whether Load Fresh
"tries to map with landscape existing segment if possible, otherwise just show warning and
unsaved dirty" — it didn't (it still unconditionally wiped everything, reversing what had
just been confirmed for "Load Fresh" a few messages earlier). Flagged the contradiction and
confirmed with the user before implementing: leftover/unmapped Landscape geometry should be
left in place, warned about, and marked dirty — not deleted. Implemented: `PerformLoadFreshFromAsset`
no longer wipes; `MaterializeMissingPointGeometry()` naturally reuses whatever of the loaded
asset's Points already resolve on the current Landscape; new `WarnAndMarkDirtyIfSyncDiffHasIssues()`
surfaces any `Mismatch`/`UntrackedInNexus` `ComputeSyncDiff()` entries afterward (Sync Inspector
notice + dirty flag) instead of silently ignoring them. Applies to LoadFresh and the ownership
dialog's Copy/Override alike (all three share `PerformLoadFreshFromAsset`). Full detail appended
to `ai-change-audits/2026-08-09/feature-add/load-layout-ownership-and-duplicate-aware-merge.md`'s
own Follow-up section. Build verified again after this change (0 errors).

## Completed

Fixed: Load Layout cross-map ownership dialog + duplicate-aware Import and Merge + Load Fresh
now maps onto existing Landscape geometry instead of always wiping

Completed: 2026-08-09 19:06 NPT (original); Load Fresh mapping follow-up same session, after

Implemented and build verified (full offline `Build.bat NexusFrameworkEditor Win64
Development`, 0 errors — editor was closed this session).
Ready for user review. NOT yet tested in the running editor.

## Verification

- Build: `Build.bat` succeeded, 0 errors (both the original implementation and the Load Fresh
  mapping follow-up).
- Manual in-editor verification (same-map/no-geometry, same-map/existing-geometry,
  cross-map Copy/Override/Cancel, `SavedMapPackage==NAME_None` backward compatibility,
  the core duplicate+genuinely-new-point Import-and-Merge scenario, Load Fresh reusing already-
  resolving geometry instead of recreating it, the leftover-geometry warn+dirty behavior, and
  the two existing Save/Load round-trip regression checks) is NOT yet done — see the full
  matrix in `ai-change-audits/2026-08-09/feature-add/load-layout-ownership-and-duplicate-aware-merge.md`'s
  own Verification section.
- Known, deliberately out-of-scope gaps (documented, not fixed): highway-level
  duplication when an incoming Highway's points are all collapsed duplicates; duplicate
  detection only catches points resolving against a currently-*tracked* WorldData point,
  not an orphaned/untracked native one.
