---
description: Pick up the next task from agent-todos/ready-for-development and implement it end-to-end, per agent-todos/AGENT-TODO-RULES.md
argument-hint: [optional: task filename or keyword to pick a specific task instead of auto-selecting]
---

Follow `agent-todos/AGENT-TODO-RULES.md` exactly. Steps:

1. Read `agent-todos/AGENT-TODO-RULES.md` in full (it is the source of truth for this
   workflow, not this command file — if the two ever disagree, the rules file wins).
2. Report anything currently sitting in `agent-todos/active/` (another task may already
   be mid-flight) — do not silently take it over.
3. List `agent-todos/ready-for-development/` (search recursively — the user may nest
   tasks under subfolders like `bugs/regression-bugs/`).
   - If the user supplied arguments (`$ARGUMENTS`), use them to pick the matching task.
   - Otherwise select exactly ONE task using the rules file's priority order (explicit
     priority in the task > blocking/foundation tasks > older tasks > first ready task).
   - If the folder is empty, report that clearly and stop — do not invent a task.
4. Move the selected task file to `agent-todos/active/` (`git mv` if tracked, preserving
   any subfolder structure it came from is not required — flatten into `active/`).
5. Read the complete task file. Before writing any code, re-verify the premise against
   the current codebase (per this project's standing rule: never assume a reported bug's
   cause — or its continued existence — is correct without checking).
6. Inspect relevant code/history — check `ai-change-audits/README.md`'s index and
   "Current open threads" section, and the `nexus-editor-onboarding` skill, for anything
   already known about this area before making changes.
7. Implement only this task. Do not silently expand scope — if the task reveals separate
   work, leave a note rather than doing it inline.
8. Build the affected module and fix any compile/link errors introduced by the change.
9. Perform whatever practical verification is possible from the task's own Verification
   section. Explicitly check that recently-fixed related bugs still work if this task
   touches the same area.
10. Append the required completion note to the task file:
    ```
    ## Completed

    Fixed: <short task title>

    Completed: <YYYY-MM-DD HH:MM> <TIMEZONE>

    Implemented and build verified.
    Ready for user review.

    ## Verification

    - <test 1>
    - <test 2>
    - <test 3>
    ```
11. Move the task file to `agent-todos/ready-for-review/`. Do NOT move it to
    `ready-for-qa/` or `closed/` — only the user does that.
12. If this task represents a durable finding (root cause, architecture decision) worth
    remembering long-term, also add a proper record under `ai-change-audits/` per
    `CLAUDE.md` — the TODO file only tracks workflow state, not durable project memory.
13. Report back in this exact shape, then stop and wait for the user:
    ```
    TODO completed.

    Task: <task name>
    Status: Ready for Review
    Completed: <YYYY-MM-DD HH:MM> <TIMEZONE>

    Build: PASS
    Verification: PASS

    Task moved:
    active/ -> ready-for-review/
    ```

Never pick more than one task per `/TODO` invocation. Never move a task directly from
`ready-for-development/` to `ready-for-qa/` or `closed/`. Never delete a task file.
