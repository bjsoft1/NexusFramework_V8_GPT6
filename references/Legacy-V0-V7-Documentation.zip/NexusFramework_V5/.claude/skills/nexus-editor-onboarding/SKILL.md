---
name: nexus-editor-onboarding
description: Load first in any fresh chat/agent working on NexusFramework_V5's NexusFrameworkEditor module (editor-side road/highway authoring on top of Unreal Landscape Splines, UE 5.8). Explains the State>City>Highway>Point data model, the Nexus-owns-config/Landscape-owns-geometry split, the pull-only-Save vs Build-Landscape-push sync architecture, known-unsafe engine APIs, and where this project's persistent memory (ai-change-audits/) and task queue (agent-todos/) live. The user switches chats/agents daily and expects every fresh agent to self-orient from these files rather than from prior chat history.
---

# NexusFrameworkEditor V5 — orientation

This project has **two persistent, file-based systems in the repo root** that survive
across chats/agents — always check them, they are the actual source of truth, not
anything in this skill's prose (which can drift out of date; the files below cannot,
because agents are required to keep them current):

1. **`ai-change-audits/`** — append-only history: bug root causes, feature designs,
   research findings, architecture decisions. Read `ai-change-audits/README.md` first —
   its "Current open threads" section at the top is the fastest way to learn what's
   unresolved or awaiting verification right now. Full rules: `../../CLAUDE.md`.
2. **`agent-todos/`** — the live task queue (`requirement-pending → ready-for-development
   → active → ready-for-review → ready-for-qa → closed/YYYY-MM/`). Read
   `agent-todos/AGENT-TODO-RULES.md` before processing a `/TODO` command. Check
   `agent-todos/active/` for work another agent left mid-flight.

Everything below is architecture that changes slowly — useful for understanding *why*
the code is shaped the way it is, so you don't have to rediscover it by trial and error.

## The one rule that matters most

**Nexus owns configuration. The Landscape owns geometry.** `FNexusRoadPoint` (Nexus's
own point struct) never stores its own Location/Rotation/Tangent as the authoritative
value — it references a real `ULandscapeSplineControlPoint` via
`SourcePoint` (`TSoftObjectPtr`), and *that* object's transform is truth while it
resolves. `Location`/`Rotation`/`OutgoingTangentLen`/`IncomingTangentLen` on
`FNexusRoadPoint` are a **snapshot/cache**, refreshed by `SyncPointGeometrySnapshots()`,
used to rebuild geometry when the live control point doesn't exist yet (fresh Load) or
no longer resolves (see cross-map guard below). Never treat the cached fields as
authoritative if `SourcePoint` currently resolves.

## Data model (`Public/Schema/Editor/`)

`FNexusWorldData` (`NexusWorldData.h`) is the single source of truth for the authored
world graph: `TMap<FGuid, FNexusState/FNexusCity/FNexusHighway/FNexusRoadPoint>` plus a
top-level `SitableStructures` map (owned by `OwnerId`, not nested — a structure can be
owned by a Point or a Highway). **All graph mutation goes through `FNexusWorldData`'s own
methods** (`AddState`/`AddCity`/`AddHighway`/`AddPointToHighway`/`RemovePoint`/etc.) —
never hand-edit the maps from UI or tool code.

- **Ownership chain**: `FNexusState → FNexusCity → FNexusHighway → FNexusRoadPoint`. A
  City has no stored location — it's always computed live from its highways' points
  (`GetCityCenter`). A Highway may be `InterCityHighway`-style (bridges `StartCityId`/
  `EndCityId` in two different cities, which may belong to two different states) — that's
  the *only* form a cross-state highway takes, there's no separate ownership field.
- **`FNexusHighway`**: `OrderedPointIds` (the real path, in order), `bIsClosedLoop` (last
  point's "next" wraps to the first), `bLockEdit`, `MeshAssetSetOverride`
  (`TSoftObjectPtr<UNexusHighwayMeshAssetSet>`), terrain fields
  (`AutoAdjustLandscape`/`bRaiseTerrain`/`bLowerTerrain`/`TerrainLayerName`).
- **`FNexusRoadPoint`**: `PointId` (real key, GUID), `Code` (optional unique label)/`Name`
  (display), `SourcePoint`, geometry snapshot fields (see above), `ConnectedHighwayIds`
  (derived, never hand-edit), `NodeType` (derived classification), decoration bitmasks
  (`PointFeatures`/`PointTargets`/`Description`).
- **IDs vs. Codes**: `FGuid` (`*Id`) is always the real structural key. `FName` (`Code`)
  is an optional, per-type-unique (not globally unique), user-editable alias —
  `NAME_None` is always valid and never collides with another `NAME_None`. Never use Code
  as a lookup key in engine-facing code, only `FGuid`.
- **`-1` convention**: any width/gap/length/limit/tangent/`AutoAdjustLandscape`-style
  field defaults to `-1` = inherit from the parent level (Point → Highway → City → State
  → global `UNexusGenerationSettings` default), `0` = explicitly off/disabled, `>0` =
  explicit override. Most-specific-wins resolution — see `ResolveAutoAdjustLandscape` for
  the canonical pattern to copy for any new inheritable field.

## Sync architecture: `UNexusFrameworkEditorSubsystem` (`NexusFrameworkEditorSubsystem.cpp`)

This is the one big file everything routes through — `UEditorSubsystem` +
`FTickableEditorObject` (it must tick every frame regardless of which dock tab has
focus, for debug-overlay drawing — see `DrawDebugOverlays`/the
`debug-overlay-freezes-on-tab-switch` audit record for why this matters).

**As of 2026-08-09, Save and Build Landscape are two deliberately asymmetric
directions** (see `ai-change-audits/2026-08-09/others/save-pull-only-no-landscape-mutation.md`
for the full design rationale):

- **Save (and the manual "Sync From Landscape" button — same function,
  `SyncFromLandscape`) is 100% pull-only**: WorldData ← Landscape. It may add/remove
  `FNexusRoadPoint`/highway bookkeeping and refresh geometry snapshots, but it must
  **never** call `RecomputePointClassification`/`ApplyMeshSetToControlPoint`/
  `ApplyPointFurniture` — i.e. never push a computed mesh/rotation back onto the live
  Landscape. Whatever mesh/rotation is currently on the Landscape (however it got there)
  is authoritative and is read as-is.
- **"Build Landscape" (the button; C++ identifiers are still named
  `ApplyHighwayConfiguration`/`ApplyAllConfiguration`/`OnApplyConfigurationClicked` —
  only the user-facing label was renamed) is the only place Nexus pushes its own config
  onto the Landscape** — mesh, scale, half-width, junction rotation/tangent recompute,
  furniture. It calls `SyncPointGeometrySnapshots()` immediately afterward so WorldData
  never sits stale relative to what it just pushed.
- **`MaterializeMissingPointGeometry`** (Load-time only, the opposite direction —
  WorldData → Landscape) still classifies/meshes every point it (re)creates from
  scratch. This is correct and *not* part of the "Save shouldn't push" rule — Load is
  reconstructing geometry that doesn't exist yet, not reconciling against something live.
- **Live incremental edits** (`OnLandscapeSplineObjectTransacted` → `TryAdoptNewLandscapePoint`
  / `TryRegisterNewLandscapeSegment` / `TryAdoptFirstLandscapePoint` / `MergeHighwaysForNewSegment`)
  still classify/mesh immediately — real-time visual feedback while drawing, not a
  Save-time side effect, also out of scope for the pull-only rule.

`SyncFromLandscape`'s reconciliation historically runs in four "Directions" (grep the
function for `Direction 1`/`2`/`2.5`/`3`/`4` comments): 1) drop WorldData points whose
control point is gone, 2) import untracked native points as new highways (2.5: splice
into an existing highway at the right index/orientation instead, when the new point sits
between two already-tracked points), 3) register "Imported Connector" 2-point highways
for untracked adjacencies between already-tracked points, 4) prune dead 2-point connector
highways whose native segment was deleted.

## Known-unsafe / gotcha APIs — don't relearn these the hard way

- **`ULandscapeSplineSelection::SetSplineSelected`** — private-to-`LandscapeEditor`,
  proven to crash (`LandscapeSplineSelection.cpp:105` assertion, documented incident).
  The one safe read is `ControlPoint->IsSplineSelected()` (query-only). Never call the
  setter from Nexus, even defensively.
- **A `ULandscapeSplineControlPoint` subclass cannot cross the module boundary** —
  `MinimalAPI` blocks it (16 unresolved externals when tried; confirmed unfixable, not a
  build-config issue). Point identity/recovery instead renames the plain control point to
  `"NexusPoint_<guid>"` for a stable `FSoftObjectPath` (see `LinkPointToControlPoint`).
- **Engine's `DeleteSplinePoints()` doesn't destroy objects** — it renames them into the
  transient package. A `TSoftObjectPtr::LoadSynchronous()`'s cached weak pointer can
  resolve to a **stale, orphaned-but-still-alive object from a different, still-resident
  map** — guarded via `IsControlPointOnTargetLandscape`, confirmed working in real
  captured logs (`ai-change-audits/bug-fixed/cross-map-sourcepoint-bug.md`).
- **`AutoCalcRotation` (engine) is never called by Nexus.** Junction rotation uses
  Nexus's own closed-form `ComputeDeterministicJunctionForward` (ported from V4's
  `UNexusJunctionAnalysis`), not the engine's iterative solver — see
  `random-city-junction-rotation-misaligned.md` for why the two disagree.
  `AutoCalcRotation` itself does not rebuild geometry — the caller must separately call
  `UpdateSplinePoints()`/`RebuildAllSplines()`.
- **Tangent sign matters.** `TangentLen` can be legitimately negative (a sign-flip
  convention, `AutoFlipTangents`) — always `FMath::Abs()` before comparing against a
  plain auto-distance value, or you'll get false-positive "mismatch" detection (see
  `sync-inspector-false-positive-tangent-mismatch.md`).
- **UNRESOLVED, still open**: a real `Q.IsNormalized()` crash in `LandscapeEditor` on
  junction rotation edits, with strong source-verified evidence it's a stock UE 5.8
  engine gap (unguarded `FQuat(Axis, Angle)` constructor fed a zero vector from
  `GetSafeNormal()` at a Hermite-curve velocity cusp) — not (so far) a Nexus
  data-correctness bug. Read `ai-change-audits/2026-08-09/research/quat-isnormalized-crash-deep-research.md`
  in full before touching rotation/tangent code near junctions.
- **Viewport highlighting via `SetSplineSelected` is permanently disabled** (the crash
  above) — segment highlighting is done instead via per-tick `DrawDebugLine` over real
  tessellation (`hierarchical-segment-highlighting-restored.md`).

## Where crash artifacts live

`Saved/Crashes/UECC-Windows-<hash>_NNNN/` — one folder per crash, survives editor
restart: `NexusFramework.log` (full session log up to the crash, including this
project's own `[NEXUS ROTATION WRITE]`/`[NEXUS ROTATION CHECK]` diagnostics),
`CrashContext.runtime-xml` (assert text + module-level call stack),
`UEMinidump.dmp` (openable in Visual Studio/WinDbg — **this engine install ships no
native PDBs by default**; getting a real symbolized stack requires Epic Games Launcher →
UE 5.8 → gear icon → Options → "Editor symbols for debugging", a GUI-only, multi-GB
download). The live session's log is also always at `Saved/Logs/NexusFramework.log`.

## Build commands (Windows, this machine)

```powershell
& "C:\Program Files\Epic Games\UE_5.8\Engine\Build\BatchFiles\Build.bat" NexusFrameworkEditor Win64 Development -Project="E:\Projects\Game\UE\NexusFramework_V5\NexusFramework.uproject" -WaitMutex
```

Works directly when the editor is closed. If it fails with "Unable to build while Live
Coding is active," the editor is open — ask the user to compile via Live Coding
(Ctrl+Alt+F11) inside the running editor instead of closing it. **Per project convention,
stop at the code change and let the user build/test** unless they've asked you to build —
see `ai-change-audits/others/user-builds-and-verifies.md`.

## Common tasks

- **Add a new inheritable config field** (Point/Highway/City/State chain, -1 = inherit):
  mirror `AutoAdjustLandscape`'s pattern — field on each level with `ClampMin=-1`, a
  `Resolve*` helper on the subsystem walking most-specific-to-least-specific, terminal
  fallback on `UNexusGenerationSettings`.
- **Add a new panel section/asset picker**: see `SNexusFrameworkPanel.cpp`'s
  `BuildAssetPicker` pattern (mirrors `DefaultMeshAssetSet`/`GenerationSettings`) — pairs
  a `GetSelected*Path`/`OnSelected*Changed` on the widget with a subsystem-level
  `TSoftObjectPtr` UPROPERTY, mirrored to/from `UNexusLayoutAsset` in
  `WriteWorldDataToAsset`/`LoadLayout`'s `LoadFresh` branch.
- **Investigate a Save/Load round-trip bug**: check `MaterializeMissingPointGeometry`
  first (Load-time reconstruction) and `SyncFromLandscape` second (Save-time pull) — most
  past bugs in this area were one of these two not handling a topology shape (mid-chain
  insert, closed loop wraparound, shared junction) that the other already did.
- **Write up a finished investigation/change**: follow `../../CLAUDE.md`'s record shape,
  file under `ai-change-audits/<YYYY-MM-DD>/<category>/`, and add a one-line pointer to
  `ai-change-audits/README.md`'s index (and its "Current open threads" section if it's
  still unresolved/unverified).
