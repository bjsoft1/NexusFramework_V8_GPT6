# Project AI Memory — Single Source of Truth

Project AI memory lives **exclusively** in:

```
ai-change-audits/
```

It is the primary and authoritative source of truth for this project's AI-assisted work
history. See `ai-change-audits/README.md` for the category index.

This rule applies automatically to every agent working in this repository — Claude Code,
new sessions, sub-agents, future agents — including ones with no memory of this
instruction ever being given. Check `ai-change-audits/` before doing work that may depend
on previous project history.

## Rules

1. **One location.** Never store project-specific AI memory in `.claude/`,
   `<PROJECT_ROOT>/.claude/`, `C:/Users/<user>/.claude/`, or any other global/external
   Claude memory, cache, log, or temp location. `.claude/` may hold tooling configuration,
   never project history.
2. **Append-only.** Never delete, overwrite, or silently edit an existing audit record.
   When new information, a correction, or a verification result comes in, append a new
   dated section to the relevant file (or add a new file) — never rewrite what's already
   there. A correction to a past finding is itself a new appended section
   (`## Correction — YYYY-MM-DD`), not an edit to the original text.
3. **Structure**: a date folder for the day the entry was written, then category, then the
   record file(s) — `ai-change-audits/<YYYY-MM-DD>/<category>/<record-name>.md`:
   ```
   ai-change-audits/
   └── 2026-08-09/
       ├── bug-fixed/    — investigations, root causes, crash/regression fixes, verification
       │   └── some-bug-fixed-record.md
       ├── feature-add/  — new features, systems, tools, editor functionality, architecture
       │   └── some-feature-record.md
       ├── research/     — UE source research, API/architecture investigation, experiments
       └── others/       — architecture decisions, project conventions, general history
   ```
   New records go in today's `YYYY-MM-DD` folder, under the right category subfolder inside
   it (create either if they don't exist yet). A follow-up/correction/verification for an
   existing record still appends to that record's own file in its **original** date folder
   (per the append-only rule below) — it does NOT get a new entry under today's date.
   Records created before this dated-folder convention existed (flat files directly under a
   category, with no date folder at all — e.g. `ai-change-audits/bug-fixed/some-record.md`)
   are untouched history, per the append-only rule — do not move or reorganize them into
   date folders retroactively. (History note: from project start through 2026-08-09 the
   order was category-then-date, `<category>/<YYYY-MM-DD>/<record>.md`; on 2026-08-09 the
   user had all then-existing dated records reordered to date-then-category to match this
   rule — that was a one-time, explicitly-requested migration, not a precedent for reordering
   again. The undated legacy flat files were left in place either way.)
4. **No duplicate memory systems.** Don't create `project-memory/`, `ai-memory/`,
   `agent-memory/`, `ai-logs/`, or similar — `ai-change-audits/` only.
5. **Preferred record shape** (existing files may instead be one long append-only log with
   dated `##` sections — both are fine, don't force a rewrite to fit this shape):
   ```
   # Title
   Date:
   Category:

   ## Context
   ## Problem / Goal
   ## Findings
   ## Changes
   ## Verification
   ## Result
   ## Important Notes
   ```

Migrated history from this project's prior (global, out-of-repo) Claude memory lives here
as of 2026-08-09 — see `ai-change-audits/README.md`'s migration note for provenance. Do
not migrate anything back out of the repo; do not maintain a second copy anywhere else
going forward.

## Related: task workflow queue (`agent-todos/`)

`agent-todos/` is a **separate, complementary system** for day-to-day task state (what's
queued, what's actively being worked, what's awaiting review/QA) — not memory, not
covered by the append-only rule above. Full rules live in `agent-todos/AGENT-TODO-RULES.md`
— **read that file before processing a `/TODO` command**. Short version: tasks flow
`requirement-pending → ready-for-development → active → ready-for-review → ready-for-qa →
closed/YYYY-MM/`; an agent may only auto-pick work from `ready-for-development/`, only on
an explicit `/TODO`, and only the user moves a task into `ready-for-qa/` or `closed/`.

`ai-change-audits/` (history of what was found/decided/changed, append-only, read for
context) and `agent-todos/` (state of what's queued/in-flight right now, files are moved
between folders as work progresses) answer different questions — check both when picking
up work cold. When a `ready-for-review/`or `closed/` task's work is significant enough to
be worth remembering long-term (a root cause, an architecture decision), it still belongs
recorded in `ai-change-audits/` too — the TODO file tracks workflow state, not durable
findings.
