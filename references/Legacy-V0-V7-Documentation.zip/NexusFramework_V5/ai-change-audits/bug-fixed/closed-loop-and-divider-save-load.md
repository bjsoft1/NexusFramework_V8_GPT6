# Closed-loop and divider/connector topology lost on Save -> Load

Date: 2026-08-09
Category: bug-fixed

## Context

User-reported data-loss bug: authored highway topology (closed/circular highways, divider
segments connecting two points that are already mid-chain on other highways) does not
survive a Save Layout -> Load Layout round trip. Explicit requirement: 100% lossless
round-trip, not "visually similar." Investigation ordered before any fix: reproduce/trace
the pipeline, research V4's load implementation for comparison, identify root cause,
implement the smallest architecture-consistent fix, verify.

## Problem / Goal

Given an authored highway network containing a closed loop, and a divider/connector segment
whose endpoints are both already-tracked points on other highways, Save Layout followed by
Load Layout must reproduce the identical topology - same points, same GUIDs, same highway
membership/ordering, same closed-loop state, same connector, no duplicates on repeated
sync/save/load.

## Findings

**V4 comparison** (full detail in `../research/v4-road-topology-research.md`): V4 has NO
closed-loop support (the one `Spline->IsClosedLoop()` branch in its code is provably dead -
nothing ever calls `SetClosedLoop(true)`) and no divider/junction data structure beyond
plain GUID cross-referencing. V4's `Load()` is a one-line struct copy with no reconciliation
step, because V4's own graph is the sole topology authority - its always-live spline visuals
are generated FROM the graph and every edit round-trips back into the SAME graph, same
frame. **Conclusion: V4's load correctness is architectural (single source of truth), not
algorithmic - there is no reconstruction technique to port.** V5's actual failure mode (a
second, independently live-editable native tool - Unreal's Landscape Spline system - that
can diverge from what's been synced into `WorldData`) does not exist in V4 at all.

Tracing V5's own pipeline (`FNexusHighway`/`SyncFromLandscape`/
`MaterializeMissingPointGeometry`/`SaveLayout` in `NexusFrameworkEditorSubsystem.cpp`)
found three distinct, concrete root causes - not a serialization bug; `WorldData` itself
never contained the missing topology by the time it got written to disk:

1. **No closed-loop representation.** `FNexusHighway::OrderedPointIds` is a plain linear
   array with no "connects back to start" flag. `MaterializeMissingPointGeometry` only ever
   connected consecutive pairs - never `Last()` back to `[0]` - even when `WorldData`
   correctly listed every point in the loop (confirmed: the import path,
   `BuildChainsFromUntrackedPoints`'s own loop-detection second pass, already correctly
   *detects* a closed loop when importing from native Landscape geometry - it just never
   *recorded* that fact anywhere for later use).
2. **Save never re-synced from the live Landscape first.** The live incremental sync
   (`OnLandscapeSplineObjectTransacted` -> `TryRegisterNewLandscapeSegment`) *deliberately*
   declines to auto-register a new native segment when either endpoint isn't a clean
   free-end (exactly the divider/connector case - both endpoints mid-chain) - correct
   behavior for a live, no-user-confirmation auto-sync. But nothing then prompted a full
   reconciliation before persisting - `SaveLayout()`/`SaveLayoutAs()` wrote `WorldData`
   straight to the asset with no `SyncFromLandscape()` call first. This exact question was
   left unresolved in this project's own earlier history (Phase 3 notes: "does Save Layout
   implicitly run Sync From Landscape first? ... needs an explicit decision") and had
   defaulted to "no."
3. **Even manual "Sync From Landscape" couldn't have caught it.** Its import logic
   (`BuildChainsFromUntrackedPoints`) only scans control points not yet tracked AT ALL. A
   divider whose both endpoints are already-tracked points is invisible to that scan -
   neither endpoint ever appears in `UntrackedPoints`.

## Changes

All in `NexusFrameworkEditorSubsystem.cpp`/`.h` and `Schema/Editor/NexusHighway.h`:

1. **`FNexusHighway::bIsClosedLoop`** (new `bool` field) - persisted like any other field
   through the existing asset serialization (no format change needed). Set in
   `BuildChainsFromUntrackedPoints`'s loop-detection pass (that function's return type
   changed from a bare `TArray<TArray<ULandscapeSplineControlPoint*>>` to
   `TArray<FNexusUntrackedChain>`, a `{Points, bIsClosedLoop}` pair, so the fact discovered
   there survives to the caller). Consumed in `MaterializeMissingPointGeometry`: after the
   normal pairwise walk, if `bIsClosedLoop` and the highway has 3+ distinct points, connects
   the last point back to the first.
2. **`AreControlPointsConnected` idempotency helper** (new, anonymous namespace) - found and
   fixed a genuinely pre-existing gap while adding this: `MaterializeMissingPointGeometry`'s
   own pairwise-connect call had NO "already connected" check at all, meaning re-running it
   over an already-fully-materialized highway (e.g. Load Layout's "Import and Merge" path,
   which does not wipe existing geometry first) would create a duplicate parallel segment
   between the same two points every time. Now guards both that existing call and the new
   closed-loop-closing connection. See `../others/landscape-topology-engine-notes.md`.
3. **`SyncFromLandscape` Direction 3** (new pass, after the existing removal/import
   directions) - for every already-tracked point, walks its native `ConnectedSegments`; for
   any segment whose far end is ALSO an already-tracked point with no existing adjacency
   between them anywhere in `WorldData` (`IsAdjacencyRepresentedInWorldData`, a new helper
   checking consecutive-in-`OrderedPointIds` OR a `bIsClosedLoop` highway's own wraparound),
   registers a new standalone 2-point `FNexusHighway` referencing both EXISTING points by
   GUID (never `AddPointToHighway` - that creates a NEW point, which would be wrong here).
   Mirrors V4's own `ConnectPoints` "not a cleanly-extendable endpoint -> branch, create a
   new highway" fallback - the one structurally transferable idea from the V4 comparison.
   Idempotent by construction: once registered, the connector highway itself makes its two
   points adjacent, so `IsAdjacencyRepresentedInWorldData` finds it on any later re-sync and
   skips re-registering. Gated by `IsControlPointOnTargetLandscape` (the cross-map guard from
   this session's earlier fix) when building the `ControlPoint -> PointId` map this pass
   walks - see `../others/landscape-topology-engine-notes.md` for why this needed narrower
   gating than the existing `TrackedControlPoints` set.
4. **`SaveLayout()`/`SaveLayoutAs()` now call `SyncFromLandscape()` first**, silently.
   Confirmed `SyncFromLandscape` was ALREADY dialog-free by construction - the result dialog
   for the manual "Sync From Landscape" button lives in `SNexusFrameworkPanel.cpp`'s own
   click handler, never inside the subsystem function itself - so no new "non-dialog variant"
   needed to be built; the existing function was already save-safe. Placed at the very top of
   `SaveLayout()` (runs once regardless of whether it then falls through to `SaveLayoutAs()`)
   and independently at the top of `SaveLayoutAs()` (a real entry point in its own right).
   `HandlePostSaveWorld` (the auto-save-after-map-save trigger) needed zero changes - it
   already just calls `SaveLayout()`.

## Idempotency / duplication check

Traced explicitly, per the task's own regression concern:

- Closed-loop closing connection: guarded by `AreControlPointsConnected` - a second
  `MaterializeMissingPointGeometry` pass over an already-closed loop will not add a second
  wraparound segment.
- Connector/divider registration: guarded by `IsAdjacencyRepresentedInWorldData` - a second
  `SyncFromLandscape` pass will not create a second "Imported Connector" highway for the
  same native segment, because the first one it created already makes the two points
  adjacent within itself.
- The existing consecutive-pair connect call in `MaterializeMissingPointGeometry` (not new,
  but touched by this fix) is now also guarded, closing the pre-existing duplicate-segment
  gap described above.

## Verification

Brace-balance and non-ASCII checks clean on all modified files
(`NexusFrameworkEditorSubsystem.cpp`/`.h`, `NexusHighway.h`). Symbol cross-reference checked
(every new identifier's declaration/definition/call-sites match).

**NOT VERIFIED**: no build or editor run performed (no build/launch access - user builds and
verifies, per established project workflow). None of the following have been confirmed:
- Project builds successfully.
- Closed-loop Save -> Load reproduces the loop.
- Divider/connector Save -> Load reproduces the connector.
- Shared-point/junction topology survives (expected to already work - traced as not being
  part of the actual bug, each highway's own `OrderedPointIds` independently lists a shared
  point, reconstructed correctly per-highway already - but not independently re-verified
  after this change).
- Repeated Sync From Landscape does not duplicate topology (reasoned through above, not
  build-tested).
- Repeated Save/Load does not duplicate topology.
- Existing Landscape functionality (Draw Point, Apply Configuration, native edit sync, the
  viewport-highlight-disabled state) still works unregressed.
- The already-documented engine-crash protections (viewport highlight disable, cross-map
  guard, nested-transaction avoidance) remain intact in practice, not just in code review.

## Result

Code-complete, NOT VERIFIED. Awaiting a build + the acceptance test matrix from the
original task (closed loop, curved/circular, divider/connector, multiple connected
segments, mixed layout - before/after structural comparison, plus the repeated
sync/save/load regression check).

## Important Notes

If a future session finds `MaterializeMissingPointGeometry` or `SyncFromLandscape` still
creating duplicates, check `AreControlPointsConnected`/`IsAdjacencyRepresentedInWorldData`
are actually being hit on the code path in question first - the mechanism is now in place,
but this was never build-tested end to end.
