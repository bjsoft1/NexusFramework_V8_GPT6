# Junction Mesh OffsetRotation Not Applied To Landscape Control Point

Date: 2026-08-09
Category: bug-fixed

## Context

User-reported bug: when a T/Cross/Corner junction mesh is configured in
`UNexusHighwayMeshAssetSet` (`TJunctionMesh`/`CrossJunctionMesh`/
`CornerHighwayMesh`, all `FNexusHighwayRoadMeshConfig` -> `FNexusMeshConfig`)
with a non-zero `OffsetRotation`, clicking the **Apply Configuration** button
does not rotate the mesh on the Landscape - the offset is silently ignored.
User pointed at `NexusFramework_V4` as a project that hit and fixed the same
bug.

## Problem / Goal

Find why `OffsetRotation` has no visible effect on junction control-point
meshes and fix it, referencing V4's prior fix for the same issue.

## Findings

- `RecomputePointClassification` (`NexusFrameworkEditorSubsystem.cpp`) is
  what assigns a junction's mesh: `ControlPoint->Mesh = PointMeshSlot->
  StaticMesh...` / `ControlPoint->MeshScale = PointMeshSlot->Scale`. It never
  read `PointMeshSlot->OffsetRotation` at all - confirmed via grep, the field
  is only ever consumed by `ApplyPointFurniture`'s `SpawnFurnitureMeshComponent`
  path (separately-spawned `UStaticMeshComponent`s for furniture, not the
  Landscape-native control-point mesh).
- Root cause is architectural, not a missed line: `ULandscapeSplineControlPoint`
  (engine class, `LandscapeSplineControlPoint.h`) has **no mesh-only rotation
  field**. Confirmed by reading the engine source
  (`UE_5.8\Engine\Source\Runtime\Landscape\Private\LandscapeSplines.cpp`,
  `ULandscapeSplineControlPoint::UpdateSplinePoints`, line ~2354):
  `MeshComponent->SetRelativeTransform(FTransform(MeshRotation, MeshLocation, MeshScale))`
  where `MeshRotation = Rotation` (the SAME field used for tangent/socket math
  elsewhere in that same file, e.g. `GetBestConnectionTo`/
  `GetConnectionLocationAndRotation` build `FTransform(Socket->RelativeRotation,
  Socket->RelativeLocation) * FTransform(Rotation, Location, MeshScale)`).
  There is no separate additive offset the engine applies for you - `Rotation`
  IS the mesh's facing.
- V4 already hit and fixed this exact bug: commit `376dd91` "Apply mesh scale
  and offset rotation to control point"
  (`NexusFrameworkSubsystem.cpp::BuildSplineSegments`), diff:
  ```cpp
  ControlPoint->MeshScale = PointSlot->Scale;
  // ULandscapeSplineControlPoint has no mesh-only rotation field - Rotation
  // IS the spline's tangent direction, reused for mesh facing too. ...
  // use a small corrective OffsetRotation to match a mesh's authored facing,
  // not an arbitrary large rotation, since it also nudges the tangent of
  // every segment through this point.
  ControlPoint->Rotation = Point->Rotation + PointSlot->OffsetRotation;
  ```
  V4's own comment says this pattern itself was carried forward from V3's
  `UNexusHighwayBuilderSubsystem::ApplyControlPoint` - i.e. this is the third
  generation of the same deliberate fix, not a one-off.

## Changes

`RecomputePointClassification` (`NexusFrameworkEditorSubsystem.cpp`), right
after assigning `ControlPoint->Mesh`/`MeshScale`: when a point mesh is
actually assigned (`bWantsPointMesh`), add
`PointMeshSlot->OffsetRotation` onto `ControlPoint->Rotation` (component-wise
`FRotator` addition, matching V4's exact approach) - `ControlPoint->Rotation`
at that point already holds the freshly `AutoCalcRotation()`-computed tangent
rotation for this call, so the offset is added on top of the real per-point
topology rotation, not a stale/default value.

Scoped to `bWantsPointMesh` only (Straight/SmoothCorner points have no point
mesh - `ResolvePointMeshSlot` returns null for them - so their `Rotation`
stays exactly the AutoCalcRotation tangent value, unaffected).

## Verification

Not yet build-verified - see [[user-builds-and-verifies]].

## Result

Code fix applied, mirroring V4's already-shipped fix for the identical
engine-level constraint (no mesh-only rotation field on
`ULandscapeSplineControlPoint`).

## Important Notes

- This intentionally reuses `ControlPoint->Rotation` for both the mesh's
  facing AND the tangent/socket geometry used by connected segments - per
  V4's own comment (carried forward here), `OffsetRotation` should stay a
  *small corrective* value to match a mesh's authored facing, not an
  arbitrary large rotation, since a large offset will visibly bend the
  segments plugging into this point along with the mesh.
- MainHighwayMesh's `OffsetRotation` (the Straight/SmoothCorner segment mesh,
  applied via `ApplyMeshSetToSegment`/`FLandscapeSplineMeshEntry`) was NOT
  investigated as part of this fix - out of scope, user's report was
  specifically about T/Cross/Corner junction meshes on control points.

## Follow-up — 2026-08-09 — compounding bug found in the fix above

User reported that after applying the fix above, editing `TJunctionMesh`'s
`OffsetRotation` in the data asset and clicking **Apply Configuration** again
still didn't visibly rotate the mesh, and asked for Apply Configuration to
just unconditionally recompute/reapply everything ("recalculate everything,
if need destroy old and insert new fine").

**Root cause of the follow-up**: read `ULandscapeSplineControlPoint::
AutoCalcRotation` in full (`LandscapeSplines.cpp`, ~line 2094). It has TWO
completely different code paths:
- Exactly 2 connections (`bAlwaysRotateForward=true`, Straight/Corner/
  SmoothCorner's case): fully OVERWRITES `Rotation` from scratch every call -
  `Rotation = LocalQuat.Rotator().GetNormalized();` - genuinely idempotent,
  no dependency on the incoming value at all.
- 1 or 3+ connections (DeadEnd/TJunction/CrossJunction/MultiJunction - the
  exact node types that actually get a point mesh, per `ResolvePointMeshSlot`):
  an ITERATIVE step, not a closed-form answer -
  `Delta = average(DesiredRotation_i - Rotation)` then
  `Rotation = (Rotation + Delta).GetNormalized()`. Confirmed this is exactly
  how the native Landscape Spline editor tool uses it too (`grep
  AutoCalcRotation` in `LandscapeEdModeSplineTools.cpp` - always a single call
  per user action, e.g. the "Auto-rotate Landscape Spline Control Points"
  command) - a single call is the engine's own normal usage, not a shortcut
  Nexus was taking.

  The bug: our own fix above ADDS `PointMeshSlot->OffsetRotation` onto
  `ControlPoint->Rotation` AFTER `AutoCalcRotation`, and that combined value
  is what persists as `ControlPoint->Rotation` going into the NEXT Apply
  Configuration call. Since the 3+/1-connection branch's very first line of
  math is `DesiredRotation - Rotation` (the CURRENT, already-offset value),
  every repeat Apply Configuration fed the previous call's OffsetRotation-
  polluted result back in as this call's starting point - so a NEW
  OffsetRotation value edited into the data asset was being averaged against
  stale contamination from the OLD OffsetRotation instead of a clean
  topology-only baseline, which could look like "nothing changed" or drift
  unpredictably rather than cleanly reflecting the new value.

**Fix**: reset `ControlPoint->Rotation = FRotator::ZeroRotator` immediately
before calling `AutoCalcRotation` in `RecomputePointClassification`, for
every point (`ConnectionCount > 0`) - confirmed harmless for the 2-connection
branch (already fully overwrites regardless of incoming value), and removes
the cross-Apply contamination for the 1/3+-connection branch, so every Apply
Configuration now starts from the same clean baseline and its result depends
only on CURRENT topology + CURRENT `OffsetRotation`, never on a prior Apply's
output.

**On "destroy old and insert new"**: not implemented literally - traced
`UpdateSplinePoints` (engine, called via `RebuildAllSplines()`, which
`ApplyHighwayConfiguration` already always calls unconditionally, unlike the
Sync-triggered rebuild gated in
[[save-forces-landscape-spline-rebuild]]) and confirmed it already does a
real transform update whenever `Rotation`/`Location`/`MeshScale` differ from
the currently-rendered `MeshComponent`'s transform (a tolerance-based
`Equals()` check, not an identity/pointer check) - a pure rotation change was
never silently skipped by staleness there. A literal destroy+recreate of the
`UControlPointMeshComponent` wasn't needed once the actual data-value bug
(the contamination above) is fixed, and would have thrown away the engine's
own cheap update-in-place path for no benefit.

**Not yet build-verified.** Also flagged to the user as worth double-checking:
this fix only affects the SECOND-and-later Apply Configuration click after an
OffsetRotation edit; if literally the FIRST click after editing OffsetRotation
already showed no visible change, that would point at a stale editor binary
(C++ changes need a rebuild - see [[user-builds-and-verifies]]) rather than
this compounding bug specifically.
