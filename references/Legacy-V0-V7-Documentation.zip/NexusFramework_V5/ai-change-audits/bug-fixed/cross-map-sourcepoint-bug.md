---
name: v5-cross-map-sourcepoint-bug
description: "Diagnosed (not fixed) 2026-08-08 - pre-existing bug, predates the segment-create-sync session: FNexusRoadPoint::SourcePoint can resolve to a stale control point from a DIFFERENT map still resident in memory, since UNexusFrameworkEditorSubsystem never validates the resolved control point belongs to the current ResolveTargetLandscape(). Causes cross-map segment references, a LandscapeSplines.cpp:574 engine ensure, illegal-reference save errors, and level-switch memory leaks."
metadata:
  node_type: memory
  type: project
  originSessionId: 981d13f6-153a-4882-9852-bbbc0e384a44
  modified: 2026-08-08T18:50:53.210Z
---

User reported three crash/error logs from real usage (create new level+landscape, load a
saved Nexus Layout; separately, save-as a debug copy of a map, create a new landscape
there, load layout, switch Landscape Mode tabs; separately, switch levels without saving)
and asked for root-cause research only, explicitly noting it's an old/pre-existing bug,
not caused by the same session's new-segment-create-sync work
(see [[project_v5_landscape_nexus_two_way_sync]]'s own session-update section for that
change, and its own "verified safe against Nexus's own segment creation" note - this bug
is a different, independent issue).

## The three symptoms (all one root cause)

1. Engine ensure: `Connection.ControlPoint->GetOuterULandscapeSplinesComponent() == this`
   (LandscapeSplines.cpp:574) - fired both on a fresh `/Temp/Untitled_1` map right after
   Load Layout, and later on a saved `LV0_Development_Debug` map after
   save/create-landscape/load/tab-switching.
2. `Fatal error: ... World Memory Leaks: 2 leaks objects and packages` (EditorServer.cpp:1951)
   when switching levels without saving.
3. Save failure: `Illegal reference to private object: 'LandscapeSplineControlPoint
   .../LV0_Development:...Landscape_1.LandscapeSplinesComponent_0.NexusPoint_<guid>'
   referenced by 'LandscapeSplineSegment_11' (at '.../LV0_Development_Debug...') ... private
   object belongs to an external map` - a segment in one map's package illegally
   referencing a control point that lives in a DIFFERENT map's package.

## Root cause

`UNexusFrameworkEditorSubsystem` is a global `UEditorSubsystem` - it persists for the
whole editor session and is NOT reset/reinitialized when the user loads a different
level/map. `FNexusRoadPoint::SourcePoint` is a `TSoftObjectPtr<ULandscapeSplineControlPoint>`,
resolved via `.LoadSynchronous()`/`.Get()` at 6 call sites in
`NexusFrameworkEditorSubsystem.cpp` (`MaterializeMissingPointGeometry`,
`ApplyHighwayConfiguration`, `TryGetPointWorldLocation`, `TryGetPointWorldRotation`,
`OnLandscapeSplineObjectTransacted`'s reverse-lookup, `SyncPointGeometrySnapshots`) - NONE
of them check that the resolved control point's owning `ULandscapeSplinesComponent`
actually matches `ResolveTargetLandscape()`'s own splines component for the CURRENT
world. `ResolveTargetLandscape()` itself IS correctly scoped
(`GEditor->GetEditorWorldContext().World()`, confirmed correct) - the bug is purely the
missing cross-check on the resolved `SourcePoint`, not landscape resolution itself.

`TSoftObjectPtr::LoadSynchronous()` resolves by full package path, independent of which
map is currently open in the level editor - if the ORIGINAL map's package is still
resident in memory in the same session (e.g. right after "Save As" duplicating a map, or
simply never explicitly closed), it returns a live, valid object that belongs to a
DIFFERENT map's splines component. Nothing currently detects this.

Chain of effects:
1. Load Layout -> `MaterializeMissingPointGeometry` sees `SourcePoint.LoadSynchronous()`
   succeed -> treats the point as already-materialized (skips creating a fresh control
   point on the CURRENT landscape) -> calls
   `ConnectControlPointsWithSegment(CurrentMapSplinesComponent, StaleControlPoint, ...)` ->
   wires a segment in the current map's splines component whose `Connections[].ControlPoint`
   points into the OTHER map's package. That's symptom 3 exactly.
2. Engine's own internal consistency check fires the ensure (symptom 1) whenever it walks
   that segment.
3. The subsystem's cached resolved reference into the old map's package (kept alive as
   long as the long-lived subsystem/WorldData holds it) prevents that package from being
   cleanly garbage-collected on level switch - matches symptom 2 (memory leak fatal error).

Also independently found: `ApplyHighwayConfiguration` derives WHICH `SplinesComponent` to
call `RebuildAllSplines()` on from the FIRST resolved point's own `GetOuter()`, not from
`ResolveTargetLandscape()` - if that first point resolves stale, the whole function
operates on the wrong map's splines component. Same root cause, separate manifestation.

## Update (same session) - user asked for the fix, implemented as a full Layout reset on level change

User's own framing after the diagnosis: "if level/map change then reset our the layout" -
went with the simpler of the two suggested shapes (reset-on-map-change) rather than the
per-call-site `IsControlPointOnTargetLandscape` guard, since WorldData is inherently tied
to one Landscape's real geometry and can't meaningfully carry over to a different level
anyway - no point re-validating call-by-call when the whole Layout is invalid the moment
the level changes.

**Implementation** (`NexusFrameworkEditorSubsystem.h`/`.cpp`): new
`HandleMapOpened(const FString& Filename, bool bAsTemplate)`, bound to
`FEditorDelegates::OnMapOpened` in `Initialize()` (new `MapOpenedHandle` field), removed
in `Deinitialize()`. Confirmed via engine source (`FileHelpers.cpp`) that this ONE
delegate covers both Open Level AND New Level - `UEditorLoadingAndSavingUtils::
NewMapFromTemplate` (New Level's actual implementation, since UE5's New Level dialog
picks a template) routes through the same `FEditorFileUtils::LoadMap` that broadcasts
`OnMapOpened` at the very end, after the new level is fully loaded (matches the user's
own `/Temp/Untitled_1` repro exactly - that's the "untitled package" LoadMap creates for
a template-as-new-level).

Handler body: `ResetToDefaultLayout()` (same baseline `NewLayout()`/first-run
`Initialize()` use) + `CurrentLayoutAsset.Reset()` + `bIsDirty = false` +
`OnLayoutChanged.Broadcast()`/`OnActiveSelectionChanged.Broadcast()` (so the Hierarchy
tree/Details panel/Sync Inspector all refresh to the empty default immediately, not on
next interaction). Deliberately NOT wrapped in `Modify()`/a transaction - same reasoning
as `Initialize()`'s own unwrapped `ResetToDefaultLayout()` call: there's no meaningful
undo for a level switch, and the old WorldData described a different level's geometry.

Net effect: any saved Layout containing `SourcePoint` references now gets wiped back to
the fresh default the instant the level changes, before anything else (Tick-driven
orphan-check, Load Layout, Apply Configuration, ...) gets a chance to resolve a stale
cross-map reference. User must explicitly Load Layout again in the new level (expected -
same as if starting fresh). Not yet build-verified.

## TODO (user-confirmed still reproducing, 2026-08-08, later session) - residual gap the map-change reset does NOT cover

Live repro log after the `HandleMapOpened` fix above: user on `LV0_Development_Debug`,
clicked Load Layout (discarded an "unsaved changes?" prompt), four points' tangent-synced
(`OutgoingTangentLen changed X -> -1.0` - `MaterializeMissingPointGeometry`/related sync
running), then the SAME `Connection.ControlPoint->GetOuterULandscapeSplinesComponent() ==
this` ensure fired again on `LV0_Development_Debug`.

Root cause: `HandleMapOpened`'s reset only clears WorldData that was ALREADY stale from
BEFORE the switch. It does nothing to stop the user from RE-introducing a stale reference
by explicitly Load-Layout-ing a `UNexusLayoutAsset` whose OWN saved `World` (a full
`FNexusWorldData` snapshot, including every `SourcePoint`) was captured while a DIFFERENT
map was active - loading that asset copies those stale paths right back into WorldData,
and `MaterializeMissingPointGeometry` still has zero check that a resolved control point
belongs to the CURRENT `ResolveTargetLandscape()`. This is exactly the deeper fix already
suggested (and not yet implemented) earlier in this file - a shared
`IsControlPointOnTargetLandscape`-style guard at the `LoadSynchronous()`/`.Get()` call
sites - the map-change reset alone was never meant to close this half of the bug, only
the "stale state lingering after a switch with no explicit Load" half.

User said to log this as a TODO and continue with other work (the Save-architecture
refactor) rather than fix it immediately - revisit next.

## TODO:2 (user-reported 2026-08-08, later session) - same bug, new symptom detail worth keeping

Fresh repro, same shape: switch into a new level, Load Layout (a saved asset whose
`SourcePoint`s were baked against a different map's package - see the TODO above), same
`Connection.ControlPoint->GetOuterULandscapeSplinesComponent() == this` ensure
(LandscapeSplines.cpp:574) on `LV0_Development_Debug`, callstack this time running through
`Engine.dll`/`Renderer.dll` frames (scene proxy creation), not just editor-tool code -
consistent with the stale cross-map object still being resolvable/renderable-attempted at
all, not merely referenced.

New color from the user worth recording for whoever implements the real fix: after this
Load Layout, the affected point IS clickable in the Hierarchy tree and DOES focus the
camera to a location - but is NOT visually rendered in the viewport, even though the user
confirms a control point genuinely exists on the current level's Landscape at that spot,
and the Sync Inspector / debug draw tools report no mismatch (all points "correct"). This
is exactly consistent with the existing root-cause diagnosis, not a new bug: the resolved
`SourcePoint` is a real, valid `ULandscapeSplineControlPoint` UObject (so `LoadSynchronous()`
succeeds, `TryGetPointWorldLocation` returns true, click-to-focus works, Sync Inspector's
tolerance-diff sees no mismatch because it's comparing the stale object's OWN
Location/Rotation against itself) - it is simply the WRONG object, silently belonging to a
different, still-resident map's `LandscapeSplinesComponent` rather than the current level's,
so the CURRENT level's viewport never renders it (nothing there references it) while a
genuinely separate, correctly-materialized control point sits at that same authored
position, unconnected to Nexus's `SourcePoint`. Still not fixed - same open TODO, same
proposed fix (a shared `IsControlPointOnTargetLandscape`-style guard at each
`LoadSynchronous()`/`.Get()` call site, validating the resolved object's owning
`ULandscapeSplinesComponent` against `ResolveTargetLandscape()` before trusting it).

## TODO:3 - "DANGER BUG" (user-reported 2026-08-09) - stale SourcePoint doesn't just misresolve, it actively DIRTIES and tries to SAVE the wrong, closed map

User's own words: "I have 2 Level/Map A and B. i adjust someing in A and switch into B our
system still try to reference the old A when i do soming change in B it pointing in A still
so, due to this UE showing dirty A but we currently stay on B. and due to this when i load
layout it still try to open inside the A so, due to this UE some time crash and the A
showing dirty and try to save but failed."

Confirmed `ResolveTargetLandscape()` itself is NOT the culprit (re-read it this session -
`NexusFrameworkEditorSubsystem.cpp:1528` - it re-resolves fresh via
`GEditor->GetEditorWorldContext().World()` on every single call, nothing cached). This is
the SAME root cause as the TODO/TODO:2 sections above, one level more severe than either
described: Load Layout in B resolves a `SourcePoint` that's a real, still-resident
`ULandscapeSplineControlPoint` living in map A's package (`TSoftObjectPtr` resolves by
package path, independent of which level is currently open).
`MaterializeMissingPointGeometry`/`ApplyHighwayConfiguration` then don't just READ that
stale object, they call `Modify()`/`ConnectControlPointsWithSegment(...)` on it directly -
since `Modify()` operates on whatever UObject you hand it regardless of which level is
"current" in the editor, this actively marks map A's package dirty and writes new
segment/connection data into it, even though the user is looking at (and believes they're
only editing) map B. That's exactly "UE showing dirty A but we currently stay on B" - not a
misdisplay, a real unwanted write into a closed level's package, which is also why a save
can intermittently crash or fail (the same "Illegal reference to private object... belongs
to an external map" class of error from this file's original symptom 3, now confirmed to
also leave the SOURCE map dirty-and-unsaveable, not just the current one).

Still the same fix, now higher priority given the save-corruption/crash risk: a shared
`IsControlPointOnTargetLandscape`-style guard at every `LoadSynchronous()`/`.Get()` call
site (validating the resolved object's owning `ULandscapeSplinesComponent` against
`ResolveTargetLandscape()` BEFORE calling `Modify()`/wiring it into anything) - logged only,
not implemented yet, per direct instruction to add this as a TODO.

## FIXED (2026-08-09, not yet build-verified) - proven with captured logs first, per user's explicit "prove it before patching" instruction

User demanded map-trace evidence before any further patch (rightly, after 3 prior reports
of "the same known issue" with no log proof). Added temporary diagnostic logging
(`LogSourcePointMapTrace` + call sites in `MaterializeMissingPointGeometry`,
`ApplyHighwayConfiguration`, `TryGetPointWorldLocation`/`Rotation`, `SyncFromLandscape`,
`LoadLayout`, `HandleMapOpened`) - all pure `UE_LOG` additions, no behavior change - then
had the user run the EXACT repro (`Debug2: Generate Random City, Save` -> `Debug1: Load same
Layout`) and paste the captured Output Log.

**The log proved it unambiguously**: `HandleMapOpened` DID correctly reset WorldData to 0
points on the Debug2->Debug1 switch (confirmed via the before/after point-count log). Then
Load Layout's own `[Nexus LayoutLoad]` trace showed all 9 loaded points' `SavedSourcePointPath`
pointing at `LV0_Development_Debug2...Landscape_1.LandscapeSplinesComponent_0.NexusPoint_*`.
Then EVERY `[Nexus MapTrace] MaterializeMissingPointGeometry` line for all 9 points showed
`ResolvedControlPoint` successfully resolving to that same Debug2 object (`MapMatch: NO`,
`SplinesComponentMatch: NO`) - proving Debug2's package was still fully resident in memory
after `CleanupWorld` (no explicit GC pass forces it out immediately) and
`TSoftObjectPtr::LoadSynchronous()` happily resolved across it.

**Found the exact mechanism while tracing where to log** (more precise than the earlier
TODO/TODO:2/TODO:3 writeups): `MaterializeMissingPointGeometry` only gates FRESH CREATION on
`if (!ControlPoint)` - but unconditionally calls
`ConnectControlPointsWithSegment(SplinesComponent, PreviousControlPoint, ControlPoint, ...)`
for every consecutive point pair regardless of whether either resolved point is actually on
the CURRENT map. Since all 9 points "resolved successfully" (to Debug2), nothing got created
fresh, but the code still wired brand-new `ULandscapeSplineSegment` objects INSIDE Debug1's
own SplinesComponent whose `Connections[].ControlPoint` point at Debug2's control points, AND
added those segments into Debug2's own `ConnectedSegments` arrays - a bidirectional illegal
cross-package reference. That is exactly what
`Connection.ControlPoint->GetOuterULandscapeSplinesComponent() == this` catches. The
`OutgoingTangentLen changed` log lines captured right before the crash are the tangent-sync
handler reacting to those very newly-created (wrongly-wired) segments as the "Nexus: Load
Layout" transaction closed - independent confirmation from a second log signal, not just the
MapTrace lines.

**Fix implemented** (smallest correct change, per direct instruction not to redesign the
architecture): new `bool IsControlPointOnTargetLandscape(const ULandscapeSplineControlPoint*)
const` (`NexusFrameworkEditorSubsystem.h`/`.cpp`, public, next to `ResolveTargetLandscape()`) -
true only if `ControlPoint->GetOuter() == ResolveTargetLandscape()->GetSplinesComponent()`.
Applied at exactly the 3 call sites implicated by the proven mechanism (not all ~20
`SourcePoint` resolution sites in the file - deliberately scoped to the ones that actually
write Landscape geometry or feed data everything else depends on):
1. `MaterializeMissingPointGeometry` - a resolved-but-wrong-map `ControlPoint` is now treated
   exactly like `!ControlPoint` (set back to `nullptr` before the existing creation branch) -
   this single change fixes BOTH the "silently skipped, nothing materializes" symptom AND the
   cross-map segment-wiring bug in one place, since `ConnectControlPointsWithSegment` further
   down always sees the (now guaranteed current-map) reassigned variable.
2. `ApplyHighwayConfiguration` - same guard, but SKIPS the point (logged) rather than
   re-materializing - this function configures already-placed points, it shouldn't silently
   create geometry as a side effect. Also fixed the second, previously-flagged exposure of
   the same bug in the same function: `SplinesComponent` used to be derived from the FIRST
   resolved point's own `GetOuter()` (could itself be the wrong map); now taken directly from
   `ResolveTargetLandscape()->GetSplinesComponent()`, made explicit rather than incidental now
   that the guard establishes every processed point IS on-target.
3. `TryGetPointWorldLocation`/`TryGetPointWorldRotation` - a wrong-map resolution now returns
   `false` (same as unresolved), which cascades correctness to every consumer (Sync Inspector
   diff, click-to-focus, `SyncPointGeometrySnapshots` before every save) without needing to
   patch each of them individually.

Diagnostic logging left in place (not stripped) - `TryGetPointWorldLocation`/`Rotation` still
log on the same mismatch condition, now purely as a build-verification aid (a clean rebuild
of this exact repro should produce zero MapTrace mismatch lines and zero
`OutgoingTangentLen changed` lines from foreign points, with the loaded points instead
getting freshly created on Debug1). `SyncFromLandscape`'s own `TrackedControlPoints` gather
was deliberately left unguarded - not implicated in either proven write-path mechanism,
kept out of scope per "smallest correct fix".

Not yet build-verified.

## BUILD-VERIFIED (2026-08-09) - user re-ran the exact Debug2->Debug1 repro, fix confirmed working

Captured log shows, for all 9 loaded points: `MaterializeMissingPointGeometry`'s MapTrace
line (`MapMatch: NO`) immediately followed by the new
`[Landscape->Nexus] Point <id>: SourcePoint resolved but belongs to a different map
(.../LV0_Development_Debug2) - re-materializing fresh on the current map.` line - the guard
fired for every single point, every time. The full log runs clean through to the end of
Load Layout with **no `Connection.ControlPoint->GetOuterULandscapeSplinesComponent() == this`
ensure and no `Cast of Package /Engine/Transient` fatal error** - both fired reliably on this
exact repro before the fix. `OutgoingTangentLen changed` lines at the end are now benign
(freshly-created Debug1 segments, not cross-map ones).

Root cause fully closed for the 3 guarded call sites
(`MaterializeMissingPointGeometry`/`ApplyHighwayConfiguration`/
`TryGetPointWorldLocation`+`Rotation`). Diagnostic logging (`[Nexus MapTrace]`/
`[Nexus LayoutLoad]`/`[Nexus MapChange]`) still present in code, left in deliberately as an
ongoing regression tripwire - safe to strip later if it gets noisy, not urgent.
