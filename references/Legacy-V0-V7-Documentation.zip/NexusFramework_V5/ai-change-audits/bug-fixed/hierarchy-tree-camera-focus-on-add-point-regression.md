# Hierarchy tree camera-focus-on-add-point regression

Date: 2026-08-09
Category: bug-fixed

## Context

User reported: adding a new highway/spline point (either via native Landscape point
creation, or the Draw Point "external add-point" button) must NOT move/focus the viewport
camera. Only an explicit Tree View row click/keyboard navigation should trigger the
existing camera-focus behavior. Explicitly flagged as having been "fixed multiple times
and returned multiple times" - user asked for the actual root cause, not another one-off
patch.

## Problem / Goal

`SNexusFrameworkPanel::OnTreeSelectionChanged` calls `FocusViewportOnActiveSelection()` +
`RestoreViewportFocus()`. An existing in-code comment (found already in place before this
session) claimed the fix was already correct: `bIsSyncingTreeSelection` (a bool flag set
true for the duration of `SyncTreeSelectionFromSubsystem()`'s own `SetItemSelection` call)
guards every programmatic selection change, so only a genuine user tree click should ever
reach the focus call. That comment was itself evidence of at least one earlier fix attempt
- and yet the bug kept recurring, meaning that guard was not actually sufficient.

## Findings

Traced the mechanism via Slate engine source (`Engine/Source/Runtime/Slate/Public/Widgets/
Views/SListView.h` and `STreeView.h`), not guessed:

- `STreeView::Tick()` (`STreeView.h` ~line 607-667) does its OWN selection reconciliation,
  independent of any call this project's code makes: whenever `RequestTreeRefresh()` was
  called (which `RefreshHierarchy()` - bound to `OnLayoutChanged`, broadcast by every
  point-add path - does every time), the tree repopulates `LinearizedItems` from the
  current `RootItems` on the *next Slate tick* and compares the resulting selected-item set
  against what the tree widget already had cached. If `RefreshHierarchy()` replaced
  `RootItems` with brand-new `FNexusOutlinerItem` instances (it does - `RootItems.Reset()`
  then full rebuild, every time), this reconciliation can find a mismatch and calls
  `Private_SignalSelectionChanged(ESelectInfo::Direct)` **itself**, on a later frame,
  entirely outside any call stack this project's C++ controls.
- `bIsSyncingTreeSelection` only brackets the SYNCHRONOUS call stack of our own
  `SyncTreeSelectionFromSubsystem() -> TreeView->SetItemSelection()` call. It has already
  been reset to `false` by the time a next-tick, engine-internal signal like the one above
  fires - so it cannot, and structurally never could, guard against that path. This is why
  every previous fix attempt (guard added, bug "resolved," bug returns later) kept failing
  in the same way: each one only re-verified the synchronous path, not the deferred one.
- Confirmed via `SlateEnums.h` (`ESelectInfo::Type`) that `Direct`'s own engine doc comment
  is literally *"Selection was directly set in code"* - and it is the exact tag BOTH our
  own `SetItemSelection(..., ESelectInfo::Direct)` calls AND Slate's internal deferred
  reconciliation use. Genuine user interaction is always tagged `OnMouseClick`,
  `OnKeyPress`, or `OnNavigation` - never `Direct`.

## Changes

`SNexusFrameworkPanel::OnTreeSelectionChanged` (`SNexusFrameworkPanel.cpp`): added
`if (SelectInfo == ESelectInfo::Direct) { return; }` as the very first check, before even
`bIsSyncingTreeSelection`. This is the correct architectural boundary the user asked for:
it doesn't matter WHEN or WHY a `Direct` signal fires (our own code, or Slate's own
internal deferred Tick reconciliation, now or in some future engine version) - only a
genuine user-driven selection change should ever call `SetActiveXxx`/move the camera from
this function, and `SelectInfo` is exactly the semantic tag Slate provides for that
distinction. `bIsSyncingTreeSelection` was kept as defense-in-depth (harmless, still
correct for the synchronous case) but is no longer the only guard.

Also fixed the identical unguarded pattern in `SNexusSyncInspectorPanel::
OnSyncDiffSelectionChanged` (found while checking "all relevant paths" per the task's own
instruction) - this panel's tree doesn't auto-rebuild on point-add (only on its manual
Refresh button), so it wasn't the direct cause of this regression, but it shares the exact
same unguarded `STreeView::Tick()`-reconciliation exposure and would have let the same bug
class resurface via a different trigger (click Refresh while a row is selected). Same
one-line `SelectInfo == ESelectInfo::Direct` guard added.

Updated the stale doc comment on `SNexusFrameworkPanel::FocusViewportOnActiveSelection`
(header) which incorrectly credited `bIsSyncingTreeSelection` alone as sufficient - now
points at the real mechanism.

## Verification

Brace-balance and non-ASCII checks clean on both modified `.cpp` files and the header.
**Not yet built or run** - per this project's own established workflow, the user builds
and verifies. Per the task's own explicit execution order ("do not proceed until this is
fixed and verified"), Priority 2 (save/load fidelity) has not been started yet - waiting
for this fix to be confirmed first.

## Result

Code-complete, not yet build-verified.

## Important Notes

If this regression is ever reported again in the future, the first thing to check is
whether some OTHER Slate delegate binding was added that reacts to `ESelectInfo::Direct`
without filtering it - the fix here is structural (filter the tag, not the timing), so a
recurrence would mean a NEW unguarded listener was added somewhere, not that this fix
itself failed.
