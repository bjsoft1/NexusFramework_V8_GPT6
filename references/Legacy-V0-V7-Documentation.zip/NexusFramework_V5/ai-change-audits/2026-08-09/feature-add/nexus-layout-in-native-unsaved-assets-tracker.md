# Nexus Layout Shows Up In UE's Native "Unsaved Assets" Status Bar

Date: 2026-08-09
Category: feature-add

## Context

User asked: is it possible to put our (Nexus Layout) file into the editor's
own "unsaved/dirty files" indicator - the one that shows a count in the
status bar and, when clicked, lists every unsaved asset - if that's possible
and not already wired up.

## Findings

- UE 5.8 ships a real engine feature for exactly this: `FUnsavedAssetsTrackerModule`
  (`Engine/Source/Developer/UnsavedAssetsTracker`) - the status bar widget the
  user described (count badge + click-to-expand dropdown listing every dirty
  asset with a Save button per row) already exists natively, no custom UI
  needed on our side at all.
- Confirmed via engine source (`UnsavedAssetsTracker.cpp`) that it populates
  its list purely by listening to `UPackage::PackageMarkedDirtyEvent`/
  `PackageDirtyStateChangedEvent` - GENERIC engine-wide package events, not
  anything specific to worlds/levels/particular asset types
  (`ShouldTrackDirtyPackage` only excludes non-persistent/temp packages,
  which a normal `/Game/NexusLayouts/...` asset isn't).
- Our own `bIsDirty` flag lives entirely on the SUBSYSTEM (`WorldData` is
  copied into the actual `UNexusLayoutAsset` only at save time, via
  `WriteWorldDataToAsset`) - the asset's own UPackage was never being marked
  dirty as Nexus edits happened, so it could never have shown up in the
  engine's tracker even though it conceptually had pending changes.

## Changes

`NexusFrameworkEditorSubsystem.h`/`.cpp`:
- New private `MarkWorldDataDirty()` - the single place `bIsDirty` is now
  ever set true from internal code. Besides the flag, also calls
  `CurrentLayoutAsset->MarkPackageDirty()` when a Layout asset is loaded, so
  the engine's own tracker picks it up for free. All 14 raw
  `bIsDirty = true;` call sites in the .cpp were mechanically replaced with
  calls to this (`replace_all`, verified none of the `bIsDirty = false;`
  sites were touched). The existing public `MarkLayoutDirty()` (external
  UI's entry point, e.g. the Details panel) now routes through it too.
- New private `ClearStalePackageDirtyFlag(UNexusLayoutAsset*)` - counterpart
  for the 3 "discard instead of save" paths (`NewLayout`, `LoadLayout`'s
  LoadFresh choice, `HandleMapOpened`'s forced reset on a map change).
  Without this, discarding unsaved Nexus changes would leave the OLD asset's
  package flagged dirty forever (since `MarkWorldDataDirty()` marks the
  package speculatively, before the asset's own properties are ever actually
  written to - only `WriteWorldDataToAsset`, called from `SaveLayout`/
  `SaveLayoutAs`, does that) - a phantom "unsaved" entry for an asset with
  nothing real to save. Called with the OLD asset pointer captured BEFORE
  `CurrentLayoutAsset` is reset/reassigned at each of the 3 sites. Always
  safe/idempotent - a no-op if the asset was never dirty or already clean
  from a real save (the engine's own `SaveLoadedAsset` already clears the
  package dirty flag on a successful save, same mechanism the tracker
  listens to, so the two SUCCESSFUL-save `bIsDirty = false;` sites in
  `SaveLayout`/`SaveLayoutAs` needed no change).

## Verification

Not yet build-verified - see [[user-builds-and-verifies]].

## Result

Once a Nexus Layout asset has been saved once this session, any further
Nexus edit marks its package dirty, so it appears in the engine's native
Unsaved Assets status bar widget (count + dropdown + per-row Save) with zero
custom UI. Discarding changes (New Layout / Load Layout fresh / a map change
forcing a reset) correctly clears that flag again instead of leaving a
phantom entry.

## Important Notes

- Before a Layout asset has EVER been saved once in a given session (fresh
  editor launch, no Save Layout/Save Layout As done yet), there's no real
  `UNexusLayoutAsset` UObject/package to mark - `MarkWorldDataDirty()`
  degrades to just setting `bIsDirty` in that case, same as before this
  change. The asset only starts appearing in the native tracker from the
  point it first exists onward.
- `ClearStalePackageDirtyFlag` unconditionally clears the target asset's
  package dirty flag - deliberately not checking for some OTHER, unrelated
  reason the package might be dirty, since a `UNexusLayoutAsset` in this
  codebase is only ever edited through this subsystem (never raw
  Details-panel property edits), making that assumption safe here
  specifically - not a pattern to copy onto a more general-purpose asset type.
