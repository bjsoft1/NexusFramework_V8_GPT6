# Smart "Unsaved Changes?" Prompt On Landscape-Mode-Exit / Editor Shutdown

Date: 2026-08-09
Category: feature-add

## Context

User request (paraphrased from a somewhat garbled description): on save,
Nexus should compare live Landscape Location/Rotation/Tangent values against
what's tracked, and only when the user is about to lose unsaved Nexus state
(leaving Landscape Mode / closing the editor) AND there's a REAL mismatch
should a "save now?" popup appear - a `bIsDirty` flag alone shouldn't be
enough to nag the user if nothing has actually diverged from what's on disk.

Clarified with the user (AskUserQuestion) before implementing:
- Trigger scope: **both** leaving Landscape Mode AND actual editor shutdown.
- When `bIsDirty` is true but nothing really differs: **silently clear
  `bIsDirty`**, no popup, no save.

## Findings

- `SyncPointGeometrySnapshots()` (`WriteWorldDataToAsset`, called by every
  `SaveLayout()`/`SaveLayoutAs()`) already grabs live Location/Rotation/
  OutgoingTangentLen from the Landscape into `WorldData` on every save - this
  part of the user's ask already existed, unconditionally (blind overwrite,
  not compare-then-write, but functionally equivalent since overwriting with
  an identical value is a no-op).
- No "unsaved changes?" prompt existed at all for leaving Landscape Mode or
  closing the editor. `ResolveUnsavedChangesBeforeProceeding` (Yes/No/Cancel)
  only guarded two internal Nexus actions - New Layout, Load Layout.
- `ComputeSyncDiff()` (built for the Sync Inspector tab, see
  [[v5-phase4-todo-refactors]]'s #4) already does exactly the field-level
  comparison needed here - topology AND Location/Rotation/Tangent, same
  tolerances `OnLandscapeSplineObjectTransacted` uses. Reused directly rather
  than writing new comparison logic.
- `FEditorDelegates::OnEditorPreExit` (`Editor.h`) confirmed via engine
  header comment: "Called before the editor exits... before any editor
  subsystems are deinitialized" - safe to read `WorldData`/`bIsDirty`/the
  live Landscape from this callback.
- `FNexusFrameworkLandscapeModeExtension::OnEditorModeIDChanged`'s
  `bIsEnteringMode == false` branch (leaving Landscape Mode) already exists
  and is exactly where the 3 Nexus dockable tabs get closed - a POST-change
  notification, not a vetoable pre-change hook, so by the time it fires the
  mode has already switched (no way to actually cancel leaving the mode from
  here, unlike New Layout/Load Layout which haven't happened yet when
  `ResolveUnsavedChangesBeforeProceeding` runs).

## Changes

`NexusFrameworkEditorSubsystem.h`/`.cpp`:
- `bool HasRealUnsyncedChanges() const` - true if `ComputeSyncDiff()` returns
  any entry with `Status != Synchronized`.
- `void ResolveUnsavedChangesOnExit()` - no-op if `!bIsDirty`; if
  `HasRealUnsyncedChanges()` is false, silently clears `bIsDirty` (per the
  user's clarified choice) and returns with no dialog; otherwise shows a
  Yes/No (not Yes/No/Cancel - nothing left to veto) "Save the Nexus Layout
  now?" dialog, calling `SaveLayout()` on Yes. "No" deliberately leaves
  `bIsDirty` true so the next exit attempt (or the next map save) asks again.
- `HandleEditorPreExit()` + `EditorPreExitHandle`, bound to
  `FEditorDelegates::OnEditorPreExit` in `Initialize()`/removed in
  `Deinitialize()`, same pattern as the existing `PostSaveWorldHandle`/
  `MapOpenedHandle` - calls `ResolveUnsavedChangesOnExit()`.

`NexusFrameworkLandscapeModeExtension.cpp`: `OnEditorModeIDChanged`'s leaving-
Landscape-Mode branch now calls `Subsystem->ResolveUnsavedChangesOnExit()`
before requesting the 3 tabs to close.

## Verification

Not yet build-verified - see [[user-builds-and-verifies]].

## Result

Two new trigger points (leaving Landscape Mode, editor shutdown) both run the
same real value-comparison before ever showing a save prompt. A `bIsDirty`
flag that turns out to be a false positive (nothing actually diverged from
disk) is now silently cleared instead of interrupting the user.

## Important Notes

- `ResolveUnsavedChangesBeforeProceeding` (New Layout / Load Layout's own
  Yes/No/Cancel prompt) was deliberately left untouched - out of scope for
  this request, which was specifically about exit/mode-switch. The same
  false-positive problem could in principle affect those two too; worth
  revisiting later if the user wants that consistency, not assumed here.
- `SyncPointGeometrySnapshots` was NOT changed to be conditional
  (compare-then-write) - its unconditional overwrite was already functionally
  equivalent to a compare-then-write for the persisted end state, and
  changing it wasn't needed to satisfy the actual new behavior requested
  (the exit-time prompt gating).
