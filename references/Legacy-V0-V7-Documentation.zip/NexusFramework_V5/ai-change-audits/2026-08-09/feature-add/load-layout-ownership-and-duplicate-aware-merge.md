# Load Layout: Cross-Map Ownership Dialog + Duplicate-Aware Import and Merge

Date: 2026-08-09
Category: feature-add

## Context

Follow-up to `agent-todos/ready-for-development/layout-load-ownership-mismatch-and-authoritative-refresh.md`
(itself a split-out of `layout_load_time_if_existing_segment_already_has_then_not_asking_queston.txt`,
whose "dialog doesn't appear" bug was already fixed separately, see
`ai-change-audits/2026-08-09/bug-fixed/` — Improve Load Layout safety commit f689e88). That
ready-for-development doc's Part A (ownership) and Part B (same-map landscape-authoritative
refresh) had been approved in design terms but never implemented. This session, the user
re-specified both more precisely across several messages, adding a requirement not in the
original doc at all: "Import and Merge" needed genuine duplicate-point detection (an incoming
Layout's point that's already physically present on the Landscape must be recognized and
reconciled, not re-added as a second entity).

## Problem / Goal

1. `FNexusWorldData::MergeFrom` was a blind GUID-collision-avoiding union — zero duplicate
   detection. An incoming point already materialized on the current Landscape (e.g. re-merging
   a Layout saved earlier in the same session) would be added again under a fresh GUID,
   creating a second `FNexusRoadPoint` entry aliasing the same physical control point.
2. `MaterializeMissingPointGeometry()`'s classification pass ran
   `RecomputePointClassification(..., bRestoreSavedRotation=true)` over every point *walked*
   during a Load batch (`TouchedPointIds`), not just points actually (re)created — so an
   already-resolved point sharing a highway with a newly-materialized neighbor had its live,
   currently-correct rotation overwritten by a stale saved snapshot. This made merge-with-
   dedup unsafe even once duplicate detection existed.
3. No map-ownership tracking existed at all — loading a Layout saved from a different map had
   no safety net.

User's explicit, twice-stated requirement: an already-existing/duplicate point's location,
rotation, and mesh must never be touched by Load/Merge — "landscape has valid value so we do
not want to reset or update it."

## Findings

- `MergeFrom` (`NexusWorldData.cpp:395-488` before this change) has exactly one call site in
  the whole module (`NexusFrameworkEditorSubsystem.cpp`'s `LoadLayout()`), so extending its
  signature in place (default-valued param) was safe — no other caller to consider.
- `MaterializeMissingPointGeometry`'s `TouchedPointIds` had exactly one real purpose (feeding
  the classification loop) despite being populated unconditionally for every point walked —
  confirmed via full read, no other consumer existed.
- This function sits directly next to the still-open, engine-level `Q.IsNormalized()` crash
  investigation (`ai-change-audits/2026-08-09/research/quat-isnormalized-crash-deep-research.md`,
  TODO 7: "do not implement rotation/tangent architecture changes without explicit approval").
  The fix here only narrows *which* points get `RecomputePointClassification` called on them
  (`NewlyMaterializedPointIds` is always a strict subset of the old `TouchedPointIds`) — it
  cannot increase exposure to that crash pattern, only reduce it. No rotation/tangent math was
  touched.
- No existing toast/notification widget exists anywhere in this module — confirmed via grep.
  The only precedent (`ai-change-audits/feature-add/v5-auto-save-after-map-save.md`'s "if
  saved failed notify retry") uses a blocking `FMessageDialog::Open`, reused here for the
  Override-mismatch warning.
- `NexusFrameworkTab::SyncInspectorTabId` is declared `.cpp`-local inside
  `NexusFrameworkLandscapeModeExtension.cpp:14-19`, not header-exported. Rather than hoist it
  into a new shared header (scope creep for one FName), the literal `FName(TEXT("NexusSyncInspectorPanel"))`
  is duplicated with a cross-reference comment. **If that TabId string ever changes, this
  literal must be updated too — it is not compile-enforced.**

## Changes

**A. `UNexusLayoutAsset`** (`Public/Schema/Editor/NexusLayoutAsset.h`) — new field
`FName SavedMapPackage`, stamped in `WriteWorldDataToAsset` (the single choke point shared by
`SaveLayout()`/`SaveLayoutAs()`) from `GEditor->GetEditorWorldContext().World()->GetOutermost()->GetName()`.
`NAME_None` (asset predates this field, or saved with no map resident) is always treated as "no
conflict" for full backward compatibility with every already-saved asset.

**B. `FNexusWorldData::MergeFrom`** — new param `const TMap<FGuid, FGuid>& PointCollapseRemap = {}`
(`IncomingPointId -> ExistingPointId`). Seeded into the internal `Remap` table before the
existing collision-avoidance pass (a deliberate collapse always wins over a plain ID
collision). The Points loop now skips re-adding a collapsed incoming point entirely — folds
its (remapped) `ConnectedHighwayIds` onto the **existing** point via `AddUnique`, leaves
Code/Name/PointId/SourcePoint/geometry untouched. States/Cities/Highways loops are unchanged;
`RemapId` transparently redirects a collapsed PointId, so an incoming Highway referencing
duplicate points is still added as a new entity with correctly-rewired `OrderedPointIds` — no
highway-level dedup was introduced (out of scope, not requested).

**Known gap, not fixed:** if an incoming Highway's points are *all* collapsed duplicates,
`MergeFrom` still adds a new `FNexusHighway` record describing the same physical chain (no
duplicate geometry gets created — `MaterializeMissingPointGeometry`'s `AreControlPointsConnected`
guard already prevents that — but WorldData ends up with two Highway records for one road).

**C. `LoadLayout()`'s `ImportAndMerge` branch** — new pre-pass building
`PointCollapseRemap`: reverse-lookup every currently-tracked WorldData point's resolved,
on-target-landscape `SourcePoint` into `ULandscapeSplineControlPoint* -> PointId`, then for
each incoming point whose own `SourcePoint` resolves to one of those same live control points,
record the collapse. `WorldData.MergeFrom(Asset->World, PointCollapseRemap)` then
`SyncPointGeometrySnapshots()` (pull-only, already-existing function) refreshes every
duplicate's geometry snapshot from the live Landscape.

**D. `MaterializeMissingPointGeometry()`** — `TouchedPointIds` renamed to
`NewlyMaterializedPointIds` and only populated inside the `if (!ControlPoint) { ... }` branch
(genuinely (re)created this pass), not unconditionally for every point walked. The
classification loop (`RecomputePointClassification`/`ApplyPointFurniture`) now iterates only
this narrower set — an already-resolved point (including every duplicate-collapse target) is
never reclassified/remeshed, keeping its live Landscape state exactly as-is even if a new
neighbor was just wired up next to it. Segment-connection/tangent-enforce logic for such points
is untouched — a new segment to a genuinely-new neighbor still connects correctly.

**E. `LoadLayout()`** — `PerformLoadFreshFromAsset(UNexusLayoutAsset*)` extracted as a private
helper (wipe Landscape → wholesale WorldData/config swap → reset active selection), shared by
the existing `LoadFresh` choice and the new ownership dialog's Copy/Override choices. New
ownership pre-check inserted before the existing 4-choice dialog: if `Asset->SavedMapPackage`
is set and differs from the current map, shows `SNexusLoadLayoutOwnershipDialog`
(Copy/Override/Cancel) **instead of** the 4-choice dialog (self-contained, returns after
handling — never falls through to it). Copy = `PerformLoadFreshFromAsset` + `SaveLayoutAs()`
(new asset tied to the current map; original untouched). Override = `PerformLoadFreshFromAsset`
+ post-load `ComputeSyncDiff()` check, warning dialog + Sync Inspector tab invoke if any
`Mismatch` entries remain.

**F. New `SNexusLoadLayoutOwnershipDialog`** (`Public/UI/` + `Private/UI/`) — mirrors
`SNexusLoadLayoutChoiceDialog`'s exact shape (`SModalEditorDialog<>`, same button-building
pattern), `ENexusLoadLayoutOwnershipChoice { Copy, Override, Cancel }`.

## Verification

Build: `Build.bat NexusFrameworkEditor Win64 Development` — **Succeeded, 0 errors** (editor was
closed this session, ran the full offline build rather than Live Coding).

**NOT yet manually tested in-editor** — per project convention, code changes stop here; the
user builds/verifies. Full verification matrix (same-map/no-geometry, same-map/existing-
geometry, cross-map Copy/Override/Cancel, backward-compat with `SavedMapPackage==NAME_None`,
and the core duplicate+genuinely-new-point merge scenario) is spelled out in the approved plan
file for this session (not itself part of the repo) — condensed list:

1. Same-map load, empty landscape → unchanged (no new dialogs).
2. Same-map load, existing geometry → existing 4-choice dialog unchanged, no ownership dialog.
3. Cross-map load, Copy → ownership dialog fires; new asset saved via native Save dialog;
   original asset's `World`/`SavedMapPackage` unmodified.
4. Cross-map load, Override → behaves like Load Fresh; mismatch warning + Sync Inspector tab
   invoke fires only when `ComputeSyncDiff()` actually reports a `Mismatch` afterward.
5. Cross-map load, Cancel → nothing changes.
6. Legacy asset (`SavedMapPackage == NAME_None`) → skips ownership dialog, falls straight into
   existing flow.
7. **Core scenario**: Import and Merge with a duplicate (already-materialized, natively
   rotated without saving) + genuinely-new point sharing a highway — duplicate's live
   rotation/mesh must be unchanged, must not appear as a second `FNexusRoadPoint`, new point
   materializes from its own saved config, the connecting segment renders, duplicate's
   `ConnectedHighwayIds` includes both highways.
8. Regression: re-run `tangent-lost-on-save-load-roundtrip.md` and
   `sync-inspector-false-positive-tangent-mismatch.md`'s existing verifications.

## Result

Code complete, compiles clean. Awaiting user in-editor verification per
`ai-change-audits/others/user-builds-and-verifies.md`.

## Important Notes

- `NexusFrameworkTab::SyncInspectorTabId`'s string literal is duplicated (not shared) in
  `LoadLayout()` — see Findings above. Update both places if that TabId ever changes.
- Override reassigns `CurrentLayoutAsset` to the original, mismatched asset (matching "proceed
  exactly like today's Load Fresh") — a subsequent plain `Save` (not Save As) after Override
  will silently overwrite that original asset. Since `WriteWorldDataToAsset` now re-stamps
  `SavedMapPackage` on every save, this "self-corrects" the mismatch going forward — flagged as
  an intentional consequence, not a bug, but worth knowing if it surprises the user later.
- `MergeFrom`'s duplicate detection only catches points whose `SourcePoint` resolves against a
  *currently-tracked* WorldData point. An incoming point resolving to a live-but-untracked
  (orphaned/native) control point on the target Landscape still aliases via the pre-existing
  (unchanged) "add as new, keep old SourcePoint" path — not a new gap, but not closed by this
  change either.
- Highway-level duplication (two Highway records describing one physical chain when an
  incoming Highway's points are all collapsed duplicates) is a known, explicitly out-of-scope
  gap — see Changes/B.

## Follow-up — 2026-08-09 (same-day, Load Fresh gains the same "map, don't wipe" behavior)

**Context**: right after the above shipped, the user asked directly whether Load Fresh
"tries to map with landscape existing segment if possible, otherwise just show warning and
unsaved dirty" — it did not. Load Fresh still unconditionally called `WipeLandscapeSplineGeometry`
before rebuilding everything from the loaded asset's saved snapshot, discarding any
already-correct live geometry even when the incoming asset's own saved `SourcePoint`
references would have resolved fine. This directly reversed something confirmed earlier the
same session (that Load Fresh's job is "landscape remove all segment info, put layout segment
info") — flagged explicitly to the user before implementing, since it also affects
`PerformLoadFreshFromAsset` (shared by the ownership dialog's Copy/Override). User confirmed:
leave any leftover/unmapped Landscape geometry in place (warn + mark dirty), don't delete it.

**Changes**:
- `PerformLoadFreshFromAsset` (`NexusFrameworkEditorSubsystem.cpp`) no longer calls
  `WipeLandscapeSplineGeometry`. It still replaces WorldData/config wholesale from the Asset,
  but now the caller's subsequent `MaterializeMissingPointGeometry()` naturally reuses
  whichever of the just-loaded Points' `SourcePoint` references still resolve on the current
  Landscape (this is only safe because of the `NewlyMaterializedPointIds` fix earlier in this
  same file's Changes/D — an already-resolving point is never reclassified/remeshed) and only
  creates fresh geometry for the rest.
- New `WarnAndMarkDirtyIfSyncDiffHasIssues()` — called right after `MaterializeMissingPointGeometry()`
  on every path that no longer wipes (LoadFresh choice, and the ownership dialog's Copy AND
  Override, replacing Override's previous Mismatch-only inline check). Runs `ComputeSyncDiff()`
  and, if anything comes back `Mismatch` or `UntrackedInNexus` (leftover Landscape geometry the
  newly-loaded WorldData doesn't reference), shows a blocking notice pointing at the Sync
  Inspector tab and calls `MarkWorldDataDirty()` — nothing is deleted, nothing is silently
  ignored either.
- Updated two stale comments that described the old unconditional-wipe behavior (the
  native-selection crash guard's rationale, and the `MaterializeMissingPointGeometry` call-site
  comment) to stay accurate — the crash guard itself was left functionally unchanged
  (still blocks any Load with a natively-selected point) even though its originally-cited
  destroy-while-selected mechanism no longer applies to Load Fresh specifically, since removing
  a crash-prevention guard wasn't asked for and costs nothing to keep.
- `ImportAndMerge` is unaffected — it never wiped either, and its own duplicate-collapse
  reconciliation (added earlier this same file's Changes/C) already achieves the equivalent
  "map instead of recreate" behavior for that path.

**Build**: `Build.bat NexusFrameworkEditor Win64 Development` — Succeeded, 0 errors.

**NOT yet manually tested in-editor** — same as the rest of this record.
