# Sync Inspector: JSON Export / Auto-Log Report

Date: 2026-08-09
Category: feature-add

## Context

While investigating [[quat-not-normalized-crash-on-load]], the user opened
the Nexus Sync Inspector and found 15 Configuration Mismatch entries, but
had no way to get their full detail (Nexus-vs-UE values for every field) out
of the tree-view UI to hand back for diagnosis - the tree only shows one
field pair at a time per expanded row, no select-all/copy. User asked for
either a JSON copy system or a full console-log dump, whichever was easier,
so they could paste the complete data back for the actual investigation to
continue.

## Changes

`NexusFrameworkEditor.Build.cs`: added `"ApplicationCore"` to
`PrivateDependencyModuleNames` - needed for `FPlatformApplicationMisc::
ClipboardCopy`, not previously a dependency of this module.

`SNexusSyncInspectorPanel.h`/`.cpp`:
- New `LastDiffEntries` member - the raw `ComputeSyncDiff()` output from the
  last Refresh, cached verbatim (separately from `RootItems`, which
  `BuildTreeFromDiff` folds into a display tree) so the report always
  reflects exactly what's on screen, not a freshly-recomputed and
  potentially-already-different snapshot.
- New **"Copy Report as JSON"** button next to Refresh - copies
  `BuildJsonReport(LastDiffEntries)` straight to the OS clipboard via
  `FPlatformApplicationMisc::ClipboardCopy`.
- `BuildJsonReport`: hand-serializes (no `Json` module dependency added -
  the value types here are simple enough not to need one) a JSON array, one
  object per non-Synchronized entry (Mismatch/MissingInUE/UntrackedInNexus -
  Synchronized is the "nothing wrong" case and would just be noise).
  Each object carries: `status`, `pointLabel`, `pointId`, `chainIndex`,
  `state`/`city`/`highway` (Code, falling back to Name - looked up from
  `WorldData` the same way `BuildTreeFromDiff` labels its State/City/Highway
  rows), `mismatchFlags` (array of which fields actually differ, only
  populated for Mismatch entries), and the FULL Nexus-vs-UE value pairs for
  Location/Rotation/OutgoingTangent/IncomingTangent regardless of whether
  that specific field was flagged - a complete, standalone snapshot readable
  without the live tool open.
- `EscapeJsonString`: minimal manual JSON string escaping (`"`, `\`,
  `\n`/`\r`/`\t`) applied to every string value placed into the report -
  `DisplayLabel`/State/City/Highway names are free-form user text and could
  contain characters that would otherwise break the JSON.
- `LogDiffReport`: prints the same JSON to `UE_LOG(LogTemp, Log, ...)`,
  chunked line-by-line (`ParseIntoArrayLines`) rather than one giant
  multi-KB `UE_LOG` call - avoids Output Log readability/console
  line-truncation issues. Wrapped in `[NEXUS SYNC REPORT] ===...=== begin/end`
  markers plus a one-line summary count, all lines prefixed
  `[NEXUS SYNC REPORT]` for easy log-file searching.
- **Called automatically at the end of every `RefreshSyncDiff()`** (not just
  when Copy is clicked) - clicking the existing "Refresh Sync Diff" button
  (or just opening the tab) now always leaves the full report in the log,
  with zero extra steps, directly matching "I will give you full console
  logs."

## Verification

**Build-verified**: `Build.bat NexusFrameworkEditor Win64 Development` -
**Result: Succeeded**, 23/23 actions, 0 compile errors. Same pre-existing,
unrelated `SNexusFrameworkPanel.cpp` header-order warning as prior sessions
- not caused by this change.

Not interactively verified (no GUI-automation capability) - user should open
Nexus Sync Inspector, click Refresh (or just note it already ran on tab
open), and check the log for `[NEXUS SYNC REPORT]` lines, or click "Copy
Report as JSON" and paste.

## Result

The Sync Inspector's mismatch data is no longer trapped in the tree-view UI
- every Missing-in-UE/Untracked/Mismatch entry's full Nexus-vs-UE field
values are available both via clipboard (JSON) and automatically in the log
on every refresh, addressing the immediate blocker in the ongoing
[[quat-not-normalized-crash-on-load]] investigation.

## Important Notes

- Purely additive/read-only - does not change `ComputeSyncDiff`'s own logic,
  the tree view's existing behavior, or any Nexus/Landscape data.
- Synchronized entries are deliberately omitted from the report to keep it
  focused - if a future need arises to see those too, that's a small,
  separate follow-up (a "include synchronized" toggle), not implemented
  here since it wasn't asked for.
