# Global Configuration section (Default Mesh Asset Set + City Generate Configuration) and Generate Random City gating

Date: 2026-08-09
Category: feature-add

## Context

User asked to add a "City Generate Configuration/Data Asset" section to the
panel immediately after the existing "Default Mesh Asset Set" picker, fold
both under one renamed "Global Configuration" concept instead of a per-
section label each, drop the standalone "Mesh Config" header text (spacing
only, no replacement label), and change `Generate Random City` to enable off
the new config asset being set rather than requiring a City to be the active
Hierarchy selection first.

A `Content/NF/Datasets/CityGenerateSettingsDataAsset.uasset` (an instance of
the existing `UNexusGenerationSettings` class) was already sitting staged in
the working tree before this session started - confirmed via binary string
inspection (class `/Script/NexusFrameworkEditor.NexusGenerationSettings`),
not something this session created. Also already staged/unrelated to this
task: a separate in-progress `CornerSharpDetectionAngle` override-chain
feature touching `NexusCity.h`/`NexusState.h`/`NexusHighway.h`/
`NexusGenerationSettings.h`/the subsystem - left untouched throughout.

## Findings

`UNexusLayoutAsset` already had a `GenerationSettings` field
(`TSoftObjectPtr<UNexusGenerationSettings>`) and
`UNexusFrameworkEditorSubsystem::ResolveGenerationSettings(CityId)` already
resolved City->`LayoutSettingsOverride`, else
**`CurrentLayoutAsset->GenerationSettings` read directly off the asset** -
i.e. only reachable once a Layout was loaded, with no panel UI and no
subsystem-level mirrored copy. This is a different pattern from
`DefaultMeshAssetSet`/`DebugDrawSettingsAsset`, both of which are
subsystem-level `UPROPERTY`s mirrored to/from `CurrentLayoutAsset` in
`WriteWorldDataToAsset` (save) and `LoadLayout`'s `LoadFresh` branch (load),
so they resolve/are editable even before any Layout is ever saved.

`FNexusCity::LayoutSettingsOverride`'s own doc comment already said "falls
back to the subsystem's default `UNexusGenerationSettings` when unset" -
documenting the `DefaultMeshAssetSet`-style intent before it was actually
wired up. Completed that existing intent rather than inventing a new
pattern.

`SNexusFrameworkPanel::IsGenerateCityEnabled()` gated on
`GetActiveSelectionKind() == City`. The click handler it arms
(`IsGenerateCityOriginArmed`'s eventual viewport click, per its own header
comment) already independently re-checks the active selection is a City AT
CLICK TIME and no-ops otherwise - so the button-level City-selection gate
was a redundant, separable requirement, not load-bearing for correctness.

## Changes

`NexusFrameworkEditorSubsystem.h`: new `TSoftObjectPtr<UNexusGenerationSettings>
GenerationSettings` UPROPERTY (`Category = "Nexus|Generation"`), directly
after `DefaultMeshAssetSet`, same pattern/comment style.

`NexusFrameworkEditorSubsystem.cpp`:
- `WriteWorldDataToAsset`: added `Asset->GenerationSettings = GenerationSettings;`
- `LoadLayout` `LoadFresh` branch: added `GenerationSettings = Asset->GenerationSettings;`
- `LoadLayout` `ImportAndMerge` branch comment: now also lists
  `GenerationSettings` among the fields deliberately left untouched (same as
  `DefaultMeshAssetSet`/`DebugDrawSettingsAsset`/`DebugDrawState`) - no code
  change needed there, it was already only touching `WorldData`.
- `ResolveGenerationSettings`: fallback changed from reading
  `CurrentLayoutAsset->GenerationSettings` to the subsystem's own live
  `GenerationSettings` (mirrors `ResolveHighwayMeshSet`'s own
  `DefaultMeshAssetSet` fallback) - resolves correctly pre-Layout-load too,
  and is what the panel picker actually edits.

`SNexusFrameworkPanel.h`: added `GetSelectedGenerationSettingsPath()` /
`OnSelectedGenerationSettingsChanged()` declarations next to the
`DefaultMeshAssetSet` pair. `IsGenerateCityEnabled()`'s doc comment updated
to explain the new gating.

`SNexusFrameworkPanel.cpp`:
- `#include "NexusGenerationSettings.h"` added; own-header
  (`SNexusFrameworkPanel.h`) moved to the very first include - required by
  this project's `IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_8`
  (own-header-first rule), which the file already silently violated before
  this session (just hadn't been re-invalidated/recompiled recently enough
  to trip the check) - see Verification.
- Section renamed `"MeshConfig"/"Mesh Config"` -> `"GlobalConfiguration"/
  "Global Configuration"` - one shared header now covers both pickers, no
  second section label added for the new one (extra top padding on its
  slot, `Padding(4.f, 8.f, 4.f, 2.f)`, is the only separation).
  `BuildAssetPicker(LOCTEXT("GenerationSettingsLabel", "City Generate
  Configuration"), UNexusGenerationSettings::StaticClass(), ...)` added
  directly below the existing Default Mesh Asset Set picker slot.
- New `GetSelectedGenerationSettingsPath`/`OnSelectedGenerationSettingsChanged`
  - verbatim mirror of the `DefaultMeshAssetSet` pair, targeting
  `Subsystem->GenerationSettings`, calling `MarkLayoutDirty()` on change.
- `IsGenerateCityEnabled()`: `GetActiveSelectionKind() == City` check
  replaced with `!Subsystem->GenerationSettings.IsNull()`; the
  `IsSplinesToolActive()` requirement is unchanged/preserved.

## Verification

Build: `Build.bat NexusFrameworkEditor Win64 Development` first failed with
`error: Expected SNexusFrameworkPanel.h to be first header included` - a
pre-existing include-order violation in this file, newly enforced only
because adding the `NexusGenerationSettings.h` include forced UBT to
re-invalidate/recompile this translation unit (adaptive non-unity build
otherwise leaves untouched files unchecked). Fixed by moving the own-header
include to the top; confirmed this is the project's actual configured rule
via `NexusFrameworkEditor.Target.cs`/`NexusFramework.Target.cs`:
`IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_8`. Second
`Build.bat` attempt then failed only with `Unable to build while Live
Coding is active` (UnrealEditor.exe was running) - user compiled via
Live Coding (Ctrl+Alt+F11) inside the running editor instead. Confirmed
successful via `UnrealEditor-NexusFrameworkEditor.dll`/`.pdb` timestamps
in `Binaries/Win64` matching the compile time the user reported, ~30s
before the check. No further compile/link errors reported.

Not yet interactively verified in the running editor (panel layout,
picker round-trip, button enable/disable, Save/Load Layout round-trip of
the new field) - build-only verification this session, per
[[feedback_user_builds_and_verifies]].

## Result

Global Configuration section now shows Default Mesh Asset Set immediately
followed by City Generate Configuration under one shared header, no
"Mesh Config" label. `GenerationSettings` is a proper subsystem-level
editor default, save/load-mirrored the same way as `DefaultMeshAssetSet`.
`Generate Random City` enables as soon as a City Generate Configuration
asset is assigned (plus the Splines tool being active), independent of
Hierarchy tree selection - the origin-click handler still requires a City
be selected at the moment of the viewport click, unchanged.

## Important Notes

- The pre-existing `CityGenerateSettingsDataAsset.uasset` in
  `Content/NF/Datasets/` is a ready-made `UNexusGenerationSettings` instance
  the user can assign directly via the new picker - not created or modified
  this session.
- Did not touch the separate, already-staged `CornerSharpDetectionAngle`
  work in `NexusCity.h`/`NexusState.h`/`NexusHighway.h`/
  `NexusGenerationSettings.h` - unrelated in-progress feature, left as-is.
- `ResolveGenerationSettings`'s fallback source changed (asset-direct ->
  subsystem-mirrored-live) - functionally a behavior fix/completion of the
  documented-but-unwired intent on `FNexusCity::LayoutSettingsOverride`, not
  a new architecture; flagging in case any other caller was relying on the
  old asset-direct read specifically (none found - `ResolveGenerationSettings`
  is the only reader of that fallback tier).
