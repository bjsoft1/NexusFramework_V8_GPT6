# Auto Terrain Adjustment for Highways (AutoAdjustLandscape)

Date: 2026-08-09
Category: feature-add

## Context

User request: when a highway control point is created or moved, the
Landscape terrain should optionally auto-grade/sculpt to meet the road (a
"ramp"), the way a real highway cuts into or is banked against terrain. Some
highways (bridges, flyovers, tunnels) must NOT get this treatment, and the
override must be settable at every level of the hierarchy - Global -> State
-> City -> Highway -> Point - as a tri-state (`-1` inherit / `0` force off /
`1` force on), most-specific-wins, editable through the same Details panel +
right-click context menu UI already used for Name/Code. Full design went
through `EnterPlanMode`/`ExitPlanMode` with user sign-off before any code was
written - see the approved plan for the original research trail
(`C:\Users\BijayAdhikari\.claude\plans\inherited-plotting-harbor.md`).

## Problem / Goal

Add the override field at every level, a most-specific-wins resolver, and
wire up whatever's needed to make it actually cause terrain deformation on
point create/move - while never touching the recently-fixed rotation logic
(`RecomputePointClassification`/`ComputeDeterministicJunctionForward`) or the
Save/Load rotation-restore path (`bRestoreSavedRotation`).

## Findings

- `FNexusHighway` already had `bRaiseTerrain`/`bLowerTerrain`/`TerrainLayerName`
  (plain bools/name, always `true`/`true`/`None`), already copied onto every
  `ULandscapeSplineSegment` created. **Confirmed via full-module grep:
  `RequestSplineLayerUpdate`/`ApplySplines` were never called anywhere in
  V5.** These fields, even though plumbed onto engine objects, had zero
  actual effect - the engine's terrain-deformation pass never ran. This
  wasn't "add an override to an existing automatic behavior" - the automatic
  behavior didn't exist yet.
- UE 5.8 engine source (`LandscapeSplines.cpp`,
  `ULandscapeSplineControlPoint`/`ULandscapeSplineSegment`) confirmed the
  Landscape Spline system already does exactly the wanted "ramp/grade"
  behavior via `bRaiseTerrain`/`bLowerTerrain` bits read by its own
  rasterizer - no custom sculpting algorithm was needed, only (a) these bits
  were never set on `ControlPoint`s at all (only `Segment`s, and only from
  one of three creation call sites - `ConnectControlPointsWithSegment`'s own
  doc comment already flagged this pre-existing gap), and (b) nothing ever
  called `RequestSplineLayerUpdate()` to trigger a recompute.
- `ULandscapeSplinesComponent::RequestSplineLayerUpdate()` is declared
  without `LANDSCAPE_API` (not exported from the Landscape module DLL) -
  confirmed by a real link error (`LNK2019`) on first build attempt. Its own
  engine-source body just forwards to `SplineOwner->GetLandscapeInfo()->
  RequestSplineLayerUpdate()`; `ALandscape::RequestSplineLayerUpdate()` (and
  `ULandscapeInfo`'s) IS exported. Fixed by calling `Landscape->
  RequestSplineLayerUpdate()` directly everywhere (the `ALandscape*` was
  already in scope at 3 of 4 call sites; the 4th, `OnLandscapeSplineObjectTransacted`,
  resolves it via `Cast<ALandscape>(SplinesComponent->GetOwner())`, since
  `GetOrCreateLandscapeSplinesComponent` creates the spline component
  directly on the Landscape actor via `Landscape->CreateSplineComponent()`).
- `RequestSplineLayerUpdate()` only sets a deferred `bSplineLayerUpdateRequested`
  flag (`LandscapeEditLayers.cpp`), consumed once per Editor Tick - safe to
  call unconditionally/liberally, no debounce needed.
- `OnLandscapeSplineObjectTransacted` fires on transaction commit (mouse-up),
  not per-frame during a drag - confirmed by this function's own pre-existing
  doc comment on why `OnObjectTransacted` (not `OnObjectPropertyChanged`) was
  chosen. This matches the engine's own convention: `ULandscapeSplineControlPoint::
  PostEditChangeProperty` only calls `RequestSplineLayerUpdate()` when
  `PropertyChangedEvent.ChangeType == ValueSet`, explicitly excluding
  `Interactive` (live-drag) events.
- `ResolveGenerationSettings(CityId)` (City's `LayoutSettingsOverride` -> the
  current Layout asset's `GenerationSettings` -> `nullptr`) was already the
  existing "Global Default" concept in this codebase - reused as the terminal
  level instead of inventing a second global-settings mechanism.
- No enum-based tri-state pattern exists anywhere in this codebase - every
  `-1`-convention override (`LaneWidth`, `SpeedLimit`, etc.) is a raw numeric
  UPROPERTY. Followed that convention rather than introducing a new enum
  type, for consistency (confirmed via `feedback_negative_one_means_global_default`
  memory and direct source reading of `NexusHighway.h`).

## Changes

**Schema** - `int32 AutoAdjustLandscape = -1;` (with `ClampMin/Max = "-1"/"1"`
UI meta) added identically to `FNexusState`, `FNexusCity`, `FNexusHighway`,
`FNexusRoadPoint` (`Public/Schema/Editor/*.h`). Plus a new terminal Global
level: `UNexusGenerationSettings::bAutoAdjustLandscapeByDefault = true;`
(plain bool, `NexusGenerationSettings.h`). "Segment" and "Point" are the same
concept in V5's schema (no standalone Segment struct) - the override is one
value per Point (not split into incoming/outgoing like `OutgoingTangentLen`/
`IncomingTangentLen`), per the user's own explicit simplification request. A
segment's own effective value is the AND of both its endpoint points'
resolved values.

**Resolver** - new `UNexusFrameworkEditorSubsystem::ResolveAutoAdjustLandscape
(const FNexusHighway& Highway, const FNexusRoadPoint* Point = nullptr) const`,
declared/defined next to `ResolveHighwayMeshSet` (same shape/chain pattern:
Highway -> City -> State -> editor-level fallback). Walks Point -> Highway ->
City -> State -> `ResolveGenerationSettings`'s `bAutoAdjustLandscapeByDefault`
-> `true`, returning the first explicit `0`/`1` found (`>= 0`), most-specific
first.

**Wiring** - `CreateControlPointOnLandscape` gained two new trailing
`bRaiseTerrain`/`bLowerTerrain` bool params (default `true, true`, preserving
prior behavior), now actually setting `ControlPoint->bRaiseTerrain/bLowerTerrain`
(previously never set at all - closed gap). `ConnectControlPointsWithSegment`
needed no signature change (already accepted these params). All three
creation call sites now resolve+pass the real effective value:
- `PlacePointOnLandscape` (Draw Point) - resolves the new point (nullptr
  Point, since its `FNexusRoadPoint` doesn't exist yet - guaranteed `-1`
  default, so equivalent) and, for the connecting segment, ANDs with the
  previous point's own resolved value. Also fixed the same pre-existing gap
  `ConnectControlPointsWithSegment`'s own doc comment flagged: this call site
  previously passed no override args at all, silently using hardcoded
  `true/true/None` instead of the highway's real fields.
- `GenerateCityInternalGrid` (Generate Random City) - resolves each row's OWN
  `FNexusHighway` (not just row 0's, which only `MeshSet` was simplified to
  reuse) since each grid row is a distinct highway object. Stamps each
  point's `ControlPoint->bRaiseTerrain/bLowerTerrain` retroactively right
  after the point exists (mesh/creation still happens before the Nexus point
  struct does, same ordering as before). Horizontal and vertical segment
  connections each resolve the AND of their two real endpoints, including
  correctly resolving the "point above" against ITS OWN row's highway, not
  the current row's.
- `MaterializeMissingPointGeometry` (Load Layout) - resolves per-point at
  control-point creation and per-pair at segment connection (both the normal
  consecutive-pair path and the closed-loop closing-connection path).
  Deliberately did NOT touch the classification pass right after it
  (`RecomputePointClassification(..., bRestoreSavedRotation=true)`) - out of
  scope, per the plan's explicit non-goal.
- `OnLandscapeSplineObjectTransacted` (native viewport move) - added a
  `bAnyGeometryChange` flag set by either the existing Location-changed or
  Rotation-changed branch, firing one `RequestSplineLayerUpdate()` (via the
  resolved owning `ALandscape`) after both checks, once per transacted
  commit. Same treatment added to the segment TangentLen-changed branch
  (dragging a tangent handle without moving the point itself also reshapes
  the terrain footprint). Neither branch re-resolves `AutoAdjustLandscape` -
  a move doesn't change the override, only the position/rotation it already
  has `bRaiseTerrain`/`bLowerTerrain` set from.
- Every one of the 3 creation call sites' final `RequestSplineLayerUpdate()`
  call is **unconditional**, never gated on the resolved value - a highway
  toggled ON->OFF still needs one more pass to *retract* previously-applied
  deformation, not just skip applying new deformation.

**UI**:
- Details panel needed **zero new code** - `SNexusFrameworkDetailsPanel::
  RefreshDetailsPanel()` already wraps whichever struct in a plain
  `FStructOnScope` fed to a native `IStructureDetailsView`; the new
  `UPROPERTY(EditAnywhere, ...)` field shows up automatically for all 4
  entity kinds (Point's Details-panel case already existed from a prior
  session, no longer a gap).
- Context menu (`SNexusFrameworkPanel.cpp`) - extended the existing shared
  Name/Code `switch` blocks (pre-fill in `OnTreeContextMenuOpening`, write-back
  in `OnContextMenuSaveClicked`) with one line each for `AutoAdjustLandscape`,
  and added a new 3-button row ("Inherit"/"Off"/"On" - explicit labels
  showing the tri-state meaning directly) reusing the existing `BuildToolButton`
  idiom (no new Slate widget type introduced - zero precedent for e.g.
  `SSegmentedControl` anywhere in this codebase). New `ContextMenuAutoAdjustLandscapeValue`
  member (`SNexusFrameworkPanel.h`) holds the pending value between button
  clicks and Save, same deferred-write timing as the existing Name/Code text
  boxes. 3 setter handlers + 3 button-type getters (drive live highlighting
  via `TAttribute`) added near the existing `OnContextMenuCancelClicked`.

## Build

`Build.bat NexusFrameworkEditor Win64 Development -project=... -waitmutex -NoHotReloadFromIDE`
- First attempt: `C4456` (variable shadowing - my new outer `PreviousPoint`
  in `PlacePointOnLandscape` collided with a pre-existing inner-scope
  `PreviousPoint` a few lines later in the same function). Fixed by renaming
  my new variable to `LastHighwayPoint`, leaving the pre-existing inner one
  untouched.
- Second attempt: `LNK2019` unresolved external
  `ULandscapeSplinesComponent::RequestSplineLayerUpdate` - not
  `LANDSCAPE_API`-exported. Fixed by routing every call through the owning
  `ALandscape`'s own exported `RequestSplineLayerUpdate()` instead (see
  Findings above).
- Third attempt: **Result: Succeeded**, 0 errors.

## Verification

Not yet performed by the agent - see [[user-builds-and-verifies]]. Hand-off:
1. Set a Highway's `AutoAdjustLandscape` to `1` (via Details panel, then
   separately via the right-click "Inherit"/"Off"/"On" row), Draw Point along
   it, confirm terrain visibly grades to meet the road.
2. Set a different Highway to `0`, Draw Point, confirm terrain is untouched.
3. Leave a Point at `-1` (inherit) on an Off Highway, override that one Point
   to `1`, confirm only that point/its segments deform (the "bridge starts
   here" case).
4. Drag-move an existing point in the viewport, confirm terrain re-grades
   after release, not during the drag.
5. Toggle a Highway from On to Off and move a point on it, confirm
   previously-applied deformation actually retracts.
6. Ctrl+Z after a Draw Point / move - confirm both the Nexus-side data and
   the terrain height revert together (relies entirely on the engine's own
   Landscape Edit Layers undo system plus this codebase's existing
   `Modify()`/`FScopedTransaction` usage - no new undo handling was added).
7. Re-verify Save/Load rotation fidelity and random-city junction rotation
   still hold - neither code path was touched, but both share this file.

## Result

Feature implemented across schema (4 structs + global settings), a new
most-specific-wins resolver mirroring `ResolveHighwayMeshSet`'s existing
shape, all 3 geometry-creation call sites plus the native-move handler, and
both required UI surfaces - reusing 100% engine-native terrain-deformation
machinery (no custom heightmap code) and the codebase's existing raw-int
`-1`/`0`/`>0` override convention throughout. Build-verified, 0 errors.

## Important Notes

- Re-applying the override retroactively to already-materialized geometry
  (e.g. via the existing "Apply Configuration" button) is a **known,
  deliberately out-of-scope gap** - editing the override on an already-built
  highway takes effect on next create/move/Load, not immediately. Flagged in
  the approved plan as a possible fast-follow, not implemented here.
- A point/segment created directly via the native Landscape Splines tool
  (not through Nexus's own Draw Point/Generate) never gets
  `ResolveAutoAdjustLandscape` applied - out of scope, flagged as a likely
  follow-up in the approved plan.
