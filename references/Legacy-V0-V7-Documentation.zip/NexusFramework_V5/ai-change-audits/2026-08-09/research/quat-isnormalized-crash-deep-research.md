# RESEARCH REPORT: Q.IsNormalized() Crash — Deep Engine-Source Investigation

Date: 2026-08-09
Category: research
Status: **Research only — no code changed.** Companion to
[[quat-not-normalized-crash-on-load]] (the live bug-fixed thread with prior
diagnostics/build history) — this file is the deep-dive engine-source
investigation requested to hand off to a fresh agent. Read that file first
for prior-session context (diagnostics already added, mesh-offset ruled
out, etc.) before acting on this one.

## 0. HEADLINE FINDING — read this first

**A real crash dump from THIS exact bug already exists on disk and was
analyzed directly** (not hypothetical):
`Saved/Crashes/UECC-Windows-BC25F56041DC289505CFEA8EF5EF83C2_0000/`
(2026-08-09 04:08:34 UTC / 09:53 local). It proves, with real captured
values, that **every rotation Nexus itself wrote or observed immediately
before the crash was already valid and normalized** (`RawRotationContainsNaN=0`,
`RawQuatIsNormalized=1`, `NewQuatIsNormalized=1` on every line). The crash
happens **entirely inside engine code, with zero further Nexus log output**,
in the ~32ms immediately after the last `OnLandscapeSplineObjectTransacted`
callback for 3 T-junction points. This is FACT, not inference — see §1.

Cross-referencing that timing against direct UE 5.8 engine source reading
(§2-§4) identified a **mathematically provable mechanism** by which the
engine's own spline-tessellation code can construct a genuinely
non-normalized `FQuat` from perfectly valid, finite input — via an
undocumented "axis must already be unit-length" assumption in
`FQuat(FVector Axis, float AngleRad)` that a neighboring "safe" function
(`GetSafeNormal()`) can silently violate. This is the strongest lead found
(P0, see §10) — not yet 100% proven to be THE trigger (the exact last hop
into `FQuatRotationTranslationMatrix` is unconfirmed), but a real,
source-verified engine weak point sitting exactly in the code path that
runs whenever a junction's rotation changes.

## 1. FACT CONFIRMED — real crash evidence (read directly, not paraphrased)

Project already has ~30+ crash folders under `Saved/Crashes/` accumulated
this session (Landscape Splines interaction with UE 5.8 editor is evidently
crash-prone in this environment generally). The MOST RECENT one at time of
this research:

- **Folder**: `Saved/Crashes/UECC-Windows-BC25F56041DC289505CFEA8EF5EF83C2_0000/`
- **Contents**: `CrashContext.runtime-xml` (206KB), `NexusFramework.log`
  (426KB, full log up to the crash — **the project's log file survives the
  crash on disk**, contrary to the user's worry about not being able to
  copy the Output Log widget in time), `UEMinidump.dmp` (2MB, full minidump
  with debug symbols available — `IsWithDebugInfo=true` in the XML),
  `CrashReportClient.ini`.
- **Confirmed identical crash**: `ErrorMessage` = `Assertion failed:
  Q.IsNormalized() [File:...QuatRotationTranslationMatrix.h] [Line: 81]`.
  `EngineVersion=5.8.1-56057345`.
- **Module-level CallStack** (from `CrashContext.runtime-xml`, top = innermost):
  ```
  UnrealEditor_Core            (the assert itself)
  UnrealEditor_LandscapeEditor x3
  UnrealEditor_UnrealEd        x11
  UnrealEditor_Renderer        x5   <-- important, see below
  UnrealEditor_UnrealEd        x1
  UnrealEditor_Engine          x1
  UnrealEditor_UnrealEd        x3
  UnrealEditor (main exe)      x6
  kernel32 / ntdll
  ```
  No function names in this summary (module-only) — the `.dmp` has full
  symbol info and was NOT further decoded in this pass (see TODO 1).
  **The presence of `UnrealEditor_Renderer` frames sandwiched between two
  `UnrealEd` blocks is a strong signal this happens during scene-proxy /
  render-state creation for a component** (e.g. a
  `CreateSceneProxy()`/`GetRenderMatrix()`-style call triggered by a
  component re-register), not during pure gameplay-thread spline math.

- **The exact log tail before the crash** (`NexusFramework.log` lines
  3250-3279, reproduced verbatim, timestamps included):
  ```
  [04:08:34:386] 13x [NEXUS ROTATION WRITE] Source=RecomputePointClassification ...
     (all 13 points, all NewRotation values small/clean, Pitch/Roll ~0.000000-0.000003, no NaN)
  [04:08:34:386-388] 5x LogActorComponent: UnregisterComponent: (...ControlPointMeshComponent_10..14) Not registered. Aborting.
  [04:08:34:650] [NEXUS ROTATION WRITE] Point=2090ED89... Source=OnLandscapeSplineObjectTransacted Reason=NativeLandscapeEdit
     RawRotationContainsNaN=0 RawQuatIsNormalized=1 NewQuatIsNormalized=1
  [04:08:34:650] [NEXUS ROTATION WRITE] Point=4BEF66A3... Source=OnLandscapeSplineObjectTransacted Reason=NativeLandscapeEdit
     RawRotationContainsNaN=0 RawQuatIsNormalized=1 NewQuatIsNormalized=1
  [04:08:34:650] [NEXUS ROTATION WRITE] Point=7B3E317E... Source=OnLandscapeSplineObjectTransacted Reason=NativeLandscapeEdit
     RawRotationContainsNaN=0 RawQuatIsNormalized=1 NewQuatIsNormalized=1
  [04:08:34:670] LogOutputDevice: Warning: Script Stack (0 frames)      <- crash handler starting
  [04:08:34:682] LogWindows: Error: appError called: Assertion failed: Q.IsNormalized() ...
  ```
  **Zero Nexus log lines between the last valid rotation observation
  (`:650`) and the crash handler starting (`:670`) - a 20ms gap with no
  Nexus code executing at all.**

### What this FACT proves

- **Case D confirmed, cases A/B/C eliminated for this specific crash
  instance**: per the user's own A/B/C/D classification
  (`ai-change-audits/bug-fixed/2026-08-09/quat-not-normalized-crash-on-load.md`),
  this is **D — entirely inside LandscapeEditor, after Nexus had already
  written/observed a PROVABLY valid rotation.** Nexus is not corrupting
  anything; whatever goes wrong happens purely in engine code triggered
  by the transaction closing.
- All 3 points that got the native-edit callback
  (`2090ED89`/`4BEF66A3`/`7B3E317E`) have `ConnectionCount=3` (confirmed
  from their own `RecomputePointClassification` lines a moment earlier) -
  **all three are T-junctions**, directly matching the user's own
  observation ("especially at junctions").
- The `[Nexus MapTrace] ... MapMatch: NO -> resolves fine 1ms later`
  pattern visible in the log (e.g. point `85B39566` at 3152-3157) is the
  **already-understood, already-guarded** `TSoftObjectPtr` stale-weak-
  pointer-resolves-to-transient-object behavior from
  [[cross-map-sourcepoint-bug]] - confirmed working as designed here
  (falls through to "re-materializing fresh"), NOT a new lead. Don't
  re-investigate this pattern; it's solved.
- The 5x `ControlPointMeshComponent_10..14 Not registered. Aborting.`
  messages are **confirmed harmless** (see §3) - standard
  `UActorComponent::UnregisterComponent()` early-out log
  (`ActorComponent.cpp:2130-2133`) for a component that was never
  registered yet (freshly `NewObject`'d this pass). Not evidence of
  lifecycle corruption.

## 2. FACT CONFIRMED — the exact unnormalized-quaternion construction found in engine source

Read `Quat.h:912` (UE 5.8) directly:
```cpp
template<typename T>
inline TQuat<T>::TQuat(TVector<T> Axis, T AngleRad)
{
    const T half_a = 0.5f * AngleRad;
    T s, c;
    FMath::SinCos(&s, &c, half_a);
    X = s * Axis.X;  Y = s * Axis.Y;  Z = s * Axis.Z;  W = c;
    DiagnosticCheckNaN();
}
```
**This constructor does NOT validate or normalize `Axis`.** If `|Axis| = k
≠ 1`, the result has `SizeSquared = s²k² + c² ≠ 1` for any `k ≠ 1`. Unlike
`FRotator::Quaternion()` (`UnrealMath.cpp:468-476`, which explicitly checks
`ContainsNaN()` and falls back to `Identity`) and unlike
`TQuat(const TMatrix&)` + `FTransform::SetFromMatrix` (which BOTH has its
own zero-axis guard at `Quat.h:780` AND gets an unconditional
`VectorNormalizeQuaternion()` re-normalize afterward at
`TransformVectorized.h:1296`), **this axis-angle constructor has zero
defensive fallback anywhere in the call chain that uses it.**

### Where this constructor is actually used (grep'd across the whole Landscape module)

Exactly 4 call sites, ALL structurally identical:
```cpp
FQuat(Tangent, -Roll).RotateVector((Tangent ^ FVector(0, 0, -1)).GetSafeNormal())
```
- `LandscapeSplines.cpp:2538` — `ULandscapeSplineControlPoint::UpdateSplinePoints`,
  Mesh-having branch, building the `Points` interp array.
- `LandscapeSplines.cpp:2564` — same function, no-Mesh branch.
- `LandscapeSplineRaster.cpp:1082` — `Pointify()`, first/key sample point.
- `LandscapeSplineRaster.cpp:1114` — `Pointify()`, interior subdivision
  points (this is the one evaluated MANY times per segment,
  `NumSubdivisions`-many, for the actual tessellated road-mesh placement).

**In all 4 cases, `Tangent`/`NewKeyTangent` is produced via
`.GetSafeNormal()`** — either `StartRotation.Vector()` (control-point case,
already proven exactly unit-length for any finite Rotation, see prior
session's investigation) or, critically, in `Pointify()`:
```cpp
const FVector NewKeyTangent = SplineInfo.EvalDerivative(NewKeyTime, FVector::ZeroVector).GetSafeNormal();
```
`GetSafeNormal()` is EXPLICITLY DESIGNED to return `FVector::ZeroVector`
(not NaN/Inf) when the input vector's length is at/near zero — a documented,
intentional safety behavior. **But feeding that "safe" zero vector into the
unguarded `FQuat(Axis, Angle)` constructor produces `X=Y=Z=0, W=cos(Angle/2)`
— a quaternion whose `SizeSquared = cos²(Angle/2)`, which is LESS than 1 for
any `Angle` that isn't an exact multiple of 360°.** This is not floating-point
drift — it's a deterministic, mathematically exact violation of
`IsNormalized()` whenever the spline derivative legitimately reaches zero.

### When can `EvalDerivative` legitimately be (near) zero?

`SplineInfo` is a cubic Hermite curve (`FInterpCurveVector`, `CIM_CurveUser`)
built directly from Nexus/Landscape data
(`LandscapeSplines.cpp:3112-3117`, `ULandscapeSplineSegment::UpdateSplinePoints`):
```cpp
SplineInfo.Points.Emplace(0.0f, StartLocation, StartRotation.Vector() * Connections[0].TangentLen, ..., CIM_CurveUser);
SplineInfo.Points.Emplace(1.0f, EndLocation,   EndRotation.Vector()   * -Connections[1].TangentLen, ..., CIM_CurveUser);
```
A cubic Hermite curve's derivative is a quadratic polynomial in the
curve parameter `t`; it has a **real root in `[0,1]` (a literal cusp/reversal
in the curve's velocity) for a well-known, common class of tangent
configurations** — specifically when the two endpoint tangent vectors
(`Rotation.Vector() * TangentLen`) point in sufficiently different/opposed
directions relative to the chord between the two points. This is EXACTLY
what changing a junction's `Rotation` does: `Rotation` **is** the tangent
direction for every segment through that control point (established fact
from prior sessions), so a manual rotation edit at a junction directly
reshapes this Hermite curve's tangent vectors — a plausible, ordinary way to
create (or remove) a zero-derivative point without needing any bug in
Nexus's own math.

**This is a STRONG INFERENCE, not yet fully proven**: the exact real crash
log (§1) shows the crash happening right after editing 3 T-junctions'
rotations, which is consistent with this mechanism, but the precise
segment/subdivision-index where `EvalDerivative` actually hit zero was not
(and, without a debugger session, cannot currently be) confirmed from static
analysis alone.

## 3. FACT CONFIRMED — "ControlPointMeshComponent ... Not registered. Aborting." is harmless

Read `ActorComponent.cpp:2124-2134` directly:
```cpp
void UActorComponent::UnregisterComponent()
{
    if(!IsRegistered())
    {
        UE_LOGF(LogActorComponent, Log, "UnregisterComponent: (%ls) Not registered. Aborting.", *GetPathName());
        return;
    }
    ...
}
```
This is the STANDARD, universal early-out log for calling
`UnregisterComponent()` on a component that isn't currently registered — a
complete no-op, not an error. `ULandscapeSplineControlPoint::UpdateSplinePoints`
(`LandscapeSplines.cpp:2309, 2361`) calls `MeshComponent->UnregisterComponent()`
defensively before certain mesh-swap operations, then re-registers via
`RegisterComponent()` later in the same function if
`bComponentNeedsRegistering` (line 2483-2486). For a component that was
JUST created this same call via `NewObject<UControlPointMeshComponent>`
(line 2290) — i.e. every freshly-materialized junction point, exactly
Nexus's `MaterializeMissingPointGeometry` scenario — it has never been
registered yet, so this call is a guaranteed, expected, harmless no-op.
**Confirmed NOT evidence of broken lifecycle state, no double-unregister
found, no stale-pointer mechanism found here.**

## 4. FACT CONFIRMED — `FTransform`'s basis-vector constructor is doubly defended (ruled OUT)

`USplineMeshComponent::CalcSliceTransform`/`CalcSliceTransformAtSplineOffset`
(`SplineMeshSceneProxyDesc.cpp:667-682, 89-159`) — the function that
orients each spline-mesh instance along a segment — builds:
```cpp
SliceTransform = FTransform(FVector(SplineDir), FVector(XVec), FVector(YVec), FVector(SplinePos));
```
using the `FTransform(InX, InY, InZ, InTranslation)` constructor
(`TransformVectorized.h:280-284`), which calls `SetFromMatrix()`
(`TransformVectorized.h:1273-1297`). Traced this fully: it (a) extracts
scale via `ExtractScaling`, (b) builds a quaternion via `TQuat(Matrix)`
which ITSELF has a zero-axis guard falling back to `Identity`
(`Quat.h:780-793`), AND (c) unconditionally re-normalizes via
`VectorNormalizeQuaternion()` afterward. **Even a fully-degenerate
all-zero basis (which would happen if `SplineDir` were also zero here)
cannot produce a non-normalized result through this path.** Ruled out as a
candidate — this was a plausible-looking secondary lead that direct source
reading eliminated with certainty.

## 5. Landscape spline save/lifecycle functions — traced

All in `LandscapeSplines.cpp` (not a separate `LandscapeSplinesComponent.cpp`
as the file layout might suggest):

| Function | Line | What it does | Runs during |
|---|---|---|---|
| `CheckSplinesValid()` | 538 | `ensureMsgf` validation only (removes null entries, checks outer consistency) - does NOT touch rotation/quaternion math | `OnRegister`, `PostLoad`, `PreSave`, `PostEditUndo`, `CreateSceneProxy` |
| `OnRegister()` | 580 | Calls `CheckSplinesValid()` then `Super::OnRegister()` | Component (re)registration - map load, PIE, explicit register/unregister cycles |
| `Serialize()` | 677 | Foreign-mesh-component bookkeeping only for non-persistent archives; no rotation math | Save/load package serialization |
| `PostLoad()` | 1126 | Rebuilds `MeshComponentForeignOwnersMap`, calls `CheckSplinesValid()` | After package load |
| `PreSave()` | 1158 | **Only** calls `CheckSplinesValid()` - does NOT rebuild/retessellate anything | Immediately before `SavePackage` |
| `PostEditChangeProperty()` | 1167 | Calls `RebuildAllSplines(bUpdateCollision)` **unless** `bHackIsUndoingSplines` is set | Any property-editor-driven change to the SplinesComponent itself (not necessarily individual control points/segments) |
| `PostEditUndo()` | 1180 | Sets `bHackIsUndoingSplines=true`, calls `Super::PostEditUndo()`, `CheckSplinesValid()`, `MarkRenderStateDirty()` - explicitly SKIPS `RebuildAllSplines` during undo | Undo/Redo of a transacted change |
| `RebuildAllSplines()` | 1191 | `ControlPoint->UpdateSplinePoints(true,false)` for every point + `Segment->UpdateSplinePoints(true)` for every segment - **this is where the `Pointify`/`FQuat(Axis,Angle)` code (§2) actually executes** | Called explicitly by Nexus (`MaterializeMissingPointGeometry`, `ApplyHighwayConfiguration`) AND automatically by `PostEditChangeProperty` |
| `AutoFixMeshComponentErrors()` | 747 | Cross-level/streaming foreign-mesh reconciliation - calls `ControlPoint->UpdateSplinePoints`/`Segment->UpdateSplinePoints` too, but only for **foreign-world** meshes (cross-streaming-level) | Streaming level load/unload interactions - **almost certainly NOT relevant** to this project (single non-streaming map, `LV0_Development_Debug2`) |
| `DestroyUnreferencedForeignMeshComponents`/`DestroyOrphanedForeignControlPointMeshComponents`/`RemoveForeignMeshComponent` | 1569, 1677, 1405/1493 | All exclusively handle **foreign** (cross-streaming-level) mesh components | Same as above — **not read in full detail this pass; P2 priority, likely irrelevant given this project has no streaming sub-levels involved in the crash** |

**Key inference**: `PreSave` itself does nothing risky (just validation).
The actual tessellation/rebuild that could hit the §2 mechanism is
`RebuildAllSplines()`, called both by Nexus directly AND automatically by
the native `PostEditChangeProperty()` — meaning **a plain native rotation
edit through the Landscape Splines tool can trigger this same rebuild path
independently of anything Nexus calls**, consistent with the real crash log
(§1) showing the crash immediately after `OnLandscapeSplineObjectTransacted`
(a native edit notification) with no further Nexus code running.

## 6. `ControlPointMeshComponent` ownership/lifecycle — answered

- **Created by**: `ULandscapeSplineControlPoint::UpdateSplinePoints()`
  (`LandscapeSplines.cpp:2290`), `NewObject<UControlPointMeshComponent>`,
  only when `Mesh != nullptr` and no existing component is found.
- **Owned by**: the mesh component's outer is the Landscape actor
  (`MeshComponentOuterActor`); tracked via
  `ULandscapeSplinesComponent::MeshComponentLocalOwnersMap` (component ->
  owning control point) for same-level meshes, or
  `AddForeignMeshComponent`/`ForeignWorldSplineDataMap` for cross-level ones.
- **Registered/unregistered by**: the SAME function, defensively, as part
  of every property-sync pass (§3) - this is NORMAL, expected, per-call
  bookkeeping, not a sign of external interference.
- **Can Nexus cause double-unregister or stale pointers?** No mechanism
  found. Nexus never directly touches `LocalMeshComponent`/`ControlPoints`
  arrays or calls `UnregisterComponent`/`RegisterComponent` itself anywhere
  in `NexusFrameworkEditorSubsystem.cpp` (confirmed via grep - Nexus only
  ever calls `RebuildAllSplines()`/`UpdateSplinePoints()`-adjacent
  higher-level engine APIs, never manipulates component registration
  directly).
- **Conclusion**: this entire line of investigation (§3 finding + this
  section) is now **RULED OUT** as a contributing cause - normal, defended,
  expected lifecycle.

## 7. `SavedSourcePointPath` / `TSoftObjectPtr` stability — answered from established project precedent

This project's OWN prior investigation (this session, `LinkPointToControlPoint`'s
doc comment, [[cross-map-sourcepoint-bug]]) already established, and the
real crash log (§1) reconfirms: `ULandscapeSplineControlPoint` objects are
explicitly renamed to `"NexusPoint_<guid>"` specifically to make their
`FSoftObjectPath` stable and predictable across save/load. This path IS
stable AS LONG AS the object (a) stays alive (persistent, not orphaned to
the transient package) and (b) isn't renamed again. The KNOWN, ALREADY-
GUARDED failure mode is `TSoftObjectPtr::LoadSynchronous()`'s cached weak
pointer resolving to a STALE, wipe-orphaned-but-still-alive object from a
PREVIOUS session's geometry (engine's `DeleteSplinePoints()` only
`Rename(nullptr, GetTransientPackage())`s, never destroys) - guarded via
`IsControlPointOnTargetLandscape`, confirmed working correctly in the real
log (§1, point `85B39566`'s `MapMatch: NO -> re-materializing fresh`
sequence). **This is a debugging/reference hint that Nexus has correctly
hardened against, not an open risk** - do not re-investigate this pattern
unless NEW evidence contradicts the guard's effectiveness.

## 8. `AutoCalcRotation` indirect side effects — answered

Already established in the prior session (do not repeat: neighbor-Rotation
is fetched but unused in the direction math). New for this pass:
`AutoCalcRotation()` itself does **not** call `UpdateSplinePoints()` or
trigger any rebuild - it purely sets `this->Rotation`. The actual
tessellation/mesh update is a SEPARATE call the CALLER makes afterward
(`LandscapeEdModeSplineTools.cpp`'s own calls always pair
`AutoCalcRotation()` immediately with `->UpdateSplinePoints()`; Nexus's
`RecomputePointClassification` does NOT call `UpdateSplinePoints()` itself
- it relies on the caller's later `SplinesComponent->RebuildAllSplines()`
call, e.g. in `MaterializeMissingPointGeometry`/`ApplyHighwayConfiguration`).
**This means there IS a real gap between "Rotation changed" and "geometry
actually rebuilt with the new Rotation" in Nexus's own flow** - not proven
to matter for THIS crash, but worth the next agent confirming there's no
window where a segment briefly has inconsistent tangent data mid-batch.

## 9. Native edit vs Nexus edit — key behavioral difference found

- **Native edit** (`LandscapeEdModeSplineTools.cpp`): calls
  `ControlPoint->AutoCalcRotation(bAlwaysRotateForward)` **with
  `bAlwaysRotateForward` defaulting to `false`** (confirmed prior session),
  immediately followed by `->UpdateSplinePoints()` on the SAME control
  point (and sometimes the segment) in the SAME function call - a tight,
  synchronous pairing.
- **Nexus edit** (`RecomputePointClassification`): always passes
  `bAlwaysRotateForward=true` (forcing the full-Slerp-overwrite 2-connection
  branch, or the iterative branch for 3+/1-connection points - see prior
  session), and does NOT call `UpdateSplinePoints()` itself - relies on a
  LATER, separate `RebuildAllSplines()` call (which updates EVERY point/
  segment in the whole SplinesComponent, not just the one just changed).
- **Neither difference has been shown to be UNSAFE** - both eventually
  reach the same `UpdateSplinePoints()`/`Pointify()` code (§2/§5). The
  `bAlwaysRotateForward=true` vs `false` difference changes WHICH rotation
  value results (already established, not re-litigated here), which in
  turn changes the Hermite tangent vectors fed to `Pointify` - i.e. Nexus's
  own choice to force `true` unconditionally is a plausible amplifying
  factor for hitting the §2 mechanism more often than vanilla native
  editing would (since native editing defaults to the gentler iterative
  nudge), but this is UNPROVEN, not confirmed via a controlled experiment.

## 10. RANKED HYPOTHESIS LIST

### P0 — `GetSafeNormal()` -> unguarded `FQuat(Axis, Angle)` in spline tessellation
- **Evidence for**: Source-confirmed the constructor has no normalization/
  guard (§2, FACT). Source-confirmed `GetSafeNormal()` can legitimately
  return `ZeroVector` for a near-zero derivative (standard, documented UE
  behavior). Source-confirmed the resulting `SizeSquared = cos²(Angle/2)`
  is mathematically `< 1` whenever `Axis=Zero` and `Angle` isn't a multiple
  of 360° (exact arithmetic, not floating-point drift). Source-confirmed
  this sits directly inside `Pointify()`/`UpdateSplinePoints()`, which is
  exactly the code that runs on every `RebuildAllSplines()` — both Nexus's
  own calls AND the native `PostEditChangeProperty` auto-rebuild. Real
  crash log (§1) shows the crash happening immediately after a native
  rotation edit on 3 T-junctions, with zero Nexus code executing in
  between — consistent with an engine-internal rebuild triggering this.
- **Evidence against**: The specific quaternion this constructor produces
  (`NewKeyBiNormal`'s basis) is, in the 2 `LandscapeSplineRaster.cpp` call
  sites, only used via `.RotateVector(...)` to compute plain `FVector`
  positions (`NewKeyLeftPos` etc.) — NOT stored/reused directly as a
  component transform's rotation. The EXACT final hop from this vector
  math into a `FQuatRotationTranslationMatrix` construction has NOT been
  traced to a single confirmed line.
- **Engine source to inspect**: `Quat.h:912` (constructor),
  `LandscapeSplineRaster.cpp:1050-1130` (`Pointify`),
  `LandscapeSplines.cpp:2520-2570` (`Points` array build),
  `LandscapeSplines.cpp:3096-3151` (`ULandscapeSplineSegment::UpdateSplinePoints`,
  the Hermite tangent setup that feeds `Pointify`). Also check
  `FInterpCurveVector::EvalDerivative`/`Eval` (`Curves`/`InterpCurve.h` or
  similar) for the exact Hermite derivative formula, to confirm when it can
  reach exactly zero for realistic tangent-length/direction combos.
- **Exact experiment**: reproduce the user's isolated repro (plain highway,
  mesh offset=0, rotate a T-junction control point manually, apply) with a
  DEBUGGER attached (or via the `.dmp`, see TODO 1), set a conditional
  breakpoint in `Quat.h:912`'s constructor for `Axis.IsNearlyZero()`, see if
  it fires during `RebuildAllSplines`/`Pointify` right before the crash.
- **Confirms if**: breakpoint fires with `Axis≈(0,0,0)` and `AngleRad` not
  a multiple of 2π, immediately preceding the assert.
- **Eliminates if**: breakpoint never fires during the repro, or fires but
  the resulting quaternion never reaches anything that constructs a
  `FQuatRotationTranslationMatrix`.

### P1 — Component re-registration during `RebuildAllSplines`/`PostEditChangeProperty` pushes a bad transform into `CreateSceneProxy`
- **Evidence for**: Real crash module-stack (§1) shows `Renderer` frames
  sandwiched inside `UnrealEd` frames — consistent with a scene-proxy/
  render-state creation happening mid-editor-operation. `UpdateSplinePoints`
  unregisters+re-registers mesh components (§3/§6) as part of the same
  rebuild pass that computes the (potentially corrupted, per P0) `Points`
  array.
- **Evidence against**: `ControlPointMeshComponent`'s own transform-setting
  code (`SetRelativeTransform(FTransform(MeshRotation, MeshLocation,
  MeshScale))`, line 2354) uses the FRotator-constructor path, confirmed
  SAFE (routes through `.Quaternion()`'s NaN-defensive fallback) —
  `MeshRotation = Rotation` is the raw control-point field, already proven
  valid at write time (§1). This specific transform write is not obviously
  the culprit on its own.
- **Engine source to inspect**: `UPrimitiveComponent::CreateSceneProxy`
  overrides for `UStaticMeshComponent`/`UControlPointMeshComponent`/
  `USplineMeshComponent`, and whatever calls
  `MarkRenderStateDirty()`/`RecreateRenderState_Concurrent()` synchronously
  during `UpdateSplinePoints`/`RebuildAllSplines`.
- **Exact experiment**: symbolize the `.dmp` (TODO 1) to get real function
  names for the `Renderer`/middle-`UnrealEd` frames — this alone would
  likely settle P0 vs P1 vs a third option definitively without further
  guessing.
- **Confirms/eliminates if**: symbolized stack shows (or doesn't show) a
  `CreateSceneProxy`/`GetRenderMatrix` frame directly calling into
  `FQuatRotationTranslationMatrix`.

### P2 — `AutoFixMeshComponentErrors`/foreign (cross-streaming-level) mesh reconciliation
- **Evidence for**: These functions exist and do call
  `UpdateSplinePoints`/`Segment->UpdateSplinePoints` too (§5).
- **Evidence against**: This project's crashing map (`LV0_Development_Debug2`)
  does not appear to use World Partition/streaming sub-levels for its
  Landscape splines (single `Landscape_1` actor, single
  `LandscapeSplinesComponent_0` throughout the real log). This machinery is
  for CROSS-LEVEL foreign mesh placement specifically.
- **Not investigated further this pass** — low priority unless P0/P1 are
  both eliminated.

### P2 — Bug is purely in stock UE 5.8 Landscape Splines, unrelated to Nexus's specific choices
- **Evidence for**: WebSearch found a UE 5.8-specific forum report ("UE 5.8
  cant control tangents of landscape splines anymore") and historical
  `Q.IsNormalized()` crashes tied to Landscape Splines going back to 4.26
  ("Instant Crash when using splines in 4.26.1") and other unrelated
  systems (Niagara), suggesting quaternion-normalization assumptions in
  spline/transform code are a recurring, cross-version engine weak point,
  not something specific to this plugin.
- **Evidence against**: Doesn't explain why THIS project hits it reliably
  and reproducibly at junctions specifically — some project-specific factor
  (topology, Nexus's `bAlwaysRotateForward=true` choice, or simply "this
  project uses Landscape Splines far more heavily/proceduraly than typical
  hand-authored use") is still needed to explain reproducibility.
- **Useful as context, not as an actionable lead** — if P0 is confirmed,
  this becomes the explanation for WHY it's an engine bug rather than a
  Nexus bug, informing whether the eventual fix is a Nexus-side workaround
  (avoid feeding topology that produces a zero-derivative Hermite segment)
  vs an engine patch/version upgrade.

## 11. RESEARCH TODO for the next agent

**TODO 1 — Symbolize the existing minidump for the REAL function-level stack.**
`Saved/Crashes/UECC-Windows-BC25F56041DC289505CFEA8EF5EF83C2_0000/UEMinidump.dmp`
already exists with debug symbols available (confirmed `IsWithDebugInfo=true`).
Open it in Visual Studio (Debug > Open Dump File > select this .dmp) or
WinDbg, with symbol path including the engine's own PDBs
(`C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\`) — this
requires NO reproduction, no waiting for a new crash, and would likely
answer P0 vs P1 immediately by naming the exact functions in the
`Renderer`/`UnrealEd` frames currently only known by module name. **This
should be the very first action**, cheaper than everything else combined.

**TODO 2 — Check for MORE existing crash folders matching this same signature.**
`Saved/Crashes/` has 30+ folders from this session alone (`ls -t` to sort by
time). Not all inspected this pass — grep each `CrashContext.runtime-xml`
for `Q.IsNormalized` to build a corpus of every instance, then diff their
`NexusFramework.log` tails (like §1's analysis) to see if the SAME
"3 T-junction native edit, then silent 20ms gap, then crash" pattern
repeats, or if there's a DIFFERENT pattern in some instances (e.g. some
triggered by Nexus's own `RecomputePointClassification` rebuild instead of
a native edit) — this would strengthen or complicate the P0 hypothesis.

**TODO 3 — Set a debugger breakpoint in `Quat.h:912`'s axis-angle constructor,
conditioned on `Axis.IsNearlyZero()`, and reproduce interactively.** Requires
a Development editor launched under a debugger (Visual Studio "Debug > Attach
to Process" or launch-with-debugger). Reproduce the user's exact isolated
repro (plain highway, no mesh offset, rotate a T-junction, apply). This is
the single most direct way to CONFIRM (or eliminate) P0 with certainty.

**TODO 4 — Trace `FInterpCurveVector::EvalDerivative`'s exact formula** (
likely `Curves/Public/Curves/CurveOwnerInterface.h` or a Core math header for
`FInterpCurve`) to confirm precisely which tangent-vector configurations
(direction difference angle, TangentLen ratio between the two ends) make the
derivative cross zero within `[0,1]` — would let the next agent (or user)
predict/reproduce the exact junction rotation that triggers it on demand,
rather than relying on incidental discovery.

**TODO 5 — Determine whether Nexus's own `bAlwaysRotateForward=true` choice
measurably increases the rate of zero-derivative segments** vs the native
tool's default `false`. Requires either (a) a controlled A/B repro (same
topology, toggle which code path computes the junction's rotation) or (b)
reading `AutoCalcRotation`'s two branches (`LandscapeSplines.cpp:2094-2180`,
already read in full this session) side-by-side against realistic junction
angles to reason about which produces more "extreme" tangent directions.
This determines whether a SAFE, minimal Nexus-side mitigation exists
(e.g., detecting a would-be zero-derivative segment before committing a
rotation change) without needing an engine-level fix.

**TODO 6 — Confirm whether `RecomputePointClassification` should call
`ControlPoint->UpdateSplinePoints()` immediately after `AutoCalcRotation()`**
(matching the native tool's own tight pairing, §9) instead of relying on a
LATER, separate `RebuildAllSplines()` call — investigate ONLY, do not
implement; determine if the current "changed but not yet rebuilt" window
(§8) could matter for consistency, independent of the P0/P1 crash mechanism.

**TODO 7 — Once P0/P1 is confirmed via TODO 1/3, determine the correct fix
tier**: if it's a genuine stock-engine gap (§10's context hypothesis), the
options are (a) a Nexus-side avoidance — detect/refuse a rotation change
that would create a degenerate segment, with clear user feedback, or
(b) a topology-level fix — insert an intermediate point to break up a
segment whose Hermite curve would otherwise self-intersect its own
tangent. **Do not implement either without explicit user approval** — this
is a research report, not an authorization to change rotation/tangent
architecture.

**TODO 8 — Read `LandscapeSplines.cpp`'s `DestroyUnreferencedForeignMeshComponents`
(1569), `DestroyOrphanedForeignControlPointMeshComponents` (1677), and
`RemoveForeignMeshComponent` (1405/1493) in full** if TODO 1's symbolized
stack points toward foreign/cross-level mesh handling (currently P2/low
priority, not read in full this pass — confirmed the project doesn't appear
to use streaming levels for its Landscape, but this wasn't independently
verified against the actual level setup, only inferred from the log).

## Where crash artifacts are stored (for the next agent, or the user, after ANY future crash)

Confirmed by direct inspection of this project's own `Saved/` folder — UE
5.8, this project's exact configuration:

- **`<ProjectDir>/Saved/Crashes/UECC-Windows-<hash>_NNNN/`** — one folder
  PER CRASH, created automatically, survives editor restart. Contains:
  - `NexusFramework.log` — full copy of the editor log up to the crash
    (confirmed: captures `UE_LOG` output, including this project's own
    `[NEXUS ROTATION WRITE]`/`[NEXUS ROTATION CHECK]` diagnostic lines,
    right up to within ~20ms of the crash). **This alone answers the user's
    "I can't copy the Output Log before it crashes" concern — the log file
    is already being preserved automatically, no extra tooling needed.**
  - `CrashContext.runtime-xml` — structured XML with `ErrorMessage` (the
    assert text), module-level `CallStack`, engine version, and extensive
    machine/session metadata.
  - `UEMinidump.dmp` — full minidump, openable in Visual Studio or WinDbg
    for a fully symbolized stack (TODO 1).
  - `CrashReportClient.ini` — crash reporter's own config, not useful for
    debugging.
- **`<ProjectDir>/Saved/Logs/NexusFramework.log`** — the CURRENT/live
  session's log (gets moved/copied into a timestamped
  `Saved/Logs/NexusFramework-backup-<date>.log` on next editor launch, and
  a copy is placed in the crash folder above at crash time) — same content
  as the crash-folder copy for the session that just ended.
- To find the RIGHT crash folder for a specific incident: sort by
  modification time (`ls -t` / `dir /o-d`) and match against the
  approximate time the user reports the crash happened, or grep every
  `CrashContext.runtime-xml` for the specific `ErrorMessage` text.
- No additional tooling/config changes are needed to get this — it's
  default UE Editor crash-reporting behavior, already working correctly for
  this project.

## Follow-up — 2026-08-09 (session 2): minidump re-walk attempt, PDB gap discovered, new module-level evidence for P1

**Status: still no code changed.** Continuing directly from TODO 1 (symbolize the
existing `.dmp`).

### What was done

1. Installed WinDbg (`winget install Microsoft.WinDbg`) since no debugger
   existed on this machine (`cdb.exe`/`windbg.exe` absent from all standard
   locations, checked exhaustively). WinDbg's `cdb.exe` had to be copied out
   of `C:\Program Files\WindowsApps\...` to a scratch folder to run at all —
   Windows blocks direct execution of MSIX package contents from that path
   for non-packaged callers (`Access is denied`); the copy runs fine.
2. Opened `UEMinidump.dmp` with `cdb.exe -z <dmp> -y <EngineBinaries> -c "lm; !analyze -v; kb; q"`.
3. **Checked for engine PDBs first, before trusting any output**: searched
   the entire `C:\Program Files\Epic Games\UE_5.8\` tree for `*.pdb` —
   **zero native (C++) PDBs exist anywhere in this install.** The only
   `.pdb` files present are `.NET` PDBs for build tooling
   (`AutomationTool`/`UnrealBuildTool` etc.), and this project's own two
   modules (`UnrealEditor-NexusFramework.pdb`,
   `UnrealEditor-NexusFrameworkEditor.pdb` under
   `<ProjectDir>/Binaries/Win64/`). **This is a standard Epic Games Launcher
   binary-distribution install of the engine — it does not ship native
   debug symbols for `Core`/`LandscapeEditor`/`UnrealEd`/`Renderer`/`Engine`
   by default.** No local symbol cache, no `_NT_SYMBOL_PATH`, nothing else
   found that could substitute.
4. **Confirmed cdb's output is NOT trustworthy for function names as a
   result.** `!analyze -v` explicitly flagged its own top frame as
   `WRONG_SYMBOLS` (`PROCESS_NAME: ntdll.wrong.symbols.dll`,
   `FAILURE_BUCKET_ID: WRONG_SYMBOLS_X64_...`, with cdb's own advice
   `"You can run '.symfix; .reload' to try to fix the symbol path"`).
   Independently cross-checked one printed name against its own address:
   the `kb` output labeled the return address `0x00007ffb7e87c9cd` as
   `UnrealEditor_Core!FDebug::CheckVerifyFailedImpl2+0x18` — but that
   address falls inside `UnrealEditor-LandscapeEditor`'s module range
   (base `0x7ffb7e710000`, size well under this offset from Core's base),
   **not Core at all** — a direct, provable contradiction. cdb is falling
   back to "nearest public/export symbol in the wrong place" for every
   engine-module frame (`UnrealEditor_LandscapeEditor!StaticEnum<enum
   ELandscapeWeightBlendPaintMode>+0x19dd`,
   `UnrealEditor_LandscapeEditor!FLandscapeImportHelper::GetWeightmapImportDescriptor+0x16ae`,
   `UnrealEditor_UnrealEd!ULandscapeEditorObject::~ULandscapeEditorObject+0x2e9e2`
   etc. — offsets of 5-190KB past the named symbol are themselves the
   giveaway these are wrong). **None of these specific function names
   should be treated as real** — this supersedes nothing in §10, it just
   confirms TODO 1 is still open pending real PDBs.

### What IS newly confirmed (module + offset only, no symbol names — cross-validated two independent ways)

The crashing thread's raw addresses were extracted twice, independently,
and agree exactly:
(a) directly from `CrashContext.runtime-xml`'s `<PCallStack>` element
(already-trimmed by the crash reporter itself, `NumMinidumpFramesToIgnore=6`),
and (b) by re-walking the raw `.dmp` in cdb. Module **boundaries** (which
DLL an address falls in) come from the minidump's own module directory and
don't require any symbols to be reliable — only the name-within-module
lookup is broken. Full ordered list (innermost first), with hex offsets,
for the next agent to plug straight into a real symbolized session once
PDBs exist:

```
UnrealEditor-Core             +0x47bec8   (assert machinery, already known)
UnrealEditor-LandscapeEditor  +0x16c9cd
UnrealEditor-LandscapeEditor  +0x255d2e
UnrealEditor-LandscapeEditor  +0x1a4282
UnrealEditor-UnrealEd         +0x7dabd8
UnrealEditor-UnrealEd         +0x7da470
UnrealEditor-UnrealEd         +0x7fe83f
UnrealEditor-UnrealEd         +0x7ffea9
UnrealEditor-UnrealEd         +0x80082b
UnrealEditor-UnrealEd         +0x8008de
UnrealEditor-UnrealEd         +0x8793f0
UnrealEditor-UnrealEd         +0xd1276e
UnrealEditor-UnrealEd         +0x1398420
UnrealEditor-UnrealEd         +0x86163e
UnrealEditor-UnrealEd         +0xd01cc5
UnrealEditor-Renderer         +0x1267088
UnrealEditor-Renderer         +0x1da465
UnrealEditor-Renderer         +0x127f53f
UnrealEditor-Renderer         +0x12796d6
UnrealEditor-Renderer         +0x1279f40
UnrealEditor-UnrealEd         +0x86112a
UnrealEditor-Engine           +0x24654bd
UnrealEditor-UnrealEd         +0x7b7d35
UnrealEditor-UnrealEd         +0x7ad545
UnrealEditor-UnrealEd         +0x1316c36
UnrealEditor.exe              +0x32779   (LaunchWindowsStartup-area, outermost UE frame)
UnrealEditor.exe              +0x1c4ac
UnrealEditor.exe              +0x1c5ba
UnrealEditor.exe              +0x21256
UnrealEditor.exe              +0x35c74
UnrealEditor.exe              +0x3902a
KERNEL32                      +0x17374
ntdll                         +0x4cc91   (thread entry)
```

### Why this matters even without names — new evidence for P1 over P0

Even though the *names* are wrong, cdb's low-offset (small, plausible)
matches for a handful of frames happen to land on functions whose
identity is independently corroborated by their **position in the known,
well-documented UE editor main-loop structure**, not by trusting the name
in isolation:

```
ntdll!RtlUserThreadStart
 → kernel32!BaseThreadInitThunk
 → UnrealEditor.exe: LaunchWindowsStartup / GuardedMainWrapper / EngineTick   (standard UE entry chain — module-level fact)
 → UnrealEditor-UnrealEd: UUnrealEdEngine::Tick → UEditorEngine::Tick → UEditorEngine::UpdateSingleViewportClient
 → UnrealEditor-Engine: FViewport::Draw            (+0x47d, small offset — plausible real hit)
 → UnrealEditor-UnrealEd: FLevelEditorViewportClient::Draw / FEditorViewportClient::Draw   (+0xf5 / +0x4e, small offsets — plausible real hits)
 → UnrealEditor-Renderer: FSceneRenderBuilder::FSceneRenderBuilder / ::CreateSceneRenderer / ::AddRenderer   (5 Renderer frames total)
 → UnrealEditor-UnrealEd (11 frames — unnamed reliably, but MODULE-confirmed)
 → UnrealEditor-LandscapeEditor (3 frames — unnamed reliably, but MODULE-confirmed)
 → UnrealEditor-Core: assert machinery → CRASH
```

**This is a materially more specific finding than §1/§10's "Renderer frames
sandwiched between UnrealEd blocks, consistent with scene-proxy creation"
(which was inference from module COUNTS only).** We now have the exact
frame order and can say with much higher confidence, from address/module
evidence alone (not name-guessing): **the LandscapeEditor code that
ultimately reaches `Q.IsNormalized()` is being called from INSIDE a
viewport Draw/render pass** (`FEditorViewportClient::Draw` →
`FLevelEditorViewportClient::Draw` → `FSceneRenderBuilder` construction →
back out into UnrealEd → into LandscapeEditor → assert) — **not from an
isolated, edit-time-only `RebuildAllSplines()`/`Pointify()` call**, which
is what P0 (§10) implicitly assumed as the trigger context. `Pointify()`/
`UpdateSplinePoints()` are not part of the Renderer's scene-render-builder
path in normal engine architecture; something invoked *during rendering*
is the more likely proximate cause.

**This shifts leading-hypothesis weight toward P1** (§10: "component
re-registration / scene-proxy creation pushes a bad transform into
`CreateSceneProxy`") or a closely related third option: the LandscapeEditor
**edit-mode's own `Render()` override** (editor modes draw their gizmos/
handles/spline-control-point visuals via a callback invoked FROM
`FEditorViewportClient::Draw` on every frame, in the LandscapeEditor
module) reconstructing a rotation/quaternion for on-screen handle/line
drawing without the same guards as the persisted geometry path — this
would be a **different quaternion construction than the `Pointify()` one
described in §2**, most likely for immediate/debug-line rendering rather
than final spline mesh placement. **Not proven — the exact function is
still unknown without real PDBs** — but the *context* (during Draw, not
during an isolated edit-apply) is now solid, address-verified evidence,
correcting the previous "not yet traced to a single confirmed line"
caveat in P0's evidence-against.

### Blocker: real PDBs required for the actual deliverable (exact function/line)

To go from "module + offset, corroborated by main-loop position" to the
literal function names and source lines the handoff document requires
(§22.B/C), real native PDBs for `Core`/`LandscapeEditor`/`UnrealEd`/
`Renderer`/`Engine` are required and are **not obtainable from anywhere
already on this machine**. The only route found: Epic Games Launcher →
Unreal Engine 5.8 install → gear icon → **Options → "Editor symbols for
debugging"** → Apply (downloads the missing PDBs into
`Engine/Binaries/Win64/`). This is a **GUI-only step an agent cannot
perform** (no documented CLI/silent-install flag for this specific
optional component was found), and is a **multi-GB download** (exact size
unconfirmed, historically these packages have been in the several-GB range
for a full engine's editor symbols). Disk space is not a constraint (584GB
free on `C:`, 707GB free on `E:`, checked directly). Once those PDBs
exist, re-running the exact same `cdb -z <dmp> -y <EngineBinaries+PDBs>
-c "kb"` command used this session (or reopening in the now-installed
WinDbg app directly) should immediately produce a trustworthy symbolized
stack for the offset list above — no new tooling work needed, only the
download.

**Decision on how to proceed with this blocker was handed to the user —
not resolved unilaterally in this pass** (see live conversation, not
logged here per this project's memory rules covering only durable
findings, not in-flight back-and-forth).

## Sources (WebSearch, for corroborating context only — not proof, not UE 5.8-source-verified)

- [Unreal Engine Issues and Bug Tracker (UE-63596)](https://issues.unrealengine.com/issue/UE-63596)
- [Unreal Engine Issues and Bug Tracker (UE-48053)](https://issues.unrealengine.com/issue/UE-48053)
- [Unreal Engine Issues and Bug Tracker (UE-97702)](https://issues.unrealengine.com/issue/UE-97702)
- [Niagara FX crashing often: Q is normalized - Epic Developer Community Forums](https://forums.unrealengine.com/t/niagara-fx-crashing-often-q-is-normalized/508495)
- [Instant Crash when using splines in 4.26.1 - Epic Developer Community Forums](https://forums.unrealengine.com/t/instant-crash-when-using-splines-in-4-26-1/480221)
- [UE 5.8 cant control tangents of landscape splines anymore - Epic Developer Community Forums](https://forums.unrealengine.com/t/ue-5-8-cant-control-tangents-of-landscape-splines-anymore/2737196)
- [Landscape spline issues - Feedback & Requests - Epic Developer Community Forums](https://forums.unrealengine.com/t/landscape-spline-issues/1356525)
