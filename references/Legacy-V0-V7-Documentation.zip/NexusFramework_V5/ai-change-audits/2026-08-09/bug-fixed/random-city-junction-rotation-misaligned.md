# Random-city junction rotations (corner/T/cross/multi) misaligned vs V4

Date: 2026-08-09
Category: bug-fixed

## Context

User-reported regression relative to `NexusFramework_V4`
(`E:\Projects\Game\UE\NexusFramework_V4`): V4 correctly aligned corner/
T-junction/4-way junction rotations when generating a random city. V5 kept
the exact same per-mesh `OffsetRotation` values from V4, but newly generated
random cities still had visibly misaligned junctions. User explicitly flagged
that V4 disabled Unreal Landscape's own automatic spline rotation adjustment
as a possible reason V4 aligned correctly, and asked for V4 vs V5 to be
compared before changing anything (not a blind copy, since V5's generation
lifecycle - direct-to-Landscape, no V4-style temp-points-then-Final-Build
staging step - is architecturally different).

## Problem / Goal

Find the exact point where V5's junction rotation calculation diverges from
V4's during random-city generation (`GenerateCityInternalGrid`) and fix it
without touching the Save/Load rotation-restore system
([[tangent-lost-on-save-load-roundtrip]]), selection, debug labels, or any
other unrelated code.

## Findings

**V4 never calls the engine's `ULandscapeSplineControlPoint::AutoCalcRotation`
at all** - confirmed by grep, zero matches anywhere in
`NexusFramework_V4\Source`. V4's `BuildSplineSegments`
(`NexusFrameworkSubsystem.cpp:1439`) assigns `ControlPoint->Rotation =
Point.Rotation` directly, where `Point.Rotation` was already computed by
`UNexusJunctionAnalysis::AnalyzeJunction` (`NexusJunctionAnalysis.cpp`) - a
real, deterministic, closed-form direction formula, purely a function of a
point's own Location and its neighbors' Locations:
- 2 connections, Corner: the angle **bisector** (sum) of the two branch
  directions - rotation-equivariant, so the same physical corner shape always
  resolves the same way regardless of how the whole junction is rotated.
- 2 connections, Straight/SmoothCorner: the **through-direction** (difference
  of the two branch directions).
- 3 connections (T-junction): the **largest angular gap** between the three
  angle-sorted branch directions (bisected) - where a missing 4th road would
  logically continue.
- 4+ connections: the **lowest-angle** branch direction (Atan2-sorted, first
  entry) - a deterministic, stable pick.

V5's `RecomputePointClassification` (`NexusFrameworkEditorSubsystem.cpp`), by
contrast, reset `ControlPoint->Rotation = FRotator::ZeroRotator` and called
the engine's own `ControlPoint->AutoCalcRotation(bAlwaysRotateForward=true)`
for every fresh (non-Load) classification. Read `AutoCalcRotation` in full
(`LandscapeSplines.cpp` ~2094-2180, UE 5.8 engine source):
- Its `ConnectedSegments.Num()==2` branch **is** a genuine closed-form Slerp -
  but it computes a mathematically **different** bisector-family answer than
  V4's plain vector-sum bisector. Close, but not numerically identical, so a
  V4-tuned `OffsetRotation` added on top lands on the wrong baseline.
- Its 1-or-3+-connection branch is **not closed-form at all** - it's a single
  step of an iterative solver: `Delta = average(DesiredRotation_i -
  Rotation)` then `Rotation = (Rotation + Delta).GetNormalized()`. This is
  designed to be invoked repeatedly (the native Landscape Spline Tool's own
  "Auto-rotate Control Points" command works this way, converging over
  several user clicks - confirmed by grep, every engine call site of
  `AutoCalcRotation` is in the interactive `LandscapeEdModeSplineTools.cpp`,
  never automatic). A single call from a reset `ZeroRotator` baseline
  performs a component-wise **Euler-angle average** of the branch directions'
  desired rotations - not a real geometric "facing" direction, and not
  reproducible/order-independent in any way that matches V4's math.

This directly explains the user's exact symptom: reusing V4's exact
`OffsetRotation` values produced misaligned junctions in V5 because those
values were tuned against V4's closed-form formula, not the engine's
iterative (or differently-shaped closed-form) one. This is also the direct
answer to "is V4's disabled automatic Landscape rotation adjustment required
in V5": yes - V4 was never disabling a running engine behavior, it simply
never depended on `AutoCalcRotation` in the first place, and V5 must not
either if it wants V4's tuned offsets to still apply correctly.

**Ruled out as the cause**: call-order/lifecycle differences between V4's
staged (temp points -> Final Build) and V5's direct-to-Landscape generation.
Traced `GenerateCityInternalGrid`: point/segment creation already completes
in one loop, then a **separate** classification pass runs afterward over
every created point (comment at the call site already notes this is
required, "a point's connection count isn't final until every neighbor ...
has been wired up"). Confirmed `ComputeDeterministicJunctionForward`'s inputs
(a point's own `Location` and each neighbor's `Location`) are fully populated
before ANY classification runs (both loops iterate over the same grid;
Location is set at control-point creation time, never touched again by
classification) - so this formula is provably order-independent regardless of
which point in the batch is classified first, unlike a Rotation-dependent
formula would be. Also confirmed `ConnectControlPointsWithSegment` always
leaves `SocketName` as `NAME_None` for a freshly-generated connection
(`GetBestConnectionTo` called before either endpoint has a `Mesh` assigned -
mesh assignment happens later, in the classification pass) - so the engine's
own socket-relative geometry never factors into `GetConnectionLocationAndRotation`
here either.

## Changes

`NexusFrameworkEditorSubsystem.cpp`, `RecomputePointClassification`:

- Added a new file-local helper, `ComputeDeterministicJunctionForward(NodeType,
  SortedDirections)` - a straight port of V4's
  `UNexusJunctionAnalysis::AnalyzeJunction`'s direction-selection logic
  (bisector / through-direction / largest-gap / lowest-angle-sorted), adapted
  to read `ULandscapeSplineControlPoint::ConnectedSegments`/`Location`
  instead of `FNexusRoadGraph`/`FNexusRoadPoint`.
- `RecomputePointClassification` now builds one angle-sorted
  (`Atan2(Y,X)`, matching V4's exact sort convention) `TArray<FVector>` of
  outward branch directions once per call, reused both for the existing
  Straight/Corner/SmoothCorner `Dot`-threshold classification (previously
  computed inline, now reads from the same array - no behavior change there)
  and for the new rotation formula.
- The `!bRestoredFromSavedSnapshot` branch no longer resets `Rotation` to
  `ZeroRotator` and calls `ControlPoint->AutoCalcRotation(...)` for **any**
  connection count (previously only the 1-or-3+ case was suspect; the
  2-connection case is replaced too, since its engine-Slerp answer doesn't
  match V4's bisector numerically). It now calls
  `ComputeDeterministicJunctionForward` and assigns
  `ControlPoint->Rotation = ForwardDirection.Rotation()` directly, mirroring
  V4's `Point->Rotation = ForwardDirection.Rotation()` assignment exactly.
- `ControlPoint->AutoFlipTangents()` is still called immediately after
  (unchanged) - confirmed via engine source
  (`ULandscapeSplineSegment::AutoFlipTangents`, `LandscapeSplines.cpp:3011`)
  that tangent-flip sign selection reads the (now-correct) `Rotation` field,
  so it still needs to run after Rotation is finalized, same as before.
- Everything after this point in the function (junction mesh
  assignment/`MeshScale`, `PointMeshSlot->OffsetRotation` addition,
  `bRestoreSavedRotation` Load path) is **untouched** - the fix is scoped
  entirely to how the baseline (pre-offset) `Rotation` is computed for the
  fresh-classification case.
- Updated `RecomputePointClassification`'s header doc comment
  (`NexusFrameworkEditorSubsystem.h`) to describe the new formula and
  explicitly document why `AutoCalcRotation` is no longer called for any
  connection count. Fixed one stale diagnostic-log reason string
  (`"AutoCalcRotation(bAlwaysRotateForward=true)"` -> 
  `"ComputeDeterministicJunctionForward"`) that would otherwise have kept
  claiming the old code path ran.

## Verification

Build: `Build.bat NexusFrameworkEditor Win64 Development -project=... -waitmutex -NoHotReloadFromIDE`
- **Result: Succeeded**, 10/10 actions, 0 errors (one pre-existing UHT
  advisory about include order in an unrelated file,
  `SNexusFrameworkPanel.cpp`, printed before the build proper started - not a
  compile error, not touched by this change, build still fully succeeded).

Not yet manually verified in-editor - see [[user-builds-and-verifies]].
Hand-off:
1. Generate Random City repeatedly (varying `RandomSeed`/jitter) with a mesh
   asset set that has `CornerHighwayMesh`/`TJunctionMesh`/`CrossJunctionMesh`
   assigned, using the SAME `OffsetRotation` values that were tuned in V4.
2. Confirm corner, T-junction, and 4-way/multi-way junction meshes visually
   face the correct direction and their connected road segments meet them
   without a visible kink/rotation mismatch - matching V4's known-good look
   for equivalent topology.
3. Confirm Straight/SmoothCorner segments (no junction mesh, uses the
   segment's own `SplineMeshes`) still run smoothly through pass-through
   points - this path shares the same new rotation formula.
4. Confirm dead-end points (1 connection) still orient sensibly (facing back
   toward their one neighbor).
5. Re-verify the unrelated, already-shipped fixes still hold: Save -> Load
   round-trip rotation fidelity ([[tangent-lost-on-save-load-roundtrip]]) and
   the junction OffsetRotation Apply-Configuration fix
   ([[junction-mesh-offset-rotation-not-applied]]) - both share this same
   function and neither's own code path was touched, but both are worth a
   quick re-check given how central `RecomputePointClassification` is.

## Result

Root cause identified via direct engine-source reading of
`AutoCalcRotation`/`AutoFlipTangents`/`GetConnectionLocationAndRotation`
(`LandscapeSplines.cpp`) cross-referenced against V4's own
`NexusJunctionAnalysis.cpp`, not assumed: V5 depended on the engine's
Landscape Spline rotation solver (a single, unconverged iterative step for
3+/1 connections, and a differently-shaped closed-form Slerp for 2
connections) where V4 always computed rotation itself via a real closed-form
formula and never called the engine solver at all. Fixed by porting V4's
exact formula into V5, scoped entirely to the "compute a fresh rotation"
branch of `RecomputePointClassification` - the Save/Load restore path,
selection system, debug labels, and every other call site's surrounding
logic are unchanged.

## Important Notes

- This changes the ABSOLUTE rotation V5 assigns to every freshly-classified
  point (all connection counts, not just 3+), which is the deliberate,
  necessary scope of this fix (V4's `OffsetRotation` values are tuned against
  this exact baseline) - but it means any V5 layout generated/reclassified
  before this fix will look different (correctly, not regressed) after a
  re-Apply/regenerate, purely because the underlying facing direction changed
  to match V4's convention.
- Did not touch `ULandscapeSplineControlPoint::AutoCalcRotation` itself
  (engine code, out of scope) or remove any of its call sites elsewhere in
  the engine - V5 simply no longer calls it from
  `RecomputePointClassification`.
