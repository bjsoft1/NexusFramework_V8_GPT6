# Map Save Forces A Full Landscape Spline Rebuild (Looks Like Apply Configuration Ran)

Date: 2026-08-09
Category: bug-fixed

## Context

User-reported bug: hitting the editor's own Save button forces a visible
Landscape spline "refresh" - the same effect as if **Apply Configuration**
had just been clicked. User's expectation: Apply Configuration must only
ever run when that specific button is clicked, never implicitly on save.

## Problem / Goal

Find what on the map-save path touches the Landscape splines component and
stop it from doing so when nothing actually changed.

## Findings

- `HandlePostSaveWorld` (`NexusFrameworkEditorSubsystem.cpp`) - the
  `FEditorDelegates::PostSaveWorldWithContext` handler documented in
  [[v5-auto-save-after-map-save]] - calls `SaveLayout()` on every real,
  successful, non-autosave map save while `bIsDirty`.
- `SaveLayout()`/`SaveLayoutAs()` both call `SyncFromLandscape()` first, as a
  pre-save reconciliation step (added for
  [[closed-loop-and-divider-save-load]] - re-syncing WorldData against the
  live Landscape before writing to disk).
- `SyncFromLandscape()` ended with an **unconditional**
  `SplinesComponent->RebuildAllSplines(); Owner->MarkPackageDirty();` inside
  its `if (SplinesComponent)` block - not gated on whether Direction 1/2/3
  actually found/changed anything. This ran on literally every plain
  File > Save with a dirty Nexus WorldData, whether or not Sync found any
  real mismatch.
- Those exact two calls (`RebuildAllSplines()` + `MarkPackageDirty()`) are
  also the last thing `ApplyHighwayConfiguration` does (the real Apply
  Configuration button's handler) - so a plain Save was producing the
  identical visible/side-effect signature as clicking Apply Configuration,
  even on saves where Sync changed nothing at all.
- Confirmed the explicit "Import Landscape" (Sync From Landscape) button
  (`SNexusFrameworkPanel.cpp::OnSyncFromLandscapeClicked`) already treats
  "0 removed, 0 imported" as a distinct "No changes found" outcome for its
  own result dialog - i.e. a no-op rebuild in that case was already known to
  be meaningless, just not skipped.

## Changes

`SyncFromLandscape` (`NexusFrameworkEditorSubsystem.cpp`): gated the final
`RebuildAllSplines()`/`MarkPackageDirty()` block on
`OutRemovedCount > 0 || OutImportedCount > 0` (the same condition already
used a few lines below it for `bIsDirty`/`OnLayoutChanged.Broadcast()`) - a
Sync that found nothing to change now touches the Landscape splines
component not at all.

## Verification

Not yet build-verified - see [[user-builds-and-verifies]].

## Result

Plain map saves with nothing for Sync to reconcile no longer rebuild/dirty
the Landscape splines component. Apply Configuration's own rebuild is
untouched (`ApplyHighwayConfiguration`/`ApplyAllConfiguration` still always
rebuild - that's correct, real configuration changed there by definition).
Saves where Sync DOES find real changes (an orphaned point removed, a native
untracked point/connector imported) still rebuild, same as before - that
path genuinely needs it (freshly classified points need their mesh/rotation
to actually render).

## Important Notes

- This does not change WHEN `SyncFromLandscape` itself runs (still every
  save, per [[closed-loop-and-divider-save-load]]'s reasoning for why the
  reconciliation itself has to happen pre-save) - only whether its own
  cosmetic/dirtying side effect fires when it found nothing to do.
