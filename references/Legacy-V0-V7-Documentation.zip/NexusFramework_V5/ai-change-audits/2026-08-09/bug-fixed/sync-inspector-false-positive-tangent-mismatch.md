# Sync Inspector 15 "Tangent Mismatch" Entries Were All False Positives

Date: 2026-08-09
Category: bug-fixed

## Context

User repro: Clear all -> Load layout -> manually adjust rotation/location of
several points in the viewport -> Save -> open Nexus Sync Inspector -> hit
Refresh -> hit "Copy Report as JSON" (the export tool built for exactly this
- see [[sync-inspector-json-export]]) and pasted the full 15-entry JSON
report back for diagnosis, alongside a very detailed brief demanding a
proven root cause (not a blind fix), full understanding of what UE's
reported `-1.0` tangent actually means, explicit protection of the
Imported-Connector/closed-loop/shared-point architecture, and a real test
matrix.

## Diagnosis

### What does UE's reported `-1.0` tangent actually mean?

It is **not an engine value** - `ULandscapeSplineSegment::Connections[].TangentLen`
is a plain float, always some real number, never a sentinel in engine terms.
`-1.0` is purely **Nexus's own reporting convention**: `ComputeSyncDiff` and
`OnLandscapeSplineObjectTransacted` both normalize a live TangentLen down to
`-1.f` whenever it's within `0.5` units of the plain distance-based formula
(`AutoTangentLen = FVector::Dist(A->Location, B->Location)`) - i.e. "this
segment has no explicit custom tangent, it's just sitting at its natural
default," matching the project's universal "-1 = auto/unset" convention
(see [[negative-one-means-global-default]]).

### Root cause

`SyncPointGeometrySnapshots` (`NexusFrameworkEditorSubsystem.cpp:1039`,
called by `WriteWorldDataToAsset` on every `SaveLayout`/`SaveLayoutAs`) read
each segment's live `TangentLen` **raw**, with no such normalization:

```cpp
PointA->OutgoingTangentLen = Connection.Segment->Connections[Connection.End].TangentLen;
PointB->IncomingTangentLen = Connection.Segment->Connections[OtherEnd].TangentLen;
```

`git log -S` confirms this line has been missing the check since the
function's very first commit (`19fc7f7f`) - not something the recent
`IncomingTangentLen`/Tier 1 work broke, a pre-existing gap that simply had
more surface area to manifest on once BOTH ends were captured (previously
only `OutgoingTangentLen` existed).

Two OTHER places reading the identical live value already had the correct
check (`OnLandscapeSplineObjectTransacted:~1338`, `ComputeSyncDiff:~3164`):
```cpp
const float AutoTangentLen = FVector::Dist(ControlPointA->Location, ControlPointB->Location);
const float ActualTangentLenA = Segment->Connections[Connection.End].TangentLen;
const float NewOutgoingTangentLen = FMath::IsNearlyEqual(ActualTangentLenA, AutoTangentLen, 0.5f) ? -1.f : ActualTangentLenA;
```

**Net effect**: for a segment that was never manually tangent-edited (sitting
at its natural auto/distance length - true for essentially every point in
the user's report, including points touched by the recent
rotation/location edits, since moving a point's LOCATION does not itself
set a custom TangentLen), Save baked the raw numeric auto-length into
`OutgoingTangentLen`/`IncomingTangentLen` as if it were an explicit override.
`ComputeSyncDiff` then correctly re-normalized the SAME live value down to
`-1.f` and compared it against Save's un-normalized real number ->
guaranteed mismatch, every time, for every untouched segment. **This is a
reporting/comparison bug, not a geometry-loss bug** - since
`ConnectControlPointsWithSegment`'s own override logic
(`(OverrideTangentLenA > 0.f) ? OverrideTangentLenA : AutoTangentLen`) would
apply that captured number on a later Load, and that number IS numerically
equal to the auto value anyway, the reconstructed geometry is visually and
numerically identical either way - only the Sync Inspector's own comparison
was wrong.

### Verifying this explains all 15 entries (not partial)

Every single mismatched field in the user's report reads exactly `UE = -1.0`
- no other stale/wrong number appears anywhere in the 15 entries. That
uniformity is the signature of this exact bug (a systematic missing
normalization affecting every untouched segment identically) rather than
scattered data corruption, which would show varied incorrect numbers
instead. Cross-checked point `B76B7BF5...`/`2090ED89...` (which each appear
in two different highways - `Highway 1` + `Imported Connector 1`/`2`) and
confirmed both of that shared point's reported rows read the *same*
`nexusOutgoingTangent`/`nexusIncomingTangent` number (expected - it's
literally the same underlying field), with each row's OWN mismatch flag
depending only on whether THAT row's own real segment happens to currently
be at auto - consistent with this bug, not with a cross-highway value
collision corrupting the stored number itself.

### Answering the user's specific architecture questions

- **Imported Connector correctly represented / contributing to mismatch?**
  No corruption traced to Direction 3's connector-discovery logic itself -
  it only registers topology (`OrderedPointIds`, `ConnectedHighwayIds`) and
  calls `RecomputePointClassification` (rotation only); it never touches
  `TangentLen`. Connector segments were flagged only because THEY, like the
  normal-highway segments, happened to be at their natural auto length and
  hit the same missing-normalization bug.
- **Reconstruction order causing overwrite?** Not for this bug - the fix is
  per-call, not order-dependent.
- **Does a shared control point require segment-specific (not point-level)
  tangent data?** This remains a real, SEPARATE, still-open, deliberately
  NOT-addressed limitation (Case C from [[tangent-lost-on-save-load-roundtrip]]'s
  Tier 1 follow-up): if a shared point genuinely has two DIFFERENT
  *explicit, non-auto* custom tangents across two different highways, the
  single scalar `OutgoingTangentLen`/`IncomingTangentLen` field still can't
  represent both, and whichever highway `SyncPointGeometrySnapshots`
  processes last on a given Save still wins. Nothing in the user's 15
  reported entries showed evidence of THIS specific collision (no entry
  showed a Nexus value that didn't match ITS OWN segment's natural auto
  length) - it did not need to be touched to fix this report, and per the
  user's own "do not expand scope" instruction from the Tier 1 conversation,
  it was left alone again here.

## Changes

`NexusFrameworkEditorSubsystem.cpp`, `SyncPointGeometrySnapshots`: added the
identical `AutoTangentLen`/`IsNearlyEqual` normalization
`OnLandscapeSplineObjectTransacted`/`ComputeSyncDiff` already use, applied
independently to both `PointA->OutgoingTangentLen` and
`PointB->IncomingTangentLen`. No schema change, no new fields, no change to
Load/materialization logic, Imported Connector logic, or closed-loop
handling - the three functions that read/compare a segment's live
`TangentLen` now all agree on the same "-1 if it's just auto" rule.

## Build

`Build.bat NexusFrameworkEditor Win64 Development` - **Result: Succeeded**,
4/4 actions (incremental, single-file recompile), 0 errors.

## Verification

**Build-verified only** - no GUI-automation capability, so the user's full
6-case test matrix (open/closed highway, connector variants, repeated
Save/Clear/Load cycles) was not run by the agent. Hand-off: repeat the exact
repro (Load -> adjust a few points -> Save -> Sync Inspector -> Refresh ->
Copy Report as JSON) and confirm the 15 entries are gone (0 Mismatch, or
only genuinely-real ones if a tangent handle was deliberately hand-dragged
during the session). If any mismatch remains, paste the new JSON report -
given the diagnosis above, a remaining entry where `ueOutgoingTangent`/
`ueIncomingTangent` is NOT exactly `-1.0` and doesn't match Nexus would be
the concrete signal that the separate, still-open shared-point/Case C
limitation is actually live in that specific layout, distinguishable from
this now-fixed false-positive class.

## Result

Root cause proven (not assumed) via direct comparison of three call sites
reading the identical live value, one of which was missing an established,
already-proven-correct normalization step present in the other two. Fixed
with the smallest possible change - reusing the exact existing pattern, no
architecture change. The separate shared-control-point-needs-segment-
specific-data limitation (Case C) remains open and was not touched, per
explicit prior scoping.

## Important Notes

- Imported Connector, closed-loop, and shared-point topology representation
  were all read/traced but NOT modified - confirmed not the cause of any of
  the 15 reported entries.
- This record is a separate, new bug thread from
  [[tangent-lost-on-save-load-roundtrip]] (that one was about a
  saved-but-real custom tangent silently reverting to auto on Load; this one
  is about an auto tangent being silently mis-reported as a custom one on
  Save) - kept as its own file rather than appended to that one, since it's
  a distinct defect in a different function, even though both concern the
  same `OutgoingTangentLen`/`IncomingTangentLen` fields.
