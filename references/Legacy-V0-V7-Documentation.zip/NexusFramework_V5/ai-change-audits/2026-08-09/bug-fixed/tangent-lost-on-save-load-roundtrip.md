# CRITICAL: Manually-Edited Tangent Lost On Save -> Load Round-Trip

Date: 2026-08-09
Category: bug-fixed

## Context

User-reported CRITICAL bug (their words: "this bug is very critical... our
main goal is when we load landscape from our data it should as it is need
to load which we save"). Repro: manually adjust a landscape segment's
tangent/location/rotation directly in Landscape Splines mode (building a
highway by hand), hit Save (triggers the auto-save-on-map-save path -
[[v5-auto-save-after-map-save]]), then Load Layout pointing at the
just-saved asset. The reloaded landscape visually differs from what was
saved. Nexus Sync Inspector reports "Configuration Mismatch (7)"; expanding
a detail row shows `UE has tangent value -1`, `our system has: 8354.927734`.
User explicitly invited schema changes if needed: "if we need to store more
info so you can do it."

## Problem / Goal

Find why a saved `FNexusRoadPoint::OutgoingTangentLen` fails to make it back
onto the live Landscape segment after Load, and fix it without any further
data loss.

## Findings

Traced the full Save -> Load round-trip against both this codebase and the
UE 5.8 engine source (`LandscapeSplines.cpp`):

1. **Save is correct.** `SyncPointGeometrySnapshots` (`WriteWorldDataToAsset`,
   called by every `SaveLayout`/`SaveLayoutAs`) reads the live segment's
   `TangentLen` and stores it as `PointA->OutgoingTangentLen` - confirmed
   this path works (the user's own Sync Inspector reading of "our system:
   8354.927734" proves the correct value survived Save and the WorldData
   round-trip through the asset).

2. **`LoadLayout`'s "Load Fresh" choice wipes the Landscape first.**
   `WipeLandscapeSplineGeometry` calls `ControlPoint->DeleteSplinePoints()`/
   `Segment->DeleteSplinePoints()` on everything, then
   `SplinesComponent->GetControlPoints().Reset()`/`GetSegments().Reset()`.

3. **`DeleteSplinePoints()` does NOT destroy the UObject** - confirmed by
   reading the engine source directly
   (`ULandscapeSplineControlPoint::DeleteSplinePoints`/
   `ULandscapeSplineSegment::DeleteSplinePoints`, `LandscapeSplines.cpp`
   ~line 2622/3670): it resets `Points`/`Bounds` and calls
   `Rename(nullptr, GetTransientPackage())` - the object survives, orphaned,
   reparented into the transient package. Its `ConnectedSegments`/
   `Connections[].TangentLen` are left completely untouched by this call.

4. **This project's OWN prior-established precedent** (comment already in
   `LinkPointToControlPoint`, written for the unrelated cross-map bug -
   [[cross-map-sourcepoint-bug]]) states outright: `TSoftObjectPtr` "carries
   a live weak-pointer cache that resolves regardless of the object's
   current name while it stays resident in memory." Since `WorldData ->
   Asset->World -> WorldData` (Save then Load, same session) is a pure
   in-memory struct copy chain, `SourcePoint.LoadSynchronous()` after a wipe
   can resolve straight back to the SAME now-orphaned-but-still-alive
   control point via that cached weak pointer, without ever doing a fresh
   path lookup that would correctly fail.

5. **`MaterializeMissingPointGeometry` already has a guard against exactly
   this class of problem** - `IsControlPointOnTargetLandscape` (checks
   `ControlPoint->GetOuter() == TargetSplines`, which SHOULD be false for a
   transient-reparented object) - so a fully-orphaned CONTROL POINT gets
   correctly detected and re-created fresh. BUT: the actual gap is one level
   up. `ConnectControlPointsWithSegment` (which is what applies
   `OutgoingTangentLen` as `OverrideTangentLen`) is only ever called in the
   `!AreControlPointsConnected(...)` branch - i.e. only for a BRAND NEW
   connection. Any pair that resolves as "already connected" - a shared/
   junction point another highway in the same Load already materialized
   this pass, or (per #4) a pair that survives resolution as still
   "connected" to each other via stale-but-intact `ConnectedSegments`
   bookkeeping - never got `OutgoingTangentLen` applied AT ALL. The existing
   segment (fresh or stale) silently kept whatever tangent it already had,
   frequently the plain auto/distance-based default.

6. **This exactly explains the "-1" reading.** `ComputeSyncDiff`'s own
   tangent comparison normalizes a live value that's nearly equal to the
   plain auto-distance formula down to `-1.f` (matching this codebase's
   universal "-1 = auto/unset" convention) - so "UE has -1" doesn't mean the
   live engine field is literally negative one, it means the live segment's
   real tangent was close enough to the default that it read as "just
   auto, no explicit override" - i.e. `OutgoingTangentLen` was never
   actually enforced onto it.

7. **Two smaller, related gaps found and closed for consistency/safety**:
   - `SyncPointGeometrySnapshots`'s tangent-reading loop had NO
     `IsControlPointOnTargetLandscape` guard at all (unlike
     `TryGetPointWorldLocation`/`TryGetPointWorldRotation`, which already
     have it) - a stale/cross-map read there would get baked into WorldData
     and persisted as if real.
   - `ComputeSyncDiff` itself (the Sync Inspector's own data source) also
     lacked the guard on both the primary `ControlPoint` resolution and the
     `NextControlPoint` lookup used for the tangent comparison - the
     diagnostic tool the user relied on to investigate this bug could in
     principle report a misleading comparison of its own.

## Changes

`NexusFrameworkEditorSubsystem.cpp`:
- New `EnforceSegmentTangent(A, B, OverrideTangentLen)` (anonymous
  namespace, alongside `AreControlPointsConnected`/
  `ConnectControlPointsWithSegment`) - finds the REAL segment already
  connecting A and B and force-sets both ends' `TangentLen` to
  `OverrideTangentLen` (matching `ConnectControlPointsWithSegment`'s own
  symmetric convention) if it doesn't already match, within tolerance.
  Returns whether it actually changed anything.
- `MaterializeMissingPointGeometry`'s main per-point walk AND its
  closed-loop closing-connection block: the `!AreControlPointsConnected`
  branch is unchanged (still creates fresh with the override, as before);
  added an `else` branch calling `EnforceSegmentTangent` for the
  ALREADY-connected case - the exact gap from finding #5. Its return value
  is OR'd into `bAnyMaterialized` so a tangent-only fix (no new point/
  segment actually created) still triggers the function's final
  `RebuildAllSplines()`/`MarkPackageDirty()` - otherwise the corrected DATA
  would be right but the RENDERED geometry would stay stale.
- `SyncPointGeometrySnapshots`: added the missing `IsControlPointOnTargetLandscape`
  guard on both `ControlPointA`/`ControlPointB` before trusting their
  `ConnectedSegments` for a tangent read (finding #7).
- `ComputeSyncDiff`: added the same guard on its primary `ControlPoint`
  resolution (treated as `MissingInUE`, same as a genuinely-unresolved
  SourcePoint) and on `NextControlPoint` (finding #7).

## Verification

Not yet build-verified - see [[user-builds-and-verifies]]. User should
reproduce their exact repro (manual tangent edit -> Save -> Load Fresh) and
confirm the Sync Inspector reports 0 mismatches afterward.

## Result

Every consecutive point pair Load reconciles now has its saved
`OutgoingTangentLen` enforced onto the live segment regardless of whether
that pair ended up "newly connected" or "already connected" during
reconciliation - closing the specific gap that let a manually-edited
tangent silently revert to auto on reload. Three related stale/cross-map
resolution gaps (save-time read, and the Sync Inspector's own two
resolution points) were also closed so neither Save nor the diagnostic tool
itself can be fooled by a resolved-but-orphaned SourcePoint.

## Important Notes

- **Known, separate, smaller fidelity gap NOT addressed here** (flagged to
  the user, not fixed blind): `FNexusRoadPoint::OutgoingTangentLen` is ONE
  float per point, but the engine's `FLandscapeSplineSegmentConnection`
  supports fully independent `TangentLen` values on EACH end of EACH
  segment - a point that's the "far end" of an asymmetrically-tangented
  segment has no field to capture that specific value, and
  `ConnectControlPointsWithSegment`/`EnforceSegmentTangent` both apply ONE
  override value to BOTH ends symmetrically. If the user's actual edits are
  ever asymmetric (different tangent length on each side of a single
  segment), this is a real, additional, NOT-yet-closed fidelity gap - worth
  a follow-up (e.g. a second `IncomingTangentLen` field) if reload mismatches
  persist after this fix specifically on segments edited asymmetrically.
- The root mechanism (a `TSoftObjectPtr` resolving via its cached weak
  pointer to an object `WipeLandscapeSplineGeometry` orphaned-but-didn't-
  destroy) is a GENERAL risk, not unique to tangent - any other per-point
  saved field that's only ever applied in the "newly connected/created"
  branch of a similar reconciliation pass would have the same class of gap.

## Follow-up — 2026-08-09 — Tier 1 fix implemented: IncomingTangentLen (asymmetric-tangent fidelity)

User requested a full, source-verified investigation (not trusting the prior
research blind) covering Location/Rotation/start-tangent/end-tangent/
closed-loop/shared-junction, framed as explicit Case A-E questions, before
any further code changes. Full report given; user approved "Tier 1 only"
(add `IncomingTangentLen`, do NOT build the larger per-neighbor/shared-
junction architecture, do NOT change `Point.Rotation` restoration behavior).

### Re-verification findings (before implementing)

Re-confirmed the prior report's engine-source claims against a fresh reading
of `LandscapeSplineControlPoint.h`/`LandscapeSplineSegment.h` directly (not
assumed): `FLandscapeSplineSegmentConnection::TangentLen` is independently
stored per `Connections[0]`/`Connections[1]` (confirmed on the struct
itself); there is NO independent tangent-direction field anywhere in the
engine - direction is always `ControlPoint->Rotation`, shared by every
segment attached to that point without a mesh socket. Also directly
confirmed (`LandscapeSplineControlPoint.h` line ~295-297) the engine's OWN
doc comment on `GetOuterSafe()`: *"Use GetOuterSafe instead of
GetOuterULandscapeSplinesComponent if there is any danger that this point
has been deleted (via DeleteSplinePoints)... because the outer is no longer
a ULandscapeSplinesComponent"* - direct first-party engine confirmation of
the exact stale-weak-pointer mechanism this bug's original investigation
(above) diagnosed independently.

**One correction to the original investigation's Case D claim**: re-reading
`SyncPointGeometrySnapshots` and `OnLandscapeSplineObjectTransacted` fresh
revealed BOTH used the identical bound `Index + 1 < Highway->OrderedPointIds.Num()`
for their pairwise walk - which structurally EXCLUDES the closed-loop
closing pair (Last, First) from ever being captured, in either the batch
pre-save sync or the live per-edit sync. `ComputeSyncDiff` had the same
bound, so the Sync Inspector was also structurally blind to this specific
pair. The original investigation's `EnforceSegmentTangent` fix correctly
fixed the WRITE side for the closing connection (`MaterializeMissingPointGeometry`
already threaded `PreviousPoint->OutgoingTangentLen` through it), but that
field was never actually being kept up to date FOR the closing pair by
either capture path - so "Case D: fixed" was only half true. Fixed as part
of this follow-up (see Changes below).

### Changes

`NexusRoadPoint.h`: added `float IncomingTangentLen = -1.f;` alongside (not
replacing) `OutgoingTangentLen` - "this point's own end of the segment
coming in from the PREVIOUS point in its highway's OrderedPointIds." Pure
UPROPERTY addition, default -1.f (auto) - old saved Layouts deserialize this
at the default automatically (standard UE tagged-property versioning, no
migration code needed), degrading gracefully to today's exact behavior
until re-saved.

`NexusFrameworkEditorSubsystem.cpp`/`.h`:
- `SyncPointGeometrySnapshots`: pairwise walk restructured to also process
  the (Last, First) closing pair for `bIsClosedLoop` highways (a small
  `NextIndex = bIsLastIndex ? 0 : Index+1` wrap, gated on
  `bIsClosedLoop && Num >= 3`). Now captures BOTH ends independently:
  `PointA->OutgoingTangentLen` (unchanged) AND (new) `PointB->IncomingTangentLen`.
- `OnLandscapeSplineObjectTransacted`'s segment-transacted branch: same
  closing-pair wrap added to its own highway-pair search loop; same
  both-ends independent capture, preserving its existing -1-normalization
  behavior (`IsNearlyEqual` against the auto-distance formula) for both
  fields now instead of just one.
- `ConnectControlPointsWithSegment`: `OverrideTangentLen` (one shared value)
  replaced with `OverrideTangentLenA`/`OverrideTangentLenB`, applied to
  `Connections[0]`/`Connections[1]` independently. Callers passing neither
  (`PlacePointOnLandscape`, `GenerateCityInternalGrid`) needed no changes -
  both default to `-1.f` (auto), same as before.
- `EnforceSegmentTangent`: same A/B split - independently no-ops per side
  when that side's override is `<= 0.f`, so a caller that only has one real
  saved value (e.g. an old asset with `IncomingTangentLen` still at its -1
  default) doesn't clobber the other end back to auto.
- `MaterializeMissingPointGeometry`: both call sites (main walk, closed-loop
  closer) now pass `PreviousPoint->OutgoingTangentLen` (A-side) AND
  `Point->IncomingTangentLen` / `FirstPoint->IncomingTangentLen` (B-side)
  independently. Added `FNexusRoadPoint* FirstPoint` tracking alongside the
  existing `FirstControlPoint` so the closing block can reach the first
  point's own `IncomingTangentLen`.
- `ComputeSyncDiff`: same closing-pair wrap added; now runs an INCOMING
  check (walking to the PREVIOUS point, wrapping for a closed loop's first
  point) independently alongside the existing OUTGOING check. New
  `NexusSyncMismatch_IncomingTangent` flag and `NexusIncomingTangent`/
  `UEIncomingTangent` fields on `FNexusSyncDiffEntry` (additive, existing
  `NexusTangent`/`UETangent`/`NexusSyncMismatch_Tangent` left untouched -
  no rename, no removed field).
- `SNexusSyncInspectorPanel.cpp`: `AddMismatchDetailRows` renders the new
  flag as a second "Incoming tangent mismatch" detail row; the existing one
  relabeled "Outgoing tangent mismatch" (was "Tangent mismatch") purely for
  disambiguation now that two exist side by side - no behavior change.

### Build verification

Ran `Build.bat NexusFrameworkEditor Win64 Development -project=...` directly
(UE 5.8 UnrealBuildTool). **Result: Succeeded**, 23/23 actions, ~30s
incremental build, `UnrealEditor-NexusFrameworkEditor.dll` linked with no
compile errors from these changes. One pre-existing, unrelated warning
(`SNexusFrameworkPanel.cpp(1): error: Expected SNexusFrameworkPanel.h to be
first header included`) appeared but did not block the build and is not
caused by any file this fix touched.

### Interactive verification - NOT performed by the agent, hand-off to user

The agent has no GUI-automation capability for the Unreal Editor (no way to
launch it, drag a tangent handle in the viewport, click Save/Load, or read
the Sync Inspector's rendered output) - only source-level investigation and
command-line compilation were possible this session. The user's requested
runtime verification steps (asymmetric A=8354/B=4210 repro, closed-loop
repro, backward-compat check against an existing saved asset) still need to
be performed interactively. Suggested exact steps:
1. Build the full editor as usual (this session only confirmed the target
   module compiles - a full editor launch wasn't attempted).
2. Two-point highway A->B: in Landscape Splines mode, independently set A's
   tangent handle length to ~8354 and B's to ~4210. Save. Load Fresh. Open
   Nexus Sync Inspector - expect 0 mismatches, and (if inspecting via the
   Details panel) A's live `Connections[].TangentLen` ~8354, B's ~4210.
3. Closed-loop highway (3+ points, `bIsClosedLoop` true): manually edit the
   CLOSING segment's tangent specifically (the one connecting the last
   point back to the first). Save. Load Fresh. Confirm the closing
   segment's shape/tangent matches pre-save, and Sync Inspector shows 0
   mismatches for both the last point's `OutgoingTangentLen` and the first
   point's `IncomingTangentLen`.
4. Backward compatibility: open an existing pre-this-change saved Layout
   asset (e.g. `NF_NewLayout3.uasset`, already present in the repo) and
   confirm it still loads without error/crash, with every point's
   `IncomingTangentLen` reading -1 (auto) until re-saved.

### Known limitation (unchanged from the original investigation, explicitly NOT in scope)

Per the user's explicit instruction, the larger per-neighbor/shared-junction
tangent architecture was NOT built. A point shared by multiple highways
(e.g. a T-junction: main highway A-P-C, branch highway P-B) still has only
ONE `OutgoingTangentLen`/`IncomingTangentLen` pair - if P is a "PointA" (has
a real "next" within its own highway) in more than one highway
simultaneously, whichever highway `SyncPointGeometrySnapshots`'/
`ComputeSyncDiff`'s outer loop processes last still overwrites the earlier
highway's captured value on Save. This is the SAME Case C/E gap flagged in
the original report - confirmed still present, deliberately deferred, not
silently expanded into this Tier 1 change.

## Verification Pass — 2026-08-09 — Full round-trip re-audit (no code changes)

User requested a full stop-and-verify pass on the Tier 1 implementation
above before any further work: re-trace the entire Landscape -> Nexus ->
Save -> Load -> Materialize -> Sync Inspector pipeline against the ACTUAL
current source (not the prior report's word), with explicit instructions
not to assume the prior write-up was correct. This pass made NO code
changes - pure re-verification.

### Round-trip trace (re-read fresh, source line numbers as of this pass)

- **Live edit capture**: `OnLandscapeSplineObjectTransacted`'s segment
  branch (`NexusFrameworkEditorSubsystem.cpp:1210-1297`) resolves the real
  `Connection.End`/`OtherEnd` for the transacted segment (never assumes
  `Connections[0]` is A) and independently updates
  `PointA->OutgoingTangentLen`/`PointB->IncomingTangentLen`, including the
  closed-loop closing pair via the same `bHasClosingPair`/`NextIndex` wrap
  as the save-time walk.
- **Save capture**: `SyncPointGeometrySnapshots` (`:992-1074`) - same
  independent-ends, same closing-pair wrap, both guarded by
  `IsControlPointOnTargetLandscape` on A and B before trusting a read.
- **FNexusRoadPoint storage**: `OutgoingTangentLen`/`IncomingTangentLen`
  (`NexusRoadPoint.h:85,105`) - both plain `-1.f`-default UPROPERTY floats,
  additive, no field removed/renamed.
- **Load / materialize**: `MaterializeMissingPointGeometry` (`:3560-3677`)
  - main walk passes `PreviousPoint->OutgoingTangentLen`/
  `Point->IncomingTangentLen` independently to `ConnectControlPointsWithSegment`
  (new segment) or `EnforceSegmentTangent` (already-connected pair, e.g.
  shared junction or a stale-but-resolved `SourcePoint`); the closed-loop
  closing block (`:3662-3676`) does the same for
  `PreviousPoint->OutgoingTangentLen`/`FirstPoint->IncomingTangentLen`.
  `EnforceSegmentTangent`'s bool return is OR'd into `bAnyMaterialized` at
  both call sites, so a tangent-only correction still triggers the final
  `RebuildAllSplines()`.
- **Diagnostic**: `ComputeSyncDiff` (`:3123-3215`) runs the OUTGOING check
  (vs `NextIndex`) and INCOMING check (vs `PrevIndex`) as two fully separate
  blocks, each resolving its own segment/connection and its own
  `Connection.End` - confirmed NOT comparing the same value twice under
  either flag.
- **UI**: `SNexusSyncInspectorPanel.cpp:264-279` - `NexusSyncMismatch_Tangent`
  -> "Outgoing tangent mismatch", `NexusSyncMismatch_IncomingTangent` ->
  "Incoming tangent mismatch", each reading its own
  `Nexus*/UE*` field pair.

**Connections[0]-is-not-always-A check**: every read/write site above
resolves the real end index via `Connection.End`/`GetFarConnection()` at the
point of use rather than assuming a fixed slot - confirmed by direct
re-reading, not inferred.

### Closed-loop re-verification

Re-confirmed the same `bHasClosingPair = Highway->bIsClosedLoop && Num >= 3`
gate is applied identically in all three capture/diagnose sites
(`SyncPointGeometrySnapshots:1013`, `OnLandscapeSplineObjectTransacted:1225`,
`ComputeSyncDiff:3138`) and in `MaterializeMissingPointGeometry`'s own
closing-block condition (`:3662-3663`, which additionally requires
`FirstControlPoint != PreviousControlPoint`). This is consistent, not a
partial fix - the closing D->A segment's `OutgoingTangentLen`(D)/
`IncomingTangentLen`(A) values are captured, saved, restored, and diagnosed
through the exact same code paths as any other consecutive pair, confirmed
by reading the actual index arithmetic rather than trusting the prior
report's claim.

**Edge case newly noted (not a regression, not fixed - flagged only)**:
`Num >= 3` is required everywhere above for a closing pair to exist, with
`MaterializeMissingPointGeometry`'s own comment explaining why ("a 2-point
'loop' would just be the same single segment doubled back on itself, not a
real ring"). But `bIsClosedLoop` (`NexusHighway.h:69`) is `EditAnywhere`, and
a separate, unrelated function (`IsAdjacencyRepresentedInWorldData:434`)
treats `Num >= 2` as sufficient for "adjacent via wraparound." Also,
`BuildChainsFromUntrackedPoints`' loop-detection walk (`:2953-2992`, used by
Sync From Landscape to auto-import a real closed ring from the Landscape)
cannot actually detect a genuine 2-point loop topology (two parallel
segments between the same two points) - traced its walk logic and it
terminates with `Current == nullptr`, `bClosedLoop` false. Net effect: a
2-point `bIsClosedLoop = true` highway can only ever arise from a user
manually ticking the checkbox in the Details panel on a straight 2-point
highway, not from any automatic path - and if that happens, the "closing"
segment (which wouldn't really exist as a second real segment anyway, per
the doubled-back-segment reasoning) is correctly left alone by the `Num >=
3` guard rather than mishandled. Judged a pre-existing, self-consistent
design constraint (not introduced or altered by the Tier 1 change) - not
fixed, per "stop after verification" instruction.

### Location / Rotation re-confirmation

- **Location**: still saved/restored. `MaterializeMissingPointGeometry:3621`
  creates a fresh control point directly from `Point->Location` (the saved
  snapshot) when `SourcePoint` doesn't resolve, with height resampling
  explicitly disabled (`bResampleHeight=false`) so the exact saved Z
  survives even if terrain shape changed since save.
- **Rotation**: still NOT restored from the saved snapshot on load - traced
  `CreateControlPointOnLandscape` (`:237-258`) end to end and confirmed it
  never assigns `ControlPoint->Rotation` from any Nexus-side value; the
  control point's `Rotation` is left at engine-default until the later
  classification pass (`RecomputePointClassification:2540-2565`) calls
  `AutoCalcRotation()` fresh. `Point.Rotation` itself remains a pure
  observation snapshot (`SyncPointGeometrySnapshots:985-989`,
  `OnLandscapeSplineObjectTransacted:1186-1194`), matching the user's
  explicitly-approved "leave as-is" decision. No accidental change found.

### Shared-junction limitation (reasoned from source, not GUI-tested)

Confirmed via source (`NexusFrameworkEditorSubsystem.cpp:3695`, "A shared
junction point can belong to more than one highway" - pre-existing comment)
that the data model reality behind Case C is real, not hypothetical: a
point's `OutgoingTangentLen`/`IncomingTangentLen` are single scalar fields
on `FNexusRoadPoint`, not per-neighbor. If such a point is processed as
"PointA" (has a real "next" in its own `OrderedPointIds`) by more than one
highway, `SyncPointGeometrySnapshots`'/`ComputeSyncDiff`'s outer
per-highway loop means whichever highway is processed last on a given Save
overwrites the earlier highway's captured value for that shared point. No
per-neighbor map was introduced - confirmed the scope was not silently
expanded.

### Backward compatibility re-confirmation

`IncomingTangentLen` is a plain additive UPROPERTY float with a C++ default
member initializer (`= -1.f`) and no custom serialization. UE's tagged
property system fills any property absent from an old asset's serialized
data with the class default (from the CDO) - standard engine behavior,
confirmed by inspecting the field declaration itself (no `Version`/custom
`Serialize()` override anywhere in `FNexusRoadPoint`/`FNexusHighway` that
could interfere). No migration code needed or added. Not tested against an
actual pre-Tier-1 `.uasset` in a running editor this pass (no GUI
capability) - reasoning is static/engine-guarantee-based, not runtime-
confirmed.

### Build

Re-ran `Build.bat NexusFrameworkEditor Win64 Development -project=... -waitmutex`
fresh this pass (not reusing the prior session's build claim). Output:
`Target is up to date` / `Using Unreal Build Accelerator local executor to
run 0 action(s)` / **`Result: Succeeded`**. "Up to date" confirms the
current on-disk source is byte-for-byte what the prior successful build
(23/23 actions, 0 errors) already compiled - i.e. nothing drifted
uncompiled since, not merely that a build was claimed earlier.

### Runtime verification

Still NOT performed - the agent has no GUI-automation capability for the
Unreal Editor in this environment (confirmed again this pass; unchanged
from the original Tier 1 report). The four hand-off repro steps in the
Tier 1 section above (asymmetric A=8354/B=4210, closed-loop closing-segment
edit, Sync Inspector zero-mismatch check, backward-compat load of
`NF_NewLayout3.uasset`) remain the concrete steps for the user to run
interactively.

### Outcome

No defects found in the Tier 1 implementation during this re-audit - every
item the user asked to re-check (round-trip completeness, closed-loop
capture, Location/Rotation architecture, asymmetric independence,
transaction path, Sync Inspector independence, all call sites, shared-
junction scope discipline, backward compatibility) traced correctly against
current source. One pre-existing, self-consistent edge case was newly
noted (2-point `bIsClosedLoop`, only reachable via manual Details-panel
toggle, never mishandled - just inert) and documented above, not fixed.
No code was changed this pass. Per instruction, stopping here for the
user's next decision - Tier 2 (per-neighbor/shared-junction architecture)
and Rotation-restoration-on-load remain explicitly out of scope until
separately approved.

## Follow-up — 2026-08-09 (3) — Rotation-restoration-on-load approved and implemented: root cause of the persisting visual Save→Load mismatch

**Context**: user reported the Save→Load mismatch was still happening
after setting every junction mesh `OffsetRotation`/offset value to 0
(explicitly ruling out the mesh-offset path), and asked for the exact
divergence point to be traced and fixed. This picks up the exact item this
file's own prior section left "explicitly out of scope until separately
approved" - new evidence (mismatch persisting with offsets at zero)
directly implicates it.

### Root cause (source-confirmed, not speculative)

`RecomputePointClassification` (`NexusFrameworkEditorSubsystem.cpp:2594`,
the only place `ControlPoint->Rotation` is ever computed) has always reset
`ControlPoint->Rotation = FRotator::ZeroRotator` then called
`AutoCalcRotation(bAlwaysRotateForward=true)` fresh, for every point with
`ConnectionCount > 0`, every time it runs - including from
`MaterializeMissingPointGeometry`'s Load-time classification pass
(`:3849`). The saved `Point.Rotation` snapshot (WorldData, restored from
the `.uasset` on Load) was never read by this function at all - confirmed
by re-reading it end to end, matching this file's own prior "Rotation:
still NOT restored from the saved snapshot on load" finding.

Read UE 5.8's actual `ULandscapeSplineControlPoint::AutoCalcRotation`
(`LandscapeSplines.cpp:2094-2180`) directly to characterize exactly how
wrong the recompute can be:
- For exactly 2 connections (`bAlwaysRotateForward=true` branch,
  `:2099-2144`): a genuine from-scratch Slerp-midpoint computation that
  never reads the incoming `Rotation` value at all - fully deterministic
  from neighbor topology alone. **Not a source of mismatch** (Location,
  which this determinism depends on, already round-trips correctly).
- For 1 connection or 3+ connections (T/Cross/MultiJunction, the fallback
  branch, `:2147-2179`): `Delta = average of (DesiredRotation - Rotation)
  across all connections; Rotation = (Rotation + Delta).GetNormalized()`.
  This is **one step of an iterative solver, not a convergent solve** -
  starting from `Rotation=ZeroRotator` (Nexus's own reset), a single call
  only nudges partway toward the true desired orientation. It will not, in
  general, reproduce whatever rotation the point actually had at Save time
  (reached via the native Landscape Splines tool's own manual
  edits/repeated incremental calls, or a real user gizmo drag) - it
  reproduces a mathematically different value that merely happens to be
  "in the right direction." **This is exactly a T/Cross/MultiJunction-only
  bug** - matching the user's and the (now-paused) crash investigation's
  own independent observation that problems concentrate "especially at
  junctions."

Since a junction's `Rotation` **is** every attached segment's tangent
direction (established fact, this file's own prior sections), a wrong
recompute doesn't just mis-report in the Sync Inspector - it visibly
reshapes the spline curve through that point after every Load, independent
of `PointMeshSlot->OffsetRotation` (a separate, additive field the user had
already correctly ruled out).

### Fix

`RecomputePointClassification` gained a new `bRestoreSavedRotation = false`
parameter (defaults preserve every existing caller's behavior unchanged -
interactive placement, Apply Configuration, Sync From Landscape imports all
still recompute fresh, exactly as before). Only
`MaterializeMissingPointGeometry`'s Load-time classification pass
(`:3849`, the *only* call site fed exclusively by just-deserialized
`WorldData`) now passes `true`.

When `bRestoreSavedRotation` is true, instead of the
`ZeroRotator`+`AutoCalcRotation` recompute, `ControlPoint->Rotation` is set
directly from `Point.Rotation` (the saved snapshot), inverse-transformed
from WORLD space back to the control point's own LOCAL space via
`SplinesComponent->GetComponentTransform().InverseTransformRotation(...)` -
the exact inverse of how `TryGetPointWorldRotation`/
`SyncPointGeometrySnapshots` captured it in the first place
(`TransformRotation`), confirmed by reading that capture path directly
rather than assuming symmetry. `AutoFlipTangents()` still runs afterward
(against the now-final, restored rotation, not a stale pre-restore value -
order matters, since `AutoFlipTangents` reads `ControlPoint->Rotation` to
decide each connected segment's `TangentLen` sign). The final
`PointMeshSlot->OffsetRotation` addition is skipped in the restored case
(`bWantsPointMesh && !bRestoredFromSavedSnapshot`) - the saved snapshot was
captured AFTER that same addition already ran once at the point's last live
sync, so re-adding it would double-apply the offset.

No schema change - `Point.Rotation` already existed and was already
captured unconditionally on every Save
(`SyncPointGeometrySnapshots:1049-1053`) and every live native edit
(`OnLandscapeSplineObjectTransacted`); it simply wasn't being read back.
Every point reaching `MaterializeMissingPointGeometry`'s classification
pass came from `WorldData.Points`/`WorldData.Highways`, i.e. the
just-deserialized asset, so it necessarily has real, previously-captured
`Point.Rotation` data (traced the full call path with no gap found for a
"never-observed" point reaching this specific site).

### Why this doesn't reintroduce the (now-paused) `Q.IsNormalized()` crash risk

Restoring a plain finite `FRotator` via `.Quaternion()`/`TransformRotation`/
`InverseTransformRotation` was already proven safe for any finite input
during the crash investigation (no NaN-producing singularity found in
`FRotator::Quaternion()` for finite values) - this fix carries no more risk
than the pre-existing, never-questioned `Location` restoration already
does. If anything, it now means Load calls `AutoCalcRotation`'s
iterative-Delta engine code path *less* often (skipped entirely for every
point with valid saved rotation data), reducing exposure to that specific
engine function during Load rather than increasing it - a neutral-to-positive
side effect, not a claimed fix for the paused crash investigation, which
remains a separate, unrelated thread.

### Build

`Build.bat NexusFrameworkEditor Win64 Development -project=... -waitmutex` -
**Result: Succeeded**, 10/10 actions, 0 errors.

### Verification - NOT yet performed by the agent

No GUI-automation capability, per [[user-builds-and-verifies]]. Hand-off:
1. Build/reload the editor (Ctrl+Alt+F11 Live Coding or full rebuild+relaunch).
2. Repro: build or open a highway with at least one real T/Cross/MultiJunction
   (3+ connections). Save. **Load Fresh** (not just Load - must go through
   `WipeLandscapeSplineGeometry`+`MaterializeMissingPointGeometry` to
   exercise this specific path).
3. Compare the reloaded junction's curve shape/tangent direction against
   pre-save (visually, and via Nexus Sync Inspector -> Refresh -> expect 0
   `NexusSyncMismatch_Rotation` entries for points that were already
   synchronized before Save).
4. Also check the `[NEXUS ROTATION WRITE] ... Reason=RestoredSavedRotation`
   log line now appears (vs. the old `Reason=AutoCalcRotation(...)`) for
   every classified point on Load - confirms the new path is actually being
   taken, not silently falling through to the fallback.
5. Regression-check a 2-connection Straight/Corner/SmoothCorner point still
   looks identical after Load (expected - untouched code path, but worth
   confirming nothing else shifted).

### Result

Root cause of the persisting Save→Load visual mismatch (independent of mesh
offset, which the user had already correctly ruled out) identified via
direct engine-source reading, not assumed: `AutoCalcRotation`'s 3+/1-connection
fallback is a single-step iterative delta, not a convergent recompute, so a
fresh Load-time call can never reliably reproduce a junction's true pre-save
rotation. Fixed with a minimal, opt-in parameter restoring the already-captured
`Point.Rotation` snapshot on Load only, leaving every other caller (and the
2-connection deterministic path) completely untouched. Build-verified;
interactive Save→Load visual/Sync-Inspector verification still needs the
user to run per the hand-off steps above.
