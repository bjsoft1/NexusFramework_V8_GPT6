﻿# CRASH: Assertion Q.IsNormalized() on Save -> Load Same Layout

Date: 2026-08-09
Category: bug-fixed
Status: **UNRESOLVED / diagnostics added, root cause not yet proven** - do not
treat as fixed.

## Context

User's actual in-editor repro (first real runtime test of the Tier 1
tangent work - see [[tangent-lost-on-save-load-roundtrip]]):

```
Save Layout
    -> Load the SAME layout
    -> Crash
    -> Repeat Save -> Load
    -> Crash again
```

Crash:
```
Assertion failed: Q.IsNormalized()
File: Engine/Source/Runtime/Core/Public/Math/QuatRotationTranslationMatrix.h
Line: 81
```
Stack: `UnrealEditor_Core`, `UnrealEditor_LandscapeEditor` (x3),
`UnrealEditor_UnrealEd`.

User's explicit instructions: do not assume Tier 1/`IncomingTangentLen` is
the cause; do not blindly normalize/reset/clamp to make the assert
disappear; find the first invalid value; if it can't be reproduced directly
(no GUI automation available), add diagnostics and hand off exact repro
steps instead of guessing a fix.

## Investigation

### 1. The assertion itself

`TQuatRotationTranslationMatrix(Q, Origin)`'s constructor
(`QuatRotationTranslationMatrix.h:81`) `check(Q.IsNormalized())` fires
editor-only, any time engine code builds a rotation matrix from a
non-unit-length or NaN-containing `FQuat`. This constructor is used
throughout the engine for object/component transforms - the assertion
itself only proves SOME quaternion reaching Landscape/LandscapeEditor code
is invalid; it doesn't by itself say which one.

### 2. Which of Nexus's own rotation math is even reachable

`AutoCalcRotation` is the only engine function that writes
`ULandscapeSplineControlPoint::Rotation` from scratch, and is `WITH_EDITOR`-
only, called ONLY from `Editor/LandscapeEditor/Private/LandscapeEdModeSplineTools.cpp`
in the vanilla engine (confirmed via `git grep`-equivalent search of the
engine source - no other engine caller exists). Its `bAlwaysRotateForward`
parameter **defaults to `false`** in the engine's own tool
(`LandscapeEdModeSplineTools.cpp:63`), gated behind an opt-in "Always Rotate
Forward" checkbox in Landscape tool settings
(`LandscapeEditorDetailCustomization_MiscTools.cpp`) - meaning normal manual
spline editing almost never exercises `AutoCalcRotation`'s 2-connection
"full Slerp overwrite" branch (`LandscapeSplines.cpp:2099-2145`).
`RecomputePointClassification` (`NexusFrameworkEditorSubsystem.cpp`) is
Nexus's own port of this same engine behavior (comment: "V5 never called
AutoCalcRotation before this feature") and calls it with
`bAlwaysRotateForward = true` **unconditionally, every single time** - the
one caller in the whole codebase that reliably, deterministically exercises
that branch for every 2-connection point on every Load.

### 3. Mathematically auditing the Slerp/rotation math itself

Read `AutoCalcRotation`, `Slerp_NotNormalized`, and `TVector::ToOrientationRotator`
directly from UE 5.8 engine source (not assumed):

- `TVector::ToOrientationRotator()` (`UnrealMath.cpp:200`) uses `Atan2(Y,X)`/
  `Atan2(Z,Sqrt(X*X+Y*Y))` - `Atan2(0,0)` is well-defined (returns 0), so a
  **zero-length direction vector does NOT produce NaN** here; the engine
  even has a defensive `ContainsNaN()` fallback to `ZeroRotator` as a
  backstop. Ruled out as a direct NaN source.
- `TQuat::Slerp_NotNormalized` (`UnrealMath.cpp:1226`) compensates for
  quaternion double-cover (`Sign = FloatSelect(RawCosom, 1, -1)`) BEFORE
  computing `Omega = Acos(RawCosom)`, so the compensated `RawCosom` is
  always in `[0,1]` and `Sin(Omega)` is always in `[0,1]`, never 0 in the
  branch that divides by it (`RawCosom < 0.9999` guards the only division;
  the near-identical case falls back to a safe Lerp). Audited the full
  numeric range - **found no genuine division-by-zero or NaN-producing
  singularity in this implementation** for any pair of valid, finite,
  normalized inputs, including the classic "180 degrees apart" case a naive
  Slerp would mishandle.
- `GetConnectionLocationAndRotation`'s mesh-socket branch
  (`LandscapeSplines.cpp:2071`) composes `FTransform(Socket->RelativeRotation,
  Socket->RelativeLocation) * FTransform(Rotation, Location, MeshScale)` -
  `FTransform` rotation composition is pure quaternion multiplication,
  independent of `Scale3D`, so a `MeshScale` with a zero component (a real,
  observed possibility - `ControlPoint->MeshScale = PointMeshSlot->Scale`,
  `NexusFrameworkEditorSubsystem.cpp:~2645`, and `Scale` has no enforced
  non-zero default) does **not** appear to corrupt the resulting rotation by
  this math, though it wasn't exhaustively proven risk-free for every
  FTransform code path.

**Conclusion of the math audit**: every individual function in the chain is
robust for FINITE input. No function was found to manufacture NaN out of
otherwise-valid finite data. This means the corruption, if it's really
rotation-math-related, has to come from an ALREADY-invalid upstream value
(a NaN/Inf `Location`, or a topology producing a value outside what was
checked) rather than from the Slerp/trig arithmetic itself - which could
not be proven or disproven further by static reading alone.

### 4. Stale/orphaned object risk (re-checked specifically for this crash)

`WipeLandscapeSplineGeometry`'s `DeleteSplinePoints()` (engine source,
confirmed again this pass) renames the object into the transient package but
does **not** clear `Location`/`Rotation`/`ConnectedSegments` - the object
survives with stale-but-intact data. `MaterializeMissingPointGeometry`'s
`IsControlPointOnTargetLandscape` guard (`ControlPoint->GetOuter() ==
TargetSplines`) correctly excludes these from `SourcePoint` reuse (transient
package outer != real SplinesComponent outer) - traced this specifically for
the "Load the SAME layout" case (where `SourcePoint`'s cached soft-path most
plausibly resolves back to the object it pointed at pre-wipe) and confirmed
the guard applies unconditionally, not just for cross-map cases. No gap
found here for THIS crash.

### 5. Highlighting system

`RefreshLandscapeSelectionHighlight()` is fully disabled (confirmed by
direct re-read) - its entire body is commented out, early-returns
immediately, never calls `SetSplineSelected`. Ruled out.

### 6. Transaction/callback re-entry

`OnLandscapeSplineObjectTransacted` fires when a transaction closes
(`FTransaction::Finalize`/`Apply`), not synchronously interleaved with
in-progress `Modify()` calls. `LoadLayout` wraps the entire wipe + wholesale
`WorldData` swap + `MaterializeMissingPointGeometry` call in ONE
`FScopedTransaction` that stays open until `LoadLayout()` returns, so any
transacted-object callback for objects created during this Load only fires
AFTER materialization fully completes - not against partially-constructed
objects. No re-entrant `BeginTransaction` call was found anywhere in this
path (consistent with the codebase's existing hardened precedent for the
point-deletion case, which already had to solve exactly this class of
problem). Not proven to be a factor.

### 7. "Imported Connector" / closed-loop / shared-junction interaction

Per the user's specific request, re-traced `SyncFromLandscape`'s Direction 3
(`NexusFrameworkEditorSubsystem.cpp:~3444-3555`, "Imported Connector N"):

- It reuses the two ALREADY-TRACKED `FNexusRoadPoint` GUIDs by lookup
  (`ControlPointToPointId`) - explicitly "never `AddPointToHighway`... these
  two already exist and must not be duplicated." **No duplicate-point
  creation found** - ruled out the "connector creates a second, coincident
  point on top of an existing one" theory.
- It DOES call `RecomputePointClassification` on both endpoints immediately
  (mid-`SyncFromLandscape`, i.e. before Save even happens), which can
  reclassify a point from a 2-connection type (Straight/Corner) to a
  3-connection TJunction - this switches which `AutoCalcRotation` branch
  runs. Confirmed `RecomputePointClassification` unconditionally resets
  `Rotation = FRotator::ZeroRotator` before every call regardless of
  classification, so sequential re-classification (as more connections are
  discovered) starts from a clean baseline each time - no compounding/carry-
  over risk found here.
- A shared point belonging to multiple highways is only classified ONCE per
  `MaterializeMissingPointGeometry` pass (`TouchedPointIds` is a `TSet<FGuid>`,
  confirmed) and only after ALL highways' segments for this pass have
  already been wired into `ConnectedSegments` (the classification loop runs
  strictly after the full per-highway connect loop) - so classification
  always sees the point's COMPLETE connection set, never a partial one.
  **No "conflicting/partial AutoCalcRotation call" mechanism found.**
- A T-junction/cross-junction point from a real connector (e.g. the diagonal
  of a closed 4-point ring) is a genuine, non-degenerate 3-way junction, not
  a coincident-point case - nothing about the connector topology itself
  requires two points to collide spatially.

**No proven defect found in the Imported Connector mechanism specifically**
- it was not ruled in or out with certainty, but no concrete corruption
  path was identified despite specifically looking for one.

### 8. Regression check via actual git history (not just session memory)

This session's changes are NOT all one uncommitted blob - most were already
committed:
```
752d163 Integrate layout assets with UE unsaved assets tracker
74946a2 Improve "Unsaved Changes?" prompt with field-level diff   <- adds the
                                                                       Rotation=ZeroRotator
                                                                       reset before
                                                                       AutoCalcRotation
685a82c Fix unnecessary Landscape spline rebuilds on save
2a745d0 Fix junction mesh rotation; restore safe segment highlighting
2628eed Fix: Preserve closed-loop & divider highways on save/load  <- Imported
                                                                       Connector /
                                                                       closed-loop
                                                                       mechanism
b4d8194 Improve road point classification and mesh updates         <- AutoCalcRotation
                                                                       call FIRST
                                                                       introduced here
[UNCOMMITTED] IncomingTangentLen / Tier 1 (this session's tangent work)
```
`git log --all -S "AutoCalcRotation"` and `-S "ControlPoint->Rotation =
FRotator::ZeroRotator"` confirm: the `AutoCalcRotation(bAlwaysRotateForward=
true)` call, its `ZeroRotator` reset, AND the entire closed-loop/Imported-
Connector mechanism are **all fully committed, predating the current
uncommitted Tier 1 diff**. `git diff HEAD` for the current uncommitted
changes contains **zero occurrences** of `AutoCalcRotation` or
`ZeroRotator` - Tier 1 never touches the rotation-calculation code path at
all, only `TangentLen` values passed into already-existing segment
connections.

**Conclusion**: the crash mechanism (if rotation-math-related) was already
fully reachable before ANY of this session's work, including before the
"Imported Connector" fix. Tier 1 is very unlikely to be the root cause,
though it does supply different (independently-tracked) `TangentLen` values
than before - and `TangentLen`'s only participation in `AutoCalcRotation`'s
math is a SIGN check (`FMath::Sign(TangentLen) < 0`), never direction -
confirmed via direct engine source read, not assumed.

## What was NOT found (ruled out with reasonable confidence)

- Highlighting system involvement (fully disabled, confirmed).
- Duplicate/coincident points created BY the Imported Connector mechanism
  specifically (it reuses existing GUIDs, doesn't create new ones).
- A pure NaN-producing singularity in `Slerp_NotNormalized` or
  `ToOrientationRotator` for finite inputs (audited both against engine
  source; both are defensively written).
- Stale/orphaned control point reuse past the existing
  `IsControlPointOnTargetLandscape` guard, specifically for the "reload the
  same layout" case.
- `IncomingTangentLen`/Tier 1 as the introducing change (git-history-
  confirmed: the rotation math and Imported Connector mechanism both predate
  it; `TangentLen` magnitude cannot affect `AutoCalcRotation`'s direction
  math, only a sign check).

## What remains an open, UNPROVEN hypothesis

Two (or more) control points ending up at, or extremely near, the exact
same `Location` would produce a `TangentLen` of 0 for their connecting
segment (`AutoTangentLen = FVector::Dist(A->Location, B->Location)`) and a
zero-length direction vector feeding `AutoCalcRotation`. Individually this
was shown to be SAFE by the math audit above (Atan2(0,0) doesn't NaN), but
the audit could not rule out every possible interaction (e.g. an already-
mesh-socket-having neighbor combining a zero direction with unusual
`MeshScale`/socket data, or a genuinely NaN `Location` entering from
somewhere not yet identified) without live values. This remains a real,
concrete, testable lead - not a conclusion.

## Diagnostics added (no behavior change)

All three are pure `UE_LOG(LogTemp, Error, ...)` calls - they do not skip,
clamp, normalize, or otherwise alter any value or control flow. Silent when
values are valid (no spam under normal use). Marked `TEMPORARY DIAGNOSTIC`
in-code for easy removal once root-caused.

`NexusFrameworkEditorSubsystem.cpp`:
1. **`LogInvalidRotationIfAny(CallSite, ControlPoint, PointId)`** (new,
   anonymous-namespace helper) - checks `Rotation.ContainsNaN()` and
   `Rotation.Quaternion().IsNormalized()`; if either fails, logs the point's
   full state (Rotation, quaternion SizeSquared, Location, Mesh, MeshScale,
   ConnectionCount) AND every connected neighbor's Location/TangentLen/
   Rotation. Called from `RecomputePointClassification` immediately after
   `AutoCalcRotation()`/`AutoFlipTangents()` - the single choke point every
   Nexus rotation calculation passes through (`PlacePointOnLandscape`,
   `GenerateCityInternalGrid`, `MaterializeMissingPointGeometry`,
   `SyncFromLandscape`'s Direction 3 all funnel through this one function -
   confirmed via source, it is the ONLY caller of `AutoCalcRotation` in this
   codebase).
2. **Near-coincident-point check** in `ConnectControlPointsWithSegment` -
   logs an error with both points' names/locations/distance whenever a
   newly-connected pair's `AutoTangentLen < 1.f` (near-zero distance),
   testing the open hypothesis above directly at its source.
3. **Saved-Location NaN check** in `MaterializeMissingPointGeometry` - logs
   if `Point->Location.ContainsNaN()` is true BEFORE that Location is used
   to create a fresh control point, to determine whether corruption already
   exists in the SAVED asset data itself (upstream of all Landscape/engine
   math) versus being introduced during reconstruction.

## Build

**BLOCKED, not yet verified this pass.** `Build.bat NexusFrameworkEditor
Win64 Development` failed immediately with `Unable to build while Live
Coding is active. Exit the editor and game, or press Ctrl+Alt+F11` - the
user's Unreal Editor is currently open (expected, since they just ran the
actual crash repro). Did not force-close the user's editor session. The
diagnostic-only changes above should compile (straightforward `UE_LOG`
calls using already-included types/headers) but this is NOT confirmed by an
actual compiler run yet.

## Hand-off: exact steps for the user

1. In the still-open editor, either press **Ctrl+Alt+F11** (Live Coding
   compile) to pick up these diagnostic-only changes without closing the
   editor, or close the editor and run `Build.bat NexusFrameworkEditor
   Win64 Development` normally, then reopen.
2. Reproduce the exact crash: Save Layout -> Load the same layout.
3. **Before** it crashes (or in the log even if it still crashes), search
   the Output Log / log file for `[NEXUS ROTATION CHECK]`:
   - If a `Near-coincident control points` line appears, note the two point
     names/locations/distance - this identifies the exact pair.
   - If an `INVALID rotation at RecomputePointClassification` line appears,
     note the Point GUID, Location, Mesh/MeshScale, and every logged
     Neighbor line - this identifies the exact point and its full
     connection context at the moment its Rotation went bad.
   - If a `has an INVALID (NaN/Inf) saved Location` line appears, the
     corruption already existed in the saved asset BEFORE this Load even
     started reconstructing geometry - a different, earlier bug (likely in
     Save/`SyncPointGeometrySnapshots`, not in Load/`AutoCalcRotation`).
   - If NONE of these lines appear at all, the crash's invalid quaternion is
     NOT coming from any of Nexus's own `Rotation`/`Location` writes -
     the next trace target would need to be inside `LandscapeEditor` itself
     (e.g. viewport gizmo/handle code reading a valid Nexus-written value but
     building a bad matrix from it some other way), which would need a
     debugger/crash dump to pin down further.
4. Report back exactly which (if any) `[NEXUS ROTATION CHECK]` lines fired,
   with their full text - that will let the actual root cause (and a real,
   proven, minimal fix) be identified, instead of guessing.

## Result

Root cause **NOT proven**. Ruled out: highlighting, duplicate-point creation
by Imported Connector, a mathematical singularity in the engine's own
Slerp/trig functions for finite inputs, stale-object reuse past the
existing guard, and (via actual git-history bisection, not just session
ordering) `IncomingTangentLen`/Tier 1 as the introducing change. The
strongest remaining, unproven, concrete lead is near-coincident control
point locations producing a zero/near-zero tangent and direction vector.
Added three non-invasive diagnostic log points covering the full requested
trace (saved Location validity, tangent/distance at connection time, and
Rotation validity immediately after every `AutoCalcRotation` call) to let
the user's next repro pinpoint the exact first invalid value. No fix
applied - per explicit instruction, nothing was normalized, clamped, reset,
or masked to make the assertion merely "go away."

## Important Notes

- The previously-fixed closed-loop, Imported Connector, and shared-junction
  mechanisms (see [[closed-loop-and-divider-save-load]]) were NOT reverted,
  disabled, or altered by this investigation - only read/traced.
- Do not remove the three diagnostic log points until the root cause is
  confirmed fixed and re-verified - they are the only current instrumentation
  covering this crash.

## Follow-up — 2026-08-09 (2) — narrowed repro: rotation APPLICATION, not Save/Load; mesh offset ruled out

User performed a critical isolation test themselves: **Mesh Rotation Offset
set to 0 (no mesh offset involved at all), manually adjusted a Landscape
spline/control-point rotation directly in the editor, applied it - crash
still occurred**, identical assertion/stack. This proves the mesh
`OffsetRotation` (`RecomputePointClassification`'s `ControlPoint->Rotation =
ControlPoint->Rotation + PointMeshSlot->OffsetRotation;`) is NOT required to
reproduce the crash - the earlier suspicion (a `-270°` mesh offset
interacting badly with a Landscape rotation) is ruled out as the SOLE
cause, though not necessarily unrelated to other rotation-application
crashes in general.

### Re-verified `FRotator::Quaternion()` is not the mathematical culprit

Read the actual UE 5.8 implementation (`UnrealMath.cpp:413-549`,
`FRotator3f/3d::Quaternion()`) directly: it computes the quaternion via
closed-form half-angle sin/cos (`Fmod(Angle, 360)` first, then
`SinCos(Angle/2)`), which is unit-length by construction for ANY finite
input (including -270, or values well outside ±360) - sin²+cos²=1 holds
regardless of the angle's magnitude within normal ranges. The engine's own
NaN-diagnostic fallback (`RotationQuat = FQuat::Identity` if
`ContainsNaN()`) only triggers for truly extreme/uninitialized-garbage
values, not everyday offsets like -270. This rules out "-270 vs 90 as
different Euler representations" as a direct arithmetic cause with high
confidence - a valid finite rotation value cannot become a non-normalized
quaternion through this conversion alone.

### Re-verified `AutoCalcRotation`'s neighbor-rotation read is unused

Re-checked whether a neighbor control point's OWN `Rotation` (which could
already have a mesh offset baked in from an earlier point's classification
within the same "Apply Configuration" loop) feeds into the CURRENT point's
`AutoCalcRotation` math, which would mean a cosmetic mesh-offset value could
propagate into and corrupt tangent-direction calculations. Confirmed via
direct engine source re-reading: `GetConnectionLocationAndRotation`'s output
`FRotator EndRotation`/`EndRotation0`/`EndRotation1` parameters are fetched
in both `AutoCalcRotation` branches but never actually read afterward - only
the paired `FVector EndLocation` is used for direction math. A neighbor's
`Rotation` field cannot influence this point's own `AutoCalcRotation` result
at all. Ruled out.

### New lead found: `TryGetPointWorldRotation`'s quaternion composition

`TryGetPointWorldRotation` (`NexusFrameworkEditorSubsystem.cpp:2495-2521`,
called from `OnLandscapeSplineObjectTransacted` on every native Landscape
rotation edit, and from `SyncPointGeometrySnapshots`/`ComputeSyncDiff`)
does:
```cpp
OutRotation = SplinesComponent->GetComponentTransform().TransformRotation(ControlPoint->Rotation.Quaternion()).Rotator();
```
`ControlPoint->Rotation.Quaternion()` is confirmed unit-length (see above).
`TransformRotation` composes it with `SplinesComponent`'s OWN world-space
rotation via quaternion multiplication - mathematically norm-preserving
ONLY if `GetComponentTransform().GetRotation()` is ALSO already unit-length.
Not yet proven whether the Landscape actor/SplinesComponent's own world
transform could carry a drifted (not-quite-unit) rotation quaternion (e.g.
from repeated parent/child transform composition) - flagged as a candidate,
NOT confirmed. Importantly, this specific function only ever WRITES into
`Point.Rotation` (Nexus's own snapshot struct field) - it never writes back
to any live Landscape object - so even if this composition were imperfect,
it could not itself be the write that later crashes LandscapeEditor. Kept
as a secondary lead for the NEXT diagnostic pass, not the current one's
focus.

### Diagnostics added this pass (still pure logging, no behavior change)

`NexusFrameworkEditorSubsystem.cpp`:
- `RecomputePointClassification`: added a `[NEXUS ROTATION WRITE]` log
  immediately after `AutoCalcRotation()`/`AutoFlipTangents()` (before any
  mesh-offset addition), recording Point/ConnectionCount/NewRotation, in
  addition to the existing validity check from the first crash-investigation
  pass (now explicitly labeled "before mesh offset" for clarity against a
  second checkpoint that would run after it).
- `OnLandscapeSplineObjectTransacted`'s control-point branch: added a
  `LogInvalidRotationIfAny` call at the VERY TOP of the branch (before ANY
  Nexus processing - before `TryGetPointWorldLocation`/
  `TryGetPointWorldRotation` even run), validating `ControlPoint->Rotation`
  the instant this transacted-object callback fires for a native edit. This
  is the earliest possible Nexus-side observation point - if THIS fires
  invalid, the corruption already existed before Nexus touched anything at
  all (rules Nexus out entirely for that occurrence). Also upgraded the
  existing "Rotation changed" log into a full `[NEXUS ROTATION WRITE]` line
  with previous/new FRotator, previous/new FQuat + SizeSquared +
  IsNormalized, the raw (untransformed) `ControlPoint->Rotation`/its own
  quaternion validity, and `ContainsNaN`, per the user's exact requested
  format.

### Build

**Blocked again** - `Build.bat` failed with "Unable to build while Live
Coding is active" (user's editor open again, expected mid-investigation).
Not force-closed. User should press **Ctrl+Alt+F11** to Live Coding-compile,
or close and rebuild normally.

### Hand-off for next repro

1. Ctrl+Alt+F11 (or close/rebuild/reopen) to pick up the new diagnostics.
2. Repeat the EXACT isolated repro that just proved mesh-offset-independence:
   plain highway or junction, Mesh Offset = 0, manually change a control
   point's rotation in the Landscape Splines tool, apply it.
3. Search the log for, in this order:
   - `[NEXUS ROTATION WRITE] ... Source=OnLandscapeSplineObjectTransacted` -
     if this appears BEFORE the crash, Nexus's callback fired and read
     SOME rotation from the native edit; check its `RawControlPointRotation`/
     `RawQuatIsNormalized`/`RawRotationContainsNaN` fields - if
     `RawRotationContainsNaN=1` or `RawQuatIsNormalized=0` HERE, the
     corruption existed in `ControlPoint->Rotation` BEFORE Nexus did
     anything with it (native/engine-side origin, case A/D - Nexus is not
     the cause).
   - `[NEXUS ROTATION CHECK] INVALID rotation at OnLandscapeSplineObjectTransacted (control point, on first callback entry)` -
     if THIS appears, it's the single strongest signal: the very first
     thing Nexus's callback sees is already invalid.
   - `[NEXUS ROTATION WRITE] ... Source=RecomputePointClassification` - only
     relevant if the user also clicks Nexus's own Apply Configuration
     button (not the same action as a plain native rotation edit) - if this
     fires and the crash follows immediately after, compare its logged
     `NewRotation` against whatever LandscapeEditor was doing right after.
   - If NONE of these lines appear at all before the crash, the invalid
     quaternion is not coming from anything Nexus wrote or observed at any
     traced point - the next step would need to be inside LandscapeEditor's
     own native rotation-apply/gizmo code, which needs a debugger or crash
     dump to pin down further (outside this agent's capability).
4. Report back exactly which lines fired (or didn't), with their full text.


## Follow-up — 2026-08-09 (3) — user found an old crash log; pinpointed exact engine line via direct source read

User located a separate crash log (CrashReportClient-style, with
`LoginId`/`EpicAccountId` header) for what looked like the same assertion
and asked "is this ours or not." Full stack (abridged to the relevant
frames):

```
Assertion failed: Q.IsNormalized() [QuatRotationTranslationMatrix.h:81]
UnrealEditor_LandscapeEditor!TQuatRotationTranslationMatrix<double>::TQuatRotationTranslationMatrix()
UnrealEditor_LandscapeEditor!FLandscapeToolSplines::GetWidgetRotation() [LandscapeEdModeSplineTools.cpp:1920]
UnrealEditor_LandscapeEditor!FEdModeLandscape::GetCustomDrawingCoordinateSystem()
UnrealEditor_UnrealEd!FEditorModeTools::GetCustom{Drawing,Input}CoordinateSystem/ForEachEdMode()
UnrealEditor_UnrealEd!FEditorViewportClient::GetWidgetCoordSystem() -> FWidget::Render() -> FEditorViewportClient::Draw()
UnrealEditor_UnrealEd!UEditorEngine::Tick() -> UUnrealEdEngine::Tick() -> FEngineLoop::Tick()
```

This is a **different call site** than everything traced in this file so
far (`AutoCalcRotation`/`Slerp_NotNormalized`/`RecomputePointClassification`,
all reached via Load/Apply Configuration). This one fires from ordinary
**viewport rendering**, every `Draw()` tick, whenever the Landscape Splines
tool has a control point selected - completely independent of Save/Load
timing.

### Read the exact engine line directly (not assumed)

`C:\Program Files\Epic Games\UE_5.8\Engine\Source\Editor\LandscapeEditor\Private\LandscapeEdModeSplineTools.cpp:1901-1925`,
`FLandscapeToolSplines::GetWidgetRotation()`:

```cpp
else if (SelectedSplineControlPoints.Num() > 0)
{
    ULandscapeSplineControlPoint* FirstPoint = *SelectedSplineControlPoints.CreateConstIterator();
    ULandscapeSplinesComponent* SplinesComponent = FirstPoint->GetOuterULandscapeSplinesComponent();
    return FQuatRotationTranslationMatrix(FirstPoint->Rotation.Quaternion() * SplinesComponent->GetComponentTransform().GetRotation(), FVector::ZeroVector);
}
```

This is a direct engine-source hit confirming the exact mechanism the
second follow-up's "New lead: `TryGetPointWorldRotation`'s quaternion
composition" section flagged as a *candidate pattern* in Nexus's own
code - turns out the engine itself does the identical composition
(`ControlPointRotationQuat * SplinesComponentTransformRotationQuat`) for
gizmo display, reading the LIVE `ControlPoint->Rotation` directly.

Quaternion multiplication only preserves unit length if BOTH operands are
already unit-length. Ruled out `SplinesComponent->GetComponentTransform().GetRotation()`
as a contributing factor: grepped this codebase for any Nexus write to the
Landscape actor's or `SplinesComponent`'s own actor/component transform
(`SetActorRotation`/`SetRelativeRotation`/`SetWorldRotation`/`SetActorTransform`/
`SetRelativeTransform`) - **zero matches**. Nexus never touches that
transform at all, so it stays at whatever the Landscape actor's own
placement is (normally identity/unrotated) and its `GetRotation()` quaternion
is not a plausible source of non-unit-length here.

### Conclusion

This confirms with high confidence: whenever this specific crash fires, the
**selected control point's own `FirstPoint->Rotation` field** was already a
non-unit-length/NaN `FRotator` at the moment it got selected - not
something the widget/gizmo code computes wrong itself, and not something
Save/Load-specific. The engine code here is a passive reader, asserting on
data that was already bad by the time this point was selected. Since the
bad value just sits on the object until selected, this is fully consistent
with being "an old crash" unrelated to whatever the user was doing right
before it fired - the corruption could have been written arbitrarily long
before (by Generate/Apply Configuration/Sync/a prior manual edit), and only
surfaces the next time that exact point happens to get selected and
rendered.

**Answer to "is this ours or not"**: the function that technically asserts
is 100% engine code (`LandscapeEditor` module, not `NexusFrameworkEditor` -
zero Nexus frames anywhere in this stack). But the corrupted `Rotation`
value it's reading almost certainly originated from an earlier Nexus write
onto that `ULandscapeSplineControlPoint` (Generate/Apply
Configuration/Sync/`RecomputePointClassification` are the only writers of
that field in this codebase, per section 2 above) - not from an unrelated,
independent engine bug. Root cause (which specific write left it bad) is
still not proven; this only narrows *where the assertion fires* and rules
out the `SplinesComponent` transform as a contributing factor, it does not
supply a live corrupted value. The existing `[NEXUS ROTATION CHECK]`/
`[NEXUS ROTATION WRITE]` diagnostics (section 2 pass, still in place) remain
the right tool to catch the actual bad write on the next live repro - no new
diagnostic was added this pass, this was a pure engine-source read.

No fix applied. No diagnostics changed.

## Follow-up — 2026-08-09 (5) — precise repro (square + diagonal), a SECOND crash, and AutoCalcRotation confirmed obsolete

User supplied a precise, concrete repro this time (previous passes never
had one): a city with a closed square shape (multiple edge highways sharing
corner points, or a single closed-loop highway - either way, 4 corners),
then connecting two EXISTING opposite corners with a diagonal (both corners
already-tracked, mid-chain points - the exact "Imported Connector" /
Direction 3 shape from `closed-loop-and-divider-save-load.md`). Works live;
Save -> Load the same layout crashes. Also supplied a SECOND, different
crash from the same repro:

```
Fatal error: Trying to resize TArray to an invalid size of 2147483648
UnrealEditor_Core!OnInvalidArrayNum() [ContainerHelpers.cpp:8]
UnrealEditor_Engine!FBatchedElements::AddReserveLines() [BatchedElements.cpp:359]
UnrealEditor_Engine!DrawDashedLine() [PrimitiveDrawingUtils.cpp:1486]
UnrealEditor_LandscapeEditor!FLandscapeToolSplines::Render() [LandscapeEdModeSplineTools.cpp:1777]
UnrealEditor_LandscapeEditor!FEdModeLandscape::Render() [LandscapeEdMode.cpp:3124]
... FEditorViewportClient::Draw() -> same rendering-tick path as before ...
```

### Crash #2 traced to the exact same class of cause as crash #1

Read `FLandscapeToolSplines::Render()` directly
(`LandscapeEdModeSplineTools.cpp:1764-1775`):

```cpp
for (ULandscapeSplineControlPoint* ControlPoint : SplineSelection->GetSelectedSplineControlPoints())
{
    ...
    FVector HandlePos0 = SplinesComponent->GetComponentTransform().TransformPosition(ControlPoint->Location + ControlPoint->Rotation.Vector() * -20);
    FVector HandlePos1 = SplinesComponent->GetComponentTransform().TransformPosition(ControlPoint->Location + ControlPoint->Rotation.Vector() * 20);
    DrawDashedLine(PDI, HandlePos0, HandlePos1, FColor::White, 20, SDPG_Foreground);
```

Same precondition as crash #1: only runs for a SELECTED control point.
`ControlPoint->Rotation.Vector()` - if `Rotation` (or `Location`) contains
NaN/Inf, `HandlePos0`/`HandlePos1` become NaN/Inf. Read `DrawDashedLine`
(`PrimitiveDrawingUtils.cpp:1471-1501`):

```cpp
double LineLeft = (End - Start).Size();          // NaN if End/Start are NaN
const int32 nLines = FMath::CeilToInt32(LineLeft / (DashSize*2));  // NaN->int cast
PDI->AddReserveLines(DepthPriority, nLines, ...);  // nLines garbage (e.g. INT32_MIN)
```

A NaN-to-int32 cast reliably produces `INT32_MIN` on this platform; the
"2147483648" in the fatal error is exactly `abs(INT32_MIN)` - a textbook
signature of a NaN/Inf `Location` or `Rotation` feeding a distance-based
array-size computation. **Confirms**: both crashes require the SAME
precondition (a selected control point's `Rotation` and/or `Location`
already NaN/Inf/non-unit by the time it's selected and rendered) - two
different engine call sites hitting the identical upstream corruption, not
two unrelated bugs.

### AutoCalcRotation is NOT called anywhere in this codebase - the earlier investigation's own section 2 is now obsolete

Re-read `RecomputePointClassification` in full this pass (previously only
partially read). Its own doc comment (`NexusFrameworkEditorSubsystem.cpp`,
~line 2793) is explicit: *"Why this replaces every call to the engine's own
ULandscapeSplineControlPoint::AutoCalcRotation, not just the 1/3+ connection
cases"* - a full replacement, not the `bAlwaysRotateForward=true` wrapper
this file's earlier sections (2)/(3) assumed. Confirmed by reading the
function body end to end: it computes rotation via
`ComputeDeterministicJunctionForward` (a pure, closed-form, order-independent
function of current topology - bisector for Corner, through-direction for
Straight/SmoothCorner, largest-angular-gap for T-junction, lowest-angle for
Dead-end/4+-way) for the live/Apply/Generate/Sync path, or restores the
exact saved snapshot (`InverseTransformRotation` of `Point.Rotation`) for
the Load path (`bRestoreSavedRotation=true`). `ControlPoint->AutoCalcRotation()`
itself is never invoked. **This means every hypothesis in sections 2-3 of
this file chasing `AutoCalcRotation`'s branches (the `bAlwaysRotateForward`
2-connection Slerp, the iterative 1/3+-connection Delta-accumulation branch)
was investigating dead code paths that Nexus doesn't actually exercise.**
Left those sections in place per the append-only rule, but they should not
guide further investigation.

### Math-audited ComputeDeterministicJunctionForward's 3-connection (T-junction) branch specifically - the case the diagonal's corners hit

The diagonal's two touched corners go from 2 connections (Straight/Corner)
to 3 (TJunction) once the connector highway registers. Read the
`SortedDirections.Num() == 3` branch
(`NexusFrameworkEditorSubsystem.cpp`, ~2844-2870): largest-angular-gap via
`Atan2`/`Cos`/`Sin` only, no division, no square root - safe for any finite,
non-degenerate input, returns a genuine unit vector (`Cos²+Sin²=1`). Also
audited `SortedDirections`' construction: a neighbor whose `Delta` is nearly
zero is silently SKIPPED (not added), so `SortedDirections.Num()` can be
LESS than the raw `ConnectedSegments.Num()` used for `NodeType` - traced
what happens if `NodeType==TJunction` but `SortedDirections.Num()` ends up 2
(a near-coincident neighbor): falls into the `.Num()==2` branch, and since
`NodeType != Corner`, computes the through-direction via `GetSafeNormal()`
(defensively returns `ZeroVector`, never NaN, for a degenerate input) -
wrong/mismatched classification-vs-direction-count in that edge case, but
not NaN-producing. `.Num()==0`/`==1` are both explicitly guarded (early
`ZeroVector` return / falls through to a single valid entry). **No NaN-
producing path found in this function for any input.**

### Verified the Save-time write-then-capture ordering is correct (not the cause)

Traced whether a STALE `Point.Rotation` snapshot (captured before the
diagonal's reclassification) could be what gets "restored" on Load,
producing a merely-wrong-but-still-finite rotation (not itself explaining
NaN, but worth ruling out precisely): `SaveLayout()` calls
`SyncFromLandscape()` (which runs Direction 3's `RecomputePointClassification`
for both diagonal corners, computing their fresh T-junction rotation into
the LIVE `ControlPoint->Rotation`) BEFORE `WriteWorldDataToAsset()` ->
`SyncPointGeometrySnapshots()` (which captures `Point.Rotation` FROM that
now-current live value via `TryGetPointWorldRotation`). Order is correct -
the saved snapshot reflects the fresh T-junction rotation, not a stale
2-connection one. Ruled out.

Also re-verified `TryGetPointWorldRotation`/its Load-time inverse
(`SplinesComponent->GetComponentTransform().TransformRotation(...)` at Save,
`InverseTransformRotation(...)` at Load) are exact inverse operations -
lossless for finite, normalized inputs regardless of the
`SplinesComponent`/Landscape actor's own transform, PROVIDED that
transform's own rotation quaternion is itself unit-length (confirmed
earlier, Follow-up (3): Nexus never writes to the Landscape actor's/
SplinesComponent's own transform at all, so this stays whatever the level
author set - normally identity for a Landscape actor).

### Conclusion of this pass

Every individual function actually reachable in Nexus's CURRENT (not
assumed/outdated) rotation pipeline was audited against real engine source
and found safe for finite input, same "robust for finite input" conclusion
as every prior pass - but now with the actual live code path (not
`AutoCalcRotation`) confirmed, and a second, independently-confirmed crash
site pinpointing the same underlying precondition. The corruption still has
to originate from an already-invalid `Location` or `Rotation` entering this
pipeline from somewhere not yet directly observed with live data - static
reading alone cannot find it without an actual value to trace. The existing
diagnostics (`LogInvalidRotationIfAny` at `RecomputePointClassification`'s
choke point and `OnLandscapeSplineObjectTransacted`'s entry, the saved-
Location NaN check in `MaterializeMissingPointGeometry`) already cover the
exact repro needed - what's missing is the user actually running the
square+diagonal Save->Load repro against a build containing them and
reporting back which lines fire, per this file's own existing hand-off
section. No new diagnostics were needed this pass since the existing ones
already instrument every point this pass's tracing touched.

### Build

Not rebuilt this specific pass (no code changes - purely engine-source
reading); the diagnostics referenced above are already present and were
confirmed still building cleanly as part of this session's other, larger
changes (`imported-connector-and-split-point-save-load-duplication.md`,
`clear-all-full-reset-matching-new-layout.md`) - `Build.bat` Result:
Succeeded.

### Hand-off (updated)

Same as the existing hand-off section above, with the T-junction case now
specifically in scope: reproduce square (closed highway or 4 edge
highways) + diagonal between two existing opposite corners -> Save -> Load
-> select one of the two diagonal-touched corners (the ones that became
T-junctions) in Landscape Mode. Report which `[NEXUS ROTATION CHECK]` /
`[NEXUS CLASSIFY]` / `[NEXUS ROTATION WRITE]` lines fired for that point's
GUID, in order, from the Save through the Load through the selection.

## Follow-up — 2026-08-09 (6) — found and read the ACTUAL crash log on disk; strong new root-cause hypothesis; two fixes applied

User gave an exact deterministic repro (Generate Random City's grid, not
freehand drawing: "create new clear file, add city, generate random city,
then add diagonal inside the square city box, save, load, crash") and
re-pasted crash #2's log. Rather than wait for pasted Output Log text,
found UE already writes everything to disk at
`Saved/Logs/NexusFramework.log` (rotated to `-backup-<timestamp>.log` on
each new session) - read it directly, located the exact crash session by
grepping for the crash text, and read the full sequence leading up to it.

### The classification/rotation pass itself is provably clean

Every `[NEXUS CLASSIFY]`/`[NEXUS ROTATION WRITE]` line for every point in
the just-loaded grid (including the diagonal's two T-junction corners) logs
a completely finite, sane `NewRotation` (e.g. `P=0.000000 Y=90.000000
R=-0.000000`, `P=-0.000000 Y=-178.602008 R=-0.000000`) - zero NaN, zero
`[NEXUS ROTATION CHECK] INVALID` lines anywhere in the load. This
definitively rules out `RecomputePointClassification`/
`ComputeDeterministicJunctionForward` as the source for THIS repro,
consistent with (but now actually proven, not just math-audited) Follow-up
(5)'s conclusion.

### New finding #1 (confirmed bug, fixed): sign-insensitive auto-tangent detection

~53ms after the classification pass, four `[Landscape->Nexus] Segment ...:
OutgoingTangentLen -1.0 -> -15000.0` (etc.) lines fire from
`OnLandscapeSplineObjectTransacted`'s segment branch - for exactly the
T-junction points identified moments earlier. `-15000.0` is suspicious:
`-1 * BlockSpacing` (this generated grid's cell spacing) for a tangent that
should be "auto" (`-1`). Read the code
(`NexusFrameworkEditorSubsystem.cpp`, ~1512-1533): it compares the LIVE
segment's actual `TangentLen` against `AutoTangentLen` (`FVector::Dist(...)`,
always positive) to decide whether the point is still "auto" - but the
engine's own `AutoFlipTangents`/`AutoSetConnections` can legitimately leave
an auto-MAGNITUDE tangent NEGATIVE (a sign-only "flip 180" convention,
independent of magnitude - see `AutoCalcRotation`'s own "flip 180 if the
tangent is inverted" comment, engine source). Without `Abs()`, a
still-auto-but-sign-flipped tangent (exactly what a grid's vertical link -
"deliberately NOT part of any highway's `OrderedPointIds`", per
`GenerateCityInternalGrid`'s own comment - naturally produces) gets
wrongly pinned into `WorldData` as an explicit `-15000` override, when
every actual consumer of that field (`EnforceSegmentTangent`'s `> 0.f`
guard, `ConnectControlPointsWithSegment`) already treats overrides as
magnitude-only - the signed value was never a valid state for this field to
begin with, independent of whether it's also implicated in the crash.
**Fixed**: wrapped both the live-vs-auto comparison and the stored override
in `FMath::Abs()`.

### New finding #2 (strong hypothesis, mitigated): native tool selection persists across Load with no safe way to clear it

Re-examined `RefreshLandscapeSelectionHighlight`'s own existing comment
(already in this file from an EARLIER, unrelated crash this project hit -
`Assertion failed: ControlPoint->IsSplineSelected(),
LandscapeSplineSelection.cpp:105`): Landscape Mode's Splines tool tracks
its OWN selection in `ULandscapeSplineSelection`, a class PRIVATE to the
`LandscapeEditor` module (confirmed: its header lives under
`LandscapeEditor/Private/`, not reachable from Nexus at all) - and calling
`ControlPoint->SetSplineSelected(...)` from outside desyncs that private
array from the object's own flag and crashes elsewhere (proven by that
earlier crash dump), so Nexus was already forced to disable ITS OWN
selection-highlight feature entirely rather than risk it.

Grepped this entire module for any code that clears/touches that selection
across a Load: **none exists.** Combined with the log evidence: both
crash #1 (`GetWidgetRotation`) and crash #2 (`Render`'s dashed line) only
run `for ControlPoint : SplineSelection->GetSelectedSplineControlPoints()`
- i.e. only fire when something is ALREADY selected, and neither crash's
timeline in the log shows the user making a NEW selection first (crash #2
fires ~53ms after Load's own materialization/reclassification finishes,
far too fast for a fresh manual click). Load's own wipe
(`WipeLandscapeSplineGeometry` -> `DeleteSplinePoints()`) destroys every
existing `ULandscapeSplineControlPoint` and replaces it with brand new
objects - if a point was natively selected right before Save (highly
plausible: the diagonal's own endpoint(s), the last thing the user
interacted with before saving, are exactly what native Landscape editing
tends to leave selected), that object survives the wipe as a stale,
transient-package object ("stale but intact" per the earlier `#4` section
of this file) that `SplineSelection` keeps referencing - and once nothing
else references it (Nexus's own `SourcePoint` gets repointed to the NEW
replacement object during materialization) it becomes eligible for garbage
collection. A subsequent GC pass turns `SplineSelection`'s reference into a
genuinely dangling pointer; reading `->Location`/`->Rotation` from freed/
reused memory is undefined behavior fully capable of producing the exact
NaN/Inf values both crash sites need. This is not proven with a captured
NaN value in hand (no diagnostic can safely instrument freed memory), but
it is the only hypothesis consistent with EVERY piece of evidence gathered
across all six follow-ups in this file, including a documented precedent
crash in the exact same private-selection-tracking area.

**Mitigation applied** (not a full fix - a full fix would require touching
the same private, already-proven-unsafe engine internals): confirmed
`ControlPoint->IsSplineSelected()` itself IS a safe, public, READ-ONLY
query (already used elsewhere in this codebase,
`SyncActiveSelectionFromNativeViewportSelection`) - only the SETTER side is
unsafe. Added a guard at the top of `LoadLayout()`, after the asset picker
resolves and before any wipe/materialize work begins: walks the CURRENT
(about-to-be-wiped) Landscape's control points, and if any is natively
selected, blocks the Load with an explanatory dialog asking the user to
deselect (click empty Landscape space, or Escape) first, rather than
proceeding into the known crash risk. Zero engine-internals risk - pure
detection via an already-proven-safe read, no attempt to clear the
selection itself.

### Build

**Succeeded.** `Build.bat NexusFrameworkEditor Win64 Development` - editor
closed, no Live Coding block, `Result: Succeeded`.

**NOT YET independently verified by the user.** To confirm: repeat the
exact repro (Generate Random City, add a diagonal between two existing
grid points, Save). If the diagonal's own endpoint is still selected when
Load is attempted, the new dialog should appear instead of a crash;
deselecting and retrying Load should then complete without crashing. If the
crash STILL reproduces even with nothing selected at Load time, this
hypothesis is wrong and the investigation needs to resume from the
"stale/dangling reference" theory being ruled out.

## Important Notes (2026-08-09 update)

- The `LoadLayout()` guard is a BLOCKING dialog, not a Yes/No override -
  deliberate, since deselecting costs nothing and there is no legitimate
  reason to proceed into a documented crash risk.
- Do not attempt to fix the underlying selection-desync problem by calling
  `SetSplineSelected` from Nexus, even defensively (e.g. "clear it before
  wiping") - this is the EXACT mechanism that caused the prior, separate,
  already-fixed `LandscapeSplineSelection.cpp:105` assertion crash. If a
  real fix (not just a detect-and-block mitigation) is ever wanted, it
  needs a different, non-invasive mechanism - e.g. investigating whether
  briefly cycling the active Landscape tool via a genuinely PUBLIC API
  safely triggers the engine's own `ExitTool()`/`EnterTool()` (which DOES
  call `SplineSelection->ClearSelection()`/`GEditor->SelectNone()`) without
  the side effects a full Landscape-mode deactivation would have - not
  attempted this pass, flagged as future work only.
