# Clear All left State/City/Highway tree rows behind - now fully resets like New Layout

Date: 2026-08-09
Category: bug-fixed

## Context

User report (second round, after an earlier session's Clear All fix): after
Load Layout, clicking Clear All removes the actual road geometry, but the
Hierarchy tree still shows the old State/City/Highway rows - only New
Layout produces a genuinely empty-looking tree.

## Investigation

Compared `SNexusFrameworkPanel::RefreshHierarchy()` (the tree rebuild) against
both `ClearAllLandscapeGeometry()` and `NewLayout()`/`ResetToDefaultLayout()`.

- `RefreshHierarchy()` does `RootItems.Reset()` then rebuilds entirely from
  `Subsystem->GetWorldData()` every call - provably a correct full rebuild,
  no caching/staleness bug. Both `OnClearAllLandscapeGeometryClicked` (direct
  call) and the `OnLayoutChanged` broadcast (bound to `RefreshHierarchy` in
  `Construct()`, fired by both `ClearAllLandscapeGeometry()` and
  `NewLayout()`) trigger it correctly - ruled out a refresh-not-firing bug.
- The actual difference is scope, by design (from an earlier session's Task
  C fix): `ClearAllLandscapeGeometry()` removed every `FNexusRoadPoint` but
  deliberately left States/Cities/Highways (and their own mesh/generation/
  terrain overrides) untouched - matching the button's own confirmation text
  ("Delete every road point/segment..."). `NewLayout()` -> `ResetToDefaultLayout()`
  does `WorldData.Reset()` (wipes States/Cities/Highways/Points entirely)
  then reseeds exactly one default State/City/Highway - a small, obviously-
  fresh tree, which is why it "looks cleared" and Clear All's Points-only
  scope didn't.

Confirmed with the user (AskUserQuestion: "Full reset like New Layout" vs
"Keep Points-only scope") which behavior "Clear All" should actually have -
not a pure bug, a real scope/design fork with real consequences (discarding
per-entity config, not just geometry) either way. User chose the full reset.

## Changes

`NexusFrameworkEditorSubsystem.cpp`, `ClearAllLandscapeGeometry()`: after
`WipeLandscapeSplineGeometry`, replaced the Points-only removal loop with a
direct call to the existing `ResetToDefaultLayout()` (same helper
`NewLayout()`/`EnsureMinimumWorldDataOrReset()` already use) - full
`WorldData.Reset()` plus one fresh default State/City/Highway. Unlike
`NewLayout()`, `CurrentLayoutAsset` is deliberately left untouched (stays
associated with the same loaded file, just emptied, ready to Save over).
Broadcasts `OnLayoutChanged` + `OnActiveSelectionChanged` (mirroring
`NewLayout()`'s own two broadcasts) so the tree AND selection both pick up
the fresh default highway, not just the tree.

`SNexusFrameworkPanel.cpp`, `OnClearAllLandscapeGeometryClicked`: updated
the confirmation dialog text to state the stronger scope explicitly (resets
the whole State/City/Highway hierarchy, not just road geometry) rather than
silently changing what the button does without telling the user in the UI
itself.

## Verification

**Build: Succeeded** (`Build.bat NexusFrameworkEditor Win64 Development`,
same pass as `imported-connector-and-split-point-save-load-duplication.md`).

**NOT YET independently function-tested by the user.** To verify: Load a
layout with multiple States/Cities/Highways/Points, click Clear All -> tree
should show exactly one default State/City/Highway with zero points,
identical in shape to a fresh New Layout tree; Save over the same file,
reload -> stays that way.

## Important Notes

- This is a real behavior change with a real cost: Clear All now discards
  per-State/City/Highway config overrides (mesh sets, generation settings,
  terrain flags), not just road points - confirmed as the desired tradeoff
  with the user, not an oversight.
