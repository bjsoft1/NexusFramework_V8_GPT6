# Hierarchy tree: previously-selected row stays highlighted after selecting a new one

Date: 2026-08-09
Category: bug-fixed

## Context

User-reported UI bug (also logged in `todo-tasks/bug-lists.txt`): selecting
Point A highlights its Hierarchy tree row correctly; selecting Point B then
highlights B correctly too, but A's row never un-highlights - both stay
visually selected. Explicitly asked to root-cause via the actual selection
state/subsystem and Slate refresh logic, not a visual-only workaround, and
to verify A -> B -> C -> A plus multi-selection if supported.

A related but DIFFERENT prior bug
([[hierarchy-tree-camera-focus-on-add-point-regression]]) already exists for
this same tree - that one was about `ESelectInfo::Direct` incorrectly
triggering camera focus on programmatic changes. This is a separate defect
in the same area, not a recurrence of that one.

## Investigation

`SNexusFrameworkPanel::SyncTreeSelectionFromSubsystem()`
(`SNexusFrameworkPanel.cpp:1508-1562`) is the function that pushes the
subsystem's `ActiveSelectionKind`/`ActiveSelectionId` onto the tree widget's
own selection state, called after every selection-changing action (tree
click, native viewport click, Delete, etc.). It has two paths:

- `SelectionKind == None` (nothing active): correctly calls
  `TreeView->ClearSelection()`.
- A real item found (`SelectionKind != None`, `FindOutlinerItemPath`
  succeeds): called `TreeView->SetItemSelection(Found, true,
  ESelectInfo::Direct)` - **with no preceding `ClearSelection()`**.

Read Slate's own implementation directly (`SListView.h`, UE 5.8) rather than
assuming behavior:

```cpp
// SListView.h:1955
void SetItemSelection(const ItemType& InItem, bool bSelected, ESelectInfo::Type SelectInfo)
{
    ...
    Private_SetItemSelection(InItem, bSelected, SelectInfo != ESelectInfo::Direct);
    ...
}

// SListView.h:1189
virtual void Private_SetItemSelection(ItemType TheItem, bool bShouldBeSelected, bool bWasUserDirected) override
{
    ...
    if (bShouldBeSelected) { SelectedItems.Add(TheItem); }   // <- purely additive
    else                    { SelectedItems.Remove(TheItem); }

    // Single/SingleToggle mode only updates SelectorItem/RangeSelectionStart
    // (keyboard range-select bookkeeping) here - it does NOT clear
    // SelectedItems. There is no other enforcement of exclusivity anywhere
    // in this function.
    if (bWasUserDirected || GetSelectionMode() == ESelectionMode::Single || ...) { ... }
}
```

**`SetItemSelection()` is purely additive, even when `SelectionMode` is
`Single`.** `Single` mode is not self-enforcing for programmatic calls - it
only affects keyboard-navigation bookkeeping. A genuine mouse click behaves
correctly on its own because Slate's internal click-handling path clears the
previous selection itself before calling this; a direct C++
`SetItemSelection()` call does not get that same courtesy - the caller is
responsible for clearing first, exactly as the `None` branch above already
(correctly) does.

Compounding factor confirmed alongside this: `RefreshHierarchy()`
(`:1399-1433`) does `RootItems.Reset()` then rebuilds every
`FNexusOutlinerItem` from scratch on every call. The previously-selected
item is a different C++ object than anything in the new tree after a
refresh, so it could never have been naturally reconciled away either - the
missing `ClearSelection()` is the actual defect regardless of whether a
refresh happened in between.

Also present in Slate: `SetSelection(ItemType SoleSelectedItem,
ESelectInfo::Type SelectInfo)` (`SListView.h:2144`) - "Set the currently
selected Item" - implemented as exactly `SelectedItems.Empty(); then
SetItemSelection(...)` (`Private_SetSelection`, `:2154-2158`). This is the
correct, already-existing, purpose-built API for "replace the whole
selection with just this one item," not something that needed to be
hand-rolled.

Checked `SNexusSyncInspectorPanel.cpp` for the same anti-pattern (per "check
all relevant paths") - it has no `SetItemSelection`/`SetSelection` calls at
all, not affected.

## Root cause

`SyncTreeSelectionFromSubsystem`'s "found an item" branch called the
additive `SetItemSelection()` instead of the exclusive `SetSelection()` (or
an explicit `ClearSelection()` first, matching its own `None` branch) -
every previously-selected row's item stayed in `TreeView`'s internal
`SelectedItems` set forever, so its row kept rendering as highlighted
alongside whatever was selected next.

## Changes

`SNexusFrameworkPanel.cpp:1559` - one-line fix:

```cpp
// Before:
TreeView->SetItemSelection(Found, true, ESelectInfo::Direct);
// After:
TreeView->SetSelection(Found, ESelectInfo::Direct);
```

No other logic touched - `bIsSyncingTreeSelection` guard, ancestor
expansion, `RequestScrollIntoView` all unchanged. Not a visual-only
workaround: this fixes the actual Slate selection SET (`SelectedItems`),
which is also what every row's highlight rendering (`IsSelected()`) reads
from - the highlight is a direct consequence of this state, not a separate
thing being patched independently.

## Build

`Build.bat NexusFrameworkEditor Win64 Development -project=... -waitmutex` -
**Result: Succeeded**, 10/10 actions, 0 errors (built together with the
debug-overlay-freeze fix in the same pass - see
[[debug-overlay-freezes-on-tab-switch]]).

## Verification - NOT yet performed by the agent

No GUI-automation capability, per [[user-builds-and-verifies]]. Hand-off:
1. Build/reload the editor.
2. Select Point A (via tree click or native viewport click) - confirm A
   highlights.
3. Select Point B - confirm B highlights AND A's row is no longer
   highlighted.
4. Repeat A -> B -> C -> A and confirm only ever one row highlighted at a
   time, including returning to A.
5. Multi-selection: the tree is declared `SelectionMode(ESelectionMode::Single)`
   (`:868`) - there is no existing multi-select capability in this tree to
   verify (not a gap introduced by this fix; simply out of scope, as the
   tree was never built to support it).
6. Also sanity-check State/City/Highway row selection (not just Point) -
   `SyncTreeSelectionFromSubsystem` is shared code for every selection kind,
   so the fix applies uniformly, but worth confirming nothing about a
   non-Point selection kind behaves differently.

## Result

Root cause proven via direct Slate engine source reading (not assumed):
`SetItemSelection()` is additive even in Single mode; the fix uses the
already-existing purpose-built `SetSelection()` API instead. One-line change,
no visual/cosmetic workaround, no unrelated behavior touched.
