# Imported Connector delete not persisting, and split-point-in-existing-highway duplication, on Save -> Load

Date: 2026-08-09
Category: bug-fixed

## Context

Two user-reported bugs, suspected related:

1. Deleting an "Imported Connector N" highway (the synthetic 2-point highway
   `SyncFromLandscape`'s Direction 3 creates for a divider/diagonal whose
   endpoints are both already-tracked points - see
   `closed-loop-and-divider-save-load.md`) via the Hierarchy tree's Delete
   action, then Save -> Load, brings it back.
2. Inserting a new control point mid-way along an existing highway (clicking
   an existing Landscape spline segment to split it into two) inside a
   closed-loop highway, then Save -> Load, produces TWO parallel paths
   between the same two points - the new split-in point's real segments,
   plus the highway's own stale direct old adjacency, resurrected.

## Findings

Both trace to the same architectural gap: `SyncFromLandscape`'s Direction
2/3 (which runs automatically before every Save, see
`closed-loop-and-divider-save-load.md`) only ever ADD missing WorldData
adjacencies to match live Landscape geometry - nothing ever REMOVES or
UPDATES a WorldData adjacency whose underlying live segment changed or
disappeared. `MaterializeMissingPointGeometry` (Load) blindly recreates
ANY `OrderedPointIds`-implied adjacency that isn't currently live, with no
way to distinguish "genuinely never materialized yet" (correct to recreate
- the normal fresh-Load case) from "was deliberately changed/removed by the
user natively since the last sync" (wrong to recreate).

1. **Bug 1 root cause**: `OnLandscapeSplineObjectTransacted` has no
   segment-DELETE handler (a pre-existing, already-documented gap - see
   `project_v5_landscape_nexus_two_way_sync.md`, "Segment DELETE still
   unhandled"). Selecting the connector's road mesh/segment directly in
   Landscape Mode and pressing Delete removes the native
   `ULandscapeSplineSegment`, but WorldData's own 2-point "Imported
   Connector" highway record survives completely untouched. On the next
   Save -> Load, `MaterializeMissingPointGeometry`'s pairwise walk finds the
   highway's two points not connected and recreates the segment - the exact
   thing the user just deleted.

2. **Bug 2 root cause**: confirmed directly from
   `BuildChainsFromUntrackedPoints`'s own pre-existing doc comment: "an
   untracked run attached to an existing highway is still imported as its
   own separate highway rather than splicing into the existing one, since
   OrderedPointIds has no 'insert mid-sequence at this Landscape connection'
   concept" - a documented, known limitation, not a regression. A point
   split into an existing chain gets imported by Direction 2 as a
   disconnected standalone "Imported Highway", while the ORIGINAL highway's
   `OrderedPointIds` still lists the two now-separated neighbors as directly
   consecutive (nothing ever removes that stale entry). On Load,
   `MaterializeMissingPointGeometry` recreates that stale direct adjacency
   (no live segment currently connects them, so its "missing -> materialize"
   rule fires), sitting right alongside the real new segments through the
   split-in point(s).

## Changes

All in `NexusFrameworkEditorSubsystem.cpp`, inside `SyncFromLandscape`:

1. **New Direction 2.5 (splice), inside Direction 2's chain-import loop.**
   For a non-closed-loop chain whose both free ends each touch exactly one
   already-tracked point (`FindExternalTrackedNeighbor`, new helper; a
   length-1 chain checks for exactly 2 already-tracked neighbors instead,
   since its single point IS both free ends) - if those two already-tracked
   points (X, Y) are themselves currently adjacent (consecutive, or a
   closed-loop's own wraparound pair) somewhere in WorldData
   (`TryFindSpliceSite`, new helper, mirrors `IsAdjacencyRepresentedInWorldData`'s
   walk but also returns exactly where/how to insert), the chain is spliced
   into that highway's `OrderedPointIds` at the correct index in the correct
   orientation (reversed if needed - same "reorient so the join reads
   correctly" idiom as `MergeHighwaysForNewSegment`'s own ChainA/ChainB
   reversal) instead of being imported as a disconnected standalone highway.
   Reclassifies only the new points plus the two existing neighbors (not the
   whole highway, to avoid touching unrelated points' Rotation given the
   open quat-crash investigation).
2. **New Direction 4, after Direction 3.** Removes any highway with exactly
   2 points where BOTH points are ALSO shared with at least one other
   highway (the exact shape Direction 3 always creates, and the only shape
   safe to prune - removing it can never orphan either point, since each
   still belongs to its original highway) whose two points are no longer
   actually connected by a live segment. Mirrors Direction 3 in reverse.

## Verification

Brace/paren balance and non-ASCII check clean
(`OpenBrace=701 CloseBrace=701 OpenParen=2766 CloseParen=2766`,
`NonAsciiCount=0`).

**Build: Succeeded.** `Build.bat NexusFrameworkEditor Win64 Development`
ran directly (editor was closed, no Live Coding block) - `Result: Succeeded`.

**NOT YET independently function-tested by the user** - build success only.
Scenarios still to confirm:
- Delete an Imported Connector, Save, Load -> stays deleted.
- Split a point into an existing (including closed-loop) highway via native
  click-on-segment, Save, Load -> single correct path, highway's own
  identity/order preserved, no duplicate.
- Repeated Sync From Landscape / Save does not re-duplicate either case
  (idempotency, same reasoning as the sibling closed-loop/divider fix).
- Normal open highways, plain divider/connector creation, closed-loop
  creation - all still round-trip correctly (unchanged code paths).

## Important Notes

- Direction 4 is deliberately scoped ONLY to exactly-2-point highways where
  both points are shared elsewhere - a longer highway losing a genuine
  MID-CHAIN segment (not at a shape Direction 3 ever creates) is a
  different, currently still-unhandled case, not reported by the user and
  out of scope here.
- Did not touch the live `OnLandscapeSplineObjectTransacted` callback path
  at all (segment-delete handling) - both fixes live entirely in the
  already-established Save-time reconciliation pattern
  (`SyncFromLandscape`), lower-risk than extending the more fragile,
  crash-history-laden live-sync callback.
