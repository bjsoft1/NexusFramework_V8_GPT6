# Debug labels/overlays freeze when switching away from the Nexus Framework tab or Editor Mode

Date: 2026-08-09
Category: bug-fixed

## Context

User-reported: after loading a layout with the Debug checkbox enabled, the
viewport correctly shows Highway/Point/City/State labels and updates as the
camera moves. Switching to a different dockable tab (Nexus Sync Inspector,
or the native Landscape Mode panel) - or switching Editor Mode to Select
Mode - freezes the labels at whatever they last showed; they don't clear,
don't error, just stop updating. Returning to the Nexus Framework tab
immediately makes them correct again. Explicitly asked for the actual
invalidation/update lifecycle to be fixed, not a disable/recreate
workaround.

## Investigation

`UNexusFrameworkEditorSubsystem::DrawDebugOverlays()` (the function that
draws every debug line/sphere/box AND drives
`FNexusDebugLabelOverlay::UpdateLabels()` for the world-space text labels,
per that class's own doc comment: "called explicitly every frame by
DrawDebugOverlays instead of an automatic per-frame engine callback") had
exactly ONE caller in the entire codebase: `SNexusFrameworkPanel::Tick()`
(`SNexusFrameworkPanel.cpp:226-228`), called unconditionally every tick of
that one Slate widget.

`SNexusFrameworkPanel` is the content widget of the "Nexus Framework"
dockable tab (`FNexusFrameworkLandscapeModeExtension::SpawnNexusFrameworkTab`).
Slate only ticks a widget while it is part of the actively-rendered widget
tree - a dock tab's content is not ticked while a DIFFERENT tab in the same
dock area is the active/foregrounded one (standard Slate/docking-framework
behavior, not specific to this project). This exactly explains both
reported triggers:
- Switching to Sync Inspector or Landscape Mode's own panel: a different tab
  becomes active in the same dock well, so `SNexusFrameworkPanel::Tick()`
  stops firing.
- Switching Editor Mode to Select Mode:
  `FNexusFrameworkLandscapeModeExtension`'s own class doc comment confirms
  the Nexus Framework tab is shown/hidden in lockstep with Landscape Mode
  being active - leaving Landscape Mode hides the tab entirely, same
  underlying effect (no ticking).

The world-space text labels (`FNexusDebugLabelOverlay`, pooled `STextBlock`s
positioned via `WorldToScreen` each `UpdateLabels()` call) have no
expiration mechanism of their own - they simply stay wherever they were last
positioned until the next call, which is why they read as "frozen" rather
than disappearing (the `DrawDebugLine`/Sphere/Box calls, by contrast, use
`bPersistent=false` with a 0.05s `LifeTime` and WOULD visibly vanish within
a frame or two of ticking stopping - the freeze is most obviously visible on
the labels specifically for this reason, though the whole overlay system was
affected).

Confirmed `DrawDebugOverlays()` is already fully internally defensive and
therefore safe to call unconditionally from anywhere:
- `if (!DebugDrawState.bShouldDrawDebug) { return; }` (first line) - the
  user's own Debug checkbox remains the real on/off control.
- Null-checks `GEditor`/`GetEditorWorldContext().World()`.
- `if (LabelOverlay) { ... }` before touching the label overlay.

## Root cause

The debug-draw/label update was wired to a Slate widget's `Tick()` - a
lifecycle tied to "is this specific dock tab currently the visible one,"
which is the wrong lifecycle for a world-space viewport visualization that
should be independent of arbitrary UI tab focus.

## Fix

`UNexusFrameworkEditorSubsystem` now also inherits `FTickableEditorObject`
(`NexusFrameworkEditorSubsystem.h`) - a standard engine mechanism for
"tick this every editor frame regardless of any Slate widget's
visibility/mount state," used by several real engine classes for exactly
this reason (e.g. `UEditorConfigSubsystem` combines `UEditorSubsystem` +
`FTickableEditorObject` the same way, confirmed via engine source as a real,
supported precedent - not a novel pattern). Its registration is tied to the
subsystem's own C++ object lifetime (a `UEditorSubsystem`, alive for the
whole editor session), not to any dock tab or Editor Mode.

```cpp
// NexusFrameworkEditorSubsystem.h
class NEXUSFRAMEWORKEDITOR_API UNexusFrameworkEditorSubsystem : public UEditorSubsystem, public FTickableEditorObject
{
    ...
    virtual void Tick(float DeltaTime) override;
    virtual TStatId GetStatId() const override;
};
```

```cpp
// NexusFrameworkEditorSubsystem.cpp
void UNexusFrameworkEditorSubsystem::Tick(float DeltaTime)
{
    DrawDebugOverlays();
}

TStatId UNexusFrameworkEditorSubsystem::GetStatId() const
{
    RETURN_QUICK_DECLARE_CYCLE_STAT(UNexusFrameworkEditorSubsystem, STATGROUP_Tickables);
}
```

`SNexusFrameworkPanel::Tick()`'s own `Subsystem->DrawDebugOverlays();` call
removed (now redundant - would otherwise double-draw every frame the panel
happens to also be visible). `SyncActiveSelectionFromNativeViewportSelection()`
and `RemoveOrphanedPointsFromLandscape()`, called from the same block, were
deliberately left untouched - out of scope for this specific bug report (the
user asked about debug labels; those two are a different concern and were
not reported as broken), per "do not refactor unrelated systems."

Not a disable/recreate workaround: `DrawDebugOverlays()`/`FNexusDebugLabelOverlay`
themselves are completely unchanged - only WHERE the per-frame call
originates from was moved, to the correct lifecycle owner.

## Build

`Build.bat NexusFrameworkEditor Win64 Development -project=... -waitmutex` -
**Result: Succeeded**, 10/10 actions, 0 errors (built together with
[[hierarchy-tree-stale-highlight-on-reselect]] in the same pass).

## Verification - NOT yet performed by the agent

No GUI-automation capability, per [[user-builds-and-verifies]]. Hand-off:
1. Build/reload the editor.
2. Load a layout with the Debug checkbox enabled - confirm labels/lines show
   and track the camera as before (no regression in the normal case).
3. Switch to the Nexus Sync Inspector tab - move the viewport camera -
   confirm labels/lines now continue updating instead of freezing.
4. Switch Editor Mode to Select Mode - move the camera - confirm the same.
5. Return to the Nexus Framework tab / Landscape Mode - confirm still
   correct, no leftover double-drawn lines or duplicated labels from having
   two update sources briefly overlap during the transition.
6. Toggle the Debug checkbox off while on a different tab - confirm the
   overlay actually clears/stops (proves `bShouldDrawDebug` is still the
   real gate, not just "always on now").

## Result

Root cause identified via direct reading of this project's own Tick call
site plus Slate/docking lifecycle behavior (not assumed): the debug overlay
was driven by a specific dock tab's widget Tick instead of a tab-independent
per-frame source. Fixed by moving the trigger to `FTickableEditorObject`
(the subsystem's own tick), a real, precedented engine pattern for exactly
this class of problem - the underlying invalidation/update lifecycle is what
changed, not the drawing logic itself.

## Follow-up — 2026-08-09 (2) — second, distinct freeze trigger: labels never clear when debug drawing turns off (incl. via Load Layout)

User tested the tab-switch fix above and confirmed it worked for that
specific trigger, but reported a NEW/separate repro: "when i load new layout
from far the old label still freeze" - loading a different Layout asset
left old, stale world-space labels frozen on screen instead of clearing or
updating for the new layout.

### Root cause

`DrawDebugOverlays()`'s very first line is `if (!DebugDrawState.bShouldDrawDebug)
{ return; }`. `LoadLayout()` (`:1951`, pre-existing, unrelated to the
tab-switch fix) does `DebugDrawState = Asset->DebugDrawState;` - the Debug
master/category toggles are per-Layout saved state (`WriteWorldDataToAsset`
mirrors this on Save), not a global editor setting. Loading a DIFFERENT
Layout asset that happens to have been saved with `bShouldDrawDebug` off (or
simply different category toggles) silently changes the live
`DebugDrawState` out from under the user.

The early return above skips EVERYTHING below it, including the
`LabelOverlay->UpdateLabels(LabelRequests)` call at the very end of the
function. The `DrawDebugLine`/Sphere/Box calls elsewhere in this function
are fine with that - they use `bPersistent=false` with a 0.05s `LifeTime` and
self-expire once stop being reissued. `FNexusDebugLabelOverlay`'s pooled
`STextBlock`s have no such auto-expiry (confirmed by re-reading
`UpdateLabels()`, `NexusDebugLabelOverlay.cpp:77-133` - the only place that
ever calls `SetVisibility(EVisibility::Collapsed)` on a pooled entry) - if
`UpdateLabels()` simply never runs again, they stay exactly as last shown,
forever.

Found the exact wrong assumption already baked into a comment at the
checkbox handler, `SNexusFrameworkPanel::OnDebugBoolChanged` (`:691-693`):
*"No viewport-refresh call needed, unlike most other button/checkbox
handlers in this panel - DrawDebugOverlays already reads the live
DebugDrawState fresh every Tick, no cached state to invalidate."* True for
the `DrawDebugLine` calls, false for the label overlay - this same defect is
reachable simply by unchecking the master "Should Draw Debug" checkbox by
hand, independent of Load Layout entirely; Load is just the trigger the user
happened to hit first (loading a layout with different saved debug settings
than what was showing).

Confirmed the "requests shrink but stay non-zero" case (e.g. loading a
layout with fewer visible categories, but `bShouldDrawDebug` still true) was
ALREADY handled correctly - `UpdateLabels()`'s pool-hiding loop
(`Index >= Requests.Num()` -> `Collapsed`) runs every time the function
doesn't early-return, confirmed by direct reading, not assumed. Only the
`bShouldDrawDebug == false` top-level early return had this gap.

### Fix

`DrawDebugOverlays()`'s early return now explicitly clears the label overlay
before returning:

```cpp
if (!DebugDrawState.bShouldDrawDebug)
{
    if (LabelOverlay)
    {
        LabelOverlay->UpdateLabels(TArray<FNexusDebugLabelRequest>());
    }
    return;
}
```

An empty request array makes every pooled label collapse via the existing
`Index >= Requests.Num()` branch - reuses `UpdateLabels()`'s own established
hide mechanism rather than adding a new one. `DrawDebugLine`/Sphere/Box
calls, the rest of `DrawDebugOverlays()`, and `FNexusDebugLabelOverlay`
itself are otherwise untouched.

The second early-return a few lines later (`if (!World) { return; }`) was
deliberately NOT given the same treatment - no plausible path for the
editor world to go null specifically around a Nexus Layout load (the load
only swaps `WorldData`/Landscape geometry, never the `UWorld` itself), so
this would be speculative, not a confirmed gap; left alone per "do not
refactor unrelated systems."

### Build

`Build.bat NexusFrameworkEditor Win64 Development -project=... -waitmutex` -
**Result: Succeeded**, 4/4 actions (incremental), 0 errors.

### Verification - NOT yet performed by the agent

1. Enable Debug, confirm labels show and track the camera as normal.
2. Uncheck the master "Should Draw Debug" checkbox directly (no Load
   involved) - confirm labels now disappear immediately instead of freezing.
   Re-check it - confirm they resume.
3. With Debug on and labels showing, Load a DIFFERENT layout that was saved
   with Debug off (or fewer categories checked) - confirm old labels clear
   instead of freezing, and the Debug section's own checkboxes in the panel
   correctly reflect the newly-loaded layout's saved state (not the old
   layout's).
4. Load a layout saved WITH Debug on - confirm labels correctly update to
   the new layout's own Highway/Point/City/State content.

### Result

Second, distinct root cause for the same reported symptom class found via
direct source reading (not assumed): `DrawDebugOverlays()`'s master-toggle
early return skipped the one call that can hide already-shown world-space
text labels, and `DebugDrawState` is per-Layout saved state that Load Layout
legitimately changes. Fixed by clearing the label overlay explicitly before
that early return, reusing its own existing hide mechanism. Independent of,
and does not modify, the earlier `FTickableEditorObject` fix in this same
file - both were necessary, addressing two different ways the labels could
stop updating.
