# Architecture change: Save is pull-only, landscape is authoritative

Date: 2026-08-09
Category: others (architecture decision)

## Context

User's own words, following the closed-loop+diagonal crash investigation
(`bug-fixed/2026-08-09/quat-not-normalized-crash-on-load.md`) and a
suspicion that Save silently mutating live Landscape geometry might be
contributing to the crash risk:

> when UE get save then refresh into our system then do not refresh UE.
> just fully refresh our system... My main goal is which we seeing on
> landscape those all info should as it is save on my DB after load same
> previously seeing this 100% accurately load in Landscape... our
> character move in the highway (landscape segment points) - if some
> segment missing in Editor and exist those info in our system so after
> game play maybe not [gives] accurate result. so the UE is always good.
> our system maybe missed, due to UE has many hidden features so we
> currently cannot implement those all places so best solution is replace
> our data by UE always.

Important context this reveals: `WorldData` isn't just an editor-tree
display concern - it's consumed at RUNTIME (gameplay/character movement
along highway/segment data), so drift between what's visually on the
Landscape and what `WorldData` records is a correctness bug, not just a
cosmetic one.

## Design decided

**Save (and the manual "Sync From Landscape" button, same underlying
function) is now 100% pull-only**: it may read from the live Landscape
into `WorldData` (topology bookkeeping - new/orphaned points, new/dead
connector adjacencies, geometry snapshots) and it may remove/add WorldData-
only records, but it must NEVER mutate the live Landscape itself (no more
`RecomputePointClassification`/`ApplyMeshSetToControlPoint`/
`ApplyPointFurniture` calls anywhere in this path). The Landscape's own
current state (whatever mesh/rotation the native tool or a prior Build
Landscape left on a point) is authoritative and is pulled as-is.

**Build Landscape (renamed from "Apply Configuration") is now the ONLY
place Nexus pushes its own config onto the Landscape** - mesh, scale,
half-width, junction rotation/tangent recompute, furniture. After pushing,
it immediately syncs the result back into `WorldData`'s own Location/
Rotation/Tangent cache (previously this only happened lazily at the next
Save), so `WorldData` never sits stale relative to what Build Landscape
just did.

**Nexus-only data (State/City/Highway identity, Code/Name, per-entity mesh/
generation/terrain overrides, per-point config) is never touched by any of
this** - it has no Landscape equivalent, so it's preserved exactly as
authored regardless of how many times pull-only reconciliation runs.

## Changes

`NexusFrameworkEditorSubsystem.cpp`:

1. **`SyncFromLandscape`**: removed all three landscape-mutating call
   sites that existed inside it (added earlier the same day):
   - The Direction 2.5 splice branch's reclassify-new-points-and-neighbors
     block.
   - Direction 2's standalone-"Imported Highway"-import classification
     loop.
   - Direction 3's "Imported Connector" classification of both endpoints.
   Each replaced with a comment explaining the deferral. Topology
   bookkeeping (which points exist, which highway/adjacency they belong
   to, closed-loop detection, orphan removal, geometry snapshot capture)
   is unchanged - only the "also push a computed mesh/rotation onto the
   live control point" side effect was removed.
2. **`ApplyHighwayConfiguration`**: added a `SyncPointGeometrySnapshots()`
   call at the very end, after the existing `RebuildAllSplines()`/
   `MarkPackageDirty()` block - captures the Landscape's own post-Build
   Location/Rotation/Tangent back into `WorldData` immediately, not just
   at the next Save. `ApplyAllConfiguration` gets this for free (it loops
   `ApplyHighwayConfiguration` per highway).

`SNexusFrameworkPanel.cpp`: renamed the button's visible label from
"Apply Configuration" to "Build Landscape" (`OnApplyConfigurationClicked`/
`IsApplyConfigurationEnabled`/the LOCTEXT key itself left as internal
identifiers - only the user-facing string changed, to keep this a small,
low-risk rename rather than a wide identifier refactor).

## What was deliberately NOT changed

- `MaterializeMissingPointGeometry` (Load) still classifies/meshes every
  point it materializes - this is legitimate: Load is reconstructing the
  Landscape FROM WorldData (the opposite direction, WorldData -> Landscape),
  not pulling FROM the Landscape, so it's not part of the "Save shouldn't
  push" concern at all.
- `GenerateCityInternalGrid`/`PlacePointOnLandscape`/the live incremental
  sync callbacks (`OnLandscapeSplineObjectTransacted` ->
  `TryAdoptNewLandscapePoint`/`TryRegisterNewLandscapeSegment`/
  `TryAdoptFirstLandscapePoint`) still classify/mesh immediately - these
  are explicit, real-time user actions (drawing/generating), giving
  immediate visual feedback while editing, not a Save-time side effect.
  Out of scope for this change.
- No attempt made at a full "rebuild highway OrderedPointIds/adjacency
  purely from the live segment graph" redesign (replacing Direction 1-4's
  incremental diffing with a from-scratch rebuild) - the user's specific
  reported bug (deleted diagonal reappearing after Save->Load) is already
  handled by the existing Direction 4 (added earlier the same day, see
  `bug-fixed/2026-08-09/imported-connector-and-split-point-save-load-
  duplication.md`) and the user confirmed no further investigation was
  needed there. A from-scratch full-rebuild is a substantially larger,
  riskier redesign (handling arbitrary mid-chain highway splits, not just
  the 2-point-connector shape) - flagged as a possible future direction if
  a case Direction 1-4 doesn't cover is ever found, not attempted here.

## Verification

Brace balance clean (698/698). **Build: Succeeded** (`Build.bat
NexusFrameworkEditor Win64 Development`, editor closed, no Live Coding
block).

**NOT YET independently verified by the user.** To confirm: draw new
geometry (a diagonal, a split point) natively, Save (without clicking
Build Landscape first) - the new topology should be tracked in WorldData
and survive Load, but should NOT get an auto-assigned junction mesh/
rotation until Build Landscape is explicitly clicked afterward. After
clicking Build Landscape, the Sync Inspector (if opened) should show no
Mismatch even before the next Save.

## Important Notes

- This is a genuine behavior change from earlier today's own Direction 2/3
  work (which DID auto-classify newly-discovered geometry as a
  convenience) - a real regression in "convenience," not a bug, per the
  user's explicit, deliberate choice.
- If a future session is asked "why doesn't a freshly hand-drawn junction
  have a proper mesh after Save/Load," this is why - point at Build
  Landscape, not a bug.
