# Landscape Spline topology - engine mechanics notes

Date: 2026-08-09
Category: others

## Context

General, reusable engine-mechanics notes discovered while fixing the closed-loop/divider
save-load data loss (see `../bug-fixed/closed-loop-and-divider-save-load.md`). Kept
separately from that bug record because these are standing facts about how
`ULandscapeSplineControlPoint`/`ULandscapeSplineSegment` work, useful for any future
topology-touching change, not just this one fix.

## `FLandscapeSplineConnection::GetFarConnection()` is the walk primitive

`ControlPoint->ConnectedSegments` is `TArray<FLandscapeSplineConnection>`, each entry a
`{Segment, End}` pair. `Connection.GetFarConnection()` returns the connection info at the
OTHER end of that same segment (`Segment->Connections[1 - End]`) - `.ControlPoint` on the
result is "the point at the other end of this segment." This is the one primitive every
topology-walking function in this codebase already uses
(`BuildChainsFromUntrackedPoints`, `SyncPointGeometrySnapshots`,
`OnLandscapeSplineObjectTransacted`'s segment branch, and the new Direction 3 connector
detection) - there is no engine-provided multi-hop chain-walk utility; every "walk a chain"
implementation in this file hand-rolls it from this one-hop primitive.

## No native segment/adjacency idempotency guarantee

`NewObject<ULandscapeSplineSegment>(...)` + manually pushing an `FLandscapeSplineConnection`
onto both endpoints' `ConnectedSegments` (what `ConnectControlPointsWithSegment` does) will
happily create a SECOND, parallel segment between two points that are already connected -
the engine does not deduplicate this. Any reconciliation-style code (code that might run
more than once over the same already-correct data, as opposed to code that only ever
touches a point/segment the instant it's freshly created) MUST check first. New helper for
this: `AreControlPointsConnected(const ULandscapeSplineControlPoint* A, const
ULandscapeSplineControlPoint* B)` (anonymous namespace, `NexusFrameworkEditorSubsystem.cpp`,
near `ConnectControlPointsWithSegment`'s own definition) - walks `A->ConnectedSegments`
checking `GetFarConnection().ControlPoint == B`. This was a genuinely pre-existing gap in
`MaterializeMissingPointGeometry`'s own pairwise walk (not hypothetical - confirmed by
reading the code, it had zero such check before this session), now fixed there and reused
for the new closed-loop-closing connection and the Direction 3 connector pass.

## Existing crash/workaround comments audited before this change (none touched)

Per explicit instruction, searched the whole `NexusFrameworkEditor` module for
crash/workaround/ensure/limitation comments before touching any segment/selection logic.
Confirmed still-current and NOT modified by this session's work:

- `RefreshLandscapeSelectionHighlight()`/`DetectAndClearHighlightIfOverriddenByViewport()`
  (`NexusFrameworkEditorSubsystem.cpp`) - viewport highlight DISABLED, unconditional early
  `return`, original body kept as a comment. Root cause: `SetSplineSelected(bool)` flips the
  same `bSelected` flag Landscape Mode's own private, module-local
  `ULandscapeSplineSelection` tracks in its own separate array, and asserts the two never
  desync (`ControlPoint->IsSplineSelected()`, `LandscapeSplineSelection.cpp:105`) - confirmed
  via a real crash dump. No accessor/event exists to safely coordinate with it. This
  session's changes never call `SetSplineSelected` - not implicated, left exactly as-is.
- The cross-map `SourcePoint` guard (`IsControlPointOnTargetLandscape`, added earlier this
  session - see the migrated cross-map-sourcepoint-bug record) - this session's new
  `ControlPointToPointId` map (feeding the new Direction 3 connector-detection pass in
  `SyncFromLandscape`) is now ALSO gated by this same guard, since Direction 3 actively
  walks a point's `ConnectedSegments` (a different map's segment graph entirely, for a stale
  cross-map `SourcePoint`) rather than just doing a `Contains()` membership test the way
  `TrackedControlPoints` does - deliberately narrower gating than that existing set, see the
  bug-fixed record for the exact reasoning.
- `OnLandscapeSplineObjectTransacted`'s nested-transaction constraint (never open a NEW
  `FScopedTransaction` from inside this callback - `Modify()` only, joins the already-open
  transaction) - not touched; this session's new `SyncFromLandscape` reconciliation runs from
  an explicit user/save-time call path (already has its own `FScopedTransaction`), never from
  inside the live `OnObjectTransacted` callback.

## Result

Notes only - no code change from this file itself. Referenced by
`../bug-fixed/closed-loop-and-divider-save-load.md`.
