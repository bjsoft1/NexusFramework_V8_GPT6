---
name: category-max-two-levels
description: "UPROPERTY Category strings must be at most 2 pipe-separated levels, formatted as NexusStructName|Subcategory, not Nexus|StructName|Subcategory."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 1ebdb727-a1c2-4779-b2e2-4c352ef30479
  modified: 2026-08-07T14:42:39.011Z
---

`UPROPERTY(..., Category = "...")` strings across the V5 schema (see [[v5_schema_folder_layout]]) must be at most 2 pipe-separated segments. The struct-name prefix and "Nexus" are merged into one segment: `NexusState`, `NexusCity`, `NexusHighway`, `NexusPoint` — not `Nexus|State`, `Nexus|City`, etc. A subcategory adds exactly one more segment: `NexusCity|Internal Roads`, `NexusHighway|Lanes`, `NexusState|Streaming` — never a third level like `Nexus|City|Internal Roads`.

**Why:** User's own example: "Nexus|City|Internal Roads ... should this format: NexusCity|Internal Roads" — explicit instruction to cap category nesting at 2 levels for readability in the UE Details panel.

**How to apply:** When adding a new UPROPERTY to any Schema/Editor or Schema/Runtime struct, use `Category = "Nexus{StructName}"` with no subcategory, or `Category = "Nexus{StructName}|{Subcategory}"` if grouping is useful — never introduce a third pipe-separated level. Runtime structs already followed a flat `NexusFinal`/`NexusStation|Segments`-style convention and needed no changes when this was applied; only the Editor structs (`Schema/Editor/*.h`, which had inherited V4's `Nexus|Highway|Lanes`-style 3-level categories) were reformatted.
