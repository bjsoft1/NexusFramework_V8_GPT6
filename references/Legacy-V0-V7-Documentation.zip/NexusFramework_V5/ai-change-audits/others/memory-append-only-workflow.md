---
name: feedback_memory_append_only
description: "User wants memory files treated as an append-only historical log - never edit/rewrite existing lines (including frontmatter), only add new sections at the end."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8c39eae7-0f64-4ea9-b261-8f332775fe5a
  modified: 2026-08-08T12:16:35.834Z
---

When updating a memory file for an ongoing project (e.g. [[project_v5_phase3_landscape_click_to_place]]), only append a new section at the end - do not edit, rewrite, or "clean up" any existing line, including the frontmatter `description`/`modified` fields.

**Why:** user's explicit instruction: "please make sure when you update something do not modify/update memory just append your new things okay. this is reference so, maybe it will harder to debug later." The file is a historical reference/debug trail - retroactively editing earlier entries (even just the summary description) destroys the ability to see exactly what was true/decided at each point in time.

**How to apply:** for any memory file the user is actively treating as a running log (per-session follow-up entries, e.g. the numbered "follow-up #N" sections in the V5 Phase 3 memory), always append a new dated section rather than touching frontmatter or prior sections, even when the frontmatter description has clearly gone stale. This does not necessarily apply to memory files that are NOT structured as a running log (e.g. a memory that's just a single standing fact) - use judgement, but when in doubt for a file with this log-like shape, append only.
