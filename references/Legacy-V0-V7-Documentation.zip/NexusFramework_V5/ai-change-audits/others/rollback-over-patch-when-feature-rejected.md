---
name: feedback_rollback_over_patch_when_feature_rejected
description: "When user rejects a just-built feature as \"not working\" with no specifics, fully roll the code back out (not a feature flag/toggle) and preserve research findings in memory rather than deleting them."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ba6d180c-7c4c-42aa-b8a6-c1389d9efa9c
  modified: 2026-08-08T03:43:07.932Z
---

When the user rejects a freshly-built feature outright (e.g. "this is not working, we will make it advance later"), the correct response is a **full code rollback to the pre-feature state**, not disabling it behind a flag, not leaving it half-in with TODOs, and not trying to guess-fix it further in the same session. Confirmed on the Procedural Terrain Generator ([[project_v5_phase3_landscape_click_to_place]] follow-up #14): user gave no specifics on what was wrong (not a crash, not a build issue - purely "not working"), and explicitly asked to roll back, demote it to a backlog/last-phase task, and keep findings for a future attempt.

**Why**: the user did not ask for a smaller/safer version of the feature or a bugfix - they asked to remove it entirely from the active codebase while keeping the research so a future attempt doesn't re-derive it from scratch. Leaving broken/rejected code in place (even gated off) adds surface area and confusion for zero benefit once the user has said it's not wanted right now.

**How to apply**:
- Delete new files entirely; strip new-feature-only code out of modified shared files line-by-line rather than wholesale-reverting those files (they usually also contain other, still-wanted work).
- After stripping, diff against the last commit / prior known-good state to confirm the removal was surgical - if a file comes back byte-identical (or near-identical) to HEAD, that's strong confirmation nothing unrelated got dragged along.
- Rebuild to confirm the rollback compiles clean before reporting done.
- Write a memory follow-up (not a deletion of the original research entry) documenting: what was rolled back, what was deliberately left untouched and why (e.g. binary/map files with mixed legitimate+rejected changes shouldn't be blindly `git checkout`'d), and which parts of the original research are still believed correct vs. which are the likely actual problem - so a future revisit has a real starting point instead of re-guessing blind.
- If the user's rejection reason is vague ("not working"), note in memory that specific reproduction/feedback should be gathered before the next attempt, rather than re-implementing the same design blind.
