---
name: feedback_user_builds_and_verifies
description: Do not auto-build or auto-launch the editor after code changes in NexusFramework_V5 - user builds and verifies themselves and will report issues.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ba6d180c-7c4c-42aa-b8a6-c1389d9efa9c
  modified: 2026-08-08T09:00:37.070Z
---

Do not automatically run `Build.bat`/UBT or launch `UnrealEditor.exe` after making code changes. Stop once the code change itself is complete (and explain what changed) - let the user build and verify it themselves.

**Why:** explicit correction on 2026-08-08 after a long session where the established pattern had been implement -> build both targets -> launch editor in background -> check log/crash dumps for stability -> report. User wants that build/verify step back under their own control: "next time do not auto build, run verify let them to me. I will build and verify if any issue i will tell you."

**How to apply:** after an edit, it's fine to describe what should be tested/expected, but do not proactively run the build or launch the editor unless the user explicitly asks for a build/verify this time. If the user reports a bug, that's the trigger to investigate/fix code again - not to also start auto-building afterward. This supersedes the build/launch/log-check workflow described throughout [[project_v5_phase3_landscape_click_to_place]]'s earlier follow-ups - that pattern was normal and correct for its time but is now explicitly opted out of going forward.
