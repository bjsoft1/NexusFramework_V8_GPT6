---
name: negative-one-means-global-default
description: "Every width/gap/length/limit/range/distance field in V5's schema defaults to -1 meaning \"inherit global config\", not a concrete number."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 1ebdb727-a1c2-4779-b2e2-4c352ef30479
  modified: 2026-08-07T14:39:53.208Z
---

Any numeric field on a Schema/Editor or Schema/Runtime struct that represents a physical dimension or tunable limit — width, gap, length, limit, range/distance — must default to `-1`, meaning "pull this value from the global config/algorithm instead of using a per-instance override." `0` means explicitly disabled/no-width-at-all for that feature (distinct from -1). A positive value is a real per-instance override.

**Why:** User's own words: "most of the value is same so, global is fine just some need override so, set as -1." Most highways/points/stations in a large world (V5's whole premise — see [[v5_hierarchy_redesign]]) will use the same lane widths, sidewalk widths, speed limits, etc., pulled from one global settings asset (`UNexusGenerationSettings` in V4's pattern); per-instance fields exist only for the rare highway/station that needs to deviate. Defaulting to a concrete number (e.g. `LaneWidth = 350.f`) silently makes every authored instance a "custom override" even when the author never touched it, defeating the point of having a global config at all.

**How to apply:** When adding a new width/gap/length/limit/range/distance-shaped field anywhere in `Schema/Editor` or `Schema/Runtime`, default it to `-1.f` (or `-1` for int), and add a one-line comment: `-1 = apply global default. 0 = explicitly disabled. >0 = custom value.` (adjust the "0 =" clause per-field, e.g. "0 = no speed limit" / "0 = no sidewalk on this side" — that clause is field-specific, but the -1/global rule is universal). Applied so far to: `FNexusHighway`/`FNexusFinalHighwayData`'s `SpeedLimit`, `LaneWidth`, `LaneGap`, `CenterMedianGap`, `SidewalkGap`, `LeftSidewalkWidth`, `RightSidewalkWidth`; `FNexusStationInfoBase`'s `SegmentWidth`, `SegmentLength`, `SegmentRow`, `SegmentColumn`; `FNexusDynamicInteractable::ActivationDistance`. Does NOT apply to: bitmask/flag fields (`Features`, `PointTargets`, `AllowVehicles`, `AllowLanes`, `ActiveTimes` — `0` correctly means "none set" there), grid indices (`RowIndex`/`ColumnIndex`), or `OverrideLineThickness` (gated by its own separate `bOverride*` bool flag, a different override mechanism entirely — don't fold it into this rule).
