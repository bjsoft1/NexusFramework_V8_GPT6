---
name: feedback-verify-landscape-changes-not-just-logs
description: "A clean \"N applied\" log line does not mean a UE Landscape edit actually took effect - build a visual debug overlay sourced from the engine's own post-operation data, not from input data, to verify."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: aacde4df-9da2-4e2c-a4b6-d021555a2b61
  modified: 2026-08-07T09:46:59.760Z
---

When making Landscape heightmap/terrain edits (e.g. `ALandscapeProxy::EditorApplySpline`, `FLandscapeEditDataInterface::SetHeightData`) via editor tool code, a clean completion log ("N highway(s) applied, 0 skipped") is NOT proof the edit visually took effect. Confirmed twice in NexusFramework_V4 (E:\Projects\Game\UE\NexusFramework_V4):

1. `EditorApplySpline` silently no-op'd on every call (wrong `EditLayerName` - `NAME_None` doesn't resolve to a real edit layer on a 5.8 Edit-Layers-enabled landscape) while still logging a normal success count, since the function only logs an internal `LogLandscape` error and returns - it never propagates failure back to the caller.
2. After fixing that, calls "succeeded" but produced spike/seam artifacts at every junction where multiple independent `EditorApplySpline` calls overlapped - again nothing in the log revealed this, only visual inspection did.

**Why**: The user's own report each time was "no error but nothing changed" / "line doesn't match" - i.e. they had to eyeball the actual result, because the log was useless as a verification signal.

**How to apply**: When building any Landscape-editing feature, build the debug/visual-verification overlay from the very start, and make sure it sources data from the ENGINE'S OWN post-operation state (e.g. `ULandscapeSplineSegment::GetPoints()`, the real tessellated centerline `LandscapeSplineRaster` used) rather than from the tool's own input data (e.g. our authored `USplineComponent`). Sourcing the overlay from input data only proves the input was sent, not that the engine did what you expected with it - this exact distinction ("used our tangent data" vs "used landscape data") is what let the user visually catch both bugs above. Don't trust a success log for this class of operation; always cross-check against a visualization of the actual engine-side result.
