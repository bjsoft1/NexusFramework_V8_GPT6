---
name: v5-schema-folder-layout
description: "V5's NexusFramework module headers are split into Public/Schema/Editor, Public/Schema/Runtime, and Public/Schema/Shared by the user's explicit request."
metadata: 
  node_type: memory
  type: project
  originSessionId: 1ebdb727-a1c2-4779-b2e2-4c352ef30479
  modified: 2026-08-07T14:58:46.946Z
---

`e:\Projects\Game\UE\NexusFramework_V5\NexusFramework\Source\NexusFramework\Public\` is organized as:

```
Public/
  Schema/
    Editor/     — live authoring structs + editor-only enums (GUID-keyed): NexusState.h, NexusCity.h, NexusHighway.h, NexusRoadPoint.h,
                  NexusRoadGraph.h, NexusRoadTypes.h (SplinePointType, NodeType, AnchorKind, HighwayOwnershipKind, HighwayStateSpan, OutlinerItemType)
    Runtime/    — locked Tier-4 export/dynamic structs (FName-keyed): NexusFinalState.h, NexusFinalCity.h, NexusFinalHighway.h, NexusFinalPoint.h,
                  NexusStationInfo.h (+NexusStationTypes.h), NexusDynamicInteractable.h (+NexusInteractableTypes.h), NexusFrameworkResult.h
    Shared/     — enums used by BOTH Editor and Runtime structs: NexusSharedRoadTypes.h (LaneConfiguration),
                  NexusHighwayFeatureTypes.h (ENexusHighwayFeature highway flags, ENexusHighwayPointFeature point-decoration flags),
                  NexusPointTargetTypes.h (ENexusPointTarget flags, ENexusPointDescription)
```

Nothing lives directly under `Public/` anymore — every header is inside one of the three `Schema/` subfolders. `NexusRoadTypes.h` originally sat at the `Public/` root (a leftover from before the 3-way split existed) and was moved into `Schema/Editor/` once its enums were confirmed editor-only-consumed (user caught this: "NexusRoadTypes.h this is also schema right? categorize Runtime, Shared, Editor if schema").

**Why:** User explicitly distinguishes "Final output" structs (one City/Highway/Point/State) from "editor level" structs (a second City/Highway/Point/State) and asked for them physically separated into different folders, with a third `Shared/` folder for enums both sides use. This is a deliberate three-way split, not incidental organization — don't collapse it back to a flat `Public/` layout or merge Editor+Runtime structs.

**How to apply:** When adding a new field/enum to the schema, decide first whether it's authored-only (goes in `Schema/Editor`), export/dynamic-only (goes in `Schema/Runtime`), or needed by both (goes in `Schema/Shared`) — follow the existing precedent (e.g. `ENexusLaneConfiguration` is Shared because both `FNexusHighway` (Editor) and `FNexusFinalHighwayData` (Runtime) carry it; `ENexusHighwayOwnershipKind`/`ENexusHighwayStateSpan` stayed Editor-only because they're derived from GUID fields that don't exist at runtime). UE's UBT flattens all `Public/` subfolder includes onto one include path, so `#include "NexusX.h"` works regardless of which subfolder a file lives in — no relative/subfolder-qualified include paths needed, matching V4's own include convention. See [[v5_hierarchy_redesign]] for the underlying State→City→Highway→Point hierarchy this schema encodes, and [[v5_final_output_design_port]] for the source design doc this Runtime schema was ported from (including specific fixes applied to it).

**Removed:** `ENexusEntryPointType` (General/BusStop/Parking) was deleted from `NexusSharedRoadTypes.h` along with the `EntryPointType` field on `FNexusRoadPoint`/`FNexusFinalPointData` — the user spotted it was redundant with the richer `ENexusPointTarget` flags + `ENexusPointDescription` fine-grained enum added later in the same session (Station_Bus/Station_Parking already cover BusStop/Parking). If a future session sees a memory or comment mentioning `ENexusEntryPointType`, it's stale — treat `PointTargets`/`Description` as the only point-classification fields now.

**Bitmask-flags-over-bools convention:** the user's pattern for any per-instance boolean decoration set that's likely to grow is a `Shared` bitmask enum (`meta = (Bitflags, UseEnumValuesAsMaskValuesInEditor = "true")` + `ENUM_CLASS_FLAGS(...)`) backing a single `int32` field with `meta = (Bitmask, BitmaskEnum = "...")`, mirrored identically on both the Editor and Runtime struct — not separate `bool bHasX` fields. Applied so far: `ENexusHighwayFeature`→`FNexusHighway::Features`/`FNexusFinalHighwayData::Features`; `ENexusPointTarget`→`PointTargets`; and `ENexusHighwayPointFeature` (TrafficLight, Crosswalk), which replaced the standalone `bHasTrafficLight`/`bHasCrosswalk` bools on `FNexusRoadPoint::PointFeatures`/`FNexusFinalPointData::PointFeatures`. Follow this pattern by default for new point/highway decoration flags rather than adding more bools.
