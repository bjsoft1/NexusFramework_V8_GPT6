---
name: id-code-name-semantics
description: "Every Nexus struct (Editor and Runtime) carries Id/Code/Name with distinct roles - Id is the real primary/foreign key, Code and Name are editable labels never used for cross-references."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 1ebdb727-a1c2-4779-b2e2-4c352ef30479
  modified: 2026-08-07T14:50:15.537Z
---

Every State/City/Highway/Point struct — both `Schema/Editor` (GUID `Id`) and `Schema/Runtime` (FName `Id`, added per this feedback) — carries three identity fields with distinct, non-interchangeable roles:

- **`Id`** — the real primary/foreign key. Stable, never shown to the player, never reused, never hand-edited. All cross-references between structs (`FNexusFinalHighwayData::PointIds`, `OtherStateCityId`, station/interactable anchor fields like `HighwaySplinePointId`/`HighwayId`) point at `Id`, never at `Code`.
- **`Code`** — editable, human-meaningful short label (e.g. `"HB2"`, `"CA1"`). This is what gameplay/audio-trigger logic keys off conceptually (user's examples: "the killer is on highway HB2", "city CA1 is dangerous") — but the trigger system should still resolve that label to the struct's `Id` internally rather than storing/comparing `Code` directly, since `Code` can be renamed.
- **`Name`** — editable, full display label (e.g. `"New York"`), for UI text only.

**Why:** User's own words: "id is unique so, id is primary key... Name and code can editable... if you used code as primary or foreign key so, update id is primary." Before this, the Runtime (`Schema/Runtime`) structs had no `Id` field at all — V4's original rule was "Code is the only runtime cross-reference key, GUIDs are editor-only." The user overrode that: Runtime structs now need their own non-GUID `Id` (`FName`) so `Code` stays freely renameable without breaking any link, matching how the Editor structs already used `FGuid {X}Id` as the real key with `Code`/`Name` as editable labels alongside it.

**How to apply:** When adding a new Runtime (`Schema/Runtime`) struct or cross-reference field, always add an `Id` (`FName`) primary key first, and make any field that references another struct instance point at that struct's `Id`, not its `Code`. Renamed in this pass: `FNexusFinalHighwayData::PointCodes`→`PointIds`, `OtherStateCityCode`→`OtherStateCityId`; `FNexusStationInfoBase::HighwaySplinePointCode`→`HighwaySplinePointId`, `HighwayCode`→`HighwayId`; `FNexusDynamicInteractable::HighwaySplinePointCode`→`HighwaySplinePointId`. `FNexusFinalPointData`/`HighwayData`/`CityData`/`StateData` all now have `Id` (VisibleAnywhere/BlueprintReadOnly, real key) ahead of `Code` (EditAnywhere, label) in field order. See [[v5_schema_folder_layout]] for where these structs live.
