# V4 road/highway save-load topology research

Date: 2026-08-09
Category: research

## Context

V5's save/load pipeline was found to silently lose highway topology (closed loops,
divider/connector segments) on Save -> Load. Before touching any V5 code, per explicit
instruction, researched NexusFramework_V4 (`E:\Projects\Game\UE\NexusFramework_V4`) to
determine whether its "100% accurate load-segment method" contains reconstruction logic
worth porting, or whether its correctness comes from a different architecture entirely.
Delegated to a research-only subagent (Explore) with instructions not to modify any code;
findings below are that agent's report, condensed and verified against the questions asked.

## Findings

**1. Save/Load code**: `UNexusFrameworkSubsystem::LoadLayout()`
(`NexusFrameworkEditor/Private/NexusFrameworkSubsystem.cpp:768-798`) is a one-line struct
copy - `WorkingGraph = Asset->Graph;` - followed by `SyncHighwayActorsFromGraph()` which
rebuilds the always-live `USplineComponent` visuals FROM that graph. There is no
reconstruction/reconciliation logic in Load at all. Save (`WriteWorkingGraphToAsset`) is
the mirror image: `Asset->Graph = WorkingGraph;` then `SaveLoadedAsset`.

**2. Topology metadata on `FNexusHighway`/`FNexusRoadPoint`**: no closed-loop flag, no
divider/junction struct. Only `OrderedPointIds` (linear array) plus the point-level
`ConnectedHighwayIds` back-reference (derived, rebuilt by graph mutators, never hand-edited).
Junction/branch classification (`ENexusNodeType`) is a derived read of connection count, not
authored/persisted topology state.

**3. Reconstruction mechanism**: `PopulateSplineFromHighway`
(`NexusHighwayRoadActor.cpp:16-65`) is a plain pairwise walk over `OrderedPointIds`, same
shape as V5's own `MaterializeMissingPointGeometry`. `RebuildSegmentsForSpline` DOES contain
a closed-loop branch (`Spline->IsClosedLoop() ? NumPoints : NumPoints - 1`) - but this reads
a runtime `USplineComponent` property that **nothing in V4 ever sets**
(`grep`'d the whole `Source` tree for `SetClosedLoop` - zero call sites). **V4 does not
support closed-loop highway topology as an authorable/saveable concept at all** - the branch
is dead code, likely inherited boilerplate. Shared points (junctions) are handled purely by
GUID cross-reference - `FNexusRoadGraph::ConnectPoints` decides, at graph-mutation time
(not load time), whether to extend an existing highway or fall back to
`AddHighway(PointAId, PointBId, false)` - literally "Branch: create a new highway" - when
neither point is a cleanly-extendable degree-1 endpoint. This branch-fallback is the one
structurally transferable idea, even though V4 needed it for a different reason (an editing
action, not a load-time reconciliation).

**4. Does V4 sync from a separately-authored, live geometry tool?** No. V4's own always-live
geometry (`ANexusHighwayRoadActor::Spline`) is generated FROM the graph and any user drag on
it is synced immediately back into the SAME graph via `PostEditMove` -> `SyncHighwaySplineEdit`
(position explicitly clamped back to `Point->Location` - "shaping the arc must never relocate
a point"). The one place V4 touches native Unreal Landscape Splines
(`ConvertToLandscapeSupportPath`) is write-only/destructive-rebuild - it always calls
`ClearAllLandscapeSplineData` first, builds fresh from `WorkingGraph`, and never reads
pre-existing native-tool-authored topology back in. V4 never has a second, independently
live-editable topology authority that could silently diverge from what gets saved.

**5. Terminology grep**: zero matches for "loop"/"circular"/"divider" anywhere in V4 source
or `Docs/Development-Plan.md`, aside from the one dead `IsClosedLoop()` check above. No TODOs
or comments addressing these concepts.

## Assessment

V4's load correctness is **architectural, not algorithmic** - there is no reconstruction
technique to port. `FNexusRoadGraph` is the single topology authority; the only
live-editable geometry is always derived from it and any edit round-trips straight back into
the same graph, same frame. V5's actual failure mode - a separate, natively-live-editable
tool (Unreal's Landscape Spline system) whose state can silently diverge from what
`WorldData` has recorded - simply does not exist in V4's architecture, so V4 never needed to
solve it. The one useful principle V4 does demonstrate: **topology must be explicit and
GUID-based, never positional/index-based** - `OrderedPointIds` + `ConnectedHighwayIds`
already follow this in V5 too; the fix for V5's actual bugs is closing gaps in that model
(a missing closed-loop flag, a missing tracked-to-tracked reconciliation pass), not
importing anything from V4's own load code.

## Result

Research complete, no code changed by this investigation. Findings consumed directly by the
fix documented in `../bug-fixed/closed-loop-and-divider-save-load.md`.
