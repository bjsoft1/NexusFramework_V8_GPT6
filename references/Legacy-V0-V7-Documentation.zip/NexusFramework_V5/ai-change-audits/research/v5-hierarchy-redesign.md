---
name: v5-hierarchy-redesign
description: "V5 adds a State level above City→Highway→Point; V5 repo is currently a fresh unmigrated UE template, V4 has the full working implementation to port from."
metadata: 
  node_type: memory
  type: project
  originSessionId: 1ebdb727-a1c2-4779-b2e2-4c352ef30479
  modified: 2026-08-07T14:34:24.357Z
---

V5 requires a new 4-level world hierarchy: State → City → Highway → Spline Point (V4 only had City → Highway → Point). Cross-state highways must be supported (a highway can belong to two states, same as V4 already allows a highway to belong to two cities).

**Why:** V4's City-as-root design doesn't scale to large open worlds (100+ states, 1000+ cities, 10000+ highways, millions of points) and has no streaming/World Partition story.

**How to apply:** Do not treat this as a refactor of existing V5 code — as of 2026-08-07, `e:\Projects\Game\UE\NexusFramework_V5` is a stock fresh UE C++ template with none of V4's ~30 hierarchy/editor source files ported over yet. `NexusFrameworkEditor.Target.cs` doesn't even reference a separate editor module. The real reference implementation to port/extend from is V4 at `E:\Projects\Game\UE\NexusFramework_V4\Source\NexusFramework\Public\` (runtime structs: NexusCity.h, NexusHighway.h, NexusRoadPoint.h, NexusRoadGraph.h, NexusRoadTypes.h, NexusFinalDataTypes.h) and `E:\Projects\Game\UE\NexusFramework_V4\Source\NexusFrameworkEditor\` (editor subsystem + SNexusFrameworkPanel tree view).

**V4's architectural pattern to extend (not replace):**
- Single flat registry struct `FNexusRoadGraph` holds parallel `TMap<FGuid, T>`s per level (Points, Highways, Cities) — no nested TMaps, no direct UObject pointers between levels, everything cross-referenced by `FGuid` resolved via `Find*()` lookups.
- Ownership is asymmetric: the *child* holds the real owning-parent field (`FNexusHighway::StartCityId/EndCityId`, `FNexusHighway::OrderedPointIds`); the *parent*'s array (`FNexusCity::ConnectedHighwayIds`) is derived/cached, written only by the graph's own mutator methods (e.g. `SetHighwayCityOwnership`), never hand-edited.
- Inter-city highways already exist in V4 and the editor tree already duplicates that highway's node under both parent cities to represent it — this is the direct precedent for how cross-state highways should be generalized in V5 (extend `ENexusOutlinerItemType`/`FNexusOutlinerItem` with a State case, one more nesting level in `RefreshHierarchy()`).
- A separate locked "Tier 4" flattened export schema (`NexusFinalDataTypes.h`) exists using `FName Code` instead of `FGuid` (GUIDs are editor-only) — City→Highway→PointCodes[]. V5 will need a State-aware equivalent.
- Landscape Spline integration is opt-in/one-way tooling (`BuildSplineSegments`, `ConvertToLandscapeSupportPath`), not a live sync — framework's own `FNexusRoadPoint` Location/Rotation/tangents are ground truth for AI/export in the common case. See [[v4_landscape_terrain_approach]].
- No World Partition/streaming/DataLayer code exists anywhere in V4 — this is entirely new scope for V5.

**Other loose end:** `V5-Final-Output-Design.cs` at the V5 repo root is scratch-pad C#-pseudocode for a *runtime export schema* only (FHighway/FHighwaySplinePoint/POI decoration types). It has since been fully ported into C++ (see [[v5_schema_folder_layout]] for where) — treat that C# file as historical/superseded, not as the thing to re-derive from again.
