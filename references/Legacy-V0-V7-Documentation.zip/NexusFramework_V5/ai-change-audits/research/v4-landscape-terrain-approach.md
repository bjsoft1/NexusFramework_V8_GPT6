---
name: project-v4-landscape-terrain-approach
description: "NexusFramework_V4's final approach to landscape terrain deformation under roads - Convert Landscape Support Path, not Build Spline Segments' mesh placement"
metadata: 
  node_type: memory
  type: project
  originSessionId: aacde4df-9da2-4e2c-a4b6-d021555a2b61
  modified: 2026-08-07T09:46:45.725Z
---

NexusFramework_V4 (E:\Projects\Game\UE\NexusFramework_V4) settled on a split architecture for roads-on-terrain: **mesh placement and terrain deformation are handled by two completely separate systems**, after months of trying to make Landscape Spline's own mesh placement match the authored road curve exactly (it structurally can't - a `ULandscapeSplineSegment` is one cubic Hermite curve per segment driven by a single shared `Rotation`/`TangentLen` per endpoint, no per-side tangent).

**Mesh placement** (100% accurate, unchanged): `ANexusHighwayRoadActor::Spline` (a real `USplineComponent` with the graph's exact authored tangents) + `RebuildSegmentsForSpline`'s `USplineMeshComponent::SetStartAndEnd` calls, plus `ANexusJunctionMeshActor` placing junction meshes directly at each graph point's `Location`/`Rotation`. Both are always-live via `SyncHighwayActorsFromGraph`/`SyncJunctionActorsFromGraph`. Never touches Landscape Spline.

**Terrain deformation**: `UNexusFrameworkSubsystem::ConvertToLandscapeSupportPath()` (panel button "Convert Landscape Support Path"). Builds REAL `ULandscapeSplineControlPoint`/`ULandscapeSplineSegment` objects (shared control points at every junction, same creation pattern as the older `BuildSplineSegments()`) but assigns **no mesh to any of it** - purely to drive `Landscape->RequestSplineLayerUpdate()`, which processes the whole spline network in one coherent pass via `ULandscapeInfo::ApplySplines`. This was necessary because the first attempt (looping `ALandscapeProxy::EditorApplySpline` once per highway, independently) produced sharp spike/seam artifacts at every junction: each independent call commits its own height write (a one-sided raise/lower-vs-already-committed-height test, not a true blend) before the next call runs, so 2-4 highways all touching the same junction fight each other pixel-by-pixel. Real Landscape Spline data's junction-fan blending (`RasterizeControlPointHeights`) is the one part of that system that's actually correct - it was only ever the curve-shape/mesh-placement part that was wrong.

**Why this matters**: if `Build Spline Segments` (the OLD mesh-placement pipeline, still present as a separate button) and `Convert Landscape Support Path` are both run, they share the same `ULandscapeSplinesComponent` on the Landscape actor - running one clears whatever the other built (`ClearAllLandscapeSplineData`). They are alternatives, not complementary.

See also [[feedback-verify-landscape-changes-not-just-logs]] for how the debug overlay that proved this bug was built.
