---
name: v5-landscape-nexus-two-way-sync
description: Live Landscape-Spline -> Nexus WorldData sync built 2026-08-08 via FCoreUObjectDelegates::OnObjectTransacted; covers Location/Rotation/Tangent/Delete; single-Ctrl+Z Undo solved via joining the still-open transaction with a plain Modify() call. NOT compiled/tested past the final Modify()-join edit.
metadata: 
  node_type: memory
  type: project
  originSessionId: 981d13f6-153a-4882-9852-bbbc0e384a44
  modified: 2026-08-08T18:25:10.779Z
---

## What exists now

`UNexusFrameworkEditorSubsystem::OnLandscapeSplineObjectTransacted(UObject*, const FTransactionObjectEvent&)`
(NexusFrameworkEditorSubsystem.h/.cpp), bound to `FCoreUObjectDelegates::OnObjectTransacted`
in `Initialize()`/unbound in `Deinitialize()`. This is the ONLY reliable hook found
(source-verified against UE 5.8 engine): a viewport gizmo drag on a Landscape Spline
control point never calls `PostEditChangeProperty` (so `OnObjectPropertyChanged` never
fires for it), only `Modify()` + `EndTransaction()`, which reaches `OnObjectTransacted`.

Branches:
- `ULandscapeSplineControlPoint` cast: Location + Rotation (added `FRotator Rotation`
  field to `FNexusRoadPoint`, `NexusRoadPoint.h`, same snapshot pattern as `Location`;
  new `TryGetPointWorldRotation` mirrors `TryGetPointWorldLocation`). Also checks
  `ControlPoint->GetOuterSafe() == nullptr` FIRST - this is the engine's own idiom for
  "has this point been deleted" (a deleted point is `Rename()`'d into the transient
  package, never destroyed - kept alive by the Undo buffer's own strong reference).
- `ULandscapeSplineSegment` cast: `OutgoingTangentLen`, since `TangentLen` lives on
  `FLandscapeSplineSegmentConnection`, not the control point. Auto-vs-override aware:
  compares the live value against the distance-based auto-default formula
  (`ConnectControlPointsWithSegment`'s own formula) before deciding whether to keep
  `-1` (still auto) or capture a concrete override - see [[feedback_negative_one_means_global_default]].

Every mutation branch is tolerance-checked against the current snapshot first (avoids
log spam / needless dirty-flagging from unrelated `Modify()` calls on the same object).

## Deletion: `DeletePointNoTransaction`

Calling the existing public `DeletePoint()` (Hierarchy tree's own Delete button) from
inside this callback CRASHED LIVE: `Assertion failed: ActiveRecordCounts.Num() ==
ActiveCount` (EditorTransaction.cpp:1765) - `DeletePoint()` opens its own
`FScopedTransaction`, and this callback fires from inside `UTransBuffer::End()`/
`Finalize()` for the Landscape delete's OWN transaction, still mid-close; opening a
second one corrupts the transaction buffer's bookkeeping.

Fix: `DeletePoint()` was split - `DeletePointNoTransaction(FGuid)` now holds all the
actual work (fallback-selection computation, `DeletePointCore`, `FinishDeleteOperation`),
with `DeletePoint()` reduced to `{ FScopedTransaction; Modify(); return
DeletePointNoTransaction(PointId); }`. `DeletePointCore` itself was ALREADY safe to call
on an already-detached point (its own `Cast<ULandscapeSplinesComponent>(ControlPoint->GetOuter())`
check fails harmlessly), so no change was needed there.

## Undo/Redo: single-transaction join (the hard requirement)

User's explicit hard rule: UE owns Undo/Redo for Landscape-originated changes; Nexus
must never create its own transaction/history for them (Nexus-initiated edits, e.g. the
Hierarchy tree's Delete button, keep their own transaction unchanged - that's a
different case). But a bare "no transaction at all" mutation means structural changes
(deletion) are NOT undo-tracked by anything, silently diverging Landscape/Nexus after
one Ctrl+Z.

Resolved via engine-source verification (NOT guessed - see conversation transcript for
full trace with file/line citations if this needs re-deriving): calling plain `Modify()`
(never `Begin`/`EndTransaction`) on `this` immediately before mutating `WorldData`, from
inside `OnObjectTransacted`, is safe and DOES join the still-open transaction:
- `SaveObject()` (what `Modify()` calls) never touches `ActiveCount`/`ActiveRecordCounts`
  - the specific bookkeeping a nested `FScopedTransaction` crashed against.
- `GUndo` still legitimately points at the closing transaction for `Finalize()`'s entire
  duration (cleared only after `Finalize()` returns) - confirmed via
  `UTransBuffer::End()`, EditorTransaction.cpp ~line 1315-1360.
- A record added this late misses that transaction's own `Finalize()` diff pass, but
  `FTransaction::Apply()` (the Undo/Redo path, EditorTransaction.cpp:853-859) explicitly
  lazy-finalizes any still-unfinalized record - a documented engine fallback, not a hack.
- Requires `RF_Transactional` on the subsystem - already set once in `Initialize()`
  (`SetFlags(RF_Transactional);`), pre-existing, no change needed.

Applied uniformly: every one of the four mutation branches above (Location, Rotation,
Tangent, Delete) now calls `Modify()` immediately before its WorldData write. Net
effect (not yet build-verified): one Ctrl+Z should revert the Landscape edit AND the
Nexus field together; one Ctrl+Y should reapply both.

## Not done / explicitly out of scope this session

- The final Modify()-join change (the fix for single-undo) was NOT compiled or tested
  before the session ended - this is the top priority to verify next.
- Nexus -> Landscape push-back for `OutgoingTangentLen` edited live via the Details
  panel: confirmed to have ZERO live effect on already-materialized segments (only
  read at Save time via `SyncPointGeometrySnapshots`, only written at Load-time
  materialization via `MaterializeMissingPointGeometry`) - flagged, not fixed, explicitly
  deferred by the user in favor of finishing the Landscape->Nexus direction first.
- Segment/connection CREATE (new segment drawn directly on Landscape) was never
  addressed - only control-point Location/Rotation/Delete and segment Tangent. A newly
  drawn segment connecting two already-tracked points is untested territory.
- Multi-select delete (deleting several control points in one Landscape operation) is
  untested - the per-object loop should handle it (each gets its own
  `OnObjectTransacted` call), but not verified live.

## Session update (2026-08-08, later session) - new-segment CREATE sync IMPLEMENTED, not yet build-verified

Location/Rotation/Delete/Tangent confirmed working by the user in the meantime (via the
new Sync Inspector tab - see [[project_v5_phase4_todo_refactors]]), which is also what
surfaced this exact gap: "Segment/connection CREATE... untested territory" above turned
out to be a real hole, not just untested - a brand new Landscape segment between two
already-tracked Nexus points was never registered into `WorldData` at all.

**Engine-source research this session** (UE 5.8, `LandscapeEdModeSplineTools.cpp`,
`EditorTransaction.cpp`): `AddSegment(Start, End, ...)` is the one creation path
(`NewObject<ULandscapeSplineSegment>` + `ConnectedSegments.Add` on both endpoints). It's
called both top-level (Ctrl-click an existing point while another is selected - own
`FScopedTransaction`) and NESTED inside `AddControlPoint` (click empty space to extend a
highway - creates a brand-new untracked point AND the connecting segment in ONE outer
transaction). Confirmed via `UTransBuffer::End()` that nested transactions only finalize
(fire `OnObjectTransacted`) when the OUTERMOST one closes - so both objects' callbacks
fire together, batched, order not guaranteed by contract. Also found `SplitSegment`
(mid-segment point insert) reassigns an EXISTING segment's `Connections[1].ControlPoint`
post-creation - the one place a segment's endpoints can change after the fact.
`DeleteSegment` uses the identical Rename-to-transient-package idiom as control point
deletion (`GetOuterSafe() == nullptr` after) - segments behave the same way on delete.

**Fix** (`NexusFrameworkEditorSubsystem.h`/`.cpp`): the EXISTING tangent-sync scan in the
`ULandscapeSplineSegment` branch already returns as soon as it finds the highway-pair a
transacted Segment matches. Added an `if (Segment->GetOuterSafe() != nullptr)` fallthrough
after that scan (guard excludes a just-deleted segment, which also has no match, from
being misread as new) calling new `TryRegisterNewLandscapeSegment(Segment)`:
1. Resolve both `Connections[0]/[1].ControlPoint` back to Nexus Points (same reverse
   `SourcePoint.Get()` scan the deletion branch uses). Either unresolved -> no-op
   (deliberately did NOT extend live-import to cover the "brand new point + segment in
   one transaction" case - untracked-point import stays manual-only/Sync-From-Landscape,
   per this file's own established policy above; safe regardless of event order since an
   untracked endpoint is untracked before AND after, Nexus never imports it itself).
2. New `FindFreeHighwayEnd(PointId, OutHighwayId, bOutIsLast) const`: true only if the
   point belongs to EXACTLY ONE highway and sits at that highway's first-or-last
   `OrderedPointIds` slot. Either endpoint failing this (junction/mid-chain/2+ highways)
   -> logged, no-op.
3. Same highway both ends (loop-close) -> logged, no-op (loops aren't representable in
   the linear `OrderedPointIds` model - matches `BuildChainsFromUntrackedPoints`'s own
   dedicated loop-handling complexity, out of scope here).
4. Different-city or either highway is `InterCityHighway` -> logged, no-op (conservative
   guard, not explicitly requested but seemed safer than silently reassigning points
   across city boundaries).
5. Otherwise: new `MergeHighwaysForNewSegment(HighwayAId, bAIsLast, HighwayBId, bBIsLast)`
   - concatenates HighwayB's `OrderedPointIds` onto HighwayA's (each reversed first if
   needed so the two free ends land adjacent, verified by hand-tracing both orientations),
   repoints every moved point's `ConnectedHighwayIds`, clears HighwayB's `OrderedPointIds`
   then calls the EXISTING `WorldData.RemoveHighway` to delete it (reused, not
   reimplemented) - plus repoints `ActiveSelectionId`/`ActiveHighwayId` off the deleted
   highway if either was pointing at it (same dangling-selection guard `DeleteHighway`'s
   own fallback logic already follows).

Single `Modify()` before the merge (same join-not-create-transaction rule as every other
branch) + `MarkLayoutDirty()` + `OnLayoutChanged.Broadcast()` (topology changed wholesale,
same "Hierarchy tree needs a full rebuild" reasoning as every other topology-changing
action). No Sync Inspector code changes needed - confirmed by inspection that its existing
per-point Tangent-mismatch forward-walk (over `Highway->OrderedPointIds` pairs) will
automatically pick up the new adjacency once `WorldData` reflects it.

**Verified safe against Nexus's OWN segment creation** (`PlacePointOnLandscape`/
`GenerateCityInternalGrid`/`MaterializeMissingPointGeometry`, which also call
`ConnectControlPointsWithSegment`): traced `PlacePointOnLandscape` and found the segment
IS created before `WorldData.AddPointToHighway` in source order (opposite of what the
header doc comment's prose implies) - but it doesn't matter, because `OnObjectTransacted`
only fires after the WHOLE enclosing `FScopedTransaction` closes (see the Undo/Redo
section above), by which point the function's later `AddPointToHighway` call has already
run synchronously regardless of the earlier code's ordering. So the existing tangent-scan
always finds the match first for Nexus-authored segments; the new fallthrough only ever
fires for genuinely UE-authored ones.

**Explicitly deferred, not fixed this session** (per direct user instruction to report
rather than silently fix): segment DELETION (disconnecting two still-Nexus-adjacent
points without deleting either control point) has no detection at all currently - Nexus
would keep believing they're adjacent. `DeleteSegment`'s `GetOuterSafe() == nullptr`
idiom would make this a small, consistent addition if picked up later.

Not yet build-verified - next step is the same testing matrix used for the earlier
Location/Rotation/Delete work: create segment between two tracked points, confirm Nexus
picks it up + Sync Inspector shows Synchronized, Ctrl+Z removes it, Ctrl+Y restores it,
Save/Reload keeps it, and an unrelated existing segment's tangent edit still works
unregressed.

## Session update (2026-08-08, later session) - closed the "brand new point + segment" gap this file's own point 1 above deliberately deferred

User reported (real usage, not a design review) that extending a highway by clicking past
its own end in the Landscape Splines tool - the actual common workflow, not the "wire two
pre-existing free ends together" case already handled above - never showed up in Nexus at
all. Confirmed this was exactly the deliberately-deferred case from point 1 above, not a
regression: `TryRegisterNewLandscapeSegment` required BOTH endpoints already tracked.

**Fix**: `TryRegisterNewLandscapeSegment` now branches on `bATracked != bBTracked` (exactly
one endpoint tracked) BEFORE the existing "both tracked" checks, calling new
`TryAdoptNewLandscapePoint(Segment, TrackedPointId, NewControlPoint)`:
- Same `FindFreeHighwayEnd` eligibility guard as the merge case (junction/mid-chain ->
  logged, no-op) - reused, not reimplemented.
- No ownership-kind/city guard needed here (unlike the merge case) - appending one point to
  an already-owned highway never crosses a city boundary, so `InterCityHighway` is fine too.
- `WorldData.AddPointToHighway` + `LinkPointToControlPoint` - the exact same pair
  `PlacePointOnLandscape` (manual Draw Point click) and `SyncFromLandscape`'s own
  chain-import path already use. `Point.Location`/`Rotation` deliberately left at their
  post-`AddPoint()` default - `TryGetPointWorldLocation`/`Rotation` always resolve live from
  `SourcePoint` rather than trusting the cached field, and `SyncPointGeometrySnapshots`
  (called before every save) will populate them for real before anything persists.
- `AddPointToHighway` always appends; if the tracked endpoint was the chain's FIRST point
  (not `Last()`), the new point is moved from the back to the front directly (`RemoveAt` +
  `Insert(0)`) rather than reversing the whole array, which would also flip every
  pre-existing point's order.
- Re-classifies (`RecomputePointClassification`/`ApplyPointFurniture`) both the new point
  AND the tracked endpoint it extended from (its own junction type may change, e.g.
  highway-end mesh -> Straight) - same as `PlacePointOnLandscape` already does for its own
  previous-point on every manual click.

Both endpoints untracked (a wholly new pair, not touching any existing highway) is still
left alone/manual-only - correctly ambiguous, no highway to attach to.

## Related but SEPARATE finding (2026-08-08, same report) - native engine bug in repeated Landscape-Splines delete-with-join, NOT a Nexus bug

User also hit a fatal crash (`Cast of Package /Engine/Transient to LandscapeSplinesComponent
failed`, Casts.cpp:10) while cleaning up points created via the untracked-new-point workflow
above. Traced through the actual crash-folder log
(`Saved/Crashes/UECC-Windows-F2028.../NexusFramework.log:2215-2302`), not just the pasted
snippet: 8 rapid native `DELETE` key presses in Landscape Splines edit mode, each hitting
the engine's own built-in "Control point has two segments attached, do you want to join
them?" dialog (Yes every time) - **zero `[Nexus]`/`[Landscape->Nexus]` log lines anywhere in
the whole sequence**, confirming these were untracked points and Nexus's
`OnLandscapeSplineObjectTransacted` never even engaged. The 8th delete triggered a
`LandscapeEditor.dll`-only engine ensure ("Array has changed during ranged-for iteration!")
immediately followed by the fatal Cast crash - both purely inside
`Landscape`/`LandscapeEditor`/`UnrealEd` callstack frames, zero `NexusFrameworkEditor`
frames anywhere. User separately confirmed this specific crash "always happens when we try
to delete last index" (the highway's own end point). This is a genuine UE 5.8 engine bug in
native repeated delete+auto-join, not something Nexus's code causes or could patch -
logged for awareness only, no code change made or needed on Nexus's side. The
`TryAdoptNewLandscapePoint` fix above is the practical mitigation: once a point is
Nexus-tracked, deleting it via Nexus's own Delete button
(`DeleteControlPointFromLandscape`, already fixed for the DIFFERENT
`DetachSegmentFromControlPoint` stale-reference bug - see
[[project_v5_phase3_landscape_click_to_place]] #29-30) avoids this native code path
entirely.

## Session update (2026-08-09) - Bug 3 FIXED, not yet build-verified: first point of an empty/no-yet-existing highway never synced

User's own report: "when initial time nothing have points and we try to add point from UE
then it not sync. but if any points has and highway maybe active then sync." Root cause:
every branch above (`TryAdoptNewLandscapePoint`, the two-tracked-endpoints merge) only ever
fires from a `ULandscapeSplineSegment`'s own `OnObjectTransacted` event - but the Landscape
Splines tool's native `AddControlPoint` only creates a paired Segment when extending FROM an
existing point. The very FIRST point of a brand new chain is a lone `ULandscapeSplineControlPoint`
with zero `ConnectedSegments` and no Segment event at all - nothing previously handled that
case.

**Fix**: in `OnLandscapeSplineObjectTransacted`'s `ULandscapeSplineControlPoint` branch, the
tracked-points loop's previously-bare fallthrough `return;` (reached when the point isn't
found in `WorldData.Points`) now calls new `TryAdoptFirstLandscapePoint(ControlPoint)`
(`NexusFrameworkEditorSubsystem.h`/`.cpp`):
- No-ops if `ConnectedSegments.Num() > 0` - that means a Segment event for this same point
  either already fired or is about to, and `TryAdoptNewLandscapePoint` owns that case; this
  avoids double-importing the same point regardless of which of the two transacted objects
  the callback sees first (same "no guaranteed order" fact this whole file already
  established for the segment-create case).
- Resolves the target highway from `ActiveHighwayId`; per the user's explicit instructions
  for the two edge cases they called out - "if no points has or no highway has active then
  make 0 index active" (falls back to the first highway in `WorldData.Highways` if
  `ActiveHighwayId` doesn't resolve but at least one highway exists) and "if no any highway
  then create all required hierarchy" (if `WorldData.Highways.Num() == 0`, builds whichever
  of State/City/Highway are missing - reuses an existing State/City if one happens to exist,
  same default "State 1"/"City 1"/"Highway 1" shape `ResetToDefaultLayout` already seeds a
  brand new Layout with). Either fallback also makes the resolved highway the active
  selection (`ActiveSelectionKind/Id`, `ActiveHighwayId`, broadcasts
  `OnActiveSelectionChanged`) - only when it had to guess; an already-valid `ActiveHighwayId`
  is left untouched.
- Still no-ops (manual Sync From Landscape only) if the resolved highway already has 1+
  points - a disconnected new point can't be assumed to belong to an already-populated
  highway, same ambiguity guard every other branch in this file already applies. This is
  exactly why the bug was invisible once ANY point/highway already existed ("if any points
  has and highway maybe active then sync" - true, because by then every subsequent native
  click always pairs a Segment with an existing tracked free end, which
  `TryAdoptNewLandscapePoint` already handled).
- Otherwise: same `AddPointToHighway` + `LinkPointToControlPoint` +
  `RecomputePointClassification`/`ApplyPointFurniture` pattern as
  `TryAdoptNewLandscapePoint`/`PlacePointOnLandscape`.

Not yet build-verified.

## TODO added 2026-08-09 (user-reported, not investigated yet) - Hierarchy tree leaves the PREVIOUS point highlighted as "active" after selecting a new one

User: "when i click the landscape segment point then tree viewer shoing active but when
select next point still tree viewer showing active previous and current as well as. so, i
want reset previous." I.e. clicking a Landscape spline control point in the viewport
correctly marks its row active in the Hierarchy tree, but selecting a DIFFERENT point
afterward leaves the first row still showing as active too - both rows appear highlighted
simultaneously instead of the highlight moving. Not investigated yet (user asked only to
log it) - likely somewhere in the Hierarchy tree's own active-row highlight logic reacting
to `OnActiveSelectionChanged`/`SetActivePoint` (`SNexusFrameworkPanel.cpp`) rather than in
the Landscape->Nexus sync code itself, since `SetActivePoint`/`ActiveSelectionId` are
single-value (not a set) - worth checking whether the tree's `STreeView` selection call
uses `ClearSelection()` before re-selecting, or whether row widgets cache their own
"IsActive" bool that isn't being invalidated on the OLD row when a NEW one is set.
