---
name: project_v5_nexus_landscape_spline_edit_layer
description: "EXPERIMENT ROLLED BACK 2026-08-07 by explicit user request - UNexusLandscapeSplineEditLayer no longer exists on disk. Kept only for the GetRenderFlags export gotcha and the editor-only-vs-Runtime tradeoff analysis, in case this is revisited."
metadata:
  node_type: memory
  type: project
  originSessionId: ba6d180c-7c4c-42aa-b8a6-c1389d9efa9c
  modified: 2026-08-07T18:12:27.968Z
---

**2026-08-07 update: user rolled this experiment back** ("now i rollback it. my experiment is done") — `Source/NexusFrameworkEditor/Public/Landscape/` and `Private/Landscape/` are empty again, `NexusFrameworkEditor.Build.cs` no longer has the `Landscape` module dependency or `Public/Landscape` include path this work added. **Do not assume any of the below is currently on disk** - it was a completed, reviewed experiment that the user chose not to keep, not a bug or an in-progress task. The technical findings below (engine architecture, the `GetRenderFlags` link gotcha) remain accurate if this direction is ever revisited, which is the only reason this memory is kept rather than deleted.

Original (no longer on disk) work: added `UNexusLandscapeSplineEditLayer` (`Source/NexusFrameworkEditor/Public/Landscape/NexusLandscapeSplineEditLayer.h` + `Private/Landscape/NexusLandscapeSplineEditLayer.cpp`), a stub subclass of `ULandscapeEditLayerPersistent` (engine class, `Runtime/Landscape/Classes/LandscapeEditLayer.h`). Selectable from Landscape Mode > Manage > Splines > Layers > Add > "Pick Landscape Edit Layer Class" — that picker (`FLandscapeEditorCustomNodeBuilder_Layers::PickEditLayerClass`, `Editor/LandscapeEditor/Private/LandscapeEditorDetailCustomization_EditLayersStack.cpp`) auto-enumerates via `ClassViewer`/`IClassViewerFilter` over all non-abstract, non-deprecated children of `ULandscapeEditLayerBase` — pure reflection, no manual registration needed, confirmed by reading the engine source directly rather than assumed.

## Deliberate architecture deviation from Epic's own pattern (explicitly chosen by user, not a mistake)

Checked engine source first: `ULandscapeEditLayerBase`/`ULandscapeEditLayerPersistent`/`ULandscapeEditLayer`/`ULandscapeEditLayerSplines` **all live in the `Landscape` Runtime module**, with unconditional `UCLASS()`/`GENERATED_BODY()` — only individual *methods* inside them are `#if WITH_EDITOR`-gated, never the class declarations. `ALandscape::CreateLayer` (which instantiates the picked class via `NewObject`) is also unconditionally `LANDSCAPE_API`, not editor-gated. This means a class that only exists in an Editor module is invisible to the picker in a packaged/cooked game, and a landscape asset serialized with that layer would fail to resolve the class on load in a cooked build.

**User was told this conflict directly and explicitly chose to keep the class editor-only anyway** (original requirement #1 said "must never be compiled into packaged builds" — user picked "force it into NexusFrameworkEditor anyway" over the recommended "class in Runtime module, matching Epic's pattern" option). Consequence to remember: this custom edit layer can only ever be added/edited in-editor; if a level with a Nexus spline layer is ever cooked and run, the layer will not exist in that build. **If a future session needs this layer's data to survive into a packaged game (e.g. runtime nav-mesh generation reading baked spline data), the class needs to move to `NexusFramework` (Runtime) — this is not a bug to silently fix, re-confirm with the user first since it was an explicit choice, not an oversight.**

## Non-obvious build issue: `ULandscapeEditLayerPersistent::GetRenderFlags` not exported

`GetRenderFlags` is declared in `LandscapeEditLayer.h` as `virtual ... override` **without `LANDSCAPE_API`** (unlike its siblings `GetRendererStateInfo`/`GetRenderItems`/`RenderLayer`/`BlendLayer`/`GetEditLayerRendererDebugName`, which all have it) — its implementation in `LandscapeEditLayers.cpp` is Landscape-module-internal only. `ULandscapeEditLayerSplines` never hits this because it's compiled inside the same `Landscape` module/DLL. Any subclass in a *different* module (like `NexusFrameworkEditor`) that doesn't override `GetRenderFlags` itself gets an unresolved-external at link time (`LNK2001`/`LNK1120`). **Fix: override `GetRenderFlags` directly** with the same trivial body Epic uses (`ERenderFlags::RenderMode_Recorded | ERenderFlags::BlendMode_SeparateBlend`), inside `#if WITH_EDITOR` (the whole `ILandscapeEditLayerRenderer` interface and `FMergeContext` type are `WITH_EDITOR`-only). **How to apply**: any future engine-class subclass hitting a similarly surprising unresolved-external on a non-`_API` virtual should check whether the base's default implementation is actually cross-module-exported before assuming the override is optional — grep the declaring header for the missing `_API` macro on that specific method, not just the class.

## What's stubbed (per user's explicit "do NOT implement yet" list)

`GetDefaultName()` returns `"NexusHighways"`; `SupportsMultiple()` returns false (matches `ULandscapeEditLayerSplines`'s "only one instance" rule — reasonable default, not explicitly requested). All real logic (generating `LandscapeSplineControlPoint`/`LandscapeSplineSegment` from the Nexus highway graph, tangents, junctions, metadata storage, undo/redo, regeneration) is TODO-comment-only — see [[project_v5_landscape_native_highway_pivot]] for the schema (`FNexusHighway`, `TSoftObjectPtr<ULandscapeSplineControlPoint>`) this will eventually read from.

## Build.cs / module wiring

`NexusFrameworkEditor.Build.cs`: added `Landscape` to `PublicDependencyModuleNames`; added `Public/Landscape` to `PublicIncludePaths` (same BuildSettingsVersion.V7-subfolder reason as `Public/Schema/Editor` — see [[project_v5_editor_module_and_build_fixes]]). Both targets (`NexusFrameworkEditor` and standalone `NexusFramework` game target) build-verified green after this change.
