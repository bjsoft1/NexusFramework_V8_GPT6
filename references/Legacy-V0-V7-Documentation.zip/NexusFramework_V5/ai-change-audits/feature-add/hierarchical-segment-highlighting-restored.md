# Hierarchical (State/City/Highway) segment highlighting - restored via a new, crash-safe mechanism

Date: 2026-08-09
Category: feature-add

## Context

User asked to restore/complete hierarchical highlighting: selecting a City highlights every
segment belonging to it; selecting a State highlights every segment belonging to every City
in it. This behavior existed once, was removed after a confirmed engine crash, and the user
did not know where the crash investigation had been documented. Required investigating
existing history (`ai-change-audits/`) before writing any code.

## Investigation - recovered crash knowledge

The full investigation already exists, migrated verbatim from this project's prior memory
store: `ai-change-audits/feature-add/v5-phase3-landscape-click-to-place.md`, sections
"2026-08-08 follow-up #6" (original implementation) and "follow-up #10" (the crash and
disable decision). Not re-migrated here (would duplicate an existing historical record) -
summarized and answered against the task's own 9 questions instead:

1. **Original implementation**: `RefreshLandscapeSelectionHighlight()` - collected every
   materialized `ULandscapeSplineControlPoint` reachable under the current
   `ActiveSelectionKind`/`ActiveSelectionId` (State -> all its cities' highways -> their
   points; City -> its highways -> points; Highway -> its own `OrderedPointIds`; Point ->
   itself), then called `ControlPoint->SetSplineSelected(...)` on every control point in the
   splines component and `Segment->SetSplineSelected(...)` true only if both endpoints were
   in the set. Called from all four `SetActive*`/`ClearActiveSelection` setters.
2. **Exact cause**: `SetSplineSelected(bool)` flips `ULandscapeSplineControlPoint`/
   `Segment::bSelected` - the SAME flag Landscape Mode's own Splines tool privately tracks a
   second time in its own array (`ULandscapeSplineSelection`), assuming exclusive ownership.
3. **Where**: `Assertion failed: ControlPoint->IsSplineSelected()`,
   `LandscapeEditor/Private/LandscapeSplineSelection.cpp:105`, inside
   `ClearSelectedControlPoints`/`ClearSelectedSegments`.
4. **Object/lifecycle involved**: none - not a dangling-pointer/UObject-validity bug. A pure
   state-desync between two independent trackers of one shared bool flag on an otherwise
   perfectly valid, live object.
5. **Trigger**: the NEXT native Landscape-tool selection-changing action (click elsewhere,
   Escape, tool switch) after Nexus's own highlight call had already flipped `bSelected` on
   any point - user's own repro: "when i click the city, highway, state then highlight and
   when i click landscape then crash."
6. **Category**: "material/highlight state" desync - specifically none of the other listed
   categories (not selection-object-lifetime, not destroyed objects, not cross-world, not
   GC/pending-kill, not transaction/undo, not recursive propagation).
7. **Workaround/plan documented**: disable outright (the user's chosen option over two
   others - "reduce but don't eliminate risk," and "build a fully independent PDI-based
   highlight"). Future correct fix already explicitly named: "a genuinely safe highlight
   needs to render independently of `bSelected` entirely - e.g. a custom
   `FPrimitiveDrawInterface`/hit-proxy-based outline... never touching the shared flag."
8. **Disabled how**: fully, intentionally - both `RefreshLandscapeSelectionHighlight()` and
   `DetectAndClearHighlightIfOverriddenByViewport()` unconditionally `return` immediately,
   original bodies preserved as comments (not deleted), the per-tick poll call to the latter
   removed entirely from `SNexusFrameworkPanel::Tick()`.
9. **Still necessary?** Yes - re-confirmed live in the current source
   (`NexusFrameworkEditorSubsystem.cpp`, both functions still exactly as described above,
   nothing this session or any other since has touched `SetSplineSelected`/
   `ULandscapeSplineSelection`). The underlying engine limitation (no accessor, no event, no
   heuristic for Landscape Mode's private tool-side selection array) is a UE 5.8 API gap, not
   something this project's own code changes could have fixed - still fully true.

Also confirmed via `SNexusSyncInspectorPanel.h`'s own class comment (built in an earlier
session, same day) that this project had already independently established the precedent of
avoiding `SetSplineSelected` for click-to-focus, citing this exact crash history.

## Implementation - new mechanism, does not touch `SetSplineSelected`

Per the recovered plan's own recommendation, and per "reuse the existing mechanism where
possible": this project already has a fully-built, per-tick `DrawDebugOverlays()` system
(`NexusFrameworkEditorSubsystem.cpp`) that draws curve-accurate lines for highways/lanes/
sidewalks using plain `DrawDebugLine` against each real `ULandscapeSplineSegment`'s own
tessellated points (`Segment->GetPoints()`) - a rendering primitive completely independent
of `bSelected`/Landscape Mode's private selection cache. This is the safe vehicle used.

**New**: `UNexusFrameworkEditorSubsystem::IsHighwayInActiveSelectionScope(const
FNexusHighway&) const` - the traversal, using the EXISTING authoritative relationships
(no second hierarchy invented): Highway selection matches only that highway
(`Highway.HighwayId`); City selection matches `Highway.StartCityId`/`EndCityId` (covers
InternalCityRoad and InterCityHighway, matching how the Hierarchy tree already duplicates an
inter-city highway under both parent cities); State selection resolves each owning city's
`ParentStateId`. Point selection and no selection both return false, deliberately.

**New**: `UNexusFrameworkEditorSubsystem::DrawHierarchySelectionHighlight() const` - for
every highway in scope, walks its `OrderedPointIds` the same way `DrawDebugOverlays`' own
Highway category does (`FindConnectingSegment` + `GetPoints()`), drawing a thick
(9.f vs. the Highway category's own 3.f default) orange `DrawDebugLine` over the same
curve-accurate tessellated points. Called unconditionally every tick from
`SNexusFrameworkPanel::Tick()`, right next to the existing `DrawDebugOverlays()` call -
deliberately independent of `DebugDrawState.bShouldDrawDebug` (core selection feedback, not
an optional debug visualization). Gated by `IsControlPointOnTargetLandscape` (this session's
earlier cross-map fix) so a stale cross-map `SourcePoint` never draws a highlight line
sourced from a different map's geometry.

## Why this is safe (crash-class analysis)

The confirmed crash required TWO independent trackers of the SAME piece of object state
(`bSelected`) to desync. This implementation touches zero object state - `DrawDebugLine` is
a stateless, immediate-mode rendering call (same family as any gameplay debug-draw), and
`IsHighwayInActiveSelectionScope`/`DrawHierarchySelectionHighlight` only ever READ
`WorldData`/`ActiveSelectionKind`/`ActiveSelectionId`, never write to any
`ULandscapeSplineControlPoint`/`Segment` property. There is no second system anywhere in the
engine that also owns "what color is this DrawDebugLine call" - the entire crash class is
structurally impossible for this mechanism, not just unlikely.

**Recursive-loop analysis** (explicitly required by the task): the old mechanism was called
FROM `SetActiveXxx`/`OnActiveSelectionChanged`, mutating object state that could itself
trigger further engine callbacks - a real re-entrancy surface. This mechanism is called only
from a per-tick poll (same pattern as `DrawDebugOverlays`/
`SyncActiveSelectionFromNativeViewportSelection`, already proven safe), never from inside a
selection-change callback, and never mutates `ActiveSelectionKind`/`ActiveSelectionId`/
`WorldData` itself - there is no path back into `SetActiveXxx` from this code at all, so no
loop can form.

**Clearing highlight**: no explicit "clear" step needed or written - `DrawDebugLine` calls
use `bPersistent=false` with a short `LifeTime` (0.05s), matching `DrawDebugOverlays`' own
established contract of "redraw every frame or the line visibly expires." Switching
selection from City A to City B simply means next frame's call draws B's highways and not
A's; A's previously-drawn lines expire on their own within one short window - the same
mechanism already relied on throughout `DrawDebugOverlays`, not something new to get wrong.

**Performance**: one pass over `WorldData.Highways` per tick (already the exact iteration
`DrawDebugOverlays`' own Highway category performs every tick, independent of this change) -
no world-wide actor search, uses only the existing State->City->Highway->Point relationships
already in `FNexusWorldData`.

## Verification

Brace-balance and non-ASCII checks clean on all modified files
(`NexusFrameworkEditorSubsystem.cpp`/`.h`, `SNexusFrameworkPanel.cpp`). Symbol
cross-reference checked (declaration/definition/call-site names match).

**NOT VERIFIED**: no build or editor run performed (no build/launch access - user builds and
verifies). None of the following have been confirmed by running the editor:
- Project builds successfully.
- Select City -> only that City's highways highlight, others stay normal.
- Select a different City -> previous highlight clears, new one appears.
- Select State -> every highway under every city in that State highlights.
- Select a different State -> clears/switches correctly.
- Individual Point selection still behaves as before (no highlight either way - there was
  none to preserve, since the old mechanism was fully disabled).
- Mixed-hierarchy test matrix (2 cities under one state, 1 city under a second state) from
  the task's own Test 6.

**Crash regression test - explicitly could not be attempted**: no editor/build access this
session. **Previous crash path could not be reproduced in the current build - it was never
run.** This implementation was made with the documented crash constraint fully in mind (see
"Why this is safe" above - the mechanism is structurally incapable of touching the object
state the old crash required), but this claim is a design-time safety argument, not a tested
one. Do not report "crash fixed" - report "implemented with the documented crash constraint,
not build-tested."

## Result

Code-complete, NOT VERIFIED. Old `SetSplineSelected`-based mechanism left exactly as
disabled (not touched, not re-enabled, not deleted) - see the header banner comment now
pointing future readers at this record and at
`v5-phase3-landscape-click-to-place.md`'s own original investigation.

## Limitations / future work

- Point-level individual highlighting was NOT restored (matches the task's own scope -
  "existing segment/individual selection behavior remains unchanged," and there was no
  existing visual behavior for Point selection to begin with, since the old mechanism was
  fully disabled for ALL selection kinds, not just City/State).
- Highlight color/thickness are hardcoded constants (`FColor::Orange`, 9.f), not exposed
  through `UNexusDebugDrawSettings` the way every other debug-draw category is - could be
  added later as a real `ENexusDebugDrawCategory` entry if configurability is wanted; kept
  out of this change to stay minimal.
- A future genuinely-safe alternative closer to native selection visuals (a custom
  `FPrimitiveDrawInterface`/hit-proxy outline, as the original crash investigation itself
  suggested) remains possible but was not pursued - the debug-line approach was preferred
  here specifically because it reuses an already-built, already-proven-safe mechanism
  wholesale rather than building new rendering infrastructure.

## 2026-08-09 - Bug found and fixed: highlight was invisible (missing terrain Z-offset)

User tested and reported: "highlight color effect i cannot see." Root cause found by
re-reading `DrawHierarchySelectionHighlight`'s own line-drawing code against
`DrawDebugOverlays`' established convention: the raw tessellated `Center` points
(`Segment->GetPoints()`) sit AT the road/terrain surface height. `DrawDebugOverlays`' own
Highway/Lane/Sidewalk categories all lift their lines by `Settings->LineZOffset` (default
`10.f`, `NexusDebugDrawSettings.h:116`) specifically to avoid z-fighting with / being
visually swallowed by the terrain mesh - `DrawHierarchySelectionHighlight` was written
without this offset at all, so the highlight line was being drawn essentially clipped into
the terrain surface, invisible from normal camera angles. Not a selection-logic bug - the
line-drawing calls were very likely happening, just not visibly.

**Fix**: resolved `DebugDrawSettingsAsset`/`Settings` the same fallback-to-default-instance
pattern `DrawDebugOverlays` itself uses, and lifted the highlight line by
`Settings->LineZOffset + 15.f` (deliberately higher than the plain Highway line's own
`LineZOffset`, so the highlight visibly sits above/in front of it rather than being
exactly coincident and z-fighting between the two colors).

**Verification**: brace-balance and non-ASCII checks clean. **NOT YET VERIFIED by the user**
- this is a fix made in response to their report, not yet confirmed to actually resolve it.
If the highlight is still not visible after this fix, the next things to check (in order):
whether `ActiveSelectionKind`/`ActiveSelectionId` are actually being set on City/State clicks
(add temporary logging in `IsHighwayInActiveSelectionScope`/`DrawHierarchySelectionHighlight`
if so, following this project's established diagnostic-logging pattern - see
`ai-change-audits/bug-fixed/cross-map-sourcepoint-bug.md` for that precedent); whether
`ResolveTargetLandscape()`/`GetSplinesComponent()` resolve at all in the user's test map;
whether `FColor::Orange` is simply hard to distinguish against the existing Highway line's
own default yellow at the user's zoom level (consider a more saturated/contrasting color,
e.g. pure red or magenta, if position is confirmed correct but color isn't visually distinct
enough).
