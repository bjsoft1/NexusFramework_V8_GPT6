---
name: project_v5_editor_module_and_build_fixes
description: "NexusFrameworkEditor module history: UI-shell version built once then lost from disk (uncommitted changes gone); rebuilt 2026-08-07 as a minimal empty Editor module only, by user's explicit choice. Three pre-existing V5 build blockers found and fixed along the way (still valid)."
metadata: 
  node_type: memory
  type: project
  originSessionId: c77d3cfc-afa7-465c-97ad-97db9114e96a
  modified: 2026-08-07T17:04:48.521Z
---

## Current state (2026-08-07, minimal rebuild)

The UI-shell version described below (dockable tab, Landscape Mode gating) was found **completely gone from disk** in a later session — `Source/NexusFrameworkEditor/` contained only empty leftover subfolders (`Private/Landscape`, `Private/UI`, `Public/Landscape`, `Public/UI`), no `.Build.cs`, no `.cpp`/`.h` files, and the `.uproject`'s `Modules` list only had `NexusFramework` (Runtime) — the `NexusFrameworkEditor` entry was gone too. Only `Source/NexusFrameworkEditor.Target.cs` survived, and even that just did `ExtraModuleNames.Add("NexusFramework")` — no reference to an editor module at all. This is the same "uncommitted work lost" pattern as [[project_v5_landscape_native_highway_pivot]]'s correction note — nothing in this project's git history (`git log --all -- Source/NexusFrameworkEditor*` is empty) ever had this module committed, so there's no commit to blame; the work was simply never saved to disk/git and something cleared it.

**User explicitly chose NOT to rebuild the UI shell / Landscape Mode gating this time** — asked only for "the module, only target for editor," i.e. minimal scaffold. What exists now:
- `Source/NexusFrameworkEditor/NexusFrameworkEditor.Build.cs` — deps: `Core, CoreUObject, Engine, NexusFramework` (public), `Slate, SlateCore, UnrealEd` (private, pre-added anticipating UI work later even though nothing uses them yet).
- `Source/NexusFrameworkEditor/Public/NexusFrameworkEditorModule.h` + `Private/NexusFrameworkEditorModule.cpp` — bare `IModuleInterface`, empty `StartupModule`/`ShutdownModule`, `IMPLEMENT_MODULE(FNexusFrameworkEditorModule, NexusFrameworkEditor)`. No panel, no tab, no Landscape Mode hook.
- Emptied leftover `Private/Landscape`, `Private/UI`, `Public/Landscape`, `Public/UI` subfolders removed (were empty, not repopulated).
- `Source/NexusFrameworkEditor.Target.cs` — `ExtraModuleNames` now `{ "NexusFramework", "NexusFrameworkEditor" }`.
- Root `NexusFramework.uproject` — `Modules` list now has both `NexusFramework` (Runtime) and `NexusFrameworkEditor` (Editor), both `LoadingPhase: Default`.
- Build-verified green: `Build.bat NexusFrameworkEditor Win64 Development` succeeds, both DLLs link.

**How to apply**: if asked again to add the dockable-tab UI / Landscape Mode gating, the design below (tab-based, not custom UEdMode) is still the right target — it just needs re-implementing from scratch, nothing to port from disk. **Given the pattern of losing uncommitted work twice now, strongly suggest committing this module to git once the user confirms it's in a good state**, rather than leaving it uncommitted across sessions again.

## Original UI-shell design (not currently on disk — historical record only, see above)

Created `Source/NexusFrameworkEditor/` (registered in the root `NexusFramework.uproject` as an `Editor`-type module). UI-shell-only: `SNexusFrameworkPanel` (buttons only UE_LOG, no real logic yet), hosted as a **dockable Nomad tab** (`SNexusFrameworkTab`, registered via `RegisterNexusFrameworkTabSpawner()`/`FGlobalTabmanager::Get()->RegisterNomadTabSpawner`), shown/hidden by `FNexusFrameworkLandscapeModeExtension` in lockstep with built-in Landscape Mode (`TryInvokeTab`/`RequestCloseTab` on `FBuiltinEditorModes::EM_Landscape` enter/exit via `FEditorModeManager::OnEditorModeIDChanged()`).

**Why NOT a custom UEdMode (tried first, reverted)**: initially ported V4's pattern verbatim — a custom `UNexusFrameworkMode` (UEdMode) + `FNexusFrameworkModeToolkit` (FModeToolkit) hosting the panel inline, activated/deactivated by the Landscape extension via `ModeTools.ActivateMode/DeactivateMode`. This crashed at runtime: `Assertion failed: !Toolkits.Contains(NewToolkit)` in `ToolkitManager.cpp` — activating a second `UEdMode` alongside built-in Landscape Mode conflicts with Landscape Mode's own toolkit registration. Root cause: `FLandscapeToolKit`/`SLandscapeEditor` (Landscape Mode's actual panel) are private, non-API classes in the `LandscapeEditor` module with no supported extension point — there is no way to inject a widget into Landscape Mode's own toolkit, and no way to run a second UEdMode alongside it without this exact assert. User explicitly redirected to the dockable-tab approach after seeing the crash; the mode/toolkit files (`NexusFrameworkMode.h/.cpp`, `NexusFrameworkModeToolkit.h/.cpp`) were deleted entirely.

**How to apply**: any future "hook into Landscape Mode" work in this codebase must go through this tab-based extension pattern (or a details-panel-style customization if one is ever found to be viable) — do not resurrect the custom-UEdMode approach, it's a dead end confirmed by a real crash, not just a design guess.

**How to apply**: when extending the panel's buttons with real logic later, follow V4's handler pattern (`FReply OnXClicked()` calling into a subsystem, always ending with viewport-focus restoration) — see [[project_v5_hierarchy_redesign]] and [[project_v5_schema_folder_layout]] for the surrounding schema this UI will eventually drive.

## Three pre-existing V5 build blockers found and fixed (unrelated to the editor-module task, but blocked all compilation)

1. **`UNexusGenerationSettings` never migrated from V4.** `Schema/Editor/NexusCity.h` (and comments in `NexusHighway.h`/`NexusFinalHighway.h`) reference it via `TSoftObjectPtr`, forward-declared but never defined anywhere in V5. Migrated to `Schema/Editor/NexusGenerationSettings.h` as a `UDataAsset`, same fields as V4, but Category strings rewritten to the 2-level max convention (`"NexusGenerationSettings|City Grid"` not V4's flat `"NexusGeneration"`) — see [[feedback_category_max_two_levels]]. `ENexusLaneConfiguration` (one of its fields) already lives in `Schema/Shared/NexusSharedRoadTypes.h` in V5 (V4 had it in the now-split-up `NexusRoadTypes.h`).

2. **9 `BitmaskEnum` UPROPERTY meta tags used bare enum names** (e.g. `BitmaskEnum = "ENexusHighwayFeature"`) instead of the full path UE 5.8 requires (`"/Script/NexusFramework.ENexusHighwayFeature"`). Affected: `NexusRoadPoint.h` (x2), `NexusHighway.h`, `NexusStationInfo.h` (x2), `NexusFinalHighway.h`, `NexusFinalPoint.h` (x2), `NexusDynamicInteractable.h`. Fixed by prefixing all 9 with `/Script/NexusFramework.`.

3. **Schema/Editor, Schema/Runtime, Schema/Shared cross-include each other by bare filename** (e.g. `Runtime/NexusFinalHighway.h` does `#include "NexusSharedRoadTypes.h"`, which physically lives in `Shared/`), but `NexusFramework.Build.cs` used `BuildSettingsVersion.V7`, under which UBT only auto-adds `ModuleDirectory/Public` to the include path — not each subfolder recursively. Same-folder includes silently worked (compiler always searches the including file's own dir first); cross-folder ones didn't. Fixed by adding all three `Public/Schema/{Editor,Runtime,Shared}` paths to `PublicIncludePaths` in `NexusFramework.Build.cs`, rather than rewriting every bare include to a qualified path — user chose this option specifically to avoid touching the schema headers' existing include style.

**How to apply**: if a *new* schema file is added under `Schema/Editor|Runtime|Shared` and cross-includes a sibling-folder header, it'll just work now — the include path fix is structural, not per-file. If `NexusFramework.Build.cs` is ever regenerated/reset, this `PublicIncludePaths` block needs to be re-added or the cross-folder includes will break again silently (only surfaces as a compile error, no runtime symptom).

Full project build verified green after all fixes: `Build.bat NexusFrameworkEditor Win64 Development -project=<uproject>` succeeds, both `NexusFramework.dll` and `NexusFrameworkEditor.dll` link.

## Runtime crash found after build succeeded: StartupModule() calling GLevelEditorModeTools() too early

The build succeeding doesn't mean the editor launches cleanly. `FNexusFrameworkLandscapeModeExtension::Register()` was called from `StartupModule()` and called `GLevelEditorModeTools()` immediately — this crashed the editor on launch with `EXCEPTION_ACCESS_VIOLATION` inside `UnrealEditor_UnrealEd`, because the global level-editor mode manager doesn't exist yet that early in module loading (this is exactly what the `GLevelEditorModeToolsIsValid()` deprecation message was warning about — "use `FLevelEditorModule::OnLevelEditorCreated` to gate the access" — which I initially just silenced instead of heeding).

**Fix**: mirrored the engine's own pattern from `FLevelInstanceEditorModule::StartupModule()` (`Editor/LevelInstanceEditor/Private/LevelInstanceEditorModule.cpp`) — check `FLevelEditorModule::GetFirstLevelEditor().IsValid()` first; if a level editor already exists, bind immediately; otherwise defer via `LevelEditorModule.OnLevelEditorCreated().AddRaw(...)` and bind once that fires. `Unregister()` correspondingly guards on `EditorModeChangedHandle.IsValid()` before calling `GLevelEditorModeTools()`, since that handle is only ever set once binding actually happened.

**How to apply**: this is the general pattern for anything in an Editor module's `StartupModule()`/global object that needs `GLevelEditorModeTools()`, `GEditor`, or other level-editor-scoped globals — never call them directly from `StartupModule()`; always gate on `GetFirstLevelEditor()` / `OnLevelEditorCreated()` (or `GEditor` null-checks) first. A clean compile says nothing about this — it only surfaces as a crash on editor launch.
