---
name: project_v5_phase1_authoring_panel
description: Phase 1 of the direct-in-Landscape city authoring redesign - data model (FNexusWorldData/FNexusRoadPoint), UNexusFrameworkEditorSubsystem, dockable panel with Hierarchy tree + Layout Tools. Built and editor-launch-verified. Viewport highlighting NOT done yet - only hierarchy-tree selection sync.
metadata:
  node_type: memory
  type: project
  originSessionId: ba6d180c-7c4c-42aa-b8a6-c1389d9efa9c
  modified: 2026-08-07T18:15:42.233Z
---

Implemented Phase 1 of [[project_v5_direct_landscape_city_todo]] (the phased plan agreed with the user for the "generate city directly into Landscape, no V4-style skeletal-then-build-segment two-step" redesign). Architecture: Nexus owns config, Landscape owns geometry (see that plan's "Core architecture" section) - Phase 1 only builds the Nexus-config side; nothing here touches `ULandscapeSplineControlPoint`/`Segment` yet (that's Phase 3).

## What was built

- **`Schema/Editor/NexusRoadPoint.h`** (new) - `FNexusRoadPoint`: config only (Code, decoration flags/targets/description, render overrides), no Location/Rotation/tangents - those will live on `TSoftObjectPtr<ULandscapeSplineControlPoint> SourcePoint` once Phase 3 materializes it (field exists, unset for now).
- **`Schema/Editor/NexusWorldData.h/.cpp`** (new) - `FNexusWorldData`: root container (States/Cities/Highways/Points maps) + mutators (`AddState`/`AddCity`/`AddHighway`/`AddPoint`/`AddPointToHighway`/`Remove*`/`Reset`), ported from V4's `FNexusRoadGraph` but State-aware (V4 had no State level) and trimmed to only what Phase 1 needs (no `ConnectPoints`/junction-continuity-rule/tangent-splitting logic yet - ownership sync only).
- **`Schema/Editor/NexusState.h`** (modified) - added `bOverrideRenderColor`/`OverrideRenderColor`/`bOverrideLineThickness`/`OverrideLineThickness`, matching the pattern `FNexusCity`/`FNexusHighway` already had (State didn't have these before).
- **`Schema/Editor/NexusLayoutAsset.h`** (new) - `UNexusLayoutAsset : UDataAsset`, wraps `FNexusWorldData World` + `GenerationSettings` soft ref. The only persisted store - Landscape spline objects (Phase 3+) are never authoritative, matching the user's "Nexus config is source of truth" requirement.
- **`NexusFrameworkEditorSubsystem.h/.cpp`** (new) - `UNexusFrameworkEditorSubsystem : UEditorSubsystem`. Owns live `WorldData`, active selection (`ENexusFrameworkSelectionKind` State/City/Highway/Point + `ActiveHighwayId` tracked separately so it survives selecting a Point on that highway), and Layout Tools (`NewLayout`/`SaveLayout`/`SaveLayoutAs`/`LoadLayout`/`DeleteLayout`) - **save/load/asset-dialog code ported near-verbatim from V4's `UNexusFrameworkSubsystem`** (same `PromptForSaveAssetPath`/`PromptForExistingLayoutAsset` native-dialog helpers, same "reuse already-loaded package on re-save" gotcha, same `ResolveUnsavedChangesBeforeProceeding` Yes/No/Cancel gate). `Initialize()` calls `ResetToDefaultLayout()` which creates State 1 > City 1 > Highway 1 and makes Highway 1 active - satisfies requirement #2 (default layout + new points auto-assign to active highway via `AddPointToActiveHighway()`).
- **UI** (`Public/UI`, `Private/UI`, new): `FNexusFrameworkLandscapeModeExtension` - dockable Nomad tab (`SNexusFrameworkPanel`), shown/hidden via `FEditorModeManager::OnEditorModeIDChanged()` matching `FBuiltinEditorModes::EM_Landscape`, registration deferred via `FLevelEditorModule::OnLevelEditorCreated()`/`GetFirstLevelEditor()` mirroring the engine's own `FLevelInstanceEditorModule::StartupModule()` pattern - this is the exact approach [[project_v5_editor_module_and_build_fixes]] already validated crash-free (custom UEdMode was tried once, reverted after a real crash). `SNexusFrameworkPanel` - Hierarchy tree (State>City>Highway>Point, one level deeper than V4's City>Highway>Point), active-selection label, "Add Point To Active Highway" button, Layout Tools button row (New/Save/Save As/Load) - UI code and generic building blocks (`BuildToolButton`/`BuildButtonRows`/`BuildAssetPicker`/`RestoreViewportFocus`) ported near-verbatim from V4's `SNexusFrameworkPanel.cpp`.

## Build/module changes

- `NexusFrameworkEditor.Build.cs`: `PrivateDependencyModuleNames` now matches V4's exactly (`InputCore, Slate, SlateCore, AppFramework, EditorFramework, EditorSubsystem, UnrealEd, AssetRegistry, PropertyEditor, EditorWidgets, RenderCore, EditorScriptingUtilities, ContentBrowser, Landscape, MainFrame`) - `Landscape` added now even though Phase 1 doesn't use it yet, needed by Phase 3. `PublicIncludePaths` now has `Public/Schema/Editor` AND `Public/UI` (BuildSettingsVersion.V7 subfolder gotcha, same reason as always - see [[project_v5_editor_module_and_build_fixes]]).
- Root `.uproject`: added `EditorScriptingUtilities` plugin entry (`TargetAllowList: ["Editor"]`) - required for `UEditorAssetLibrary`, V5's `.uproject` didn't have it even though V4's did.

## Two real bugs hit and fixed (both worth remembering for next time)

1. **`struct FEditorModeID;` forward-declare is wrong and causes cascading, misleading errors.** `FEditorModeID` is `typedef FName FEditorModeID` (in `Editor.h`), not a class/struct. Forward-declaring it as `struct` in a header that gets included before `Editor.h`/`EditorModeManager.h` elsewhere in the same translation unit causes `C2371: redefinition; different basic types` - and because it corrupts an early part of the parse, the **real symptom shows up as unrelated-looking errors far downstream** (in this case, `SNexusFrameworkPanel.h`'s unrelated `FOnSetObject` type going "unresolved" and Slate's `operator[]` overloads failing to match, none of which mention `FEditorModeID` at all). **Fix: never forward-declare a typedef you haven't verified is a real class - use the underlying type (`FName` here) directly instead.** If a similarly bizarre, deeply-cascading Slate/UHT error shows up again with no obvious cause near the reported line, suspect a bad forward-declaration earlier in the same header chain before assuming the reported line itself is wrong.
2. **`SNexusFrameworkPanel.h` used `FOnSetObject`/`FAssetData` in method signatures without including their headers** (`PropertyCustomizationHelpers.h`/`AssetRegistry/AssetData.h`) - only the `.cpp` had them. Worked in V4 because V4's header included both; easy to miss when writing the header fresh instead of copying V4's include list exactly. **Always copy a ported file's original include list into the new header/cpp split, don't assume the .cpp's includes cover the .h's own needs.**

## What Phase 1 does NOT include yet (do not assume done)

- **Viewport/3D highlighting is NOT implemented** - only Hierarchy-tree row selection/expansion sync (`SyncTreeSelectionFromSubsystem`) exists. The plan's 1.6 (select a City → highlight its highways/points/segments/bounds in the 3D viewport) needs actual debug-draw or component-highlight code, which doesn't exist at all yet - there's no `Render()`/`DrawHUD()`-equivalent anywhere in this module. This is a real gap, not a rename - don't report 1.6 as satisfied.
- No mesh/debug-render Phase 2 details panels (rename/Code/mesh-override/debug-override UI for State/City/Highway) - `FNexusState`/`FNexusCity`/`FNexusHighway` all have the override *fields* now, but no panel UI reads/writes them.
- No `ConnectPoints`/junction-continuity-rule graph mutator - `AddPointToHighway` just appends, no splitting/branching logic ported yet.
- No Landscape interaction at all (Phase 3) - `TSoftObjectPtr<ULandscapeSplineControlPoint> SourcePoint` exists on `FNexusRoadPoint` but nothing ever sets it.

## Verification performed

- `Build.bat NexusFrameworkEditor Win64 Development` and `Build.bat NexusFramework Win64 Development` (standalone game target) both succeed.
- Editor launched via `UnrealEditor.exe <uproject> -log` and reached full Slate/UI init with **no crash, no assert, no fatal error** in `Saved/Logs/NexusFramework.log` - confirms the `FEditorModeManager`/tab-registration deferral pattern didn't reproduce the earlier documented `GLevelEditorModeTools()`-too-early crash.
- **2026-08-08: user manually confirmed** - tab shows/hides correctly on Landscape Mode enter/exit, docks, moves, and switches panels fine. Phase 1 is fully done, not just build-verified. Cleared to start Phase 2.
