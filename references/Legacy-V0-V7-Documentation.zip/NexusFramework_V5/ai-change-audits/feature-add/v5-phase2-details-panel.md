---
name: project_v5_phase2_details_panel
description: Phase 2 of the direct-in-Landscape city authoring redesign - UNexusHighwayMeshAssetSet ported from V4 (full, incl. street furniture), mesh/render/font-size override fields added to FNexusState/City/Highway, and a native IStructureDetailsView-based details panel wired into the Hierarchy tree with Code-uniqueness validation. User confirmed working 2026-08-08.
metadata:
  node_type: memory
  type: project
  originSessionId: ba6d180c-7c4c-42aa-b8a6-c1389d9efa9c
  modified: 2026-08-07T18:53:30.139Z
---

Implemented Phase 2 of [[project_v5_direct_landscape_city_todo]] on top of [[project_v5_phase1_authoring_panel]]. Two explicit user decisions resolved the plan's Phase 2 open questions before building:
1. **Mesh override at State/City level** = a `TSoftObjectPtr<UNexusHighwayMeshAssetSet>` soft-ref override field (mirrors `FNexusCity::LayoutSettingsOverride`'s existing pattern), falling back State→City→Highway→global. Required first porting `UNexusHighwayMeshAssetSet` from V4 since V5 had no mesh-asset-set type at all yet.
2. **Font-size scope** = user wants it for a *future* viewport overlay rendering City/Highway/Lane/State name+code AND waypoint/junction-type labels - "for now just put the data-assets assign and save the config when layout is saved." So: schema fields added now (`bOverrideFontSize`/`OverrideFontSize` on all three levels), **no rendering implemented** - that's future viewport-HUD work, not Phase 2's job. Don't build the overlay unprompted; just don't lose track of these fields existing.

## What was built

- **`Schema/Editor/NexusHighwayMeshAssetSet.h`** (new, ~530 lines) - **full port from V4** (`FNexusMeshConfig`/`FNexusHighwayRoadMeshConfig`/`FNexusSpacedMeshConfig`/`FNexusAreaMeshConfig`/`FNexusBusStopMeshConfig`/`FNexusHighwayDimensions`/`FNexusHighwayMeshSet`/`UNexusHighwayMeshAssetSet`), including the street-furniture half V4 itself still calls "design only, unread" - **user explicitly chose full port over road-mesh-only** when asked, so this is deliberate, not scope creep. All `_API` macros changed `NEXUSFRAMEWORK_API`→`NEXUSFRAMEWORKEDITOR_API` (lives in `NexusFrameworkEditor` now, not `NexusFramework` - V4 had this in the Runtime module, V5 keeps the whole mesh-authoring concept editor-only per the schema's current home in `Schema/Editor`). Static resolver helpers (`ResolveDecorationSlot` etc.) ported verbatim - nothing calls them yet, same as V4.
- **`FNexusState`/`FNexusCity`/`FNexusHighway`** (all modified) - each gained `bOverrideFontSize`/`OverrideFontSize` (default 12, ClampMin 1) and `MeshAssetSetOverride` (`TSoftObjectPtr<UNexusHighwayMeshAssetSet>`). Resolution chain documented in each field's comment: State→City→Highway→(future) global default, most-specific wins.
- **`UNexusFrameworkEditorSubsystem::MarkLayoutDirty()`** (new, trivial setter) - needed because the details panel edits `WorldData` map entries directly in-place (see below), bypassing every existing mutator method that used to be the only place `bIsDirty` got set.
- **Details panel** (`SNexusFrameworkPanel` additions): a new "Details" section between Hierarchy and Layout Tools, built from Unreal's **native `IStructureDetailsView`** (`FPropertyEditorModule::CreateStructureDetailView`), not hand-rolled widgets. `RefreshDetailsPanel()` wraps whichever State/City/Highway struct is currently active-selected in an `FStructOnScope(UScriptStruct*, uint8* InData)` pointing **directly at the live map entry** (`World.FindState/City/Highway(ActiveId)`), non-owning - edits through the details view write straight into `WorldData`'s actual `TMap` storage, no copy/apply/write-back step. Re-run on every `OnActiveSelectionChanged`/`OnLayoutChanged` broadcast so the wrapped pointer never goes stale across a `TMap` reallocation. This gets rename/Id-readonly/mesh-override-picker/color-picker/checkbox UI entirely for free from the structs' own UPROPERTY metadata (`VisibleAnywhere` Id fields render grayed-out automatically; `EditCondition` metadata already on the Render fields drives the checkbox-gates-color-picker graying) - no per-field widget code needed, unlike V4's hand-built `BuildCheckboxRow`/`BuildAssetPicker` pattern.
- **Code uniqueness**: `FNexusWorldData::IsStateCodeUnique`/`IsCityCodeUnique`/`IsHighwayCodeUnique` (new) - **scoped per-type**, not globally across all four hierarchy levels (a State and a City can share a Code; two States cannot) - this was an inferred design choice, not explicitly asked, reasoning: Code is meant for gameplay triggers like "the killer is on highway HB2," which only need to disambiguate within one kind of thing. `SNexusFrameworkPanel::HandleDetailsPropertyChanged` checks `PropertyChangedEvent.Property->GetFName() == GET_MEMBER_NAME_CHECKED(FNexusState, Code)` (works for all three structs since they share the exact member name `Code`) and reverts to `NAME_None` + shows a message dialog on collision, matching the existing "NAME_None always valid, never collides with itself" rule already documented on the Code fields.

## Non-obvious implementation choice worth remembering

**Used `IStructureDetailsView`/`FStructOnScope` instead of hand-building per-field widgets** (V4's `BuildCheckboxRow`/`BuildAssetPicker`/etc. pattern) for the details panel. This was a deliberate architecture call, not requested explicitly - reasoning: V4's structs didn't have this many override fields with EditCondition/ClampMin metadata: hand-building a color picker, spinbox, and asset picker per field for State+City+Highway (3x the same field set) would have been a lot of repetitive Slate code for something the engine already does automatically from UPROPERTY metadata. **How to apply**: if Phase 2's scope grows (e.g. Point ever gets a details block), extend this same pattern (add a case to `RefreshDetailsPanel`'s switch) rather than reverting to hand-built widgets - it's the same one-line addition per new selection kind.

## Build/module changes

No new Build.cs dependencies needed - `PropertyEditor` module was already in `PrivateDependencyModuleNames` from Phase 1. New includes: `PropertyEditorModule.h`, `IStructureDetailsView.h`, `UObject/StructOnScope.h`, `Misc/MessageDialog.h` in `SNexusFrameworkPanel.cpp`.

## Verification performed

- `Build.bat NexusFrameworkEditor` and `Build.bat NexusFramework` (standalone game target) both succeed.
- Editor launched via `UnrealEditor.exe <uproject> -log`, reached stable running state, **no crash/assert/fatal in `Saved/Logs/NexusFramework.log`**.
- **2026-08-08: user manually confirmed and liked it** ("I love it") - Details panel fields, editing, and Save/Load persistence all work as intended. Phase 2 is fully done. Cleared to start Phase 3.

## What Phase 2 does NOT include (do not assume done)

- No font-size *rendering* - fields exist, nothing reads them (explicit user scope decision, see above).
- No mesh-asset-set *resolution* logic wired into anything yet (no Apply/Refresh exists - that's Phase 3) - the override fields and the resolver static helpers exist but nothing calls the resolution chain end-to-end.
- Point still has no Phase 2 details UI (only State/City/Highway, matching the original plan's Phase 2 scope - Point-level decoration/target editing was never part of this phase).
- Still no viewport highlighting (carried over gap from Phase 1, see [[project_v5_phase1_authoring_panel]] - still not started).
