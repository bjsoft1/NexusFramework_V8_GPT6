---
name: v5-phase4-todo-refactors
description: "4 queued refactor/feature TODOs handed off at 2% session limit (2026-08-08), not yet started - UI cleanup, a junction-mesh bug, Point details panel support, new Landscape<->Nexus sync-diff dockable tab."
metadata: 
  node_type: memory
  type: project
  originSessionId: 8c39eae7-0f64-4ea9-b261-8f332775fe5a
  modified: 2026-08-08T16:58:43.010Z
---

Recorded verbatim from the user at end of a session that hit its 2% context
limit before any of these could be started - nothing below is implemented yet.
See [[project_v5_phase3_landscape_click_to_place]] for the full Phase 3 history
these build on (Hierarchy tree, Details tab, Delete, Duplicate/New context-menu
actions, Load Layout's new geometry-choice dialog, stored Point Location/
OutgoingTangentLen, per-highway terrain fields - all from the session just before this one).

## 1. Remove the "Selected Layout" dropdown/asset-picker

`SNexusFrameworkPanel.cpp`'s Config section (`BuildAssetPicker(LOCTEXT("SelectedLayoutLabel", "Selected Layout")...)`)
is used less now that Load Layout has its own native asset-picker dialog
(`PromptForExistingLayoutAsset`) - same "redundant surface, remove it" reasoning
already applied to the standalone outside Delete button earlier in Phase 3.

**Gotcha for whoever picks this up**: `DeleteLayout()`
(`NexusFrameworkEditorSubsystem.cpp`) reads `SelectedLayoutAsset`, which is
CURRENTLY ONLY EVER SET by this same dropdown (`OnSelectedLayoutAssetChanged`).
Removing the dropdown outright silently breaks the Delete Layout button (no way
left to pick a target). Needs a decision: either also remove the Delete Layout
button, or give it its own `PromptForExistingLayoutAsset`-style picker dialog
the same way Load Layout already works, instead of relying on a pre-selected
dropdown value.

## 2. Straight/SmoothCorner points shouldn't get a junction mesh

User's exact words: "If the junction is straight/smooth corner then do not
apply highway mesh, due to the auto handle by UE segment."

`RecomputePointClassification` (`NexusFrameworkEditorSubsystem.cpp`) is
supposed to already clear `ControlPoint->Mesh` back to null for
Straight/SmoothCorner NodeTypes (those rely on the connected segments' own
SplineMeshes to carry the road through, not a control-point mesh - only real
junctions TJunction/CrossJunction/MultiJunction get a control-point mesh via
`ResolvePointMeshSlot`). The user is observing a highway mesh still showing up
at these points in practice - needs live investigation to find where that
clearing isn't actually taking effect (check every call site:
`PlacePointOnLandscape`, `ApplyHighwayConfiguration`, `GenerateCityInternalGrid`,
`MaterializeMissingPointGeometry` - confirm `MeshScale` is also reset, not just
`Mesh`, and confirm this runs AFTER the point's final connection count is known
in every path, not before).

## 3. Details panel needs a Point case (currently has none at all)

`SNexusFrameworkDetailsPanel::RefreshDetailsPanel` (`SNexusFrameworkDetailsPanel.cpp`)
explicitly has no branch for `ENexusFrameworkSelectionKind::Point` today
("None/Point - no Phase 2 details UI yet for Point" in its `default:` case) -
selecting a Point (from the Hierarchy tree OR a native Landscape click, both of
which already correctly set the active selection) shows nothing.

User wants: Name, Code, Id, Tangent info, Parent info all shown, editable
EXCEPT Id and Parent info.

Good news: `FNexusRoadPoint`'s own UPROPERTY specifiers (`NexusRoadPoint.h`)
already encode most of this correctly for the same `IStructureDetailsView`/
`FStructOnScope` mechanism the State/City/Highway cases already use - `PointId`
is `VisibleAnywhere` (read-only), `ConnectedHighwayIds` (the "Parent info" -
which highway(s) own it) is `VisibleAnywhere` (read-only), `Location` is
`VisibleAnywhere` (read-only, it's a geometry snapshot not meant for manual
editing), `Code`/`Name`/`OutgoingTangentLen` are all `EditAnywhere`. So this is
likely just: add a `case ENexusFrameworkSelectionKind::Point:` to
`RefreshDetailsPanel` building `FStructOnScope(FNexusRoadPoint::StaticStruct(), ...)`
the same way City/Highway already do, plus a matching branch in
`HandleDetailsPropertyChanged` for Code-uniqueness validation
(`World.IsPointCodeUnique`, already exists) and `OnEntityLabelChanged`
broadcasting on Name/Code edits (same pattern, just needs the Point case added
to that switch too).

## 4. New dockable "Sync Diff" panel - Nexus WorldData vs live Landscape

A NEW, separate dockable tab (third one, alongside Hierarchy and Details -
reuse `NexusFrameworkLandscapeModeExtension`'s `RegisterNomadTabSpawner`
pattern) showing a tree in the SAME shape as the Hierarchy tree
(State > City > Highway > Point), but for VISUALIZING mismatches between
WorldData and the actual live Landscape spline data, not for selection/editing.

Branches for whatever doesn't match cleanly:
- **Exists in UE Landscape, not in our Layout** - an untracked control point
  (today's `SyncFromLandscape`'s import direction handles this blindly/
  automatically; this panel would surface it as a browsable list first instead).
- **Exists in our Layout, not in UE Landscape** - an orphaned Nexus point whose
  `SourcePoint` doesn't resolve (today's `RemoveOrphanedPointsFromLandscape`/
  Sync From Landscape's removal direction, same "make it visible/browsable
  first" idea).
- **Exists in both, but Tangent value mismatch** - newly relevant now that
  Phase 3 added `FNexusRoadPoint::OutgoingTangentLen` as a saved snapshot that
  can legitimately drift from the live segment's actual `TangentLen` between
  an Apply/Save (see `SyncPointGeometrySnapshots`).
  - **Optional, user flagged as maybe-not-needed**: Exists in both, but Code/
  Name/other metadata missing on one side - only worth comparing if the live
  Landscape object actually carries an equivalent field to compare against.

This is a genuinely large, standalone feature (new tab registration, a real
diff-computation pass over WorldData + the target Landscape's control
points/segments, its own tree-building code) - scope it as its own planned
piece of work, not a quick bolt-on to the existing Hierarchy tree.

## Session update (2026-08-08, later session, ended at 4% limit)

Items 1-3 DONE and build-confirmed by user this session:
- #1: dropdown + dead `SelectedLayoutAsset`/`DeleteLayout()`/`OnDeleteLayoutClicked` removed entirely (user chose "remove entirely" over "give it its own picker").
- #2: fixed - `ResolvePointMeshSlot` was returning `&MeshSet->MainHighwayMesh` for Straight/SmoothCorner instead of `nullptr` (root cause, not a clearing-order bug as guessed above).
- #3: done - Point case added to `RefreshDetailsPanel`/`HandleDetailsPropertyChanged` exactly as scoped above.

**#4 (Sync-Diff tab) still PAUSED, not started.** A full technical design was produced (Plan agent) before the user paused it: new `SNexusFrameworkSyncDiffPanel` + `ENexusSyncDiffStatus` enum + `FNexusSyncDiffTreeItem` tree row + subsystem-side `ComputeSyncDiff()`/`FNexusSyncDiffResult` (read-only, reuses `BuildChainsFromUntrackedPoints`/`FindConnectingSegment` already in `NexusFrameworkEditorSubsystem.cpp` - no engine-Landscape includes needed in the new widget itself). One real open question blocked implementation: should a mismatch just COLOR the existing row (simpler, Plan-agent-recommended), or add an explicit extra child row spelling out the problem (matches the user's literal original wording more closely, more tree clutter)? User was asked this directly and didn't resolve it before running low on context - ask again before implementing. See this file's own git history / session transcript for the full Plan-agent design doc if needed (not saved verbatim to memory - regenerate via a Plan agent pass over `NexusFrameworkEditorSubsystem.cpp`'s `SyncFromLandscape`/`RemoveOrphanedPointsFromLandscape` if the design needs re-deriving).

Session also built a large, unrelated-to-this-file feature: real-time Landscape->Nexus sync via `OnObjectTransacted`. See [[project_v5_landscape_nexus_two_way_sync]].

## Session update (2026-08-08, later session) - #4 Sync-Diff tab IMPLEMENTED, not yet build-verified

The open question from the previous session (color-only row vs. explicit mismatch-detail child rows) was resolved by the user's own next handoff doc: explicit detail rows, spelling out exactly which field(s) differ with Nexus-vs-UE values shown - not just a color/label. Implemented accordingly, following [[feedback_user_builds_and_verifies]] (code-only, no build/launch attempted).

**Subsystem** (`NexusFrameworkEditorSubsystem.h`/`.cpp`): added `ENexusSyncDiffStatus` (Synchronized/MissingInUE/UntrackedInNexus/Mismatch, plain enum, not UENUM), `ENexusSyncMismatchFlags` bitflags, and plain struct `FNexusSyncDiffEntry` (ancestry ids, DisplayLabel, ControlPoint weak ptr, ChainIndex, MismatchFlags, Nexus/UE Location+Rotation+Tangent pairs) - all declared at file scope above the class, next to `ENexusFrameworkSelectionKind`. New method `TArray<FNexusSyncDiffEntry> ComputeSyncDiff() const` - const, read-only, no `Modify()`/transaction/mutation. Walks State->City->Highway->OrderedPointIds top-down (so every entry carries full ancestry), classifying each Point via the exact same tolerances `OnLandscapeSplineObjectTransacted` already uses (Location 0.5, Rotation 0.1, Tangent 0.5 incl. the "-1 stays -1 if live value matches the auto-distance formula" rule) - then scans the target Landscape's control points for ones no tracked Point referenced, grouping via the existing anonymous-namespace `BuildChainsFromUntrackedPoints` (called read-only, nothing imported).

**New UI** (`Public/UI/SNexusSyncInspectorPanel.h` + `Private/UI/SNexusSyncInspectorPanel.cpp`): `SNexusSyncInspectorPanel` widget, `FNexusSyncDiffTreeItem` row struct (mirrors `FNexusOutlinerItem`'s "rebuilt from scratch, never mutated" convention), `ENexusSyncDiffRowKind` (Branch/State/City/Highway/Point/MismatchField/MismatchDetailLine/UntrackedChain/UntrackedPoint). Manual "Refresh Sync Diff" button (not per-tick - `ComputeSyncDiff` isn't free and a per-tick rebuild would collapse tree expansion state every frame). Four always-shown branch rows with live counts in the label. Click-to-focus reuses `SetActiveState/City/Highway/Point` + `GetActiveSelectionBounds`/`GEditor->MoveViewportCamerasToBox` exactly as the Hierarchy tree's own `FocusViewportOnActiveSelection` does - deliberately NEVER `ULandscapeSplineControlPoint::SetSplineSelected` (confirmed crash-prone, already disabled elsewhere - see `RefreshLandscapeSelectionHighlight`'s own comment). Untracked/MissingInUE rows (no live Nexus selection to make) fall back to a small box built from a stored best-effort world location; grouping rows (State/City/Highway/Chain) get theirs via bottom-up averaging of descendant leaf locations (`PropagateFocusLocations`).

**Tab registration** (`NexusFrameworkLandscapeModeExtension.h`/`.cpp`): third `RegisterNomadTabSpawner` (`NexusSyncInspectorPanel` id, "Nexus Sync Inspector" display name), opened/closed in lockstep with the other two on Landscape Mode enter/exit, same as the existing pattern.

**Gotcha hit and fixed during this session**: literal Unicode checkmark/warning glyphs (✓/⚠) typed into a `TEXT()` string literal kept round-tripping unchanged through Edit tool calls even when attempting a `\u` escape-sequence replacement - suspected source-encoding risk with MSVC on a non-BOM UTF-8 .cpp. Worked around by using plain ASCII `[OK]`/`[!]` prefixes instead of Unicode symbols for the branch labels - avoids the risk entirely, still reads fine. Worth remembering if a future session wants real glyph icons here: verify the project's MSVC invocation actually passes `/utf-8` (or the file has a BOM) before trying literal Unicode in a string literal again.

Not yet build-verified - user needs to compile and open the new "Nexus Sync Inspector" tab (auto-opens with the other two on entering Landscape Mode) to confirm it compiles and the tree/focus behavior works as intended.
