---
name: v5-auto-save-after-map-save
description: "New save architecture (2026-08-08): removed manual Save Layout/Save Layout As buttons; UE map save is now the authoritative save trigger, Nexus auto-saves its Layout asset right after via FEditorDelegates::PostSaveWorldWithContext. Not yet build-verified."
metadata:
  node_type: memory
  type: project
  originSessionId: 981d13f6-153a-4882-9852-bbbc0e384a44
  modified: 2026-08-08T17:47:13.033Z
---

## Architectural rule (user's own words)

"UE map save is the authoritative save event. Nexus follows UE's successful save."
Manual `Save Layout`/`Save Layout As` buttons removed; not to be reintroduced unless
explicitly requested later.

## Research: the delegate

`FEditorDelegates::PostSaveWorldWithContext` - `(UWorld* World, FObjectPostSaveContext
ObjectSaveContext)`, broadcast unconditionally (success/failure/autosave alike) from
`UEditorEngine::OnPostSaveWorld` (`EditorEngine.cpp:5065`, confirmed by reading the
function body, not guessed). `FObjectPostSaveContext::SaveSucceeded()` is the actual
success signal - engine source also confirmed the autosave branch of that same function
deliberately does NOT clear the package's real dirty flag (autosave is a background
backup copy, not a real user save).

## Implementation

**Subsystem** (`NexusFrameworkEditorSubsystem.h`/`.cpp`):
- New `ENexusLayoutSaveResult { Succeeded, Failed, Cancelled }` - `SaveLayout()`/
  `SaveLayoutAs()` changed from `void` to this (previously `bIsDirty = false` was set
  UNCONDITIONALLY regardless of whether `UEditorAssetLibrary::SaveLoadedAsset` actually
  succeeded - a latent bug even in the old manual-save flow, now fixed: only clears
  `bIsDirty`/reports `Succeeded` on a real successful write).
- New `HandlePostSaveWorld(UWorld* World, FObjectPostSaveContext ObjectSaveContext)`,
  bound/unbound in `Initialize()`/`Deinitialize()` (`PostSaveWorldHandle`), same lifecycle
  pattern as `HandleMapOpened`/`OnMapOpened` (see [[project_v5_cross_map_sourcepoint_bug]]).
  Three guards before doing anything: `SaveSucceeded()`, `!IsFromAutoSave()`,
  `World == GEditor->GetEditorWorldContext().World()` (only the current editor world -
  same scoping `ResolveTargetLandscape()` already uses, directly satisfies "only the
  active map/layout" requirement). Then no-op if `!bIsDirty` (every WorldData mutation,
  including every Landscape->Nexus live-sync branch, already calls `MarkLayoutDirty()`,
  so a Landscape edit the live sync picked up is guaranteed still-dirty here - no extra
  bookkeeping needed to satisfy "must stay synchronized with the newly saved Landscape").
  Otherwise calls the EXISTING `SaveLayout()` (which itself falls through to
  `SaveLayoutAs()` - prompting the native Save Asset dialog - when `CurrentLayoutAsset` is
  unset; user explicitly chose this "auto-prompt the existing dialog" option over
  silently skipping or keeping a manual bootstrap button, when asked directly).
- Mid-session addition (user: "if saved failed notify retry"): on
  `ENexusLayoutSaveResult::Failed` (a genuine write failure - checkout/permission/disk
  error, NOT `Cancelled` which is the user declining the Save Asset dialog and is left
  alone/not nagged about), loops a Yes/No `FMessageDialog` "retry?" and calls
  `SaveLayout()` again on Yes; declining leaves `bIsDirty` true so the next successful map
  save retries automatically regardless - sync is never permanently lost just because the
  user dismissed one retry prompt.
- No recursion risk: `SaveLayout()`/`SaveLayoutAs()` save the Layout ASSET's own package
  (`UEditorAssetLibrary::SaveLoadedAsset` on a `UNexusLayoutAsset`), never the world/map
  package - `PostSaveWorldWithContext` is specifically wired to `UWorld`'s own
  `PostSaveRoot` path, so saving an unrelated asset object cannot re-fire it.

**UI** (`SNexusFrameworkPanel.h`/`.cpp`): removed the two Save/Save As buttons and their
`OnSaveLayoutClicked`/`OnSaveLayoutAsClicked` handlers entirely. `SaveLayout()`/
`SaveLayoutAs()` themselves untouched/still reused by `ResolveUnsavedChangesBeforeProceeding`'s
own "Yes, save first" branch (still reachable from New Layout/Load Layout's own unsaved-
changes prompt, unchanged).

## Interaction with the map-change reset (already in place, see [[project_v5_cross_map_sourcepoint_bug]])

`HandleMapOpened` already resets `WorldData`/`CurrentLayoutAsset`/`bIsDirty` on every level
switch - combined with `HandlePostSaveWorld`'s own current-world-only guard, this is
belt-and-suspenders against ever auto-saving stale data from a previous map while a
different one is active.

Not yet build-verified - the task's own 6-point testing matrix (normal save, no-op when
clean, Location/Rotation/Tangent/segment sync all still trigger a save, map-change
isolation, save-failure/retry) still needs running once compiled.
