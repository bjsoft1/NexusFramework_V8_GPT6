---
name: project_v5_direct_landscape_city_todo
description: Agreed 4-phase plan for V5's direct-in-Landscape city authoring redesign (replaces V4's skeletal-then-build-segment two-step). Core architecture - Nexus owns config, Landscape owns geometry, sync is explicit user actions - plus the full Phase 1-4 breakdown and open questions.
metadata:
  node_type: memory
  type: project
  originSessionId: ba6d180c-7c4c-42aa-b8a6-c1389d9efa9c
  modified: 2026-08-07T18:11:59.172Z
---

User's stated goal: V4 (`E:\Projects\Game\UE\NexusFramework_V4`) generates a "skeletal" structure first (points/blueprints, no visuals), then a separate "Build Landscape Segment" step deforms the actual Landscape. V5 should skip that - generate the city directly into the Landscape as one step. Final target output is `FNexusFrameworkResult` (`Schema/Runtime/NexusFrameworkResult.h`: `HighwayPoints`/`ParkingPoints`/`BusStopPoints`/`InteractablePoints`).

Plan was produced after a dedicated research pass through V4's actual code (not just file names) - see that research's findings folded into "What's carried over vs. new" below. User then added a formal sync/ownership architecture on top, which resolved the plan's single biggest open question.

## Core architecture: Nexus owns config, Landscape owns geometry, sync is explicit

- **Nexus Layout Asset is the only source of truth for configuration** (mesh assignments, width, thickness, material overrides, decoration/generation settings, custom metadata). Never stored on/read from `ULandscapeSplineControlPoint`/`Segment`/mesh components - those are a **derived, disposable rendering** of Nexus's config + geometry, safe to rebuild from scratch any time.
- **Landscape owns geometry only** - point location, rotation/tangents, height, segment shape/connections. Native Landscape Spline tools (drag a point, adjust a tangent) are used directly, not reinvented.
- **Nexus keeps its own point/highway/city/state structs**, each point carrying a `TSoftObjectPtr<ULandscapeSplineControlPoint>` back-reference (same keying as [[project_v5_landscape_native_highway_pivot]]) - config and geometry are linked, never merged into one struct.
- **Sync is one-directional per concern, not bidirectional per field**: config flows Nexus→Landscape only (Apply/Refresh); geometry flows Landscape→Nexus only (Sync From Landscape) - never the reverse for either. Config is never overwritten by anything read back from Landscape.
- **Sync points are explicit user actions** (Save/Apply/Refresh/Rebuild/manual Sync), never automatic on every edit. Incremental/dirty-tracking sync is an explicitly deferred future optimization.

```
Nexus Layout Asset (config + Nexus's own point/highway/city/state structs)
        │  Apply / Refresh  (config + geometry → Landscape, one-directional)
        ▼
Landscape Splines (Control Points / Segments / Tangents / Heights - disposable, rebuildable)
        │  Sync From Landscape  (geometry ONLY → Nexus points, one-directional, never touches config)
        ▼
Nexus point Location/Rotation/Tangents updated
```

## What's carried over from V4 vs. genuinely new work

**Reusable almost as-is**: `FNexusRoadGraph`-style mutator logic (continuity rule on connect) - needs a State-aware rewrite (V4 had no State level); `UNexusLayoutGenerator::GenerateRandomLayout`'s city-grid + inter-city-highway algorithm (pure graph math, zero terrain dependency in V4); `UNexusJunctionAnalysis` angle-based classification; the asset-based Save/Load/New pattern including its hard-won gotchas (reuse loaded package on re-save, unsaved-changes gate, `RegisterCanCloseEditor` hook); `UNexusHighwayMeshAssetSet`'s 3-tier mesh/decoration override resolution.

**Must change**: V4 used a **flat** `Settings->GroundHeight` constant during generation (deformation was a separate later step) - direct generation needs real terrain height sampling *during* placement, the single biggest logic change, not a refactor. V4's three parallel visualization layers (always-on preview actors + two opt-in "commit to Landscape" steps) collapse into the Nexus-config/Landscape-geometry split above - no separate always-on preview-actor layer. No `ANexusHighwayRoadActor` at all; `SyncHighwayActorsFromGraph`'s diff-by-GUID pattern is replaced by Apply/Refresh/Sync-From-Landscape reconciling against Landscape spline objects directly.

**Confirmed dead/stub in V4, not worth porting as reference**: `UNexusDataCompiler`, `UNexusMeshMergeService`, `UNexusDecorationPreviewBuilder`, `UNexusCityInternalRoadGenerator`, `UNexusGraphValidator` - all pure `unimplemented()`. `FNexusCity::LayoutSettingsOverride` exists in schema but has zero working logic or UI anywhere in V4.

## Phase 1 — Panel shell + data model + save/load (COMPLETE - see [[project_v5_phase1_authoring_panel]])

Dockable tab gated on Landscape Mode; Nexus-owned data model (State→City→Highway→Point); New/Save/Save As/Load/Delete Layout; default State1>City1>Highway1 + auto-assign to active highway; active-selection tracking. **Viewport highlighting (1.6: select City→highlight its highways/points/segments/bounds) was NOT completed** - only Hierarchy-tree row selection sync exists. Full implementation details, files, and two real build bugs hit (bad `FEditorModeID` forward-declare; missing header includes) are in [[project_v5_phase1_authoring_panel]] - read that before resuming/extending Phase 1 work.

## Phase 2 — Per-node config UI (details panels) + overrides (NOT STARTED)

Per-State/City/Highway inline details block in the Hierarchy: rename Name/Code (Id read-only, auto-generated, unique), mesh config override, debug/render config override (color, line thickness, font-size). State needed render-override fields added first (done in Phase 1 - `bOverrideRenderColor` etc. now exist on `FNexusState`, matching City/Highway). Highway is also where the full "must never be edited in Landscape's own details panel" config list lives: Road/Junction/Sidewalk Mesh, Width, Road Thickness, Mesh Scale/Offset, Material Overrides, Decoration Settings, Generation Settings, Custom Metadata - these fields must not exist as UPROPERTYs on any Landscape spline object at all (not present-but-disabled), only ever written there as an Apply/Refresh byproduct.

**Open question carried in**: font-size override scope - requirement listed it once across State/City/Highway, worth confirming exactly what UI element it controls before building.

## Phase 3 — Direct-into-Landscape generation + Apply/Refresh/Sync workflow (NOT STARTED)

Terrain-aware point placement (real height sampling during generation, replacing V4's flat constant) requires a real `ALandscape` in the level - **open question**: does Generate require one to already exist, or offer to create it? Port `GenerateRandomLayout`'s algorithm; generation = author Nexus data then immediately run Apply. Carry forward V4's junction-blending lesson (build all control points/segments first, one `RequestSplineLayerUpdate` pass, never independent per-highway calls - avoids seam/spike artifacts, this is an API constraint not a V4 design choice). Implement the full explicit action set: **Apply Configuration** (config only, no position changes), **Refresh Landscape** (full rebuild from config+geometry), **Sync From Landscape** (geometry only, one-directional into Nexus), **Sync To Landscape** (push Nexus geometry out, distinct from Apply/Refresh), **Rebuild Selected City** / **Rebuild All Cities**. "Generate random city" then allows manual position adjustment via native Landscape dragging afterward.

**Open question carried in**: does Save Layout implicitly run Sync From Landscape first (so geometry edited directly in Landscape is never silently lost), or are Save and Sync fully independent and the user must remember to Sync first? Given the emphasis on never losing config/geometry across New/Load/Delete/Generate, this needs an explicit decision, not a silent default.

## Phase 4 — Menu polish + developer overrides + FNexusFrameworkResult export (NOT STARTED)

Visual polish matching V4's panel-positioning conventions (do this after Phase 1-3's shape is stable, not before). Developer data-asset override picker section (Generation Settings/Mesh Asset Set/etc., mirroring V4's Config section). Export pass: walk authored Nexus config + synced Landscape geometry, populate `FNexusFrameworkResult`'s four arrays using the already-in-place Tier-4 `Schema/Runtime` structs as the target shape - V4 never got this far (its equivalent was a pure stub), so this is new work end to end with no V4 reference implementation to port.
