---
name: project_v5_landscape_native_highway_pivot
description: V5 highway schema pivoted from Nexus-owned GUID graph to Unreal Landscape-Spline-native geometry; Phase 1 (schema only) complete.
metadata: 
  node_type: memory
  type: project
  originSessionId: c77d3cfc-afa7-465c-97ad-97db9114e96a
  modified: 2026-08-07T17:04:30.095Z
---

User handed a new design doc: "V5 Landscape Native Highway Framework" — highway geometry must be owned by Unreal (`ALandscape` → `ULandscapeSplinesComponent` → `ULandscapeSplineControlPoint`/`ULandscapeSplineSegment` → `USplineMeshComponent`), Nexus only adds metadata (identity, lane config, traffic rules, city/state relationship, runtime export). Explicit rule: "Do not create another spline system... do not store duplicate spline geometry."

**Why this wasn't a surprise**: `Schema/Editor/NexusState.h`'s doc comment already said "spline geometry stays owned by Unreal Landscape Splines... never by FNexusState" — a past design pass (see [[project_v5_hierarchy_redesign]]) had already anticipated this direction, but `FNexusRoadPoint`/`FNexusHighway`/`FNexusRoadGraph` as originally written contradicted it (they owned Location/Rotation/tangents and had their own GUID-based mutator API: `AddPoint`, `ConnectPoints`, `InsertPointOnHighway`, etc.). No `.cpp` ever implemented those mutators — this was schema-only, so retiring them was a clean pivot, not a migration with real behavior to port.

## What changed (Phase 1 — schema only, per user's explicit phase choice)

- **Deleted** `Schema/Editor/NexusRoadPoint.h` (geometry-owning point struct) and `Schema/Editor/NexusRoadGraph.h` (GUID-graph + all its mutators).
- **New** `Schema/Editor/NexusHighwayPoint.h` — `FNexusHighwayPoint`: metadata only (Code, PointFeatures, PointTargets, Description, render-override fields), keyed by `TSoftObjectPtr<ULandscapeSplineControlPoint> SourcePoint`.
- **New** `Schema/Editor/NexusWorldData.h` — `FNexusWorldData`: replaces `FNexusRoadGraph` as the top-level container (States/Cities/Highways maps + `PointMetadata: TMap<TSoftObjectPtr<ULandscapeSplineControlPoint>, FNexusHighwayPoint>`). Only `Find*` lookups so far — no mutators (that's Phase 3, "metadata attachment system").
- **`FNexusHighway`** (`NexusHighway.h`): dropped `OrderedPointIds`/`ParentHighwayId` (GUID graph fields); added `SplinePoints: TArray<TSoftObjectPtr<ULandscapeSplineControlPoint>>` (ordered point sequence, geometry between consecutive entries comes from the Landscape spline segments, not from Nexus). Kept: Code/Name/bLockEdit/bIsMainHighway, City/State ownership (`StartCityId`/`EndCityId`, unchanged), Rules/Lanes/Sidewalks fields, and the `|Render` override fields (user explicitly chose to keep these for a future debug overlay, even though nothing reads them yet).
- **`FNexusCity`** (`NexusCity.h`): `AnchorPointId`/`NorthGatewayPointId`/`SouthGatewayPointId`/`EastGatewayPointId`/`WestGatewayPointId` (all `FGuid`) became `AnchorPoint`/`NorthGatewayPoint`/`SouthGatewayPoint`/`EastGatewayPoint`/`WestGatewayPoint` (all `TSoftObjectPtr<ULandscapeSplineControlPoint>`).
- **`NexusRoadTypes.h`**: removed `ENexusSplinePointType`/`ENexusNodeType`/`ENexusAnchorKind` (all specific to the retired Nexus-owned graph/tangent/connectivity system). Kept `ENexusHighwayOwnershipKind`, `ENexusHighwayStateSpan`, `ENexusOutlinerItemType` (still relevant — City/State ownership and UI concepts, independent of geometry ownership).
- **`NexusFramework.Build.cs`**: added `Landscape` to `PublicDependencyModuleNames` (needed once any `.cpp` in this module or a dependent resolves `ULandscapeSplineControlPoint` beyond a forward-declare).

## Key design decisions made along the way (all explicitly confirmed with user, not inferred)

1. **Metadata keying = direct `TSoftObjectPtr`, not a Nexus-assigned side-table GUID.** `ULandscapeSplineControlPoint`/`ULandscapeSplineSegment` (checked engine headers directly) expose no stable identity of their own — no `FGuid` UPROPERTY, no editable tag. `ModificationKey` exists but is `TextExportTransient`/`NonPIEDuplicateTransient`, not meant as a persistent identity. A side-table-of-Guids alternative was explicitly rejected as reintroducing the exact "duplicate parallel bookkeeping" problem the design doc's core rule warns against.
2. **`TSoftObjectPtr`, not `TWeakObjectPtr`.** Weak pointers don't survive editor restart (resolve to null), which would silently orphan all authored metadata every session. Soft pointers serialize as object paths and resolve correctly since these are normal owned `UObject` subobjects of `ULandscapeSplinesComponent`.
3. **Central registry (`FNexusWorldData.PointMetadata` map), not metadata embedded inline per-highway.** Enables O(1) "given this spline object, what's its Nexus metadata" lookup, which per-highway-embedded arrays wouldn't support without a separately-maintained index.
4. **New top-level struct named `FNexusWorldData`** (not `FNexusHighwaySplineData`/`FNexusHighwayRegistry`) — neutral name reflecting "the whole authored-world container," chosen so it won't need renaming if its role shifts again.
5. **Render-override fields (`bOverrideRenderColor` etc.) kept**, even though Landscape now renders the actual road visually and nothing currently reads these fields — user wants them reserved for a possible future debug/heatmap overlay, not dead-code-removed.

## How to apply going forward

- **Phase 2+ not started**: Landscape spline reader, metadata-attachment editor subsystem, editor UI for highway/point metadata, runtime bake/compiler, AI nav data generation are all still to come — user explicitly chose to scope this pass to Phase 1 (schema/enums only) so they could react to the `TSoftObjectPtr` keying decision before it got baked into every downstream phase.
- **Schema/Runtime (Tier 4 — `FNexusFinalHighwayData`/`FNexusFinalPointData`/`FNexusFinalCityData`/`FNexusFinalStateData`) needed no changes** — already FName-keyed, GUID-free, "locked schema" per its own header comments, and already close to the doc's target shape (more fields than the doc's sketch: SpeedLimit, Features, lanes, sidewalks, decoration flags all already present). The eventual Phase 5 runtime compiler's job is reading `FNexusWorldData` + resolved Landscape spline geometry and producing these Tier 4 structs — see [[project_v5_final_output_design_port]] for that schema's own design notes.
- Full project build-verified green after the pivot (`Build.bat NexusFrameworkEditor` succeeds). See [[project_v5_editor_module_and_build_fixes]] for other unrelated pre-existing build fixes made in this codebase.

**2026-08-07 correction**: found `NexusRoadPoint.h`/`NexusRoadGraph.h` back on disk in a later session, byte-identical to commit `def564f` (no diff at all) — the deletions described above never actually landed (uncommitted working-tree changes were lost some other way, not a deliberate revert). Only `NexusState.h`'s deletion was still staged, which broke `NexusRoadGraph.h`'s `#include "NexusState.h"`. Re-deleted both files (confirmed with user first). **Lesson: this memory's file-level claims (what was deleted/created) can silently drift from disk if uncommitted changes get lost — always verify with `ls`/`git status`/`git diff` before trusting a memory's description of current file state, especially after a gap between sessions.** Comments in `NexusCity.h`, `NexusHighway.h`, `NexusRoadTypes.h`, `NexusState.h`, `NexusHighwayFeatureTypes.h`, `NexusPointTargetTypes.h` still reference `FNexusRoadGraph`/`FNexusRoadPoint` by name (doc comments only, not real includes/types) — harmless for compilation, not yet cleaned up.
