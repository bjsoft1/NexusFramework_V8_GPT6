---
name: v5-final-output-design-port
description: "V5-Final-Output-Design.cs (C# pseudocode at repo root) was ported into C++ under Schema/Runtime and Schema/Shared, with specific typo/bug fixes applied."
metadata: 
  node_type: memory
  type: project
  originSessionId: 1ebdb727-a1c2-4779-b2e2-4c352ef30479
  modified: 2026-08-07T14:34:56.096Z
---

`V5-Final-Output-Design.cs` at the V5 repo root (namespace `NexusFramework_Structure`) was a C#-pseudocode sketch of the runtime export schema — no compilable UE C++, no State/City struct, just Highway/Point/POI/decoration types. Per user request ("compare with this all properties exists?" then "everything in the doc"), it was fully ported into the C++ `Schema/Runtime` and `Schema/Shared` folders — see [[v5_schema_folder_layout]].

**Why:** The user wanted the full POI/decoration/traffic-light/station taxonomy from that design doc, not just the bare Highway/Point/City/State shape that existed in the ported V4 structs.

**How to apply:** Treat the `.cs` file as historical/superseded — the C++ headers are now the source of truth. If the `.cs` file is edited again in the future, it needs to be re-diffed against the C++ headers, not assumed stale. Specific deliberate deviations made during the port (don't "fix" these back toward the .cs file without asking):
- Typos fixed: `AllowHavyVehicles` → `AllowHeavyVehicles`, `Petroal` → `Petrol`, `Highway_Stright` → `Highway_Straight`.
- `EHighwaySplinePointDescriptions` in the .cs file reused numeric value `4` for four different entries (`Highway_6_4_T_Junction`, `Highway_6_2_T_Junction`, `Highway_4_2_T_Junction`, `Highway_Cross_Junction`) — a bug in the source doc. Fixed by assigning each a distinct sequential value (4/5/6/7) in `ENexusPointDescription` (Schema/Shared/NexusPointTargetTypes.h). Numeric bands per category were preserved conceptually but renumbered to leave room (e.g. Highway geometry 1-19, Service Station 20-39, Station 40-59, Shop 60-79, Playground 80-99, Building 100-119, Institution 120-139, Area 140-159) — wider than the .cs file's bands, so future band additions don't collide.
- `EHighwayLanes` (the .cs file's HumanWalk/OneLane_LeftEntry/OneLane_RightEntry/TowLane/FourLane/SixLane) was NOT ported as a separate enum — merged into the existing, richer `ENexusLaneConfiguration` (Schema/Shared/NexusSharedRoadTypes.h), which already covers HumanWalk + one-way variants + TwoLanes..TenLanes. User confirmed this merge explicitly (picked "Merge into ENexusLaneConfiguration" over adding a second lane enum).
- `FConnectedHighway` (the .cs file's per-point junction-connectivity list) was NOT ported 1:1 — the existing `FNexusFinalHighwayData::OtherStateCityCode` (a narrower cross-state-only helper) was kept as-is rather than replaced; this is a real gap if general junction connectivity data is needed later.
- `FHighway.HighwayId` (a redundant Id alongside Code) was NOT added to `FNexusFinalHighwayData` — kept V4's rule that Code (FName) is the only runtime cross-reference key, no GUID/Id at runtime.
- New files added: `NexusStationInfo.h`/`NexusStationTypes.h` (FStationDynamicInformationBase → `FNexusStationInfoBase` + `FNexusParkingInfo`/`FNexusBusStopInfo`), `NexusDynamicInteractable.h`/`NexusInteractableTypes.h` (FHighwayDynamicInteractable + FTraficLight → `FNexusDynamicInteractable` + `FNexusTrafficLightState`), `NexusFrameworkResult.h` (FFrameworkResult → `FNexusFrameworkResult`, a flat aggregate separate from the State→City→Highway ownership tree, explicitly for systems that want "every point of a kind" without walking the hierarchy).
