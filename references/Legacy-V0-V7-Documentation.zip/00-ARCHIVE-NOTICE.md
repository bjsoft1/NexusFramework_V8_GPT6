# Historical documentation only

Preserved from the user's NexusFramework_V8(1).zip upload. These V0-V7 docs, old phase numbers, statuses and agent prompts are historical reference, not active V8 instructions. The current five plans live in the outer package's phases/ directory. No claim of exhaustive legacy feature parity or current test success is made. Source C++ files, project assets, executable binaries and font files are not included. Links to omitted source/assets may not resolve. These documents were copied, not re-audited end-to-end.
